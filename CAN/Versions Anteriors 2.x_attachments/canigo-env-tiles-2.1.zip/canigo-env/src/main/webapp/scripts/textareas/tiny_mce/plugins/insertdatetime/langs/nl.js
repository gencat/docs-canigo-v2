// UK lang variables

tinyMCE.addToLang('',{
insertdate_def_fmt : '%Y-%m-%d',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Datum invoegen',
inserttime_desc : 'Tijd invoegen'
});
