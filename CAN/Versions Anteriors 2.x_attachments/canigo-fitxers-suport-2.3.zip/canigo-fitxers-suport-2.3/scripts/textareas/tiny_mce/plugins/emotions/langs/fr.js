// French lang variables by Laurent Dran

tinyMCE.addToLang('',{
insert_emotions_title : 'Ins&egrave;rer un &eacute;moticon',
emotions_desc : '&Eacute;moticons'
});
