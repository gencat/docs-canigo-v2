// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('advimage',{
tab_general : 'Generelt',
tab_appearance : 'Udseende',
tab_advanced : 'Avanceret',
general : 'Generelt',
title : 'Overskrift',
preview : 'Se',
constrain_proportions : 'Fasthold proportioner',
langdir : 'Tekstretning',
langcode : 'Sprogkode',
long_desc : 'Langt beskrivelseslink',
style : 'Style',
classes : 'Klasser',
ltr : 'Venstre til h&#248;jre',
rtl : 'H&#248;jre til venstre',
id : 'Id',
image_map : 'Billedkort',
swap_image : 'Alternativt billede',
alt_image : 'Alternative image',
mouseover : 'ved mouse over',
mouseout : 'ved mouse out',
misc : 'Diverse',
example_img : 'Appearance&nbsp;preview&nbsp;image'
});
