// NO lang variables by Knut B. Jacobsen

tinyMCE.addToLang('save',{
desc : 'Lagre'
});
