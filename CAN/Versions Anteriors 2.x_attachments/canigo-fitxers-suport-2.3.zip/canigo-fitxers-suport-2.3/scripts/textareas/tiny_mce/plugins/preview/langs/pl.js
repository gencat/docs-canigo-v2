// PL lang variables

tinyMCE.addToLang('',{
preview_desc : 'Podgl�d'
});
