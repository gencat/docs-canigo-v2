/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.exceptions;

import java.io.Serializable;


/**
 * Information about layer where Exception has been arisen<br>
 * His purpose is to help in logging, auditing, etc. of errors
 *
 */
public class Layer implements Serializable {
   /**
    *
    */
   private static final long serialVersionUID = 1L;

   /**
    * CLIENT Layer
    */
   public static Layer CLIENT = new Layer("CLIENT");

   /**
    * BUSINESS Layer
    */
   public static Layer BUSINESS = new Layer("BUSINESS");

   /**
    * SERVICES Layer
    */
   public static Layer SERVICES = new Layer("SERVICES");

   /**
    * DATA ACCESS Layer
    */
   public static Layer DATAACCESS = new Layer("DATAACCESS");

   /**
    * UNDEFINED Layer
    */
   public static Layer UNDEFINED = new Layer("UNDEFINED");

   /**
    * This layer
    */
   protected String value;

   /**
    * Constructor
    * @param value the layer
    */
   public Layer() {
   }

   /**
    * Constructor
    * @param value the layer
    */
   protected Layer(String value) {
      this.value = value;
   }

   /**
    * Getter
    * @return java.lang.String
    */
   public String getValue() {
      return value;
   }

   /**
    * To string
    * @return java.lang.String
    */
   public String toString() {
      return value;
   }

   /**
    * True if this layer is equal to the <code>layer</code> argument
    * @param layer the target layer
    * @return boolean
    */
   public boolean equals(Layer layer) {
      return value.equals(layer.value);
   }

   /**
    * The hash code
    * @return int
    */
   public int hashCode() {
      return getValue().hashCode();
   }

   /**
    * False if the argument object is not a layer.<br>
    * @param obj the target obj
    * @return boolean
    */
   public boolean equals(Object obj) {
      if (!(obj instanceof Layer)) {
         return false;
      } else {
         return ((getValue() != null) &&
         (getValue().equals(((Layer) obj).getValue())));
      }
   }
}
