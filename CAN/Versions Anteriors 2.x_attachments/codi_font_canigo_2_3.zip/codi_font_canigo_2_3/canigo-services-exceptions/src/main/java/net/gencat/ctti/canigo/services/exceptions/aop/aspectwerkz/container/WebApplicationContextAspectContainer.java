/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.exceptions.aop.aspectwerkz.container;

import org.codehaus.aspectwerkz.AspectContext;
import org.codehaus.aspectwerkz.aspect.AbstractAspectContainer;
import org.springframework.web.context.WebApplicationContext;


/**
 * Aspect container strategy that uses the Spring framework to manage aspect
 * instantiation and configuration.
 *
 * This class will be available in aWare library but now is not accessible yet
 * and their are reorganizing this class to other package
 *
 * @see https://aspectwerkz-aware.dev.java.net/source/browse/aspectwerkz-aware/src/main/org/codehaus/aware/container/Attic/SpringAspectContainer.java?only_with_tag=HEAD
 *
 */
public class WebApplicationContextAspectContainer
   extends AbstractAspectContainer {
   /**
    * Documentaci�.
    */
   private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(WebApplicationContextAspectContainer.class);

   /**
    * The bean factory.
    */
   private static WebApplicationContext factory = null;

   /**
    * Creates a new aspect container strategy that uses the Spring framework to
    * manage aspect instantiation and configuration.
    *
    * @param crossCuttingInfo
    *            the cross-cutting info
    */
   public WebApplicationContextAspectContainer(
      final AspectContext crossCuttingInfo) {
      super(crossCuttingInfo);
   }

   /**
    * Creates a new aspect instance.
    *
    * @return the new aspect instance
    */
   protected Object createAspect() {
      if (factory != null) {
         log.debug("Creating aspect... " +
            m_aspectContext.getAspectDefinition().getName() + " with factory " +
            factory);

         Object o = factory.getBean(m_aspectContext.getAspectDefinition()
                                                   .getName());
         log.debug("Bean created?" + o);

         return o;
      }

      return null;
   }

   /**
    * @return Returns the factory.
    */
   public static WebApplicationContext getFactory() {
      return factory;
   }

   /**
    * @param factory The factory to set.
    */
   public static void setFactory(WebApplicationContext aFactory) {
      log.debug("Current factory is null?" + (factory == null) +
         ", setting xml factory: " + aFactory);
      factory = aFactory;
   }
}
