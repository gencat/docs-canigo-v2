/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.exceptions;


/**
 * System Exception<br>
 * Unchecked exception to be used in exceptions thrown by system<br>
 * services (persistence, logging, configuration, ...)
 *
 */
public class SystemException extends java.lang.RuntimeException
   implements Exception {
   /**
    * Serial UID
    */
   private static final long serialVersionUID = 8162812897809676631L;

   /**
    * The details of exception
    */
   ExceptionDetails exceptionDetails;

   /**
    * Default constructor
    *
    */
   public SystemException() {
   }

   /**
    * Constructor
    *
    * @param cause
    *            inner exception
    * @param exceptionDetails
    *            exception details
    */
   public SystemException(Throwable cause, ExceptionDetails exceptionDetails) {
      super(cause);
      this.exceptionDetails = exceptionDetails;
   }

   /**
    * Constructor
    *
    * @param exceptionDetails
    *            exception details
    */
   public SystemException(ExceptionDetails exceptionDetails) {
      super();
      this.exceptionDetails = exceptionDetails;
   }

   /**
    * Constructor
    *
    * @param anErrorCode
    *            Error Code of exception. It is recommended to use a class of
    *            constants where this error code is defined
    */
   public SystemException(String anErrorCode) {
      this(null, anErrorCode, null);
   }

   /**
    * Constructor
    *
    * @param anErrorCode
    *            Error Code of exception. It is recommended to use a class of
    *            constants where
    * @param anErrorMessageArguments
    *            Arguments values of error message corresponding to error code
    */
   public SystemException(String anErrorCode, Object[] anErrorMessageArguments) {
      this(null, anErrorCode, anErrorMessageArguments, Layer.UNDEFINED,
         Subsystem.UNDEFINED);
   }

   /**
    * Constructor
    *
    * @param anErrorCode
    *            Error Code of exception. It is recommended to use a class of
    *            constants where
    * @param anErrorMessageArguments
    *            Arguments values of error message corresponding to error code
    * @param aLayer
    *            Layer where exception has been arisen
    */
   public SystemException(String anErrorCode, Object[] anErrorMessageArguments,
      Layer aLayer) {
      this(null, anErrorCode, anErrorMessageArguments, aLayer,
         Subsystem.UNDEFINED);
   }

   /**
    * Constructor
    *
    * @param anErrorCode
    *            Error Code of exception. It is recommended to use a class of
    *            constants where
    * @param anErrorMessageArguments
    *            Arguments values of error message corresponding to error code
    * @param aLayer
    *            Layer where exception has been arisen
    * @param aSubsystem
    *            Subsystem where exception has been arisen
    */
   public SystemException(String anErrorCode, Object[] anErrorMessageArguments,
      Layer aLayer, Subsystem aSubsystem) {
      this(null, anErrorCode, anErrorMessageArguments, aLayer, aSubsystem);
   }

   /**
    * Constructor
    *
    * @param cause
    *            inner exceptions
    * @param anErrorCode
    *            Error Code of exception
    */
   public SystemException(Throwable cause, String anErrorCode) {
      this(cause, anErrorCode, null);
   }

   /**
    * Constructor
    *
    * @param cause
    *            inner exception
    * @param anErrorCode
    *            Error Code of exception
    * @param anErrorMessageArguments
    *            arguments to build error description
    */
   public SystemException(Throwable cause, String anErrorCode,
      Object[] anErrorMessageArguments) {
      this(cause, anErrorCode, anErrorMessageArguments, Layer.UNDEFINED,
         Subsystem.UNDEFINED);
   }

   /**
    * Constructor
    *
    * @param cause
    *            inner exception
    * @param anErrorCode
    *            Error Code of exception
    * @param anErrorMessageArguments
    *            arguments to build error description
    * @param aLayer
    *            the layer that throws the exception
    */
   public SystemException(Throwable cause, String anErrorCode,
      Object[] anErrorMessageArguments, Layer aLayer) {
      this(cause, anErrorCode, anErrorMessageArguments, aLayer,
         Subsystem.UNDEFINED);
   }

   /**
    * Constructor
    *
    * @param cause
    *            inner exception
    * @param anErrorCode
    *            Error Code of exception
    * @param anErrorMessageArguments
    *            arguments to build error description
    * @param aLayer
    *            the layer that throws the exception
    * @param aSubsystem
    *            the subsystem that throws the exception
    */
   public SystemException(Throwable cause, String anErrorCode,
      Object[] anErrorMessageArguments, Layer aLayer, Subsystem aSubsystem) {
      this(cause,
         new ExceptionDetails(anErrorCode, anErrorMessageArguments, aLayer,
            aSubsystem));
   }

   /**
    * Getter
    *
    * @return <code>net.gencat.ctti.canigo.services.exceptions.ExceptionDetails</code>
    */
   public ExceptionDetails getExceptionDetails() {
      return exceptionDetails;
   }

   /**
    * Setter
    *
    * @param anExceptionDetails
    *            exception details
    */
   public void setExceptionDetails(ExceptionDetails anExceptionDetails) {
      exceptionDetails = anExceptionDetails;
   }
}
