/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.exceptions.aop.aspectwerkz.container;

import java.io.IOException;
import java.io.InputStream;

import org.codehaus.aspectwerkz.AspectContext;
import org.codehaus.aspectwerkz.aspect.AbstractAspectContainer;
import org.codehaus.aspectwerkz.exception.WrappedRuntimeException;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;


/**
 * Aspect container strategy that uses the Spring framework to manage aspect
 * instantiation and configuration.
 *
 * This class will be available in aWare library but now is not accessible yet
 * and their are reorganizing this class to other package
 *
 * @see https://aspectwerkz-aware.dev.java.net/source/browse/aspectwerkz-aware/src/main/org/codehaus/aware/container/Attic/SpringAspectContainer.java?only_with_tag=HEAD
 *
 */
public class SpringAspectContainer extends AbstractAspectContainer {
   /**
    * Documentaci�.
    */
   private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(SpringAspectContainer.class);

   /**
    * Bean config file name
    */
   public static String SPRING_ASPECT_CONTAINER_CONFIG = "/aware-config.xml";

   /**
    * The bean factory.
    */
   private XmlBeanFactory factory = null;

   /**
    * Creates a new aspect container strategy that uses the Spring framework to
    * manage aspect instantiation and configuration.
    *
    * @param crossCuttingInfo
    *            the cross-cutting info
    */
   public SpringAspectContainer(final AspectContext crossCuttingInfo) {
      super(crossCuttingInfo);

      InputStream is = null;

      try {
         //  is = ClassLoader.getSystemResourceAsStream(SPRING_ASPECT_CONTAINER_CONFIG);
         is = getClass().getResourceAsStream(SPRING_ASPECT_CONTAINER_CONFIG);

         Resource resource = new InputStreamResource(is);
         factory = new XmlBeanFactory(resource);
         log.info("Creating factory from " + SPRING_ASPECT_CONTAINER_CONFIG);
      } finally {
         try {
            is.close();
         } catch (IOException e) {
            throw new WrappedRuntimeException(e);
         }
      }
   }

   /**
    * Creates a new aspect instance.
    *
    * @return the new aspect instance
    */
   protected Object createAspect() {
      log.debug("Creating aspect... " +
         m_aspectContext.getAspectDefinition().getName());

      Object o = factory.getBean(m_aspectContext.getAspectDefinition().getName());
      log.debug("Bean created?" + o);

      return o;
   }

   /**
    * @return Returns the factory.
    */
   public XmlBeanFactory getFactory() {
      return factory;
   }

   /**
    * @param factory The factory to set.
    */
   public void setFactory(XmlBeanFactory factory) {
      this.factory = factory;
   }
}
