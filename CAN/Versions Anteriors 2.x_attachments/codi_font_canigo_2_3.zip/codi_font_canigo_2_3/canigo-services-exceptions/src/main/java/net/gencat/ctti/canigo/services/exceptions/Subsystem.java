/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.exceptions;

import java.io.Serializable;


/**
 * Information about subsystem where Exception has been arisen<br>
 * His purpose is to help in logging, auditing, etc. of errors
 *
 */
public class Subsystem implements Serializable {
   /**
    *
    */
   private static final long serialVersionUID = 1L;

   /**
    * LOGGING service
    */
   public static Subsystem LOGGING_SERVICES = new Subsystem("LOGGING_SERVICES");

   /**
    * MAIL service
    */
   public static Subsystem MAIL_SERVICES = new Subsystem("MAIL_SERVICES");

   /**
    * OLE service
    */
   public static Subsystem OLE_SERVICES = new Subsystem("OLE_SERVICES");

   /**
    * FTP service
    */
   public static Subsystem FTP_SERVICES = new Subsystem("FTP_SERVICES");

   /**
    * SAP service
    */
   public static Subsystem SAP_SERVICES = new Subsystem("SAP_SERVICES");

   /**
    * CONFIGURATION service
    */
   public static Subsystem CONFIGURATION_SERVICES = new Subsystem(
         "CONFIGURATION_SERVICES");

   /**
    * PERSISTENCE service
    */
   public static Subsystem PERSISTENCE_SERVICES = new Subsystem(
         "PERSISTENCE_SERVICES");

   /**
    * I18N service
    */
   public static Subsystem I18N_SERVICES = new Subsystem("I18N_SERVICES");

   /**
    * WEB LISTS service
    */
   public static Subsystem WEB_LISTS_SERVICES = new Subsystem(
         "WEB_LISTS_SERVICES");

   /**
    * SCHEDULER service
    */
   public static Subsystem SCHEDULER_SERVICES = new Subsystem(
         "SCHEDULER_SERVICES");

   /**
    * REPORTING service
    */
   public static Subsystem REPORTING_SERVICES = new Subsystem(
         "REPORTING_SERVICES");

   /**
    * UNDEFINED subsystem
    */
   public static Subsystem UNDEFINED = new Subsystem("UNDEFINED");

   /**
    * This subsystem
    */
   protected String value;

   /**
    * Creates a new Subsystem object.
    */
   public Subsystem() {
   }

   /**
    * Constructor
    * @param value the subsystem
    */
   protected Subsystem(String value) {
      this.value = value;
   }

   /**
    * Getter
    * @return java.lang.String
    */
   public String getValue() {
      return value;
   }

   /**
    * The subsystem
    * @return java.lang.String
    */
   public String toString() {
      return value;
   }

   /**
    * True if <code>subsystem</code> is equals than this subsystem
    * @param subsystem the target subsystem
    * @return boolean
    */
   public boolean equals(Subsystem subsystem) {
      return value.equals(subsystem.value);
   }

   /**
    * Hash code of this subsystem
    * @return int
    */
   public int hashCode() {
      return getValue().hashCode();
   }

   /**
    * False if the object argument is not a subsystem.<br>
    * True if <code>subsystem</code> argument is equals than this subsystem
    * @param subsystem the target object
    * @return boolean
    */
   public boolean equals(Object obj) {
      if (!(obj instanceof Subsystem)) {
         return false;
      } else {
         return ((getValue() != null) &&
         (getValue().equals(((Subsystem) obj).getValue())));
      }
   }
}
