/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.exceptions.handlers;

import net.gencat.ctti.canigo.services.logging.Log;
import net.gencat.ctti.canigo.services.logging.LoggingService;


/**
 * Implements AOP for handling system exceptions
 * @author MMA
 */
public class SystemExceptionHandler extends ExceptionHandlerAdapter {
   /**
    * Default constructor
    *
    */
   public SystemExceptionHandler() {
      super();
   }

   /**
    * Handle exception of type SystemException
    */
   public void handleException(Throwable e) throws Throwable {
      if (this.loggingService != null) {
         Log log = this.loggingService.getLog(this.getClass());
         log.debug("An exception has ocurred:" + e.getLocalizedMessage());
      }

      throw e;
   }

   /**
    * Getter
    * @return <code>net.gencat.ctti.canigo.services.logging.LoggingService</code>
    */
   public LoggingService getLoggingService() {
      return loggingService;
   }

   /**
    * Setter
    * @param loggingService the logging service
    */
   public void setLoggingService(LoggingService loggingService) {
      this.loggingService = loggingService;
   }
}
