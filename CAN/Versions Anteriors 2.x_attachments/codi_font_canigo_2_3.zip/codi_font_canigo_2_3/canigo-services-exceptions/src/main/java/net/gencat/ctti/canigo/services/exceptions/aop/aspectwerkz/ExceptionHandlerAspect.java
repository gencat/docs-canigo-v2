/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.exceptions.aop.aspectwerkz;

import java.util.HashMap;
import java.util.Map;

import net.gencat.ctti.canigo.services.exceptions.handlers.ExceptionHandler;


/**
 * Handler crosscutting Aspect of Exceptions<br>
 * This aspect can be configured as a normal bean
 * @author XES
 */
public class ExceptionHandlerAspect {
   /**
    * Documentaci�.
    */
   private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(ExceptionHandlerAspect.class);

   /**
    * Specific handlers of each type of exception
    */
   private Map exceptionHandlers = new HashMap();

   /**
    * Handle exception
    */
   public void handleException(Throwable exception) throws Throwable {
      if (exceptionHandlers != null) {
         log.info("Handling exception " + exception.getClass().getName());

         Object object = exceptionHandlers.get(exception.getClass().getName());

         if (object != null) {
            if (object instanceof ExceptionHandler) {
               ExceptionHandler exceptionHandler = (ExceptionHandler) object;
               exceptionHandler.handleException(exception);
            }
         }
      }
   }

   /**
    * Getter
    * @return java.util.Map
    */
   public Map getExceptionHandlers() {
      return exceptionHandlers;
   }

   /**
    * Setter
    * @param exceptionHandlers the exception hanlers
    */
   public void setExceptionHandlers(Map exceptionHandlers) {
      this.exceptionHandlers = exceptionHandlers;
   }
}
