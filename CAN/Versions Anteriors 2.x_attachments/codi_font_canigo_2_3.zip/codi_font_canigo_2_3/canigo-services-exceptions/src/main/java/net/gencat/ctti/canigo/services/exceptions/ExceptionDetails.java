/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.exceptions;

import java.io.Serializable;

import java.util.Locale;
import java.util.Map;


/**
 * Details of an <code>Exception</code>
 * @author XES
 */
public class ExceptionDetails implements Serializable {
   /**
    * Serial UID
    */
   private static final long serialVersionUID = -2912120098701654533L;

   /**
    * Layer where exception has been raised
    */
   private Layer layer;

   /**
    * Level of exception (warning, fatal, error, info,...)
    */
   private Level level;

   /**
    * Locale of exception
    */
   private Locale locale;

   /**
    * Additional properties of exception. A property could be "USERID" and his
    * value This map can be populated from requestContext accessible with
    * RequestContextHolder
    */
   private Map properties;

   /**
    * Other exception details customizable (depending on type of exception)
    */
   private Object otherExceptionDetails;

   /**
    * Error code.<br>
    * Instead of using traditional messages (with this.errorMessage attribute)<br>
    * it is recommended to use an errorCode defined in some class as a<br>
    * constant<br>
    * <br>
    *
    * Example: <br>
    * <code>
    * public interface WorkflowServiceErrorCodes {
    *                 static final String ERROR_WORKFLOW_PACKAGE_NOT_FOUND="ERROR_WORKFLOW_PACKAGE_NOT_FOUND";
    * </code>
    */
   private String errorCode;

   /**
    * Message of exception. Not recommended, use errorCode<br>
    * instead
    */
   private String errorMessage;

   /**
    * Subsystem where exception has been raised
    */
   private Subsystem subsystem;

   /**
    * Base exception. The cause exception. It can be used for backwards
    * compatibility if JDK1.4 or + is not used This nested exception can be
    * another Exception of canigo
    */
   private Throwable baseException;

   /**
    * Arguments of message
    */
   private Object[] errorMessageArguments;

   /**
    * Unique id of exception
    */
   private long id;

   /**
    * Timestamp of exception
    */
   private long timestamp;

   /**
    * Default constructor
    *
    */
   public ExceptionDetails() {
   }

   /**
    * Constructor
    *
    * @param anErrorCode
    *            an error code
    */
   public ExceptionDetails(String anErrorCode) {
      this(anErrorCode, null);
   }

   /**
    * Constructor
    *
    * @param anErrorCode
    *            an error code
    * @param anErrorMessageArguments
    *            error code arguments to build a description
    */
   public ExceptionDetails(String anErrorCode, Object[] anErrorMessageArguments) {
      this(anErrorCode, anErrorMessageArguments, Layer.UNDEFINED,
         Subsystem.UNDEFINED);
   }

   /**
    * Constructor
    *
    * @param anErrorCode
    *            an error code
    * @param anErrorMessageArguments
    *            error code arguments to build a description
    * @param aLayer
    *            the layer that throws the exception
    */
   public ExceptionDetails(String anErrorCode,
      Object[] anErrorMessageArguments, Layer aLayer) {
      this(anErrorCode, anErrorMessageArguments, aLayer, Subsystem.UNDEFINED);
   }

   /**
    * Constructor
    *
    * @param anErrorCode
    *            an error code
    * @param anErrorMessageArguments
    *            error code arguments to build a description
    * @param aLayer
    *            the layer that throws the exception
    * @param aSubsystem
    *            the subsystem that throws the exception
    */
   public ExceptionDetails(String anErrorCode,
      Object[] anErrorMessageArguments, Layer aLayer, Subsystem aSubsystem) {
      errorCode = anErrorCode;
      errorMessageArguments = anErrorMessageArguments;
      layer = aLayer;
      subsystem = aSubsystem;
   }

   /**
    * Getter
    *
    * @return Returns the arguments.
    */
   public Object[] getArguments() {
      return errorMessageArguments;
   }

   /**
    * Setter
    *
    * @param arguments
    *            The arguments to set.
    */
   public void setArguments(Object[] arguments) {
      this.errorMessageArguments = arguments;
   }

   /**
    * Getter
    *
    * @return Returns the locale.
    */
   public Locale getLocale() {
      return locale;
   }

   /**
    * Setter
    *
    * @param locale
    *            The locale to set.
    */
   public void setLocale(Locale locale) {
      this.locale = locale;
   }

   /**
    * Getter
    *
    * @return Returns the id.
    */
   public long getId() {
      return id;
   }

   /**
    * Setter
    *
    * @param id
    *            The id to set.
    */
   public void setId(long id) {
      this.id = id;
   }

   /**
    * Getter
    *
    * @return Returns the timestamp.
    */
   public long getTimestamp() {
      return timestamp;
   }

   /**
    * Setter
    *
    * @param timestamp
    *            The timestamp to set.
    */
   public void setTimestamp(long timestamp) {
      this.timestamp = timestamp;
   }

   /**
    * Getter
    *
    * @return Returns the errorCode.
    */
   public String getErrorCode() {
      return errorCode;
   }

   /**
    * Setter
    *
    * @param errorCode
    *            The errorCode to set.
    */
   public void setErrorCode(String errorCode) {
      this.errorCode = errorCode;
   }

   /**
    * Getter
    *
    * @return Returns the properties.
    */
   public Map getProperties() {
      return properties;
   }

   /**
    * Setter
    *
    * @param properties
    *            The properties to set.
    */
   public void setProperties(Map properties) {
      this.properties = properties;
   }

   /**
    * Getter
    *
    * @return java.lang.Throwable
    */
   public Throwable getBaseException() {
      return baseException;
   }

   /**
    * Setter
    *
    * @param baseException
    *            the base exception
    */
   public void setBaseException(Throwable baseException) {
      this.baseException = baseException;
   }

   /**
    * Getter
    *
    * @return java.lang.String
    */
   public String getErrorMessage() {
      return errorMessage;
   }

   /**
    * Setter
    *
    * @param errorMessage
    *            the error message
    */
   public void setErrorMessage(String errorMessage) {
      this.errorMessage = errorMessage;
   }

   /**
    * Getter
    *
    * @return java.lang.Object other exception details
    */
   public Object getOtherExceptionDetails() {
      return otherExceptionDetails;
   }

   /**
    * Setter
    *
    * @param otherExceptionDetails
    *            other exception details
    */
   public void setOtherExceptionDetails(Object otherExceptionDetails) {
      this.otherExceptionDetails = otherExceptionDetails;
   }

   /**
    * Getter
    *
    * @return <code>Layer</code>
    */
   public Layer getLayer() {
      return layer;
   }

   /**
    * Setter
    *
    * @param layer
    *            the layer
    */
   public void setLayer(Layer layer) {
      this.layer = layer;
   }

   /**
    * Getter
    *
    * @return <code>Subsystem</code>
    */
   public Subsystem getSubsystem() {
      return subsystem;
   }

   /**
    * Setter
    *
    * @param subsystem
    *            the subsystem
    */
   public void setSubsystem(Subsystem subsystem) {
      this.subsystem = subsystem;
   }

   /**
    * Getter
    *
    * @return <code>Level</code>
    */
   public Level getLevel() {
      return level;
   }

   /**
    * Setter
    *
    * @param level
    *            the level
    */
   public void setLevel(Level level) {
      this.level = level;
   }

   /**
    * Array of objects to a string
    * @return java.lang.String
    */
   public String arguments2string() {
      StringBuffer sb = new StringBuffer("[");

      if (this.errorMessageArguments != null) {
         for (int i = 0; i < this.errorMessageArguments.length; i++) {
            sb.append("" + this.errorMessageArguments[i]);

            if (i < (this.errorMessageArguments.length - 1)) {
               sb.append(", ");
            }
         }
      }

      sb.append("]");

      return sb.toString();
   }
}
