/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.exceptions;

import java.io.Serializable;


/**
 * Level for exception details
 *
 */
public class Level implements Serializable {
   /**
    *
    */
   private static final long serialVersionUID = 1L;

   /**
    * Fatal level
    */
   public static Level FATAL = new Level("fatal");

   /**
    * Error level
    */
   public static Level ERROR = new Level("error");

   /**
    * Warning level
    */
   public static Level WARNING = new Level("warning");

   /**
    * Info level
    */
   public static Level INFO = new Level("info");

   /**
    * The value for this level
    */
   private String value;

   /**
    * Default constructor
    *
    */
   public Level() {
      super();
   }

   /**
    * Constructor
    * @param value the value for this level
    */
   protected Level(String value) {
      this.value = value;
   }

   /**
    * Getter
    * @return java.lang.String
    */
   public String getValue() {
      return value;
   }

   /**
    * To string
    * @return java.lang.String
    */
   public String toString() {
      return value;
   }

   /**
    * True if this level is equal to the <code>level</code> argument
    * @param level the target level
    * @return boolean
    */
   public boolean equals(Level level) {
      return value.equals(level.value);
   }

   /**
    * The hash code
    * @return int
    */
   public int hashCode() {
      return getValue().hashCode();
   }

   /**
    * False if the argument object is not a level.<br>
    * True if this level is equal to the <code>object</code> argument
    * @param obj the target obj
    * @return boolean
    */
   public boolean equals(Object obj) {
      if (!(obj instanceof Layer)) {
         return false;
      } else {
         return ((getValue() != null) &&
         (getValue().equals(((Layer) obj).getValue())));
      }
   }
}
