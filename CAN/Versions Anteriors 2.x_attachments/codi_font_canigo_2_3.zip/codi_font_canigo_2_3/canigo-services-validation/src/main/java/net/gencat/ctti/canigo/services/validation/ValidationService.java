/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.validation;

import java.util.Hashtable;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.validation.exception.ValidationServiceException;

import org.springframework.validation.Errors;
import org.springmodules.validation.commons.ValidatorFactory;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public interface ValidationService {
   /**
    * Obtain validation result.
    * @param aName (the name of form, class, etc.)
    * @param aFieldName Nom del camp
    * @param aValue Valor
    * @return List of errors in parameter errors
    */
   Errors getValidationResults(String aName, Object aValue)
      throws ValidationServiceException;

   /**
    * Documentaci�.
    *
    * @param aName Documentaci�
    * @param aFieldName Documentaci�
    * @param aFieldValue Documentaci�
    * @param aErrorKey Documentaci�
    * @param aDependentFields Documentaci�
    *
    * @return Documentaci�
    *
    * @throws ValidationServiceException Documentaci�
    */
   Errors getValidationResultsTextField(String aName, String aFieldName,
      String aFieldValue, String aErrorKey, String aDependentFields)
      throws ValidationServiceException;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   I18nService getI18nService();

   /**
    * Documentaci�.
    *
    * @param service Documentaci�
    */
   void setI18nService(I18nService service);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   LoggingService getLoggingService();

   /**
    * Documentaci�.
    *
    * @param loggingService Documentaci�
    */
   void setLoggingService(LoggingService loggingService);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   ValidatorFactory getValidatorFactory();

   /**
    * Documentaci�.
    *
    * @param validatorFactory Documentaci�
    */
   void setValidatorFactory(ValidatorFactory validatorFactory);

   /**
    * Method to get if a field is required.
    * @param aName Name of validator
    * @param aFieldName Name of field to check
    * @return true if field has been defined as required
    */
   boolean isRequiredField(String aName, String aFieldName);

   /**
    * Obtain date pattern applied to the field.
    * Return null if no date pattern has been defined
    * @param aName Validator name defined in validation file
    * @param aFieldName Field name defined in validation file
    * @return Pattern date applied to field
    */
   String getDatePattern(String aName, String aFieldName);
}
