package net.gencat.ctti.canigo.services.validation.commons;

import java.util.Iterator;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.commons.validator.Field;
import org.apache.commons.validator.ValidatorAction;
import org.springframework.validation.Errors;

public class FieldChecks extends org.springmodules.validation.commons.FieldChecks {

   public static boolean validateUnique(Object bean, ValidatorAction va, Field field, Errors errors) {
      Map campsDepenents = ((FwkField) field).getCampsDependents();
      Iterator it = campsDepenents.keySet().iterator();
      
      while(it.hasNext()) {
         String campDepenentKey = (String) it.next();
         Object campDepenentValue = (Object) campsDepenents.get(campDepenentKey);
         
         if(campDepenentValue instanceof JSONObject) {
            //Llistat
            JSONObject json = (JSONObject) campDepenentValue;
            Iterator itJSON = json.keys();
            
            while(itJSON.hasNext()) {
               Object value = json.get((String) itJSON.next());
               
               if(bean.equals(value)) {
                  FieldChecks.rejectValue(errors, field, va);
                  return false;
               }
            }
         }
         else {
            //Camp
            if(bean.equals(campDepenentValue)) {
               FieldChecks.rejectValue(errors, field, va);
               return false;
            }
         }
      }
      
      return true;
   }
   
}
