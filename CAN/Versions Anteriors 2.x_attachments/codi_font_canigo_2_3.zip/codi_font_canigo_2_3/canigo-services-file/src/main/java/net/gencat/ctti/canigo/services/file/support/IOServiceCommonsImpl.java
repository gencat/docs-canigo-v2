/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.file.support;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;

import java.util.Collection;
import java.util.List;

import net.gencat.ctti.canigo.services.file.IOService;

import org.apache.commons.io.IOUtils;


/**
 * General IO stream manipulation utilities.
 * <p>
 * This class provides static utility methods for input/output operations.
 * <ul>
 * <li>closeQuietly - these methods close a stream ignoring nulls and
 * exceptions
 * <li>toXxx/read - these methods read data from a stream
 * <li>write - these methods write data to a stream
 * <li>copy - these methods copy all the data from one stream to another
 * <li>contentEquals - these methods compare the content of two streams
 * </ul>
 * <p>
 * The byte-to-char methods and char-to-byte methods involve a conversion step.
 * Two methods are provided in each case, one that uses the platform default
 * encoding and the other which allows you to specify an encoding. You are
 * encouraged to always specify an encoding because relying on the platform
 * default can lead to unexpected results, for example when moving from
 * development to production.
 * <p>
 * All the methods in this class that read a stream are buffered internally.
 * This means that there is no cause to use a <code>BufferedInputStream</code>
 * or <code>BufferedReader</code>. The default buffer size of 4K has been
 * shown to be efficient in tests.
 * <p>
 * Wherever possible, the methods in this class do <em>not</em> flush or close
 * the stream. This is to avoid making non-portable assumptions about the
 * streams' origin and further use. Thus the caller is still responsible for
 * closing streams after use.
 * <p>
 * Origin of code: Excalibur.
 *
 * @author Peter Donald
 * @author Jeff Turner
 * @author Matthew Hawthorne
 * @author Stephen Colebourne
 * @author Gareth Davis
 * @author Ian Springer
 * @version $Id: IOServiceCommonsImpl.java,v 1.4 2007/07/16 08:45:07 msabates Exp $
 */
public class IOServiceCommonsImpl implements IOService {
   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public String toString(InputStream parameter1) throws IOException {
      return IOUtils.toString(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public String toString(InputStream parameter1, String parameter2)
      throws IOException {
      return IOUtils.toString(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public String toString(byte[] parameter1) throws IOException {
      return IOUtils.toString(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public String toString(Reader parameter1) throws IOException {
      return IOUtils.toString(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public String toString(byte[] parameter1, String parameter2)
      throws IOException {
      return IOUtils.toString(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public boolean contentEquals(InputStream parameter1, InputStream parameter2)
      throws IOException {
      return IOUtils.contentEquals(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public boolean contentEquals(Reader parameter1, Reader parameter2)
      throws IOException {
      return IOUtils.contentEquals(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public char[] toCharArray(InputStream parameter1) throws IOException {
      return IOUtils.toCharArray(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public char[] toCharArray(InputStream parameter1, String parameter2)
      throws IOException {
      return IOUtils.toCharArray(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public char[] toCharArray(Reader parameter1) throws IOException {
      return IOUtils.toCharArray(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void write(StringBuffer parameter1, Writer parameter2)
      throws IOException {
      IOUtils.write(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void write(StringBuffer parameter1, OutputStream parameter2)
      throws IOException {
      IOUtils.write(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void write(StringBuffer parameter1, OutputStream parameter2,
      String parameter3) throws IOException {
      IOUtils.write(parameter1, parameter2, parameter3);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void write(byte[] parameter1, Writer parameter2, String parameter3)
      throws IOException {
      IOUtils.write(parameter1, parameter2, parameter3);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void write(String parameter1, OutputStream parameter2,
      String parameter3) throws IOException {
      IOUtils.write(parameter1, parameter2, parameter3);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void write(String parameter1, OutputStream parameter2)
      throws IOException {
      IOUtils.write(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void write(String parameter1, Writer parameter2)
      throws IOException {
      IOUtils.write(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void write(char[] parameter1, OutputStream parameter2,
      String parameter3) throws IOException {
      IOUtils.write(parameter1, parameter2, parameter3);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void write(char[] parameter1, OutputStream parameter2)
      throws IOException {
      IOUtils.write(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void write(char[] parameter1, Writer parameter2)
      throws IOException {
      IOUtils.write(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void write(byte[] parameter1, OutputStream parameter2)
      throws IOException {
      IOUtils.write(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void write(byte[] parameter1, Writer parameter2)
      throws IOException {
      IOUtils.write(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void copy(InputStream parameter1, Writer parameter2)
      throws IOException {
      IOUtils.copy(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void copy(InputStream parameter1, Writer parameter2, String parameter3)
      throws IOException {
      IOUtils.copy(parameter1, parameter2, parameter3);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void copy(Reader parameter1, OutputStream parameter2,
      String parameter3) throws IOException {
      IOUtils.copy(parameter1, parameter2, parameter3);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void copy(Reader parameter1, OutputStream parameter2)
      throws IOException {
      IOUtils.copy(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public int copy(Reader parameter1, Writer parameter2)
      throws IOException {
      return IOUtils.copy(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public int copy(InputStream parameter1, OutputStream parameter2)
      throws IOException {
      return IOUtils.copy(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public byte[] toByteArray(String parameter1) throws IOException {
      return IOUtils.toByteArray(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public byte[] toByteArray(Reader parameter1, String parameter2)
      throws IOException {
      return IOUtils.toByteArray(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public byte[] toByteArray(Reader parameter1) throws IOException {
      return IOUtils.toByteArray(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public byte[] toByteArray(InputStream parameter1) throws IOException {
      return IOUtils.toByteArray(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    */
   public void closeQuietly(Writer parameter1) {
      IOUtils.closeQuietly(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    */
   public void closeQuietly(InputStream parameter1) {
      IOUtils.closeQuietly(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    */
   public void closeQuietly(Reader parameter1) {
      IOUtils.closeQuietly(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    */
   public void closeQuietly(OutputStream parameter1) {
      IOUtils.closeQuietly(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public List readLines(InputStream parameter1, String parameter2)
      throws IOException {
      return IOUtils.readLines(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public List readLines(InputStream parameter1) throws IOException {
      return IOUtils.readLines(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public List readLines(Reader parameter1) throws IOException {
      return IOUtils.readLines(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public InputStream toInputStream(String parameter1) {
      return IOUtils.toInputStream(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public InputStream toInputStream(String parameter1, String parameter2)
      throws IOException {
      return IOUtils.toInputStream(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void writeLines(Collection parameter1, String parameter2,
      OutputStream parameter3) throws IOException {
      IOUtils.writeLines(parameter1, parameter2, parameter3);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    * @param parameter4 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void writeLines(Collection parameter1, String parameter2,
      OutputStream parameter3, String parameter4) throws IOException {
      IOUtils.writeLines(parameter1, parameter2, parameter3, parameter4);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void writeLines(Collection parameter1, String parameter2,
      Writer parameter3) throws IOException {
      IOUtils.writeLines(parameter1, parameter2, parameter3);
   }
}
