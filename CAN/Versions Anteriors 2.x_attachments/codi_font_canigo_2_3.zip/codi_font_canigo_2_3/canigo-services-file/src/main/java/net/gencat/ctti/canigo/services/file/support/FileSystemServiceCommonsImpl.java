/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.file.support;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

import java.net.URL;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import net.gencat.ctti.canigo.services.file.FileSystemService;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.FalseFileFilter;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;


/**
 * General file manipulation utilities.
 * <p>
 * Facilities are provided in the following areas:
 * <ul>
 * <li>writing to a file
 * <li>reading from a file
 * <li>make a directory including parent directories
 * <li>copying files and directories
 * <li>deleting files and directories
 * <li>converting to and from a URL
 * <li>listing files and directories by filter and extension
 * <li>comparing file content
 * <li>file last changed date
 * </ul>
 * <p>
 * Origin of code: Excalibur, Alexandria, Commons-Utils
 *
 * @author <a href="mailto:burton@relativity.yi.org">Kevin A. Burton</A>
 * @author <a href="mailto:sanders@apache.org">Scott Sanders</a>
 * @author <a href="mailto:dlr@finemaltcoding.com">Daniel Rall</a>
 * @author <a href="mailto:Christoph.Reck@dlr.de">Christoph.Reck</a>
 * @author <a href="mailto:peter@apache.org">Peter Donald</a>
 * @author <a href="mailto:jefft@apache.org">Jeff Turner</a>
 * @author Matthew Hawthorne
 * @author <a href="mailto:jeremias@apache.org">Jeremias Maerki</a>
 * @author Stephen Colebourne
 * @author Ian Springer
 * @author Chris Eldredge
 * @version $Id: FileSystemServiceCommonsImpl.java,v 1.4 2007/07/16 08:45:07 msabates Exp $
 */
public class FileSystemServiceCommonsImpl implements FileSystemService {
   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public boolean contentEquals(File parameter1, File parameter2)
      throws IOException {
      return FileUtils.contentEquals(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @return Documentaci�
    */
   public Collection listFiles(File parameter1, String[] parameter2,
      boolean parameter3) {
      return FileUtils.listFiles(parameter1, parameter2, parameter3);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @return Documentaci�
    */
   public Collection listFiles(File parameter1, IOFileFilter parameter2,
      IOFileFilter parameter3) {
      return FileUtils.listFiles(parameter1, parameter2, parameter3);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void touch(File parameter1) throws IOException {
      FileUtils.touch(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String byteCountToDisplaySize(long parameter1) {
      return FileUtils.byteCountToDisplaySize(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public File[] convertFileCollectionToFileArray(Collection parameter1) {
      return FileUtils.convertFileCollectionToFileArray(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public File toFile(URL parameter1) {
      return FileUtils.toFile(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public File[] toFiles(URL[] parameter1) {
      return FileUtils.toFiles(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public URL[] toURLs(File[] parameter1) throws IOException {
      return FileUtils.toURLs(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void copyFileToDirectory(File parameter1, File parameter2)
      throws IOException {
      FileUtils.copyFileToDirectory(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void copyFile(File parameter1, File parameter2, boolean parameter3)
      throws IOException {
      FileUtils.copyFile(parameter1, parameter2, parameter3);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void copyFile(File parameter1, File parameter2)
      throws IOException {
      FileUtils.copyFile(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void copyDirectory(File parameter1, File parameter2,
      boolean parameter3) throws IOException {
      FileUtils.copyDirectory(parameter1, parameter2, parameter3);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void copyDirectory(File parameter1, File parameter2)
      throws IOException {
      FileUtils.copyDirectory(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void copyURLToFile(URL parameter1, File parameter2)
      throws IOException {
      FileUtils.copyURLToFile(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void deleteDirectory(File parameter1) throws IOException {
      FileUtils.deleteDirectory(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void cleanDirectory(File parameter1) throws IOException {
      FileUtils.cleanDirectory(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean waitFor(File parameter1, int parameter2) {
      return FileUtils.waitFor(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public String readFileToString(File parameter1, String parameter2)
      throws IOException {
      return FileUtils.readFileToString(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public byte[] readFileToByteArray(File parameter1) throws IOException {
      return FileUtils.readFileToByteArray(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public List readLines(File parameter1, String parameter2)
      throws IOException {
      return FileUtils.readLines(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void writeStringToFile(File parameter1, String parameter2,
      String parameter3) throws IOException {
      FileUtils.writeStringToFile(parameter1, parameter2, parameter3);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void writeByteArrayToFile(File parameter1, byte[] parameter2)
      throws IOException {
      FileUtils.writeByteArrayToFile(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    * @param parameter4 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void writeLines(File parameter1, String parameter2,
      Collection parameter3, String parameter4) throws IOException {
      FileUtils.writeLines(parameter1, parameter2, parameter3, parameter4);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    * @param parameter3 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void writeLines(File parameter1, String parameter2,
      Collection parameter3) throws IOException {
      FileUtils.writeLines(parameter1, parameter2, parameter3);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void forceDelete(File parameter1) throws IOException {
      FileUtils.forceDelete(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void forceDeleteOnExit(File parameter1) throws IOException {
      FileUtils.forceDeleteOnExit(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void forceMkdir(File parameter1) throws IOException {
      FileUtils.forceMkdir(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public long sizeOfDirectory(File parameter1) {
      return FileUtils.sizeOfDirectory(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean isFileNewer(File parameter1, long parameter2) {
      return FileUtils.isFileNewer(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean isFileNewer(File parameter1, Date parameter2) {
      return FileUtils.isFileNewer(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean isFileNewer(File parameter1, File parameter2) {
      return FileUtils.isFileNewer(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param file Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public String readFileToString(File file) throws IOException {
      return this.readFileToString(file, null);
   }
}
