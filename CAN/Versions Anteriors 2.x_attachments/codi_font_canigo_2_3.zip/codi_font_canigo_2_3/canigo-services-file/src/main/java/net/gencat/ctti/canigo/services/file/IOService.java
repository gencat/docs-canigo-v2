/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.file;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;

import java.util.Collection;
import java.util.List;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public interface IOService {
   /**
    * The Unix directory separator character.
    */
   public static final char DIR_SEPARATOR_UNIX = '/';

   /**
    * The Windows directory separator character.
    */
   public static final char DIR_SEPARATOR_WINDOWS = '\\';

   /**
    * The system directory separator character.
    */
   public static final char DIR_SEPARATOR = File.separatorChar;

   /**
    * The Unix line separator string.
    */
   public static final String LINE_SEPARATOR_UNIX = "\n";

   /**
    * The Windows line separator string.
    */
   public static final String LINE_SEPARATOR_WINDOWS = "\r\n";

   //-----------------------------------------------------------------------
   /**
    * Unconditionally close an <code>Reader</code>.
    * <p>
    * Equivalent to {@link Reader#close()}, except any exceptions will be ignored.
    * This is typically used in finally blocks.
    *
    * @param input  the Reader to close, may be null or already closed
    */
   public abstract void closeQuietly(Reader input);

   /**
    * Unconditionally close a <code>Writer</code>.
    * <p>
    * Equivalent to {@link Writer#close()}, except any exceptions will be ignored.
    * This is typically used in finally blocks.
    *
    * @param output  the Writer to close, may be null or already closed
    */
   public abstract void closeQuietly(Writer output);

   /**
    * Unconditionally close an <code>InputStream</code>.
    * <p>
    * Equivalent to {@link InputStream#close()}, except any exceptions will be ignored.
    * This is typically used in finally blocks.
    *
    * @param input  the InputStream to close, may be null or already closed
    */
   public abstract void closeQuietly(InputStream input);

   /**
    * Unconditionally close an <code>OutputStream</code>.
    * <p>
    * Equivalent to {@link OutputStream#close()}, except any exceptions will be ignored.
    * This is typically used in finally blocks.
    *
    * @param output  the OutputStream to close, may be null or already closed
    */
   public abstract void closeQuietly(OutputStream output);

   // read toByteArray
   //-----------------------------------------------------------------------
   /**
    * Get the contents of an <code>InputStream</code> as a <code>byte[]</code>.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedInputStream</code>.
    *
    * @param input  the <code>InputStream</code> to read from
    * @return the requested byte array
    * @throws NullPointerException if the input is null
    * @throws IOException if an I/O error occurs
    */
   public abstract byte[] toByteArray(InputStream input)
      throws IOException;

   /**
    * Get the contents of a <code>Reader</code> as a <code>byte[]</code>
    * using the default character encoding of the platform.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedReader</code>.
    *
    * @param input  the <code>Reader</code> to read from
    * @return the requested byte array
    * @throws NullPointerException if the input is null
    * @throws IOException if an I/O error occurs
    */
   public abstract byte[] toByteArray(Reader input) throws IOException;

   /**
    * Get the contents of a <code>Reader</code> as a <code>byte[]</code>
    * using the specified character encoding.
    * <p>
    * Character encoding names can be found at
    * <a href="http://www.iana.org/assignments/character-sets">IANA</a>.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedReader</code>.
    *
    * @param input  the <code>Reader</code> to read from
    * @param encoding  the encoding to use, null means platform default
    * @return the requested byte array
    * @throws NullPointerException if the input is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract byte[] toByteArray(Reader input, String encoding)
      throws IOException;

   /**
    * Get the contents of an <code>InputStream</code> as a character array
    * using the default character encoding of the platform.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedInputStream</code>.
    *
    * @param is  the <code>InputStream</code> to read from
    * @return the requested character array
    * @throws NullPointerException if the input is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract char[] toCharArray(InputStream is) throws IOException;

   /**
    * Get the contents of an <code>InputStream</code> as a character array
    * using the specified character encoding.
    * <p>
    * Character encoding names can be found at
    * <a href="http://www.iana.org/assignments/character-sets">IANA</a>.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedInputStream</code>.
    *
    * @param is  the <code>InputStream</code> to read from
    * @param encoding  the encoding to use, null means platform default
    * @return the requested character array
    * @throws NullPointerException if the input is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract char[] toCharArray(InputStream is, String encoding)
      throws IOException;

   /**
    * Get the contents of a <code>Reader</code> as a character array.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedReader</code>.
    *
    * @param input  the <code>Reader</code> to read from
    * @return the requested character array
    * @throws NullPointerException if the input is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract char[] toCharArray(Reader input) throws IOException;

   // read toString
   //-----------------------------------------------------------------------
   /**
    * Get the contents of an <code>InputStream</code> as a String
    * using the default character encoding of the platform.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedInputStream</code>.
    *
    * @param input  the <code>InputStream</code> to read from
    * @return the requested String
    * @throws NullPointerException if the input is null
    * @throws IOException if an I/O error occurs
    */
   public abstract String toString(InputStream input) throws IOException;

   /**
    * Get the contents of an <code>InputStream</code> as a String
    * using the specified character encoding.
    * <p>
    * Character encoding names can be found at
    * <a href="http://www.iana.org/assignments/character-sets">IANA</a>.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedInputStream</code>.
    *
    * @param input  the <code>InputStream</code> to read from
    * @param encoding  the encoding to use, null means platform default
    * @return the requested String
    * @throws NullPointerException if the input is null
    * @throws IOException if an I/O error occurs
    */
   public abstract String toString(InputStream input, String encoding)
      throws IOException;

   /**
    * Get the contents of a <code>Reader</code> as a String.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedReader</code>.
    *
    * @param input  the <code>Reader</code> to read from
    * @return the requested String
    * @throws NullPointerException if the input is null
    * @throws IOException if an I/O error occurs
    */
   public abstract String toString(Reader input) throws IOException;

   // readLines
   //-----------------------------------------------------------------------
   /**
    * Get the contents of an <code>InputStream</code> as a list of Strings,
    * one entry per line, using the default character encoding of the platform.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedInputStream</code>.
    *
    * @param input  the <code>InputStream</code> to read from, not null
    * @return the list of Strings, never null
    * @throws NullPointerException if the input is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract List readLines(InputStream input) throws IOException;

   /**
    * Get the contents of an <code>InputStream</code> as a list of Strings,
    * one entry per line, using the specified character encoding.
    * <p>
    * Character encoding names can be found at
    * <a href="http://www.iana.org/assignments/character-sets">IANA</a>.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedInputStream</code>.
    *
    * @param input  the <code>InputStream</code> to read from, not null
    * @param encoding  the encoding to use, null means platform default
    * @return the list of Strings, never null
    * @throws NullPointerException if the input is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract List readLines(InputStream input, String encoding)
      throws IOException;

   /**
    * Get the contents of a <code>Reader</code> as a list of Strings,
    * one entry per line.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedReader</code>.
    *
    * @param input  the <code>Reader</code> to read from, not null
    * @return the list of Strings, never null
    * @throws NullPointerException if the input is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract List readLines(Reader input) throws IOException;

   //-----------------------------------------------------------------------
   /**
    * Convert the specified string to an input stream, encoded as bytes
    * using the default character encoding of the platform.
    *
    * @param input the string to convert
    * @return an input stream
    * @since Commons IO 1.1
    */
   public abstract InputStream toInputStream(String input);

   /**
    * Convert the specified string to an input stream, encoded as bytes
    * using the specified character encoding.
    * <p>
    * Character encoding names can be found at
    * <a href="http://www.iana.org/assignments/character-sets">IANA</a>.
    *
    * @param input the string to convert
    * @param encoding the encoding to use, null means platform default
    * @throws IOException if the encoding is invalid
    * @return an input stream
    * @since Commons IO 1.1
    */
   public abstract InputStream toInputStream(String input, String encoding)
      throws IOException;

   // write byte[]
   //-----------------------------------------------------------------------
   /**
    * Writes bytes from a <code>byte[]</code> to an <code>OutputStream</code>.
    *
    * @param data  the byte array to write, do not modify during output,
    * null ignored
    * @param output  the <code>OutputStream</code> to write to
    * @throws NullPointerException if output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void write(byte[] data, OutputStream output)
      throws IOException;

   /**
    * Writes bytes from a <code>byte[]</code> to chars on a <code>Writer</code>
    * using the default character encoding of the platform.
    * <p>
    * This method uses {@link String#String(byte[])}.
    *
    * @param data  the byte array to write, do not modify during output,
    * null ignored
    * @param output  the <code>Writer</code> to write to
    * @throws NullPointerException if output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void write(byte[] data, Writer output)
      throws IOException;

   /**
    * Writes bytes from a <code>byte[]</code> to chars on a <code>Writer</code>
    * using the specified character encoding.
    * <p>
    * Character encoding names can be found at
    * <a href="http://www.iana.org/assignments/character-sets">IANA</a>.
    * <p>
    * This method uses {@link String#String(byte[], String)}.
    *
    * @param data  the byte array to write, do not modify during output,
    * null ignored
    * @param output  the <code>Writer</code> to write to
    * @param encoding  the encoding to use, null means platform default
    * @throws NullPointerException if output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void write(byte[] data, Writer output, String encoding)
      throws IOException;

   // write char[]
   //-----------------------------------------------------------------------
   /**
    * Writes chars from a <code>char[]</code> to a <code>Writer</code>
    * using the default character encoding of the platform.
    *
    * @param data  the char array to write, do not modify during output,
    * null ignored
    * @param output  the <code>Writer</code> to write to
    * @throws NullPointerException if output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void write(char[] data, Writer output)
      throws IOException;

   /**
    * Writes chars from a <code>char[]</code> to bytes on an
    * <code>OutputStream</code>.
    * <p>
    * This method uses {@link String#String(char[])} and
    * {@link String#getBytes()}.
    *
    * @param data  the char array to write, do not modify during output,
    * null ignored
    * @param output  the <code>OutputStream</code> to write to
    * @throws NullPointerException if output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void write(char[] data, OutputStream output)
      throws IOException;

   /**
    * Writes chars from a <code>char[]</code> to bytes on an
    * <code>OutputStream</code> using the specified character encoding.
    * <p>
    * Character encoding names can be found at
    * <a href="http://www.iana.org/assignments/character-sets">IANA</a>.
    * <p>
    * This method uses {@link String#String(char[])} and
    * {@link String#getBytes(String)}.
    *
    * @param data  the char array to write, do not modify during output,
    * null ignored
    * @param output  the <code>OutputStream</code> to write to
    * @param encoding  the encoding to use, null means platform default
    * @throws NullPointerException if output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void write(char[] data, OutputStream output, String encoding)
      throws IOException;

   // write String
   //-----------------------------------------------------------------------
   /**
    * Writes chars from a <code>String</code> to a <code>Writer</code>.
    *
    * @param data  the <code>String</code> to write, null ignored
    * @param output  the <code>Writer</code> to write to
    * @throws NullPointerException if output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void write(String data, Writer output)
      throws IOException;

   /**
    * Writes chars from a <code>String</code> to bytes on an
    * <code>OutputStream</code> using the default character encoding of the
    * platform.
    * <p>
    * This method uses {@link String#getBytes()}.
    *
    * @param data  the <code>String</code> to write, null ignored
    * @param output  the <code>OutputStream</code> to write to
    * @throws NullPointerException if output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void write(String data, OutputStream output)
      throws IOException;

   /**
    * Writes chars from a <code>String</code> to bytes on an
    * <code>OutputStream</code> using the specified character encoding.
    * <p>
    * Character encoding names can be found at
    * <a href="http://www.iana.org/assignments/character-sets">IANA</a>.
    * <p>
    * This method uses {@link String#getBytes(String)}.
    *
    * @param data  the <code>String</code> to write, null ignored
    * @param output  the <code>OutputStream</code> to write to
    * @param encoding  the encoding to use, null means platform default
    * @throws NullPointerException if output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void write(String data, OutputStream output, String encoding)
      throws IOException;

   // write StringBuffer
   //-----------------------------------------------------------------------
   /**
    * Writes chars from a <code>StringBuffer</code> to a <code>Writer</code>.
    *
    * @param data  the <code>StringBuffer</code> to write, null ignored
    * @param output  the <code>Writer</code> to write to
    * @throws NullPointerException if output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void write(StringBuffer data, Writer output)
      throws IOException;

   /**
    * Writes chars from a <code>StringBuffer</code> to bytes on an
    * <code>OutputStream</code> using the default character encoding of the
    * platform.
    * <p>
    * This method uses {@link String#getBytes()}.
    *
    * @param data  the <code>StringBuffer</code> to write, null ignored
    * @param output  the <code>OutputStream</code> to write to
    * @throws NullPointerException if output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void write(StringBuffer data, OutputStream output)
      throws IOException;

   /**
    * Writes chars from a <code>StringBuffer</code> to bytes on an
    * <code>OutputStream</code> using the specified character encoding.
    * <p>
    * Character encoding names can be found at
    * <a href="http://www.iana.org/assignments/character-sets">IANA</a>.
    * <p>
    * This method uses {@link String#getBytes(String)}.
    *
    * @param data  the <code>StringBuffer</code> to write, null ignored
    * @param output  the <code>OutputStream</code> to write to
    * @param encoding  the encoding to use, null means platform default
    * @throws NullPointerException if output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void write(StringBuffer data, OutputStream output,
      String encoding) throws IOException;

   // writeLines
   //-----------------------------------------------------------------------
   /**
    * Writes the <code>toString()</code> value of each item in a collection to
    * an <code>OutputStream</code> line by line, using the default character
    * encoding of the platform and the specified line ending.
    *
    * @param lines  the lines to write, null entries produce blank lines
    * @param lineEnding  the line separator to use, null is system default
    * @param output  the <code>OutputStream</code> to write to, not null, not closed
    * @throws NullPointerException if the output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void writeLines(Collection lines, String lineEnding,
      OutputStream output) throws IOException;

   /**
    * Writes the <code>toString()</code> value of each item in a collection to
    * an <code>OutputStream</code> line by line, using the specified character
    * encoding and the specified line ending.
    * <p>
    * Character encoding names can be found at
    * <a href="http://www.iana.org/assignments/character-sets">IANA</a>.
    *
    * @param lines  the lines to write, null entries produce blank lines
    * @param lineEnding  the line separator to use, null is system default
    * @param output  the <code>OutputStream</code> to write to, not null, not closed
    * @param encoding  the encoding to use, null means platform default
    * @throws NullPointerException if the output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void writeLines(Collection lines, String lineEnding,
      OutputStream output, String encoding) throws IOException;

   /**
    * Writes the <code>toString()</code> value of each item in a collection to
    * a <code>Writer</code> line by line, using the specified line ending.
    *
    * @param lines  the lines to write, null entries produce blank lines
    * @param lineEnding  the line separator to use, null is system default
    * @param writer  the <code>Writer</code> to write to, not null, not closed
    * @throws NullPointerException if the input is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void writeLines(Collection lines, String lineEnding,
      Writer writer) throws IOException;

   // copy from InputStream
   //-----------------------------------------------------------------------
   /**
    * Copy bytes from an <code>InputStream</code> to an
    * <code>OutputStream</code>.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedInputStream</code>.
    *
    * @param input  the <code>InputStream</code> to read from
    * @param output  the <code>OutputStream</code> to write to
    * @return the number of bytes copied
    * @throws NullPointerException if the input or output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract int copy(InputStream input, OutputStream output)
      throws IOException;

   /**
    * Copy bytes from an <code>InputStream</code> to chars on a
    * <code>Writer</code> using the default character encoding of the platform.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedInputStream</code>.
    * <p>
    * This method uses {@link InputStreamReader}.
    *
    * @param input  the <code>InputStream</code> to read from
    * @param output  the <code>Writer</code> to write to
    * @throws NullPointerException if the input or output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void copy(InputStream input, Writer output)
      throws IOException;

   /**
    * Copy bytes from an <code>InputStream</code> to chars on a
    * <code>Writer</code> using the specified character encoding.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedInputStream</code>.
    * <p>
    * Character encoding names can be found at
    * <a href="http://www.iana.org/assignments/character-sets">IANA</a>.
    * <p>
    * This method uses {@link InputStreamReader}.
    *
    * @param input  the <code>InputStream</code> to read from
    * @param output  the <code>Writer</code> to write to
    * @param encoding  the encoding to use, null means platform default
    * @throws NullPointerException if the input or output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void copy(InputStream input, Writer output, String encoding)
      throws IOException;

   // copy from Reader
   //-----------------------------------------------------------------------
   /**
    * Copy chars from a <code>Reader</code> to a <code>Writer</code>.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedReader</code>.
    *
    * @param input  the <code>Reader</code> to read from
    * @param output  the <code>Writer</code> to write to
    * @return the number of characters copied
    * @throws NullPointerException if the input or output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract int copy(Reader input, Writer output)
      throws IOException;

   /**
    * Copy chars from a <code>Reader</code> to bytes on an
    * <code>OutputStream</code> using the default character encoding of the
    * platform, and calling flush.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedReader</code>.
    * <p>
    * Due to the implementation of OutputStreamWriter, this method performs a
    * flush.
    * <p>
    * This method uses {@link OutputStreamWriter}.
    *
    * @param input  the <code>Reader</code> to read from
    * @param output  the <code>OutputStream</code> to write to
    * @throws NullPointerException if the input or output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void copy(Reader input, OutputStream output)
      throws IOException;

   /**
    * Copy chars from a <code>Reader</code> to bytes on an
    * <code>OutputStream</code> using the specified character encoding, and
    * calling flush.
    * <p>
    * This method buffers the input internally, so there is no need to use a
    * <code>BufferedReader</code>.
    * <p>
    * Character encoding names can be found at
    * <a href="http://www.iana.org/assignments/character-sets">IANA</a>.
    * <p>
    * Due to the implementation of OutputStreamWriter, this method performs a
    * flush.
    * <p>
    * This method uses {@link OutputStreamWriter}.
    *
    * @param input  the <code>Reader</code> to read from
    * @param output  the <code>OutputStream</code> to write to
    * @param encoding  the encoding to use, null means platform default
    * @throws NullPointerException if the input or output is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract void copy(Reader input, OutputStream output, String encoding)
      throws IOException;

   // content equals
   //-----------------------------------------------------------------------
   /**
    * Compare the contents of two Streams to determine if they are equal or
    * not.
    * <p>
    * This method buffers the input internally using
    * <code>BufferedInputStream</code> if they are not already buffered.
    *
    * @param input1  the first stream
    * @param input2  the second stream
    * @return true if the content of the streams are equal or they both don't
    * exist, false otherwise
    * @throws NullPointerException if either input is null
    * @throws IOException if an I/O error occurs
    */
   public abstract boolean contentEquals(InputStream input1, InputStream input2)
      throws IOException;

   /**
    * Compare the contents of two Readers to determine if they are equal or
    * not.
    * <p>
    * This method buffers the input internally using
    * <code>BufferedReader</code> if they are not already buffered.
    *
    * @param input1  the first reader
    * @param input2  the second reader
    * @return true if the content of the readers are equal or they both don't
    * exist, false otherwise
    * @throws NullPointerException if either input is null
    * @throws IOException if an I/O error occurs
    * @since Commons IO 1.1
    */
   public abstract boolean contentEquals(Reader input1, Reader input2)
      throws IOException;
}
