/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.file;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public interface FileNamingService {
   //-----------------------------------------------------------------------
   /**
    * Converts all separators to the Unix separator of forward slash.
    *
    * @param path  the path to be changed, null ignored
    * @return the updated path
    */
   public abstract String separatorsToUnix(String path);

   /**
    * Converts all separators to the Windows separator of backslash.
    *
    * @param path  the path to be changed, null ignored
    * @return the updated path
    */
   public abstract String separatorsToWindows(String path);

   /**
    * Converts all separators to the system separator.
    *
    * @param path  the path to be changed, null ignored
    * @return the updated path
    */
   public abstract String separatorsToSystem(String path);

   //-----------------------------------------------------------------------
   /**
    * Returns the length of the filename prefix, such as <code>C:/</code> or <code>~/</code>.
    * <p>
    * This method will handle a file in either Unix or Windows format.
    * <p>
    * The prefix length includes the first slash in the full filename
    * if applicable. Thus, it is possible that the length returned is greater
    * than the length of the input string.
    * <pre>
    * Windows:
    * a\b\c.txt           --> ""          --> relative
    * \a\b\c.txt          --> "\"         --> current drive absolute
    * C:a\b\c.txt         --> "C:"        --> drive relative
    * C:\a\b\c.txt        --> "C:\"       --> absolute
    * \\server\a\b\c.txt  --> "\\server\" --> UNC
    *
    * Unix:
    * a/b/c.txt           --> ""          --> relative
    * /a/b/c.txt          --> "/"         --> absolute
    * ~/a/b/c.txt         --> "~/"        --> current user
    * ~                   --> "~/"        --> current user (slash added)
    * ~user/a/b/c.txt     --> "~user/"    --> named user
    * ~user               --> "~user/"    --> named user (slash added)
    * </pre>
    * <p>
    * The output will be the same irrespective of the machine that the code is running on.
    * ie. both Unix and Windows prefixes are matched regardless.
    *
    * @param filename  the filename to find the prefix in, null returns -1
    * @return the length of the prefix, -1 if invalid or null
    */
   public abstract int getPrefixLength(String filename);

   /**
    * Returns the index of the last directory separator character.
    * <p>
    * This method will handle a file in either Unix or Windows format.
    * The position of the last forward or backslash is returned.
    * <p>
    * The output will be the same irrespective of the machine that the code is running on.
    *
    * @param filename  the filename to find the last path separator in, null returns -1
    * @return the index of the last separator character, or -1 if there
    * is no such character
    */
   public abstract int indexOfLastSeparator(String filename);

   /**
    * Returns the index of the last extension separator character, which is a dot.
    * <p>
    * This method also checks that there is no directory separator after the last dot.
    * To do this it uses {@link #indexOfLastSeparator(String)} which will
    * handle a file in either Unix or Windows format.
    * <p>
    * The output will be the same irrespective of the machine that the code is running on.
    *
    * @param filename  the filename to find the last path separator in, null returns -1
    * @return the index of the last separator character, or -1 if there
    * is no such character
    */
   public abstract int indexOfExtension(String filename);

   //-----------------------------------------------------------------------
   /**
    * Gets the prefix from a full filename, such as <code>C:/</code>
    * or <code>~/</code>.
    * <p>
    * This method will handle a file in either Unix or Windows format.
    * The prefix includes the first slash in the full filename where applicable.
    * <pre>
    * Windows:
    * a\b\c.txt           --> ""          --> relative
    * \a\b\c.txt          --> "\"         --> current drive absolute
    * C:a\b\c.txt         --> "C:"        --> drive relative
    * C:\a\b\c.txt        --> "C:\"       --> absolute
    * \\server\a\b\c.txt  --> "\\server\" --> UNC
    *
    * Unix:
    * a/b/c.txt           --> ""          --> relative
    * /a/b/c.txt          --> "/"         --> absolute
    * ~/a/b/c.txt         --> "~/"        --> current user
    * ~                   --> "~/"        --> current user (slash added)
    * ~user/a/b/c.txt     --> "~user/"    --> named user
    * ~user               --> "~user/"    --> named user (slash added)
    * </pre>
    * <p>
    * The output will be the same irrespective of the machine that the code is running on.
    * ie. both Unix and Windows prefixes are matched regardless.
    *
    * @param filename  the filename to query, null returns null
    * @return the prefix of the file, null if invalid
    */
   public abstract String getPrefix(String filename);

   /**
    * Gets the path from a full filename, which excludes the prefix.
    * <p>
    * This method will handle a file in either Unix or Windows format.
    * The method is entirely text based, and returns the text before and
    * including the last forward or backslash.
    * <pre>
    * C:\a\b\c.txt --> a\b\
    * ~/a/b/c.txt  --> a/b
    * a.txt        --> ""
    * a/b/c        --> a/b
    * a/b/c/       --> a/b/c
    * </pre>
    * <p>
    * The output will be the same irrespective of the machine that the code is running on.
    * <p>
    * This method drops the prefix from the result.
    * See {@link #getFullPath(String)} for the method that retains the prefix.
    *
    * @param filename  the filename to query, null returns null
    * @return the path of the file, an empty string if none exists, null if invalid
    */
   public abstract String getPath(String filename);

   /**
    * Gets the path from a full filename, which excludes the prefix, and
    * also excluding the final directory separator.
    * <p>
    * This method will handle a file in either Unix or Windows format.
    * The method is entirely text based, and returns the text before the
    * last forward or backslash.
    * <pre>
    * C:\a\b\c.txt --> a\b
    * ~/a/b/c.txt  --> a/b
    * a.txt        --> ""
    * a/b/c        --> a/b
    * a/b/c/       --> a/b/c
    * </pre>
    * <p>
    * The output will be the same irrespective of the machine that the code is running on.
    * <p>
    * This method drops the prefix from the result.
    * See {@link #getFullPathNoEndSeparator(String)} for the method that retains the prefix.
    *
    * @param filename  the filename to query, null returns null
    * @return the path of the file, an empty string if none exists, null if invalid
    */
   public abstract String getPathNoEndSeparator(String filename);

   /**
    * Gets the full path from a full filename, which is the prefix + path.
    * <p>
    * This method will handle a file in either Unix or Windows format.
    * The method is entirely text based, and returns the text before and
    * including the last forward or backslash.
    * <pre>
    * C:\a\b\c.txt --> C:\a\b\
    * ~/a/b/c.txt  --> ~/a/b
    * a.txt        --> ""
    * a/b/c        --> a/b
    * a/b/c/       --> a/b/c
    * C:           --> C:
    * C:\          --> C:\
    * ~            --> ~
    * ~/           --> ~
    * ~user        --> ~user
    * ~user/       --> ~user
    * </pre>
    * <p>
    * The output will be the same irrespective of the machine that the code is running on.
    *
    * @param filename  the filename to query, null returns null
    * @return the path of the file, an empty string if none exists, null if invalid
    */
   public abstract String getFullPath(String filename);

   /**
    * Gets the full path from a full filename, which is the prefix + path,
    * and also excluding the final directory separator.
    * <p>
    * This method will handle a file in either Unix or Windows format.
    * The method is entirely text based, and returns the text before the
    * last forward or backslash.
    * <pre>
    * C:\a\b\c.txt --> C:\a\b
    * ~/a/b/c.txt  --> ~/a/b
    * a.txt        --> ""
    * a/b/c        --> a/b
    * a/b/c/       --> a/b/c
    * C:           --> C:
    * C:\          --> C:\
    * ~            --> ~
    * ~/           --> ~
    * ~user        --> ~user
    * ~user/       --> ~user
    * </pre>
    * <p>
    * The output will be the same irrespective of the machine that the code is running on.
    *
    * @param filename  the filename to query, null returns null
    * @return the path of the file, an empty string if none exists, null if invalid
    */
   public abstract String getFullPathNoEndSeparator(String filename);

   /**
    * Gets the name minus the path from a full filename.
    * <p>
    * This method will handle a file in either Unix or Windows format.
    * The text after the last forward or backslash is returned.
    * <pre>
    * a/b/c.txt --> c.txt
    * a.txt     --> a.txt
    * a/b/c     --> c
    * a/b/c/    --> ""
    * </pre>
    * <p>
    * The output will be the same irrespective of the machine that the code is running on.
    *
    * @param filename  the filename to query, null returns null
    * @return the name of the file without the path, or an empty string if none exists
    */
   public abstract String getName(String filename);

   /**
    * Gets the base name, minus the full path and extension, from a full filename.
    * <p>
    * This method will handle a file in either Unix or Windows format.
    * The text after the last forward or backslash and before the last dot is returned.
    * <pre>
    * a/b/c.txt --> c
    * a.txt     --> a
    * a/b/c     --> c
    * a/b/c/    --> ""
    * </pre>
    * <p>
    * The output will be the same irrespective of the machine that the code is running on.
    *
    * @param filename  the filename to query, null returns null
    * @return the name of the file without the path, or an empty string if none exists
    */
   public abstract String getBaseName(String filename);

   /**
    * Gets the extension of a filename.
    * <p>
    * This method returns the textual part of the filename after the last dot.
    * There must be no directory separator after the dot.
    * <pre>
    * foo.txt      --> "txt"
    * a/b/c.jpg    --> "jpg"
    * a/b.txt/c    --> ""
    * a/b/c        --> ""
    * </pre>
    * <p>
    * The output will be the same irrespective of the machine that the code is running on.
    *
    * @param filename the filename to retrieve the extension of.
    * @return the extension of the file or an empty string if none exists.
    */
   public abstract String getExtension(String filename);

   //-----------------------------------------------------------------------
   /**
    * Checks whether two filenames are equal exactly.
    * <p>
    * No processing is performed on the filenames other than comparison,
    * thus this is merely a null-safe case-sensitive equals.
    *
    * @param filename1  the first filename to query, may be null
    * @param filename2  the second filename to query, may be null
    * @return true if the filenames are equal, null equals null
    */
   public abstract boolean equals(String filename1, String filename2);

   /**
    * Checks whether two filenames are equal using the case rules of the system.
    * <p>
    * No processing is performed on the filenames other than comparison.
    * The check is case-sensitive on Unix and case-insensitive on Windows.
    *
    * @param filename1  the first filename to query, may be null
    * @param filename2  the second filename to query, may be null
    * @return true if the filenames are equal, null equals null
    */
   public abstract boolean equalsOnSystem(String filename1, String filename2);

   //-----------------------------------------------------------------------
   /**
    * Checks whether two filenames are equal after both have been normalized.
    * <p>
    * Both filenames are first passed to {@link #normalize(String)}.
    * The check is then performed in a case-sensitive manner.
    *
    * @param filename1  the first filename to query, may be null
    * @param filename2  the second filename to query, may be null
    * @return true if the filenames are equal, null equals null
    */
   public abstract boolean equalsNormalized(String filename1, String filename2);

   /**
    * Checks whether two filenames are equal after both have been normalized
    * and using the case rules of the system.
    * <p>
    * Both filenames are first passed to {@link #normalize(String)}.
    * The check is then performed case-sensitive on Unix and
    * case-insensitive on Windows.
    *
    * @param filename1  the first filename to query, may be null
    * @param filename2  the second filename to query, may be null
    * @return true if the filenames are equal, null equals null
    */
   public abstract boolean equalsNormalizedOnSystem(String filename1,
      String filename2);
}
