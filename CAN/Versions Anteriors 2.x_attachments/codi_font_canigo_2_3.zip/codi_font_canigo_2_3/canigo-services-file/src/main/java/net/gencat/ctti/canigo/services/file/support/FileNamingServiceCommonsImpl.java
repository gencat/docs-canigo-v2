/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.file.support;

import java.io.File;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Stack;

import net.gencat.ctti.canigo.services.file.FileNamingService;

import org.apache.commons.io.FilenameUtils;


/**
 * General filename and filepath manipulation utilities.
 * <p>
 * When dealing with filenames you can hit problems when moving from a Windows
 * based development machine to a Unix based production machine. This class aims
 * to help avoid those problems.
 * <p>
 * <b>NOTE</b>: You may be able to avoid using this class entirely simply by
 * using JDK {@link java.io.File File} objects and the two argument constructor
 * {@link java.io.File#File(java.io.File, java.lang.String) File(File,String)}.
 * <p>
 * Most methods on this class are designed to work the same on both Unix and
 * Windows. Those that don't include 'System', 'Unix' or 'Windows' in their
 * name.
 * <p>
 * Most methods recognise both separators (forward and back), and both sets of
 * prefixes. See the javadoc of each method for details.
 * <p>
 * This class defines six components within a filename (example
 * C:\dev\project\file.txt):
 * <ul>
 * <li>the prefix - C:\</li>
 * <li>the path - dev\project\</li>
 * <li>the full path - C:\dev\project\</li>
 * <li>the name - file.txt</li>
 * <li>the base name - file</li>
 * <li>the extension - txt</li>
 * </ul>
 * Note that this class works best if directory filenames end with a separator.
 * If you omit the last separator, it is impossible to determine if the filename
 * corresponds to a file or a directory. As a result, we have chosen to say it
 * corresponds to a file.
 * <p>
 * This class only supports Unix and Windows style names. Prefixes are matched
 * as follows:
 *
 * <pre>
 *  Windows:
 *  a\b\c.txt           --&gt; &quot;&quot;          --&gt; relative
 *  \a\b\c.txt          --&gt; &quot;\&quot;         --&gt; current drive absolute
 *  C:a\b\c.txt         --&gt; &quot;C:&quot;        --&gt; drive relative
 *  C:\a\b\c.txt        --&gt; &quot;C:\&quot;       --&gt; absolute
 *  \\server\a\b\c.txt  --&gt; &quot;\\server\&quot; --&gt; UNC
 *
 *  Unix:
 *  a/b/c.txt           --&gt; &quot;&quot;          --&gt; relative
 *  /a/b/c.txt          --&gt; &quot;/&quot;         --&gt; absolute
 *  &tilde;/a/b/c.txt         --&gt; &quot;&tilde;/&quot;        --&gt; current user
 *  &tilde;                   --&gt; &quot;&tilde;/&quot;        --&gt; current user (slash added)
 *  &tilde;user/a/b/c.txt     --&gt; &quot;&tilde;user/&quot;    --&gt; named user
 *  &tilde;user               --&gt; &quot;&tilde;user/&quot;    --&gt; named user (slash added)
 * </pre>
 *
 * Both prefix styles are matched always, irrespective of the machine that you
 * are currently running on.
 * <p>
 * Origin of code: Excalibur, Alexandria, Tomcat, Commons-Utils.
 *
 * @author <a href="mailto:burton@relativity.yi.org">Kevin A. Burton</A>
 * @author <a href="mailto:sanders@apache.org">Scott Sanders</a>
 * @author <a href="mailto:dlr@finemaltcoding.com">Daniel Rall</a>
 * @author <a href="mailto:Christoph.Reck@dlr.de">Christoph.Reck</a>
 * @author <a href="mailto:peter@apache.org">Peter Donald</a>
 * @author <a href="mailto:jefft@apache.org">Jeff Turner</a>
 * @author Matthew Hawthorne
 * @author Martin Cooper
 * @author <a href="mailto:jeremias@apache.org">Jeremias Maerki</a>
 * @author Stephen Colebourne
 * @version $Id: FileNamingServiceCommonsImpl.java,v 1.4 2007/07/16 08:45:07 msabates Exp $
 * @since Commons IO 1.1
 */
public class FileNamingServiceCommonsImpl implements FileNamingService {
   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean equals(String parameter1, String parameter2) {
      return FilenameUtils.equals(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String getName(String parameter1) {
      return FilenameUtils.getName(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public String concat(String parameter1, String parameter2) {
      return FilenameUtils.concat(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String getPath(String parameter1) {
      return FilenameUtils.getPath(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public int getPrefixLength(String parameter1) {
      return FilenameUtils.getPrefixLength(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String normalize(String parameter1) {
      return FilenameUtils.normalize(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String normalizeNoEndSeparator(String parameter1) {
      return FilenameUtils.normalizeNoEndSeparator(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String separatorsToUnix(String parameter1) {
      return FilenameUtils.separatorsToUnix(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String separatorsToWindows(String parameter1) {
      return FilenameUtils.separatorsToWindows(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String separatorsToSystem(String parameter1) {
      return FilenameUtils.separatorsToSystem(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public int indexOfLastSeparator(String parameter1) {
      return FilenameUtils.indexOfLastSeparator(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public int indexOfExtension(String parameter1) {
      return FilenameUtils.indexOfExtension(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String getPrefix(String parameter1) {
      return FilenameUtils.getPrefix(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String getPathNoEndSeparator(String parameter1) {
      return FilenameUtils.getPathNoEndSeparator(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String getFullPath(String parameter1) {
      return FilenameUtils.getFullPath(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String getFullPathNoEndSeparator(String parameter1) {
      return FilenameUtils.getFullPathNoEndSeparator(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String getBaseName(String parameter1) {
      return FilenameUtils.getBaseName(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String getExtension(String parameter1) {
      return FilenameUtils.getExtension(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    *
    * @return Documentaci�
    */
   public String removeExtension(String parameter1) {
      return FilenameUtils.removeExtension(parameter1);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean equalsOnSystem(String parameter1, String parameter2) {
      return FilenameUtils.equalsOnSystem(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean equalsNormalized(String parameter1, String parameter2) {
      return FilenameUtils.equalsNormalized(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean equalsNormalizedOnSystem(String parameter1, String parameter2) {
      return FilenameUtils.equalsNormalizedOnSystem(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean isExtension(String parameter1, String parameter2) {
      return FilenameUtils.isExtension(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean isExtension(String parameter1, Collection parameter2) {
      return FilenameUtils.isExtension(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean isExtension(String parameter1, String[] parameter2) {
      return FilenameUtils.isExtension(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean wildcardMatch(String parameter1, String parameter2) {
      return FilenameUtils.wildcardMatch(parameter1, parameter2);
   }

   /**
    * Documentaci�.
    *
    * @param parameter1 Documentaci�
    * @param parameter2 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean wildcardMatchOnSystem(String parameter1, String parameter2) {
      return FilenameUtils.wildcardMatchOnSystem(parameter1, parameter2);
   }
}
