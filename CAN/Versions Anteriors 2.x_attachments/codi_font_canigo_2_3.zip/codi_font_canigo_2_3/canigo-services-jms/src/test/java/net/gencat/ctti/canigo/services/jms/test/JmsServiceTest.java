/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.jms.test;

import java.util.Locale;

import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.jms.JmsService;
import net.gencat.ctti.canigo.services.jms.JmsServiceOperations;
import net.gencat.ctti.canigo.services.jms.JmsServiceUtils;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.StaticWebApplicationContext;
import org.springframework.web.struts.ActionSupport;

import sun.rmi.transport.proxy.HttpReceiveSocket;


/**
 * JmsService test
 *
 */
public class JmsServiceTest extends TestCase {
   /**
    * Initializing method
    */
   protected void setUp() throws Exception {
      super.setUp();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws ServletException Documentaci�
    */
   public static ActionSupport getMockActionSupport() throws ServletException {
      StaticWebApplicationContext wac = new StaticWebApplicationContext();
      ActionSupport action = new ActionSupport() {
         };

      return prepareMockActionSupport(wac, action);
   }

   /**
    * Documentaci�.
    *
    * @param wac Documentaci�
    * @param action Documentaci�
    *
    * @return Documentaci�
    *
    * @throws ServletException Documentaci�
    */
   public static ActionSupport prepareMockActionSupport(
      StaticWebApplicationContext wac, ActionSupport action)
      throws ServletException {
      final ServletContext servletContext = new MockServletContext();
      wac.setServletContext(servletContext);
      wac.refresh();
      servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE,
         wac);

      ActionServlet actionServlet = new ActionServlet() {
            public ServletContext getServletContext() {
               return servletContext;
            }
         };

      action.setServlet(actionServlet);

      return action;
   }

   /**
    * Documentaci�.
    *
    * @param wac Documentaci�
    * @param action Documentaci�
    *
    * @return Documentaci�
    */
   public ActionForward executeActionInContext(
      StaticWebApplicationContext wac, ActionSupport action) {
      try {
         prepareMockActionSupport(wac, action);

         MockHttpServletRequest request = new MockHttpServletRequest(wac.getServletContext());

         return action.execute(null, null, request, null);
      } catch (Exception e) {
         fail("Unexpected Exception");

         return null;
      }
   }

   /**
    * Documentaci�.
    */
   public void testSimpleJms() {
      BeanFactory beanFactory = new ClassPathXmlApplicationContext(
            "applicationContext.xml");
      JmsService service = (JmsService) beanFactory.getBean(JmsService.JMS_BEAN_FACTORY_KEY);
      JmsServiceOperations operations = (JmsServiceOperations) service.getDefaultJmsOperations();
      operations.convertAndSend("testMessage");
   }

   /**
    * Documentaci�.
    */
   public void testJmsUtils() {
      StaticWebApplicationContext wac = new StaticWebApplicationContext();
      wac.setParent(new ClassPathXmlApplicationContext("applicationContext.xml"));

      ActionSupport testAction = new ActionSupport() {
            public ActionForward execute(ActionMapping mapping,
               ActionForm form, HttpServletRequest request,
               HttpServletResponse response) throws Exception {
               JmsServiceUtils.getOperations(request)
                              .convertAndSend("testMessage");

               return super.execute(mapping, form, request, response);
            }
         };

      executeActionInContext(wac, testAction);
   }
}
