/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.jms.test;

import java.io.PrintWriter;
import java.io.StringWriter;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import javax.naming.Context;
import javax.naming.NamingException;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.jms.JmsServiceOperations;
import net.gencat.ctti.canigo.services.jms.impl.JmsOperationsImpl;

import org.easymock.MockControl;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsOperations;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.jms.core.ProducerCallback;
import org.springframework.jms.core.SessionCallback;
import org.springframework.jms.support.JmsUtils;
import org.springframework.jms.support.converter.SimpleMessageConverter;
import org.springframework.jms.support.destination.JndiDestinationResolver;
import org.springframework.jndi.JndiTemplate;


/**
 * Adapted from class of same name in Spring Framework
 *
 * * Unit tests for the JmsTemplate implemented using JMS 1.1.
 *
 * @author Andre Biryukov
 * @author Mark Pollack
 */
public class JmsTemplateTests extends TestCase {
   /**
    * Documentaci�.
    */
   private Connection mockConnection;

   /**
    * Documentaci�.
    */
   private ConnectionFactory mockConnectionFactory;

   /**
    * Documentaci�.
    */
   private Context mockJndiContext;

   /**
    * Documentaci�.
    */
   private MockControl connectionControl;

   /**
    * Documentaci�.
    */
   private MockControl connectionFactoryControl;

   /**
    * Documentaci�.
    */
   private MockControl mockJndiControl;

   /**
    * Documentaci�.
    */
   private MockControl queueControl;

   /**
    * Documentaci�.
    */
   private MockControl sessionControl;

   /**
    * Documentaci�.
    */
   private Queue mockQueue;

   /**
    * Documentaci�.
    */
   private Session mockSession;

   /**
    * Documentaci�.
    */
   private String destinationName = "topic1";

   /**
    * Documentaci�.
    */
   private int deliveryMode = DeliveryMode.PERSISTENT;

   /**
    * Documentaci�.
    */
   private int priority = 9;

   /**
    * Documentaci�.
    */
   private int timeToLive = 10000;

   /**
    * Create the mock objects for testing.
    */
   protected void setUp() throws Exception {
      mockJndiControl = MockControl.createControl(Context.class);
      mockJndiContext = (Context) this.mockJndiControl.getMock();

      createMockforDestination();

      mockJndiContext.close();
      mockJndiControl.replay();
   }

   /**
    * Documentaci�.
    *
    * @throws JMSException Documentaci�
    * @throws NamingException Documentaci�
    */
   private void createMockforDestination() throws JMSException, NamingException {
      connectionFactoryControl = MockControl.createControl(ConnectionFactory.class);
      mockConnectionFactory = (ConnectionFactory) connectionFactoryControl.getMock();

      connectionControl = MockControl.createControl(Connection.class);
      mockConnection = (Connection) connectionControl.getMock();

      sessionControl = MockControl.createControl(Session.class);
      mockSession = (Session) sessionControl.getMock();

      queueControl = MockControl.createControl(Queue.class);
      mockQueue = (Queue) queueControl.getMock();

      mockConnectionFactory.createConnection();
      connectionFactoryControl.setReturnValue(mockConnection);
      connectionFactoryControl.replay();

      mockConnection.createSession(useTransactedTemplate(),
         Session.AUTO_ACKNOWLEDGE);
      connectionControl.setReturnValue(mockSession);
      mockSession.getTransacted();
      sessionControl.setReturnValue(useTransactedSession());

      mockJndiContext.lookup("testDestination");
      mockJndiControl.setReturnValue(mockQueue);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private JmsServiceOperations createTemplate() {
      JmsOperationsImpl ops = new JmsOperationsImpl();
      ops.setConnectionFactory(mockConnectionFactory);

      return ops;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected boolean useTransactedSession() {
      return false;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected boolean useTransactedTemplate() {
      return false;
   }

   /**
    * Test sending to a destination using the method
    * send(Destination d, MessageCreator messageCreator)
    */
   public void testSendDestination() throws Exception {
      doTestSendDestination(true, false, true, false);
   }

   /**
    * Test seding to a destination using the method
    * send(String d, MessageCreator messageCreator)
    */
   public void testSendDestinationName() throws Exception {
      doTestSendDestination(false, false, true, false);
   }

   /**
    * Test sending to the default destination.
    */
   public void testSendDefaultDestination() throws Exception {
      doTestSendDestination(true, true, true, true);
   }

   /**
    * Test sending to the default destination name.
    */
   public void testSendDefaultDestinationName() throws Exception {
      doTestSendDestination(false, true, true, true);
   }

   /**
    * Common method for testing a send method that uses the MessageCreator
    * callback but with different QOS options.
    * @param ignoreQOS test using default QOS options.
    */
   private void doTestSendDestination(boolean explicitDestination,
      boolean useDefaultDestination, boolean ignoreQOS,
      boolean disableIdAndTimestamp) throws Exception {
      JmsServiceOperations template = createTemplate();

      MockControl messageProducerControl = MockControl.createControl(MessageProducer.class);
      MessageProducer mockMessageProducer = (MessageProducer) messageProducerControl.getMock();

      MockControl messageControl = MockControl.createControl(TextMessage.class);
      TextMessage mockMessage = (TextMessage) messageControl.getMock();

      mockSession.createProducer(mockQueue);
      sessionControl.setReturnValue(mockMessageProducer);
      mockSession.createTextMessage("just testing");
      sessionControl.setReturnValue(mockMessage);

      if (useTransactedTemplate()) {
         mockSession.commit();
         sessionControl.setVoidCallable(1);
      }

      if (disableIdAndTimestamp) {
         mockMessageProducer.setDisableMessageID(true);
         messageProducerControl.setVoidCallable(1);
         mockMessageProducer.setDisableMessageTimestamp(true);
         messageProducerControl.setVoidCallable(1);
      }

      if (ignoreQOS) {
         mockMessageProducer.send(mockMessage);
      } else {
         //			template.setExplicitQosEnabled(true);
         //			template.setDeliveryMode(deliveryMode);
         //			template.setPriority(priority);
         //			template.setTimeToLive(timeToLive);
         mockMessageProducer.send(mockMessage, deliveryMode, priority,
            timeToLive);
      }

      messageProducerControl.setVoidCallable(1);

      mockMessageProducer.close();
      messageProducerControl.setVoidCallable(1);
      mockSession.close();
      sessionControl.setVoidCallable(1);
      mockConnection.close();
      connectionControl.setVoidCallable(1);

      messageProducerControl.replay();
      sessionControl.replay();
      connectionControl.replay();

      if (useDefaultDestination) {
         template.convertAndSend("just testing");
      } else {
         if (explicitDestination) {
            template.convertAndSend(mockQueue, "just testing");
         } else {
            template.convertAndSend(destinationName, "just testing");
         }
      }

      connectionFactoryControl.verify();
      connectionControl.verify();
      sessionControl.verify();
      messageProducerControl.verify();
   }
}
