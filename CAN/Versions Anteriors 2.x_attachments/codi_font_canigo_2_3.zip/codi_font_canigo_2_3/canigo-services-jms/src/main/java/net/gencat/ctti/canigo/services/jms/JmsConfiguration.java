/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.jms;

import javax.jms.Destination;

import org.springframework.jms.core.MessageCreator;
import org.springframework.jms.core.MessagePostProcessor;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public interface JmsConfiguration {
   /**
    * Set the destination to be used on send/receive operations that do not
    * have a destination parameter.
    * <p>Alternatively, specify a "defaultDestinationName", to be
    * dynamically resolved via the DestinationResolver.
    * @see #send(MessageCreator)
    * @see #convertAndSend(Object)
    * @see #convertAndSend(Object, MessagePostProcessor)
    * @see #setDefaultDestinationName(String)
    */
   public abstract void setDefaultDestination(Destination destination);

   /**
    * Return the destination to be used on send/receive operations that do not
    * have a destination parameter.
    */
   public abstract Destination getDefaultDestination();

   /**
    * Set the destination name to be used on send/receive operations that
    * do not have a destination parameter. The specified name will be
    * dynamically resolved via the DestinationResolver.
    * <p>Alternatively, specify a JMS Destination object as "defaultDestination".
    * @see #send(MessageCreator)
    * @see #convertAndSend(Object)
    * @see #convertAndSend(Object, MessagePostProcessor)
    * @see #setDestinationResolver
    * @see #setDefaultDestination(javax.jms.Destination)
    */
   public abstract void setDefaultDestinationName(String defaultDestinationName);

   /**
    * Return the destination name to be used on send/receive operations that
    * do not have a destination parameter.
    */
   public abstract String getDefaultDestinationName();

   /**
    * Set whether message IDs are enabled. Default is "true".
    * <p>This is only a hint to the JMS producer.
    * See the JMS javadocs for details.
    * @see javax.jms.MessageProducer#setDisableMessageID
    */
   public abstract void setMessageIdEnabled(boolean messageIdEnabled);

   /**
    * Return whether message IDs are enabled.
    */
   public abstract boolean isMessageIdEnabled();

   /**
    * Set whether message timestamps are enabled. Default is "true".
    * <p>This is only a hint to the JMS producer.
    * See the JMS javadocs for details.
    * @see javax.jms.MessageProducer#setDisableMessageTimestamp
    */
   public abstract void setMessageTimestampEnabled(
      boolean messageTimestampEnabled);

   /**
    * Return whether message timestamps are enabled.
    */
   public abstract boolean isMessageTimestampEnabled();

   /**
    * Set whether to inhibit the delivery of messages published by its own connection.
    * Default is "false".
    * @see javax.jms.TopicSession#createSubscriber(javax.jms.Topic, String, boolean)
    */
   public abstract void setPubSubNoLocal(boolean pubSubNoLocal);

   /**
    * Return whether to inhibit the delivery of messages published by its own connection.
    */
   public abstract boolean isPubSubNoLocal();

   /**
    * Set the timeout to use for receive calls.
    * The default is -1, which means no timeout.
    * @see javax.jms.MessageConsumer#receive(long)
    * @see javax.jms.MessageConsumer#receive
    */
   public abstract void setReceiveTimeout(long receiveTimeout);

   /**
    * Return the timeout to use for receive calls.
    */
   public abstract long getReceiveTimeout();

   /**
    * Set if the QOS values (deliveryMode, priority, timeToLive)
    * should be used for sending a message.
    * @see #setDeliveryMode
    * @see #setPriority
    * @see #setTimeToLive
    */
   public abstract void setExplicitQosEnabled(boolean explicitQosEnabled);

   /**
    * If "true", then the values of deliveryMode, priority, and timeToLive
    * will be used when sending a message. Otherwise, the default values,
    * that may be set administratively, will be used.
    * @return true if overriding default values of QOS parameters
    * (deliveryMode, priority, and timeToLive)
    * @see #setDeliveryMode
    * @see #setPriority
    * @see #setTimeToLive
    */
   public abstract boolean isExplicitQosEnabled();

   /**
    * Set whether message delivery should be persistent or non-persistent,
    * specified as boolean value ("true" or "false"). This will set the delivery
    * mode accordingly, to either "PERSISTENT" (1) or "NON_PERSISTENT" (2).
    * <p>Default it "true" aka delivery mode "PERSISTENT".
    * @see #setDeliveryMode(int)
    * @see javax.jms.DeliveryMode#PERSISTENT
    * @see javax.jms.DeliveryMode#NON_PERSISTENT
    */
   public abstract void setDeliveryPersistent(boolean deliveryPersistent);

   /**
    * Set the delivery mode to use when sending a message.
    * Default is the Message default: "PERSISTENT".
    * <p>Since a default value may be defined administratively,
    * this is only used when "isExplicitQosEnabled" equals "true".
    * @param deliveryMode the delivery mode to use
    * @see #isExplicitQosEnabled
    * @see javax.jms.DeliveryMode#PERSISTENT
    * @see javax.jms.DeliveryMode#NON_PERSISTENT
    * @see javax.jms.Message#DEFAULT_DELIVERY_MODE
    * @see javax.jms.MessageProducer#send(javax.jms.Message, int, int, long)
    */
   public abstract void setDeliveryMode(int deliveryMode);

   /**
    * Return the delivery mode to use when sending a message.
    */
   public abstract int getDeliveryMode();

   /**
    * Set the priority of a message when sending.
    * <p>Since a default value may be defined administratively,
    * this is only used when "isExplicitQosEnabled" equals "true".
    * @see #isExplicitQosEnabled
    * @see javax.jms.Message#DEFAULT_PRIORITY
    * @see javax.jms.MessageProducer#send(javax.jms.Message, int, int, long)
    */
   public abstract void setPriority(int priority);

   /**
    * Return the priority of a message when sending.
    */
   public abstract int getPriority();

   /**
    * Set the time-to-live of the message when sending.
    * <p>Since a default value may be defined administratively,
    * this is only used when "isExplicitQosEnabled" equals "true".
    * @param timeToLive the message's lifetime (in milliseconds)
    * @see #isExplicitQosEnabled
    * @see javax.jms.Message#DEFAULT_TIME_TO_LIVE
    * @see javax.jms.MessageProducer#send(javax.jms.Message, int, int, long)
    */
   public abstract void setTimeToLive(long timeToLive);

   /**
    * Return the time-to-live of the message when sending.
    */
   public abstract long getTimeToLive();
}
