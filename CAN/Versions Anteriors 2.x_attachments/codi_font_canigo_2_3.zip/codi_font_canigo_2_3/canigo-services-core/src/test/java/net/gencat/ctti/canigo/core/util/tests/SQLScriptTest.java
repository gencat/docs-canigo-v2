/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.core.util.tests;

import java.io.IOException;

import java.sql.Connection;
import java.sql.SQLException;

import java.util.List;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.core.util.tests.SQLScript;
import net.gencat.ctti.canigo.core.util.tests.TestsHelper;


/**
 * <p>Insert description here</p>
 * <p>Date: 15 janv. 2005 </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * @author Jean-Michel Garnier
 *
 */
public class SQLScriptTest extends TestCase {
   /**
    * Documentaci�.
    */
   private SQLScript sqlScriptTest;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void setUp() throws Exception {
      HSQLDatabaseFixture.start("testdb");

      this.sqlScriptTest = new SQLScript(HSQLDatabaseFixture.getDataSource(),
            "ddl.sql");
   }

   /**
    * Documentaci�.
    *
    * @throws SQLException Documentaci�
    * @throws IOException Documentaci�
    */
   public void testLoadBatches() throws SQLException, IOException {
      List batchListTest = this.sqlScriptTest.loadBatches(this.sqlScriptTest.getScript());

      assertEquals(4, batchListTest.size());
      assertTrue(((String) batchListTest.get(1)).indexOf(
            "drop table if exists TABLE_MCK_MOCK") != -1);
   }

   /**
    * Documentaci�.
    *
    * @throws SQLException Documentaci�
    */
   public void testExecute() throws SQLException {
      this.sqlScriptTest.execute();

      Connection connection = HSQLDatabaseFixture.getDataSource().getConnection();
      connection.createStatement().execute("select * from TABLE_MCK_MOCK");
      assertTrue(true);

      connection.close();
   }
}
