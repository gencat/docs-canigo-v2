drop table if exists TABLE_MCK_BUG;
drop table if exists TABLE_MCK_MOCK;

create table TABLE_MCK_BUG (
   bug_id bigint not null,
   mck_id bigint,
   primary key (bug_id)
);

create table TABLE_MCK_MOCK (
   MCK_ID bigint not null,
   MCK_FIRSTNAME varchar(255) not null,
   MCK_LASTNAME varchar(255),
   primary key (MCK_ID)
);
