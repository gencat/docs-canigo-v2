/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.core.threadlocal;

import java.util.Hashtable;

import org.apache.log4j.MDC;


/**
 * $Id: ThreadLocalProperties.java,v 1.4 2007/07/16 08:46:11 msabates Exp $
 * ThreadLocal to set properties used in any subsystem without need to pass parameters in methods.
 * It sets this information in MDC for using in Formatters for log4J
 *
 * @author EVC
 * @version $Revision: 1.4 $ $Date: 2007/07/16 08:46:11 $
 *
 * @see
 * @since 1.0
 *
 * $Log: ThreadLocalProperties.java,v $
 * Revision 1.4  2007/07/16 08:46:11  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]
 *
 * Revision 1.3  2007/05/23 10:44:35  msabates
 * Cap�alera
 *
 * Revision 1.1.1.1.2.1  2007/05/18 10:46:24  fernando.vaquero
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2007/05/15 13:53:56  fernando.vaquero
 * Importacio canigo 2.0
 *
 * Revision 1.2  2007/05/15 10:19:46  msabates
 * Jalopy
 *
 * Revision 1.1  2007/03/28 12:14:01  msabates
 * *** empty log message ***
 *
 * Revision 1.2  2007/03/14 14:45:06  msabates
 * *** empty log message ***
 *
 * Revision 1.1  2007/03/12 11:41:09  msabates
 * Refactor a net.gencat.ctti.canigo
 *
 * Revision 1.1  2007/02/22 15:34:17  msabates
 * *** empty log message ***
 *
 * Revision 1.3  2006/11/16 17:08:52  mmateos
 * author: crico: version 1.1
 *
 * Revision 1.3  2006/09/19 14:53:39  crico
 * version 1.1
 *
 * Revision 1.1.2.2  2006/03/03 15:08:36  xescuder
 * No changes
 *
 * Revision 1.1.2.1  2006/03/03 15:05:34  xescuder
 * XES: 1.0.1 > Added MDC to set in context the same as thread local properties
 *
 */
public class ThreadLocalProperties {
   /**
    * Documentaci�.
    */
   static final ThreadLocalProperties threadlocalproperties = new ThreadLocalProperties();

   /**
    * Documentaci�.
    */
   static final int HT_SIZE = 7;

   /**
    * Documentaci�.
    */
   private Object tl;

   /**
    * Creates a new ThreadLocalProperties object.
    */
   private ThreadLocalProperties() {
      tl = new ThreadLocal();
   }

   /**
    * Put a context value (the <code>o</code> parameter) as identified with
    * the <code>key</code> parameter into the current thread's context map.
    *
    * <p>
    * If the current thread does not have a context map it is created as a side
    * effect.
    *
    */
   public static void put(String key, Object o) {
      org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(ThreadLocalProperties.class);
      log.debug("putting " + o + " with key " + key);
      threadlocalproperties.put0(key, o);

      // Add to MDC of Log4J
      MDC.put(key, o);
   }

   /**
    * Get the context identified by the <code>key</code> parameter.
    *
    * <p>
    * This method has no side effects.
    */
   public static Object get(String key) {
      return threadlocalproperties.get0(key);
   }

   /**
    * Remove the the context identified by the <code>key</code> parameter.
    *
    */
   public static void remove(String key) {
      threadlocalproperties.remove0(key);
   }

   /**
    * Get the current thread's MDC as a hashtable. This method is intended to
    * be used internally.
    */
   public static Hashtable getContext() {
      return threadlocalproperties.getContext0();
   }

   /**
    * Documentaci�.
    *
    * @param key Documentaci�
    * @param o Documentaci�
    */
   private void put0(String key, Object o) {
      Hashtable ht = (Hashtable) ((ThreadLocal) tl).get();

      if (ht == null) {
         ht = new Hashtable(HT_SIZE);
         ((ThreadLocal) tl).set(ht);
      }

      ht.put(key, o);
   }

   /**
    * Documentaci�.
    *
    * @param key Documentaci�
    *
    * @return Documentaci�
    */
   private Object get0(String key) {
      Hashtable ht = (Hashtable) ((ThreadLocal) tl).get();

      if ((ht != null) && (key != null)) {
         return ht.get(key);
      } else {
         return null;
      }
   }

   /**
    * Documentaci�.
    *
    * @param key Documentaci�
    */
   private void remove0(String key) {
      Hashtable ht = (Hashtable) ((ThreadLocal) tl).get();

      if (ht != null) {
         ht.remove(key);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private Hashtable getContext0() {
      return (Hashtable) ((ThreadLocal) tl).get();
   }
}
