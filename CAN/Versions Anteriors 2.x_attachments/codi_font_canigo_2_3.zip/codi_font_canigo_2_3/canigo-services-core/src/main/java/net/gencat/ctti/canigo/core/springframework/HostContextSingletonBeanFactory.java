/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.core.springframework;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.access.BeanFactoryLocator;
import org.springframework.context.access.ContextSingletonBeanFactoryLocator;


/**
 * Class to use context factory using host name as suffix of
 * indicated files in configuration
 * @author XES
 *
 */
public class HostContextSingletonBeanFactory
   extends ContextSingletonBeanFactoryLocator {
   /**
    * Creates a new HostContextSingletonBeanFactory object.
    *
    * @param aConfigFileName DOCUMENT ME.
    */
   public HostContextSingletonBeanFactory(String aConfigFileName) {
      super(aConfigFileName);
   }

   /**
    * Returns an instance which uses the the specified selector, as the name of the
    * definition file(s). In the case of a name with a Spring 'classpath*:' prefix,
    * or with no prefix, which is treated the same, the current thread's context
    * class loader's getResources() method will be called with this value to get all
    * resources having that name. These resources will then be combined to form a
    * definition. In the case where the name uses a Spring 'classpath:' prefix, or
    * a standard URL prefix, then only one resource file will be loaded as the
    * definition.
    * @param selector the name of the resource(s) which will be read and combine to
    * form the definition for the SingletonBeanFactoryLocator instance. The one file
    * or multiple fragments with this name must form a valid ApplicationContext
    * definition.
    */
   public static BeanFactoryLocator getInstance(String selector)
      throws BeansException {
      String newSelector = selector;

      //  Obtain host Name
      String hostName;
      InetAddress localHost = null;

      try {
         localHost = InetAddress.getLocalHost();
         hostName = new String(localHost.getHostName());
         newSelector = selector + "." + hostName;
      } catch (UnknownHostException e) {
         //error message
      }

      return ContextSingletonBeanFactoryLocator.getInstance(newSelector);
   }
}
