/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.core.springframework.beans.propertyeditors;

import java.beans.PropertyEditorSupport;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Locale;
import java.util.Map;

import net.gencat.ctti.canigo.core.threadlocal.ThreadLocalProperties;

import org.springframework.util.StringUtils;


/**
 * Custom Date Editor
 *
 * It access to current locale from user to know
 * how to transform a human text to Date object
 * @author XES
 *
 */
public class CustomDateEditor extends PropertyEditorSupport {
   /**
    * Documentaci�.
    */
   Locale defaultLocale = new Locale("es");

   /**
    * Documentaci�.
    */
   Map localeDatePatternsMap;

   /**
    * Parse the Date from the given text
    */
   public void setAsText(String text) throws IllegalArgumentException {
      if (!StringUtils.hasText(text)) {
         // Treat empty String as null value.
         setValue(null);
      } else {
         try {
            // Obtain current locale. In true environment function of i18NService has to be called
            // but editors are considered from core package
            Locale locale = (Locale) ThreadLocalProperties.get(
                  "net.gencat.ctti.canigo.services.i18n" + ".LOCALE");

            if (locale != null) {
               locale = defaultLocale;
            }

            // Now obtain from map datePattern configured for this locale
            String language = locale.getLanguage();
            String datePattern = (String) localeDatePatternsMap.get(language);

            if (datePattern != null) {
               SimpleDateFormat dateFormat = new SimpleDateFormat(datePattern);
               setValue(dateFormat.parse(text));
            }
         } catch (ParseException ex) {
            throw new IllegalArgumentException("Could not parse date: " +
               ex.getMessage());
         }
      }
   }

   /**
    * Format the Date as String, using the specified DateFormat.
    */
   public String getAsText() {
      Date value = (Date) getValue();

      // return empty string if date is null
      if (value == null) {
         return "";
      }

      Locale locale = (Locale) ThreadLocalProperties.get(
            "net.gencat.ctti.canigo.services.i18n" + ".LOCALE");

      if (locale != null) {
         locale = defaultLocale;
      }

      // Now obtain from map datePattern configured for this locale
      String language = locale.getLanguage();
      String datePattern = (String) localeDatePatternsMap.get(language);

      if (datePattern != null) {
         SimpleDateFormat dateFormat = new SimpleDateFormat(datePattern);

         return dateFormat.format(value);
      }

      return null;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getLocaleDatePatternsMap() {
      return localeDatePatternsMap;
   }

   /**
    * Documentaci�.
    *
    * @param localeDatePatternsMap Documentaci�
    */
   public void setLocaleDatePatternsMap(Map localeDatePatternsMap) {
      this.localeDatePatternsMap = localeDatePatternsMap;
   }
}
