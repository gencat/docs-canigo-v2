/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.core.util.beanutils;

import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.ConvertUtilsBean;
import org.apache.commons.beanutils.PropertyUtilsBean;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class BeanUtilsBean extends org.apache.commons.beanutils.BeanUtilsBean {
   /**
    * Creates a new BeanUtilsBean object.
    */
   public BeanUtilsBean() {
      super();

      // TODO Auto-generated constructor stub
   }

   /**
    * Creates a new BeanUtilsBean object.
    *
    * @param arg0 DOCUMENT ME.
    * @param arg1 DOCUMENT ME.
    */
   public BeanUtilsBean(ConvertUtilsBean arg0, PropertyUtilsBean arg1) {
      super(arg0, arg1);

      // TODO Auto-generated constructor stub
   }

   /**
    * <p>Copy the specified property value to the specified destination bean,
    * performing any type conversion that is required.
    *
    * Redefined in client to bypass null values
    *
    * @param bean Bean on which setting is to be performed
    * @param name Property name (can be nested/indexed/mapped/combo)
    * @param value Value to be set
    *
    * @exception IllegalAccessException if the caller does not have
    *  access to the property accessor method
    * @exception InvocationTargetException if the property accessor method
    *  throws an exception
    */
   public void copyProperty(Object bean, String name, Object value)
      throws IllegalAccessException, InvocationTargetException {
      if (value != null) {
         try {
            org.apache.commons.beanutils.BeanUtils.copyProperty(bean, name,
               value);
         } catch (Exception exc) {
            System.err.println("Error unexpected");
         }
      }
   }
}
