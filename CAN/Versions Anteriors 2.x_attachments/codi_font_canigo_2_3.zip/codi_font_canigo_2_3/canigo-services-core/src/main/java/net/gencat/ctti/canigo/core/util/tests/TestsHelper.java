/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.core.util.tests;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;


/**
 * Utilities class providing helpers methods to use in Junit tests.
 *
 * @author jean-michel.garnier
 *
 */
public class TestsHelper {
   /**
    * Singleton because accessing the class loader through the class unique instance
    */
   private static TestsHelper instance;

   /**
    * Creates a new TestsHelper object.
    */
   private TestsHelper() {
   }

   /**
    * Read the content of a test resource, generally located in the src/test/resources folder.
    * Snippet:
    * To load the {myProjectRoot}/src/test/resources/xml/testdada.xml file to a String
    * String expectedXML = TestsHelper.getTestResource("xml/testdada.xml");
    *
    * This method uses the classpath loader to get the file, hence the file must be in the classpath.
    *
    * @param file relative path
    * @return file's text content
    * @throws IOException
    */
   public static String getTestResource(String fileRelativePath)
      throws IOException {
      InputStream stream = getInstance().getClass()
                              .getResourceAsStream("/" + fileRelativePath);

      return IOUtils.toString(stream);
   }

   /**
    * Thread safe implementation of Singleton
    * @return
    */
   private static synchronized TestsHelper getInstance() {
      if (instance == null) {
         instance = new TestsHelper();
      }

      return instance;
   }
}
