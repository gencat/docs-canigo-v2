/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.core.util.tests;

import javax.sql.DataSource;

import org.hsqldb.Server;
import org.hsqldb.jdbc.jdbcDataSource;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class HSQLDatabaseFixture {
   /**
    * Documentaci�.
    */
   private static HSQLDatabaseFixture instance;

   /**
    * Documentaci�.
    */
   private static Server server;

   /**
    * Documentaci�.
    */
   private static DataSource dataSource;

   /**
    * Creates a new HSQLDatabaseFixture object.
    */
   private HSQLDatabaseFixture() {
   }

   /**
    * Documentaci�.
    *
    * @param databaseName Documentaci�
    */
   public static synchronized void start(String databaseName) {
      // If instance exists, the db has been started
      if (instance != null) {
         return;
      }

      if (instance == null) {
         instance = new HSQLDatabaseFixture();
      }

      server = new Server();
      server.setDatabaseName(0, databaseName);
      // Default port
      server.setPort(9002);
      server.start();

      dataSource = new jdbcDataSource();

      jdbcDataSource dataSourceHypersonic = (jdbcDataSource) dataSource;
      dataSourceHypersonic.setDatabase("jdbc:hsqldb:hsql://localhost:9002/" +
         databaseName);
      dataSourceHypersonic.setUser("sa");
      dataSourceHypersonic.setPassword("");
   }

   /**
    * Documentaci�.
    */
   public static synchronized void stopServer() {
      if (server == null) {
         return;
      }

      server.shutdown();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public static DataSource getDataSource() {
      return dataSource;
   }
}
