/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.core.springframework.beans;

import java.util.Map;

import org.springframework.beans.BeanWrapper;
import org.springframework.validation.BindingResult;


/**
 * Definici� classe BindException.
 *
 * @author $author$
 * @version $Revision: 1.8 $
  */
public class BindException extends org.springframework.validation.BindException {
   /**
    * Documentaci�.
    */
   private transient static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(BindException.class);

   /**
    * Documentaci�.
    */
   private transient BeanWrapper anotherBeanWrapper = null;

   /**
    * Documentaci�.
    */
   private Map bindProperties = null;

   /**
    * Implementaci� de la interface de errors. Soporta el registre
    * y evaluaci� dels error vinculants.
    *
    * @param res BindingResult
    */
   public BindException(BindingResult res) {
      super(res);
   }

   /**
    * Crea un nou objecte BindException.
    *
    * @param target Object
    * @param name String
    * @param bindProperties Map
    */
   public BindException(Object target, String name, Map bindProperties) {
      super(new BeanPropertyBindingResult(target, name, null));
      this.setBindProperties(bindProperties);
   }

   /**
    * Crea un nou objecte BindException.
    *
    * @param target Object
    * @param name String
    */
   public BindException(Object target, String name) {
      this(target, name, null);
   }

   /**
    * @deprecated
    * @return BeanWrapper
    */
   protected BeanWrapper getBeanWrapper() {
      if (this.anotherBeanWrapper == null) {
         log.debug("Creating a BeanWrapper with bindProperties=" +
            this.bindProperties);
         this.anotherBeanWrapper = new BeanWrapperImpl(super.getTarget(),
               bindProperties);
      }

      return this.anotherBeanWrapper;
   }

   //msg-ini

   /**
    * M�tode per aconseguir el beanWrapper des d'un objecte qualsevol, nom�s �s un getter
    *
    */
   public BeanWrapper getAnotherBeanWrapper() {
      return this.anotherBeanWrapper;
   }

   /**
    * M�tode per associar a un BindException el BeanWrapper creat al binder
    */
   public void setBeanWrapper(BeanWrapper wrapper) {
      if (wrapper != null) {
         this.anotherBeanWrapper = wrapper;
      }
   }

   //msg-fi

   /**
    * Documentaci�.
    *
    * @return Map
    */
   public Map getBindProperties() {
      return bindProperties;
   }

   /**
    * Documentaci�.
    *
    * @param bindProperties Map
    */
   public void setBindProperties(Map bindProperties) {
      this.bindProperties = bindProperties;
   }

   /**
    * Documentaci�.
    *
    * @return Object
    */
   public Object getTransientObject() {
      return this.getBeanWrapper().getWrappedInstance();
   }

   // EVC: added to allow actionForm.expose with customEditors.
   /**
    * Documentaci�.
    *
    * @return Map
    */
   public Map getCustomEditors() {
      if (this.anotherBeanWrapper instanceof BeanWrapperImpl) {
         return ((BeanWrapperImpl) this.anotherBeanWrapper).getCustomEditors();
      }

      return null;
   }

   /**
    * Documentaci�.
    *
    * @param customEditors Map
    */
   public void setCustomEditors(Map customEditors) {
      if (this.anotherBeanWrapper == null) {
         this.anotherBeanWrapper = new BeanWrapperImpl(super.getTarget(),
               bindProperties);
      }

      if (this.anotherBeanWrapper instanceof BeanWrapperImpl) {
         ((BeanWrapperImpl) this.anotherBeanWrapper).setCustomEditors(customEditors);
      }
   }
}
