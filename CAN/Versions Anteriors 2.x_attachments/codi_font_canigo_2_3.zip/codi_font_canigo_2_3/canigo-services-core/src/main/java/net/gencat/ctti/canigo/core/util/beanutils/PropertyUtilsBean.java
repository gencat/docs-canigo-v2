/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.core.util.beanutils;

import java.beans.PropertyDescriptor;

import java.lang.reflect.InvocationTargetException;

import java.util.Map;

import org.apache.commons.beanutils.NestedNullException;
import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.beans.BeanUtils;


/**
 * Property Utils Bean
 *
 * It extends Commons property utils to create instances
 * as needed if nested properties used
 * @author XES
 *
 */
public class PropertyUtilsBean extends org.apache.commons.beanutils.PropertyUtilsBean {
   /**
    * Creates a new PropertyUtilsBean object.
    */
   public PropertyUtilsBean() {
      super();
   }

   /**
    * Return the value of the (possibly nested) property of the specified
    * name, for the specified bean, with no type conversions.
    *
    * @param bean Bean whose property is to be extracted
    * @param name Possibly nested name of the property to be extracted
    *
    * @exception IllegalAccessException if the caller does not have
    *  access to the property accessor method
    * @exception IllegalArgumentException if <code>bean</code> or
    *  <code>name</code> is null
    * @exception NestedNullException if a nested reference to a
    *  property returns null
    * @exception InvocationTargetException
    * if the property accessor method throws an exception
    * @exception NoSuchMethodException if an accessor method for this
    *  propety cannot be found
    */
   public Object getNestedProperty(Object bean, String name)
      throws IllegalAccessException, InvocationTargetException,
         NoSuchMethodException {
      if (bean == null) {
         throw new IllegalArgumentException("No bean specified");
      }

      if (name == null) {
         throw new IllegalArgumentException("No name specified");
      }

      int indexOfINDEXED_DELIM = -1;
      int indexOfMAPPED_DELIM = -1;
      int indexOfMAPPED_DELIM2 = -1;
      int indexOfNESTED_DELIM = -1;

      while (true) {
         indexOfNESTED_DELIM = name.indexOf(PropertyUtils.NESTED_DELIM);
         indexOfMAPPED_DELIM = name.indexOf(PropertyUtils.MAPPED_DELIM);
         indexOfMAPPED_DELIM2 = name.indexOf(PropertyUtils.MAPPED_DELIM2);

         if ((indexOfMAPPED_DELIM2 >= 0) && (indexOfMAPPED_DELIM >= 0) &&
               ((indexOfNESTED_DELIM < 0) ||
               (indexOfNESTED_DELIM > indexOfMAPPED_DELIM))) {
            indexOfNESTED_DELIM = name.indexOf(PropertyUtils.NESTED_DELIM,
                  indexOfMAPPED_DELIM2);
         } else {
            indexOfNESTED_DELIM = name.indexOf(PropertyUtils.NESTED_DELIM);
         }

         if (indexOfNESTED_DELIM < 0) {
            break;
         }

         String next = name.substring(0, indexOfNESTED_DELIM);
         indexOfINDEXED_DELIM = next.indexOf(PropertyUtils.INDEXED_DELIM);
         indexOfMAPPED_DELIM = next.indexOf(PropertyUtils.MAPPED_DELIM);

         // client change: Declare nestedBean and use this property
         // to check
         Object nestedBean;

         if (bean instanceof Map) {
            nestedBean = ((Map) bean).get(next);
         } else if (indexOfMAPPED_DELIM >= 0) {
            nestedBean = getMappedProperty(bean, next);
         } else if (indexOfINDEXED_DELIM >= 0) {
            nestedBean = getIndexedProperty(bean, next);
         } else {
            nestedBean = getSimpleProperty(bean, next);
         }

         //=====================================================================
         // client: if bean is null create as an instance instead
         // of throwing NestedNullException
         //=====================================================================
         if (nestedBean == null) {
            // Obtain information in order to create instance
            PropertyDescriptor propertyDescriptor = getPropertyDescriptor(bean,
                  next);
            Class nestedBeanClass = propertyDescriptor.getPropertyType();

            // Create object
            Object nestedBeanObject = BeanUtils.instantiateClass(nestedBeanClass);
            // Now put in bean this nestedBeanObject
            setProperty(bean, propertyDescriptor.getName(), nestedBeanObject);

            // MMR: 07/08/06. Si encontramos una propiedad del tipo obj.propObj seguimos por el nestedBean
            nestedBean = nestedBeanObject;

            // MMR End.
         }

         // MMR: 07/08/06. Si encontramos una propiedad del tipo obj.propObj seguimos por el nestedBean
         if (nestedBean != null) {
            bean = nestedBean;
         }

         // MMR End.

         //======================================================================
         name = name.substring(indexOfNESTED_DELIM + 1);
      }

      indexOfINDEXED_DELIM = name.indexOf(PropertyUtils.INDEXED_DELIM);
      indexOfMAPPED_DELIM = name.indexOf(PropertyUtils.MAPPED_DELIM);

      if (bean instanceof Map) {
         bean = ((Map) bean).get(name);
      } else if (indexOfMAPPED_DELIM >= 0) {
         bean = getMappedProperty(bean, name);
      } else if (indexOfINDEXED_DELIM >= 0) {
         bean = getIndexedProperty(bean, name);
      } else {
         bean = getSimpleProperty(bean, name);
      }

      return bean;
   }
}
