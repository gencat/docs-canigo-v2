/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.core.springframework.beans;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyDescriptor;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorManager;

import java.io.File;
import java.io.InputStream;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.math.BigDecimal;
import java.math.BigInteger;

import java.net.URL;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.SortedSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.InvalidPropertyException;
import org.springframework.beans.MethodInvocationException;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.NotReadablePropertyException;
import org.springframework.beans.NotWritablePropertyException;
import org.springframework.beans.NullValueInNestedPathException;
import org.springframework.beans.PropertyAccessException;
import org.springframework.beans.PropertyBatchUpdateException;
import org.springframework.beans.PropertyValue;
import org.springframework.beans.PropertyValues;
import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.propertyeditors.ByteArrayPropertyEditor;
import org.springframework.beans.propertyeditors.CharacterEditor;
import org.springframework.beans.propertyeditors.ClassEditor;
import org.springframework.beans.propertyeditors.CustomBooleanEditor;
import org.springframework.beans.propertyeditors.CustomCollectionEditor;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.FileEditor;
import org.springframework.beans.propertyeditors.InputStreamEditor;
import org.springframework.beans.propertyeditors.LocaleEditor;
import org.springframework.beans.propertyeditors.PropertiesEditor;
import org.springframework.beans.propertyeditors.StringArrayPropertyEditor;
import org.springframework.beans.propertyeditors.URLEditor;
import org.springframework.core.MethodParameter;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourceArrayPropertyEditor;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;


/**
 * <p>Classe copiada del codi (Spring Beans 1.2.5) i canviada per tal de controlar
 * la creaci� de propietats null.
 * Implementacio de la interface BeanWrapper que hauria de ser suficient per
 * tots els casos.</p>
 *
 * <p>BeanWrapperImpl convertira els valors de coleccions i arrays sempre
 * que sigui necessari, mitjan�ant la classe propertyEditors.
 *
 * @author XES
 * @version $Revision: 1.10 $ $Date: 2007/09/17 10:30:43 $
 *
 * @see
 * @since
 *
 * <p>$Log: BeanWrapperImpl.java,v $
 * <p>Revision 1.10  2007/09/17 10:30:43  msabates
 * <p>Merge amb la branca BT2_1_325_1 i Jalopy
 * <p>
 * <p>Revision 1.9  2007/08/13 07:37:26  cbernal
 * <p>*** empty log message ***
 * <p>
 * <p>Revision 1.8  2007/07/26 10:48:08  cbernal
 * <p>Revisi� Javadoc
 * <p>
 * Revision 1.7  2007/07/16 08:46:11  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]</p>
 *
 * <p>Revision 1.6  2007/05/23 10:44:35  msabates
 * Cap�alera</p>
 *
 * <p>Revision 1.1.1.1.2.2  2007/05/18 10:46:24  fernando.vaquero
 * *** empty log message ***</p>
 *
 * <p>Revision 1.1.1.1.2.1  2007/05/15 15:55:46  fernando.vaquero
 * *** empty log message ***</p>
 *
 * <p>Revision 1.1.1.1  2007/05/15 13:52:48  fernando.vaquero
 * Importacio canigo 2.0</p>
 *
 * <p>Revision 1.4  2007/05/15 10:19:46  msabates
 * Jalopy</p>
 *
 * <p>Revision 1.3  2007/05/15 08:00:05  msabates
 * Merge amb la branca BT2001 (Spring 2.0)</p>
 *
 * <p>Revision 1.2  2007/04/23 11:18:57  msabates
 * Canvis que estaven a la v1.4</p>
 *
 * <p>Revision 1.6  2007/02/20 14:34:17  evidal
 * EVC: fixed expose with customEditors bug.</p>
 *
 * <p>Revision 1.3.2.3  2007/02/20 14:31:51  evidal
 * EVC: fixed expose with customEditors bug.</p>
 *
 * <p>Revision 1.3.2.2  2006/03/06 11:44:59  mmateos
 * MMR: corregido un bug de binding en los CustomNumberEditor</p>
 *
 * <p>Revision 1.3.2.1  2006/03/03 15:02:10  xescuder
 * XES: Added documentation</p>
 *
 */
public class BeanWrapperImpl implements org.springframework.beans.BeanWrapper {
   /**
    * Documentaci�.
    */
   public static String ALLOW_EMPTY_NUMBERS = "allowNumberEditorEmptyStrings";

   /**
    * Crearem molts objectes Log, per� no voldrem un de nou sempre.
    */
   private static final Log logger = LogFactory.getLog(BeanWrapperImpl.class);

   /**
    * Documentaci�.
    */
   private final Map defaultEditors;

   /**
    * Cached introspections results for this object, to prevent encountering
    * the cost of JavaBeans introspection every time.
    */
   private CachedIntrospectionResults cachedIntrospectionResults;

   /**
    * Documentaci�.
    */
   private Map bindProperties;

   /**
    * Documentaci�.
    */
   private Map customEditors;

   /**
    * Map with cached nested BeanWrappers: nested path -> BeanWrapper instance.
    */
   private Map nestedBeanWrappers;

   //---------------------------------------------------------------------
   // Instance data
   //---------------------------------------------------------------------

   /**
    * Objecte wrapped.
    */
   private Object object;

   /**
    * Documentaci�.
    */
   private Object rootObject;

   /**
    * Documentaci�.
    */
   private String nestedPath = "";

   /**
    * Documentaci�.
    */
   private boolean extractOldValueForEditor = false;

   //---------------------------------------------------------------------
   // Constructors
   //---------------------------------------------------------------------

   /**
    * Crea un nou BeanWrapperImpl. La instancia necesitar� cridar al seu set.
    *
    * @see #setWrappedInstance
    */
   public BeanWrapperImpl() {
      this(true);
   }

   /**
    * Crea un nou BeanWrapperImpl. La instancia necesitar� cridar al seu set.
    *
    * @param boolean registerDefaultEditors
    * @see #setWrappedInstance
    */
   public BeanWrapperImpl(boolean registerDefaultEditors) {
      if (registerDefaultEditors) {
         this.defaultEditors = new HashMap(32);
         registerDefaultEditors();
      } else {
         this.defaultEditors = Collections.EMPTY_MAP;
      }
   }

   /**
    * Crea un nou BeanWrapperImpl per l'objecte donat.
    *
    * @param Object object
    */
   public BeanWrapperImpl(Object object) {
      this();
      setWrappedInstance(object);
   }

   /**
    * Crea un nou objecte BeanWrapperImpl.
    *
    * @param Object object
    * @param Map bindProperties
    */
   public BeanWrapperImpl(Object object, Map bindProperties) {
      this();
      setWrappedInstance(object);
      setBindProperties(bindProperties);
   }

   /**
    * Crea un nou BeanWrapperImpl, Agrupant una nova instancia de la classe especificada.
    *
    * @param clazz class
    */
   public BeanWrapperImpl(Class clazz) {
      this();
      setWrappedInstance(BeanUtils.instantiateClass(clazz));
   }

   /**
    * Crea una nova BeanWrapperImpl per a l'objecte, registrant una ruta on l'objecte es troba.
    *
    * @param object Object
    * @param nestedPath String - la ruta de l'objecte
    * @param rootObject Object
    */
   public BeanWrapperImpl(Object object, String nestedPath, Object rootObject) {
      this();
      setWrappedInstance(object, nestedPath, rootObject);
   }

   /**
    * Crea una nova BeanWrapperImpl per a l'objecte, registrant una ruta on l'objecte es troba.
    *
    * @param object Object
    * @param nestedPath String - la ruta de l'objecte
    * @param superBw BeanWrapperImpl
    */
   private BeanWrapperImpl(Object object, String nestedPath,
      BeanWrapperImpl superBw) {
      this.defaultEditors = superBw.defaultEditors;
      setWrappedInstance(object, nestedPath, superBw.getWrappedInstance());
      setBindProperties(superBw.getBindProperties());
   }

   /**
    * Es registren els editors predeterminats en aquesta classe, per entorns rectrictius.
    * No s'utilitzen els JRE's PropertyEditorManager per permetre SecurityExceptions quan
    * executem en SecurityManager
    */
   private void registerDefaultEditors() {
      // Simple editors, without parameterization capabilities.
      // The JDK does not contain a default editor for any of these target types.
      this.defaultEditors.put(byte[].class, new ByteArrayPropertyEditor());
      this.defaultEditors.put(Class.class, new ClassEditor());
      this.defaultEditors.put(File.class, new FileEditor());
      this.defaultEditors.put(InputStream.class, new InputStreamEditor());
      this.defaultEditors.put(Locale.class, new LocaleEditor());
      this.defaultEditors.put(Properties.class, new PropertiesEditor());
      this.defaultEditors.put(Resource[].class,
         new ResourceArrayPropertyEditor());
      this.defaultEditors.put(String[].class, new StringArrayPropertyEditor());
      this.defaultEditors.put(URL.class, new URLEditor());

      // Default instances of collection editors.
      // Can be overridden by registering custom instances of those as custom editors.
      this.defaultEditors.put(Collection.class,
         new CustomCollectionEditor(Collection.class));
      this.defaultEditors.put(Set.class, new CustomCollectionEditor(Set.class));
      this.defaultEditors.put(SortedSet.class,
         new CustomCollectionEditor(SortedSet.class));
      this.defaultEditors.put(List.class, new CustomCollectionEditor(List.class));

      // Default instances of character and boolean editors.
      // Can be overridden by registering custom instances of those as custom editors.
      PropertyEditor characterEditor = new CharacterEditor(false);
      PropertyEditor booleanEditor = new CustomBooleanEditor(false);

      // The JDK does not contain a default editor for char!
      this.defaultEditors.put(char.class, characterEditor);
      this.defaultEditors.put(Character.class, characterEditor);

      // Spring's CustomBooleanEditor accepts more flag values than the JDK's default editor.
      this.defaultEditors.put(boolean.class, booleanEditor);
      this.defaultEditors.put(Boolean.class, booleanEditor);

      // The JDK does not contain default editors for number wrapper types!
      // Override JDK primitive number editors with our own CustomNumberEditor.
      boolean allowEmpty = true;

      if ((this.bindProperties != null) &&
            this.bindProperties.containsKey(ALLOW_EMPTY_NUMBERS)) {
         allowEmpty = !"false".equalsIgnoreCase((String) this.bindProperties.get(
                  ALLOW_EMPTY_NUMBERS));
      }

      PropertyEditor byteEditor = new CustomNumberEditor(Byte.class, allowEmpty);
      PropertyEditor shortEditor = new CustomNumberEditor(Short.class,
            allowEmpty);
      PropertyEditor integerEditor = new CustomNumberEditor(Integer.class,
            allowEmpty);
      PropertyEditor longEditor = new CustomNumberEditor(Long.class, allowEmpty);
      PropertyEditor floatEditor = new CustomNumberEditor(Float.class,
            allowEmpty);
      PropertyEditor doubleEditor = new CustomNumberEditor(Double.class,
            allowEmpty);

      this.defaultEditors.put(byte.class, byteEditor);
      this.defaultEditors.put(Byte.class, byteEditor);

      this.defaultEditors.put(short.class, shortEditor);
      this.defaultEditors.put(Short.class, shortEditor);

      this.defaultEditors.put(int.class, integerEditor);
      this.defaultEditors.put(Integer.class, integerEditor);

      this.defaultEditors.put(long.class, longEditor);
      this.defaultEditors.put(Long.class, longEditor);

      this.defaultEditors.put(float.class, floatEditor);
      this.defaultEditors.put(Float.class, floatEditor);

      this.defaultEditors.put(double.class, doubleEditor);
      this.defaultEditors.put(Double.class, doubleEditor);

      this.defaultEditors.put(BigDecimal.class,
         new CustomNumberEditor(BigDecimal.class, false));
      this.defaultEditors.put(BigInteger.class,
         new CustomNumberEditor(BigInteger.class, false));
   }

   //---------------------------------------------------------------------
   // Implementation of BeanWrapper
   //---------------------------------------------------------------------

   /**
    * Switch the target object, replacing the cached introspection results only
    * if the class of the new object is different to that of the replaced object.
    * @param object new target
    */
   public void setWrappedInstance(Object object) {
      setWrappedInstance(object, "", null);
   }

   /**
    * Switch the target object, replacing the cached introspection results only
    * if the class of the new object is different to that of the replaced object.
    * @param object new target
    * @param nestedPath the nested path of the object
    * @param rootObject the root object at the top of the path
    */
   public void setWrappedInstance(Object object, String nestedPath,
      Object rootObject) {
      if (object == null) {
         throw new IllegalArgumentException(
            "Cannot set BeanWrapperImpl target to a null object");
      }

      this.object = object;
      this.nestedPath = ((nestedPath != null) ? nestedPath : "");
      this.rootObject = ((!"".equals(this.nestedPath)) ? rootObject : object);
      this.nestedBeanWrappers = null;
      setIntrospectionClass(object.getClass());
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getWrappedInstance() {
      return this.object;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Class getWrappedClass() {
      return this.object.getClass();
   }

   /**
    * Return the nested path of the object wrapped by this BeanWrapper.
    */
   public String getNestedPath() {
      return this.nestedPath;
   }

   /**
    * Return the root object at the top of the path of this BeanWrapper.
    * @see #getNestedPath
    */
   public Object getRootInstance() {
      return this.rootObject;
   }

   /**
    * Return the class of the root object at the top of the path of this BeanWrapper.
    * @see #getNestedPath
    */
   public Class getRootClass() {
      return ((this.rootObject != null) ? this.rootObject.getClass() : null);
   }

   /**
    * Set the class to introspect.
    * Needs to be called when the target object changes.
    * @param clazz the class to introspect
    */
   protected void setIntrospectionClass(Class clazz) {
      if ((this.cachedIntrospectionResults == null) ||
            !this.cachedIntrospectionResults.getBeanClass().equals(clazz)) {
         this.cachedIntrospectionResults = CachedIntrospectionResults.forClass(clazz);
      }
   }

   /**
    * Documentaci�.
    *
    * @param extractOldValueForEditor Documentaci�
    */
   public void setExtractOldValueForEditor(boolean extractOldValueForEditor) {
      this.extractOldValueForEditor = extractOldValueForEditor;
   }

   /**
    * Documentaci�.
    *
    * @param requiredType
    * @param propertyEditor
    */
   public void registerCustomEditor(Class requiredType,
      PropertyEditor propertyEditor) {
      registerCustomEditor(requiredType, null, propertyEditor);
   }

   /**
    * Documentaci�.
    *
    * @param requiredType
    * @param propertyPath
    * @param propertyEditor
    */
   public void registerCustomEditor(Class requiredType, String propertyPath,
      PropertyEditor propertyEditor) {
      if ((requiredType == null) && (propertyPath == null)) {
         throw new IllegalArgumentException(
            "Either requiredType or propertyPath is required");
      }

      if (this.customEditors == null) {
         this.customEditors = new HashMap();
      }

      if (propertyPath != null) {
         this.customEditors.put(propertyPath,
            new CustomEditorHolder(propertyEditor, requiredType));
      } else {
         this.customEditors.put(requiredType, propertyEditor);
      }
   }

   /**
    * Documentaci�.
    *
    * @param requiredType
    * @param propertyPath
    *
    * @return PropertyEditor o Null
    */
   public PropertyEditor findCustomEditor(Class requiredType,
      String propertyPath) {
      if (this.customEditors == null) {
         return null;
      }

      if (propertyPath != null) {
         // Check property-specific editor first.
         PropertyEditor editor = getCustomEditor(propertyPath, requiredType);

         if (editor == null) {
            List strippedPaths = new LinkedList();
            addStrippedPropertyPaths(strippedPaths, "", propertyPath);

            for (Iterator it = strippedPaths.iterator();
                  it.hasNext() && (editor == null);) {
               String strippedPath = (String) it.next();
               editor = getCustomEditor(strippedPath, requiredType);
            }
         }

         if (editor != null) {
            return editor;
         } else if (requiredType == null) {
            requiredType = getPropertyType(propertyPath);
         }
      }

      // No property-specific editor -> check type-specific editor.
      return getCustomEditor(requiredType);
   }

   /**
    * Get custom editor that has been registered for the given property.
    * @return PropertyEditor o Null
    */
   private PropertyEditor getCustomEditor(String propertyName,
      Class requiredType) {
      CustomEditorHolder holder = (CustomEditorHolder) this.customEditors.get(propertyName);

      return ((holder != null) ? holder.getPropertyEditor(requiredType) : null);
   }

   /**
    * Get custom editor for the given type. If no direct match found,
    * try custom editor for superclass (which will in any case be able
    * to render a value as String via <code>getAsText</code>).
    * @return the custom editor, or <code>null</code> if none found for this type
    * @see java.beans.PropertyEditor#getAsText
    */
   private PropertyEditor getCustomEditor(Class requiredType) {
      if (requiredType != null) {
         PropertyEditor editor = (PropertyEditor) this.customEditors.get(requiredType);

         if (editor == null) {
            for (Iterator it = this.customEditors.keySet().iterator();
                  it.hasNext();) {
               Object key = it.next();

               if (key instanceof Class &&
                     ((Class) key).isAssignableFrom(requiredType)) {
                  editor = (PropertyEditor) this.customEditors.get(key);
               }
            }
         }

         return editor;
      }

      return null;
   }

   /**
    * Afegeix les rutes amb totes les variacions de les keys y/o index.
    * S'invoca a si mateix recursivament amb rutes anidades.
    *
    * @param List strippedPaths
    * @param String nestedPath
    * @param String propertyPath
    */
   private void addStrippedPropertyPaths(List strippedPaths, String nestedPath,
      String propertyPath) {
      int startIndex = propertyPath.indexOf(PROPERTY_KEY_PREFIX_CHAR);

      if (startIndex != -1) {
         int endIndex = propertyPath.indexOf(PROPERTY_KEY_SUFFIX_CHAR);

         if (endIndex != -1) {
            String prefix = propertyPath.substring(0, startIndex);
            String key = propertyPath.substring(startIndex, endIndex + 1);
            String suffix = propertyPath.substring(endIndex + 1,
                  propertyPath.length());

            // strip the first key
            strippedPaths.add(nestedPath + prefix + suffix);

            // search for further keys to strip, with the first key stripped
            addStrippedPropertyPaths(strippedPaths, nestedPath + prefix, suffix);

            // search for further keys to strip, with the first key not stripped
            addStrippedPropertyPaths(strippedPaths, nestedPath + prefix + key,
               suffix);
         }
      }
   }

   /**
    * Ens diu el primer (o �ltim) separador de la propietat donada,
    * ignorant punts entre claus com "map[my.key]".
    *
    * @param String propertyPath
    * @param boolean last
    *
    * @return int l'index del separador. -1 si no hi ha separador
    */
   private int getNestedPropertySeparatorIndex(String propertyPath, boolean last) {
      boolean inKey = false;
      int i = (last ? (propertyPath.length() - 1) : 0);

      while ((last && (i >= 0)) || (i < propertyPath.length())) {
         switch (propertyPath.charAt(i)) {
         case PROPERTY_KEY_PREFIX_CHAR:
         case PROPERTY_KEY_SUFFIX_CHAR:
            inKey = !inKey;

            break;

         case NESTED_PROPERTY_SEPARATOR_CHAR:

            if (!inKey) {
               return i;
            }
         }

         if (last) {
            i--;
         } else {
            i++;
         }
      }

      return -1;
   }

   /**
    * Aconsegueix l'�ltim component del path.
    *
    * @param BeanWrapper bw
    * @param String nestedPath
    *
    * @return String �ltim component del path
    */
   private String getFinalPath(org.springframework.beans.BeanWrapper bw,
      String nestedPath) {
      if (bw == this) {
         return nestedPath;
      }

      return nestedPath.substring(getNestedPropertySeparatorIndex(nestedPath,
            true) + 1);
   }

   /**
    * Recursively navigate to return a BeanWrapper for the nested property path.
    *
    * @param propertyPath property property path, which may be nested
    * @return a BeanWrapper for the target bean
    */
   protected BeanWrapperImpl getBeanWrapperForPropertyPath(String propertyPath)
      throws BeansException {
      int pos = getNestedPropertySeparatorIndex(propertyPath, false);

      // handle nested properties recursively
      if (pos > -1) {
         String nestedProperty = propertyPath.substring(0, pos);
         String nestedPath = propertyPath.substring(pos + 1);
         BeanWrapperImpl nestedBw = getNestedBeanWrapper(nestedProperty);

         return nestedBw.getBeanWrapperForPropertyPath(nestedPath);
      } else {
         return this;
      }
   }

   /**
    * Retrieve a BeanWrapper for the given nested property.
    * Create a new one if not found in the cache.
    * <p>Note: Caching nested BeanWrappers is necessary now,
    * to keep registered custom editors for nested properties.
    *
    * @param String nestedProperty
    * @return BeanWrapperImpl
    */
   private BeanWrapperImpl getNestedBeanWrapper(String nestedProperty)
      throws BeansException {
      if (this.nestedBeanWrappers == null) {
         this.nestedBeanWrappers = new HashMap();
      }

      // get value of bean property
      PropertyTokenHolder tokens = getPropertyNameTokens(nestedProperty);
      Object propertyValue = getPropertyValue(tokens);
      String canonicalName = tokens.canonicalName;
      String propertyName = tokens.actualName;

      if (propertyValue == null) {
         throw new NullValueInNestedPathException(getRootClass(),
            this.nestedPath + canonicalName);
      }

      // lookup cached sub-BeanWrapper, create new one if not found
      BeanWrapperImpl nestedBw = (BeanWrapperImpl) this.nestedBeanWrappers.get(canonicalName);

      if ((nestedBw == null) ||
            (nestedBw.getWrappedInstance() != propertyValue)) {
         if (logger.isDebugEnabled()) {
            logger.debug("Creating new nested BeanWrapper for property '" +
               canonicalName + "'");
         }

         nestedBw = new BeanWrapperImpl(propertyValue,
               this.nestedPath + canonicalName + NESTED_PROPERTY_SEPARATOR, this);

         // inherit all type-specific PropertyEditors
         if (this.customEditors != null) {
            for (Iterator it = this.customEditors.entrySet().iterator();
                  it.hasNext();) {
               Map.Entry entry = (Map.Entry) it.next();

               if (entry.getKey() instanceof Class) {
                  Class requiredType = (Class) entry.getKey();
                  PropertyEditor editor = (PropertyEditor) entry.getValue();
                  nestedBw.registerCustomEditor(requiredType, editor);
               } else if (entry.getKey() instanceof String) {
                  String editorPath = (String) entry.getKey();
                  int pos = getNestedPropertySeparatorIndex(editorPath, false);

                  if (pos != -1) {
                     String editorNestedProperty = editorPath.substring(0, pos);
                     String editorNestedPath = editorPath.substring(pos + 1);

                     if (editorNestedProperty.equals(canonicalName) ||
                           editorNestedProperty.equals(propertyName)) {
                        CustomEditorHolder editorHolder = (CustomEditorHolder) entry.getValue();
                        nestedBw.registerCustomEditor(editorHolder.getRegisteredType(),
                           editorNestedPath, editorHolder.getPropertyEditor());
                     }
                  }
               }
            }
         }

         this.nestedBeanWrappers.put(canonicalName, nestedBw);
      } else {
         if (logger.isDebugEnabled()) {
            logger.debug("Using cached nested BeanWrapper for property '" +
               canonicalName + "'");
         }
      }

      return nestedBw;
   }

   /**
    * Documentaci�.
    *
    * @param String propertyName
    *
    * @return PropertyTokenHolder
    */
   private PropertyTokenHolder getPropertyNameTokens(String propertyName) {
      PropertyTokenHolder tokens = new PropertyTokenHolder();
      String actualName = null;
      List keys = new ArrayList(2);
      int searchIndex = 0;

      while (searchIndex != -1) {
         int keyStart = propertyName.indexOf(PROPERTY_KEY_PREFIX, searchIndex);
         searchIndex = -1;

         if (keyStart != -1) {
            int keyEnd = propertyName.indexOf(PROPERTY_KEY_SUFFIX,
                  keyStart + PROPERTY_KEY_PREFIX.length());

            if (keyEnd != -1) {
               if (actualName == null) {
                  actualName = propertyName.substring(0, keyStart);
               }

               String key = propertyName.substring(keyStart +
                     PROPERTY_KEY_PREFIX.length(), keyEnd);

               if (key.startsWith("'") && key.endsWith("'")) {
                  key = key.substring(1, key.length() - 1);
               } else if (key.startsWith("\"") && key.endsWith("\"")) {
                  key = key.substring(1, key.length() - 1);
               }

               keys.add(key);
               searchIndex = keyEnd + PROPERTY_KEY_SUFFIX.length();
            }
         }
      }

      tokens.actualName = ((actualName != null) ? actualName : propertyName);
      tokens.canonicalName = tokens.actualName;

      if (!keys.isEmpty()) {
         tokens.canonicalName += (PROPERTY_KEY_PREFIX +
         StringUtils.collectionToDelimitedString(keys,
            PROPERTY_KEY_SUFFIX + PROPERTY_KEY_PREFIX) + PROPERTY_KEY_SUFFIX);
         tokens.keys = (String[]) keys.toArray(new String[keys.size()]);
      }

      return tokens;
   }

   /**
    * Documentaci�.
    *
    * @param String propertyName
    *
    * @return Object
    *
    * @throws BeansException
    */
   public Object getPropertyValue(String propertyName)
      throws BeansException {
      BeanWrapperImpl nestedBw = getBeanWrapperForPropertyPath(propertyName);
      PropertyTokenHolder tokens = getPropertyNameTokens(getFinalPath(
               nestedBw, propertyName));

      return nestedBw.getPropertyValue(tokens);
   }

   /**
    * Canvis ctti.
    * @param tokens PropertyTokenHolder
    * @return Object
    * @throws BeansException
    */
   protected Object getPropertyValue(PropertyTokenHolder tokens)
      throws BeansException {
      String propertyName = tokens.canonicalName;
      String actualName = tokens.actualName;
      PropertyDescriptor pd = getPropertyDescriptorInternal(tokens.actualName);

      if ((pd == null) || (pd.getReadMethod() == null)) {
         throw new NotReadablePropertyException(getRootClass(),
            this.nestedPath + propertyName);
      }

      if (logger.isDebugEnabled()) {
         logger.debug("About to invoke read method [" + pd.getReadMethod() +
            "] on object of class [" + this.object.getClass().getName() + "]");
      }

      try {
         Object value = pd.getReadMethod().invoke(this.object, (Object[]) null);

         //================ ctti changes ======================/
         if (value == null) { //ctti changes

            Class nestedBeanClass = pd.getPropertyType();

            if ((nestedBeanClass != null) &&
                  !nestedBeanClass.getName().startsWith("java")) {
               // Create object
               Object nestedBeanObject = BeanUtils.instantiateClass(nestedBeanClass);

               // Now put in bean this nestedBeanObject
               Object[] arguments = { nestedBeanObject };
               pd.getWriteMethod().invoke(this.object, arguments);
               value = pd.getReadMethod().invoke(this.object, (Object[]) null);
            }
         }

         //================ end of ctti changes ======================/
         if (tokens.keys != null) {
            // apply indexes and map keys
            for (int i = 0; i < tokens.keys.length; i++) {
               String key = tokens.keys[i];

               if (value == null) {
                  throw new NullValueInNestedPathException(getRootClass(),
                     this.nestedPath + propertyName,
                     "Cannot access indexed value of property referenced in indexed " +
                     "property path '" + propertyName + "': returned null");
               } else if (value.getClass().isArray()) {
                  value = Array.get(value, Integer.parseInt(key));
               } else if (value instanceof List) {
                  List list = (List) value;
                  value = list.get(Integer.parseInt(key));
               } else if (value instanceof Set) {
                  // apply index to Iterator in case of a Set
                  Set set = (Set) value;
                  int index = Integer.parseInt(key);

                  if ((index < 0) || (index >= set.size())) {
                     throw new InvalidPropertyException(getRootClass(),
                        this.nestedPath + propertyName,
                        "Cannot get element with index " + index +
                        " from Set of size " + set.size() +
                        ", accessed using property path '" + propertyName +
                        "'");
                  }

                  Iterator it = set.iterator();

                  for (int j = 0; it.hasNext(); j++) {
                     Object elem = it.next();

                     if (j == index) {
                        value = elem;

                        break;
                     }
                  }
               } else if (value instanceof Map) {
                  Map map = (Map) value;
                  value = map.get(key);
               } else {
                  throw new InvalidPropertyException(getRootClass(),
                     this.nestedPath + propertyName,
                     "Property referenced in indexed property path '" +
                     propertyName +
                     "' is neither an array nor a List nor a Set nor a Map; returned value was [" +
                     value + "]");
               }
            }
         }

         return value;
      } catch (InvocationTargetException ex) {
         throw new InvalidPropertyException(getRootClass(),
            this.nestedPath + propertyName,
            "Getter for property '" + actualName + "' threw exception", ex);
      } catch (IllegalAccessException ex) {
         throw new InvalidPropertyException(getRootClass(),
            this.nestedPath + propertyName,
            "Illegal attempt to get property '" + actualName +
            "' threw exception", ex);
      } catch (IndexOutOfBoundsException ex) {
         throw new InvalidPropertyException(getRootClass(),
            this.nestedPath + propertyName,
            "Index of out of bounds in property path '" + propertyName + "'", ex);
      } catch (NumberFormatException ex) {
         throw new InvalidPropertyException(getRootClass(),
            this.nestedPath + propertyName,
            "Invalid index in property path '" + propertyName + "'", ex);
      }
   }

   /**
    * Documentaci�.
    *
    * @param String StringpropertyName
    * @param Object value
    *
    * @throws BeansException
    * @throws NotWritablePropertyException
    */
   public void setPropertyValue(String propertyName, Object value)
      throws BeansException {
      BeanWrapperImpl nestedBw = null;
      logger.debug("Trying to set property " + propertyName + " with value " +
         value + " into " + this.getWrappedClass());

      try {
         nestedBw = getBeanWrapperForPropertyPath(propertyName);
      } catch (NotReadablePropertyException ex) {
         throw new NotWritablePropertyException(getRootClass(),
            this.nestedPath + propertyName,
            "Nested property in path '" + propertyName + "' does not exist", ex);
      }

      PropertyTokenHolder tokens = getPropertyNameTokens(getFinalPath(
               nestedBw, propertyName));
      nestedBw.setPropertyValue(tokens, value);
   }

   /**
    * Documentaci�.
    *
    * @param PropertyTokenHolder tokens
    * @param Object newValue
    *
    * @throws BeansException
    * @throws NotWritablePropertyException
    * @throws NullValueInNestedPathException
    * @throws TypeMismatchException
    * @throws InvalidPropertyException
    * @throws MethodInvocationException
    */
   protected void setPropertyValue(PropertyTokenHolder tokens, Object newValue)
      throws BeansException {
      String propertyName = tokens.canonicalName;

      if (tokens.keys != null) {
         // apply indexes and map keys: fetch value for all keys but the last one
         PropertyTokenHolder getterTokens = new PropertyTokenHolder();
         getterTokens.canonicalName = tokens.canonicalName;
         getterTokens.actualName = tokens.actualName;
         getterTokens.keys = new String[tokens.keys.length - 1];
         System.arraycopy(tokens.keys, 0, getterTokens.keys, 0,
            tokens.keys.length - 1);

         Object propValue = null;

         try {
            propValue = getPropertyValue(getterTokens);
         } catch (NotReadablePropertyException ex) {
            throw new NotWritablePropertyException(getRootClass(),
               this.nestedPath + propertyName,
               "Cannot access indexed value in property referenced " +
               "in indexed property path '" + propertyName + "'", ex);
         }

         // set value for last key
         String key = tokens.keys[tokens.keys.length - 1];

         if (propValue == null) {
            throw new NullValueInNestedPathException(getRootClass(),
               this.nestedPath + propertyName,
               "Cannot access indexed value in property referenced " +
               "in indexed property path '" + propertyName +
               "': returned null");
         } else if (propValue.getClass().isArray()) {
            Class requiredType = propValue.getClass().getComponentType();
            int arrayIndex = Integer.parseInt(key);
            Object oldValue = null;

            try {
               if (this.extractOldValueForEditor) {
                  oldValue = Array.get(propValue, arrayIndex);
               }

               Object convertedValue = doTypeConversionIfNecessary(propertyName,
                     propertyName, oldValue, newValue, requiredType);
               Array.set(propValue, Integer.parseInt(key), convertedValue);
            } catch (IllegalArgumentException ex) {
               PropertyChangeEvent pce = new PropertyChangeEvent(this.rootObject,
                     this.nestedPath + propertyName, oldValue, newValue);
               throw new TypeMismatchException(pce, requiredType, ex);
            } catch (IndexOutOfBoundsException ex) {
               throw new InvalidPropertyException(getRootClass(),
                  this.nestedPath + propertyName,
                  "Invalid array index in property path '" + propertyName +
                  "'", ex);
            }
         } else if (propValue instanceof List) {
            List list = (List) propValue;
            int index = Integer.parseInt(key);
            Object oldValue = null;

            if (this.extractOldValueForEditor && (index < list.size())) {
               oldValue = list.get(index);
            }

            Object convertedValue = doTypeConversionIfNecessary(propertyName,
                  propertyName, oldValue, newValue, null);

            if (index < list.size()) {
               list.set(index, convertedValue);
            } else if (index >= list.size()) {
               for (int i = list.size(); i < index; i++) {
                  try {
                     list.add(null);
                  } catch (NullPointerException ex) {
                     throw new InvalidPropertyException(getRootClass(),
                        this.nestedPath + propertyName,
                        "Cannot set element with index " + index +
                        " in List of size " + list.size() +
                        ", accessed using property path '" + propertyName +
                        "': List does not support filling up gaps with null elements");
                  }
               }

               list.add(convertedValue);
            }
         } else if (propValue instanceof Map) {
            Map map = (Map) propValue;
            Object oldValue = null;

            if (this.extractOldValueForEditor) {
               oldValue = map.get(key);
            }

            Object convertedValue = doTypeConversionIfNecessary(propertyName,
                  propertyName, oldValue, newValue, null);
            map.put(key, convertedValue);
         } else {
            throw new InvalidPropertyException(getRootClass(),
               this.nestedPath + propertyName,
               "Property referenced in indexed property path '" + propertyName +
               "' is neither an array nor a List nor a Map; returned value was [" +
               newValue + "]");
         }
      } else {
         PropertyDescriptor pd = getPropertyDescriptorInternal(propertyName);

         if ((pd == null) || (pd.getWriteMethod() == null)) {
            throw new NotWritablePropertyException(getRootClass(),
               this.nestedPath + propertyName);
         }

         Method readMethod = pd.getReadMethod();
         Method writeMethod = pd.getWriteMethod();
         Object oldValue = null;

         if (this.extractOldValueForEditor && (readMethod != null)) {
            try {
               oldValue = readMethod.invoke(this.object, new Object[0]);
            } catch (Exception ex) {
               logger.debug("Could not read previous value of property '" +
                  this.nestedPath + propertyName, ex);
            }
         }

         try {
            Object convertedValue = doTypeConversionIfNecessary(propertyName,
                  propertyName, oldValue, newValue, pd.getPropertyType());

            if (pd.getPropertyType().isPrimitive() &&
                  ((convertedValue == null) || "".equals(convertedValue))) {
               throw new IllegalArgumentException("Invalid value [" + newValue +
                  "] for property '" + pd.getName() + "' of primitive type [" +
                  pd.getPropertyType() + "]");
            }

            if (logger.isDebugEnabled()) {
               logger.debug("About to invoke write method [" + writeMethod +
                  "] on object of class [" + this.object.getClass().getName() +
                  "]");
            }

            writeMethod.invoke(this.object, new Object[] { convertedValue });

            if (logger.isDebugEnabled()) {
               logger.debug("Invoked write method [" + writeMethod +
                  "] with value of type [" + pd.getPropertyType().getName() +
                  "]");
            }
         } catch (InvocationTargetException ex) {
            PropertyChangeEvent propertyChangeEvent = new PropertyChangeEvent(this.rootObject,
                  this.nestedPath + propertyName, oldValue, newValue);

            if (ex.getTargetException() instanceof ClassCastException) {
               throw new TypeMismatchException(propertyChangeEvent,
                  pd.getPropertyType(), ex.getTargetException());
            } else {
               throw new MethodInvocationException(propertyChangeEvent,
                  ex.getTargetException());
            }
         } catch (IllegalArgumentException ex) {
            PropertyChangeEvent pce = new PropertyChangeEvent(this.rootObject,
                  this.nestedPath + propertyName, oldValue, newValue);
            throw new TypeMismatchException(pce, pd.getPropertyType(), ex);
         } catch (IllegalAccessException ex) {
            PropertyChangeEvent pce = new PropertyChangeEvent(this.rootObject,
                  this.nestedPath + propertyName, oldValue, newValue);
            throw new MethodInvocationException(pce, ex);
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param PropertyValue pv
    *
    * @throws BeansException
    */
   public void setPropertyValue(PropertyValue pv) throws BeansException {
      setPropertyValue(pv.getName(), pv.getValue());
   }

   /**
    * Bulk update from a Map.
    * Bulk updates from PropertyValues are more powerful: this method is
    * provided for convenience.
    * @param Map map
    * @throws BeansException if there's a fatal, low-level exception
    */
   public void setPropertyValues(Map map) throws BeansException {
      setPropertyValues(new MutablePropertyValues(map));
   }

   /**
    * Documentaci�.
    *
    * @param PropertyValues pvs
    *
    * @throws BeansException
    */
   public void setPropertyValues(PropertyValues pvs) throws BeansException {
      setPropertyValues(pvs, false);
   }

   /**
    * Documentaci�.
    *
    * @param PropertyValues propertyValues
    * @param boolean ignoreUnknown
    *
    * @throws BeansException
    * @throws PropertyBatchUpdateException
    */
   public void setPropertyValues(PropertyValues propertyValues,
      boolean ignoreUnknown) throws BeansException {
      List propertyAccessExceptions = new ArrayList();
      PropertyValue[] pvs = propertyValues.getPropertyValues();

      for (int i = 0; i < pvs.length; i++) {
         try {
            // This method may throw any BeansException, which won't be caught
            // here, if there is a critical failure such as no matching field.
            // We can attempt to deal only with less serious exceptions.
            setPropertyValue(pvs[i]);
         } catch (NotWritablePropertyException ex) {
            if (!ignoreUnknown) {
               throw ex;
            }

            // Otherwise, just ignore it and continue...
         } catch (PropertyAccessException ex) {
            propertyAccessExceptions.add(ex);
         }
      }

      // If we encountered individual exceptions, throw the composite exception.
      if (!propertyAccessExceptions.isEmpty()) {
         Object[] paeArray = propertyAccessExceptions.toArray(new PropertyAccessException[propertyAccessExceptions.size()]);
         throw new PropertyBatchUpdateException((PropertyAccessException[]) paeArray);
      }
   }

   /**
    * Documentaci�.
    *
    * @param String propertyName
    * @param Object oldValue
    * @param Object newValue
    *
    * @return PropertyChangeEvent
    */
   private PropertyChangeEvent createPropertyChangeEvent(String propertyName,
      Object oldValue, Object newValue) {
      return new PropertyChangeEvent(((this.rootObject != null)
         ? this.rootObject : "constructor"),
         ((propertyName != null) ? (this.nestedPath + propertyName) : null),
         oldValue, newValue);
   }

   /**
    * Converteix el valor al tipus necessari. Les conversionsde String a qualsevol
    * tipus utilitzen els metode <code>setAsText</code> de la classe PropertyEditor.
    *
    * @param Object newValue
    * @param Class requiredType
    *
    * @return Object
    *
    * @throws TypeMismatchException
    *
    * @see java.beans.PropertyEditor#setAsText(String)
    * @see java.beans.PropertyEditor#getValue()
    */
   public Object doTypeConversionIfNecessary(Object newValue, Class requiredType)
      throws TypeMismatchException {
      return doTypeConversionIfNecessary(null, null, null, newValue,
         requiredType);
   }

   /**
    * Converteix el valor al tipus requerid per la propietat especifica
    *
    * @param String propertyName nom de la propietat
    * @param String fullPropertyName
    * @param Object oldValue
    * @param Object newValue
    * @param Class requiredType
    *
    * @return Object el valor nou
    *
    * @throws TypeMismatchException if type conversion failed
    */
   protected Object doTypeConversionIfNecessary(String propertyName,
      String fullPropertyName, Object oldValue, Object newValue,
      Class requiredType) throws TypeMismatchException {
      Object convertedValue = newValue;

      if (convertedValue != null) {
         // Custom editor for this type?
         PropertyEditor pe = findCustomEditor(requiredType, fullPropertyName);

         // Value not of required type?
         if ((pe != null) ||
               ((requiredType != null) &&
               (requiredType.isArray() ||
               !requiredType.isAssignableFrom(convertedValue.getClass())))) {
            if (requiredType != null) {
               if (pe == null) {
                  // No custom editor -> check BeanWrapperImpl's default editors.
                  pe = (PropertyEditor) this.defaultEditors.get(requiredType);

                  if (pe == null) {
                     // No BeanWrapper default editor -> check standard JavaBean editors.
                     pe = PropertyEditorManager.findEditor(requiredType);
                  }
               }
            }

            if ((pe != null) && !(convertedValue instanceof String)) {
               // Not a String -> use PropertyEditor's setValue.
               // With standard PropertyEditors, this will return the very same object;
               // we just want to allow special PropertyEditors to override setValue
               // for type conversion from non-String values to the required type.
               try {
                  // MMR: this should cause thread-safe problems
                  Object newConvertedValue = null;

                  synchronized (pe) {
                     pe.setValue(convertedValue);
                     newConvertedValue = pe.getValue();
                  }

                  if (newConvertedValue != convertedValue) {
                     convertedValue = newConvertedValue;

                     // Reset PropertyEditor: It already did a proper conversion.
                     // Don't use it again for a setAsText call.
                     pe = null;
                  }
               } catch (IllegalArgumentException ex) {
                  throw new TypeMismatchException(createPropertyChangeEvent(
                        fullPropertyName, oldValue, newValue), requiredType, ex);
               }
            }

            if ((requiredType != null) && !requiredType.isArray() &&
                  convertedValue instanceof String[]) {
               // Convert String array to a comma-separated String.
               // Only applies if no PropertyEditor converted the String array before.
               // The CSV String will be passed into a PropertyEditor's setAsText method, if any.
               if (logger.isDebugEnabled()) {
                  logger.debug(
                     "Converting String array to comma-delimited String [" +
                     convertedValue + "]");
               }

               convertedValue = StringUtils.arrayToCommaDelimitedString((String[]) convertedValue);
            }

            if ((pe != null) && convertedValue instanceof String) {
               // Use PropertyEditor's setAsText in case of a String value.
               if (logger.isDebugEnabled()) {
                  logger.debug("Converting String to [" + requiredType +
                     "] using property editor [" + pe + "]");
               }

               try {
                  // MMR: this should cause thread-safe problems
                  synchronized (pe) {
                     pe.setValue(oldValue);
                     pe.setAsText((String) convertedValue);
                     convertedValue = pe.getValue();
                  }
               } catch (IllegalArgumentException ex) {
                  throw new TypeMismatchException(createPropertyChangeEvent(
                        fullPropertyName, oldValue, newValue), requiredType, ex);
               }
            }

            if (requiredType != null) {
               // Array required -> apply appropriate conversion of elements.
               if (requiredType.isArray()) {
                  Class componentType = requiredType.getComponentType();

                  if (convertedValue instanceof Collection) {
                     // Convert Collection elements to array elements.
                     Collection coll = (Collection) convertedValue;
                     Object result = Array.newInstance(componentType,
                           coll.size());
                     int i = 0;

                     for (Iterator it = coll.iterator(); it.hasNext(); i++) {
                        Object value = doTypeConversionIfNecessary(propertyName,
                              propertyName + PROPERTY_KEY_PREFIX + i +
                              PROPERTY_KEY_SUFFIX, null, it.next(),
                              componentType);
                        Array.set(result, i, value);
                     }

                     return result;
                  } else if ((convertedValue != null) &&
                        convertedValue.getClass().isArray()) {
                     // Convert Collection elements to array elements.
                     int arrayLength = Array.getLength(convertedValue);
                     Object result = Array.newInstance(componentType,
                           arrayLength);

                     for (int i = 0; i < arrayLength; i++) {
                        Object value = doTypeConversionIfNecessary(propertyName,
                              propertyName + PROPERTY_KEY_PREFIX + i +
                              PROPERTY_KEY_SUFFIX, null,
                              Array.get(convertedValue, i), componentType);
                        Array.set(result, i, value);
                     }

                     return result;
                  } else {
                     // A plain value: convert it to an array with a single component.
                     Object result = Array.newInstance(componentType, 1);
                     Object value = doTypeConversionIfNecessary(propertyName,
                           propertyName + PROPERTY_KEY_PREFIX + 0 +
                           PROPERTY_KEY_SUFFIX, null, convertedValue,
                           componentType);
                     Array.set(result, 0, value);

                     return result;
                  }
               }

               // If the resulting value definitely doesn't match the required type,
               // try field lookup as fallback. If no matching field found,
               // throw explicit TypeMismatchException with full context information.
               if ((convertedValue != null) && !requiredType.isPrimitive() &&
                     !requiredType.isAssignableFrom(convertedValue.getClass())) {
                  // In case of String value, try to find matching field (for JDK 1.5
                  // enum or custom enum with values defined as static fields).
                  if (convertedValue instanceof String) {
                     try {
                        Field enumField = requiredType.getField((String) convertedValue);

                        return enumField.get(null);
                     } catch (Exception ex) {
                        logger.debug("Field [" + convertedValue +
                           "] isn't an enum value", ex);
                     }
                  }

                  // Definitely doesn't match: throw TypeMismatchException.
                  throw new TypeMismatchException(createPropertyChangeEvent(
                        fullPropertyName, oldValue, newValue), requiredType);
               }
            }
         }
      }

      return convertedValue;
   }

   /**
    * Documentaci�.
    *
    * @return PropertyDescriptor[]
    */
   public PropertyDescriptor[] getPropertyDescriptors() {
      return this.cachedIntrospectionResults.getBeanInfo()
                                            .getPropertyDescriptors();
   }

   /**
    * Documentaci�.
    *
    * @param String propertyName
    *
    * @return PropertyDescriptor
    *
    * @throws BeansException Documentaci�
    * @throws IllegalArgumentException Documentaci�
    * @throws InvalidPropertyException Documentaci�
    */
   public PropertyDescriptor getPropertyDescriptor(String propertyName)
      throws BeansException {
      if (propertyName == null) {
         throw new IllegalArgumentException(
            "Can't find property descriptor for <code>null</code> property");
      }

      PropertyDescriptor pd = getPropertyDescriptorInternal(propertyName);

      if (pd != null) {
         return pd;
      } else {
         throw new InvalidPropertyException(getRootClass(),
            this.nestedPath + propertyName,
            "No property '" + propertyName + "' found");
      }
   }

   /**
    * Versio interna de getPropertyDescriptor.
    *
    * @return PropertyDescriptor o null
    */
   protected PropertyDescriptor getPropertyDescriptorInternal(
      String propertyName) throws BeansException {
      Assert.state(this.object != null,
         "BeanWrapper does not hold a bean instance");

      BeanWrapperImpl nestedBw = getBeanWrapperForPropertyPath(propertyName);

      return nestedBw.cachedIntrospectionResults.getPropertyDescriptor(getFinalPath(
            nestedBw, propertyName));
   }

   /**
    * Documentaci�.
    *
    * @param String propertyName
    *
    * @return Class
    *
    * @throws BeansException
    */
   public Class getPropertyType(String propertyName) throws BeansException {
      try {
         PropertyDescriptor pd = getPropertyDescriptorInternal(propertyName);

         if (pd != null) {
            return pd.getPropertyType();
         } else {
            // Maybe an indexed/mapped property...
            Object value = getPropertyValue(propertyName);

            if (value != null) {
               return value.getClass();
            }

            // Check to see if there is a custom editor,
            // which might give an indication on the desired target type.
            if (this.customEditors != null) {
               CustomEditorHolder editorHolder = (CustomEditorHolder) this.customEditors.get(propertyName);

               if (editorHolder == null) {
                  List strippedPaths = new LinkedList();
                  addStrippedPropertyPaths(strippedPaths, "", propertyName);

                  for (Iterator it = strippedPaths.iterator();
                        it.hasNext() && (editorHolder == null);) {
                     String strippedName = (String) it.next();
                     editorHolder = (CustomEditorHolder) this.customEditors.get(strippedName);
                  }
               }

               if (editorHolder != null) {
                  return editorHolder.getRegisteredType();
               }
            }
         }
      } catch (InvalidPropertyException ex) {
         // Consider as not determinable.
      }

      return null;
   }

   /**
    * Documentaci�.
    *
    * @param String propertyName
    *
    * @return boolean
    */
   public boolean isReadableProperty(String propertyName) {
      // This is a programming error, although asking for a property
      // that doesn't exist is not.
      if (propertyName == null) {
         throw new IllegalArgumentException(
            "Can't find readability status for <code>null</code> property");
      }

      try {
         PropertyDescriptor pd = getPropertyDescriptorInternal(propertyName);

         if (pd != null) {
            if (pd.getReadMethod() != null) {
               return true;
            }
         } else {
            // maybe an indexed/mapped property
            getPropertyValue(propertyName);

            return true;
         }
      } catch (InvalidPropertyException ex) {
         // cannot be evaluated, so can't be readable
      }

      return false;
   }

   /**
    * Documentaci�.
    *
    * @param String propertyName
    *
    * @return boolean
    */
   public boolean isWritableProperty(String propertyName) {
      // This is a programming error, although asking for a property
      // that doesn't exist is not.
      if (propertyName == null) {
         throw new IllegalArgumentException(
            "Can't find writability status for <code>null</code> property");
      }

      try {
         PropertyDescriptor pd = getPropertyDescriptorInternal(propertyName);

         if (pd != null) {
            if (pd.getWriteMethod() != null) {
               return true;
            }
         } else {
            // maybe an indexed/mapped property
            getPropertyValue(propertyName);

            return true;
         }
      } catch (InvalidPropertyException ex) {
         // cannot be evaluated, so can't be writable
      }

      return false;
   }

   //---------------------------------------------------------------------
   /**
    * Documentaci�.
    *
    * @return String
    */
   public String toString() {
      StringBuffer sb = new StringBuffer("BeanWrapperImpl: wrapping class [");
      sb.append(getWrappedClass().getName()).append("]");

      return sb.toString();
   }

   /**
    * @return Map
    */
   public Map getBindProperties() {
      return bindProperties;
   }

   /**
    * @param Map bindProperties
    */
   public void setBindProperties(Map bindProperties) {
      this.bindProperties = bindProperties;
   }

   // EVC: added to allow actionForm.expose with customEditors.
   /**
    * Documentaci�.
    *
    * @return Map
    */
   public Map getCustomEditors() {
      return customEditors;
   }

   /**
    * Documentaci�.
    *
    * @param Map customEditors
    */
   public void setCustomEditors(Map customEditors) {
      this.customEditors = customEditors;
   }

   /**
    * Documentaci�.
    *
    * @return boolean
    */
   public boolean isExtractOldValueForEditor() {
      // TODO Auto-generated method stub
      return false;
   }

   /**
    * Documentaci�.
    *
    * @param PropertyValues arg0
    * @param boolean arg1
    * @param boolean arg2
    *
    * @throws BeansException
    */
   public void setPropertyValues(PropertyValues pvs, boolean ignoreUnknown,
      boolean ignoreInvalid) throws BeansException {
      List propertyAccessExceptions = null;
      List propertyValues = ((pvs instanceof MutablePropertyValues)
         ? ((MutablePropertyValues) pvs).getPropertyValueList()
         : Arrays.asList(pvs.getPropertyValues()));

      for (Iterator it = propertyValues.iterator(); it.hasNext();) {
         PropertyValue pv = (PropertyValue) it.next();

         try {
            // This method may throw any BeansException, which won't be caught
            // here, if there is a critical failure such as no matching field.
            // We can attempt to deal only with less serious exceptions.
            setPropertyValue(pv);
         } catch (NotWritablePropertyException ex) {
            if (!ignoreUnknown) {
               throw ex;
            }

            // Otherwise, just ignore it and continue...
         } catch (NullValueInNestedPathException ex) {
            if (!ignoreInvalid) {
               throw ex;
            }

            // Otherwise, just ignore it and continue...
         } catch (PropertyAccessException ex) {
            if (propertyAccessExceptions == null) {
               propertyAccessExceptions = new LinkedList();
            }

            propertyAccessExceptions.add(ex);
         }
      }

      // If we encountered individual exceptions, throw the composite exception.
      if (propertyAccessExceptions != null) {
         PropertyAccessException[] paeArray = (PropertyAccessException[]) propertyAccessExceptions.toArray(new PropertyAccessException[propertyAccessExceptions.size()]);
         throw new PropertyBatchUpdateException(paeArray);
      }
   }

   /**
    * Documentaci�.
    *
    * @param Object arg0
    * @param Class arg1
    *
    * @return Object
    *
    * @throws TypeMismatchException
    */
   public Object convertIfNecessary(Object arg0, Class arg1)
      throws TypeMismatchException {
      // TODO Auto-generated method stub
      return null;
   }

   /**
    * Documentaci�.
    *
    * @param Object arg0
    * @param Class arg1
    * @param MethodParameter arg2
    *
    * @return Object
    *
    * @throws TypeMismatchException
    */
   public Object convertIfNecessary(Object arg0, Class arg1,
      MethodParameter arg2) throws TypeMismatchException {
      // TODO Auto-generated method stub
      return null;
   }

   /**
    * Holder for a registered custom editor with property name.
    * Keeps the PropertyEditor itself plus the type it was registered for.
    */
   private static class CustomEditorHolder {
      /**
       * Documentaci�.
       */
      private final Class registeredType;

      /**
       * Documentaci�.
       */
      private final PropertyEditor propertyEditor;

      /**
       * Crea un nou objecte CustomEditorHolder.
       *
       * @param PropertyEditorpropertyEditor
       * @param Class registeredType
       */
      private CustomEditorHolder(PropertyEditor propertyEditor,
         Class registeredType) {
         this.propertyEditor = propertyEditor;
         this.registeredType = registeredType;
      }

      /**
       * Documentaci�.
       *
       * @return PropertyEditor
       */
      private PropertyEditor getPropertyEditor() {
         return propertyEditor;
      }

      /**
       * Documentaci�.
       *
       * @return Class
       */
      private Class getRegisteredType() {
         return registeredType;
      }

      /**
       * Documentaci�.
       *
       * @param Class requiredType
       *
       * @return PropertyEditor o null
       */
      private PropertyEditor getPropertyEditor(Class requiredType) {
         // Special case: If no required type specified, which usually only happens for
         // Collection elements, or required type is not assignable to registered type,
         // which usually only happens for generic properties of type Object -
         // then return PropertyEditor if not registered for Collection or array type.
         // (If not registered for Collection or array, it is assumed to be intended
         // for elements.)
         if ((this.registeredType == null) ||
               ((requiredType != null) &&
               (BeanUtils.isAssignable(this.registeredType, requiredType) ||
               BeanUtils.isAssignable(requiredType, this.registeredType))) ||
               ((requiredType == null) &&
               (!Collection.class.isAssignableFrom(this.registeredType) &&
               !this.registeredType.isArray()))) {
            return this.propertyEditor;
         } else {
            return null;
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @author XES
    * @version $Revision: 1.10 $
     */
   private static class PropertyTokenHolder {
      /**
       * Documentaci�.
       */
      private String actualName;

      /**
       * Documentaci�.
       */
      private String canonicalName;

      /**
       * Documentaci�.
       */
      private String[] keys;
   }
}
