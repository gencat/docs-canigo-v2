/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.i18n.spring.beans.propertyeditors;

import java.beans.PropertyEditorSupport;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Locale;
import java.util.Map;

import net.gencat.ctti.canigo.services.i18n.I18nService;

import org.springframework.util.StringUtils;


/**
 * Custom date editor
 * Depending on locale configured use
 * a different datePattern
 *
 * @author XES
 */
public class CustomDateEditor extends PropertyEditorSupport {
   /**
    * Documentaci�.
    */
   private static String DEFAULT_LOCALE = "es";

   /**
    * Documentaci�.
    */
   private I18nService i18nService;

   /**
    * Map of locales and datePatterns configured for locale
    */
   private Map localeDatePatternsMap;

   /**
    * Creates a new CustomDateEditor object.
    */
   public CustomDateEditor() {
      super();
   }

   /**
    * Creates a new CustomDateEditor object.
    *
    * @param source DOCUMENT ME.
    */
   public CustomDateEditor(Object source) {
      super(source);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private SimpleDateFormat getApplicableFormat() {
      Locale locale = i18nService.getCurrentLocale();

      if (locale != null) {
         String language = locale.getLanguage();

         // Search in map
         String datePattern = (String) localeDatePatternsMap.get(language);

         if (datePattern == null) {
            datePattern = (String) localeDatePatternsMap.get(DEFAULT_LOCALE);
         }

         if (datePattern != null) {
            return new SimpleDateFormat(datePattern);
         }
      }

      return null;
   }

   /**
    * Parse the Date from the given text, using the specified DateFormat.
    */
   public void setAsText(String text) throws IllegalArgumentException {
      if (!StringUtils.hasText(text)) {
         // Treat empty String as null value.
         setValue(null);
      } else {
         try {
            SimpleDateFormat sdf = getApplicableFormat();

            if (sdf != null) {
               setValue(sdf.parse(text));
            }
         } catch (ParseException ex) {
            throw new IllegalArgumentException("Could not parse date: " +
               ex.getMessage());
         }
      }
   }

   /**
    * Format the Date as String, using the specified DateFormat.
    */
   public String getAsText() {
      Date value = (Date) getValue();

      if (value == null) {
         return "";
      }

      SimpleDateFormat sdf = getApplicableFormat();

      if (sdf != null) {
         return sdf.format(value);
      }

      return "";
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getLocaleDatePatternsMap() {
      return localeDatePatternsMap;
   }

   /**
    * Documentaci�.
    *
    * @param localeDatePatternsMap Documentaci�
    */
   public void setLocaleDatePatternsMap(Map localeDatePatternsMap) {
      this.localeDatePatternsMap = localeDatePatternsMap;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Documentaci�.
    *
    * @param service Documentaci�
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }
}
