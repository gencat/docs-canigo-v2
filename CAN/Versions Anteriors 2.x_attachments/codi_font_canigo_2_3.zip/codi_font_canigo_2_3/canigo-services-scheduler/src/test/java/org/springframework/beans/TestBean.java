/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package org.springframework.beans;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.util.ObjectUtils;


/**
 * Simple test bean used for testing bean factories,
 * AOP framework etc.
 *
 * @author  Rod Johnson
 * @since 15 April 2001
 */
public class TestBean implements BeanNameAware, BeanFactoryAware, ITestBean,
   IOther, Comparable {
   /**
    * Documentaci�.
    */
   private BeanFactory beanFactory;

   /**
    * Documentaci�.
    */
   private Collection friends = new LinkedList();

   /**
    * Documentaci�.
    */
   private Date date = new Date();

   /**
    * Documentaci�.
    */
   private Float myFloat = new Float(0.0);

   /**
    * Documentaci�.
    */
   private INestedTestBean doctor = new NestedTestBean();

   /**
    * Documentaci�.
    */
   private INestedTestBean lawyer = new NestedTestBean();

   /**
    * Documentaci�.
    */
   private ITestBean spouse;

   /**
    * Documentaci�.
    */
   private IndexedTestBean nestedIndexedBean;

   /**
    * Documentaci�.
    */
   private Map someMap = new HashMap();

   /**
    * Documentaci�.
    */
   private Number someNumber;

   /**
    * Documentaci�.
    */
   private Set someSet = new HashSet();

   /**
    * Documentaci�.
    */
   private String beanName;

   /**
    * Documentaci�.
    */
   private String name;

   /**
    * Documentaci�.
    */
   private String touchy;

   /**
    * Documentaci�.
    */
   private String[] stringArray;

   /**
    * Documentaci�.
    */
   private boolean destroyed = false;

   /**
    * Documentaci�.
    */
   private boolean postProcessed;

   /**
    * Documentaci�.
    */
   private int age;

   /**
    * Creates a new TestBean object.
    */
   public TestBean() {
   }

   /**
    * Creates a new TestBean object.
    *
    * @param name DOCUMENT ME.
    * @param age DOCUMENT ME.
    */
   public TestBean(String name, int age) {
      this.name = name;
      this.age = age;
   }

   /**
    * Documentaci�.
    *
    * @param beanName Documentaci�
    */
   public void setBeanName(String beanName) {
      this.beanName = beanName;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getBeanName() {
      return beanName;
   }

   /**
    * Documentaci�.
    *
    * @param beanFactory Documentaci�
    */
   public void setBeanFactory(BeanFactory beanFactory) {
      this.beanFactory = beanFactory;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public BeanFactory getBeanFactory() {
      return beanFactory;
   }

   /**
    * Documentaci�.
    *
    * @param postProcessed Documentaci�
    */
   public void setPostProcessed(boolean postProcessed) {
      this.postProcessed = postProcessed;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isPostProcessed() {
      return postProcessed;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getName() {
      return name;
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    */
   public void setName(String name) {
      this.name = name;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getAge() {
      return age;
   }

   /**
    * Documentaci�.
    *
    * @param age Documentaci�
    */
   public void setAge(int age) {
      this.age = age;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ITestBean getSpouse() {
      return spouse;
   }

   /**
    * Documentaci�.
    *
    * @param spouse Documentaci�
    */
   public void setSpouse(ITestBean spouse) {
      this.spouse = spouse;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getTouchy() {
      return touchy;
   }

   /**
    * Documentaci�.
    *
    * @param touchy Documentaci�
    *
    * @throws Exception Documentaci�
    * @throws NumberFormatException Documentaci�
    */
   public void setTouchy(String touchy) throws Exception {
      if (touchy.indexOf('.') != -1) {
         throw new Exception("Can't contain a .");
      }

      if (touchy.indexOf(',') != -1) {
         throw new NumberFormatException(
            "Number format exception: contains a ,");
      }

      this.touchy = touchy;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String[] getStringArray() {
      return stringArray;
   }

   /**
    * Documentaci�.
    *
    * @param stringArray Documentaci�
    */
   public void setStringArray(String[] stringArray) {
      this.stringArray = stringArray;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Date getDate() {
      return date;
   }

   /**
    * Documentaci�.
    *
    * @param date Documentaci�
    */
   public void setDate(Date date) {
      this.date = date;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Float getMyFloat() {
      return myFloat;
   }

   /**
    * Documentaci�.
    *
    * @param myFloat Documentaci�
    */
   public void setMyFloat(Float myFloat) {
      this.myFloat = myFloat;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Collection getFriends() {
      return friends;
   }

   /**
    * Documentaci�.
    *
    * @param friends Documentaci�
    */
   public void setFriends(Collection friends) {
      this.friends = friends;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Set getSomeSet() {
      return someSet;
   }

   /**
    * Documentaci�.
    *
    * @param someSet Documentaci�
    */
   public void setSomeSet(Set someSet) {
      this.someSet = someSet;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getSomeMap() {
      return someMap;
   }

   /**
    * Documentaci�.
    *
    * @param someMap Documentaci�
    */
   public void setSomeMap(Map someMap) {
      this.someMap = someMap;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public INestedTestBean getDoctor() {
      return doctor;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public INestedTestBean getLawyer() {
      return lawyer;
   }

   /**
    * Documentaci�.
    *
    * @param bean Documentaci�
    */
   public void setDoctor(INestedTestBean bean) {
      doctor = bean;
   }

   /**
    * Documentaci�.
    *
    * @param bean Documentaci�
    */
   public void setLawyer(INestedTestBean bean) {
      lawyer = bean;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Number getSomeNumber() {
      return someNumber;
   }

   /**
    * Documentaci�.
    *
    * @param someNumber Documentaci�
    */
   public void setSomeNumber(Number someNumber) {
      this.someNumber = someNumber;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public IndexedTestBean getNestedIndexedBean() {
      return nestedIndexedBean;
   }

   /**
    * Documentaci�.
    *
    * @param nestedIndexedBean Documentaci�
    */
   public void setNestedIndexedBean(IndexedTestBean nestedIndexedBean) {
      this.nestedIndexedBean = nestedIndexedBean;
   }

   /**
    * @see ITestBean#exceptional(Throwable)
    */
   public void exceptional(Throwable t) throws Throwable {
      if (t != null) {
         throw t;
      }
   }

   /**
    * @see ITestBean#returnsThis()
    */
   public Object returnsThis() {
      return this;
   }

   /**
    * @see IOther#absquatulate()
    */
   public void absquatulate() {
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int haveBirthday() {
      return age++;
   }

   /**
    * Documentaci�.
    */
   public void destroy() {
      this.destroyed = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean wasDestroyed() {
      return destroyed;
   }

   /**
    * Documentaci�.
    *
    * @param other Documentaci�
    *
    * @return Documentaci�
    */
   public boolean equals(Object other) {
      if (this == other) {
         return true;
      }

      if ((other == null) || !(other instanceof TestBean)) {
         return false;
      }

      TestBean tb2 = (TestBean) other;

      return (ObjectUtils.nullSafeEquals(this.name, tb2.name) &&
      (this.age == tb2.age));
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int hashCode() {
      return this.age;
   }

   /**
    * Documentaci�.
    *
    * @param other Documentaci�
    *
    * @return Documentaci�
    */
   public int compareTo(Object other) {
      if ((this.name != null) && other instanceof TestBean) {
         return this.name.compareTo(((TestBean) other).getName());
      } else {
         return 1;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String toString() {
      String s = "name=" + name + "; age=" + age + "; touchy=" + touchy;
      s += ("; spouse={" + ((spouse != null) ? spouse.getName() : null) + "}");

      return s;
   }
}
