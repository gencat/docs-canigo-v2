/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.scheduler.test;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.scheduler.CronTriggerIF;
import net.gencat.ctti.canigo.services.scheduler.JobDetailIF;
import net.gencat.ctti.canigo.services.scheduler.MethodInvokingJobDetailFactoryBeanIF;
import net.gencat.ctti.canigo.services.scheduler.SchedulerFactoryBeanIF;
import net.gencat.ctti.canigo.services.scheduler.SimpleTriggerIF;
import net.gencat.ctti.canigo.services.scheduler.TriggerIF;
import net.gencat.ctti.canigo.services.scheduler.impl.quartz.SpringQuartzCronTriggerBean;
import net.gencat.ctti.canigo.services.scheduler.impl.quartz.SpringQuartzJobDetailBean;
import net.gencat.ctti.canigo.services.scheduler.impl.quartz.SpringQuartzMethodInvokingJobDetailFactoryBean;
import net.gencat.ctti.canigo.services.scheduler.impl.quartz.SpringQuartzSchedulerFactoryBean;
import net.gencat.ctti.canigo.services.scheduler.impl.quartz.SpringQuartzSimpleTriggerBean;
import net.gencat.ctti.canigo.services.scheduler.impl.quartz.SpringQuartzTrigger;

import org.easymock.MockControl;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobListener;
import org.quartz.Scheduler;
import org.quartz.SchedulerContext;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SchedulerListener;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.quartz.TriggerListener;
import org.springframework.beans.TestBean;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.StaticApplicationContext;


/**
 * ECG: Redefine de test-cases 4 canigo service Scheduler
 *
 * @author Juergen Hoeller
 * @author Alef Arendsen
 * @author Rob Harrop
 * @since 20.02.2004
 */
public class SchedulerServiceTest extends TestCase {
   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testSchedulerFactoryBeanIF() throws Exception {
      doTestSchedulerFactoryBeanIF(false);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testSchedulerFactoryBeanIFWithExplicitJobDetailIF()
      throws Exception {
      doTestSchedulerFactoryBeanIF(true);
   }

   /**
    * Documentaci�.
    *
    * @param explicitJobDetail Documentaci�
    *
    * @throws Exception Documentaci�
    */
   private void doTestSchedulerFactoryBeanIF(boolean explicitJobDetail)
      throws Exception {
      TestBean tb = new TestBean("tb", 99);
      JobDetailIF jobDetail0 = new SpringQuartzJobDetailBean();
      jobDetail0.setJobClass(Job.class);
      jobDetail0.setBeanName("myJob0");

      Map jobData = new HashMap();
      jobData.put("testBean", tb);
      jobDetail0.setJobDataAsMap(jobData);
      jobDetail0.afterPropertiesSet();
      assertEquals(tb,
         ((SpringQuartzJobDetailBean) jobDetail0).getJobDataMap().get("testBean"));

      CronTriggerIF trigger0 = new SpringQuartzCronTriggerBean();
      trigger0.setBeanName("myTrigger0");
      trigger0.setJobDetail(jobDetail0);
      trigger0.setCronExpression("0/1 * * * * ?");
      trigger0.afterPropertiesSet();

      TestMethodInvokingTask task1 = new TestMethodInvokingTask();
      MethodInvokingJobDetailFactoryBeanIF mijdfb = new SpringQuartzMethodInvokingJobDetailFactoryBean();
      mijdfb.setBeanName("myJob1");
      mijdfb.setTargetObject(task1);
      mijdfb.setTargetMethod("doSomething");
      mijdfb.afterPropertiesSet();

      JobDetailIF jobDetail1 = (JobDetailIF) mijdfb.getObject();

      SimpleTriggerIF trigger1 = new SpringQuartzSimpleTriggerBean();
      trigger1.setBeanName("myTrigger1");
      trigger1.setJobDetail(jobDetail1);
      trigger1.setStartDelay(0);
      trigger1.setRepeatInterval(20);
      trigger1.afterPropertiesSet();

      // Create the mock control
      MockControl schedulerControl = MockControl.createControl(Scheduler.class);
      final Scheduler scheduler = (Scheduler) schedulerControl.getMock();
      SchedulerFactoryBeanIF schedulerFactoryBean = new SpringQuartzSchedulerFactoryBean() {
            protected Scheduler createScheduler(
               SchedulerFactory schedulerFactory, String schedulerName) {
               return scheduler;
            }
         };

      StaticApplicationContext ac = new StaticApplicationContext();
      SchedulerContext schedulerContext = new SchedulerContext();

      scheduler.getContext();
      schedulerControl.setReturnValue(schedulerContext, 4);

      scheduler.getJobDetail("myJob0", Scheduler.DEFAULT_GROUP);
      schedulerControl.setReturnValue(null);
      scheduler.getJobDetail("myJob1", Scheduler.DEFAULT_GROUP);
      schedulerControl.setReturnValue(null);
      scheduler.getTrigger("myTrigger0", Scheduler.DEFAULT_GROUP);
      schedulerControl.setReturnValue(null);
      scheduler.getTrigger("myTrigger1", Scheduler.DEFAULT_GROUP);
      schedulerControl.setReturnValue(null);
      scheduler.addJob((SpringQuartzJobDetailBean) jobDetail0, true);
      schedulerControl.setVoidCallable();
      scheduler.scheduleJob((Trigger) trigger0);
      schedulerControl.setReturnValue(new Date());
      scheduler.addJob((SpringQuartzJobDetailBean) jobDetail1, true);
      schedulerControl.setVoidCallable();
      scheduler.scheduleJob((Trigger) trigger1);
      schedulerControl.setReturnValue(new Date());
      scheduler.start();
      schedulerControl.setVoidCallable();
      scheduler.shutdown(false);
      schedulerControl.setVoidCallable();
      schedulerControl.replay();

      Map schedulerContextMap = new HashMap();
      schedulerContextMap.put("testBean", tb);
      schedulerFactoryBean.setSchedulerContextAsMap(schedulerContextMap);
      schedulerFactoryBean.setApplicationContext(ac);
      schedulerFactoryBean.setApplicationContextSchedulerContextKey("appCtx");

      //		if (explicitJobDetail) {
      schedulerFactoryBean.setJobDetails(new JobDetailIF[] {
            (JobDetailIF) jobDetail0, (JobDetailIF) jobDetail1
         });
      //		}
      schedulerFactoryBean.setTriggers(new TriggerIF[] {
            (SpringQuartzTrigger) trigger0, (SpringQuartzTrigger) trigger1
         });

      try {
         schedulerFactoryBean.afterPropertiesSet();

         Scheduler returnedScheduler = (Scheduler) schedulerFactoryBean.getObject();
         assertEquals(tb, returnedScheduler.getContext().get("testBean"));
         assertEquals(ac, returnedScheduler.getContext().get("appCtx"));
      } finally {
         schedulerFactoryBean.destroy();
      }

      schedulerControl.verify();
   }

   //	public void testSchedulerFactoryBeanIFWithListeners() throws Exception {
   /**
    * Documentaci�.
    *
    * @param concurrent Documentaci�
    *
    * @throws Exception Documentaci�
    */
   private void methodInvokingConcurrency(boolean concurrent)
      throws Exception {
      // Test the concurrency flag.
      // Method invoking job with two triggers.
      // If the concurrent flag is false, the triggers are NOT allowed
      // to interfere with each other.
      TestMethodInvokingTask task1 = new TestMethodInvokingTask();
      MethodInvokingJobDetailFactoryBeanIF mijdfb = new SpringQuartzMethodInvokingJobDetailFactoryBean();
      // set the concurrency flag!
      mijdfb.setConcurrent(concurrent);
      mijdfb.setBeanName("myJob1");
      mijdfb.setTargetObject(task1);
      mijdfb.setTargetMethod("doWait");
      mijdfb.afterPropertiesSet();

      JobDetailIF jobDetail1 = (JobDetailIF) mijdfb.getObject();

      SimpleTriggerIF trigger0 = new SpringQuartzSimpleTriggerBean();
      trigger0.setBeanName("myTrigger1");
      trigger0.setJobDetail(jobDetail1);
      trigger0.setStartDelay(0);
      trigger0.setRepeatInterval(1);
      trigger0.setRepeatCount(1);
      trigger0.afterPropertiesSet();

      SimpleTriggerIF trigger1 = new SpringQuartzSimpleTriggerBean();
      trigger1.setBeanName("myTrigger1");
      trigger1.setJobDetail(jobDetail1);
      trigger1.setStartDelay(1000L);
      trigger1.setRepeatInterval(1);
      trigger1.setRepeatCount(1);
      trigger1.afterPropertiesSet();

      SchedulerFactoryBeanIF schedulerFactoryBean = new SpringQuartzSchedulerFactoryBean();
      schedulerFactoryBean.setJobDetails(new JobDetailIF[] { jobDetail1 });
      schedulerFactoryBean.setTriggers(new TriggerIF[] {
            (SpringQuartzTrigger) trigger1, (SpringQuartzTrigger) trigger0
         });
      schedulerFactoryBean.afterPropertiesSet();

      // ok scheduler is set up... let's wait for like 4 seconds
      try {
         Thread.sleep(4000);
      } catch (InterruptedException ex) {
         // fall through
      }

      if (concurrent) {
         assertEquals(2, task1.counter);
         task1.stop();

         // we're done, both jobs have ran, let's call it a day
         return;
      } else {
         assertEquals(1, task1.counter);
         task1.stop();

         // we need to check whether or not the test succeed with non-concurrent jobs
      }

      try {
         Thread.sleep(4000);
      } catch (InterruptedException ex) {
         // fall through
      }

      task1.stop();
      assertEquals(2, task1.counter);

      // Although we're destroying the scheduler, it does seem to keep things in memory:
      // When executing both tests (concurrent and non-concurrent), the second test always
      // fails.
      schedulerFactoryBean.destroy();
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testSchedulerFactoryBeanIFWithPlainQuartzObjects()
      throws Exception {
      TestBean tb = new TestBean("tb", 99);
      JobDetailIF jobDetail0 = new SpringQuartzJobDetailBean();
      jobDetail0.setJobClass(Job.class);
      jobDetail0.setName("myJob0");
      jobDetail0.setGroup(Scheduler.DEFAULT_GROUP);
      ((SpringQuartzJobDetailBean) jobDetail0).getJobDataMap()
       .put("testBean", tb);
      assertEquals(tb,
         ((SpringQuartzJobDetailBean) jobDetail0).getJobDataMap().get("testBean"));

      CronTriggerIF trigger0 = new SpringQuartzCronTriggerBean();
      trigger0.setName("myTrigger0");
      trigger0.setGroup(Scheduler.DEFAULT_GROUP);
      trigger0.setJobName("myJob0");
      trigger0.setJobGroup(Scheduler.DEFAULT_GROUP);
      trigger0.setStartTime(new Date());
      trigger0.setCronExpression("0/1 * * * * ?");

      TestMethodInvokingTask task1 = new TestMethodInvokingTask();
      MethodInvokingJobDetailFactoryBeanIF mijdfb = new SpringQuartzMethodInvokingJobDetailFactoryBean();
      mijdfb.setName("myJob1");
      mijdfb.setGroup(Scheduler.DEFAULT_GROUP);
      mijdfb.setTargetObject(task1);
      mijdfb.setTargetMethod("doSomething");
      mijdfb.afterPropertiesSet();

      JobDetailIF jobDetail1 = (JobDetailIF) mijdfb.getObject();

      SimpleTriggerIF trigger1 = new SpringQuartzSimpleTriggerBean();
      trigger1.setName("myTrigger1");
      trigger1.setGroup(Scheduler.DEFAULT_GROUP);
      trigger1.setJobName("myJob1");
      trigger1.setJobGroup(Scheduler.DEFAULT_GROUP);
      trigger1.setStartTime(new Date());
      trigger1.setRepeatCount(SimpleTrigger.REPEAT_INDEFINITELY);
      trigger1.setRepeatInterval(20);

      MockControl schedulerControl = MockControl.createControl(Scheduler.class);
      final Scheduler scheduler = (Scheduler) schedulerControl.getMock();
      scheduler.getJobDetail("myJob0", Scheduler.DEFAULT_GROUP);
      schedulerControl.setReturnValue(null);
      scheduler.getJobDetail("myJob1", Scheduler.DEFAULT_GROUP);
      schedulerControl.setReturnValue(null);
      scheduler.getTrigger("myTrigger0", Scheduler.DEFAULT_GROUP);
      schedulerControl.setReturnValue(null);
      scheduler.getTrigger("myTrigger1", Scheduler.DEFAULT_GROUP);
      schedulerControl.setReturnValue(null);
      scheduler.addJob((SpringQuartzJobDetailBean) jobDetail0, true);
      schedulerControl.setVoidCallable();
      scheduler.addJob((SpringQuartzJobDetailBean) jobDetail1, true);
      schedulerControl.setVoidCallable();
      scheduler.scheduleJob((SpringQuartzTrigger) trigger0);
      schedulerControl.setReturnValue(new Date());
      scheduler.scheduleJob((SpringQuartzTrigger) trigger1);
      schedulerControl.setReturnValue(new Date());
      scheduler.start();
      schedulerControl.setVoidCallable();
      scheduler.shutdown(false);
      schedulerControl.setVoidCallable();
      schedulerControl.replay();

      SchedulerFactoryBeanIF schedulerFactoryBean = new SpringQuartzSchedulerFactoryBean() {
            protected Scheduler createScheduler(
               SchedulerFactory schedulerFactory, String schedulerName) {
               return scheduler;
            }
         };

      schedulerFactoryBean.setJobDetails(new JobDetailIF[] {
            jobDetail0, jobDetail1
         });
      schedulerFactoryBean.setTriggers(new TriggerIF[] { trigger0, trigger1 });

      try {
         schedulerFactoryBean.afterPropertiesSet();
      } finally {
         schedulerFactoryBean.destroy();
      }

      schedulerControl.verify();
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testSchedulerFactoryBeanIFWithApplicationContext()
      throws Exception {
      TestBean tb = new TestBean("tb", 99);
      StaticApplicationContext ac = new StaticApplicationContext();

      MockControl schedulerControl = MockControl.createControl(Scheduler.class);
      final Scheduler scheduler = (Scheduler) schedulerControl.getMock();

      SchedulerFactoryBeanIF schedulerFactoryBean = new SpringQuartzSchedulerFactoryBean() {
            protected Scheduler createScheduler(
               SchedulerFactory schedulerFactory, String schedulerName) {
               return scheduler;
            }
         };

      Map schedulerContextMap = new HashMap();
      schedulerContextMap.put("testBean", tb);
      schedulerFactoryBean.setSchedulerContextAsMap(schedulerContextMap);
      schedulerFactoryBean.setApplicationContext(ac);
      schedulerFactoryBean.setApplicationContextSchedulerContextKey("appCtx");

      SchedulerContext schedulerContext = new SchedulerContext();

      scheduler.getContext();
      schedulerControl.setReturnValue(schedulerContext, 4);
      scheduler.start();
      schedulerControl.setVoidCallable();
      scheduler.shutdown(false);
      schedulerControl.setVoidCallable();
      schedulerControl.replay();

      try {
         schedulerFactoryBean.afterPropertiesSet();

         Scheduler returnedScheduler = (Scheduler) schedulerFactoryBean.getObject();
         assertEquals(tb, returnedScheduler.getContext().get("testBean"));
         assertEquals(ac, returnedScheduler.getContext().get("appCtx"));
      } finally {
         schedulerFactoryBean.destroy();
      }

      schedulerControl.verify();
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testJobDetailIFWithApplicationContext()
      throws Exception {
      TestBean tb = new TestBean("tb", 99);
      StaticApplicationContext ac = new StaticApplicationContext();

      JobDetailIF jobDetail = new SpringQuartzJobDetailBean();
      jobDetail.setJobClass(Job.class);
      jobDetail.setBeanName("myJob0");

      Map jobData = new HashMap();
      jobData.put("testBean", tb);
      jobDetail.setJobDataAsMap(jobData);
      jobDetail.setApplicationContext(ac);
      jobDetail.setApplicationContextJobDataKey("appCtx");
      jobDetail.afterPropertiesSet();

      assertEquals(tb,
         ((SpringQuartzJobDetailBean) jobDetail).getJobDataMap().get("testBean"));
      assertEquals(ac,
         ((SpringQuartzJobDetailBean) jobDetail).getJobDataMap().get("appCtx"));
   }

   /**
    * Documentaci�.
    */
   public void testJobDetailIFWithListenerNames() {
      JobDetailIF jobDetail = new SpringQuartzJobDetailBean();
      String[] names = new String[] { "test1", "test2" };
      jobDetail.setJobListenerNames(names);

      List result = Arrays.asList(jobDetail.getJobListenerNames());
      assertEquals(Arrays.asList(names), result);
   }

   /**
    * Documentaci�.
    */
   public void testCronTriggerIFWithListenerNames() {
      CronTriggerIF trigger = new SpringQuartzCronTriggerBean();
      String[] names = new String[] { "test1", "test2" };
      trigger.setTriggerListenerNames(names);

      List result = Arrays.asList(trigger.getTriggerListenerNames());
      assertEquals(Arrays.asList(names), result);
   }

   /**
    * Documentaci�.
    */
   public void testSimpleTriggerIFWithListenerNames() {
      SimpleTriggerIF trigger = new SpringQuartzSimpleTriggerBean();
      String[] names = new String[] { "test1", "test2" };
      trigger.setTriggerListenerNames(names);

      List result = Arrays.asList(trigger.getTriggerListenerNames());
      assertEquals(Arrays.asList(names), result);
   }

   /**
    * Documentaci�.
    *
    * @throws InterruptedException Documentaci�
    */
   public void testWithTwoAnonymousMethodInvokingJobDetailFactoryBeanIFs()
      throws InterruptedException {
      ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(
            "applicationContext.xml");
      Thread.sleep(3000);

      try {
         TaskWriteLog taskWriteLog = (TaskWriteLog) ctx.getBean("taskWriteLog");
         TaskWriteLog taskWriteLog2 = (TaskWriteLog) ctx.getBean("taskWriteLog");

         assertEquals("getLog called TestTaskWriteLog", "Doing log at: NOW",
            taskWriteLog.getLog());
         assertEquals("getLog called TestTaskWriteLog2", "Doing log at: NOW",
            taskWriteLog2.getLog());
      } finally {
         ctx.close();
      }
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   private static class TestJobListener implements JobListener {
      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getName() {
         return null;
      }

      /**
       * Documentaci�.
       *
       * @param context Documentaci�
       */
      public void jobToBeExecuted(JobExecutionContext context) {
      }

      /**
       * Documentaci�.
       *
       * @param context Documentaci�
       */
      public void jobExecutionVetoed(JobExecutionContext context) {
      }

      /**
       * Documentaci�.
       *
       * @param context Documentaci�
       * @param jobException Documentaci�
       */
      public void jobWasExecuted(JobExecutionContext context,
         JobExecutionException jobException) {
      }
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   private static class TestSchedulerListener implements SchedulerListener {
      /**
       * Documentaci�.
       *
       * @param trigger Documentaci�
       */
      public void jobScheduled(Trigger trigger) {
      }

      /**
       * Documentaci�.
       *
       * @param triggerName Documentaci�
       * @param triggerGroup Documentaci�
       */
      public void jobUnscheduled(String triggerName, String triggerGroup) {
      }

      /**
       * Documentaci�.
       *
       * @param trigger Documentaci�
       */
      public void triggerFinalized(Trigger trigger) {
      }

      /**
       * Documentaci�.
       *
       * @param triggerName Documentaci�
       * @param triggerGroup Documentaci�
       */
      public void triggersPaused(String triggerName, String triggerGroup) {
      }

      /**
       * Documentaci�.
       *
       * @param triggerName Documentaci�
       * @param triggerGroup Documentaci�
       */
      public void triggersResumed(String triggerName, String triggerGroup) {
      }

      /**
       * Documentaci�.
       *
       * @param jobName Documentaci�
       * @param jobGroup Documentaci�
       */
      public void jobsPaused(String jobName, String jobGroup) {
      }

      /**
       * Documentaci�.
       *
       * @param jobName Documentaci�
       * @param jobGroup Documentaci�
       */
      public void jobsResumed(String jobName, String jobGroup) {
      }

      /**
       * Documentaci�.
       *
       * @param msg Documentaci�
       * @param cause Documentaci�
       */
      public void schedulerError(String msg, SchedulerException cause) {
      }

      /**
       * Documentaci�.
       */
      public void schedulerShutdown() {
      }
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   private static class TestTriggerListener implements TriggerListener {
      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getName() {
         return null;
      }

      /**
       * Documentaci�.
       *
       * @param trigger Documentaci�
       * @param context Documentaci�
       */
      public void triggerFired(Trigger trigger, JobExecutionContext context) {
      }

      /**
       * Documentaci�.
       *
       * @param trigger Documentaci�
       * @param context Documentaci�
       *
       * @return Documentaci�
       */
      public boolean vetoJobExecution(Trigger trigger,
         JobExecutionContext context) {
         return false;
      }

      /**
       * Documentaci�.
       *
       * @param trigger Documentaci�
       */
      public void triggerMisfired(Trigger trigger) {
      }

      /**
       * Documentaci�.
       *
       * @param trigger Documentaci�
       * @param context Documentaci�
       * @param triggerInstructionCode Documentaci�
       */
      public void triggerComplete(Trigger trigger, JobExecutionContext context,
         int triggerInstructionCode) {
      }
   }
}
