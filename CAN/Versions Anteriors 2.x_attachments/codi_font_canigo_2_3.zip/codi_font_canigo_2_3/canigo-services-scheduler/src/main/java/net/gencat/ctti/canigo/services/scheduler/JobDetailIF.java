/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.scheduler;

import java.util.Map;

import net.gencat.ctti.canigo.services.scheduler.exception.SchedulerServiceException;

import org.springframework.context.ApplicationContext;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public interface JobDetailIF {
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getDelegate();

   /**
    * Documentaci�.
    */
   public void afterPropertiesSet();

   /**
    * Documentaci�.
    *
    * @param applicationContext Documentaci�
    */
   public void setApplicationContext(ApplicationContext applicationContext);

   /**
    * Documentaci�.
    *
    * @param applicationContextJobDataKey Documentaci�
    */
   public void setApplicationContextJobDataKey(
      String applicationContextJobDataKey);

   /**
    * Documentaci�.
    *
    * @param beanName Documentaci�
    */
   public void setBeanName(String beanName);

   /**
    * Documentaci�.
    *
    * @param jobDataAsMap Documentaci�
    */
   public void setJobDataAsMap(Map jobDataAsMap);

   /**
    * Documentaci�.
    *
    * @param names Documentaci�
    */
   public void setJobListenerNames(String[] names);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getName();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setName(String arg0);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getGroup();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setGroup(String arg0);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getFullName();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getDescription();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setDescription(String arg0);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Class getJobClass();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setJobClass(Class arg0);

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void validate() throws SchedulerServiceException;

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setVolatility(boolean arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setDurability(boolean arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setRequestsRecovery(boolean arg0);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isVolatile();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isDurable();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isStateful();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean requestsRecovery();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void addJobListener(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean removeJobListener(String arg0);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String[] getJobListenerNames();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String toString();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object clone();
}
