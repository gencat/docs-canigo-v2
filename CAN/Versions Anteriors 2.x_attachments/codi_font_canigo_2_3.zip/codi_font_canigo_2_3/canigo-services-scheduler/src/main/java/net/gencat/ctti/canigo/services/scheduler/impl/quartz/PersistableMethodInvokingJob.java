/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.scheduler.impl.quartz;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.BeansException;
import org.springframework.beans.support.ArgumentConvertingMethodInvoker;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.util.MethodInvoker;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class PersistableMethodInvokingJob extends QuartzJobBean
   implements ApplicationContextAware {
   /**
    * Documentaci�.
    */
   private ApplicationContext applicationContext;

   /**
    * Documentaci�.
    */
   private String targetBean;

   /**
    * Documentaci�.
    */
   private String targetMethod;

   /**
    * Documentaci�.
    */
   private Object[] arguments;

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    * @throws JobExecutionException Documentaci�
    */
   protected void executeInternal(JobExecutionContext context)
      throws JobExecutionException {
      Object bean = applicationContext.getBean(targetBean);

      MethodInvoker methodInvoker = new ArgumentConvertingMethodInvoker();
      methodInvoker.setTargetObject(bean);
      methodInvoker.setTargetMethod(targetMethod);
      methodInvoker.setArguments(arguments);

      try {
         methodInvoker.prepare();
         methodInvoker.invoke();
      } catch (Exception ex) {
         throw new JobExecutionException(
            "Could not execute scheduled bean job: " + targetBean, ex, false);
      }
   }

   /**
    * Documentaci�.
    *
    * @param applicationContext Documentaci�
    *
    * @throws BeansException Documentaci�
    */
   public void setApplicationContext(ApplicationContext applicationContext)
      throws BeansException {
      this.applicationContext = applicationContext;
   }

   /**
    * Documentaci�.
    *
    * @param arguments Documentaci�
    */
   public void setArguments(Object[] arguments) {
      this.arguments = arguments;
   }

   /**
    * Documentaci�.
    *
    * @param targetMethod Documentaci�
    */
   public void setTargetMethod(String targetMethod) {
      this.targetMethod = targetMethod;
   }

   /**
    * Documentaci�.
    *
    * @param targetBean Documentaci�
    */
   public void setTargetBean(String targetBean) {
      this.targetBean = targetBean;
   }
}
