/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.scheduler.impl.quartz;

import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class PersistableMethodInvokingJobDetailFactoryBean
   implements FactoryBean, BeanNameAware, InitializingBean {
   /**
    * Documentaci�.
    */
   private JobDetail jobDetail;

   /**
    * Documentaci�.
    */
   private String beanName;

   /**
    * Documentaci�.
    */
   private String group = Scheduler.DEFAULT_GROUP;

   /**
    * Documentaci�.
    */
   private String name;

   /**
    * Documentaci�.
    */
   private String targetMethod;

   /**
    * Documentaci�.
    */
   private String targetObject;

   /**
    * Documentaci�.
    */
   private Object[] arguments;

   /**
    * Documentaci�.
    */
   private boolean concurrent = true;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public Object getObject() throws Exception {
      return this.jobDetail;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Class getObjectType() {
      return (this.jobDetail != null) ? this.jobDetail.getClass()
                                      : JobDetail.class;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isSingleton() {
      return true;
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    */
   public void setBeanName(String name) {
      this.beanName = name;
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void afterPropertiesSet() throws Exception {
      // Use specific name if given, else fall back to bean name.
      String name = ((this.name != null) ? this.name : this.beanName);

      // Consider the concurrent flag to choose between stateful and stateless job.
      Class jobClass = (this.concurrent
         ? (Class) PersistableMethodInvokingJob.class
         : StatefulPersistableMethodInvokingJob.class);

      this.jobDetail = new JobDetail(name, this.group, jobClass);
      this.jobDetail.getJobDataMap().put("targetBean", targetObject);
      this.jobDetail.getJobDataMap().put("targetMethod", targetMethod);
      this.jobDetail.getJobDataMap().put("arguments", arguments);
      this.jobDetail.setVolatility(false);
   }

   /**
    * Documentaci�.
    *
    * @param concurrent Documentaci�
    */
   public void setConcurrent(boolean concurrent) {
      this.concurrent = concurrent;
   }

   /**
    * Documentaci�.
    *
    * @param group Documentaci�
    */
   public void setGroup(String group) {
      this.group = group;
   }

   /**
    * Documentaci�.
    *
    * @param jobDetail Documentaci�
    */
   public void setJobDetail(JobDetail jobDetail) {
      this.jobDetail = jobDetail;
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    */
   public void setName(String name) {
      this.name = name;
   }

   /**
    * Documentaci�.
    *
    * @param targetMethod Documentaci�
    */
   public void setTargetMethod(String targetMethod) {
      this.targetMethod = targetMethod;
   }

   /**
    * Documentaci�.
    *
    * @param targetObject Documentaci�
    */
   public void setTargetObject(String targetObject) {
      this.targetObject = targetObject;
   }

   /**
    * Documentaci�.
    *
    * @param arguments Documentaci�
    */
   public void setArguments(Object[] arguments) {
      this.arguments = arguments;
   }
}
