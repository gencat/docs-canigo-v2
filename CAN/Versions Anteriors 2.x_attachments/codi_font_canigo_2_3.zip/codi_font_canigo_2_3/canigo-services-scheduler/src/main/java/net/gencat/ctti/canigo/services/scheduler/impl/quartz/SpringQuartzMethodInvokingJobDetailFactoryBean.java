/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.scheduler.impl.quartz;

import java.util.Properties;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.scheduler.JobDetailIF;
import net.gencat.ctti.canigo.services.scheduler.MethodInvokingJobDetailFactoryBeanIF;
import net.gencat.ctti.canigo.services.scheduler.exception.SchedulerServiceException;

import org.quartz.JobDetail;
import org.springframework.beans.BeanUtils;
import org.springframework.scheduling.quartz.MethodInvokingJobDetailFactoryBean;


/**
 * FactoryBean that exposes a JobDetail object that delegates job execution
 * to a specified (static or non-static) method. Avoids the need to implement
 * a one-line Quartz Job that just invokes an existing service method.
 *
 * <p>Derived from MethodInvoker to share common properties and behavior
 * with MethodInvokingFactoryBean.
 *
 * <p>Supports both concurrently running jobs and non-currently running
 * ones through the "concurrent" property.
 *
 * <p><b>Note: JobDetails created via this FactoryBean are <i>not</i>
 * serializable and thus not suitable for persistent job stores.</b>
 * You need to implement your own Quartz Job as a thin wrapper for each case
 * where you want a persistent job to delegate to a specific service method.
 *
 * @author Juergen Hoeller
 * @author Alef Arendsen
 * @since 18.02.2004
 * @see #setTargetObject
 * @see #setTargetMethod
 * @see #setConcurrent
 * @see org.springframework.beans.factory.config.MethodInvokingFactoryBean
 */
public class SpringQuartzMethodInvokingJobDetailFactoryBean
   extends MethodInvokingJobDetailFactoryBean
   implements MethodInvokingJobDetailFactoryBeanIF {
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getObject() {
      JobDetail jobDetail = (JobDetail) super.getObject();
      JobDetailIF jobDetailBean = new SpringQuartzJobDetailBean();
      BeanUtils.copyProperties(jobDetail, jobDetailBean);

      return jobDetailBean;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Class getObjectType() {
      return (super.getObject() != null) ? super.getObject().getClass()
                                         : JobDetailIF.class;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public Object invoke() throws SchedulerServiceException {
      try {
         return super.invoke();
      } catch (Exception ex) {
         String[] args = { this.getClass().getName() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.scheduler.invoke",
               args, Layer.SERVICES, Subsystem.SCHEDULER_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SchedulerServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void prepare() throws SchedulerServiceException {
      try {
         super.prepare();
      } catch (Exception ex) {
         String[] args = { this.getClass().getName() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.scheduler.prepare",
               args, Layer.SERVICES, Subsystem.SCHEDULER_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SchedulerServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param staticMethod Documentaci�
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void setStaticMethod(String staticMethod)
      throws SchedulerServiceException {
      try {
         super.setStaticMethod(staticMethod);
      } catch (Exception ex) {
         String[] args = { this.getClass().getName() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.scheduler.setStaticMethod",
               args, Layer.SERVICES, Subsystem.SCHEDULER_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SchedulerServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void afterPropertiesSet() throws SchedulerServiceException {
      try {
         super.afterPropertiesSet();
      } catch (Exception ex) {
         String[] args = { this.getClass().getName() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.scheduler.afterPropertiesSet",
               args, Layer.SERVICES, Subsystem.SCHEDULER_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SchedulerServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getDelegate() {
      return this;
   }
}
