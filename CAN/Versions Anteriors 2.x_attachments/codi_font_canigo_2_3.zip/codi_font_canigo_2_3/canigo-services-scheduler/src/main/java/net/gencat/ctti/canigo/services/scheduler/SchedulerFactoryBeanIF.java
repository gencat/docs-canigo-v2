/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.scheduler;

import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import net.gencat.ctti.canigo.services.scheduler.exception.SchedulerServiceException;

import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.transaction.PlatformTransactionManager;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public interface SchedulerFactoryBeanIF {
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getDelegate();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getObject();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Class getObjectType();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isSingleton();

   /**
    * Documentaci�.
    *
    * @param applicationContext Documentaci�
    */
   public void setApplicationContext(ApplicationContext applicationContext);

   /**
    * Documentaci�.
    *
    * @param applicationContextSchedulerContextKey Documentaci�
    */
   public void setApplicationContextSchedulerContextKey(
      String applicationContextSchedulerContextKey);

   /**
    * Documentaci�.
    *
    * @param autoStartup Documentaci�
    */
   public void setAutoStartup(boolean autoStartup);

   /**
    * Documentaci�.
    *
    * @param calendars Documentaci�
    */
   public void setCalendars(Map calendars);

   /**
    * Documentaci�.
    *
    * @param configLocation Documentaci�
    */
   public void setConfigLocation(Resource configLocation);

   /**
    * Documentaci�.
    *
    * @param dataSource Documentaci�
    */
   public void setDataSource(DataSource dataSource);

   /**
    * Documentaci�.
    *
    * @param jobDetails Documentaci�
    */
   public void setJobDetails(JobDetailIF[] jobDetails);

   /**
    * Documentaci�.
    *
    * @param jobSchedulingDataLocation Documentaci�
    */
   public void setJobSchedulingDataLocation(String jobSchedulingDataLocation);

   /**
    * Documentaci�.
    *
    * @param jobSchedulingDataLocations Documentaci�
    */
   public void setJobSchedulingDataLocations(
      String[] jobSchedulingDataLocations);

   /**
    * Documentaci�.
    *
    * @param nonTransactionalDataSource Documentaci�
    */
   public void setNonTransactionalDataSource(
      DataSource nonTransactionalDataSource);

   /**
    * Documentaci�.
    *
    * @param overwriteExistingJobs Documentaci�
    */
   public void setOverwriteExistingJobs(boolean overwriteExistingJobs);

   /**
    * Documentaci�.
    *
    * @param quartzProperties Documentaci�
    */
   public void setQuartzProperties(Properties quartzProperties);

   /**
    * Documentaci�.
    *
    * @param schedulerContextAsMap Documentaci�
    */
   public void setSchedulerContextAsMap(Map schedulerContextAsMap);

   /**
    * Documentaci�.
    *
    * @param schedulerFactoryClass Documentaci�
    */
   public void setSchedulerFactoryClass(Class schedulerFactoryClass);

   /**
    * Documentaci�.
    *
    * @param schedulerName Documentaci�
    */
   public void setSchedulerName(String schedulerName);

   /**
    * Documentaci�.
    *
    * @param startupDelay Documentaci�
    */
   public void setStartupDelay(int startupDelay);

   /**
    * Documentaci�.
    *
    * @param transactionManager Documentaci�
    */
   public void setTransactionManager(
      PlatformTransactionManager transactionManager);

   /**
    * Documentaci�.
    *
    * @param triggers Documentaci�
    */
   public void setTriggers(TriggerIF[] triggers);

   /**
    * Documentaci�.
    *
    * @param waitForJobsToCompleteOnShutdown Documentaci�
    */
   public void setWaitForJobsToCompleteOnShutdown(
      boolean waitForJobsToCompleteOnShutdown);

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void afterPropertiesSet() throws SchedulerServiceException;

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void destroy() throws SchedulerServiceException;
}
