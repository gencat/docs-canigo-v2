/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.scheduler.impl.quartz;

import java.util.Properties;

import javax.sql.DataSource;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.scheduler.exception.SchedulerServiceException;
import net.gencat.ctti.canigo.services.scheduler.impl.quartz.SpringQuartzSchedulerFactoryBean;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;


/**
 * La classe SchedulerFactoryBean de Spring, per defecte sobreescriu la classe del
 * JobStore definida a les propietats del Quartz si la propietat DataSource esta
 * informada.
 * Per no haver de tenir fitxers de configuracio diferents segon l'entorn (un on es
 * defineixi una referencia al bean del DataSource i un on no hi aparegui) amb aquesta
 * classe es carrega el DataSource del context en cas que s'informi el seu nom (al ser
 * un valor i no una referencia a un bean es poden informar diferents valors als
 * fitxers de configuracio)
 *
 * @author ibarrera
 *
 */
public class PersistableSpringQuartzSchedulerFactoryBean
   extends SpringQuartzSchedulerFactoryBean implements ApplicationContextAware {
   /**
    * Documentaci�.
    */
   private ApplicationContext applicationContext;

   /**
    * Documentaci�.
    */
   private String dataSourceBeanName;

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void afterPropertiesSet() throws SchedulerServiceException {
      if (!StringUtils.isBlank(dataSourceBeanName)) {
         try {
            DataSource ds = (DataSource) applicationContext.getBean(dataSourceBeanName);
            super.setDataSource(ds);
         } catch (BeansException ex) {
            String[] args = { this.getClass().getName() };
            ExceptionDetails exDetails = new ExceptionDetails("net.opentrends.openFrame.services.scheduler.afterPropertiesSet",
                  args, Layer.SERVICES, Subsystem.SCHEDULER_SERVICES);
            exDetails.setProperties(new Properties());
            throw new SchedulerServiceException(ex, exDetails);
         }
      }

      super.afterPropertiesSet();
   }

   /**
    * Documentaci�.
    *
    * @param applicationContext Documentaci�
    */
   public void setApplicationContext(ApplicationContext applicationContext) {
      this.applicationContext = applicationContext;
      super.setApplicationContext(applicationContext);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ApplicationContext getApplicationContext() {
      return applicationContext;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getDataSourceBeanName() {
      return dataSourceBeanName;
   }

   /**
    * Documentaci�.
    *
    * @param dataSourceBeanName Documentaci�
    */
   public void setDataSourceBeanName(String dataSourceBeanName) {
      this.dataSourceBeanName = dataSourceBeanName;
   }
}
