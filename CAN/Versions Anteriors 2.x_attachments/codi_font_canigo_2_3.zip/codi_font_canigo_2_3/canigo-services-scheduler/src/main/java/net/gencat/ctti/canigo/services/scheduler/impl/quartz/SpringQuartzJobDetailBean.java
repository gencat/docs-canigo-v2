/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.scheduler.impl.quartz;

import java.util.Properties;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.scheduler.JobDetailIF;
import net.gencat.ctti.canigo.services.scheduler.exception.SchedulerServiceException;

import org.springframework.scheduling.quartz.JobDetailBean;


/**
 * Convenience subclass of Quartz' JobDetail class that eases bean-style
 * usage.
 *
 * <p>JobDetail itself is already a JavaBean but lacks sensible defaults.
 * This class uses the Spring bean name as job name, and the Quartz
 * default group ("DEFAULT") as job group if not specified.
 *
 * @author Juergen Hoeller
 * @since 18.02.2004
 * @see #setName
 * @see #setGroup
 * @see org.springframework.beans.factory.BeanNameAware
 * @see org.quartz.Scheduler#DEFAULT_GROUP
 */
public class SpringQuartzJobDetailBean extends JobDetailBean
   implements JobDetailIF {
   /**
    * Documentaci�.
    */
   private static final long serialVersionUID = 1L;

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void validate() throws SchedulerServiceException {
      try {
         super.validate();
      } catch (Exception ex) {
         String[] args = { this.getClass().getName() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.scheduler.validate",
               args, Layer.SERVICES, Subsystem.SCHEDULER_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SchedulerServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getDelegate() {
      return this;
   }
}
