/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.ftp.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.ftp.FtpClientIF;
import net.gencat.ctti.canigo.services.logging.LoggingService;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * Test for the FtpService class.
 *
 * @author Eusebi Collell
 */
public class FtpServiceTest extends TestCase {
   /**
    * Logging service
    */
   private LoggingService logService = null;

   /**
    * Documentaci�.
    */
   private String host;

   /**
    * Documentaci�.
    */
   private String localFile;

   /**
    * Documentaci�.
    */
   private String localFolder;

   /**
    * Documentaci�.
    */
   private String password;

   /**
    * Documentaci�.
    */
   private String serverFile;

   /**
    * Documentaci�.
    */
   private String serverFolder;

   /**
    * Documentaci�.
    */
   private String userName;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void setUp() throws Exception {
      super.setUp();

      host = "192.168.1.190";
      userName = "prova";
      password = "prova";

      serverFile = "file2download.txt";
      serverFolder = "/";

      File f = new File(".");
      localFolder = f.getAbsolutePath()
                     .substring(0, (f.getAbsolutePath().length() - 1)) +
         "target/test-classes/ftp/";
      localFile = "file2upload.txt";
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testConnectAndLogin() throws Exception {
      FtpClientIF ftpClient = getFtpService();

      assertTrue(ftpClient.login(userName, password, host));

      if (ftpClient.isConnected()) {
         ftpClient.disconnect();
      }

      if (getLogService() != null) {
         getLogService().getLog(this.getClass().getName())
            .debug("End testConnectAndLogin()");
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testConnectFailed() throws Exception {
      password = "incorrectPasword";

      FtpClientIF ftpClient = getFtpService();

      assertFalse(ftpClient.login(userName, password, host));

      if (ftpClient.isConnected()) {
         ftpClient.disconnect();
      }

      if (getLogService() != null) {
         getLogService().getLog(this.getClass().getName())
            .debug("End testConnectFailed()");
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testSendRawCommand() throws Exception {
      FtpClientIF ftpClient = getFtpService();
      ftpClient.login(userName, password, host);

      int returnCodeOk = 257;
      int returnCode = ftpClient.sendCommand("PWD");

      if (ftpClient.isConnected()) {
         ftpClient.disconnect();
      }

      assertEquals(returnCodeOk, returnCode);

      if (getLogService() != null) {
         getLogService().getLog(this.getClass().getName())
            .debug("End testSendRawCommand()");
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testListFileNames() throws Exception {
      FtpClientIF ftpClient = getFtpService();
      ftpClient.login(userName, password, host);

      String[] listFileNames = ftpClient.listNames(serverFolder);

      if (ftpClient.isConnected()) {
         ftpClient.disconnect();
      }

      assertTrue(0 < listFileNames.length);

      if (getLogService() != null) {
         getLogService().getLog(this.getClass().getName())
            .debug("End testListFileNames()");
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testUploadFile() throws Exception {
      FtpClientIF ftpClient = getFtpService();
      ftpClient.login(userName, password, host);

      InputStream input;
      input = new FileInputStream(localFolder + localFile);

      String serverFileUploaded = localFile;
      ftpClient.storeFile(serverFileUploaded, input);

      input.close();

      // validate file at server
      boolean existsAtServer = false;
      String[] listFileNames = ftpClient.listNames(serverFolder);

      if (listFileNames != null) {
         for (int i = 0; i < listFileNames.length; i++) {
            String fileName = (String) listFileNames[i];

            if (localFile.equals(fileName)) {
               existsAtServer = true;

               break;
            }
         }
      }

      if (ftpClient.isConnected()) {
         ftpClient.disconnect();
      }

      assertTrue(existsAtServer);

      if (getLogService() != null) {
         getLogService().getLog(this.getClass().getName())
            .debug("End testUploadFile()");
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testDownloadFile() throws Exception {
      FtpClientIF ftpClient = getFtpService();
      ftpClient.login(userName, password, host);

      InputStream inputStream = ftpClient.retrieveFileStream(serverFile);
      byte[] buf = new byte[4096];
      FileOutputStream fileDownload = new FileOutputStream(localFolder +
            serverFile);

      for (int len = -1; (len = inputStream.read(buf)) != -1;) {
         fileDownload.write(buf, 0, len);
      }

      fileDownload.flush();

      if (ftpClient.isConnected()) {
         ftpClient.disconnect();
      }

      File file = new File(localFolder + serverFile);
      assertTrue(file.exists());

      if (getLogService() != null) {
         getLogService().getLog(this.getClass().getName())
            .debug("End testDownloadFile()");
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private FtpClientIF getFtpService() {
      BeanFactory beanFactory = new ClassPathXmlApplicationContext(
            "applicationContext.xml");
      FtpClientIF ftpClient = (FtpClientIF) beanFactory.getBean("ftpService");
      logService = ftpClient.getLogService();

      assertNotNull(ftpClient);

      return ftpClient;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * Documentaci�.
    *
    * @param logService Documentaci�
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }
}
