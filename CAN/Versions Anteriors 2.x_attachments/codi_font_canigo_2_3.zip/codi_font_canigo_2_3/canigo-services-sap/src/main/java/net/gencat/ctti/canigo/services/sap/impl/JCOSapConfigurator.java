/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.sap.impl;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class JCOSapConfigurator {
   /**
    * Documentaci�.
    */
   public static String DEFAULT_REPOSITORY = "ARAsoft";

   /**
    * Documentaci�.
    */
   public static boolean DEFAULT_CONNECTION_POOL = true;

   /**
    * Documentaci�.
    */
   public static String DEFAULT_CONNECTION_POOL_NAME = "poolCanigoSAP";

   /**
    * Documentaci�.
    */
   public static int DEFAULT_MAX_NUM_CONNECTIONS = 5;

   /**
    * Documentaci�.
    */
   protected String ashost;

   /**
    * Documentaci�.
    */
   protected String client;

   /**
    * Documentaci�.
    */
   protected String connectionPoolName;

   /**
    * Documentaci�.
    */
   protected String lang;

   /**
    * Documentaci�.
    */
   protected String passwd;

   /**
    * Documentaci�.
    */
   protected String repository;

   /**
    * Documentaci�.
    */
   protected String sysnr;

   /**
    * Documentaci�.
    */
   protected String user;

   /**
    * Documentaci�.
    */
   protected boolean connectionPool;

   /**
    * Documentaci�.
    */
   protected int maxNumConnections;

   /**
    * Creates a new JCOSapConfigurator object.
    */
   public JCOSapConfigurator() {
      // Default configuration
      repository = DEFAULT_REPOSITORY;
      connectionPool = DEFAULT_CONNECTION_POOL;
      maxNumConnections = DEFAULT_MAX_NUM_CONNECTIONS;
      connectionPoolName = DEFAULT_CONNECTION_POOL_NAME;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getAshost() {
      return ashost;
   }

   /**
    * Documentaci�.
    *
    * @param ashost Documentaci�
    */
   public void setAshost(String ashost) {
      this.ashost = ashost;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getClient() {
      return client;
   }

   /**
    * Documentaci�.
    *
    * @param client Documentaci�
    */
   public void setClient(String client) {
      this.client = client;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getLang() {
      return lang;
   }

   /**
    * Documentaci�.
    *
    * @param lang Documentaci�
    */
   public void setLang(String lang) {
      this.lang = lang;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getPasswd() {
      return passwd;
   }

   /**
    * Documentaci�.
    *
    * @param passwd Documentaci�
    */
   public void setPasswd(String passwd) {
      this.passwd = passwd;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getSysnr() {
      return sysnr;
   }

   /**
    * Documentaci�.
    *
    * @param sysnr Documentaci�
    */
   public void setSysnr(String sysnr) {
      this.sysnr = sysnr;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getUser() {
      return user;
   }

   /**
    * Documentaci�.
    *
    * @param user Documentaci�
    */
   public void setUser(String user) {
      this.user = user;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getRepository() {
      return repository;
   }

   /**
    * Documentaci�.
    *
    * @param repository Documentaci�
    */
   public void setRepository(String repository) {
      this.repository = repository;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isConnectionPool() {
      return connectionPool;
   }

   /**
    * Documentaci�.
    *
    * @param connectionPool Documentaci�
    */
   public void setConnectionPool(boolean connectionPool) {
      this.connectionPool = connectionPool;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getMaxNumConnections() {
      return maxNumConnections;
   }

   /**
    * Documentaci�.
    *
    * @param maxNumConnections Documentaci�
    */
   public void setMaxNumConnections(int maxNumConnections) {
      this.maxNumConnections = maxNumConnections;
   }

   /**
    * @return Returns the connectionPoolName.
    */
   public String getConnectionPoolName() {
      return connectionPoolName;
   }

   /**
    * @param connectionPoolName The connectionPoolName to set.
    */
   public void setConnectionPoolName(String connectionPoolName) {
      this.connectionPoolName = connectionPoolName;
   }
}
