/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.sap.test.abertis;

import java.math.BigDecimal;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class PermisosBean {
   /**
    * Documentaci�.
    */
   protected BigDecimal ABSENCEDAYS;

   /**
    * Documentaci�.
    */
   protected BigDecimal ABSENCEHOURS;

   /**
    * Documentaci�.
    */
   protected String ABSENCETYPE;

   /**
    * Documentaci�.
    */
   protected String EMPLOYEENO;

   /**
    * Documentaci�.
    */
   protected String END;

   /**
    * Documentaci�.
    */
   protected String LOCKINDIC;

   /**
    * Documentaci�.
    */
   protected String NAMEOFABSENCETYPE;

   /**
    * Documentaci�.
    */
   protected String OBJECTID;

   /**
    * Documentaci�.
    */
   protected String RECORDNR;

   /**
    * Documentaci�.
    */
   protected String START;

   /**
    * Documentaci�.
    */
   protected String SUBTYPE;

   /**
    * Documentaci�.
    */
   protected String VALIDBEGIN;

   /**
    * Documentaci�.
    */
   protected String VALIDEND;

   /**
    * Creates a new PermisosBean object.
    */
   public PermisosBean() {
   }

   /**
    * @return Returns the aBSENCEDAYS.
    */
   public BigDecimal getABSENCEDAYS() {
      return ABSENCEDAYS;
   }

   /**
    * @param absencedays The aBSENCEDAYS to set.
    */
   public void setABSENCEDAYS(BigDecimal absencedays) {
      ABSENCEDAYS = absencedays;
   }

   /**
    * @return Returns the aBSENCEHOURS.
    */
   public BigDecimal getABSENCEHOURS() {
      return ABSENCEHOURS;
   }

   /**
    * @param absencehours The aBSENCEHOURS to set.
    */
   public void setABSENCEHOURS(BigDecimal absencehours) {
      ABSENCEHOURS = absencehours;
   }

   /**
    * @return Returns the aBSENCETYPE.
    */
   public String getABSENCETYPE() {
      return ABSENCETYPE;
   }

   /**
    * @param absencetype The aBSENCETYPE to set.
    */
   public void setABSENCETYPE(String absencetype) {
      ABSENCETYPE = absencetype;
   }

   /**
    * @return Returns the eMPLOYEENO.
    */
   public String getEMPLOYEENO() {
      return EMPLOYEENO;
   }

   /**
    * @param employeeno The eMPLOYEENO to set.
    */
   public void setEMPLOYEENO(String employeeno) {
      EMPLOYEENO = employeeno;
   }

   /**
    * @return Returns the eND.
    */
   public String getEND() {
      return END;
   }

   /**
    * @param end The eND to set.
    */
   public void setEND(String end) {
      END = end;
   }

   /**
    * @return Returns the lOCKINDIC.
    */
   public String getLOCKINDIC() {
      return LOCKINDIC;
   }

   /**
    * @param lockindic The lOCKINDIC to set.
    */
   public void setLOCKINDIC(String lockindic) {
      LOCKINDIC = lockindic;
   }

   /**
    * @return Returns the nAMEOFABSENCETYPE.
    */
   public String getNAMEOFABSENCETYPE() {
      return NAMEOFABSENCETYPE;
   }

   /**
    * @param nameofabsencetype The nAMEOFABSENCETYPE to set.
    */
   public void setNAMEOFABSENCETYPE(String nameofabsencetype) {
      NAMEOFABSENCETYPE = nameofabsencetype;
   }

   /**
    * @return Returns the oBJECTID.
    */
   public String getOBJECTID() {
      return OBJECTID;
   }

   /**
    * @param objectid The oBJECTID to set.
    */
   public void setOBJECTID(String objectid) {
      OBJECTID = objectid;
   }

   /**
    * @return Returns the rECORDNR.
    */
   public String getRECORDNR() {
      return RECORDNR;
   }

   /**
    * @param recordnr The rECORDNR to set.
    */
   public void setRECORDNR(String recordnr) {
      RECORDNR = recordnr;
   }

   /**
    * @return Returns the sTART.
    */
   public String getSTART() {
      return START;
   }

   /**
    * @param start The sTART to set.
    */
   public void setSTART(String start) {
      START = start;
   }

   /**
    * @return Returns the sUBTYPE.
    */
   public String getSUBTYPE() {
      return SUBTYPE;
   }

   /**
    * @param subtype The sUBTYPE to set.
    */
   public void setSUBTYPE(String subtype) {
      SUBTYPE = subtype;
   }

   /**
    * @return Returns the vALIDBEGIN.
    */
   public String getVALIDBEGIN() {
      return VALIDBEGIN;
   }

   /**
    * @param validbegin The vALIDBEGIN to set.
    */
   public void setVALIDBEGIN(String validbegin) {
      VALIDBEGIN = validbegin;
   }

   /**
    * @return Returns the vALIDEND.
    */
   public String getVALIDEND() {
      return VALIDEND;
   }

   /**
    * @param validend The vALIDEND to set.
    */
   public void setVALIDEND(String validend) {
      VALIDEND = validend;
   }
}
