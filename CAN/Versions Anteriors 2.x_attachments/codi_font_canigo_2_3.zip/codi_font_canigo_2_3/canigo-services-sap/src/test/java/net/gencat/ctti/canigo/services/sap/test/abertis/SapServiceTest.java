/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.sap.test.abertis;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.sap.SapService;
import net.gencat.ctti.canigo.services.sap.impl.JCOSapService;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * Test for the ServiceSap class.
 *
 * @author Eusebi Collell
 */
public class SapServiceTest extends TestCase {
   /**
    * Logging service
    */
   private LoggingService logService = null;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void setUp() throws Exception {
      super.setUp();
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testExecuteFunctionAbertis() throws Exception {
      SapService sapService = getSapService();

      // Parameters
      Map parametersMap = new HashMap();

      parametersMap.put("EMPLOYEENUMBER", "17065258");
      parametersMap.put("SUBTYPE", "");
      parametersMap.put("TIMEINTERVALHIGH", "9999-12-31");
      parametersMap.put("TIMEINTERVALLOW", "1800-01-01");

      // Returns Lista de permisos retribuidos por usuario
      Collection col = sapService.executeFunction("Z_BAPI_ABSENCE_GETDETAILEDLIST",
            "ABSENCE", parametersMap, PermisosBean.class);

      assertNotNull(col);
      assertFalse(col.isEmpty());
      assertTrue(col.size() > 0);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private SapService getSapService() {
      BeanFactory beanFactory = new ClassPathXmlApplicationContext(
            "applicationContext.xml");
      JCOSapService sapService = (JCOSapService) beanFactory.getBean(
            "sapService");
      logService = sapService.getLogService();

      assertNotNull(sapService);

      return sapService;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * Documentaci�.
    *
    * @param logService Documentaci�
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }
}
