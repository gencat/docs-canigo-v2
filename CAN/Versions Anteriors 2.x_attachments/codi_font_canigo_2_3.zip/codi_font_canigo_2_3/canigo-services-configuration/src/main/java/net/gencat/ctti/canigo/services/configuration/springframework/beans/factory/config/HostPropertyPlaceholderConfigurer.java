/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.configuration.springframework.beans.factory.config;

import java.io.File;
import java.io.IOException;

import net.gencat.ctti.canigo.services.configuration.ConfigurationService;
import net.gencat.ctti.canigo.services.configuration.exception.ConfigurationServiceException;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;


/**
 * Host property configurer
 *
 * @author XES
 * @author MMA
 *
 */
public class HostPropertyPlaceholderConfigurer
   extends PropertyPlaceholderConfigurer implements InitializingBean,
      ConfigurationService {
   /**
    * Documentaci�.
    */
   private String entorn = System.getProperty("entorn");

   /**
    * Base property files
    */
   private String[] basePropertyFiles = null;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void afterPropertiesSet() throws Exception {
      if (this.basePropertyFiles != null) {
         Resource[] locations = new Resource[this.basePropertyFiles.length];

         for (int i = 0; i < this.basePropertyFiles.length; i++) {
            String fileName = this.basePropertyFiles[i];

            locations[i] = obtainPropertyFile(fileName);
         }

         setLocations(locations);
      }
   }

   /**
    * This method will get the property file according to the next cases:
    *
    * 1. ENTORN property is set, and exists the property file with the value
    * ENTORN as a root directory
    * 2. ENTORN property is not set or doesn't exists the file according to the rule 1
    *
    * @author PDL
    */
   private Resource obtainPropertyFile(String fileName) {
      Resource r = null;

      // Case 1
      if (entorn != null) {
         // Position where property entorn will be if the colon
         int colonNextPos = fileName.indexOf(":") + 1;

         if (colonNextPos > 0) {
            String fileNameEnv = fileName.substring(0, colonNextPos) + entorn +
               File.separator + fileName.substring(colonNextPos);

            r = new DefaultResourceLoader().getResource(fileNameEnv);

            if (!r.exists()) {
               r = null;
            }
         }
      }

      // Case 2:
      if (r == null) {
         r = new DefaultResourceLoader().getResource(fileName);
      }

      return r;
   }

   /**
       * @return Returns the basePropertyFiles.
       */
   public String[] getBasePropertyFiles() {
      return basePropertyFiles;
   }

   /**
    * @param basePropertyFiles
    *            The basePropertyFiles to set.
    */
   public void setBasePropertyFiles(String[] basePropertyFiles) {
      this.basePropertyFiles = basePropertyFiles;
   }

   /**
    * Gets the first base property file
    *
    * @return java.lang.String
    */
   public String getBasePropertyFile() {
      if (this.basePropertyFiles != null) {
         return this.basePropertyFiles[0];
      }

      return null;
   }

   /**
    * Sets an unique base property file
    *
    * @param basePropertyFile
    */
   public void setBasePropertyFile(String basePropertyFile) {
      this.setBasePropertyFiles(new String[] { basePropertyFile });
   }

   /**
    * Returns a configuration value
    *
    * @param key
    *            the key to lookup
    * @throws ConfigurationServiceException
    *             if key not found
    */
   public String getProperty(String key) throws ConfigurationServiceException {
      String propertyValue = null;

      try {
         propertyValue = this.resolvePlaceholder(key, this.mergeProperties());
      } catch (IOException ex) {
         throw new ConfigurationServiceException(ex,
            ConfigurationServiceException.class.getPackage() +
            ".no_such_property", new Object[] { key }, Layer.SERVICES,
            Subsystem.CONFIGURATION_SERVICES);
      }

      if (propertyValue == null) {
         throw new ConfigurationServiceException(ConfigurationServiceException.class.getPackage() +
            ".no_such_property", new Object[] { key }, Layer.SERVICES,
            Subsystem.CONFIGURATION_SERVICES);
      }

      return propertyValue;
   }
}
