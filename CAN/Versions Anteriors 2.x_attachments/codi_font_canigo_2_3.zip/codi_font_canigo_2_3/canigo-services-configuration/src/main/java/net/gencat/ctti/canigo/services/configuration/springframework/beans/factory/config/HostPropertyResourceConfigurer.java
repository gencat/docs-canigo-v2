/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.configuration.springframework.beans.factory.config;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.PropertyOverrideConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class HostPropertyResourceConfigurer extends PropertyOverrideConfigurer
   implements InitializingBean {
   /**
    * Documentaci�.
    */
   private String basePropertyFile;

   /**
    * @return Returns the basePropertyFile.
    */
   public String getBasePropertyFile() {
      return basePropertyFile;
   }

   /**
    * @param basePropertyFile
    *            The basePropertyFile to set.
    */
   public void setBasePropertyFile(String basePropertyFile) {
      this.basePropertyFile = basePropertyFile;
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void afterPropertiesSet() throws Exception {
      if (basePropertyFile == null) {
         return;
      }

      // Obtain host Name
      String hostName;
      InetAddress localHost = null;

      try {
         localHost = InetAddress.getLocalHost();
         hostName = new String(localHost.getHostName());

         String fileName = basePropertyFile + "." + hostName;

         // Check if exists fileName for host
         ClassPathResource classPathResource = new ClassPathResource(fileName);

         if (classPathResource.exists()) {
            Resource[] locations = {
                  new DefaultResourceLoader().getResource(fileName),
                  new DefaultResourceLoader().getResource(basePropertyFile)
               };
            setLocations(locations);
         } else {
            setLocation(new DefaultResourceLoader().getResource(
                  basePropertyFile));
         }
      } catch (UnknownHostException e) {
         // error message
      }
   }
}
