/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.configuration.test;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.configuration.ConfigurationService;
import net.gencat.ctti.canigo.services.configuration.exception.ConfigurationServiceException;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class ConfigurationServiceTest extends TestCase {
   /**
    * Documentaci�.
    */
   public void setUp() {
   }

   /**
    * Test of obtaining properties with HostPropertyResourceConfigurator
    */
   public void testHostPropertyOverride() {
      //  Obtain the spring context to initialize the bean
      ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(
            "applicationContext.xml");
      BeanFactory factory = (BeanFactory) appContext;

      ConfigurationTestVO vo = (ConfigurationTestVO) factory.getBean(
            "myConfiguration");
      assertNotSame(vo.getVar1(), "1000");
   }

   /**
    * Documentaci�.
    */
   public void testHostPlaceHolder() {
      //  Obtain the spring context to initialize the bean
      ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(
            "applicationContext.xml");
      BeanFactory factory = (BeanFactory) appContext;

      ConfigurationTestVO vo = (ConfigurationTestVO) factory.getBean(
            "myConfiguration");
      assertEquals(vo.getVar2(), "var2");
      assertNull(vo.getVar3());
   }

   /**
    * Documentaci�.
    */
   public void testConfigurationServiceStandalone() {
      //  Obtain the spring context to initicalize the bean
      ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(
            "applicationContext.xml");
      BeanFactory factory = (BeanFactory) appContext;

      ConfigurationService configService = (ConfigurationService) factory.getBean(
            "configurationService");
      String configValue = null;

      try {
         configValue = configService.getProperty("standalone.value");
      } catch (ConfigurationServiceException ex) {
         assertTrue("Config value 'standalone.value' not found", false);
      }

      assertEquals(configValue, "standalone.value");
   }
}
