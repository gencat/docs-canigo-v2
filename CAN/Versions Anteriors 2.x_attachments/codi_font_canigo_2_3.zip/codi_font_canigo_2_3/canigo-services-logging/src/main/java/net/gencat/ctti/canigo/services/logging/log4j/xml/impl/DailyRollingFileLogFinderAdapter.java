/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging.log4j.xml.impl;

import java.util.ArrayList;
import java.util.List;

import net.gencat.ctti.canigo.services.logging.LoggingService;

//XXX Adaptaci� de CAN-40
//import net.gencat.controlpanel.exceptions.ControlPanelException;
//import net.gencat.controlpanel.model.Aplicacio;
import net.mlw.vlh.DefaultListBackedValueList;
import net.mlw.vlh.ValueList;
import net.mlw.vlh.ValueListInfo;
import net.mlw.vlh.adapter.AbstractValueListAdapter;
import net.mlw.vlh.web.tag.support.Spacer;


//XXX Adaptaci� de CAN-40
/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.6 $
  */
public class DailyRollingFileLogFinderAdapter extends AbstractValueListAdapter {
   /**
    * Documentaci�.
    */
   public static String PATH = "ruta";

   /**
    * Documentaci�.
    */
   public static String DATE = "dia";

   /**
    * The log builder
    */
   private LogBuilder logBuilder = null;

   /**
    * The log service
    */
   private LoggingService logService = null;

   //  XXX Adaptaci� de CAN-40    
   /**
    * Creates a new DailyRollingFileLogFinderAdapter object.
    */
   public DailyRollingFileLogFinderAdapter() {
      super();
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param info Documentaci�
    *
    * @return Documentaci�
    */
   public ValueList getValueList(String name, ValueListInfo info) {
      if (info.getSortingColumn() == null) {
         info.setPrimarySortColumn(getDefaultSortColumn());
         info.setPrimarySortDirection(getDefaultSortDirectionInteger());
      }

      if (info.getPagingNumberPer() == Integer.MAX_VALUE) {
         info.setPagingNumberPer(getDefaultNumberPerPage());
      }

      String path = (String) info.getFilters().get(PATH);

      // path shoud never be null neither blank
      if ((path == null) || "".equals(path)) {
         this.logService.getLog(this.getClass())
                        .debug("current log list is null or blank");

         List dummyList = new ArrayList();
         dummyList.add(new Spacer());

         return new DefaultListBackedValueList(dummyList, info);
      }

      //XXX Adaptaci� de CAN-40
      //        String app = (String)info.getFilters().get(APPLICATION);
      //        if(!"".equals(app)&&app!=null){
      //            Aplicacio target = new Aplicacio();
      //            target.setId(new Integer(app));
      //            if(!this.securityService.hasUserReadPermission(target)){
      //                this.logService.getLog(this.getClass()).error("Access denied to application "+app);
      //                ExceptionDetails exD = new ExceptionDetails(ControlPanelException.class.getPackage().getName()+".acces_denied",new Object[]{app});
      //                throw new WebListsServiceException(exD);
      //            }
      //        }
      List list = null;
      this.logService.getLog(this.getClass())
                     .debug("getValueList(String adapterName = " + name +
         ", adapterType = " + this.getAdapterType() +
         ", ValueListInfo info = " + info + ") - Start to paging result set");

      int pageNumber = info.getPagingPage();
      int numberPerPage = (info.getPagingNumberPer() > 0)
         ? info.getPagingNumberPer() : getDefaultNumberPerPage();
      this.logService.getLog(this.getClass())
                     .debug("pageNumber=" + pageNumber + ",numberPerPage=" +
         numberPerPage);

      DailyRollingFileLogInfo logList = new DailyRollingFileLogInfo((pageNumber -
            1) * numberPerPage, numberPerPage);

      try {
         list = this.logBuilder.getLogItems(logList, info.getFilters());
      } catch (Throwable e) {
         //XXX CAN-40
         if (e instanceof RuntimeException) {
            throw (RuntimeException) e;
         }

         this.logService.getLog(this.getClass()).error("Cannot obtain logs", e);

         //ExceptionDetails exD = new ExceptionDetails(DailyRollingFileLogFinderAdapter.class.getPackage().getName()+".cannot_parse_xmllog4j",new Object[]{info.getFilters().get(PATH)});
         //throw new SystemException(e,exD);
         throw new RuntimeException(DailyRollingFileLogFinderAdapter.class.getPackage()
                                                                          .getName() +
            ".cannot_parse_xmllog4j. Path: " + info.getFilters().get(PATH));
      }

      if ((list != null) && !list.isEmpty()) {
         this.logService.getLog(this.getClass())
                        .debug("All logs size is " +
            logList.getTotalNumberOfItems());
         info.setTotalNumberOfEntries(logList.getTotalNumberOfItems());
         this.logService.getLog(this.getClass())
                        .debug("Paged list size is " + list.size());
      } else {
         List dummyList = new ArrayList();
         dummyList.add(new Spacer());

         return new DefaultListBackedValueList(dummyList, info);
      }

      return new DefaultListBackedValueList(list, info);
   }

   /**
    * @return Returns the logService.
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * @param logService
    *            The logService to set.
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * @return Returns the logBuilder.
    */
   public LogBuilder getLogBuilder() {
      return logBuilder;
   }

   /**
    * @param logBuilder The logBuilder to set.
    */
   public void setLogBuilder(LogBuilder logBuilder) {
      this.logBuilder = logBuilder;
   }

   //XXX Adaptaci� de CAN-40
   //    /**
   //     * @return Returns the securityService.
   //     */
   //    public SecurityService getSecurityService() {
   //        return securityService;
   //    }
   //
   //    /**
   //     * @param securityService The securityService to set.
   //     */
   //    public void setSecurityService(SecurityService securityService) {
   //        this.securityService = securityService;
   //    }
}
