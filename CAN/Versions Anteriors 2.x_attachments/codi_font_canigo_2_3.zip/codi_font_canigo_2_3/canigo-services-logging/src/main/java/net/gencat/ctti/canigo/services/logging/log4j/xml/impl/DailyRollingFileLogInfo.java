/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging.log4j.xml.impl;

import java.util.ArrayList;
import java.util.List;


/**
 * Wraps information about the number of log items has been parsed from XML
 * and the total number of log items
 * @author MMR
 *
 */
public class DailyRollingFileLogInfo {
   /**
    * Documentaci�.
    */
   private List items = null;

   /**
    * Documentaci�.
    */
   private int firstItem2Parse = 0;

   /**
    * Documentaci�.
    */
   private int numberOfItems2Parse = Integer.MAX_VALUE;

   /**
    * Documentaci�.
    */
   private int totalNumberOfItems = 0;

   /**
    * Creates a new DailyRollingFileLogInfo object.
    */
   public DailyRollingFileLogInfo() {
      this.items = new ArrayList();
   }

   /**
    * Constructor
    */
   public DailyRollingFileLogInfo(int firstItem2Parse, int numberOfItems2Parse) {
      this.items = new ArrayList();
      this.firstItem2Parse = firstItem2Parse;
      this.numberOfItems2Parse = numberOfItems2Parse;
   }

   /**
    * @return Returns the firstItem2Parse.
    */
   public int getFirstItem2Parse() {
      return firstItem2Parse;
   }

   /**
    * @param firstItem2Parse The firstItem2Parse to set.
    */
   public void setFirstItem2Parse(int firstItem2Parse) {
      this.firstItem2Parse = firstItem2Parse;
   }

   /**
    * @return Returns the items.
    */
   public List getItems() {
      return items;
   }

   /**
    * @param items The items to set.
    */
   public void setItems(List items) {
      this.items = items;
   }

   /**
    * @return Returns the numberOfItems2Parse.
    */
   public int getNumberOfItems2Parse() {
      return numberOfItems2Parse;
   }

   /**
    * @param numberOfItems2Parse The numberOfItems2Parse to set.
    */
   public void setNumberOfItems2Parse(int numberOfItems2Parse) {
      this.numberOfItems2Parse = numberOfItems2Parse;
   }

   /**
    * @return Returns the totalNumberOfItems.
    */
   public int getTotalNumberOfItems() {
      return totalNumberOfItems;
   }

   /**
    * @param totalNumberOfItems The totalNumberOfItems to set.
    */
   public void setTotalNumberOfItems(int totalNumberOfItems) {
      this.totalNumberOfItems = totalNumberOfItems;
   }

   /**
    * Adds a log item
    * @param item the item
    */
   public void addItem(Object item) {
      if (this.items.size() < this.numberOfItems2Parse) {
         if (this.firstItem2Parse <= this.totalNumberOfItems) {
            this.items.add(item);
         }
      }

      this.totalNumberOfItems++;
   }
}
