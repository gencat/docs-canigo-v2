/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging.log4j;

import org.apache.log4j.Level;
import org.apache.log4j.MDC;
import org.apache.log4j.NDC;


/**
 * Adapter class of Log4j
 */
public class Log4JLog implements net.gencat.ctti.canigo.services.logging.Log {
   /**
    * Use of log interface of Commons Logging
    */
   org.apache.log4j.Logger logger;

   /**
    * Default constructor
    * @param aLogger log4j logger
    */
   public Log4JLog(org.apache.log4j.Logger aLogger) {
      logger = aLogger;
   }

   /**
    * True if debug level is enabled
    * @return boolean
    */
   public boolean isDebugEnabled() {
      return logger.isDebugEnabled();
   }

   /**
    * True if audit level is enabled
    * @return boolean
    */
   public boolean isAuditEnabled() {
      return logger.isEnabledFor(AuditLevel.AUDIT);
   }

   /**
    * True if error level is enabled
    * @return boolean
    */
   public boolean isErrorEnabled() {
      return logger.isEnabledFor(Level.ERROR);
   }

   /**
    * True if fatal level is enabled
    * @return boolean
    */
   public boolean isFatalEnabled() {
      return logger.isEnabledFor(Level.FATAL);
   }

   /**
    * True if info level is enabled
    * @return boolean
    */
   public boolean isInfoEnabled() {
      return logger.isInfoEnabled();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isTraceEnabled() {
      return true;
   }

   /**
    * True if warn level is enabled
    * @return boolean
    */
   public boolean isWarnEnabled() {
      return logger.isEnabledFor(Level.WARN);
   }

   /**
    * Throws a trace message
    * @param aMessage the message
    */
   public void trace(Object aMessage) {
      // Unsupported in log4j
   }

   /**
    * Throws a trace message
    * @param aMessage the message
    * @param aThrowable an inner error
    */
   public void trace(Object aMessage, Throwable aThrowable) {
      // Unsupported
   }

   /**
    * Throws a debug message
    * @param aMessage the message
    */
   public void debug(Object aMessage) {
      logger.debug(aMessage);
   }

   /**
    * Throws a debug message
    * @param aMessage the message
    * @param aThrowable an inner error
    */
   public void debug(Object aMessage, Throwable aThrowable) {
      logger.debug(aMessage, aThrowable);
   }

   /**
    * Throws a info message
    * @param aMessage the message
    */
   public void info(Object aMessage) {
      logger.info(aMessage);
   }

   /**
    * Throws a info message
    * @param aMessage the message
    * @param aThrowable an inner error
    */
   public void info(Object aMessage, Throwable aThrowable) {
      logger.info(aMessage, aThrowable);
   }

   /**
    * Throws a warn message
    * @param aMessage the message
    */
   public void warn(Object aMessage) {
      logger.warn(aMessage);
   }

   /**
    * Throws a warn message
    * @param aMessage the message
    * @param aThrowable an inner error
    */
   public void warn(Object aMessage, Throwable aThrowable) {
      logger.warn(aMessage, aThrowable);
   }

   /**
    * Throws a error message
    * @param aMessage the message
    */
   public void error(Object aMessage) {
      logger.error(aMessage);
   }

   /**
    * Throws a error message
    * @param aMessage the message
    * @param aThrowable an inner error
    */
   public void error(Object aMessage, Throwable aThrowable) {
      logger.error(aMessage, aThrowable);
   }

   /**
    * Throws a fatal message
    * @param aMessage the message
    */
   public void fatal(Object aMessage) {
      logger.fatal(aMessage);
   }

   /**
    * Throws a fatal message
    * @param aMessage the message
    * @param aThrowable an inner error
    */
   public void fatal(Object aMessage, Throwable aThrowable) {
      logger.fatal(aMessage, aThrowable);
   }

   /**
    * Throws a audit message
    * @param aMessage the message
    */
   public void audit(Object aMessage) {
      logger.log(AuditLevel.AUDIT, aMessage);
   }

   /**
    * Throws a audit message
    * @param aMessage the message
    * @param aThrowable an inner error
    */
   public void audit(Object aMessage, Throwable aThrowable) {
      logger.log(AuditLevel.AUDIT, aMessage, aThrowable);
   }

   /**
    * Gets context information
    * @param key the key of the information to be retrieved
    * @return java.lang.Object
    */
   public Object getFromContext(String key) {
      return MDC.get(key);
   }

   /**
    * Inserts context information into this log
    * @param key the key of the information
    * @param object the value of the information
    */
   public void putInContext(String key, Object object) {
      MDC.put(key, object);
      /**
       * To be able to log context with XMLLayout
       */
      NDC.push(key + ": " + object.toString());
   }

   /**
    * Removes context information for the current thread
    *
    */
   public void removeContext() {
      NDC.remove();
   }
}
