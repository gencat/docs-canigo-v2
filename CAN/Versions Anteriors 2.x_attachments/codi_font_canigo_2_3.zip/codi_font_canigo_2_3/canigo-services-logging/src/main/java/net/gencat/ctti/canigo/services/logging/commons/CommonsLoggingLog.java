/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging.commons;


/**
 * Adapter class of Commons Logging
 */
public class CommonsLoggingLog implements net.gencat.ctti.canigo.services.logging.Log {
   /**
    * Use of log interface of Commons Logging
    */
   org.apache.commons.logging.Log log;

   /**
    * Default constructor
    * @param aLog the commons logging log
    */
   public CommonsLoggingLog(org.apache.commons.logging.Log aLog) {
      log = aLog;
   }

   /**
    * True if debug level is enabled
    * @return boolean
    */
   public boolean isDebugEnabled() {
      return log.isDebugEnabled();
   }

   /**
    * True if error level is enabled
    * @return boolean
    */
   public boolean isErrorEnabled() {
      return log.isErrorEnabled();
   }

   /**
    * True if fatal level is enabled
    * @return boolean
    */
   public boolean isFatalEnabled() {
      return log.isFatalEnabled();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isInfoEnabled() {
      return log.isInfoEnabled();
   }

   /**
    * True if trace level is enabled
    * @return boolean
    */
   public boolean isTraceEnabled() {
      return log.isTraceEnabled();
   }

   /**
    * True if warn level is enabled
    * @return boolean
    */
   public boolean isWarnEnabled() {
      return log.isWarnEnabled();
   }

   /**
    * Throws a trace message
    * @param aMessage the message
    */
   public void trace(Object aMessage) {
      log.trace(aMessage);
   }

   /**
    * Throws a trace message
    * @param aMessage the message
    * @param aThrowable an inner error
    */
   public void trace(Object aMessage, Throwable aThrowable) {
      log.trace(aMessage, aThrowable);
   }

   /**
    * Throws a debug message
    * @param aMessage the message
    */
   public void debug(Object aMessage) {
      log.debug(aMessage);
   }

   /**
    * Throws a debug message
    * @param aMessage the message
    * @param aThrowable an inner error
    */
   public void debug(Object aMessage, Throwable aThrowable) {
      log.debug(aMessage, aThrowable);
   }

   /**
    * Throws a info message
    * @param aMessage the message
    */
   public void info(Object aMessage) {
      log.info(aMessage);
   }

   /**
    * Throws a info message
    * @param aMessage the message
    * @param aThrowable an inner error
    */
   public void info(Object aMessage, Throwable aThrowable) {
      log.info(aMessage, aThrowable);
   }

   /**
    * Throws a warn message
    * @param aMessage the message
    */
   public void warn(Object aMessage) {
      log.warn(aMessage);
   }

   /**
    * Throws a warn message
    * @param aMessage the message
    * @param aThrowable an inner error
    */
   public void warn(Object aMessage, Throwable aThrowable) {
      log.warn(aMessage, aThrowable);
   }

   /**
    * Throws a error message
    * @param aMessage the message
    */
   public void error(Object aMessage) {
      log.error(aMessage);
   }

   /**
    * Throws a error message
    * @param aMessage the message
    * @param aThrowable an inner error
    */
   public void error(Object aMessage, Throwable aThrowable) {
      log.error(aMessage, aThrowable);
   }

   /**
    * Throws a fatal message
    * @param aMessage the message
    */
   public void fatal(Object aMessage) {
      log.fatal(aMessage);
   }

   /**
    * Throws a fatal message
    * @param aMessage the message
    * @param aThrowable an inner error
    */
   public void fatal(Object aMessage, Throwable aThrowable) {
      log.fatal(aMessage, aThrowable);
   }

   /**
    * Documentaci�.
    *
    * @param key Documentaci�
    *
    * @return Documentaci�
    */
   public Object getFromContext(String key) {
      // TODO Auto-generated method stub
      return null;
   }

   /**
    * Documentaci�.
    *
    * @param key Documentaci�
    * @param object Documentaci�
    */
   public void putInContext(String key, Object object) {
      // TODO Auto-generated method stub
   }

   /**
    * Documentaci�.
    */
   public void removeContext() {
      // TODO Auto-generated method stub
   }

   /**
    * Documentaci�.
    *
    * @param message Documentaci�
    */
   public void audit(Object message) {
      // TODO Auto-generated method stub       
   }

   /**
    * Documentaci�.
    *
    * @param message Documentaci�
    * @param t Documentaci�
    */
   public void audit(Object message, Throwable t) {
      // TODO Auto-generated method stub
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isAuditEnabled() {
      // TODO Auto-generated method stub
      return false;
   }
}
