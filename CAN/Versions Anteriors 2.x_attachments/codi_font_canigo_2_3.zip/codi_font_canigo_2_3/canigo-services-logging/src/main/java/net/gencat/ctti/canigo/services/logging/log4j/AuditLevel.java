/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging.log4j;

import org.apache.log4j.Level;


/**
 * Custom level with this priority:
 * DEBUG, INFO, AUDIT, WARN, ERROR, FATAL
 *
 * @author MMR
 */
public class AuditLevel extends Level {
   /**
    * Serial version uid
    */
   private static final long serialVersionUID = 1L;

   /**
    * Priority int
    */
   public static final int AUDIT_INT = Level.INFO_INT + 1;

   /**
    * Static level
    */
   public static final Level AUDIT = new AuditLevel(AUDIT_INT, "AUDIT", 8);

   /**
    * Default constructor
    * @param arg0 priority int
    * @param arg1 priority string
    * @param arg2 priority system int
    */
   public AuditLevel(int arg0, String arg1, int arg2) {
      super(arg0, arg1, arg2);
   }

   /**
    * Convert the string passed as argument to a level. If the conversion
    * fails, then this method returns AUDIT
    */
   public static Level toLevel(String sArg) {
      return (Level) toLevel(sArg, AuditLevel.AUDIT);
   }

   /**
    * Convert an integer passed as argument to a level. If the conversion
    * fails, then this method returns AUDIT
    *
    */
   public static Level toLevel(int val) {
      return (Level) toLevel(val, AuditLevel.AUDIT);
   }
}
