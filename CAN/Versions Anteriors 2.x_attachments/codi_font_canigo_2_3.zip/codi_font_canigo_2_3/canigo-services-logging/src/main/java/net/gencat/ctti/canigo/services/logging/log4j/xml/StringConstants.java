package net.gencat.ctti.canigo.services.logging.log4j.xml;

public class StringConstants {

	/**
	 * Empty String.
	 */
	public final static String EMPTY = "";

	/**
	 * Blank String.
	 */
	public final static String BLANK = " ";

	/**
	 * Blank character.
	 */
	public final static char BLANK_CHAR = ' ';

	/**
	 * Equal sign character.
	 */
	public static final char EQUAL = '=';

	/**
	 * Double quote.
	 */
	public static final char QUOT = '"';

	/**
	 * Left angle bracket.
	 */
	public static final char LT = '<';

	/**
	 * Right angle bracket.
	 */
	public static final char GT = '>';
	
}
