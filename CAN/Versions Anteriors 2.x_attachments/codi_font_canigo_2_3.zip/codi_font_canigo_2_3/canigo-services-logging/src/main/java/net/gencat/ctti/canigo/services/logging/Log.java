/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging;


/**
 * Interface for logging
 * Implementation can be based in different approaches:
 *  - Commons Logging
 *  - Other logging frameworks or special logs used by customers (with
 *  adapter pattern)
 *
 */
public interface Log {
   /**
    * Throws a debug message
    * @param message the message
    */
   public void debug(java.lang.Object message);

   /**
    * Throws a debug message
    * @param message
    * @param t an inner error
    */
   public void debug(java.lang.Object message, java.lang.Throwable t);

   /**
    * Throws an error message
    * @param message the message
    */
   public void error(java.lang.Object message);

   /**
    * Throws an error message
    * @param message the message
    * @param t an inner error
    */
   public void error(java.lang.Object message, java.lang.Throwable t);

   /**
    * Throws a fatal message
    * @param message the message
    */
   public void fatal(java.lang.Object message);

   /**
    * Throws a fatal message
    * @param message the message
    * @param t an inner error
    */
   public void fatal(java.lang.Object message, java.lang.Throwable t);

   /**
    * Throws an info message
    * @param message the message
    */
   public void info(java.lang.Object message);

   /**
    * Throws an info message
    * @param message the message
    * @param t an inner error
    */
   public void info(java.lang.Object message, java.lang.Throwable t);

   /**
    * Throws an audit message
    * @param message the message
    */
   public void audit(java.lang.Object message);

   /**
    * Throws an audit message
    * @param message the message
    * @param t an inner error
    */
   public void audit(java.lang.Object message, java.lang.Throwable t);

   /**
    * True if the debug level is enabled
    * @return boolean
    */
   public boolean isDebugEnabled();

   /**
    * True if the error level is enabled
    * @return boolean
    */
   public boolean isErrorEnabled();

   /**
    * True if the fatal level is enabled
    * @return boolean
    */
   public boolean isFatalEnabled();

   /**
    * True if the info level is enabled
    * @return boolean
    */
   public boolean isInfoEnabled();

   /**
    * True if the trace level is enabled
    * @return boolean
    */
   public boolean isTraceEnabled();

   /**
    * True if the warn level is enabled
    * @return boolean
    */
   public boolean isWarnEnabled();

   /**
    * True if the audit level is enabled
    * @return boolean
    */
   public boolean isAuditEnabled();

   /**
    * Throws a trace message
    * @param message the message
    */
   public void trace(java.lang.Object message);

   /**
    * Throws a trace message
    * @param message the message
    * @param t an inner error
    */
   public void trace(java.lang.Object message, java.lang.Throwable t);

   /**
    * Throws a warn message
    * @param message the message
    */
   public void warn(java.lang.Object message);

   /**
    * Throws a warn message
    * @param message the message
    * @param t an inner error
    */
   public void warn(java.lang.Object message, java.lang.Throwable t);

   /**
    * Inserts context information into this log
    * @param key the key of the information
    * @param object the value of the information
    */
   public void putInContext(String key, Object object);

   /**
    * Gets context information
    * @param key the key of the information to be retrieved
    * @return java.lang.Object
    */
   public Object getFromContext(String key);

   /**
    * Removes context information for the current thread
    *
    */
   public void removeContext();
}
