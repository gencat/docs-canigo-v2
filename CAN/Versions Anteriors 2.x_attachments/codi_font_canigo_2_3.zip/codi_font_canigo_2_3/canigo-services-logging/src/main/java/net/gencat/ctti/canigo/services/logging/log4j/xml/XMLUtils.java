package net.gencat.ctti.canigo.services.logging.log4j.xml;

public class XMLUtils {

	/**
	 * Left angle bracket xml escape.
	 */
	public static final String LT_ESCAPE = "&lt;";

	/**
	 * Left angle bracket xml escape length.
	 */
	public static final int LT_ESCAPE_LEN = LT_ESCAPE.length();

	/**
	 * Left angle bracket xml escape character array.
	 */
	public static final char[] LT_ESCAPE_ARRAY = LT_ESCAPE.toCharArray();

	/**
	 * Xml escape for right angle bracket.
	 */
	public static final String GT_ESCAPE = "&gt;";

	/**
	 * Right angle bracket xml escape string length.
	 */
	public static final int GT_ESCAPE_LEN = GT_ESCAPE.length();

	/**
	 * Right angle bracket xml escape character array.
	 */
	public static final char[] GT_ESCAPE_ARRAY = GT_ESCAPE.toCharArray();

	public static final char AMP = '&';

	public static final String AMP_ESCAPE = "&amp;";

	public static final int AMP_ESCAPE_LEN = AMP_ESCAPE.length();

	public static final char[] AMP_ESCAPE_ARRAY = AMP_ESCAPE.toCharArray();

	/**
	 * Xml escape for double quote.
	 */
	public static final String QUOT_ESCAPE = "&quot;";

	/**
	 * Double quote xml escape string length.
	 */
	public static final int QUOT_ESCAPE_LEN = QUOT_ESCAPE.length();

	/**
	 * Double quote xml escape character array.
	 */
	public static final char[] QUOT_ESCAPE_ARRAY = QUOT_ESCAPE.toCharArray();

	/**
	 * Single quote.
	 */
	public static final char APOS = '\'';

	/**
	 * Xml escape for single quote.
	 */
	public static final String APOS_ESCAPE = "&apos;";

	/**
	 * Single quote xml escape string length.
	 */
	public static final int APOS_ESCAPE_LEN = APOS_ESCAPE.length();

	/**
	 * Single quote xml escape character array.
	 */
	public static final char[] APOS_ESCAPE_ARRAY = APOS_ESCAPE.toCharArray();

	/**
	 * Slash GT
	 */
	public static final String SGT = "/>";

	/**
	 * LT Slash
	 */
	public static final String LTS = "</";

	/**
	 * Xml header.
	 */
	public static final String XML_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

	/**
	 * Escape xml constants characters
	 * 
	 * @param v
	 * @return
	 */
	public static String xmlEscape(final String v) {
		StringBuffer builder = new StringBuffer(v.length());
		for (int i = 0; i < v.length(); i++) {
			char ch = v.charAt(i);
			switch (ch) {
			case StringConstants.LT:
				builder.append(LT_ESCAPE_ARRAY);
				break;
			case StringConstants.GT:
				builder.append(GT_ESCAPE_ARRAY);
				break;
			case AMP:
				builder.append(AMP_ESCAPE_ARRAY);
				break;
			case StringConstants.QUOT:
				builder.append(QUOT_ESCAPE_ARRAY);
				break;
			case APOS:
				builder.append(APOS_ESCAPE_ARRAY);
				break;
			default:
				builder.append(ch);
			}
		}
		return builder.toString();
	}

}
