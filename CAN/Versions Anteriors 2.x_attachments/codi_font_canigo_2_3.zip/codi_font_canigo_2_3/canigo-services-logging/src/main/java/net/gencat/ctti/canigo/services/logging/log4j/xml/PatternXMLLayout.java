/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging.log4j.xml;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import net.gencat.ctti.canigo.core.threadlocal.ThreadLocalProperties;
import net.gencat.ctti.canigo.services.logging.BaseLoggingObject;

import org.apache.log4j.Layout;
import org.apache.log4j.MDC;
import org.apache.log4j.helpers.PatternConverter;
import org.apache.log4j.helpers.Transform;
import org.apache.log4j.spi.LoggingEvent;


/**
 * Pattern XML Layout to be used as generator of XML logs.
 * @author EVC
 */
public class PatternXMLLayout extends Layout {
   /** Default pattern string for log output. Currently set to the
    string <b>"%m%n"</b> which just prints the application supplied
    message. */
   public static final String DEFAULT_CONVERSION_PATTERN = "%m%n";

   /** A conversion pattern equivalent to the TTCCCLayout.
    Current value is <b>%r [%t] %p %c %x - %m%n</b>. */
   public static final String TTCC_CONVERSION_PATTERN = "%r [%t] %p %c %x - %m%n";

   /**
    * Documentaci�.
    */
   public static final int DEFAULT_TAB_LEVEL = 1;

   //public final static String LOG4J = "log4j:";
   /**
    * Documentaci�.
    */
   public static final String EQUAL = "=";

   /**
    * Documentaci�.
    */
   public static final String BASE_THREAD_LOCAL_TOKEN = "$";

   /**
    * Documentaci�.
    */
   public static final String PARAMETERS_TOKEN = "@";

   /**
    * Documentaci�.
    */
   public static String END_OF_LINE = "\r\n";

   /**
    * Documentaci�.
    */
   public String namespace = "";

   /**
    * Documentaci�.
    */
   public String nodename = "event";

   /**
    * Documentaci�.
    */
   protected final int BUF_SIZE = 512;

   /**
    * Documentaci�.
    */
   protected final int EXCEPTION_DEF_SIZE = 256;

   /**
    * Documentaci�.
    */
   protected final int MAX_CAPACITY = 1024;

   /**
    * Documentaci�.
    */
   private Map cdataNodes = new HashMap();

   /**
    * Documentaci�.
    */
   private PatternConverter attrhead;

   /**
    * Documentaci�.
    */
   private PatternConverter nodeshead;

   /**
    * Documentaci�.
    */
   private String attrpattern;

   /**
    * Documentaci�.
    */
   private String attrvaluepairdelim;

   /**
    * Documentaci�.
    */
   private String attrvardelim;

   /**
    * Documentaci�.
    */
   private String nodespattern;

   /**
    * Documentaci�.
    */
   private String nodesvaluepairdelim;

   /**
    * Documentaci�.
    */
   private String nodesvardelim;

   /**
    * Documentaci�.
    */
   private String throwable;

   /**
    * Documentaci�.
    */
   private String timezone;

   /**
    * Documentaci�.
    */
   private StringBuffer buf = new StringBuffer(BUF_SIZE);

   // output buffer appended to when format() is invoked
   /**
    * Documentaci�.
    */
   private StringBuffer sbuf = new StringBuffer(BUF_SIZE);

   /**
    * Documentaci�.
    */
   private boolean eol = true;

   /**
    * Documentaci�.
    */
   private int exceptionmaxlength = EXCEPTION_DEF_SIZE;

   //private boolean shownamespace = false;

   /**
    Constructs a PatternLayout using the DEFAULT_LAYOUT_PATTERN.
   
    The default pattern just produces the application supplied message.
    */
   public PatternXMLLayout() {
      this(DEFAULT_CONVERSION_PATTERN);
   }

   /**
    Constructs a PatternLayout using the supplied conversion pattern.
    */
   public PatternXMLLayout(String pattern) {
      this.attrpattern = pattern;
      attrhead = createPatternParser((pattern == null)
            ? DEFAULT_CONVERSION_PATTERN : pattern).parse();
   }

   /**
    Set the <b>ConversionPattern</b> option. This is the string which
    controls formatting and consists of a mix of literal content and
    conversion specifiers.
    */
   public void setAttrConversionPattern(String conversionPattern) {
      attrpattern = conversionPattern;
      attrhead = createPatternParser(conversionPattern).parse();
   }

   /**
    Returns the value of the <b>ConversionPattern</b> option.
    */
   public String getAttrConversionPattern() {
      return attrpattern;
   }

   /**
    * Documentaci�.
    *
    * @param conversionPattern Documentaci�
    */
   public void setNodesConversionPattern(String conversionPattern) {
      nodespattern = conversionPattern;
      nodeshead = createPatternParser(conversionPattern).parse();
   }

   /**
    Returns the value of the <b>ConversionPattern</b> option.
    */
   public String getNodesConversionPattern() {
      return nodespattern;
   }

   /**
    * Documentaci�.
    *
    * @param nameSpace Documentaci�
    */
   public void setNameSpace(String nameSpace) {
      if ((nameSpace != null) && (nameSpace.length() > 0)) {
         namespace = nameSpace + ":";
      }
   }

   /**
    * Documentaci�.
    *
    * @param nodeName Documentaci�
    */
   public void setNodeName(String nodeName) {
      if ((nodeName != null) && (nodeName.length() > 0)) {
         nodename = nodeName;
      }
   }

   /**
    * Documentaci�.
    *
    * @param valuePairDelim Documentaci�
    */
   public void setAttrValuePairDelim(String valuePairDelim) {
      attrvaluepairdelim = valuePairDelim;
   }

   /**
    * Documentaci�.
    *
    * @param varDelim Documentaci�
    */
   public void setAttrVarDelim(String varDelim) {
      attrvardelim = varDelim;

      if (attrpattern != null) {
         attrhead = createPatternParser(attrpattern).parse();
      }
   }

   /**
    * Documentaci�.
    *
    * @param nodesValuePairDelim Documentaci�
    */
   public void setNodesValuePairDelim(String nodesValuePairDelim) {
      nodesvaluepairdelim = nodesValuePairDelim;
   }

   /**
    * Documentaci�.
    *
    * @param nodesVarDelim Documentaci�
    */
   public void setNodesVarDelim(String nodesVarDelim) {
      nodesvardelim = nodesVarDelim;

      if (nodespattern != null) {
         nodeshead = createPatternParser(nodespattern).parse();
      }
   }

   /**
    * Documentaci�.
    *
    * @param throwableValue Documentaci�
    */
   public void setThrowable(String throwableValue) {
      throwable = throwableValue;
   }

   /**
    * Documentaci�.
    *
    * @param length Documentaci�
    */
   public void setExceptionMaxLength(int length) {
      exceptionmaxlength = length;
   }

   /**
    Does not do anything as options become effective
    */
   public void activateOptions() {
      // nothing to do.
   }

   /**
    The PatternLayout does not handle the throwable contained within
    {@link LoggingEvent LoggingEvents}. Thus, it returns
    <code>true</code>.
    */
   public boolean ignoresThrowable() {
      return false;
   }

   /**
    Returns PatternParser used to parse the conversion string. Subclasses
    may override this to return a subclass of PatternParser which recognize
    custom conversion characters.
   
    @since 0.9.0
    */
   protected PatternParser createPatternParser(String pattern) {
      return new PatternParser(pattern, nodesvardelim);
   }

   /**
    Produces a formatted string as specified by the conversion pattern.
    */
   public String format(LoggingEvent event) {
      Object message = event.getMessage();

      //		if (message instanceof BaseLoggingObject) {
      //		BaseLoggingObject loggingObject = (BaseLoggingObject)message;
      //		params = loggingObject.getParams();
      //		}

      // Reset working stringbuffer
      if (sbuf.capacity() > MAX_CAPACITY) {
         sbuf = new StringBuffer(BUF_SIZE);
      } else {
         sbuf.setLength(0);
      }

      //System.out.println("className:"+event.getClass().getName());
      buf = new StringBuffer();

      /***Start Event Tag***/
      sbuf.append("<");
      sbuf.append(namespace);
      sbuf.append(nodename);

      PatternConverter c = attrhead;

      while (c != null) {
         c.format(buf, event);
         c = c.next;
      }

      parseAttributes(buf);
      sbuf.append(">");

      if (isEol()) {
         sbuf.append(END_OF_LINE);
      }

      buf = new StringBuffer();

      c = nodeshead;

      List nodeValues = new ArrayList();

      while (c != null) {
         StringBuffer value = new StringBuffer();
         c.format(value, event);
         nodeValues.add(value.toString());
         c = c.next;
      }

      parseNodes(nodeValues);

      if (isEol()) {
         sbuf.append(END_OF_LINE);
      }

      /***Throwable***/
      if ((throwable != null) && (throwable.length() > 0)) {
         String[] s = ((LoggingEvent) event).getThrowableStrRep();

         if (s != null) {
            StringBuffer throwableSB = new StringBuffer();

            if (isEol()) {
               sbuf.append("\t");
            }

            sbuf.append("<");
            sbuf.append(namespace);
            sbuf.append(throwable);
            sbuf.append("><![CDATA[");

            for (int i = 0; i < s.length; i++) {
               throwableSB.append(s[i]);
               throwableSB.append(END_OF_LINE);
               throwableSB.append("\t");
            }

            if (throwableSB.length() > exceptionmaxlength) {
               sbuf.append(throwableSB.substring(0, exceptionmaxlength - 3) +
                  "...");
            } else {
               sbuf.append(throwableSB);
            }

            sbuf.append("]]>");

            if (isEol()) {
               sbuf.append(END_OF_LINE);
            }

            if (isEol()) {
               sbuf.append("\t");
            }

            sbuf.append("</");
            sbuf.append(namespace);
            sbuf.append(throwable);
            sbuf.append(">");

            if (isEol()) {
               sbuf.append(END_OF_LINE);
            }
         }
      }

      /***End Event Tag***/
      if (isEol()) {
         sbuf.append(END_OF_LINE);
      }

      sbuf.append("</");
      sbuf.append(namespace);
      sbuf.append(nodename);
      sbuf.append(">");
      sbuf.append(END_OF_LINE);

      return sbuf.toString();
   }

   /**
    * Documentaci�.
    *
    * @param sb Documentaci�
    */
   public void parseAttributes(StringBuffer sb) {
      StringTokenizer tokens = new StringTokenizer(sb.toString(), attrvardelim);
      StringTokenizer tokensInner = null;

      sb = new StringBuffer();

      while (tokens.hasMoreTokens()) {
         tokensInner = new StringTokenizer(tokens.nextToken(),
               attrvaluepairdelim);
         setAttribute(tokensInner.nextToken(), tokensInner.nextToken());
      }
   }

   /**
    * Documentaci�.
    *
    * @param nodeValues Documentaci�
    */
   public void parseNodes(List nodeValues) {
      Iterator it = nodeValues.iterator();

      while (it.hasNext()) {
         String nodeName = (String) it.next();
         String nodeValue = it.hasNext() ? (String) it.next() : null;
         StringTokenizer st = new StringTokenizer(nodeName, this.nodesvardelim);

         while (st.hasMoreTokens()) {
            String token = st.nextToken();

            if (!"".equals(token)) {
               StringTokenizer st2 = new StringTokenizer(token,
                     this.nodesvaluepairdelim);

               if (st2.countTokens() > 1) {
                  while (st2.hasMoreTokens()) {
                     // Literales
                     String innerNodeName = st2.nextToken();
                     String innerNodeValue = st2.hasMoreTokens()
                        ? st2.nextToken() : "";
                     setNode(innerNodeName, innerNodeValue);
                  }
               } else {
                  int end = token.indexOf(this.nodesvaluepairdelim);

                  if (end > 0) {
                     token = token.substring(0, end);
                  }

                  setNode(token, nodeValue);
               }
            }
         }
      }
   }

   /**
    * Documentaci�.
    */
   public void setMDC() {
      /***MDC***/
      Hashtable mdc = MDC.getContext();

      if (mdc != null) {
         Set keyset = mdc.keySet();

         Iterator iterator = keyset.iterator();

         while (iterator.hasNext()) {
            Object key = iterator.next();
            String value = (String) mdc.get(key);

            setNode(key.toString(), replaceSpecialCharacters(value));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param key Documentaci�
    * @param value Documentaci�
    */
   public void setAttribute(String key, String value) {
      setAttribute(key, value, DEFAULT_TAB_LEVEL);
   }

   /**
    * Documentaci�.
    *
    * @param nodeName Documentaci�
    * @param value Documentaci�
    */
   public void setNode(String nodeName, String value) {
      setNode(nodeName, value, DEFAULT_TAB_LEVEL);
   }

   /**
    * Documentaci�.
    *
    * @param key Documentaci�
    * @param value Documentaci�
    * @param level Documentaci�
    */
   public void setAttribute(String key, String value, int level) {
      if (isEol()) {
         sbuf.append(END_OF_LINE);
      }

      for (int i = 1; i <= level; i++) {
         if (isEol()) {
            sbuf.append("\t");
         }
      }

      sbuf.append(key);
      sbuf.append(EQUAL);
      sbuf.append("\"");
      sbuf.append(value);
      sbuf.append("\"");
   }

   /**
    * Documentaci�.
    *
    * @param nodeName Documentaci�
    * @param value Documentaci�
    * @param level Documentaci�
    */
   public void setNode(String nodeName, String value, int level) {
      if (isEol()) {
         sbuf.append(END_OF_LINE);
      }

      for (int i = 1; i <= level; i++) {
         if (isEol()) {
            sbuf.append("\t");
         }
      }

      sbuf.append("<");
      sbuf.append(namespace);
      sbuf.append(nodeName);
      sbuf.append(">");

      if (this.cdataNodes.containsKey(nodeName)) {
         StringBuffer escapedCDATA = new StringBuffer();
         Transform.appendEscapingCDATA(escapedCDATA, value);
         sbuf.append("<![CDATA[" + escapedCDATA + "]]>");
      } else {
         sbuf.append(XMLUtils.xmlEscape(value));
      }

      sbuf.append("</");
      sbuf.append(namespace);
      sbuf.append(nodeName);
      sbuf.append(">");
   }

   /**
    * Documentaci�.
    *
    * @param str Documentaci�
    *
    * @return Documentaci�
    */
   public String replaceSpecialCharacters(String str) {
      str = replaceStr(str, "�", "&lsquo;");
      str = replaceStr(str, "�", "&rsquo;");
      str = replaceStr(str, "�", "&sbquo;");
      str = replaceStr(str, "�", "&ldquo;");
      str = replaceStr(str, "�", "&rdquo;");
      str = replaceStr(str, "�", "&bdquo;");
      str = replaceStr(str, "&", "&amp;");
      str = replaceStr(str, "\"", "&quot;");
      str = replaceStr(str, "<", "&lt;");
      str = replaceStr(str, ">", "&gt;");
      str = replaceStr(str, "'", "&apos;");

      return str;
   }

   /**
    * Documentaci�.
    *
    * @param str Documentaci�
    * @param strToReplace Documentaci�
    * @param strReplace Documentaci�
    *
    * @return Documentaci�
    */
   public String replaceStr(String str, String strToReplace, String strReplace) {
      int pos = str.indexOf(strToReplace);

      if (pos != -1) {
         str = str.substring(0, pos) + strReplace +
            str.substring(pos + strToReplace.length(), str.length());
      }

      return str;
   }

   /**
    * @return Returns the eof.
    */
   public boolean isEol() {
      return eol;
   }

   /**
    * @param eof The eof to set.
    */
   public void setEol(boolean eof) {
      this.eol = eof;
   }

   /**
    * Documentaci�.
    *
    * @param eof Documentaci�
    */
   public void setEof(String eof) {
      try {
         this.eol = new Boolean(eof).booleanValue();
      } catch (Exception ex) {
         this.eol = true;
      }
   }

   /**
    * @param cdataNodes The cdataNodes to set.
    */
   public void setCdataNodes(String cdataNodes) {
      StringTokenizer st = new StringTokenizer(cdataNodes, ",");
      int i = 0;

      while (st.hasMoreTokens()) {
         this.cdataNodes.put(st.nextToken(), new Integer(i++));
      }
   }
}
