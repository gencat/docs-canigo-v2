/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging.log4j.xml;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;

import net.gencat.ctti.canigo.services.logging.LogConfigurator;

import org.apache.log4j.xml.DOMConfigurator;


/**
 * Configures the logging service with a file name suffixed by the host name the service is installed on
 */
public class HostDOMConfigurator extends DOMConfigurator
   implements LogConfigurator {
   /**
    * Documentaci�.
    */
   public static String CLASSPATH_PREFIX = "classpath:";

   /**
    * Configuration file name
    */
   private String configFileName;

   /**
    * True if this cofigurator has been configured
    */
   private boolean configured = false;

   /**
    * Default constructor
    *
    */
   public HostDOMConfigurator() {
      super();
   }

   /**
    * Constructor based on the file name
    * @param aConfigFileName the file name
    */
   public HostDOMConfigurator(String aConfigFileName) {
      super();
      configFileName = aConfigFileName;
   }

   /**
    * Initialization method
    */
   public void init() {
      // Before to proceed concat to filename host name
      // Obtain host Name
      String hostName;
      String lastFilename = configFileName;

      InetAddress localHost = null;

      try {
         localHost = InetAddress.getLocalHost();
         hostName = new String(localHost.getHostName());
         lastFilename = lastFilename + "." + hostName;
      } catch (UnknownHostException e) {
         //error message
      }

      if (lastFilename.startsWith(CLASSPATH_PREFIX)) {
         String configFileNameClasspath = lastFilename.substring(lastFilename.indexOf(
                  CLASSPATH_PREFIX) + CLASSPATH_PREFIX.length());
         URL url = this.getClass().getClassLoader()
                       .getResource(configFileNameClasspath);

         if (url == null) { // probably not found configFileName with host, try to get the base file
            configFileNameClasspath = configFileName.substring(configFileName.indexOf(
                     CLASSPATH_PREFIX) + CLASSPATH_PREFIX.length());
            url = this.getClass().getClassLoader()
                      .getResource(configFileNameClasspath);

            if (url != null) {
               lastFilename = url.getPath();
            }
         } else {
            lastFilename = url.getPath();
         }

         if (url != null) {
            System.out.println("Log4j resource is " + url);

            if (lastFilename.indexOf(".war!") != -1) {
               configure(url);
            } else {
               configureAndWatch(lastFilename);
            }

            this.configFileName = lastFilename;
            this.configured = true;
         } else {
            System.out.println("WARN: log4j config file not found!");
            this.configFileName = null;
            this.configured = false;
         }
      } else {
         System.out.println("Log4j resource is " + lastFilename);
         configureAndWatch(lastFilename);
         this.configFileName = lastFilename;
         this.configured = true;
      }
   }

   /**
    * Getter
    * @return string
    */
   public String getConfigFileName() {
      return configFileName;
   }

   /**
    * Setter
    * @param configFileName the config file name
    */
   public void setConfigFileName(String configFileName) {
      this.configFileName = configFileName;
   }

   /**
    * Getter
    * @return true if this configurator is configured
    */
   public boolean isConfigured() {
      return configured;
   }

   /**
    * Setter
    * @param configured
    */
   public void setConfigured(boolean configured) {
      this.configured = configured;
   }
}
