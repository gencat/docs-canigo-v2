/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging.log4j.xml.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.logging.log4j.xml.impl.TrazaCtti;


/**
 * Reads a XML file from PatternXMLLayout that is not well formed
 * @author MMR
 *
 */
public class PatternXMLLayoutReader extends InputStreamReader {
   /**
    * The logging service
    */
   private LoggingService logService = null;

   /**
    * Documentaci�.
    */
   private String xmlFooter = TrazaCtti.XML_FOOTER;

   /**
    * Documentaci�.
    */
   private String xmlHeader = TrazaCtti.XML_HEADER;

   /**
    * Documentaci�.
    */
   private boolean fileConsumed = false;

   /**
    * Documentaci�.
    */
   private int lengthPendingToReadFromFooter = TrazaCtti.XML_FOOTER.length();

   /**
    * Documentaci�.
    */
   private int lengthPendingToReadFromHeader = TrazaCtti.XML_HEADER.length();

   /**
    * Constructor
    * @param file
    * @throws FileNotFoundException
    * @throws UnsupportedEncodingException
    */
   public PatternXMLLayoutReader(File file)
      throws FileNotFoundException, UnsupportedEncodingException {
      super(new FileInputStream(file), TrazaCtti.XML_ENCODING);
   }

   /**
    * @return Returns the logService.
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * @param logService The logService to set.
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * Reads a well formed XML
    */
   public int read(char[] cbuf, int offset, int length)
      throws IOException {
      this.logService.getLog(this.getClass())
                     .debug("reading into buffer,offset=" + offset +
         ",length=" + length + ",lengthPendingToReadFromHeader=" +
         this.lengthPendingToReadFromHeader +
         ",lengthPendingToReadFromFooter=" + lengthPendingToReadFromFooter);

      if (this.lengthPendingToReadFromHeader > 0) {
         if (this.lengthPendingToReadFromHeader <= length) {
            this.logService.getLog(this.getClass()).debug("consuming all header");

            int srcStart = this.xmlHeader.length() -
               this.lengthPendingToReadFromHeader;
            int srcEnd = srcStart + this.lengthPendingToReadFromHeader;
            int readedFromString = this.lengthPendingToReadFromHeader;
            this.lengthPendingToReadFromHeader = 0;
            this.xmlHeader.getChars(srcStart, srcEnd, cbuf, offset);

            return readedFromString;
         } else {
            this.logService.getLog(this.getClass())
                           .debug("consuming partial header");

            int srcStart = this.xmlHeader.length() -
               this.lengthPendingToReadFromHeader;
            int srcEnd = srcStart + length;
            this.lengthPendingToReadFromHeader = this.lengthPendingToReadFromHeader -
               length;
            this.xmlHeader.getChars(srcStart, srcEnd, cbuf, offset);

            return length;
         }
      } else {
         if (!this.fileConsumed) {
            this.logService.getLog(this.getClass())
                           .debug("file is not consumed!");

            int fromFile = super.read(cbuf, offset, length);

            if (fromFile == -1) {
               this.fileConsumed = true;

               return 0;
            } else {
               return fromFile;
            }
         } else {
            if (this.lengthPendingToReadFromFooter > 0) {
               if (this.lengthPendingToReadFromFooter <= length) {
                  this.logService.getLog(this.getClass())
                                 .debug("consuming all footer");

                  int srcStart = this.xmlFooter.length() -
                     this.lengthPendingToReadFromFooter;
                  int srcEnd = srcStart + this.lengthPendingToReadFromFooter;
                  int readedFromString = this.lengthPendingToReadFromFooter;
                  this.lengthPendingToReadFromFooter = 0;
                  this.xmlFooter.getChars(srcStart, srcEnd, cbuf, offset);

                  return readedFromString;
               } else {
                  this.logService.getLog(this.getClass())
                                 .debug("consuming partial footer");

                  int srcStart = this.xmlHeader.length() -
                     this.lengthPendingToReadFromFooter;
                  int srcEnd = srcStart + length;
                  this.lengthPendingToReadFromFooter = this.lengthPendingToReadFromFooter -
                     length;
                  this.xmlFooter.getChars(srcStart, srcEnd, cbuf, offset);

                  return length;
               }
            } else {
               this.logService.getLog(this.getClass()).debug("end of stream!");

               return -1;
            }
         }
      }
   }
}
