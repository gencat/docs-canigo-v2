/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.portlets.struts;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.UnavailableException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.gencat.ctti.canigo.services.web.spring.util.WebApplicationContextUtils;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.portals.bridges.struts.StrutsPortlet;
import org.apache.portals.bridges.struts.StrutsPortletRenderContext;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.PlugIn;
import org.apache.struts.config.ModuleConfig;
import org.apache.struts.config.PlugInConfig;
import org.apache.struts.tiles.TilesPlugin;
import org.apache.struts.util.RequestUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class PortletServlet extends org.apache.portals.bridges.struts.PortletServlet {
   /**
    * Documentaci�.
    */
   private static final Log log = LogFactory.getLog(PortletServlet.class);

   /**
    * Documentaci�.
    *
    * @param config Documentaci�
    *
    * @throws ServletException Documentaci�
    * @throws UnavailableException Documentaci�
    */
   protected void initModulePlugIns(ModuleConfig config)
      throws ServletException {
      boolean needTilesProcessor = false;
      PlugInConfig[] plugInConfigs = config.findPlugInConfigs();

      for (int i = 0; !needTilesProcessor && (i < plugInConfigs.length); i++) {
         Class pluginClass = null;

         try {
            pluginClass = RequestUtils.applicationClass(plugInConfigs[i].getClassName());
         } catch (ClassNotFoundException ex) {
            log.fatal("Can't load Plugin class: bad class name '" +
               plugInConfigs[i].getClassName() + "'.");
            throw new ServletException(ex);
         }

         if (TilesPlugin.class.isAssignableFrom(pluginClass)) {
            needTilesProcessor = true;
         }
      }

      String processorClassName = config.getControllerConfig()
                                        .getProcessorClass();
      Class processorClass = null;

      try {
         processorClass = RequestUtils.applicationClass(processorClassName);
      } catch (ClassNotFoundException ex) {
         log.fatal("Can't load Plugin class: bad class name '" +
            processorClass + "'.");
         throw new ServletException(ex);
      }

      if (log.isDebugEnabled()) {
         log.debug("Initializing module path '" + config.getPrefix() +
            "' plug ins");
      }

      plugInConfigs = config.findPlugInConfigs();

      PlugIn[] plugIns = new PlugIn[plugInConfigs.length];

      getServletContext()
         .setAttribute(Globals.PLUG_INS_KEY + config.getPrefix(), plugIns);

      for (int i = 0; i < plugIns.length; i++) {
         try {
            plugIns[i] = (PlugIn) RequestUtils.applicationInstance(plugInConfigs[i].getClassName());
            BeanUtils.populate(plugIns[i], plugInConfigs[i].getProperties());

            // Pass the current plugIn config object to the PlugIn.
            // The property is set only if the plugin declares it.
            // This plugin config object is needed by Tiles
            try {
               PropertyUtils.setProperty(plugIns[i],
                  "currentPlugInConfigObject", plugInConfigs[i]);
            } catch (Exception e) {
               // FIXME Whenever we fail silently, we must document a valid reason
               // for doing so.  Why should we fail silently if a property can't be set on
               // the plugin?
               /**
                * Between version 1.138-1.140 cedric made these changes.
                * The exceptions are caught to deal with containers applying strict security.
                * This was in response to bug #15736
                *
                * Recommend that we make the currentPlugInConfigObject part of the PlugIn Interface if we can, Rob
                */
            }

            plugIns[i].init(this, config);
         } catch (ServletException e) {
            throw e;
         } catch (Exception e) {
            String errMsg = internal.getMessage("plugIn.init",
                  plugInConfigs[i].getClassName());

            log(errMsg, e);
            throw new UnavailableException(errMsg);
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param response Documentaci�
    * @param mapping Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    * @throws ServletException Documentaci�
    */
   public boolean performActionRenderRequest(HttpServletRequest request,
      HttpServletResponse response, ActionMapping mapping)
      throws IOException, ServletException {
      if (!request.getAttribute(StrutsPortlet.REQUEST_TYPE)
                     .equals(StrutsPortlet.ACTION_REQUEST)) {
         StrutsPortletRenderContext context = null;

         String portletName = (String) request.getAttribute(StrutsPortlet.PORTLET_NAME);

         String contextKey = StrutsPortlet.RENDER_CONTEXT + "_" + portletName;
         context = (StrutsPortletRenderContext) request.getSession(true)
                                                       .getAttribute(contextKey);

         if (context != null) {
            if (log.isDebugEnabled()) {
               log.debug("render context path: " + context.getPath());
            }

            request.getSession().removeAttribute(contextKey);

            if (context.getActionForm() != null) {
               String attribute = mapping.getAttribute();

               if (attribute != null) {
                  if (log.isDebugEnabled()) {
                     log.debug("Putting form " +
                        context.getActionForm().getClass().getName() +
                        " into request as " + attribute + " for mapping " +
                        mapping.getName());
                  }

                  request.setAttribute(mapping.getAttribute(),
                     context.getActionForm());
               } else if (log.isWarnEnabled()) {
                  log.warn("Attribute is null for form " +
                     context.getActionForm().getClass().getName() +
                     ", won't put it into request for mapping " +
                     mapping.getName());
               }
            }

            if (context.isRequestCancelled()) {
               request.setAttribute(Globals.CANCEL_KEY, Boolean.TRUE);
            }

            if (context.getMessages() != null) {
               request.setAttribute(Globals.MESSAGE_KEY, context.getMessages());
            }

            if (context.getErrors() != null) {
               request.setAttribute(Globals.ERROR_KEY, context.getErrors());
            }

            RequestDispatcher dispatcher = null;

            if (context.getDispatchNamed()) {
               dispatcher = getServletContext()
                               .getNamedDispatcher(context.getPath());
            } else {
               dispatcher = getServletContext()
                               .getRequestDispatcher(context.getPath());
            }

            dispatcher.include(request,
               new WrappedHttpServletResponse(request, response));

            return true;
         }
      }

      return false;
   }
}
