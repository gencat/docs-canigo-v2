/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.portlets;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.gencat.ctti.canigo.services.portlets.struts.FilterInterceptor;
import net.gencat.ctti.canigo.services.portlets.struts.WrappedHttpServletResponse;


import org.apache.portals.bridges.struts.PortletServlet;
import org.apache.portals.bridges.struts.PortletServletRequestWrapper;
import org.apache.portals.bridges.struts.StrutsPortlet;
import org.springframework.web.servlet.HandlerAdapter;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.3 $
  */
public class DispatcherServlet extends net.gencat.ctti.canigo.services.web.spring.servlet.DispatcherServlet {
   /**
    * Documentaci�.
    */
   boolean isInited = false;

   /**
    * Documentaci�.
    */
   private HandlerAdapterWithFilters interceptor = new HandlerAdapterWithFilters();

   /**
    * Documentaci�.
    */
   private HandlerInterceptor interceptors;

   /**
    * Documentaci�.
    *
    * @param handler Documentaci�
    *
    * @return Documentaci�
    *
    * @throws ServletException Documentaci�
    */
   protected HandlerAdapter getHandlerAdapter(Object handler)
      throws ServletException {
      interceptor.setHandler(handler);

      return interceptor;
   }

   /**
    * Documentaci�.
    */
   private void initInterceptors() {
      Map filters = getWebApplicationContext()
                       .getBeansOfType(FilterInterceptor.class);

      if (filters.size() == 0) {
         return;
      }

      List sortedInterceptors = new ArrayList(filters.values());
      sortInterceptors(sortedInterceptors);
      configureInterceptors(sortedInterceptors);

      FilterInterceptor filter = (FilterInterceptor) sortedInterceptors.get(sortedInterceptors.size() -
            1);

      if (filter != null) {
         filter.setNextInterceptor(interceptor);
      }

      interceptors = (FilterInterceptor) sortedInterceptors.get(0);
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    *
    * @return Documentaci�
    */
   private HttpServletRequest patchPortletRequest(HttpServletRequest request) {
      if (request instanceof PortletServletRequestWrapper) {
         request = new PortletServletRequestWrapper(request.getSession()
                                                           .getServletContext(),
               request) {
                  public String getServletPath() {
                     String tmpPath = super.getServletPath();

                     if (!tmpPath.startsWith(getContextPath())) {
                        tmpPath = getContextPath() +
                           (tmpPath.startsWith("/") ? "" : "/") + tmpPath;
                     }

                     return tmpPath;
                  }
               };
      }

      return request;
   }

   /**
    * Documentaci�.
    *
    * @param sortedInterceptors Documentaci�
    */
   private void configureInterceptors(List sortedInterceptors) {
      Iterator iter = sortedInterceptors.iterator();
      boolean doNext = true;
      FilterInterceptor filter = null;

      while (iter.hasNext()) {
         if (doNext) {
            filter = (FilterInterceptor) iter.next();
         }

         if (iter.hasNext()) {
            FilterInterceptor next = (FilterInterceptor) iter.next();
            filter.setNextInterceptor(next);
            filter = next;
            doNext = false;
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param sortedInterceptors Documentaci�
    */
   private void sortInterceptors(List sortedInterceptors) {
      Collections.sort(sortedInterceptors,
         new Comparator() {
            private Integer getOrder(Object f) {
               if (f instanceof FilterInterceptor) {
                  FilterInterceptor filter = (FilterInterceptor) f;

                  return new Integer(filter.getOrder());
               }

               return new Integer(-1);
            }

            public int compare(Object o1, Object o2) {
               if (o1 instanceof FilterInterceptor &&
                     o2 instanceof FilterInterceptor) {
                  return (getOrder(o1)).compareTo(getOrder(o2));
               }

               return 0;
            }
         });
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.3 $
     */
   class HandlerAdapterWithFilters extends HandlerInterceptorAdapter
      implements HandlerAdapter {
      /**
       * Documentaci�.
       */
      private static final String FILTERS_ALREADY_APPLIED_KEY = "__PORTLET_FILTERS_ALREADY_APPLIED__";

      /**
       * Documentaci�.
       */
      private HandlerAdapter adapter;

      /**
       * Documentaci�.
       */
      private ModelAndView result;

      /**
       * Documentaci�.
       */
      private Object handler;

      /**
       * Documentaci�.
       *
       * @param request Documentaci�
       * @param response Documentaci�
       * @param handler Documentaci�
       *
       * @return Documentaci�
       *
       * @throws Exception Documentaci�
       */
      public boolean preHandle(HttpServletRequest request,
         HttpServletResponse response, Object handler)
         throws Exception {
         result = adapter.handle(request, response, getHandler());

         return true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public ModelAndView getResult() {
         return result;
      }

      /**
       * Documentaci�.
       *
       * @param result Documentaci�
       */
      public void setResult(ModelAndView result) {
         this.result = result;
      }

      /**
       * Documentaci�.
       *
       * @param request Documentaci�
       * @param handler Documentaci�
       *
       * @return Documentaci�
       */
      public long getLastModified(HttpServletRequest request, Object handler) {
         return adapter.getLastModified(request, handler);
      }

      /**
       * Documentaci�.
       *
       * @param request Documentaci�
       * @param response Documentaci�
       * @param handler Documentaci�
       *
       * @return Documentaci�
       *
       * @throws Exception Documentaci�
       * @throws ServletException Documentaci�
       */
      public ModelAndView handle(HttpServletRequest request,
         HttpServletResponse response, Object handler)
         throws Exception {
         if (!isInited) {
            isInited = true;
            initInterceptors();
         }

         if ((getWebApplicationContext() == null) || (interceptors == null)) {
            return adapter.handle(request, response, handler);
         }

         try {
            // request = patchPortletRequest(request);
            if (PortletServlet.isPortletRequest(request)) {
               response = WrappedHttpServletResponse.ensureWrappedResponse(request,
                     response);

               if (request.getAttribute(FILTERS_ALREADY_APPLIED_KEY) == null) {
                  request.setAttribute(FILTERS_ALREADY_APPLIED_KEY, Boolean.TRUE);
                  interceptors.preHandle((HttpServletRequest) request,
                     response, null);
               } else {
                  return adapter.handle(request, response, handler);
               }

               //						if (response instanceof HttpServletResponseWrapperWithRedirectChecking) {
               //							HttpServletResponseWrapperWithRedirectChecking wrapper = (HttpServletResponseWrapperWithRedirectChecking) response;
               //							if (wrapper.isWasRedirected()) {
               //								boolean external=true;
               //								if(external){
               //									String redirect = wrapper.getCurrentRedirect();
               //									redirect = redirect.substring(redirect.lastIndexOf("/"));
               //									request.setAttribute("__acegi_session_integration_filter_applied",null);
               //									request.getRequestDispatcher(redirect).forward(request,response);
               //								}
               //								else{
               //									wrapper.doRedirect();
               //								}
               //							}
               //							
               //
               //						}
               //						if(mustForceRedirect(request)){
               //							String redirect = getRedirect(request);
               //							request.setAttribute(StrutsPortlet.REDIRECT_URL,null);
               //							request.setAttribute(StrutsPortlet.REDIRECT_PAGE_URL,null);
               //							redirect = redirect.substring(redirect.lastIndexOf("/"));
               //							request.setAttribute("__acegi_session_integration_filter_applied",null);
               //							request.getRequestDispatcher(redirect).forward(request,response);
               //						}
               if (WrappedHttpServletResponse.getWrappedResponse(request,
                        response) != null) {
                  WrappedHttpServletResponse.getWrappedResponse(request,
                     response).flushBuffer();
               }

               return interceptor.getResult();
            } else {
               return adapter.handle(request, response, handler);
            }
         } catch (Exception e) {
            throw new ServletException(e);
         }
      }

      /**
       * Documentaci�.
       *
       * @param request Documentaci�
       *
       * @return Documentaci�
       */
      private String getRedirect(HttpServletRequest request) {
         if (request.getAttribute(StrutsPortlet.REDIRECT_URL) != null) {
            return (String) request.getAttribute(StrutsPortlet.REDIRECT_URL);
         }

         if (request.getAttribute(StrutsPortlet.REDIRECT_PAGE_URL) != null) {
            return (String) request.getAttribute(StrutsPortlet.REDIRECT_PAGE_URL);
         }

         return null;
      }

      /**
       * Documentaci�.
       *
       * @param request Documentaci�
       *
       * @return Documentaci�
       */
      private boolean mustForceRedirect(HttpServletRequest request) {
         return ((getRedirect(request) != null) &&
         !request.getAttribute(StrutsPortlet.REQUEST_TYPE)
                 .equals(StrutsPortlet.ACTION_REQUEST));
      }

      /**
       * Documentaci�.
       *
       * @param request Documentaci�
       *
       * @return Documentaci�
       */
      public boolean hasTheSameHandler(HttpServletRequest request) {
         Object hmb = getWebApplicationContext()
                         .getBean(HANDLER_MAPPING_BEAN_NAME);
         List handlerMappings = Collections.singletonList(hmb);

         Iterator it = handlerMappings.iterator();

         while (it.hasNext()) {
            HandlerMapping hm = (HandlerMapping) it.next();

            if (logger.isDebugEnabled()) {
               logger.debug("Testing handler map [" + hm +
                  "] in DispatcherServlet with name '" + getServletName() +
                  "'");
            }

            try {
               handler = hm.getHandler(request);
            } catch (Exception e) {
               return false;
            }

            if (handler != null) {
               return handler == getHandler();
            }
         }

         return false;
      }

      /**
       * Documentaci�.
       *
       * @param handler Documentaci�
       *
       * @return Documentaci�
       */
      public boolean supports(Object handler) {
         return adapter.supports(handler);
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public Object getHandler() {
         return handler;
      }

      /**
       * Documentaci�.
       *
       * @param handler Documentaci�
       */
      public void setHandler(Object handler) {
         this.handler = handler;

         try {
            this.adapter = DispatcherServlet.super.getHandlerAdapter(handler);
         } catch (ServletException e) {
         }
      }
   }
}
