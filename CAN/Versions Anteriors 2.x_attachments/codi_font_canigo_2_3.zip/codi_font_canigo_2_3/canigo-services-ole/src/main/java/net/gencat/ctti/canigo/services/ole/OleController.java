/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.ole;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.ole.exception.OleServiceException;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class OleController implements Controller {
   /**
    * Documentaci�.
    */
   protected static final String OLE_CONTROLLER_BEAN_DEFAULT = "myBeanData";

   /**
    * Documentaci�.
    */
   public static final String OLE_CONTROLLER_MODEL = "MODEL";

   /**
    * Documentaci�.
    */
   public static final String OLE_CONTROLLER_VIEWID = "viewId";

   /**
    * Documentaci�.
    */
   public String template;

   /**
    * Creates a new OleController object.
    */
   public OleController() {
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws OleServiceException Documentaci�
    */
   public ModelAndView handleRequest(HttpServletRequest request,
      HttpServletResponse response) throws OleServiceException {
      try {
         Map model = new HashMap();
         ;

         if ((request.getSession().getAttribute(OLE_CONTROLLER_MODEL) != null) &&
               request.getSession().getAttribute(OLE_CONTROLLER_MODEL) instanceof Map) {
            model = (Map) request.getSession().getAttribute(OLE_CONTROLLER_MODEL);
            request.getSession().removeAttribute(OLE_CONTROLLER_MODEL);
         }

         // Obtain ole ID
         String oleId = "";

         if (request.getSession().getAttribute(OLE_CONTROLLER_VIEWID) != null) {
            oleId = request.getSession().getAttribute(OLE_CONTROLLER_VIEWID)
                           .toString();
         } else if (request.getParameter(OLE_CONTROLLER_VIEWID) != null) {
            oleId = request.getParameter(OLE_CONTROLLER_VIEWID).toString();
         }

         if ((model == null) || model.isEmpty()) {
            model = getEmptyModel();
         }

         return new ModelAndView(oleId, model);
      } catch (Exception ex) {
         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ole.oleController",
               args, Layer.SERVICES, Subsystem.OLE_SERVICES);
         exDetails.setProperties(new Properties());
         throw new OleServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private Map getEmptyModel() {
      Map model = new HashMap();
      Collection beanData = getData();
      model.put(OLE_CONTROLLER_BEAN_DEFAULT, beanData);

      return model;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected List getData() {
      List list = new ArrayList();
      EmptyBean emptyBean = new EmptyBean();
      list.add(emptyBean);

      return list;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getTemplate() {
      return template;
   }

   /**
    * Documentaci�.
    *
    * @param template Documentaci�
    */
   public void setTemplate(String template) {
      this.template = template;
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   protected class EmptyBean {
      /**
       * Documentaci�.
       */
      protected String id;

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getId() {
         return id;
      }

      /**
       * Documentaci�.
       *
       * @param id Documentaci�
       */
      public void setId(String id) {
         this.id = id;
      }
   }
}
