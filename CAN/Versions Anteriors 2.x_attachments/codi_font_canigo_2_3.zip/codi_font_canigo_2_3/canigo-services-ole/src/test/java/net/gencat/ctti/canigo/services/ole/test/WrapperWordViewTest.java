/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.ole.test;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.ole.exception.OleServiceException;
import net.gencat.ctti.canigo.services.ole.impl.WordDocument;
import net.gencat.ctti.canigo.services.ole.impl.WrapperWordView;

import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.model.TextPiece;
import org.apache.poi.hwpf.model.TextPieceTable;
import org.apache.poi.hwpf.usermodel.CharacterProperties;
import org.apache.poi.hwpf.usermodel.Range;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockServletContext;
import org.springframework.web.context.support.StaticWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.LocaleResolver;


/**
 * Test for the WrapperWordView classes.
 *
 * @author Eusebi Collell
 */
public class WrapperWordViewTest extends TestCase {
   /**
    * Documentaci�.
    */
   private MockHttpServletRequest request;

   /**
    * Documentaci�.
    */
   private MockHttpServletResponse response;

   /**
    * Documentaci�.
    */
   private MockServletContext servletCtx;

   /**
    * Documentaci�.
    */
   private StaticWebApplicationContext webAppCtx;

   /**
    * Documentaci�.
    */
   public void setUp() {
      servletCtx = new MockServletContext(
            "net/gencat/ctti/canigo/services/ole/test");
      request = new MockHttpServletRequest(servletCtx);
      response = new MockHttpServletResponse();
      webAppCtx = new StaticWebApplicationContext();
      webAppCtx.setServletContext(servletCtx);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWriteWord() throws Exception {
      InputStream is = Thread.currentThread().getContextClassLoader()
                             .getResourceAsStream("net/gencat/ctti/canigo/services/ole/test/template.doc");
      HWPFDocument wordDocument = new HWPFDocument(is);
      CharacterProperties props = new CharacterProperties();
      Range range = new Range(0, wordDocument.characterLength(), wordDocument);

      for (int currentRow = 0; currentRow < 10; currentRow++) {
         props = new CharacterProperties();

         if ((currentRow % 2) == 0) {
            props.setBold(true);
         } else {
            props.setItalic(true);
         }

         String text = "canigo - id: " + currentRow + " size: " +
            (currentRow * 10) + "\r\n";
         range = range.insertAfter(text, props);
      }

      URL url = Thread.currentThread().getContextClassLoader()
                      .getResource("net/gencat/ctti/canigo/services/ole/test/template.doc");
      URI uri = null;
/*
      try {
         uri = //url.toURI();
      } catch (URISyntaxException e) {
         e.printStackTrace();
      }
*/
      String path = uri.getPath();
      path = path.substring(0, path.length() - "template.doc".length()) +
         "template2.doc";

      //		System.out.println("Template2: "+path);
      FileOutputStream docOut = new FileOutputStream(path);
      wordDocument.write(docOut);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWord() throws Exception {
      request.setAttribute(DispatcherServlet.LOCALE_RESOLVER_ATTRIBUTE,
         newDummyLocaleResolver("", ""));

      WrapperWordView wordView = new WrapperWordView() {
            protected void wrappedBuildWordDocument(Map model,
               WordDocument wordDocument, HttpServletRequest request,
               HttpServletResponse response) throws OleServiceException {
               CharacterProperties props = new CharacterProperties();

               for (int currentRow = 0; currentRow < 3; currentRow++) {
                  props = new CharacterProperties();

                  if ((currentRow % 2) == 0) {
                     props.setBold(true);
                  } else {
                     props.setItalic(true);
                  }

                  String text = "canigo - id: " + currentRow + " size: " +
                     (currentRow * 10) + "\r\n";
                  insertAfter(wordDocument, text, props);
               }
            }
         };

      wordView.setApplicationContext(webAppCtx);
      wordView.setUrl("template");
      wordView.render(new HashMap(), request, response);

      WordDocument wordDocument = new WordDocument(new ByteArrayInputStream(
               response.getContentAsByteArray()));
      TextPieceTable tpt = wordDocument.getTextTable();
      List listTpt = tpt.getTextPieces();
      String textResult = "";
      Iterator ite = listTpt.iterator();

      while (ite.hasNext()) {
         TextPiece tp = (TextPiece) ite.next();
         textResult += tp.getStringBuffer();
      }

      assertEquals("Test Template\r\rcanigo - id: 0 size: 0\r\ncanigo - id: 1 size: 10\r\ncanigo - id: 2 size: 20\r\n\r",
         textResult);
   }

   /**
    * Documentaci�.
    *
    * @param lang Documentaci�
    * @param country Documentaci�
    *
    * @return Documentaci�
    */
   private LocaleResolver newDummyLocaleResolver(final String lang,
      final String country) {
      return new LocaleResolver() {
            public Locale resolveLocale(HttpServletRequest request) {
               return new Locale(lang, country);
            }

            public void setLocale(HttpServletRequest request,
               HttpServletResponse response, Locale locale) {
               // not supported!
            }
         };
   }
}
