/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.ole.test;

import java.io.ByteArrayInputStream;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.ole.exception.OleServiceException;
import net.gencat.ctti.canigo.services.ole.impl.WrapperExcelView;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockServletContext;
import org.springframework.web.context.support.StaticWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.LocaleResolver;


/**
 * Test for the WrapperExcelView classes.
 *
 * @author Alef Arendsen
 * @author Bram Smeets
 */
public class WrapperExcelViewTest extends TestCase {
   /**
    * Documentaci�.
    */
   private MockHttpServletRequest request;

   /**
    * Documentaci�.
    */
   private MockHttpServletResponse response;

   /**
    * Documentaci�.
    */
   private MockServletContext servletCtx;

   /**
    * Documentaci�.
    */
   private StaticWebApplicationContext webAppCtx;

   /**
    * Documentaci�.
    */
   public void setUp() {
      servletCtx = new MockServletContext(
            "net/gencat/ctti/canigo/services/ole/test");
      request = new MockHttpServletRequest(servletCtx);
      response = new MockHttpServletResponse();
      webAppCtx = new StaticWebApplicationContext();
      webAppCtx.setServletContext(servletCtx);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testExcel() throws Exception {
      WrapperExcelView excelView = new WrapperExcelView() {
            protected void wrappedBuildExcelDocument(Map model,
               HSSFWorkbook wb, HttpServletRequest request,
               HttpServletResponse response) throws OleServiceException {
               HSSFSheet sheet = wb.createSheet();
               wb.setSheetName(0, "Test Sheet");

               // test all possible permutation of row or column not existing
               HSSFCell cell = getCell(sheet, 2, 4);
               cell.setCellValue("Test Value");
               cell = getCell(sheet, 2, 3);
               setText(cell, "Test Value");
               cell = getCell(sheet, 3, 4);
               setText(cell, "Test Value");
               cell = getCell(sheet, 2, 4);
               setText(cell, "Test Value");
            }
         };

      excelView.render(new HashMap(), request, response);

      POIFSFileSystem poiFs = new POIFSFileSystem(new ByteArrayInputStream(
               response.getContentAsByteArray()));
      HSSFWorkbook wb = new HSSFWorkbook(poiFs);
      assertEquals("Test Sheet", wb.getSheetName(0));

      HSSFSheet sheet = wb.getSheet("Test Sheet");
      HSSFRow row = sheet.getRow(2);
      HSSFCell cell = row.getCell((short) 4);
      assertEquals("Test Value", cell.getStringCellValue());
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testExcelWithTemplateAndCountryAndLanguage()
      throws Exception {
      request.setAttribute(DispatcherServlet.LOCALE_RESOLVER_ATTRIBUTE,
         newDummyLocaleResolver("en", "US"));

      WrapperExcelView excelView = new WrapperExcelView() {
            protected void wrappedBuildExcelDocument(Map model,
               HSSFWorkbook wb, HttpServletRequest request,
               HttpServletResponse response) throws OleServiceException {
               HSSFSheet sheet = wb.getSheet("Sheet1");

               // test all possible permutation of row or column not existing
               HSSFCell cell = getCell(sheet, 2, 4);
               cell.setCellValue("Test Value");
               cell = getCell(sheet, 2, 3);
               setText(cell, "Test Value");
               cell = getCell(sheet, 3, 4);
               setText(cell, "Test Value");
               cell = getCell(sheet, 2, 4);
               setText(cell, "Test Value");
            }
         };

      excelView.setApplicationContext(webAppCtx);
      excelView.setUrl("template");
      excelView.render(new HashMap(), request, response);

      POIFSFileSystem poiFs = new POIFSFileSystem(new ByteArrayInputStream(
               response.getContentAsByteArray()));
      HSSFWorkbook wb = new HSSFWorkbook(poiFs);
      HSSFSheet sheet = wb.getSheet("Sheet1");
      HSSFRow row = sheet.getRow(0);
      HSSFCell cell = row.getCell((short) 0);
      assertEquals("Test Template American English", cell.getStringCellValue());
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testExcelWithTemplateAndLanguage() throws Exception {
      request.setAttribute(DispatcherServlet.LOCALE_RESOLVER_ATTRIBUTE,
         newDummyLocaleResolver("de", ""));

      WrapperExcelView excelView = new WrapperExcelView() {
            protected void wrappedBuildExcelDocument(Map model,
               HSSFWorkbook wb, HttpServletRequest request,
               HttpServletResponse response) throws OleServiceException {
               HSSFSheet sheet = wb.getSheet("Sheet1");

               // test all possible permutation of row or column not existing
               HSSFCell cell = getCell(sheet, 2, 4);
               cell.setCellValue("Test Value");
               cell = getCell(sheet, 2, 3);
               setText(cell, "Test Value");
               cell = getCell(sheet, 3, 4);
               setText(cell, "Test Value");
               cell = getCell(sheet, 2, 4);
               setText(cell, "Test Value");
            }
         };

      excelView.setApplicationContext(webAppCtx);
      excelView.setUrl("template");
      excelView.render(new HashMap(), request, response);

      POIFSFileSystem poiFs = new POIFSFileSystem(new ByteArrayInputStream(
               response.getContentAsByteArray()));
      HSSFWorkbook wb = new HSSFWorkbook(poiFs);
      HSSFSheet sheet = wb.getSheet("Sheet1");
      HSSFRow row = sheet.getRow(0);
      HSSFCell cell = row.getCell((short) 0);
      assertEquals("Test Template auf Deutsch", cell.getStringCellValue());
   }

   /**
    * Documentaci�.
    *
    * @param lang Documentaci�
    * @param country Documentaci�
    *
    * @return Documentaci�
    */
   private LocaleResolver newDummyLocaleResolver(final String lang,
      final String country) {
      return new LocaleResolver() {
            public Locale resolveLocale(HttpServletRequest request) {
               return new Locale(lang, country);
            }

            public void setLocale(HttpServletRequest request,
               HttpServletResponse response, Locale locale) {
               // not supported!
            }
         };
   }
}
