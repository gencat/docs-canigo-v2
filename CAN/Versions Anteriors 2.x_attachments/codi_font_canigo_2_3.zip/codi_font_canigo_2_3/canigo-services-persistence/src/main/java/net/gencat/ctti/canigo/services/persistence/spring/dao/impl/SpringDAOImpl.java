/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.persistence.spring.dao.impl;

import java.io.Serializable;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.persistence.DAO;
import net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.SessionFactoryUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public abstract class SpringDAOImpl extends org.springframework.orm.hibernate3.support.HibernateDaoSupport
   implements DAO {
   /**
    * Return the name of the configuration file to be used with this DAO or
    * null if default
    */
   public String getConfigurationFileName() {
      return null;
   }

   /**
    * Serialitze map.
    */
   protected static String serialize(Map pMap) {
      String tmpS = null;

      if (pMap != null) {
         StringBuffer tmpBuff = new StringBuffer("{");
         Iterator tmpIt = pMap.entrySet().iterator();

         while (tmpIt.hasNext()) {
            Entry tmpEntry = (Entry) tmpIt.next();
            tmpBuff.append(tmpEntry.getKey() + ":" + tmpEntry.getValue() + ",");
         }

         if (tmpBuff.length() > 1) {
            tmpBuff.deleteCharAt(tmpBuff.length() - 1);
         }

         tmpBuff.append("}");
         tmpS = tmpBuff.toString();
      }

      return tmpS;
   }

   /**
    * Serialitze array.
    */
   protected static String serialize(Object[] pArray) {
      String tmpS = null;

      if (pArray != null) {
         StringBuffer tmpBuff = new StringBuffer("[");

         for (int i = 0; i < pArray.length; i++) {
            tmpBuff.append(pArray[i] + ",");
         }

         if (tmpBuff.length() > 1) {
            tmpBuff.deleteCharAt(tmpBuff.length() - 1);
         }

         tmpBuff.append("]");
         tmpS = tmpBuff.toString();
      }

      return tmpS;
   }

   /**
    * Used by the base DAO classes but here for your modification Get object
    * matching the given key and return it.
    */
   public Object get(Class refClass, Serializable key)
      throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return get(refClass, key, s);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_get", new Object[] { refClass, key }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_get", new Object[] { refClass, key }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Used by the base DAO classes but here for your modification Get object
    * matching the given key and return it.
    */
   protected Object get(Class refClass, Serializable key, Session s)
      throws PersistenceServiceException {
      try {
         return s.get(refClass, key);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_get", new Object[] { refClass, key }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_get", new Object[] { refClass, key }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Used by the base DAO classes but here for your modification Load object
    * matching the given key and return it.
    */
   public Object load(Class refClass, Serializable key)
      throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return load(refClass, key, s);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_load", new Object[] { refClass, key }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_load", new Object[] { refClass, key }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Used by the base DAO classes but here for your modification Load object
    * matching the given key and return it.
    */
   protected Object load(Class refClass, Serializable key, Session s)
      throws PersistenceServiceException {
      try {
         return s.load(refClass, key);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_load", new Object[] { refClass, key }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_load", new Object[] { refClass, key }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Obtain an instance of Query for a named query string defined in the
    * mapping file.
    *
    * @param name
    *            the name of a query defined externally
    * @return Query
    */
   protected Query getNamedQuery(String name)
      throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return getNamedQuery(name, s);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Obtain an instance of Query for a named query string defined in the
    * mapping file. Use the session given.
    *
    * @param name
    *            the name of a query defined externally
    * @param s
    *            the Session
    * @return Query
    */
   protected Query getNamedQuery(String name, Session s)
      throws PersistenceServiceException {
      try {
         return s.getNamedQuery(name);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Obtain an instance of Query for a named query string defined in the
    * mapping file.
    *
    * @param name
    *            the name of a query defined externally
    * @param param
    *            the first parameter to set
    * @return Query
    */
   protected Query getNamedQuery(String name, Serializable param)
      throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return getNamedQuery(name, param, s);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name, param }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name, param }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Obtain an instance of Query for a named query string defined in the
    * mapping file. Use the session given.
    *
    * @param name
    *            the name of a query defined externally
    * @param param
    *            the first parameter to set
    * @param s
    *            the Session
    * @return Query
    */
   protected Query getNamedQuery(String name, Serializable param, Session s)
      throws PersistenceServiceException {
      try {
         Query q = s.getNamedQuery(name);
         q.setParameter(0, param);

         return q;
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name, param }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name, param }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Obtain an instance of Query for a named query string defined in the
    * mapping file. Use the parameters given.
    *
    * @param name
    *            the name of a query defined externally
    * @param params
    *            the parameter array
    * @return Query
    */
   protected Query getNamedQuery(String name, Serializable[] params)
      throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return getNamedQuery(name, params, s);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name, serialize(params) },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name, serialize(params) },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Obtain an instance of Query for a named query string defined in the
    * mapping file. Use the parameters given and the Session given.
    *
    * @param name
    *            the name of a query defined externally
    * @param params
    *            the parameter array
    * @s the Session
    * @return Query
    */
   protected Query getNamedQuery(String name, Serializable[] params, Session s)
      throws PersistenceServiceException {
      try {
         Query q = s.getNamedQuery(name);

         if (null != params) {
            for (int i = 0; i < params.length; i++) {
               q.setParameter(i, params[i]);
            }
         }

         return q;
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name, serialize(params) },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name, serialize(params) },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Obtain an instance of Query for a named query string defined in the
    * mapping file. Use the parameters given.
    *
    * @param name
    *            the name of a query defined externally
    * @param params
    *            the parameter Map
    * @return Query
    */
   protected Query getNamedQuery(String name, Map params)
      throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return getNamedQuery(name, params, s);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name, serialize(params) },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name, serialize(params) },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Obtain an instance of Query for a named query string defined in the
    * mapping file. Use the parameters given and the Session given.
    *
    * @param name
    *            the name of a query defined externally
    * @param params
    *            the parameter Map
    * @s the Session
    * @return Query
    */
   protected Query getNamedQuery(String name, Map params, Session s)
      throws PersistenceServiceException {
      try {
         Query q = s.getNamedQuery(name);

         if (null != params) {
            for (Iterator i = params.entrySet().iterator(); i.hasNext();) {
               Map.Entry entry = (Map.Entry) i.next();
               q.setParameter((String) entry.getKey(), entry.getValue());
            }
         }

         return q;
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name, serialize(params) },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".query_not_found", new Object[] { name, serialize(params) },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Execute a query.
    *
    * @param queryStr
    *            a query expressed in Hibernate's query language
    * @return a distinct list of instances (or arrays of instances)
    */
   protected Query getQuery(String queryStr) throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return getQuery(queryStr, s);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query", new Object[] { queryStr }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query", new Object[] { queryStr }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Execute a query but use the session given instead of creating a new one.
    *
    * @param queryStr
    *            a query expressed in Hibernate's query language
    * @s the Session to use
    */
   protected Query getQuery(String queryStr, Session s)
      throws PersistenceServiceException {
      try {
         return s.createQuery(queryStr);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query", new Object[] { queryStr }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query", new Object[] { queryStr }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Execute a query.
    *
    * @param query
    *            a query expressed in Hibernate's query language
    * @param queryStr
    *            the name of a query defined externally
    * @param param
    *            the first parameter to set
    * @return Query
    */
   protected Query getQuery(String queryStr, Serializable param)
      throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return getQuery(queryStr, param, s);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query", new Object[] { queryStr }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query", new Object[] { queryStr }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Execute a query but use the session given instead of creating a new one.
    *
    * @param queryStr
    *            a query expressed in Hibernate's query language
    * @param param
    *            the first parameter to set
    * @s the Session to use
    * @return Query
    */
   protected Query getQuery(String queryStr, Serializable param, Session s)
      throws PersistenceServiceException {
      try {
         Query q = getQuery(queryStr, s);
         q.setParameter(0, param);

         return q;
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query", new Object[] { queryStr, param },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query", new Object[] { queryStr, param },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Execute a query.
    *
    * @param queryStr
    *            a query expressed in Hibernate's query language
    * @param params
    *            the parameter array
    * @return Query
    */
   protected Query getQuery(String queryStr, Serializable[] params)
      throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return getQuery(queryStr, params, s);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query",
            new Object[] { queryStr, serialize(params) }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query",
            new Object[] { queryStr, serialize(params) }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Execute a query but use the session given instead of creating a new one.
    *
    * @param queryStr
    *            a query expressed in Hibernate's query language
    * @param params
    *            the parameter array
    * @s the Session
    * @return Query
    */
   protected Query getQuery(String queryStr, Serializable[] params, Session s)
      throws PersistenceServiceException {
      try {
         Query q = getQuery(queryStr, s);

         if (null != params) {
            for (int i = 0; i < params.length; i++) {
               q.setParameter(i, params[i]);
            }
         }

         return q;
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query",
            new Object[] { queryStr, serialize(params) }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query",
            new Object[] { queryStr, serialize(params) }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Obtain an instance of Query for a named query string defined in the
    * mapping file. Use the parameters given.
    *
    * @param queryStr
    *            a query expressed in Hibernate's query language
    * @param params
    *            the parameter Map
    * @return Query
    */
   protected Query getQuery(String queryStr, Map params)
      throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return getQuery(queryStr, params, s);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query",
            new Object[] { queryStr, serialize(params) }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query",
            new Object[] { queryStr, serialize(params) }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Obtain an instance of Query for a named query string defined in the
    * mapping file. Use the parameters given and the Session given.
    *
    * @param queryStr
    *            a query expressed in Hibernate's query language
    * @param params
    *            the parameter Map
    * @s the Session
    * @return Query
    */
   protected Query getQuery(String queryStr, Map params, Session s)
      throws PersistenceServiceException {
      try {
         Query q = getQuery(queryStr, s);

         if (null != params) {
            for (Iterator i = params.entrySet().iterator(); i.hasNext();) {
               Map.Entry entry = (Map.Entry) i.next();
               q.setParameter((String) entry.getKey(), entry.getValue());
            }
         }

         return q;
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query",
            new Object[] { queryStr, serialize(params) }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_create_query",
            new Object[] { queryStr, serialize(params) }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected Order getDefaultOrder() {
      return null;
   }

   /**
    * Used by the base DAO classes but here for your modification Persist the
    * given transient instance, first assigning a generated identifier. (Or
    * using the current value of the identifier property if the assigned
    * generator is used.)
    */
   public Serializable save(Object obj) throws PersistenceServiceException {
      try {
         return getSession().save(obj);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_save", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_save", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Used by the base DAO classes but here for your modification Persist the
    * given transient instance, first assigning a generated identifier. (Or
    * using the current value of the identifier property if the assigned
    * generator is used.)
    */
   public Serializable save(Object obj, Session s)
      throws PersistenceServiceException {
      try {
         return s.save(obj);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_save", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_save", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Used by the base DAO classes but here for your modification Either save()
    * or update() the given instance, depending upon the value of its
    * identifier property.
    */
   public void saveOrUpdate(final Object obj)
      throws PersistenceServiceException {
      try {
         getSession().saveOrUpdate(obj);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_save_or_update", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_save_or_update", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Used by the base DAO classes but here for your modification Either save()
    * or update() the given instance, depending upon the value of its
    * identifier property.
    */
   public void saveOrUpdate(Object obj, Session s)
      throws PersistenceServiceException {
      try {
         s.saveOrUpdate(obj);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_save_or_update", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_save_or_update", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Used by the base DAO classes but here for your modification Update the
    * persistent state associated with the given identifier. An exception is
    * thrown if there is a persistent instance with the same identifier in the
    * current session.
    *
    * @param obj
    *            a transient instance containing updated state
    */
   public void update(final Object obj) throws PersistenceServiceException {
      try {
         getSession().update(obj);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_update", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_update", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Used by the base DAO classes but here for your modification Update the
    * persistent state associated with the given identifier. An exception is
    * thrown if there is a persistent instance with the same identifier in the
    * current session.
    *
    * @param obj
    *            a transient instance containing updated state
    * @param s
    *            the Session
    */
   protected void update(Object obj, Session s)
      throws PersistenceServiceException {
      try {
         s.update(obj);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_update", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_update", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Delete all objects returned by the query
    */
   protected int delete(final Query query) throws PersistenceServiceException {
      return new Integer(delete((Query) query, getSession())).intValue();
   }

   /**
    * Delete all objects returned by the query
    */
   protected int delete(Query query, Session s)
      throws PersistenceServiceException {
      try {
         List list = query.list();

         for (Iterator i = list.iterator(); i.hasNext();) {
            delete(i.next(), s);
         }

         return list.size();
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_delete_query", new Object[] { query }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_delete_query", new Object[] { query }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Used by the base DAO classes but here for your modification Remove a
    * persistent instance from the datastore. The argument may be an instance
    * associated with the receiving Session or a transient instance with an
    * identifier associated with existing persistent state.
    */
   public void delete(final Object obj) throws PersistenceServiceException {
      delete(obj, getSession());
   }

   /**
    * Used by the base DAO classes but here for your modification Remove a
    * persistent instance from the datastore. The argument may be an instance
    * associated with the receiving Session or a transient instance with an
    * identifier associated with existing persistent state.
    */
   protected void delete(Object obj, Session s)
      throws PersistenceServiceException {
      try {
         s.delete(obj);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_delete", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_delete", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Used by the base DAO classes but here for your modification Re-read the
    * state of the given instance from the underlying database. It is
    * inadvisable to use this to implement long-running sessions that span many
    * business tasks. This method is, however, useful in certain special
    * circumstances.
    */
   public void refresh(Object obj, Session s)
      throws PersistenceServiceException {
      try {
         s.refresh(obj);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_refresh", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_refresh", new Object[] { obj }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Used by the base DAO classes but here for your modification Re-read the
    * state of the given instance from the underlying database. It is
    * inadvisable to use this to implement long-running sessions that span many
    * business tasks. This method is, however, useful in certain special
    * circumstances.
    */
   public void refresh(Object obj) throws PersistenceServiceException {
      refresh(obj, getSession());
   }

   /**
    * Documentaci�.
    *
    * @param s Documentaci�
    * @param namedQuery Documentaci�
    * @param params Documentaci�
    *
    * @return Documentaci�
    *
    * @throws PersistenceServiceException Documentaci�
    */
   protected List findByNamedQuery(Session s, String namedQuery, Map params)
      throws PersistenceServiceException {
      try {
         Query query = s.getNamedQuery(namedQuery);
         String[] paramNames = query.getNamedParameters();

         if (paramNames != null) {
            for (int i = 0; i < paramNames.length; i++) {
               Object paramValue = params.get(paramNames[i]);

               if (paramValue == null) {
                  throw new PersistenceServiceException(PersistenceServiceException.class.getPackage()
                                                                                         .getName() +
                     ".cannot_find_named_parameter",
                     new Object[] { namedQuery, paramNames[i] }, Layer.SERVICES);
               }

               query.setParameter(paramNames[i], paramValue);
            }
         }

         return query.list();
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_find_namedQuery", new Object[] { namedQuery, params },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_find_namedQuery", new Object[] { namedQuery, params },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Documentaci�.
    *
    * @param namedQuery Documentaci�
    * @param params Documentaci�
    *
    * @return Documentaci�
    *
    * @throws PersistenceServiceException Documentaci�
    */
   public List findByNamedQuery(String namedQuery, Map params)
      throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return findByNamedQuery(s, namedQuery, params);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findfiltered",
            new Object[] { namedQuery, serialize(params) }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findfiltered",
            new Object[] { namedQuery, serialize(params) }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }
}
