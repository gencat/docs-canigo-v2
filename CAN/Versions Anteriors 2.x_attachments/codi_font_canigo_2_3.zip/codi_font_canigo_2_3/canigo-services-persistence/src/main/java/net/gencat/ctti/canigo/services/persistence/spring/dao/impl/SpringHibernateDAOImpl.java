/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.persistence.spring.dao.impl;

import java.util.List;

import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.persistence.HibernateDAO;
import net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Order;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.SessionFactoryUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public abstract class SpringHibernateDAOImpl extends SpringDAOImpl
   implements HibernateDAO {
   /**
    * Return the specific Object class that will be used for class-specific
    * implementation of this DAO.
    *
    * @return the reference Class
    */
   protected abstract Class getReferenceClass();

   /**
    * Return all objects related to the implementation of this DAO with no
    * filter.
    */
   public java.util.List findAll() throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return findAll(s);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findall", new Object[] { getReferenceClass() },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findall", new Object[] { getReferenceClass() },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Return all objects related to the implementation of this DAO with no
    * filter. Use the session given.
    *
    * @param s
    *            the Session
    */
   protected java.util.List findAll(Session s)
      throws PersistenceServiceException {
      return findAll(s, getDefaultOrder());
   }

   /**
    * Return all objects related to the implementation of this DAO with no
    * filter.
    */
   public java.util.List findAll(Order defaultOrder)
      throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return findAll(s, defaultOrder);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findall",
            new Object[] { getReferenceClass(), defaultOrder }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findall",
            new Object[] { getReferenceClass(), defaultOrder }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Return all objects related to the implementation of this DAO with no
    * filter. Use the session given.
    *
    * @param s
    *            the Session
    */
   protected java.util.List findAll(Session s, Order defaultOrder)
      throws PersistenceServiceException {
      try {
         Criteria crit = s.createCriteria(getReferenceClass());

         if (null != defaultOrder) {
            crit.addOrder(defaultOrder);
         }

         return crit.list();
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findall",
            new Object[] { getReferenceClass(), defaultOrder }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findall",
            new Object[] { getReferenceClass(), defaultOrder }, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Return all objects related to the implementation of this DAO with a
    * filter. Use the session given.
    *
    * @param propName
    *            the name of the property to use for filtering
    * @param filter
    *            the value of the filter
    */
   public List findFiltered(String propName, Object filter)
      throws PersistenceServiceException {
      return findFiltered(propName, filter, getDefaultOrder());
   }

   /**
    * Documentaci�.
    *
    * @param propNames Documentaci�
    * @param filters Documentaci�
    *
    * @return Documentaci�
    *
    * @throws PersistenceServiceException Documentaci�
    */
   public List findFiltered(String[] propNames, Object[] filters)
      throws PersistenceServiceException {
      return findFiltered(propNames, filters, getDefaultOrder());
   }

   /**
    * Return all objects related to the implementation of this DAO with a
    * filter. Use the session given.
    *
    * @param propName
    *            the name of the property to use for filtering
    * @param filter
    *            the value of the filter
    * @param orderProperty
    *            the name of the property used for ordering
    */
   public List findFiltered(String propName, Object filter, Order order)
      throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return findFiltered(s, propName, filter, order);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findfiltered",
            new Object[] { getReferenceClass(), filter, order },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findfiltered",
            new Object[] { getReferenceClass(), filter, order },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Documentaci�.
    *
    * @param propNames Documentaci�
    * @param filters Documentaci�
    * @param order Documentaci�
    *
    * @return Documentaci�
    *
    * @throws PersistenceServiceException Documentaci�
    */
   public List findFiltered(String[] propNames, Object[] filters, Order order)
      throws PersistenceServiceException {
      Session s = null;

      try {
         s = getSession();

         return findFiltered(s, propNames, filters, order);
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findfiltered",
            new Object[] { getReferenceClass(), serialize(filters), order },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findfiltered",
            new Object[] { getReferenceClass(), serialize(filters), order },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Return all objects related to the implementation of this DAO with a
    * filter. Use the session given.
    *
    * @param s
    *            the Session
    * @param propName
    *            the name of the property to use for filtering
    * @param filter
    *            the value of the filter
    * @param orderProperty
    *            the name of the property used for ordering
    */
   protected List findFiltered(Session s, String propName, Object filter,
      Order order) throws PersistenceServiceException {
      try {
         Criteria crit = s.createCriteria(getReferenceClass());
         crit.add(Expression.eq(propName, filter));

         if (null != order) {
            crit.addOrder(order);
         }

         return crit.list();
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findfiltered",
            new Object[] { getReferenceClass(), filter, propName, order },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findfiltered",
            new Object[] { getReferenceClass(), filter, propName, order },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Documentaci�.
    *
    * @param s Documentaci�
    * @param propNames Documentaci�
    * @param filters Documentaci�
    * @param order Documentaci�
    *
    * @return Documentaci�
    *
    * @throws PersistenceServiceException Documentaci�
    */
   protected List findFiltered(Session s, String[] propNames, Object[] filters,
      Order order) throws PersistenceServiceException {
      try {
         Criteria crit = s.createCriteria(getReferenceClass());

         for (int i = 0; i < propNames.length; i++) {
            crit.add(Expression.eq(propNames[i], filters[i]));
         }

         if (null != order) {
            crit.addOrder(order);
         }

         return crit.list();
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findfiltered",
            new Object[] { getReferenceClass(), filters, serialize(propNames) },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_findfiltered",
            new Object[] { getReferenceClass(), filters, serialize(propNames) },
            Layer.SERVICES, Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Returns the hibernate session
    */
   public Session getHibernateSession() {
      try {
         return this.getSession();
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_get_hibernate_session", null, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }

   /**
    * Used by client DAO classes. This call forces a syncronization process between <br>
    * session state and the database (NO COMMIT!). See Hibernate Documentation for a more <br>
    * detailed description about flushing process and when to call it.
    * @throws PersistenceServiceException
    */
   public void flush() throws PersistenceServiceException {
      try {
         getSession().flush();
      } catch (HibernateException ex) {
         throw new PersistenceServiceException(SessionFactoryUtils.convertHibernateAccessException(
               ex),
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_flush", null, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      } catch (DataAccessException ex) {
         throw new PersistenceServiceException(ex,
            PersistenceServiceException.class.getPackage().getName() +
            ".cannot_flush", null, Layer.SERVICES,
            Subsystem.PERSISTENCE_SERVICES);
      }
   }
}
