/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package com.myapp.test;

import java.util.Iterator;
import java.util.List;

import com.myapp.model.Category;
import com.myapp.model.dao.CategoryDAO;

import net.gencat.ctti.canigo.services.logging.LoggingService;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class MultiSave {
   /**
    * Documentaci�.
    */
   private CategoryDAO categoryDAO = null;

   /**
    * Documentaci�.
    */
   private LoggingService logService = null;

   /**
    * Creates a new MultiSave object.
    */
   public MultiSave() {
   }

   /**
    * Documentaci�.
    *
    * @param categories Documentaci�
    */
   public void saveMultiple(List categories) {
      Iterator it = categories.iterator();
      int i = 0;

      while (it.hasNext()) {
         Category c = (Category) it.next();
         this.logService.getLog(this.getClass())
                        .debug("Trying to save category...");

         if (i == (categories.size() - 1)) {
            this.logService.getLog(this.getClass())
                           .debug("Persistence error will occur...");
            this.categoryDAO.update(c);
         } else {
            this.categoryDAO.save(c);
         }

         this.logService.getLog(this.getClass())
                        .debug("Category saved with id " + c.getId());
         i++;
      }
   }

   /**
    * @return Returns the categoryDAO.
    */
   public CategoryDAO getCategoryDAO() {
      return categoryDAO;
   }

   /**
    * @param categoryDAO The categoryDAO to set.
    */
   public void setCategoryDAO(CategoryDAO categoryDAO) {
      this.categoryDAO = categoryDAO;
   }

   /**
    * @return Returns the logService.
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * @param logService The logService to set.
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * Documentaci�.
    *
    * @param id Documentaci�
    *
    * @return Documentaci�
    */
   public Category loadCategory(Integer id) {
      return this.categoryDAO.get(id);
   }
}
