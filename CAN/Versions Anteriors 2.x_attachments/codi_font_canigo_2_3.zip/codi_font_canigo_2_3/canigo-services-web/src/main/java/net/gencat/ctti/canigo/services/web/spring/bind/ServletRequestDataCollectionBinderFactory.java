/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.spring.bind;

import java.util.Map;


/**
 * Factory of servlet request binders
 * @author Eusebi
 */
public class ServletRequestDataCollectionBinderFactory
   extends ServletRequestDataBinderFactory {
   /**
    * 1->true, 0->true, on->true, off->false, and so on...
    */
   private Map selectedConversion = null;

   /**
    * Bind property for 'selecteds' if only bind selecteds
    */
   private String selectedBindProperty = "selected";

   /**
    * To bing only selected
    */
   private boolean onlyBindSelecteds = false;

   /**
    * Creates a new ServletRequestDataCollectionBinderFactory object.
    */
   public ServletRequestDataCollectionBinderFactory() {
   }

   /**
    * Documentaci�.
    *
    * @param aTarget Documentaci�
    * @param aName Documentaci�
    *
    * @return Documentaci�
    */
   public ServletRequestDataBinder getInstance(Object aTarget, String aName) {
      ServletRequestDataCollectionBinder dataBinder = new ServletRequestDataCollectionBinder(aTarget,
            aName, bindProperties);

      // Now register custom editors defined
      registerCustomEditors(dataBinder);
      dataBinder.setOnlyBindSelecteds(this.onlyBindSelecteds);
      dataBinder.setSelectedBindProperty(this.selectedBindProperty);
      dataBinder.setSelectedConversion(this.selectedConversion);

      return dataBinder;
   }

   /**
    * @return Returns the onlyBindSelecteds.
    */
   public boolean isOnlyBindSelecteds() {
      return onlyBindSelecteds;
   }

   /**
    * @param onlyBindSelecteds The onlyBindSelecteds to set.
    */
   public void setOnlyBindSelecteds(boolean onlyBindSelecteds) {
      this.onlyBindSelecteds = onlyBindSelecteds;
   }

   /**
    * @return Returns the selectedBindProperty.
    */
   public String getSelectedBindProperty() {
      return selectedBindProperty;
   }

   /**
    * @param selectedBindProperty The selectedBindProperty to set.
    */
   public void setSelectedBindProperty(String selectedBindProperty) {
      this.selectedBindProperty = selectedBindProperty;
   }

   /**
    * @return Returns the selectedConversion.
    */
   public Map getSelectedConversion() {
      return selectedConversion;
   }

   /**
    * @param selectedConversion The selectedConversion to set.
    */
   public void setSelectedConversion(Map selectedConversion) {
      this.selectedConversion = selectedConversion;
   }
}
