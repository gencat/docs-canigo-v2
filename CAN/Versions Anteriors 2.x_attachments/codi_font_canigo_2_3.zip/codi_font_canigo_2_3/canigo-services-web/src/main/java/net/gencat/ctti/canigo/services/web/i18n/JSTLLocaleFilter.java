/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.i18n;

import java.io.IOException;

import java.util.Locale;
import java.util.StringTokenizer;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.jstl.core.Config;

import net.gencat.ctti.canigo.core.threadlocal.ThreadLocalProperties;
import net.gencat.ctti.canigo.services.i18n.Constants;


/**
 * DOCUMENT ME!
 */
public class JSTLLocaleFilter implements Filter {
   /** DOCUMENT ME! */
   private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(JSTLLocaleFilter.class);

   /**
    * DOCUMENT ME!
    *
    * @param arg0 DOCUMENT ME!
    *
    * @throws ServletException DOCUMENT ME!
    */
   public void init(FilterConfig arg0) throws ServletException {
   }

   /**
    * DOCUMENT ME!
    */
   public void destroy() {
   }

   /**
    * DOCUMENT ME!
    *
    * @param arg0 DOCUMENT ME!
    * @param arg1 DOCUMENT ME!
    * @param arg2 DOCUMENT ME!
    *
    * @throws IOException DOCUMENT ME!
    * @throws ServletException DOCUMENT ME!
    */
   public void doFilter(ServletRequest arg0, ServletResponse arg1,
      FilterChain arg2) throws IOException, ServletException {
      // TODO Auto-generated method stub
      HttpServletRequest request = (HttpServletRequest) arg0;
      HttpSession session = request.getSession();

      log.debug("session is null? " + (session == null));

      Locale locale = null;
      String localeStr = request.getParameter("set-locale");

      if ((localeStr == null) || (localeStr.equals(Constants.EMPTY))) {
         log.debug("set-locale not found!");
         locale = (Locale) Config.get(session, Config.FMT_LOCALE);
         log.debug("locale from session found?" + locale);

         if (locale == null) {
            log.debug("locale from session not found! Setting from request... ");
            locale = request.getLocale();
            log.debug("Setting locale in session from request... " + locale);
            Config.set(session, Config.FMT_LOCALE, locale);
         }

         log.debug("Setting locale in thl from locale... " + locale);
         ThreadLocalProperties.put(Constants.LOCALE, locale);
      } else {
         log.info("set-locale found: " + localeStr);

         if (localeStr.indexOf(Constants.LOCALE_SEPARATOR) != -1) {
            // Format ca_ES
            StringTokenizer stringtokenizer = new StringTokenizer(localeStr,
                  Constants.LOCALE_SEPARATOR);

            locale = new Locale(stringtokenizer.nextToken(),
                  stringtokenizer.nextToken());
         } else {
            // Format ca
            locale = new Locale(localeStr);
         }

         log.info("Setting locale in thl+session from set-locale... " + locale);
         Config.set(session, Config.FMT_LOCALE, locale);
         ThreadLocalProperties.put(Constants.LOCALE, locale);
      }

      arg2.doFilter(arg0, arg1);
   }
}
