/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.lists.impl;

import java.util.HashMap;
import java.util.Map;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.web.lists.ValueListActionHelper;
import net.gencat.ctti.canigo.services.web.lists.exception.WebListsServiceException;
import net.gencat.ctti.canigo.services.web.spring.bind.WebDataBinderFactory;
import net.gencat.ctti.canigo.services.web.struts.SpringBindingActionForm;
import net.mlw.vlh.ValueList;
import net.mlw.vlh.ValueListInfo;
import net.mlw.vlh.web.ValueListRequestUtil;
import net.mlw.vlh.web.mvc.ValueListHandlerHelper;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;


/**
 * @since 1.0.1
 * Modificaci� 30/05/2006:
 *  <li> S'afegeix la funcionalitat de poder modificar els par�metres de cerca que venen a la request <br>
 *  mitja�ant l'opci� d'afegir un Map a la request amb m�s par�metres de cerca. <br>
 *  <li> Es soluciona el problema de la exportaci� a formats diferents a HTML.
 *  <li> Es soluciona el problema amb el par�metre maxExportRows: si s'informa, aquest par�metre <br>
 *  indica el m�xim de registres del llistat que seran exportats. Si no s'informa, el nombre de registres <br>
 *  exportats ser� igual al total de registres del llistat.
 *
 */
public class SimpleValueListActionHelper implements ValueListActionHelper {
   /**
    * Documentaci�.
    */
   public static String WEB_DATA_BINDER_FACTORY = "webDataBinderFactory";

   /**
    * Logging service
    */
   private LoggingService logService = null;

   /**
    * Documentaci�.
    */
   private String id;

   /**
    * Documentaci�.
    */
   private String listAttributeName = "list";

   /**
    * Documentaci�.
    */
   private String listForwardName = "list";

   /**
    * Documentaci�.
    */
   private String listName;

   /**
    * Documentaci�.
    */
   private String reqCode = "search";

   /**
    * Documentaci�.
    */
   private String tableId;

   /**
    * Documentaci�.
    */
   private ValueListHandlerHelper valueListHelper;

   /**
    * Documentaci�.
    */
   private String[] excludedParameters = new String[] {
         ValueListInfo.PAGING_PAGE, ValueListInfo.PAGING_NUMBER_PER
      };

   /**
    * Documentaci�.
    */
   private boolean rememberFilters = true;

   /**
    * Documentaci�.
    */
   private int maxExportRows = Integer.MAX_VALUE;

   /**
    * Getter
    * @return net.gencat.ctti.canigo.services.logging.LoggingService
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * Setter
    * @param logService the logging service
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @throws WebListsServiceException Documentaci�
    */
   public void search(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws WebListsServiceException {
      // Aquest codi provoca que la exportaci� a formats diferents a HTML no funcioni, ja que estem 
      // reempla�ant el reqCode que ve a la request (pe SearchExportExcel) per search
      //String reqCode = "search";   
      String sReqCode = request.getParameter("reqCode");
      request.setAttribute("subReqCode",
         (sReqCode != null) ? sReqCode.replaceFirst(getReqCode(), "") : "");

      if (listName == null) {
         String[] args = { mapping.getPath() };
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.web.lists.noListName",
               args, Layer.SERVICES, Subsystem.WEB_LISTS_SERVICES);
         throw new WebListsServiceException(exDetails);
      }

      if (tableId == null) {
         String[] args = new String[] { mapping.getPath(), listName };
         throw new WebListsServiceException("canigo.services.web.lists.noTableId",
            args, Layer.SERVICES, Subsystem.WEB_LISTS_SERVICES);
      }

      /**
       * ValueListInfo DOES NOT contains reference to the table we are looking for,<br>
       * because it expects parameters prefixed with "tableId" so <br>
       * DO NOT use getValueListInfo(request,tableId);
           */
      ValueListInfo info = valueListHelper.getValueListInfo(request);

      ValueListInfo infoById = ValueListRequestUtil.buildValueListInfo(request,
            this.id);

      info.getFilters().putAll(infoById.getFilters());

      /**
       * Afegit 30/05/2006
       * Els par�metres de la Map VALUE_LIST_FILTERS_ATTRIBUTE_NAME sobreescriuen els de la
       * request i els de la session en cas de que no siguin nulls.
       * Per tal de que els par�metres de cerca afegits per l'usuari siguin considerats en
       * qualsevol cerca, s'ha modificat el comportament previ d'aquesta part. El cam� que es segueix
       * per a constru�r la llista de par�metres de cerca ara �s:
       * 1. Par�metres de la Session.
       * 2. Par�metres de la Request.
       * 3. Par�metres de l'usuari.
       */
      HashMap allFiltersInOne = new HashMap();

      if (request.getSession() != null) {
         Map filtersFromSession = (Map) request.getSession()
                                               .getAttribute(tableId);

         //Map filtersFromSession = null;
         if (filtersFromSession != null) {
            if (this.logService != null) {
               this.logService.getLog(this.getClass())
                              .info("Found filters from session: " +
                  filtersFromSession);
            }

            allFiltersInOne.putAll(filtersFromSession);
         }
      } else {
         if (this.logService != null) {
            this.logService.getLog(this.getClass())
                           .info("Filters from session not found! Keeping those from ValueListInfo: " +
               info.getFilters());
         }
      }

      /**
       * Expected: filters from request override those from session if not null
       */
      if (this.logService != null) {
         this.logService.getLog(this.getClass())
                        .info("Filters from value list are: " +
            info.getFilters());
      }

      allFiltersInOne.putAll(info.getFilters());

      if (this.logService != null) {
         this.logService.getLog(this.getClass())
                        .info("Current filters are now: " + allFiltersInOne);
      }

      /**
       * Afegit 30/05/2006
       * Els par�metres de la Map VALUE_LIST_FILTERS_ATTRIBUTE_NAME sobreescriuen la resta.
       */
      Map wFiltersFromUser = (Map) request.getAttribute(VALUE_LIST_FILTERS_ATTRIBUTE_NAME);

      if (wFiltersFromUser != null) {
         allFiltersInOne.putAll(wFiltersFromUser);

         if (this.logService != null) {
            this.logService.getLog(this.getClass())
                           .info("After adding filters from user, current filters are now: " +
               allFiltersInOne);
         }
      }

      info.setFilters(allFiltersInOne);

      this.addCustomFilters(info, form, request);

      String subReqCode = (String) request.getAttribute("subReqCode");

      if (subReqCode.startsWith("Export")) {
         info.setPagingNumberPer(maxExportRows);
         info.setPagingPage(1);

         ValueList valueList = valueListHelper.getValueList(listName, info);

         /**
          * Modificaci� 30/05/2006.
          * En funci� del valor de maxExportRows, es fixa e�l nombre m�xim d'elements a exportar.
          */
         if ((maxExportRows == 0) &&
               (valueList.getValueListInfo().getTotalNumberOfEntries() > 0)) {
            info.setPagingNumberPer(valueList.getValueListInfo()
                                             .getTotalNumberOfEntries());
            valueList = valueListHelper.getValueList(listName, info);
         }

         //valueListHelper.backupAndSet(request, valueList, listAttributeName, "MyTable");
         valueListHelper.setValueListTo(request, valueList, listAttributeName);
      } else {
         ValueList valueList = valueListHelper.getValueList(listName, info);
         //valueListHelper.backupAndSet(request, valueList, listAttributeName, "MyTable");
         valueListHelper.setValueListTo(request, valueList, listAttributeName);
      }

      // EVC: added isRememberFilters condition
      if ((request.getSession() != null) && isRememberFilters()) {
         /**
          * Save request parameters into session (filters from ValueListInfo)
          * except excludedParameters (those from ValueListInfo)
          */
         Map toSave = new HashMap(info.getFilters());

         for (int i = 0; i < this.excludedParameters.length; i++) {
            toSave.remove(this.excludedParameters[i]);
         }

         if (this.logService != null) {
            this.logService.getLog(this.getClass())
                           .info("Saving filters in session " + toSave +
               " for tableId=" + this.tableId);
         }

         request.getSession().setAttribute(tableId, toSave);
      }

      /**
       * If there are request parameters in session from an
       * old search we should populate the pojo to display
       * this parameters again. These filter parameters has
       * been saved by the ValueListSearcherDelegate
       * implementation
       */
      Map filterParams = (Map) request.getSession().getAttribute(getTableId());

      if (filterParams != null) {
         SpringBindingActionForm actionForm = (SpringBindingActionForm) form;

         // MMR: el form puede ser null si se est� ejecutando una b�squeda sin criterio de b�squeda (por lo que
         // no tiene asociado ning�n formulario o ning�n pojoClass
         if ((form != null) && (actionForm.getTarget() != null) &&
               this.isRememberFilters()) {
            // Before of calling obtain information of action
            WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(request.getSession()
                                                                                                                     .getServletContext());

            // In case of have been defined a pojoClass in action bind into the pojo
            WebDataBinderFactory webDataBinderFactory = (WebDataBinderFactory) webApplicationContext.getBean(WEB_DATA_BINDER_FACTORY);

            WebDataBinder vlFilterBinder = webDataBinderFactory.getInstance(actionForm.getTarget(),
                  "_filters_");

            try {
               vlFilterBinder.bind(new MutablePropertyValues(filterParams));
            } catch (Exception bindex) {
               if (this.logService != null) {
                  this.logService.getLog(this.getClass())
                                 .info("Got binding error when binding filter: " +
                     bindex.getMessage());
               }
            }
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ValueListHandlerHelper getValueListHelper() {
      return valueListHelper;
   }

   /**
    * Documentaci�.
    *
    * @param valueListHelper Documentaci�
    */
   public void setValueListHelper(ValueListHandlerHelper valueListHelper) {
      this.valueListHelper = valueListHelper;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getListAttributeName() {
      return listAttributeName;
   }

   /**
    * Documentaci�.
    *
    * @param listAttributeName Documentaci�
    */
   public void setListAttributeName(String listAttributeName) {
      this.listAttributeName = listAttributeName;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getListForwardName() {
      return listForwardName;
   }

   /**
    * Documentaci�.
    *
    * @param listForwardName Documentaci�
    */
   public void setListForwardName(String listForwardName) {
      this.listForwardName = listForwardName;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getReqCode() {
      return reqCode;
   }

   /**
    * Documentaci�.
    *
    * @param reqCode Documentaci�
    */
   public void setReqCode(String reqCode) {
      this.reqCode = reqCode;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getListName() {
      return listName;
   }

   /**
    * Documentaci�.
    *
    * @param listName Documentaci�
    */
   public void setListName(String listName) {
      this.listName = listName;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getMaxExportRows() {
      return maxExportRows;
   }

   /**
    * Documentaci�.
    *
    * @param maxExportRows Documentaci�
    */
   public void setMaxExportRows(int maxExportRows) {
      this.maxExportRows = maxExportRows;
   }

   /**
    * @return Returns the tableId.
    */
   public String getTableId() {
      return tableId;
   }

   /**
    * @param tableId The tableId to set.
    */
   public void setTableId(String tableId) {
      this.tableId = tableId;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getId() {
      return id;
   }

   /**
    * Documentaci�.
    *
    * @param id Documentaci�
    */
   public void setId(String id) {
      this.id = id;
   }

   /**
    * @return Returns the rememberFilters.
    */
   public boolean isRememberFilters() {
      return rememberFilters;
   }

   /**
    * @param rememberFilters The rememberFilters to set.
    */
   public void setRememberFilters(boolean rememberFilters) {
      this.rememberFilters = rememberFilters;
   }

   /**
    * Subclasses should override this method to add custom filters
    * @param info the current filters
    * @param form the form from the Struts Action
    * @param request the request from the user
    */
   public void addCustomFilters(ValueListInfo info, ActionForm form,
      javax.servlet.http.HttpServletRequest request) {
   }
}
