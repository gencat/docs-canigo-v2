/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.spring.bind;

import java.lang.reflect.InvocationTargetException;

import java.util.ArrayList;
import java.util.Map;

import javax.servlet.ServletRequest;

import net.gencat.ctti.canigo.core.util.beanutils.BeanUtils;
import net.gencat.ctti.canigo.core.util.beanutils.PropertyUtilsBean;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.PropertyValue;
import org.springframework.beans.TypeMismatchException;
import org.springframework.web.bind.ServletRequestParameterPropertyValues;
import org.springframework.web.multipart.MultipartHttpServletRequest;


/**
 * Servlet Request Data Binder BeanWrapper
 *
 * @author Eusebi
 *
 */
public class ServletRequestDataCollectionBinder extends ServletRequestDataBinder {
   /**
    * 1->true, 0->true, on->true, off->false, and so on...
    */
   private Map selectedConversion = null;

   /**
    * Bind property for 'selecteds' if only bind selecteds
    */
   private String selectedBindProperty = "selected";

   /**
    * To bing only selected
    */
   private boolean onlyBindSelecteds = false;

   /**
    * Creates a new ServletRequestDataCollectionBinder object.
    *
    * @param target DOCUMENT ME.
    * @param objectName DOCUMENT ME.
    * @param bindProperties DOCUMENT ME.
    */
   public ServletRequestDataCollectionBinder(Object target, String objectName,
      Map bindProperties) {
      super(target, objectName, bindProperties);

      Object obj = getErrors();

      if (obj instanceof net.gencat.ctti.canigo.core.springframework.beans.BindException) {
         ((net.gencat.ctti.canigo.core.springframework.beans.BindException) obj).setBindProperties(bindProperties);
      }

      this.setWrappedInstanceMutable(true);
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    */
   public void bind(ServletRequest request) {
      if (this.logService != null) {
         this.logService.getLog(this.getClass())
                        .info("Binding editable list. OnlyBindSelecteds=" +
            this.onlyBindSelecteds + ",SelectedBindProperty=" +
            this.selectedBindProperty);
      }

      MutablePropertyValues mpvs = new ServletRequestParameterPropertyValues(request);

      //msg-ini
      if (request instanceof MultipartHttpServletRequest) {
         MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
         bindMultipartFiles(multipartRequest.getFileMap(), mpvs);
      }

      //doBind(mpvs);
      //msg-fi
      PropertyValue[] pvs = mpvs.getPropertyValues();
      BeanWrapper bean = getBeanWrapper();

      if ((pvs != null) && (pvs.length > 0)) {
         PropertyValue pv = pvs[0];
         Object value = pv.getValue();
         String propName = pv.getName();

         try {
            int numRows = 1;

            if (value instanceof String[]) {
               String[] arValue = (String[]) value;
               numRows = arValue.length;
            }

            ArrayList alBean = new ArrayList();
            Class beanClass = bean.getWrappedClass();

            if (this.logService != null) {
               this.logService.getLog(this.getClass())
                              .info("Number of rows=" + numRows);
            }

            for (int i = 0; i < numRows; i++) {
               boolean isSelected = true;
               Object beanObject = beanClass.newInstance();

               if (this.logService != null) {
                  this.logService.getLog(this.getClass())
                                 .debug("Creating instance of " +
                     beanClass.getName() + " for row " + i);
               }

               for (int j = 0; j < pvs.length; j++) {
                  propName = pvs[j].getName();

                  if (this.logService != null) {
                     this.logService.getLog(this.getClass())
                                    .debug("Found property=" + propName);
                  }

                  if (bean.isWritableProperty(propName)) {
                     if (this.logService != null) {
                        this.logService.getLog(this.getClass())
                                       .debug("Property " + propName +
                           " is writable!");
                     }

                     try {
                        Object valueTyped = null;
                        Object preValued = mpvs.getPropertyValue(propName)
                                               .getValue();

                        if (preValued instanceof String[]) {
                           String[] new_name = (String[]) preValued;
                           valueTyped = ((Object[]) new_name)[i];
                        } else if (preValued instanceof Object) {
                           valueTyped = preValued;
                        }

                        if (this.logService != null) {
                           this.logService.getLog(this.getClass())
                                          .debug("Value typed is " +
                              valueTyped);
                        }

                        if (valueTyped != null) {
                           Object propValue = convert(propName, valueTyped,
                                 beanObject);

                           if (this.logService != null) {
                              this.logService.getLog(this.getClass())
                                             .debug("Converted value is " +
                                 propValue);
                           }

                           if (propName.equals(this.selectedBindProperty)) {
                              if (propValue != null) {
                                 try {
                                    String convertedValue = (this.selectedConversion != null)
                                       ? (String) this.selectedConversion.get(propValue.toString())
                                       : null;

                                    if (convertedValue == null) {
                                       convertedValue = propValue.toString();
                                    }

                                    if (this.logService != null) {
                                       this.logService.getLog(this.getClass())
                                                      .debug("Getting " +
                                          propValue +
                                          " from conversion map. Result is " +
                                          convertedValue);
                                       this.logService.getLog(this.getClass())
                                                      .debug("Trying to convert " +
                                          convertedValue + " to boolean");
                                    }

                                    isSelected = new Boolean(convertedValue).booleanValue();

                                    if (this.logService != null) {
                                       this.logService.getLog(this.getClass())
                                                      .debug("Converted value is " +
                                          isSelected);
                                    }

                                    if (!isSelected) {
                                       // Skip this object
                                       break;
                                    }
                                 } catch (Exception ex) {
                                    if (this.logService != null) {
                                       this.logService.getLog(this.getClass())
                                                      .error("Error converting " +
                                          propValue + " to boolean for " +
                                          propName, ex);
                                    } else {
                                       ex.printStackTrace();
                                    }
                                 }
                              } else {
                                 // Skip it
                              }
                           }

                           if (this.logService != null) {
                              this.logService.getLog(this.getClass())
                                             .debug("Copying " + propName +
                                 " with value " + propValue + " to " +
                                 beanObject);
                           }

                           BeanUtils.copyProperty(beanObject, propName,
                              propValue);
                        }
                     } catch (IllegalAccessException e) {
                        if (this.logService != null) {
                           this.logService.getLog(this.getClass())
                                          .error("Error getting property " +
                              propName, e);
                        } else {
                           e.printStackTrace();
                        }
                     } catch (InvocationTargetException e) {
                        if (this.logService != null) {
                           this.logService.getLog(this.getClass())
                                          .error("Error getting property " +
                              propName, e);
                        } else {
                           e.printStackTrace();
                        }
                     }
                  } else {
                     if (this.logService != null) {
                        this.logService.getLog(this.getClass())
                                       .debug("Property " + propName +
                           " is not writable. Skkipping!");
                     }
                  }
               }

               if (this.onlyBindSelecteds) {
                  if (this.logService != null) {
                     this.logService.getLog(this.getClass())
                                    .debug("Object " + beanObject +
                        " is selected?" + isSelected);
                  }

                  if (isSelected) {
                     alBean.add(beanObject);
                  }
               } else {
                  if (this.logService != null) {
                     this.logService.getLog(this.getClass())
                                    .debug("Adding " + beanObject +
                        " to editable list array");
                  }

                  alBean.add(beanObject);
               }
            }

            // MMR 08/08/06 Esto no funcionar� nunca, ya que existe una diferencia entre el target del BeanWrapperImpl y el
            // target del BindException. Si reaprovecho la instancia del BeanWrapperImpl, el errors (BindException) apuntar�
            // a un target diferente del beanWrapper. Como el formulario cuando se expone (form.expose) coge el target del
            // errors, no encontrar�amos nunca el array (alBean)
            bean.setWrappedInstance(alBean);

            // MMR End.
         } catch (InstantiationException e1) {
            if (this.logService != null) {
               this.logService.getLog(this.getClass())
                              .error("Error in binding " + propName, e1);
            } else {
               e1.printStackTrace();
            }
         } catch (IllegalAccessException e1) {
            if (this.logService != null) {
               this.logService.getLog(this.getClass())
                              .error("Error in binding " + propName, e1);
            } else {
               e1.printStackTrace();
            }
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param propName Documentaci�
    * @param value Documentaci�
    * @param beanObject Documentaci�
    *
    * @return Documentaci�
    */
   public Object convert(String propName, Object value, Object beanObject) {
      Object obj = null;

      try {
         //         obj = getBeanWrapper();
         //         if (obj instanceof net.gencat.ctti.canigo.core.springframework.beans.BeanWrapperImpl) {
         //            obj = ((net.gencat.ctti.canigo.core.springframework.beans.BeanWrapperImpl) obj).doTypeConversionIfNecessary(value,
         //                  getPropertyType(propName, beanObject));
         //         } else if (obj instanceof BeanWrapper) {
         //            obj = ((BeanWrapper) obj).convertIfNecessary(value,
         //                  getPropertyType(propName, beanObject));
         //         } else {
         //            obj = value;
         //         }

         //msg-ini
         obj = ((net.gencat.ctti.canigo.core.springframework.beans.BeanWrapperImpl) getBeanWrapper()).doTypeConversionIfNecessary(value,
               getPropertyType(propName, beanObject));

         //msg-fi
      } catch (TypeMismatchException e) {
         if (this.logService != null) {
            this.logService.getLog(this.getClass())
                           .error("Error converting " + propName +
               " with value " + value + " for object " + beanObject, e);
         } else {
            e.printStackTrace();
         }
      }

      return obj;
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param beanObject Documentaci�
    *
    * @return Documentaci�
    */
   private Class getPropertyType(String name, Object beanObject) {
      try {
         PropertyUtilsBean pub = new PropertyUtilsBean();
         pub.getNestedProperty(beanObject, name);

         return pub.getPropertyType(beanObject, name);
      } catch (IllegalAccessException e) {
         if (this.logService != null) {
            this.logService.getLog(this.getClass())
                           .error("Error getting property type " + name +
               " for object " + beanObject, e);
         } else {
            e.printStackTrace();
         }
      } catch (InvocationTargetException e) {
         if (this.logService != null) {
            this.logService.getLog(this.getClass())
                           .error("Error getting property type " + name +
               " for object " + beanObject, e);
         } else {
            e.printStackTrace();
         }
      } catch (NoSuchMethodException e) {
         if (this.logService != null) {
            this.logService.getLog(this.getClass())
                           .error("Error getting property type " + name +
               " for object " + beanObject, e);
         } else {
            e.printStackTrace();
         }
      }

      return null;
   }

   /**
    * @return Returns the onlyBindSelecteds.
    */
   public boolean isOnlyBindSelecteds() {
      return onlyBindSelecteds;
   }

   /**
    * @param onlyBindSelecteds The onlyBindSelecteds to set.
    */
   public void setOnlyBindSelecteds(boolean onlyBindSelecteds) {
      this.onlyBindSelecteds = onlyBindSelecteds;
   }

   /**
    * @return Returns the selectedBindProperty.
    */
   public String getSelectedBindProperty() {
      return selectedBindProperty;
   }

   /**
    * @param selectedBindProperty The selectedBindProperty to set.
    */
   public void setSelectedBindProperty(String selectedBindProperty) {
      this.selectedBindProperty = selectedBindProperty;
   }

   /**
    * @return Returns the selectedConversion.
    */
   public Map getSelectedConversion() {
      return selectedConversion;
   }

   /**
    * @param selectedConversion The selectedConversion to set.
    */
   public void setSelectedConversion(Map selectedConversion) {
      this.selectedConversion = selectedConversion;
   }
}
