/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.spring.bind;

import java.beans.PropertyEditorSupport;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import net.gencat.ctti.canigo.services.logging.LoggingService;


/**
 * Factory of servlet request binders
 * @author XES
 */
public class ServletRequestDataBinderFactory {
   /**
    * Documentaci�.
    */
   protected LoggingService logService = null;

   /**
    * Documentaci�.
    */
   Map bindProperties;

   /**
    * Map with key='className' and customEditor
    */
   Map customEditors;

   /**
    * Creates a new ServletRequestDataBinderFactory object.
    */
   public ServletRequestDataBinderFactory() {
   }

   /**
    * Documentaci�.
    *
    * @param aTarget Documentaci�
    * @param aName Documentaci�
    *
    * @return Documentaci�
    */
   public ServletRequestDataBinder getInstance(Object aTarget, String aName) {
      ServletRequestDataBinder dataBinder = new ServletRequestDataBinder(aTarget,
            aName, bindProperties);
      // Now register custom editors defined
      registerCustomEditors(dataBinder);

      return dataBinder;
   }

   /**
    * Register Custom Editors defined
    * @param aWebDataBinder
    */
   public void registerCustomEditors(ServletRequestDataBinder aWebDataBinder) {
      if (this.customEditors != null) {
         Set keysSet = customEditors.keySet();
         Iterator keysIterator = keysSet.iterator();

         while (keysIterator.hasNext()) {
            // register custom editors
            String className = (String) keysIterator.next();
            Class classType;

            try {
               classType = Class.forName(className);

               PropertyEditorSupport customEditor = (PropertyEditorSupport) customEditors.get(className);

               if (customEditor != null) {
                  aWebDataBinder.registerCustomEditor(classType, customEditor);
               }
            } catch (ClassNotFoundException e) {
               e.printStackTrace();
            }
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getCustomEditors() {
      return customEditors;
   }

   /**
    * Documentaci�.
    *
    * @param customEditors Documentaci�
    */
   public void setCustomEditors(Map customEditors) {
      this.customEditors = customEditors;
   }

   /**
    * @return Returns the bindProperties.
    */
   public Map getBindProperties() {
      return bindProperties;
   }

   /**
    * @param bindProperties The bindProperties to set.
    */
   public void setBindProperties(Map bindProperties) {
      this.bindProperties = bindProperties;
   }

   /**
    * @return Returns the logService.
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * @param logService The logService to set.
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }
}
