/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.spring;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;

import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.DynaClass;
import org.apache.commons.beanutils.DynaProperty;
import org.apache.commons.beanutils.LazyDynaBean;
import org.apache.commons.beanutils.LazyDynaClass;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.ServletRequestParameterPropertyValues;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class ServletRequestDynamicDataBinder extends ServletRequestDataBinder {
   /**
    * Creates a new ServletRequestDynamicDataBinder object.
    *
    * @param definition DOCUMENT ME.
    * @param objectName DOCUMENT ME.
    */
   public ServletRequestDynamicDataBinder(Map definition, String objectName) {
      super(processDefinition(definition, null), objectName);
   }

   /**
    * Creates a new ServletRequestDynamicDataBinder object.
    *
    * @param definition DOCUMENT ME.
    * @param forcedClass DOCUMENT ME.
    * @param objectName DOCUMENT ME.
    */
   public ServletRequestDynamicDataBinder(List definition, Class forcedClass,
      String objectName) {
      super(processDefinition(definition, forcedClass), objectName);
   }

   /**
    * Documentaci�.
    *
    * @param className Documentaci�
    *
    * @return Documentaci�
    */
   static Class getClass(String className) {
      try {
         return Class.forName(className);
      } catch (ClassNotFoundException e) {
         return null;
      }
   }

   /**
    * Documentaci�.
    *
    * @param inDefinition Documentaci�
    * @param forcedClass Documentaci�
    *
    * @return Documentaci�
    */
   static DynaBean processDefinition(Map inDefinition, Class forcedClass) {
      LazyDynaClass outDefinition = new LazyDynaClass();

      for (Iterator iter = inDefinition.entrySet().iterator(); iter.hasNext();) {
         Map.Entry entry = (Map.Entry) iter.next();

         if (entry.getKey() instanceof String) {
            Class theClass = getClass((String) entry.getValue());

            if ((forcedClass != null) || (theClass != null)) {
               outDefinition.add((String) entry.getKey(),
                  (Class) ((forcedClass == null) ? theClass : forcedClass));
            }
         }
      }

      try {
         DynaBean theInstance = outDefinition.newInstance();

         for (int i = 0;
               i < theInstance.getDynaClass().getDynaProperties().length;
               i++) {
            String propName = theInstance.getDynaClass().getDynaProperties()[i].getName();
            theInstance.set(propName, null);
         }

         return theInstance;
      } catch (IllegalAccessException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      } catch (InstantiationException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }

      return null;
   }

   /**
    * Documentaci�.
    *
    * @param inDefinition Documentaci�
    * @param forcedClass Documentaci�
    *
    * @return Documentaci�
    */
   static DynaBean processDefinition(List inDefinition, Class forcedClass) {
      LazyDynaClass outDefinition = new LazyDynaClass();

      for (Iterator iter = inDefinition.iterator(); iter.hasNext();) {
         Object entry = iter.next();

         if (entry instanceof String) {
            if (forcedClass != null) {
               outDefinition.add((String) entry, forcedClass);
            }
         }
      }

      try {
         DynaBean theInstance = outDefinition.newInstance();

         for (int i = 0;
               i < theInstance.getDynaClass().getDynaProperties().length;
               i++) {
            String propName = theInstance.getDynaClass().getDynaProperties()[i].getName();
            theInstance.set(propName, null);
         }

         return theInstance;
      } catch (IllegalAccessException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      } catch (InstantiationException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }

      return null;
   }

   /**
    * Documentaci�.
    *
    * @param propName Documentaci�
    * @param value Documentaci�
    *
    * @return Documentaci�
    */
   public Object convert(String propName, Object value) {
      return ((BeanWrapperImpl) getBeanWrapper()).doTypeConversionIfNecessary(value,
         getPropertyDefinition(propName).getType());
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    */
   public void bind(ServletRequest request) {
      MutablePropertyValues mpvs = new ServletRequestParameterPropertyValues(request);
      doBind(mpvs);

      LazyDynaBean bean = getDynaBean();

      for (int i = 0; i < bean.getDynaClass().getDynaProperties().length;
            i++) {
         String propName = bean.getDynaClass().getDynaProperties()[i].getName();

         if (mpvs.contains(propName)) {
            bean.set(propName,
               convert(propName, mpvs.getPropertyValue(propName).getValue()));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private LazyDynaBean getDynaBean() {
      return (LazyDynaBean) getBeanWrapper().getWrappedInstance();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private DynaClass getDynaClass() {
      return getDynaBean().getDynaClass();
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    *
    * @return Documentaci�
    */
   private DynaProperty getPropertyDefinition(String name) {
      return getDynaBean().getDynaClass().getDynaProperty(name);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map asMap() {
      Map result = new HashMap();

      if (getDynaBean() != null) {
         DynaProperty[] props = getDynaBean().getDynaClass().getDynaProperties();

         for (int i = 0; i < props.length; i++) {
            DynaProperty property = props[i];

            if (getDynaBean().get(property.getName()) != null) {
               result.put(property.getName(),
                  getDynaBean().get(property.getName()));
            }
         }
      }

      return result;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected BeanWrapper getBeanWrapper() {
      return new net.gencat.ctti.canigo.core.springframework.beans.BeanWrapperImpl(super.getTarget());
   }
}
