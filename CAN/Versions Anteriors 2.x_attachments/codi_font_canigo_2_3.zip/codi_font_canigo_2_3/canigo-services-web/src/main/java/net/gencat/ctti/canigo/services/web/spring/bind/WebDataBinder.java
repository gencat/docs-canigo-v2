/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.spring.bind;

import java.beans.PropertyEditor;

import java.util.Map;

import net.gencat.ctti.canigo.core.springframework.beans.BeanWrapperImpl;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.ConfigurablePropertyAccessor;
import org.springframework.validation.BindException;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.6 $
  */
public class WebDataBinder extends org.springframework.web.bind.WebDataBinder {
   /**
    * Documentaci�.
    */
   protected Map bindProperties;

   /**
    * Documentaci�.
    */
   private BeanWrapper wrapper = null;

   /**
    * Creates a new WebDataBinder object.
    *
    * @param target DOCUMENT ME.
    * @param objectName DOCUMENT ME.
    * @param bindProperties DOCUMENT ME.
    */

   //	 msg-ini
   private BindException errors = null;

   // msg-fi
   /**
    * Creates a new WebDataBinder object.
    *
    * @param target DOCUMENT ME.
    * @param objectName DOCUMENT ME.
    * @param bindProperties DOCUMENT ME.
    */
   public WebDataBinder(Object target, String objectName, Map bindProperties) {
      super(target, objectName);
      //msg-ini
      this.bindProperties = bindProperties;
      //    Generem un nou BindException
      setErrors(createErrors(target, objectName));

      //Generam un nou BeanWrapperImpl
      if (wrapper == null) {
         wrapper = new BeanWrapperImpl(super.getTarget(), bindProperties);
      }

      //Associem el bindProperties al BindException
      ((net.gencat.ctti.canigo.core.springframework.beans.BindException) this.getErrors()).setBindProperties(bindProperties);

      //Associem el BeanWrapper al BindException
      ((net.gencat.ctti.canigo.core.springframework.beans.BindException) this.getErrors()).setBeanWrapper(wrapper);

      //Associem el BeanWrapper al BindingResults
      ((net.gencat.ctti.canigo.core.springframework.beans.BeanPropertyBindingResult) ((net.gencat.ctti.canigo.core.springframework.beans.BindException) this.getErrors()).getBindingResult()).setBeanWrapper(wrapper);

      //      Object obj = getErrors();
      //
      //      if (obj instanceof net.gencat.ctti.canigo.core.springframework.beans.BindException) {
      //         ((net.gencat.ctti.canigo.core.springframework.beans.BindException) obj).setBindProperties(bindProperties);
      //      }
      //msg-fi
   }

   /**
    * Documentaci�.
    *
    * @param requiredType Documentaci�
    * @param propertyEditor Documentaci�
    */
   public void registerCustomEditor(Class requiredType,
      PropertyEditor propertyEditor) {
      super.registerCustomEditor(requiredType, propertyEditor);
   }

   /**
    * Documentaci�.
    *
    * @param target Documentaci�
    * @param objectName Documentaci�
    *
    * @return Documentaci�
    */
   protected BindException createErrors(Object target, String objectName) {
      return new net.gencat.ctti.canigo.core.springframework.beans.BindException(target,
         objectName);
   }

   // msg-ini
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected BeanWrapper getBeanWrapper() {
      // this.logService.getLog(ServletRequestDataBinder.class).debug("Creating a BeanWrapper with bindProperties="+this.bindProperties);
      if (wrapper == null) {
         wrapper = new BeanWrapperImpl(super.getTarget(), bindProperties);
      }

      return wrapper;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public BindException getErrors() {
      return errors;
   }

   /**
    * Documentaci�.
    *
    * @param errors Documentaci�
    */
   public void setErrors(BindException errors) {
      this.errors = errors;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected ConfigurablePropertyAccessor getPropertyAccessor() {
      return getBeanWrapper();
   }

   //msg-fi
}
