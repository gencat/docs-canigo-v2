/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.dwr.impl;

import java.io.IOException;
import java.io.PrintWriter;

import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import uk.ltd.getahead.dwr.AccessControl;
import uk.ltd.getahead.dwr.Creator;
import uk.ltd.getahead.dwr.CreatorManager;
import uk.ltd.getahead.dwr.Processor;
import uk.ltd.getahead.dwr.impl.HtmlConstants;
import uk.ltd.getahead.dwr.util.JavascriptUtil;
import uk.ltd.getahead.dwr.util.LocalUtil;


/**
 * DWR + UrlRewrite
 *
 * @version $Id: UrlRewriteInterfaceProcessor.java,v 1.5 2007/07/16 08:45:52 msabates Exp $
 * $Log: UrlRewriteInterfaceProcessor.java,v $
 * Revision 1.5  2007/07/16 08:45:52  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]
 *
 * Revision 1.4  2007/05/23 10:47:41  msabates
 * Cap�alera
 *
 * Revision 1.1.1.1.2.1  2007/05/18 10:49:49  fernando.vaquero
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2007/05/15 13:54:10  fernando.vaquero
 * Importacio canigo 2.0
 *
 * Revision 1.3  2007/05/15 10:19:04  msabates
 * Jalopy
 *
 * Revision 1.2  2007/04/20 09:49:21  msabates
 * Canvis que estaven a la v1.4
 *
 * Revision 1.3  2007/02/20 14:41:58  evidal
 * EVC: merging 1.0 & 1.1.
 *
 * Revision 1.1.2.2  2006/11/16 17:43:44  mmateos
 * author: mmateos: MMR: added contextpath
 *
 * Revision 1.1.2.2  2006/09/06 13:55:01  mmateos
 * MMR: added contextpath
 *
 * Revision 1.1.2.1  2006/09/06 13:38:16  mmateos
 * DWR + URLRewrite
 *
 *
 */
public class UrlRewriteInterfaceProcessor implements Processor {
   /**
    * The security manager
    */
   protected AccessControl accessControl = null;

   /**
    * How we create new beans
    */
   protected CreatorManager creatorManager = null;

   /**
    * The means by which we strip comments
    */
   private JavascriptUtil jsutil = new JavascriptUtil();

   /**
    * If we need to override the default path
    */
   private String overridePath = null;

   /**
    * This helps us test that access rules are being followed
    */
   private boolean allowImpossibleTests = false;

   /**
    * Documentaci�.
    *
    * @param req Documentaci�
    * @param resp Documentaci�
    *
    * @throws ServletException Documentaci�
    * @throws IOException Documentaci�
    */
   public void handle(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
      String pathinfo = req.getPathInfo();
      String servletpath = req.getServletPath();

      if (pathinfo == null) {
         pathinfo = req.getServletPath();
         servletpath = HtmlConstants.PATH_ROOT;
      }

      String scriptname = pathinfo;
      scriptname = LocalUtil.replace(scriptname, HtmlConstants.PATH_INTERFACE,
            HtmlConstants.BLANK);
      scriptname = LocalUtil.replace(scriptname, HtmlConstants.EXTENSION_JS,
            HtmlConstants.BLANK);

      Creator creator = creatorManager.getCreator(scriptname);

      // resp.setContentType("text/javascript");
      PrintWriter out = resp.getWriter();
      out.println();

      out.println("function " + scriptname + "() { }"); //$NON-NLS-1$ //$NON-NLS-2$

      String path = overridePath;

      if (path == null) {
         path = req.getContextPath() + resp.encodeURL(servletpath);
      }

      out.println(scriptname + "._path = '" + path + "';"); //$NON-NLS-1$ //$NON-NLS-2$

      Method[] methods = creator.getType().getMethods();

      for (int i = 0; i < methods.length; i++) {
         Method method = methods[i];
         String methodName = method.getName();

         // We don't need to check accessControl.getReasonToNotExecute()
         // because the checks are made by the doExec method, but we do check
         // if we can display it
         String reason = accessControl.getReasonToNotDisplay(req, creator,
               scriptname, method);

         if ((reason != null) && !allowImpossibleTests) {
            continue;
         }

         // Is it on the list of banned names
         if (jsutil.isReservedWord(methodName)) {
            continue;
         }

         out.print('\n');
         out.print(scriptname + '.' + methodName + " = function("); //$NON-NLS-1$

         Class[] paramTypes = method.getParameterTypes();

         for (int j = 0; j < paramTypes.length; j++) {
            if (!LocalUtil.isServletClass(paramTypes[j])) {
               out.print("p" + j + ", "); //$NON-NLS-1$ //$NON-NLS-2$
            }
         }

         out.println("callback) {"); //$NON-NLS-1$

         out.print("    DWREngine._execute(" + scriptname + "._path, '" +
            scriptname + "', '" + methodName + "\', "); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

         for (int j = 0; j < paramTypes.length; j++) {
            if (LocalUtil.isServletClass(paramTypes[j])) {
               out.print("false, "); //$NON-NLS-1$
            } else {
               out.print("p" + j + ", "); //$NON-NLS-1$ //$NON-NLS-2$
            }
         }

         out.println("callback);"); //$NON-NLS-1$

         out.println('}');
      }

      out.flush();
   }

   /**
    * Accessor for the DefaultCreatorManager that we configure
    *
    * @param creatorManager
    *            The new DefaultConverterManager
    */
   public void setCreatorManager(CreatorManager creatorManager) {
      this.creatorManager = creatorManager;
   }

   /**
    * Accessor for the security manager
    *
    * @param accessControl
    *            The accessControl to set.
    */
   public void setAccessControl(AccessControl accessControl) {
      this.accessControl = accessControl;
   }

   /**
    * Do we allow impossible tests for debug purposes
    *
    * @param allowImpossibleTests
    *            The allowImpossibleTests to set.
    */
   public void setAllowImpossibleTests(boolean allowImpossibleTests) {
      this.allowImpossibleTests = allowImpossibleTests;
   }

   /**
    * If we need to override the default path
    *
    * @param overridePath
    *            The new override path
    */
   public void setOverridePath(String overridePath) {
      this.overridePath = overridePath;
   }
}
