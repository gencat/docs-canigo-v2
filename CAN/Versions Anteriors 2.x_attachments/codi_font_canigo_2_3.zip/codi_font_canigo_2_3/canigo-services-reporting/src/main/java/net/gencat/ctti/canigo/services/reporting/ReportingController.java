/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.reporting;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class ReportingController implements Controller {
   /**
    * Documentaci�.
    */
   public static String REPORTING_CONTROLLER_MODEL = "MODEL";

   /**
    * Documentaci�.
    */
   public static String REPORTING_CONTROLLER_REPORTID = "reportId";

   /**
    * Documentaci�.
    */
   public static String REPORTING_CONTROLLER_FORMAT = "format";

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ModelAndView handleRequest(HttpServletRequest request,
      HttpServletResponse response) throws Exception {
      Map model = new HashMap();
      ;

      if ((request.getSession().getAttribute(REPORTING_CONTROLLER_MODEL) != null) &&
            request.getSession().getAttribute(REPORTING_CONTROLLER_MODEL) instanceof Map) {
         model = (Map) request.getSession()
                              .getAttribute(REPORTING_CONTROLLER_MODEL);
         request.getSession().removeAttribute(REPORTING_CONTROLLER_MODEL);
      }

      // Obtain format: pdf, xls, csv, html
      String format = "pdf";

      if (request.getParameter("contentType") != null) {
         format = request.getParameter("contentType");
      }

      // Obtain report ID
      String reportId = "";

      if (request.getSession().getAttribute(REPORTING_CONTROLLER_REPORTID) != null) {
         reportId = request.getSession()
                           .getAttribute(REPORTING_CONTROLLER_REPORTID)
                           .toString();
      } else if (request.getParameter(REPORTING_CONTROLLER_REPORTID) != null) {
         reportId = request.getParameter(REPORTING_CONTROLLER_REPORTID)
                           .toString();
      }

      if ((model == null) || model.isEmpty()) {
         model = getEmptyModel();
      }

      model.put(REPORTING_CONTROLLER_FORMAT, format);

      return new ModelAndView(reportId, model);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private Map getEmptyModel() {
      Map model = new HashMap();
      Collection beanData = getData();
      model.put("myBeanData", beanData);

      return model;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected List getData() {
      List list = new ArrayList();
      EmptyBean emptyBean = new EmptyBean();
      list.add(emptyBean);

      return list;
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   protected class EmptyBean {
      /**
       * Documentaci�.
       */
      protected String id;

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getId() {
         return id;
      }

      /**
       * Documentaci�.
       *
       * @param id Documentaci�
       */
      public void setId(String id) {
         this.id = id;
      }
   }
}
