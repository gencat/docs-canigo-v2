/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.reporting.test;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletResponse;

import net.gencat.ctti.canigo.services.reporting.impl.WrapperAbstractJasperView;
import net.gencat.ctti.canigo.services.reporting.impl.WrapperJasperMultiFormatView;
import net.sf.jasperreports.engine.JasperPrint;


/**
 * @author Rob Harrop
 */
public class WrapperJasperMultiFormatViewTest
   extends WrapperAbstractJasperViewTester {
   /**
    * Documentaci�.
    *
    * @param model Documentaci�
    */
   protected void extendModel(Map model) {
      model.put(getDiscriminatorKey(), "csv");
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testSimpleHtmlRender() throws Exception {
      if (!canCompileReport) {
         return;
      }

      WrapperAbstractJasperView view = getView(UNCOMPILED_REPORT);

      Map model = getBaseModel();
      model.put(getDiscriminatorKey(), "html");

      view.render(model, request, response);

      //		assertEquals("Invalid content type", "text/html", view.getContentType());
      assertEquals("Invalid content type", "text/html; charset=ISO-8859-1",
         view.getContentType());
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testOverrideContentDisposition() throws Exception {
      if (!canCompileReport) {
         return;
      }

      WrapperAbstractJasperView view = getView(UNCOMPILED_REPORT);

      Map model = getBaseModel();
      model.put(getDiscriminatorKey(), "csv");

      String headerValue = "inline; filename=foo.txt";

      Properties mappings = new Properties();
      mappings.put("csv", headerValue);

      ((WrapperJasperMultiFormatView) view).setContentDispositionMappings(mappings);

      view.render(model, request, response);

      assertEquals("Invalid Content-Disposition header value", headerValue,
         response.getHeader("Content-Disposition"));
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testExporterParametersAreCarriedAcross()
      throws Exception {
      if (!canCompileReport) {
         return;
      }

      WrapperJasperMultiFormatView view = (WrapperJasperMultiFormatView) getView(UNCOMPILED_REPORT);

      Properties mappings = new Properties();
      mappings.put("test", ExporterParameterTestView.class.getName());

      Map exporterParameters = new HashMap();

      // test view class performs the assertions - robh
      exporterParameters.put(ExporterParameterTestView.TEST_PARAM, "foo");

      view.setExporterParameters(exporterParameters);
      view.setFormatMappings(mappings);

      Map model = getBaseModel();
      model.put(getDiscriminatorKey(), "test");

      view.render(model, request, response);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected String getDiscriminatorKey() {
      return "format";
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected WrapperAbstractJasperView getViewImplementation() {
      return new WrapperJasperMultiFormatView();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected String getDesiredContentType() {
      return "text/csv";
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private Map getBaseModel() {
      Map model = new HashMap();
      model.put("ReportTitle", "Foo");
      model.put("dataSource", getData());

      return model;
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.5 $
     */
   public static class ExporterParameterTestView
      extends WrapperJasperMultiFormatView {
      /**
       * Documentaci�.
       */
      public static final String TEST_PARAM = "net.sf.jasperreports.engine.export.JRHtmlExporterParameter.IMAGES_URI";

      /**
       * Documentaci�.
       *
       * @param filledReport Documentaci�
       * @param parameters Documentaci�
       * @param response Documentaci�
       */
      protected void renderReport(JasperPrint filledReport, Map parameters,
         HttpServletResponse response) {
         assertNotNull("Exporter parameters are null", getExporterParameters());

         //			assertEquals("Incorrect number of exporter parameters", 1, getExporterParameters().size());
      }
   }
}
