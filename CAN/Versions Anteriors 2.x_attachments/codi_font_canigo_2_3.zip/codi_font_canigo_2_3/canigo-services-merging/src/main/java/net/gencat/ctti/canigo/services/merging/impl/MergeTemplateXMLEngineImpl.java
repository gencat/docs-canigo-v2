/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.merging.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.merging.MergeTemplateEngine;
import net.gencat.ctti.canigo.services.merging.exception.MergingServiceException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class MergeTemplateXMLEngineImpl implements MergeTemplateEngine {
   /** Identificador de fin de marca. Es configurable por fichero. */
   public String fiBookmark = null;

   /** Identificador de inicio de marca. Es configurable por fichero. */
   public String iniciBookmark = null;

   /** Nombre del tag root de un XML en formato WordML. */
   private final String sNom_Root_Element = "wordDocument";

   /** Nombre del tag text. */
   private final String sNom_Text_Element = "t";

   /** DOM obtenido a partir del InputStream recibido. */
   private Document wTemplate = null;

   /** Gestor de logs. */
   private LoggingService logService = null;

   /** Texto correspondiente a la parte parcial de la marca incompleta encontrada. */
   private String bookmarkBeforeReplace = "";

   /** Lista de documentos generados en el proceso de fusi�n. */
   private ByteArrayOutputStream[] wDocuments = null;

   /** Flag para controlar que se ha encontrado el inicio de una marca incompleta. */
   private boolean foundBeginMark = false;

   /**
    * Constructor.
    */
   public MergeTemplateXMLEngineImpl() {
      super();
   }

   /**
    * Para cada elemento de la lista <code>pDades</code>, este m�todo realiza <br>
    * la fusi�n de la plantilla <code>pTemplate</code> con los datos indicados <br>
    * por el elemento. <br>
    * @param pTemplate Stream con el contenido del documento a fusionar.
    * @param pDades Lista de datos con los que realizar la fusi�n. Cada elemento de la <br>
    *               lista corresponde a una Map, en la cual tenemos para cada bookmark <br>
    *               el valor por el cual ha de ser reemplazada.
    * @return ByteArrayOutputStream[] Array de Outputs, con el resultado de cada una de las fusiones.
    * @throws Exception.
    */
   public ByteArrayOutputStream[] mergeTemplate(InputStream pTemplate,
      List pDades) throws Exception {
      if ((pTemplate == null) || (pDades == null)) {
         return null;
      }

      wDocuments = new ByteArrayOutputStream[pDades.size()];

      writeToLog("Iniciando proceso de validaci�n de la plantilla XML");
      isValidTemplate(pTemplate);
      writeToLog("Proceso de validaci�n finalizado OK");

      for (int i = 0; i < pDades.size(); i++) {
         Map wDadesDoc = (Map) pDades.get(i);
         wDocuments[i] = mergeTemplate((Document) wTemplate.clone(), wDadesDoc);
         writeToLog("Generado documento " + (i + 1) + " de " + pDades.size());
      }

      return wDocuments;
   }

   /**
    * Utilitat per a escriure un missatge de log, amb nivell INFO.
    * @param pMessage Missatge a escriure al log.
    */
   private void writeToLog(String pMessage) {
      if (this.logService != null) {
         this.logService.getLog(this.getClass())
                        .info("SERVEI MERGING -- " + pMessage);
      }
   }

   /**
    * Valida que el formato de la plantilla recibida sea correcto y corresponda <br>
    * a Word XML. <br>
    * @param pTemplate Plantilla a validar.
    * @return Flag indicando el resultado de la validaci�n.
    * @throws Exception
    */
   private boolean isValidTemplate(InputStream pTemplate)
      throws Exception {
      parseWithSAX(pTemplate);

      Element wRoot = wTemplate.getRootElement();

      //TODO A lo mejor ser�a conveniente validar contra un DTD ... 
      if (!wRoot.getName().equals(sNom_Root_Element)) {
         ExceptionDetails wDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.merging.wrongXML",
               null, Layer.SERVICES);
         throw new MergingServiceException(wDetails);
      }

      return true;
   }

   /**
    * Carga un documento DOM a partir del contenido del contenido de <code>pTemplate</code>.
    *
    * @param pTemplate Origen de los datos del documento
    * @throw Exception en caso de error en el parseo.
    */
   private void parseWithSAX(InputStream pTemplate) throws Exception {
      try {
         SAXReader xmlReader = new SAXReader();
         this.wTemplate = xmlReader.read(pTemplate);
      } catch (DocumentException e) {
         ExceptionDetails wDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.merging.gral",
               new Object[] { e.getMessage() }, Layer.SERVICES);
         throw new MergingServiceException(wDetails);
      }
   }

   /**
    * Realiza la fusi�n de los datos recibidos en <code>pDades</code>, <br>
    * dentro de la plantilla. <br>
    * @param pTemplate
    * @param pDades
    * @return outputStream con el contenido del DOM modificado.
    * @throws Exception
    */
   private ByteArrayOutputStream mergeTemplate(Document pTemplate, Map pDades)
      throws Exception {
      try {
         recorrerDoc(pTemplate, pDades);

         ByteArrayOutputStream wOut = new ByteArrayOutputStream();
         XMLWriter xmlWriter = new XMLWriter(wOut);
         xmlWriter.write(pTemplate);
         xmlWriter.flush();

         return wOut;
      } catch (UnsupportedEncodingException e) {
         ExceptionDetails wDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.merging.gral",
               new Object[] { e.getMessage() }, Layer.SERVICES);
         throw new MergingServiceException(wDetails);
      } catch (IOException e) {
         ExceptionDetails wDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.merging.gral",
               new Object[] { e.getMessage() }, Layer.SERVICES);
         throw new MergingServiceException(wDetails);
      }
   }

   /**
    * Realiza un recorrido por la estructura del documento, en busca de bookmarks. <br>
    * A medida que encuentra los bookmarks los va sustituyendo por los valores <br>
    * indicados en <code>pDades</code>. <br>
    * @param document Documento DOM a recorrer.
    * @param pDades Tabla con los valores de los bookmarks a reemplazar.
    */
   private void recorrerDoc(Document pDocument, Map pDades) {
      recorrerDoc(pDocument.getRootElement(), pDades);
   }

   /**
    * Realiza un recorrido por la estructura del elemento, en busca de bookmarks. <br>
    * A medida que encuentra los bookmarks los va sustituyendo por los valores <br>
    * indicados en <code>pDades</code>. <br>
    * @param pElement Elemento a recorrer.
    * @param pDades Tabla con los valores de los bookmarks a reemplazar.
    */
   private void recorrerDoc(Element pElement, Map pDades) {
      if (pElement == null) {
         return;
      }

      for (int i = 0, size = pElement.nodeCount(); i < size; i++) {
         Node wNode = pElement.node(i);

         if (wNode instanceof Element) {
            if (wNode.getName().equals(sNom_Text_Element)) {
               String sText = wNode.getText();

               if ((sText.indexOf(iniciBookmark) != -1) ||
                     (sText.indexOf(fiBookmark) != -1) || foundBeginMark) {
                  ((Element) wNode).setText(replaceDadesBookmarks(sText, pDades));
               }
            }

            recorrerDoc((Element) wNode, pDades);
         }
      }
   }

   /**
    * Realiza una sustituci�n de las marcas que aparecen en el texto <code>pText</code>, <br>
    * ya sean completas o incompletas, por su valor correspondiente. <br>
    * Los posibles casos que se pueden recibir son: <br>
    * <i>pText = ..... @@MARCA##......</i>, corresponde a una marca completa. La marca se reemplaza <br>
    * por el texto indicado en <code>pDades</code>.
    * <i>pText = ..... @@MARCA</i> , corresponde a una marca incompleta. La marca se reemplaza por "", y <br>
    * se activa el flag <code>foundBeginMark</code> y la variable bookmarkBeforeReplace toma el valor "MARCA".
    * <i>pText = ..... MARCA##.....</i>, corresponde a una marca incompleta. Se desactiva el flag <code>foundBeginMark</code>, <br>
    * la variable bookmarkBeforeReplace toma el valor bookmarkBeforeReplace+"MARCA", y se reemplaza en el text <br>
    * la marca MARCA## por el valor retornado por <code>pDades</code> asociado a la marca @@bookmarkBeforeReplace+"MARCA"##.<br>
    *
    * @param pText Texto a recorrer
    * @param pDades Map de datos.
    * @return Texto con las marcas reemplazadas.
    */
   private String replaceDadesBookmarks(String pText, Map pDades) {
      String sText = pText;
      String sTextARetornar = "";

      // El primer que fem �s reempla�ar en el text totes les marques que estiguin completes.
      sTextARetornar = replaceBookmark(sText, pDades);

      if (foundBeginMark) {
         // El primer que s'ha de fer �s veure si en aquest text es troba la senyal de final de la marca.
         int iPosEnds = sTextARetornar.indexOf(fiBookmark);

         if (iPosEnds == -1) {
            // Com la marca no tanca en aquest node, el que fem es afegir el text del node al text de la marca
            // incompleta i indicar que el text a retornar �s "". El text de la marca es ficar� en el node que 
            // contingui la marca de fi del bookmark.
            bookmarkBeforeReplace += sTextARetornar;
            sTextARetornar = "";
         } else {
            // Aix� significa que en aquest node es tanca la marca que quedava oberta del pas anterior.            
            bookmarkBeforeReplace += sTextARetornar.substring(0, iPosEnds);

            sTextARetornar = (String) pDades.get(bookmarkBeforeReplace.toUpperCase()) +
               sTextARetornar.substring(iPosEnds + 2);

            foundBeginMark = false;
            bookmarkBeforeReplace = "";
         }
      }

      // Per �ltim, abans de fer el retorn hem de distingir si encara queda alguna senyal de marca per tractar.
      // Podria ser que el text rebut inicialment pel m�tode fos:
      //     marca1##.....@@marca2##...@@marca3
      // aleshores, en el primer pas, @@marca2## s'hauria reempla�at pel seu valor; s'hauria entrat en el tractament
      // del if(foundBeginMark), en el qual el text de marca1## s'hauria reempla�at pel seu valor; i a l'arribar a 
      // aquest punt quedaria per tractar el text de @@marca3.
      int iPosBegin = sTextARetornar.indexOf(iniciBookmark);

      if (iPosBegin != -1) { //Tenim l'inici d'una marca incompleta
                             // Activem el flag d'inici de marca incompleta trobat.
         foundBeginMark = true;
         // Informem quin �s la part del text de la marca trobada.
         bookmarkBeforeReplace = sTextARetornar.substring(iPosBegin + 2);
         // I per �ltim, reemplacem dintre del text la part corresponent a la marca incompleta per "".
         sTextARetornar = sTextARetornar.substring(0, iPosBegin);
      }

      return sTextARetornar;
   }

   /**
    * Realiza una sustituci�n de todas las marcas completas que aparezcan en el texto <code>pText</code>, <br>
    * por el correspondiente valor, el cual viene indicado en la map <code>pDades</code>.
    * @param pText Texto a modificar.
    * @param pDades  Tabla con el valor de cada marca.
    * @return Texto modificado.
    */
   private String replaceBookmark(String pText, Map pDades) {
      if (pText == null) {
         return null;
      }

      String sTextFusionat = pText;

      Iterator it = pDades.keySet().iterator();

      while (it.hasNext()) {
         String sKey = (String) it.next();
         String sBookmark = iniciBookmark + sKey + fiBookmark;

         if (sTextFusionat.indexOf(sBookmark) != -1) {
            sTextFusionat = sTextFusionat.replaceAll(sBookmark,
                  (String) pDades.get(sKey));
         }
      }

      return sTextFusionat;
   }

   /**
    * @return Returns the sFiBookmark.
    */
   public String getFiBookmark() {
      return fiBookmark;
   }

   /**
    * @param sFiBookmark The sFiBookmark to set.
    */
   public void setFiBookmark(String fiBookmark) {
      this.fiBookmark = fiBookmark;
   }

   /**
    * @return Returns the sIniciBookmark.
    */
   public String getIniciBookmark() {
      return iniciBookmark;
   }

   /**
    * @param sIniciBookmark The sIniciBookmark to set.
    */
   public void setIniciBookmark(String iniciBookmark) {
      this.iniciBookmark = iniciBookmark;
   }

   /**
    * @return Returns the logService.
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * @param logService The logService to set.
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }
}
