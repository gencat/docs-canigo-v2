/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.fileupload.impl;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.fileupload.FileUploadService;
import net.gencat.ctti.canigo.services.fileupload.UploadedFiles;
import net.gencat.ctti.canigo.services.fileupload.exception.FileUploadServiceException;
import net.gencat.ctti.canigo.services.logging.LoggingService;

import org.apache.struts.upload.MultipartRequestWrapper;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.servlet.DispatcherServlet;


/**
 * Implementation of the FileUpload service, which offers both Spring
 * configuration with a Spring-supported MultipartResolver to which we delegate,
 * and a getUploadBinder method which canb be used to extract actual files out
 * of the HTTPServletrequest.
 *
 * The user of the service can invoke the getUploadedFiles method, and must
 * provide:
 * - a list of fields that are known to be mappable
 * - an HTTPServletRequest to inspect for multipart files (which have already been
 * properly detected and handled by the Spring multipart infrastructure.
 *
 * and he/she will get in return a
 *
 * @see net.gencat.ctti.canigo.services.web.spring.ServletRequestDynamicDataBinder
 *      from which to extract a Map of
 * @see org.springframework.web.multipart.MultipartFile which represents the
 *      attributes of the uploaded file.
 *
 */
public class FileUploadServiceImpl implements FileUploadService,
   BeanFactoryAware {
   /**
    * Logging service
    */
   private LoggingService logService = null;

   /**
    * Documentaci�.
    */
   private MultipartResolver resolver;

   /**
    * Documentaci�.
    */
   private WrappedMultipartResolver wrapper;

   /**
    * Documentaci�.
    */
   private long maxAttachmentSize;

   /**
    * Default constructor
    *
    */
   public FileUploadServiceImpl() {
   }

   /**
    * Getter
    *
    * @return net.gencat.ctti.canigo.services.logging.LoggingService
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * Setter
    *
    * @param logService
    *            the logging service
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * @see WrappedMultipartResolver
    */
   public void cleanupMultipart(MultipartHttpServletRequest request) {
      resolver.cleanupMultipart(request);
   }

   /**
    * @see WrappedMultipartResolver
    */
   public boolean isMultipart(HttpServletRequest request) {
      return resolver.isMultipart(request);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public MultipartResolver getResolver() {
      if (wrapper != null) {
         return wrapper;
      }

      return resolver;
   }

   /**
    * Documentaci�.
    *
    * @param resolver Documentaci�
    */
   public void setResolver(MultipartResolver resolver) {
      this.resolver = resolver;

      if ((wrapper != null) && (resolver != null)) {
         wrapper.setDelegate(resolver);
      }
   }

   /**
    * Getter
    *
    * @return net.gencat.ctti.canigo.services.logging.LoggingService
    */
   public UploadedFiles getUploadedFiles(HttpServletRequest request,
      String[] fieldsToBind) {
      List fileUploadNames;

      if (fieldsToBind == null) {
         fileUploadNames = Collections.EMPTY_LIST;
      } else {
         fileUploadNames = Arrays.asList(fieldsToBind);
      }

      UploadedFilesImpl files = new UploadedFilesImpl(fileUploadNames);

      if (fileUploadNames != null) {
         try {
            HttpServletRequest requestToCheck = request;

            if (request instanceof MultipartRequestWrapper) {
               //unwrap the real request
               requestToCheck = ((MultipartRequestWrapper) request).getRequest();
            }

            if (requestToCheck instanceof MultipartHttpServletRequest) {
               MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) requestToCheck;
               Map fileMap = multipartRequest.getFileMap();

               for (Iterator it = fileMap.entrySet().iterator(); it.hasNext();) {
                  Map.Entry entry = (Map.Entry) it.next();
                  String key = (String) entry.getKey();
                  MultipartFile value = (MultipartFile) entry.getValue();

                  if (!value.isEmpty()) {
                     files.add(key, value);
                  }
               }
            }
         } catch (Exception ex) {
            ExceptionDetails exDetails = new ExceptionDetails("canigo.services.fileUpload.error_binding_file_uploads",
                  null, Layer.SERVICES, Subsystem.MAIL_SERVICES);
            exDetails.setProperties(new Properties());
            throw new FileUploadServiceException(ex, exDetails);
         }
      }

      return files;
   }

   /**
    * Documentaci�.
    *
    * @param beanFactory Documentaci�
    *
    * @throws BeansException Documentaci�
    */
   public void setBeanFactory(BeanFactory beanFactory)
      throws BeansException {
      wrapper = (WrappedMultipartResolver) beanFactory.getBean(DispatcherServlet.MULTIPART_RESOLVER_BEAN_NAME,
            WrappedMultipartResolver.class);

      if ((wrapper != null) && (resolver != null)) {
         wrapper.setDelegate(resolver);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public long getMaxAttachmentSize() {
      return maxAttachmentSize;
   }

   /**
    * Documentaci�.
    *
    * @param maxAttachmentSize Documentaci�
    */
   public void setMaxAttachmentSize(long maxAttachmentSize) {
      this.maxAttachmentSize = maxAttachmentSize;
   }
}
