/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.fileupload.exception;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.exceptions.SystemException;


/**
 * Wrapper for mailing errors
 *
 */
public class FileUploadServiceException extends SystemException {
   /**
    * Default constructor
    *
    */
   public FileUploadServiceException() {
      super();
   }

   /**
    * Wraps an inner error (probably an exception throwed by a different layer) with details
    * @param arg0 the inner error
    * @param arg1 the details
    */
   public FileUploadServiceException(Throwable arg0, ExceptionDetails arg1) {
      super(arg0, arg1);
   }

   /**
    * Wraps an error with details
    * @param arg0 the details
    */
   public FileUploadServiceException(ExceptionDetails arg0) {
      super(arg0);
   }

   /**
    * Wraps an error with a error code
    * @param arg0 the error code
    */
   public FileUploadServiceException(String arg0) {
      super(arg0);
   }

   /**
    * Wraps an error with a error code and arguments
    * @param arg0 the error code
    * @param arg1 the code arguments
    */
   public FileUploadServiceException(String arg0, Object[] arg1) {
      super(arg0, arg1);
   }

   /**
    * Wraps an error with an error code, arguments and the layer that throws the error
    * @param arg0 the error code
    * @param arg1 the code arguments
    * @param arg2 the layer that throws the error
    */
   public FileUploadServiceException(String arg0, Object[] arg1, Layer arg2) {
      super(arg0, arg1, arg2);
   }

   /**
    * Wraps an error with an error code, arguments, the layer and subsystem that throws the error
    * @param arg0 the error code
    * @param arg1 the code arguments
    * @param arg2 the layer that throws the error
    * @param arg3 the subsystem that throws the error
    */
   public FileUploadServiceException(String arg0, Object[] arg1, Layer arg2,
      Subsystem arg3) {
      super(arg0, arg1, arg2, arg3);
   }

   /**
    * Wraps an inner error (probably an exception throwed by a different layer) with an error code
    * @param arg0 the inner error
    * @param arg1 the error code
    */
   public FileUploadServiceException(Throwable arg0, String arg1) {
      super(arg0, arg1);
   }

   /**
    * Wraps an inner error (probably an exception throwed by a different layer) with an error code and arguments
    * @param arg0 the inner error
    * @param arg1 the error code
    * @param arg2 the code arguments
    */
   public FileUploadServiceException(Throwable arg0, String arg1, Object[] arg2) {
      super(arg0, arg1, arg2);
   }

   /**
    * Wraps an inner error (probably an exception throwed by a different layer) with an error code, arguments and the layer that throws the error
    * @param arg0 the inner error
    * @param arg1 the error code
    * @param arg2 the code arguments
    * @param arg3 the layer that throws the error
    */
   public FileUploadServiceException(Throwable arg0, String arg1,
      Object[] arg2, Layer arg3) {
      super(arg0, arg1, arg2, arg3);
   }

   /**
    * Wraps an inner error (probably an exception throwed by a different layer) with an error code, arguments,the layer and the subsystem that throws the error
    * @param arg0 the inner error
    * @param arg1 the error code
    * @param arg2 the code arguments
    * @param arg3 the layer that throws the error
    * @param arg4 the subsystem that throws the error
    */
   public FileUploadServiceException(Throwable arg0, String arg1,
      Object[] arg2, Layer arg3, Subsystem arg4) {
      super(arg0, arg1, arg2, arg3, arg4);
   }
}
