/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.fileupload.impl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.gencat.ctti.canigo.services.fileupload.UploadedFile;
import net.gencat.ctti.canigo.services.fileupload.UploadedFiles;

import org.springframework.web.multipart.MultipartFile;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class UploadedFilesImpl implements UploadedFiles {
   /**
    * Documentaci�.
    */
   private Map files = new HashMap();

   /**
    * Creates a new UploadedFilesImpl object.
    *
    * @param fields DOCUMENT ME.
    */
   public UploadedFilesImpl(List fields) {
      super();

      for (Iterator iter = fields.iterator(); iter.hasNext();) {
         String entryName = (String) iter.next();
         files.put(entryName, null);
      }
   }

   /**
    * Documentaci�.
    *
    * @param tagId Documentaci�
    *
    * @return Documentaci�
    */
   public UploadedFile getFile(String tagId) {
      if (isFileAvailable(tagId)) {
         return new MultipartFileWrapper((MultipartFile) files.get(tagId));
      }

      return null;
   }

   /**
    * Documentaci�.
    *
    * @param tagId Documentaci�
    *
    * @return Documentaci�
    */
   public boolean isFileAvailable(String tagId) {
      if (files.containsKey(tagId) && (files.get(tagId) != null)) {
         MultipartFile file = (MultipartFile) files.get(tagId);

         if (!file.isEmpty()) {
            return true;
         }
      }

      return false;
   }

   /**
    * Documentaci�.
    *
    * @param tagId Documentaci�
    * @param file Documentaci�
    */
   public void add(String tagId, MultipartFile file) {
      if (files.containsKey(tagId)) {
         files.put(tagId, file);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean hasFiles() {
      if (files.isEmpty()) {
         return false;
      }

      for (Iterator iter = files.keySet().iterator(); iter.hasNext();) {
         String fieldName = (String) iter.next();

         if (isFileAvailable(fieldName)) {
            return true;
         }
      }

      return false;
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   class MultipartFileWrapper implements UploadedFile {
      /**
       * Documentaci�.
       */
      MultipartFile delegate;

      /**
       * Creates a new MultipartFileWrapper object.
       *
       * @param delegate DOCUMENT ME.
       */
      public MultipartFileWrapper(MultipartFile delegate) {
         super();
         // TODO Auto-generated constructor stub
         this.delegate = delegate;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       *
       * @throws IOException Documentaci�
       */
      public byte[] getBytes() throws IOException {
         return delegate.getBytes();
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getContentType() {
         return delegate.getContentType();
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       *
       * @throws IOException Documentaci�
       */
      public InputStream getInputStream() throws IOException {
         return delegate.getInputStream();
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getName() {
         return delegate.getName();
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getOriginalFilename() {
         return delegate.getOriginalFilename();
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public long getSize() {
         return delegate.getSize();
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public boolean isEmpty() {
         return delegate.isEmpty();
      }

      /**
       * Documentaci�.
       *
       * @param dest Documentaci�
       *
       * @throws IOException Documentaci�
       * @throws IllegalStateException Documentaci�
       */
      public void transferTo(File dest)
         throws IOException, IllegalStateException {
         delegate.transferTo(dest);
      }
   }
}
