/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.fileupload;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;


/**
 *
 * @author romaferre
 *static methods to:
 * - obtain the service from the servlet context and
 * - to get an UploadedFiles object from a request (resolves the service by examining the request)
 */
public class FileUploadServiceUtils {
   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    * @return Documentaci�
    */
   public static FileUploadService getService(ServletContext context) {
      WebApplicationContext webContext = WebApplicationContextUtils.getRequiredWebApplicationContext(context);

      return (FileUploadService) webContext.getBean(FileUploadService.FILE_UPLOAD_BEAN_FACTORY_KEY);
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param filenames Documentaci�
    *
    * @return Documentaci�
    */
   public static UploadedFiles getFiles(HttpServletRequest request,
      String[] filenames) {
      FileUploadService service = getService(request.getSession()
                                                    .getServletContext());

      if (service != null) {
         return service.getUploadedFiles(request, filenames);
      }

      return UploadedFiles.EMPTY_INSTANCE;
   }
}
