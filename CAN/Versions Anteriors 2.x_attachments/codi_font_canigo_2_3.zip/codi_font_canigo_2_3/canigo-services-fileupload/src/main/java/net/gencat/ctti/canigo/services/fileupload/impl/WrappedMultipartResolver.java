/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.fileupload.impl;

import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.fileupload.exception.FileUploadServiceException;

import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class WrappedMultipartResolver implements MultipartResolver {
   /**
    * Documentaci�.
    */
   MultipartResolver delegate = new CommonsMultipartResolver();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void cleanupMultipart(MultipartHttpServletRequest arg0) {
      delegate.cleanupMultipart(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean isMultipart(HttpServletRequest arg0) {
      return delegate.isMultipart(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    *
    * @return Documentaci�
    */
   public MultipartHttpServletRequest resolveMultipart(
      HttpServletRequest request) {
      try {
         return delegate.resolveMultipart(request);
      } catch (MaxUploadSizeExceededException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.fileUpload.attachment_size_exceeded",
               new String[] { Long.toString(ex.getMaxUploadSize()) },
               Layer.SERVICES, Subsystem.MAIL_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FileUploadServiceException(ex, exDetails);
      } catch (MultipartException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.fileUpload.error_resolving_multipart_uploads",
               null, Layer.SERVICES, Subsystem.MAIL_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FileUploadServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public MultipartResolver getDelegate() {
      return delegate;
   }

   /**
    * Documentaci�.
    *
    * @param delegate Documentaci�
    */
   public void setDelegate(MultipartResolver delegate) {
      this.delegate = delegate;
   }
}
