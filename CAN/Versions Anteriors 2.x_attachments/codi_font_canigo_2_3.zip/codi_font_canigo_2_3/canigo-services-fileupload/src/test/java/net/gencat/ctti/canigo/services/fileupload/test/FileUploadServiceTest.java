/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.fileupload.test;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.fileupload.FileUploadService;
import net.gencat.ctti.canigo.services.fileupload.UploadedFile;
import net.gencat.ctti.canigo.services.fileupload.UploadedFiles;
import net.gencat.ctti.canigo.services.fileupload.exception.FileUploadServiceException;
import net.gencat.ctti.canigo.services.fileupload.impl.FileUploadServiceImpl;
import net.gencat.ctti.canigo.services.fileupload.impl.WrappedMultipartResolver;

import org.apache.commons.fileupload.DiskFileUpload;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadBase;
import org.apache.commons.fileupload.FileUploadBase.SizeLimitExceededException;
import org.apache.commons.fileupload.FileUploadException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockServletContext;
import org.springframework.web.context.support.StaticWebApplicationContext;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.util.WebUtils;


/**
 * FileUploadService test
 *
 */
public class FileUploadServiceTest extends TestCase {
   /**
    * Initializing method
    */
   protected void setUp() throws Exception {
      super.setUp();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private HttpServletRequest getMockedMultiPartRequest() {
      MockHttpServletRequest mockRequest = new MockHttpServletRequest();
      mockRequest.setContentType("multipart/form-data");
      mockRequest.addHeader("Content-type", "multipart/form-data");
      mockRequest.addParameter("getField", "getValue");

      return mockRequest;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private FileUploadServiceImpl getUploadService() {
      //Obtain the test applicationContext, where we have bound a MockResolver, see below MockCommonsMultipartResolver
      BeanFactory beanFactory = new ClassPathXmlApplicationContext(
            "applicationContext.xml");

      //Obtain the service itself
      FileUploadServiceImpl fileUploadService = (FileUploadServiceImpl) beanFactory.getBean(
            "FileUploadService");
      assertNotNull(fileUploadService);

      return fileUploadService;
   }

   /**
    * FileUploadService test with a file attachment
    *
    */
   public void testSimpleUpload() {
      FileUploadServiceImpl fileUploadService = getUploadService();

      //here we prepare a mocked multipart request.
      HttpServletRequest originalRequest = getMockedMultiPartRequest();
      //Now we see if our resolver agrees that this request is multipart
      assertTrue(fileUploadService.getResolver().isMultipart(originalRequest));

      try {
         //this step in a real situation is performed by the Spring Framework
         MultipartHttpServletRequest request = fileUploadService.getResolver()
                                                                .resolveMultipart(originalRequest);

         //this is what a user of the service will actually do to obtain the uploaded files...
         UploadedFiles uploads = fileUploadService.getUploadedFiles(request,
               new String[] { "field1", "field2", "nonUploadedField" });
         //Now the user would just use the UploadedFiles interface to interact with the files themselves...
         //we just perform several assertions here
         assertNotNull(uploads);
         //we really must have some files here...
         assertTrue(uploads.hasFiles());

         //precisely, those mapped by field1 and field2
         assertTrue(uploads.isFileAvailable("field1"));
         assertTrue(uploads.isFileAvailable("field2"));
         //trying with a non uploaded file (the user stated that he/she wanted it, but was not uploaded
         assertFalse(uploads.isFileAvailable("nonUploadedField"));
         assertNotNull(uploads.getFile("field1"));
         assertNotNull(uploads.getFile("field2"));
         assertNull(uploads.getFile("nonUploadedField"));

         //let us use the file mapped by field1 a bit
         UploadedFile file1 = uploads.getFile("field1");
         assertFalse(file1.isEmpty());
         assertEquals(file1.getOriginalFilename(), "field1.txt");
         assertEquals(file1.getName(), "field1");
      } catch (MultipartException e) {
         fail(e.toString());
      }
   }

   /**
    * Documentaci�.
    */
   public void testNoUploadPerformed() {
      FileUploadServiceImpl fileUploadService = getUploadService();

      //HERE is the twist, we set a MockEmptyCommonsMultipartResolver (see below) which even though the request will
      //be interpreted as multipart, will return an empty file list 
      fileUploadService.setResolver(new MockEmptyCommonsMultipartResolver());

      //END of said twist

      //here we prepare a mocked multipart request.
      HttpServletRequest originalRequest = getMockedMultiPartRequest();
      //Now we see if our resolver agrees that this request is multipart
      assertTrue(fileUploadService.getResolver().isMultipart(originalRequest));

      try {
         //this step in a real situation is performed by the Spring Framework
         MultipartHttpServletRequest request = fileUploadService.getResolver()
                                                                .resolveMultipart(originalRequest);

         //this is what a user of the service will actually do to obtain the uploaded files...
         UploadedFiles uploads = fileUploadService.getUploadedFiles(request,
               new String[] { "field1", "field2", "nonUploadedField" });
         //should not have files, none were uploaded
         assertFalse(uploads.hasFiles());
      } catch (MultipartException e) {
         fail(e.toString());
      }
   }

   /**
    * Documentaci�.
    */
   public void testRequestedNullList() {
      FileUploadServiceImpl fileUploadService = getUploadService();

      //here we prepare a mocked multipart request.
      HttpServletRequest originalRequest = getMockedMultiPartRequest();
      //Now we see if our resolver agrees that this request is multipart
      assertTrue(fileUploadService.getResolver().isMultipart(originalRequest));

      try {
         //this step in a real situation is performed by the Spring Framework
         MultipartHttpServletRequest request = fileUploadService.getResolver()
                                                                .resolveMultipart(originalRequest);

         //this is what a user of the service will actually do to obtain the uploaded files...
         UploadedFiles uploads = fileUploadService.getUploadedFiles(request,
               null);
         //should not have files, none were requested
         assertFalse(uploads.hasFiles());
      } catch (MultipartException e) {
         fail(e.toString());
      }
   }

   /**
    * Documentaci�.
    */
   public void testHugeFileUpload() {
      FileUploadServiceImpl fileUploadService = getUploadService();

      //HUGE FILE: HERE is the twist, we set a MockHugeFileCommonsMultipartResolver (see below)
      //It will throw a FileUploadBase.SizeLimitExceededException();
      //we expect this exception to be wrapped properly with a ServiceException
      fileUploadService.setResolver(new MockHugeFileCommonsMultipartResolver());

      //END of said twist

      //here we prepare a mocked multipart request.
      HttpServletRequest originalRequest = getMockedMultiPartRequest();
      //Now we see if our resolver agrees that this request is multipart
      assertTrue(fileUploadService.getResolver().isMultipart(originalRequest));

      try {
         //it has to break here...
         fileUploadService.getResolver().resolveMultipart(originalRequest);
         fail("No exception was thrown on huge file situation");
      } catch (Exception e) {
         assertTrue(e instanceof FileUploadServiceException);

         FileUploadServiceException fex = (FileUploadServiceException) e;
      }
   }

   /**
    * the following mockObjects on loan from the Spring Framework's CommonMultiPartResolverTests
    *
    */
   public static class MockCommonsMultipartResolver
      extends CommonsMultipartResolver {
      /**
       * Documentaci�.
       */
      private boolean empty;

      /**
       * Documentaci�.
       *
       * @param empty Documentaci�
       */
      protected void setEmpty(boolean empty) {
         this.empty = empty;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      protected DiskFileUpload newFileUpload() {
         return new DiskFileUpload() {
               public List parseRequest(HttpServletRequest request) {
                  if (request instanceof MultipartHttpServletRequest) {
                     throw new IllegalStateException(
                        "Already a multipart request");
                  }

                  List fileItems = new ArrayList();
                  MockFileItem fileItem1 = new MockFileItem("field1", "type1",
                        empty ? "" : "field1.txt", empty ? "" : "text1");
                  MockFileItem fileItem2 = new MockFileItem("field2", "type2",
                        empty ? "" : "C:/field2.txt", empty ? "" : "text2");
                  MockFileItem fileItem2x = new MockFileItem("field2x",
                        "type2", empty ? "" : "C:\\field2x.txt",
                        empty ? "" : "text2");
                  MockFileItem fileItem3 = new MockFileItem("field3", null,
                        null, "value3");
                  MockFileItem fileItem4 = new MockFileItem("field4", null,
                        null, "value4");
                  MockFileItem fileItem5 = new MockFileItem("field4", null,
                        null, "value5");
                  fileItems.add(fileItem1);
                  fileItems.add(fileItem2);
                  fileItems.add(fileItem2x);
                  fileItems.add(fileItem3);
                  fileItems.add(fileItem4);
                  fileItems.add(fileItem5);

                  return fileItems;
               }
            };
      }
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   public static class MockEmptyCommonsMultipartResolver
      extends CommonsMultipartResolver {
      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      protected DiskFileUpload newFileUpload() {
         return new DiskFileUpload() {
               public List parseRequest(HttpServletRequest request) {
                  return Collections.EMPTY_LIST;
               }
            };
      }
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   public static class MockHugeFileCommonsMultipartResolver
      extends CommonsMultipartResolver {
      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      protected DiskFileUpload newFileUpload() {
         return new DiskFileUpload() {
               public List parseRequest(HttpServletRequest request)
                  throws FileUploadException {
                  throw new FileUploadBase.SizeLimitExceededException();
               }
            };
      }
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   private static class MockFileItem implements FileItem {
      /**
       * Documentaci�.
       */
      private File writtenFile;

      /**
       * Documentaci�.
       */
      private String contentType;

      /**
       * Documentaci�.
       */
      private String fieldName;

      /**
       * Documentaci�.
       */
      private String name;

      /**
       * Documentaci�.
       */
      private String value;

      /**
       * Documentaci�.
       */
      private boolean deleted;

      /**
       * Creates a new MockFileItem object.
       *
       * @param fieldName DOCUMENT ME.
       * @param contentType DOCUMENT ME.
       * @param name DOCUMENT ME.
       * @param value DOCUMENT ME.
       */
      public MockFileItem(String fieldName, String contentType, String name,
         String value) {
         this.fieldName = fieldName;
         this.contentType = contentType;
         this.name = name;
         this.value = value;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       *
       * @throws IOException Documentaci�
       */
      public InputStream getInputStream() throws IOException {
         return new ByteArrayInputStream(value.getBytes());
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getContentType() {
         return contentType;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getName() {
         return name;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public boolean isInMemory() {
         return true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public long getSize() {
         return value.length();
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public byte[] get() {
         return value.getBytes();
      }

      /**
       * Documentaci�.
       *
       * @param encoding Documentaci�
       *
       * @return Documentaci�
       *
       * @throws UnsupportedEncodingException Documentaci�
       */
      public String getString(String encoding)
         throws UnsupportedEncodingException {
         return new String(get(), encoding);
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getString() {
         return value;
      }

      /**
       * Documentaci�.
       *
       * @param file Documentaci�
       *
       * @throws Exception Documentaci�
       */
      public void write(File file) throws Exception {
         this.writtenFile = file;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public File getWrittenFile() {
         return writtenFile;
      }

      /**
       * Documentaci�.
       */
      public void delete() {
         this.deleted = true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public boolean isDeleted() {
         return deleted;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getFieldName() {
         return fieldName;
      }

      /**
       * Documentaci�.
       *
       * @param s Documentaci�
       */
      public void setFieldName(String s) {
         this.fieldName = s;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public boolean isFormField() {
         return (this.name == null);
      }

      /**
       * Documentaci�.
       *
       * @param b Documentaci�
       */
      public void setFormField(boolean b) {
         throw new UnsupportedOperationException();
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       *
       * @throws IOException Documentaci�
       * @throws UnsupportedOperationException Documentaci�
       */
      public OutputStream getOutputStream() throws IOException {
         throw new UnsupportedOperationException();
      }
   }
}
