/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.http;

import java.applet.Applet;

import java.util.HashMap;
import java.util.Map;

import com.caucho.hessian.client.HessianProxyFactory;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public abstract class HessianApplet extends Applet {
   /**
    *
    */
   private static final long serialVersionUID = 8698659585226703360L;

   /** The package separator character '.' */
   private static final char PACKAGE_SEPARATOR_CHAR = '.';

   /** The inner class separator character '$' */
   private static final char INNER_CLASS_SEPARATOR_CHAR = '$';

   /** The CGLIB class separator character "$$" */
   private static final String CGLIB_CLASS_SEPARATOR_CHAR = "$$";

   /**
    * Documentaci�.
    */
   private Map servicesMap;

   /**
    * Documentaci�.
    */
   private Class[] interfaceServices;

   /**
    * Creates a new HessianApplet object.
    *
    * @param interfaceService DOCUMENT ME.
    */
   protected HessianApplet(Class interfaceService) {
      this.interfaceServices = new Class[] { interfaceService };
      this.servicesMap = new HashMap(1);
   }

   /**
    * Creates a new HessianApplet object.
    *
    * @param interfaceServices DOCUMENT ME.
    */
   protected HessianApplet(Class[] interfaceServices) {
      this.interfaceServices = interfaceServices;
      this.servicesMap = new HashMap();
   }

   /**
    * Documentaci�.
    */
   public void init() {
      String hostUrl = getParameter("hostUrl");

      try {
         HessianProxyFactory hessianproxyfactory = new HessianProxyFactory();

         for (int i = 0; i < this.interfaceServices.length; i++) {
            Class interfaceClass = this.interfaceServices[i];

            String serviceUrl = hostUrl + "remoting/" +
               getShortName(interfaceClass);
            Object proxyService = hessianproxyfactory.create(interfaceClass,
                  serviceUrl);

            this.servicesMap.put(interfaceClass, proxyService);
         }
      } catch (Exception exception) {
         exception.printStackTrace();
      }
   }

   /**
    * Documentaci�.
    *
    * @param interfaceService Documentaci�
    *
    * @return Documentaci�
    */
   protected Object getService(Class interfaceService) {
      return this.servicesMap.get(interfaceService);
   }

   /**
    * Get the class name without the qualified package name.
    * @param clazz the class to get the short name for
    * @return the class name of the class without the package name
    * @throws IllegalArgumentException if the class is null
    */
   private static String getShortName(Class clazz) {
      return getShortName(clazz.getName());
   }

   /**
    * Get the class name without the qualified package name.
    * @param className the className to get the short name for
    * @return the class name of the class without the package name
    * @throws IllegalArgumentException if the className is empty
    */
   private static String getShortName(String className) {
      int lastDotIndex = className.lastIndexOf(PACKAGE_SEPARATOR_CHAR);
      int nameEndIndex = className.indexOf(CGLIB_CLASS_SEPARATOR_CHAR);

      if (nameEndIndex == -1) {
         nameEndIndex = className.length();
      }

      String shortName = className.substring(lastDotIndex + 1, nameEndIndex);
      shortName = shortName.replace(INNER_CLASS_SEPARATOR_CHAR,
            PACKAGE_SEPARATOR_CHAR);

      return shortName;
   }
}
