DROP SEQUENCE ACL_PERMISSION_SEQ;
DROP SEQUENCE ACL_OBJECT_SEQ;
drop table authorities;
drop table acl_permission;
drop table acl_object_identity ;
drop table users ;

CREATE TABLE users (
        username VARCHAR2(50) NOT NULL PRIMARY KEY,
        password VARCHAR2(50) NOT NULL,
        enabled number(1) NOT NULL
);

CREATE TABLE authorities (
        username VARCHAR2(50) NOT NULL,
        authority VARCHAR2(50) NOT NULL
);
CREATE UNIQUE INDEX ix_auth_username ON authorities ( username, authority );

ALTER TABLE authorities ADD CONSTRAINT fk_authorities_users foreign key (username) REFERENCES users(username);


CREATE TABLE acl_object_identity (
     id NUMBER PRIMARY KEY,
     object_identity VARCHAR2(250) NOT NULL,
     parent_object INTEGER,
     acl_class VARCHAR2(250) NOT NULL,
     CONSTRAINT unique_object_identity UNIQUE(object_identity),
     FOREIGN KEY (parent_object) REFERENCES acl_object_identity(id)
);
create sequence ACL_OBJECT_SEQ
start with 1
increment by 1;

CREATE OR REPLACE TRIGGER ACL_OBJ_TRIGGER
before insert on ACL_OBJECT_IDENTITY
for each row
begin
select ACL_OBJECT_SEQ.nextval into :new.id from dual;
end;

CREATE TABLE acl_permission (
     id NUMBER PRIMARY KEY,
     acl_object_identity NUMBER NOT NULL,
     recipient VARCHAR2(100) NOT NULL,
     mask NUMBER NOT NULL,
     CONSTRAINT unique_recipient UNIQUE(acl_object_identity, recipient),
     FOREIGN KEY (acl_object_identity) REFERENCES acl_object_identity(id)
);

create sequence ACL_PERMISSION_SEQ
start with 1
increment by 1;

CREATE OR REPLACE TRIGGER ACL_PERMISSION_TRIGGER
before insert on ACL_PERMISSION
for each row
begin
select ACL_PERMISSION_SEQ.nextval into :new.id from dual;
end;

