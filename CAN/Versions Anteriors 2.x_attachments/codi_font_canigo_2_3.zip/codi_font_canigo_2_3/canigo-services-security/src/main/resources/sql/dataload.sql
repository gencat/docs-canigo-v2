insert into acl_object_identity values (null, 'net.gencat.ctti.canigo.samples.jpetstore.model.Account:ACID', null, 'net.sf.acegisecurity.acl.basic.SimpleAclEntry');
insert into acl_object_identity values (null, 'net.gencat.ctti.canigo.samples.jpetstore.model.Account:j2ee', null, 'net.sf.acegisecurity.acl.basic.SimpleAclEntry');
insert into acl_permission values (null, 1, 'usuario_admin1', 2);
insert into acl_permission values (null, 2, 'usuario_admin1', 2);
insert into acl_permission values (null, 1, 'usuario_user2', 2);

INSERT INTO PARTY_GROUP (PARTY_ID, GROUP_NAME) VALUES (1, 'GROUP ADMIN');
INSERT INTO PARTY_GROUP (PARTY_ID, GROUP_NAME) VALUES (2, 'GROUP USER');

INSERT INTO ROLE (ROLE_ID, ROLE_NAME) VALUES (3, 'ROLE_BASE');
INSERT INTO ROLE (ROLE_ID, ROLE_NAME, ROLE_ID_PARENT) VALUES (1, 'ROLE_ADMIN', 3);
INSERT INTO ROLE (ROLE_ID, ROLE_NAME) VALUES (2, 'ROLE_USER');

INSERT INTO USER_LOGIN (USER_LOGIN_ID, PARTY_ID, PASSWORD) VALUES ('usuario_admin1', 1, 'password1');
INSERT INTO PARTY_ROLE (USER_LOGIN_ID, ROLE_ID) VALUES ('usuario_admin1', 1);

INSERT INTO USER_LOGIN (USER_LOGIN_ID, PARTY_ID, PASSWORD) VALUES ('usuario_user2', 2, 'password2');
INSERT INTO PARTY_ROLE (USER_LOGIN_ID, ROLE_ID) VALUES ('usuario_user2', 2);

INSERT INTO USER_LOGIN (USER_LOGIN_ID, PARTY_ID, PASSWORD) VALUES ('gestoruser', 2, 'password In LDAP');
INSERT INTO PARTY_ROLE (USER_LOGIN_ID, ROLE_ID) VALUES ('gestoruser', 1);

INSERT INTO USER_LOGIN (USER_LOGIN_ID, PARTY_ID, PASSWORD) VALUES ('46238600K', 2, 'password In SACE');
INSERT INTO PARTY_ROLE (USER_LOGIN_ID, ROLE_ID) VALUES ('46238600K', 1);

INSERT INTO ROLE (ROLE_ID, ROLE_NAME) VALUES (4, 'ROLE_GRAND_PARENT');
INSERT INTO ROLE (ROLE_ID, ROLE_NAME, ROLE_ID_PARENT) VALUES (5, 'ROLE_PARENT', 4);
INSERT INTO ROLE (ROLE_ID, ROLE_NAME, ROLE_ID_PARENT) VALUES (6, 'ROLE_SON', 5);

INSERT INTO USER_LOGIN (USER_LOGIN_ID, PARTY_ID, PASSWORD) VALUES ('USER_ROLE_HIERARCHY', 2, 'password');
INSERT INTO PARTY_ROLE (USER_LOGIN_ID, ROLE_ID) VALUES ('USER_ROLE_HIERARCHY', 6);

INSERT INTO PARTY_GROUP (PARTY_ID, GROUP_NAME) VALUES (3, 'PARENT GROUP');
INSERT INTO PARTY_GROUP (PARTY_ID, GROUP_PARENT_ID, GROUP_NAME) VALUES (4, 3, 'TEST GROUP WITH ROLE');
INSERT INTO USER_LOGIN (USER_LOGIN_ID, PARTY_ID, PASSWORD) VALUES ('USER WITH GROUP WITH ROLE', 3, 'password');
INSERT INTO ROLE (ROLE_ID, ROLE_NAME) VALUES (7, 'ROLE_TEST_GROUP_WITH_ROLE');
INSERT INTO GROUP_ROLE(PARTY_ID, ROLE_ID) VALUES (3, 4);

select PARTY_OBJECT_SEQ.nextval from dual;
select PARTY_OBJECT_SEQ.nextval from dual;
select PARTY_OBJECT_SEQ.nextval from dual;
select PARTY_OBJECT_SEQ.nextval from dual;


select ROLE_OBJECT_SEQ.nextval from dual;
select ROLE_OBJECT_SEQ.nextval from dual;
select ROLE_OBJECT_SEQ.nextval from dual;
select ROLE_OBJECT_SEQ.nextval from dual;
select ROLE_OBJECT_SEQ.nextval from dual;
select ROLE_OBJECT_SEQ.nextval from dual;