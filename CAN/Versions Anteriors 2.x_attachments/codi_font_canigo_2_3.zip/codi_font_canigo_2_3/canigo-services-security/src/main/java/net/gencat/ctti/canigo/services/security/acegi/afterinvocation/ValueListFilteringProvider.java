/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.afterinvocation;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import net.mlw.vlh.DefaultListBackedValueList;
import net.mlw.vlh.ValueList;
import net.sf.acegisecurity.AccessDeniedException;
import net.sf.acegisecurity.Authentication;
import net.sf.acegisecurity.AuthorizationServiceException;
import net.sf.acegisecurity.ConfigAttribute;
import net.sf.acegisecurity.ConfigAttributeDefinition;
import net.sf.acegisecurity.acl.AclEntry;
import net.sf.acegisecurity.acl.basic.AbstractBasicAclEntry;
import net.sf.acegisecurity.afterinvocation.BasicAclEntryAfterInvocationCollectionFilteringProvider;

import org.springframework.util.ClassUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class ValueListFilteringProvider
   extends BasicAclEntryAfterInvocationCollectionFilteringProvider {
   /**
    * Documentaci�.
    */
   private Set businessClassesUsingAclsSet = new HashSet();

   /**
    *
    */
   public Object decide(Authentication authentication, Object object,
      ConfigAttributeDefinition config, Object returnedObject)
      throws AccessDeniedException {
      Iterator iter = config.getConfigAttributes();

      if (returnedObject == null) {
         if (logger.isDebugEnabled()) {
            logger.debug("Return object is null, skipping");
         }

         return null;
      }

      // Cast to ValueList
      ValueList valueList = null;

      if (returnedObject instanceof ValueList) {
         valueList = (ValueList) returnedObject;
      } else {
         throw new AuthorizationServiceException(
            "A ValueList was required as the returnedObject, but the returnedObject was: " +
            returnedObject);
      }

      // Check if we apply ACLs for this ValueList
      if (valueList.getList().size() > 0) {
         Class businessClass = valueList.getList().get(0).getClass();

         if (!this.businessClassesUsingAclsSet.contains(businessClass)) {
            return returnedObject;
         }
      }

      while (iter.hasNext()) {
         ConfigAttribute attr = (ConfigAttribute) iter.next();

         if (this.supports(attr)) {
            // Need to process the Collection for this invocation
            Filterer filterer = null;
            filterer = new CollectionFilterer(valueList.getList());

            // Locate unauthorised Collection elements
            Iterator collectionIter = filterer.iterator();

            while (collectionIter.hasNext()) {
               Object domainObject = collectionIter.next();

               boolean hasPermission = false;

               AclEntry[] acls = null;

               if (domainObject == null) {
                  hasPermission = true;
               } else {
                  acls = super.getAclManager()
                              .getAcls(domainObject, authentication);
               }

               if ((acls != null) && (acls.length != 0)) {
                  for (int i = 0; i < acls.length; i++) {
                     // Locate processable AclEntrys
                     if (acls[i] instanceof AbstractBasicAclEntry) {
                        AbstractBasicAclEntry processableAcl = (AbstractBasicAclEntry) acls[i];

                        // See if principal has any of the required
                        // permissions
                        for (int y = 0;
                              y < super.getRequirePermission().length; y++) {
                           if (processableAcl.isPermitted(
                                    super.getRequirePermission()[y])) {
                              hasPermission = true;

                              if (logger.isDebugEnabled()) {
                                 logger.debug(
                                    "Principal is authorised for element: " +
                                    domainObject + " due to ACL: " +
                                    processableAcl.toString());
                              }
                           }
                        }
                     }
                  }
               }

               if (!hasPermission) {
                  filterer.remove(domainObject);

                  if (logger.isDebugEnabled()) {
                     logger.debug("Principal is NOT authorised for element: " +
                        domainObject);
                  }
               }
            }

            return new DefaultListBackedValueList((List) filterer.getFilteredObject());
         }
      }

      return returnedObject;
   }

   /**
    * Documentaci�.
    *
    * @param aclsClassList Documentaci�
    *
    * @throws ClassNotFoundException Documentaci�
    */
   public void setAclsClassesList(List aclsClassList)
      throws ClassNotFoundException {
      this.businessClassesUsingAclsSet = new HashSet();

      for (Iterator iter = aclsClassList.iterator(); iter.hasNext();) {
         String className = (String) iter.next();
         this.addFilterForBusinessClass(ClassUtils.forName(className));
      }
   }

   /**
    * Documentaci�.
    *
    * @param businessClass Documentaci�
    */
   public void addFilterForBusinessClass(Class businessClass) {
      this.businessClassesUsingAclsSet.add(businessClass);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List getAclsClassesList() {
      return new ArrayList(this.businessClassesUsingAclsSet);
   }
}
