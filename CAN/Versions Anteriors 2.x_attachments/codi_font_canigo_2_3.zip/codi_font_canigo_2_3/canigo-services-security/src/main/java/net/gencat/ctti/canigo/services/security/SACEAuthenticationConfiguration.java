/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import java.util.Properties;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.security.acegi.https.HttpsConfigBean;
import net.gencat.ctti.canigo.services.security.acegi.providers.sace.SACEAuthenticationProvider;
import net.gencat.ctti.canigo.services.security.acegi.providers.sace.SACEPasswordAuthenticationDao;
import net.gencat.ctti.canigo.services.security.acegi.providers.sace.enums.SACEUserNameFormatEnum;
import net.sf.acegisecurity.providers.AuthenticationProvider;
import net.sf.acegisecurity.providers.dao.cache.EhCacheBasedUserCache;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.util.Assert;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.9 $
  */
public class SACEAuthenticationConfiguration
   extends AbstractAuthenticationConfiguration {
	
	private ApplicationContext applicationContext;
   /**
    * Documentaci�.
    */
   HttpsConfigBean httpsConfigBean;

   /** Gestor de logs. */
   private LoggingService logService = null;

   /** Certificates from application classpath. */
   private Properties certificates;

   /**
    * Documentaci�.
    */
   private SACEUserNameFormatEnum userFormat;

   /** Server KeyStore params. */
   private String keyStore;

   /**
    * Documentaci�.
    */
   private String keyStorePassPhrase;

   /**
    */
   private String urlSACE = "https://sace.prepdc.gencat.intranet/SACE/SACE_Logon.aspx?XMLIn=";

   /** Indicador de si el servidor on est� desplegat el servei �s un WAS. <br>
    *  El tractament en aquest cas requereix d'una classe propiet�ria de IBM. */
   private boolean wasServer;
   
   
   /** ASM: Internacionalitzaci� de missatges d'error */
   private I18nService i18nSecurityService = null;
   
   /**
    * Documentaci�.
    *
    * @param ldapURL Documentaci�
    */
   public void setUrlSACE(String ldapURL) {
      this.urlSACE = ldapURL;
   }

   /**
    * Documentaci�.
    *
    * @param applicationContext Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   protected AuthenticationProvider getAuthenticationProvider(
      ApplicationContext applicationContext) throws Exception {
      SACEPasswordAuthenticationDao saceDAO = new SACEPasswordAuthenticationDao();

      saceDAO.setLogService(this.logService);
      saceDAO.setI18nSecurityService(this.i18nSecurityService);
      saceDAO.setWasServer(this.wasServer);
      saceDAO.setSACEHostName(this.urlSACE);
      saceDAO.setUserNameFormatEnum(this.userFormat);
      saceDAO.setCertificates(this.certificates);
      saceDAO.setKeyStore(this.keyStore);
      saceDAO.setKeyStorePassPhrase(this.keyStorePassPhrase);
      saceDAO.setHttpsConfigBean(this.httpsConfigBean);

      saceDAO.setAuthoritiesDAO(super.getAuthoritiesDAO(applicationContext));

      SACEAuthenticationProvider passwordDaoAuthenticationProvider = createPasswordDaoAuthenticationProvider(saceDAO);

      return passwordDaoAuthenticationProvider;
   }
   
   protected SACEAuthenticationProvider createPasswordDaoAuthenticationProvider(
		   SACEPasswordAuthenticationDao dao) throws Exception {
	   
	  SACEAuthenticationProvider passwordDaoAuthenticationProvider = new SACEAuthenticationProvider();
      EhCacheBasedUserCache userCache = (EhCacheBasedUserCache) applicationContext.getBean(
            "userCache");
      passwordDaoAuthenticationProvider.setUserCache(userCache);
      passwordDaoAuthenticationProvider.setAuthenticationDao(dao);

      passwordDaoAuthenticationProvider.afterPropertiesSet();

      return passwordDaoAuthenticationProvider;
   }

   /**
    * Documentaci�.
    *
    * @param userFormatString Documentaci�
    */
   public void setUserNameFormat(String userFormatString) {
      SACEUserNameFormatEnum format = SACEUserNameFormatEnum.getEnum(userFormatString);

      if (format == null) {
         throw new IllegalArgumentException(userFormatString +
            ": invalid user format, values authorized: " +
            SACEUserNameFormatEnum.INTERNAL_CODE.getLabel() + " or " +
            SACEUserNameFormatEnum.NIF.getLabel());
      }

      this.userFormat = format;
   }

   /**
    * Documentaci�.
    *
    * @param userFormat Documentaci�
    */
   public void setUserNameFormatEnum(SACEUserNameFormatEnum userFormat) {
      this.userFormat = userFormat;
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void afterPropertiesSet() throws Exception {
      Assert.notNull(this.urlSACE, "urlSACE must be set");
      Assert.notNull(this.userFormat, "userFormat must be set");
   }

   /**
    * @return Returns the logService.
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * @param logService The logService to set.
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * @return Returns the wasServer.
    */
   public boolean isWasServer() {
      return wasServer;
   }

   /**
    * @param wasServer The wasServer to set.
    */
   public void setWasServer(boolean wasServer) {
      this.wasServer = wasServer;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Properties getCertificates() {
      return certificates;
   }

   /**
    * Documentaci�.
    *
    * @param certificates Documentaci�
    */
   public void setCertificates(Properties certificates) {
      this.certificates = certificates;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getKeyStore() {
      return keyStore;
   }

   /**
    * Documentaci�.
    *
    * @param keyStore Documentaci�
    */
   public void setKeyStore(String keyStore) {
      this.keyStore = keyStore;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getKeyStorePassPhrase() {
      return keyStorePassPhrase;
   }

   /**
    * Documentaci�.
    *
    * @param keyStorePassPhrase Documentaci�
    */
   public void setKeyStorePassPhrase(String keyStorePassPhrase) {
      this.keyStorePassPhrase = keyStorePassPhrase;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public HttpsConfigBean getHttpsConfigBean() {
      return httpsConfigBean;
   }

   /**
    * Documentaci�.
    *
    * @param httpsConfigBean Documentaci�
    */
   public void setHttpsConfigBean(HttpsConfigBean httpsConfigBean) {
      this.httpsConfigBean = httpsConfigBean;
   }
   
   public void setApplicationContext(ApplicationContext applicationContext)
   throws BeansException {
	   this.applicationContext = applicationContext;
	   super.setApplicationContext(applicationContext);
   }   
   
    /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public I18nService getI18nSecurityService() {
      return i18nSecurityService;
   }

   /**
    * Documentaci�.
    *
    * @param service Documentaci�
    */
   public void setI18nSecurityService(I18nService service) {
      i18nSecurityService = service;
   }
   
}
