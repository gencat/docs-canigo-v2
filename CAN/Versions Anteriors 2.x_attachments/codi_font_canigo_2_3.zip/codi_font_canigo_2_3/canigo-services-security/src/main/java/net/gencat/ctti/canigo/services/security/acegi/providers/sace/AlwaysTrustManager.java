/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers.sace;

import java.net.Socket;

import java.security.Principal;
import java.security.PrivateKey;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import com.sun.net.ssl.X509TrustManager;


//Referenced classes of package com.dmrconsulting.common.SACE:
/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class AlwaysTrustManager implements X509TrustManager {
   /**
    * Creates a new AlwaysTrustManager object.
    */
   public AlwaysTrustManager() {
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public X509Certificate[] getAcceptedIssuers() {
      return null;
   }

   /**
    * Documentaci�.
    *
    * @param chain Documentaci�
    *
    * @return Documentaci�
    */
   public boolean isClientTrusted(X509Certificate[] chain) {
      return true;
   }

   /**
    * Documentaci�.
    *
    * @param chain Documentaci�
    *
    * @return Documentaci�
    */
   public boolean isServerTrusted(X509Certificate[] chain) {
      return true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String toString() {
      return "toString: AlwaysTrustManager";
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    *
    * @return Documentaci�
    */
   public String[] getClientAliases(String arg0, Principal[] arg1) {
      return null;
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    * @param arg2 Documentaci�
    *
    * @return Documentaci�
    */
   public String chooseClientAlias(String[] arg0, Principal[] arg1, Socket arg2) {
      return null;
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    *
    * @return Documentaci�
    */
   public String[] getServerAliases(String arg0, Principal[] arg1) {
      return null;
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    * @param arg2 Documentaci�
    *
    * @return Documentaci�
    */
   public String chooseServerAlias(String arg0, Principal[] arg1, Socket arg2) {
      return null;
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public X509Certificate[] getCertificateChain(String arg0) {
      return null;
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public PrivateKey getPrivateKey(String arg0) {
      return null;
   }

   /**
    * Documentaci�.
    *
    * @param ax509certificate Documentaci�
    * @param s Documentaci�
    *
    * @throws CertificateException Documentaci�
    */
   public void checkClientTrusted(X509Certificate[] ax509certificate, String s)
      throws CertificateException {
   }

   /**
    * Documentaci�.
    *
    * @param ax509certificate Documentaci�
    * @param s Documentaci�
    *
    * @throws CertificateException Documentaci�
    */
   public void checkServerTrusted(X509Certificate[] ax509certificate, String s)
      throws CertificateException {
   }
}
