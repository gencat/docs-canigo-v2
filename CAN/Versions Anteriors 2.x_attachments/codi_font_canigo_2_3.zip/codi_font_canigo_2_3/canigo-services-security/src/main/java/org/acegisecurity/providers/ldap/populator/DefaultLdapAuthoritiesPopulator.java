/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package org.acegisecurity.providers.ldap.populator;

import java.util.HashSet;
import java.util.Set;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.GrantedAuthorityImpl;

import org.acegisecurity.providers.ldap.InitialDirContextFactory;
import org.acegisecurity.providers.ldap.LdapAuthoritiesPopulator;
import org.acegisecurity.providers.ldap.LdapDataAccessException;
import org.acegisecurity.providers.ldap.LdapUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;


/**
 * The default strategy for obtaining user role information from the directory.
 * <p>
 * It obtains roles by
 * <ul>
 * <li>Reading the values of the roles specified by the attribute names in the
 * <tt>userRoleAttributes</tt> </li>
 * <li>Performing a search for "groups" the user is a member of and adding
 * those to the list of roles.</li>
 * </ul>
 * </p>
 * <p>
 * If the <tt>userRolesAttributes</tt> property is set, any matching
 * attributes amongst those retrieved for the user will have their values added
 * to the list of roles.
 * If <tt>userRolesAttributes</tt> is null, no attributes will be mapped to roles.
 * </p>
 * <p>
 * A typical group search scenario would be where each group/role is specified using
 * the <tt>groupOfNames</tt> (or <tt>groupOfUniqueNames</tt>) LDAP objectClass
 * and the user's DN is listed in the <tt>member</tt> (or <tt>uniqueMember</tt>) attribute
 * to indicate that they should be assigned that role. The following LDIF sample
 * has the groups stored under the DN <tt>ou=groups,dc=acegisecurity,dc=org</tt>
 * and a group called "developers" with "ben" and "marissa" as members:
 *
 * <pre>
 * dn: ou=groups,dc=acegisecurity,dc=org
 * objectClass: top
 * objectClass: organizationalUnit
 * ou: groups
 *
 * dn: cn=developers,ou=groups,dc=acegisecurity,dc=org
 * objectClass: groupOfNames
 * objectClass: top
 * cn: developers
 * description: Acegi Security Developers
 * member: uid=ben,ou=people,dc=acegisecurity,dc=org
 * member: uid=marissa,ou=people,dc=acegisecurity,dc=org
 * ou: developer
 * </pre>
 * </p>
 * <p>
 * The group search is performed within a DN specified by the <tt>groupSearchBase</tt>
 * property, which should be relative to the root DN of its <tt>InitialDirContextFactory</tt>.
 * If the search base is null, group searching is disabled. The filter used in the search is defined by the
 * <tt>groupSearchFilter</tt> property, with the filter argument {0} being the full DN of the user. You can also specify which attribute defines the role name by
 * setting the <tt>groupRoleAttribute</tt> property (the default is "cn").
 * </p>
 * <p>
 * The configuration below shows how the group search might be performed with the above schema.
 * <pre>
 * &lt;bean id="ldapAuthoritiesPopulator" class="org.acegisecurity.providers.ldap.populator.DefaultLdapAuthoritiesPopulator">
 *   &lt;constructor-arg>&lt;ref local="initialDirContextFactory"/>&lt;/constructor-arg>
 *   &lt;constructor-arg>&lt;value>ou=groups&lt;/value>&lt;/constructor-arg>
 *   &lt;property name="groupRoleAttribute">&lt;value>ou&lt;/value>&lt;/property>
 *
 * &lt;!-- the following properties are shown with their default values -->
 *
 *   &lt;property name="searchSubTree">&lt;value>false&lt;/value>&lt;/property>
 *   &lt;property name="rolePrefix">&lt;value>ROLE_&lt;/value>&lt;/property>
 *   &lt;property name="convertToUpperCase">&lt;value>true&lt;/value>&lt;/property>
 * &lt;/bean>
 * </pre>
 * A search for roles for user "uid=ben,ou=people,dc=acegisecurity,dc=org" would return the single
 * granted authority "ROLE_DEVELOPER".
 * </p>
 *
 *
 * @author Luke Taylor
 * @version $Id: DefaultLdapAuthoritiesPopulator.java,v 1.5 2007/07/16 08:44:00 msabates Exp $
 */
public class DefaultLdapAuthoritiesPopulator implements LdapAuthoritiesPopulator {
   /**
    * Documentaci�.
    */
   private static final Log logger = LogFactory.getLog(DefaultLdapAuthoritiesPopulator.class);

   /** A default role which will be assigned to all authenticated users if set */
   private GrantedAuthority defaultRole = null;

   /** An initial context factory is only required if searching for groups is required. */
   private InitialDirContextFactory initialDirContextFactory = null;

   /** The ID of the attribute which contains the role name for a group */
   private String groupRoleAttribute = "cn";

   /** The base DN from which the search for group membership should be performed */
   private String groupSearchBase = null;

   /** The pattern to be used for the user search. {0} is the user's DN */
   private String groupSearchFilter = "(member={0})";

   /**
    * Documentaci�.
    */
   private String rolePrefix = "ROLE_";

   /** Attributes of the User's LDAP Object that contain role name information. */
   private String[] userRoleAttributes = null;

   /**
    * Documentaci�.
    */
   private boolean convertToUpperCase = true;

   /** Whether group searches should be performed over the full sub-tree from the base DN */
   // private boolean searchSubtree = false;

   /** Internal variable, tied to searchSubTree property */
   private int searchScope = SearchControls.ONELEVEL_SCOPE;

   /**
    * Constructor for non-group search scenarios. Typically in this case
    * the <tt>userRoleAttributes</tt> property will be set to obtain roles directly
    * from the user's directory entry attributes. The <tt>defaultRole</tt> property
    * may also be set and will be assigned to all users.
    */
   public DefaultLdapAuthoritiesPopulator() {
   }

   /**
    * Constructor for group search scenarios. <tt>userRoleAttributes</tt> may still be
    * set as a property.
    *
    * @param initialDirContextFactory
    * @param groupSearchBase
    */
   public DefaultLdapAuthoritiesPopulator(
      InitialDirContextFactory initialDirContextFactory, String groupSearchBase) {
      Assert.notNull(initialDirContextFactory,
         "InitialDirContextFactory must not be null");
      Assert.hasLength(groupSearchBase,
         "The groupSearchBase (name to search under), must be specified.");
      this.initialDirContextFactory = initialDirContextFactory;
      this.groupSearchBase = groupSearchBase;
   }

   /**
    *
    * @param username the login name passed to the authentication provider.
    * @param userDn the user's DN.
    * @param userAttributes the attributes retrieved from the user's directory entry.
    * @return the full set of roles granted to the user.
    */
   public GrantedAuthority[] getGrantedAuthorities(String username,
      String userDn, Attributes userAttributes) {
      logger.debug("Getting authorities for user " + userDn);

      Set roles = getRolesFromUserAttributes(userDn, userAttributes);

      Set groupRoles = getGroupMembershipRoles(userDn, userAttributes);

      if (groupRoles != null) {
         roles.addAll(groupRoles);
      }

      if (defaultRole != null) {
         roles.add(defaultRole);
      }

      return (GrantedAuthority[]) roles.toArray(new GrantedAuthority[roles.size()]);
   }

   /**
    * Documentaci�.
    *
    * @param userDn Documentaci�
    * @param userAttributes Documentaci�
    *
    * @return Documentaci�
    */
   protected Set getRolesFromUserAttributes(String userDn,
      Attributes userAttributes) {
      Set userRoles = new HashSet();

      for (int i = 0;
            (userRoleAttributes != null) && (i < userRoleAttributes.length);
            i++) {
         Attribute roleAttribute = userAttributes.get(userRoleAttributes[i]);

         addAttributeValuesToRoleSet(roleAttribute, userRoles);
      }

      return userRoles;
   }

   /**
    * Searches for groups the user is a member of.
    *
    * @param userDn the user's distinguished name.
    * @param userAttributes
    * @return the set of roles obtained from a group membership search, or null if
    *         <tt>groupSearchBase</tt> has been set.
    */
   protected Set getGroupMembershipRoles(String userDn,
      Attributes userAttributes) {
      Set userRoles = new HashSet();

      if (groupSearchBase == null) {
         return null;
      }

      if (logger.isDebugEnabled()) {
         logger.debug("Searching for roles for user '" + userDn +
            "', with filter " + groupSearchFilter + " in search base '" +
            groupSearchBase + "'");
      }

      DirContext ctx = initialDirContextFactory.newInitialDirContext();
      SearchControls ctls = new SearchControls();

      ctls.setSearchScope(searchScope);
      ctls.setReturningAttributes(new String[] { groupRoleAttribute });

      try {
         NamingEnumeration groups = ctx.search(groupSearchBase,
               groupSearchFilter, new String[] { userDn }, ctls);

         while (groups.hasMore()) {
            SearchResult result = (SearchResult) groups.next();
            Attributes attrs = result.getAttributes();

            // There should only be one role attribute.
            NamingEnumeration groupRoleAttributes = attrs.getAll();

            while (groupRoleAttributes.hasMore()) {
               Attribute roleAttribute = (Attribute) groupRoleAttributes.next();

               addAttributeValuesToRoleSet(roleAttribute, userRoles);
            }
         }
      } catch (NamingException e) {
         throw new LdapDataAccessException("Group search failed for user " +
            userDn, e);
      } finally {
         LdapUtils.closeContext(ctx);
      }

      if (logger.isDebugEnabled()) {
         logger.debug("Roles from search: " + userRoles);
      }

      return userRoles;
   }

   /**
    * Documentaci�.
    *
    * @param roleAttribute Documentaci�
    * @param roles Documentaci�
    */
   private void addAttributeValuesToRoleSet(Attribute roleAttribute, Set roles) {
      if (roleAttribute == null) {
         return;
      }

      try {
         NamingEnumeration attributeRoles = roleAttribute.getAll();

         while (attributeRoles.hasMore()) {
            Object role = attributeRoles.next();

            // We only handle Strings for the time being
            if (role instanceof String) {
               if (convertToUpperCase) {
                  role = ((String) role).toUpperCase();
               }

               roles.add(new GrantedAuthorityImpl(rolePrefix + role));
            } else {
               logger.warn("Non-String value found for role attribute " +
                  roleAttribute.getID());
            }
         }
      } catch (NamingException ne) {
         throw new LdapDataAccessException(
            "Error retrieving values for role attribute " +
            roleAttribute.getID(), ne);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected String[] getUserRoleAttributes() {
      return userRoleAttributes;
   }

   /**
    * Documentaci�.
    *
    * @param userRoleAttributes Documentaci�
    */
   public void setUserRoleAttributes(String[] userRoleAttributes) {
      this.userRoleAttributes = userRoleAttributes;
   }

   /**
    * Documentaci�.
    *
    * @param rolePrefix Documentaci�
    */
   public void setRolePrefix(String rolePrefix) {
      Assert.notNull(rolePrefix, "rolePrefix must not be null");
      this.rolePrefix = rolePrefix;
   }

   /**
    * Documentaci�.
    *
    * @param groupSearchFilter Documentaci�
    */
   public void setGroupSearchFilter(String groupSearchFilter) {
      Assert.notNull(groupSearchFilter, "groupSearchFilter must not be null");
      this.groupSearchFilter = groupSearchFilter;
   }

   /**
    * Documentaci�.
    *
    * @param groupRoleAttribute Documentaci�
    */
   public void setGroupRoleAttribute(String groupRoleAttribute) {
      Assert.notNull(groupRoleAttribute, "groupRoleAttribute must not be null");
      this.groupRoleAttribute = groupRoleAttribute;
   }

   /**
    * Documentaci�.
    *
    * @param searchSubtree Documentaci�
    */
   public void setSearchSubtree(boolean searchSubtree) {
      //    this.searchSubtree = searchSubtree;
      this.searchScope = searchSubtree ? SearchControls.SUBTREE_SCOPE
                                       : SearchControls.ONELEVEL_SCOPE;
   }

   /**
    * Documentaci�.
    *
    * @param convertToUpperCase Documentaci�
    */
   public void setConvertToUpperCase(boolean convertToUpperCase) {
      this.convertToUpperCase = convertToUpperCase;
   }

   /**
    * The default role which will be assigned to all users.
    *
    * @param defaultRole the role name, including any desired prefix.
    */
   public void setDefaultRole(String defaultRole) {
      Assert.notNull(defaultRole,
         "The defaultRole property cannot be set to null");
      this.defaultRole = new GrantedAuthorityImpl(defaultRole);
   }
}
