/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Logger;

import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import javax.security.cert.CertificateExpiredException;
import javax.security.cert.CertificateNotYetValidException;

import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;

import sun.security.x509.CertificateValidity;

import weblogic.security.SSL.TrustManagerJSSE;


/**
 * A configurable trust manager built on X509TrustManager.
 *
 * If set to 'open' trust, the default, will get us into sites for whom we do
 * not have the CA or any of intermediary CAs that go to make up the cert chain
 * of trust.  Will also get us past selfsigned and expired certs.  'loose'
 * trust will get us into sites w/ valid certs even if they are just
 * selfsigned.  'normal' is any valid cert not including selfsigned.  'strict'
 * means cert must be valid and the cert DN must match server name.
 *
 * <p>Based on pointers in
 * <a href="http://jakarta.apache.org/commons/httpclient/sslguide.html">SSL
 * Guide</a>,
 * and readings done in <a
 * href="http://java.sun.com/j2se/1.4.2/docs/guide/security/jsse/JSSERefGuide.html#Introduction">JSSE
 * Guide</a>.
 *
 * <p>TODO: Move to an ssl subpackage when we have other classes other than
 * just this one.
 *
 * @author stack
 * @version $Id: ConfigurableX509TrustManager.java,v 1.4 2007/07/16 08:44:00 msabates Exp $
 */
public class ConfigurableX509TrustManager implements X509TrustManager,
   TrustManagerJSSE {
   /**
    * Logging instance.
    */
   protected static Logger logger = Logger.getLogger(
         "org.archive.httpclient.ConfigurableX509TrustManager");

   /**
    * Trust anything given us.
    *
    * Default setting.
    *
    * <p>See <a href="http://javaalmanac.com/egs/javax.net.ssl/TrustAll.html">
    *  e502. Disabling Certificate Validation in an HTTPS Connection</a> from
    * the java almanac for how to trust all.
    */
   public static final String OPEN = "open";

   /**
    * Trust any valid cert including self-signed certificates.
    */
   public static final String LOOSE = "loose";

   /**
    * Normal jsse behavior.
    *
    * Seemingly any certificate that supplies valid chain of trust.
    */
   public static final String NORMAL = "normal";

   /**
    * Strict trust.
    *
    * Ensure server has same name as cert DN.
    */
   public static final String STRICT = "strict";

   /**
    * All the levels of trust as an array from babe-in-the-wood to strict.
    */
   public static String[] LEVELS_AS_ARRAY = { OPEN, LOOSE, NORMAL, STRICT };

   /**
    * Levels as a list.
    */
   private static List LEVELS = Arrays.asList(LEVELS_AS_ARRAY);

   /**
    * Default setting for trust level.
    */
   public static final String DEFAULT = OPEN;

   /**
    * An instance of the SUNX509TrustManager that we adapt variously
    * depending upon passed configuration.
    *
    * We have it do all the work we don't want to.
    */
   private javax.net.ssl.X509TrustManager standardTrustManager = null;

   /** Certificates from application classpath. */
   private Properties certificates;

   /**
    * Trust level.
    */
   private String trustLevel = DEFAULT;

   /**
    * Creates a new ConfigurableX509TrustManager object.
    *
    * @throws NoSuchAlgorithmException DOCUMENT ME.
    * @throws KeyStoreException DOCUMENT ME.
    */
   public ConfigurableX509TrustManager()
      throws NoSuchAlgorithmException, KeyStoreException {
      this(DEFAULT);
      System.out.println("ConfigurableX509TrustManager Constructor");
   }

   /**
    * Constructor.
    *
    * @param level Level of trust to effect.
    *
    * @throws NoSuchAlgorithmException
    * @throws KeyStoreException
    */
   public ConfigurableX509TrustManager(String level)
      throws NoSuchAlgorithmException, KeyStoreException {
      super();

      TrustManagerFactory factory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());

      // Pass in a null (Trust) KeyStore.  Null says use the 'default'
      // 'trust' keystore (KeyStore class is used to hold keys and to hold
      // 'trusts' (certs)). See 'X509TrustManager Interface' in this doc:
      // http://java.sun.com
      // /j2se/1.4.2/docs/guide/security/jsse/JSSERefGuide.html#Introduction
      factory.init((KeyStore) null);

      TrustManager[] trustmanagers = factory.getTrustManagers();

      if (trustmanagers.length == 0) {
         throw new NoSuchAlgorithmException(TrustManagerFactory.getDefaultAlgorithm() +
            " trust manager not supported");
      }

      this.standardTrustManager = (X509TrustManager) trustmanagers[0];

      this.trustLevel = (LEVELS.contains(level.toLowerCase())) ? level : DEFAULT;
   }

   /**
    * Documentaci�.
    *
    * @param certificates Documentaci�
    * @param type Documentaci�
    *
    * @throws CertificateException Documentaci�
    */
   public void checkClientTrusted(X509Certificate[] certificates, String type)
      throws CertificateException {
      //        if (this.trustLevel.equals(OPEN)) {
      //            return;
      //        }
      System.out.println("checkClientTrusted");

      X509Certificate[] allCertificates = getAllCertificates(certificates);

      this.standardTrustManager.checkClientTrusted(allCertificates, type);
   }

   /**
    * Documentaci�.
    *
    * @param certificates Documentaci�
    * @param type Documentaci�
    *
    * @throws CertificateException Documentaci�
    */
   public void checkServerTrusted(X509Certificate[] certificates, String type)
      throws CertificateException {
      //        if (this.trustLevel.equals(OPEN)) {
      //            return;
      //        }
      System.out.println("checkServerTrusted");

      try {
         X509Certificate[] allCertificates = getAllCertificates(certificates);
         this.standardTrustManager.checkServerTrusted(allCertificates, type);

         if (this.trustLevel.equals(STRICT)) {
            logger.severe(STRICT + " not implemented.");
         }
      } catch (CertificateException e) {
         if (this.trustLevel.equals(LOOSE) && (certificates != null) &&
               (certificates.length == 1)) {
            // If only one cert and its valid and it caused a
            // CertificateException, assume its selfsigned.
            X509Certificate certificate = certificates[0];
            certificate.checkValidity();
         } else {
            // If we got to here, then we're probably NORMAL. Rethrow.
            throw e;
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public X509Certificate[] getAcceptedIssuers() {
      System.out.println("getAcceptedIssuers");

      X509Certificate[] allCertificates = null;

      try {
         allCertificates = getAllCertificates(this.standardTrustManager.getAcceptedIssuers());
      } catch (CertificateException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }

      return allCertificates;
   }

   /**
    * Documentaci�.
    *
    * @param certificates Documentaci�
    *
    * @return Documentaci�
    *
    * @throws CertificateException Documentaci�
    */
   public X509Certificate[] getAllCertificates(X509Certificate[] certificates)
      throws CertificateException {
      if (this.certificates != null) {
         X509Certificate[] allCertificates = new X509Certificate[certificates.length +
            this.certificates.size()];

         // allCertificates counter
         int i = 0;

         // Add initial certificates
         for (; i < certificates.length; i++) {
            allCertificates[i] = certificates[i];
         }

         // Add application certificates
         Set keySet = this.certificates.keySet();
         Iterator iterator = keySet.iterator();

         while (iterator.hasNext()) {
            String alias = (String) iterator.next();
            String fileName = this.certificates.getProperty(alias);
            Resource resource = new DefaultResourceLoader().getResource(fileName);
            InputStream inputStream = null;

            try {
               inputStream = resource.getInputStream();
            } catch (IOException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
            }

            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509Certificate cert = (X509Certificate) cf.generateCertificate(inputStream);
            allCertificates[certificates.length + i++] = cert;
         }

         return allCertificates;
      }

      return certificates;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Properties getCertificates() {
      return certificates;
   }

   /**
    * Documentaci�.
    *
    * @param certificates Documentaci�
    */
   public void setCertificates(Properties certificates) {
      this.certificates = certificates;
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean certificateCallback(
      javax.security.cert.X509Certificate[] arg0, int arg1) {
      //		try {
      //			arg0[0].checkValidity();
      //		} catch (CertificateExpiredException e) {
      //			// TODO Auto-generated catch block
      //			e.printStackTrace();
      //		} catch (CertificateNotYetValidException e) {
      //			// TODO Auto-generated catch block
      //			e.printStackTrace();
      //		}

      // TODO Auto-generated method stub
      return true;

      //		return appCertificatesCheck();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean appCertificatesCheck() {
      // Check application certificates validity
      Set keySet = this.certificates.keySet();
      Iterator iterator = keySet.iterator();

      while (iterator.hasNext()) {
         String alias = (String) iterator.next();
         String fileName = this.certificates.getProperty(alias);
         Resource resource = new DefaultResourceLoader().getResource(fileName);
         InputStream inputStream = null;

         try {
            inputStream = resource.getInputStream();
         } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }

         try {
            javax.security.cert.X509Certificate cert = javax.security.cert.X509Certificate.getInstance(inputStream);
            cert.checkValidity();
         } catch (javax.security.cert.CertificateException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            return false;
         }

         try {
            inputStream.close();
         } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
      }

      return true;
   }
}
