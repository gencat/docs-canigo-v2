/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import javax.security.cert.X509Certificate;

import weblogic.security.SSL.TrustManagerJSSE;


/**
 * Given the partial or complete certificate chain provided by
 * the peer, build a certificate path to a trusted root and return
 * true if it can be validated and is trusted for client SSL
 * authentication.
 *
 * This is a null implemention which always returns true after
 * printing the certificate chain to System.out
 *
 * This is an example only and should NOT be used in a
 * production environment.
 *
 * @author Copyright (c) 1999-2004 by BEA Systems, Inc. All Rights Reserved.
 */
public class NulledTrustManager implements TrustManagerJSSE {
   /**
    * Documentaci�.
    *
    * @param o Documentaci�
    * @param validateErr Documentaci�
    *
    * @return Documentaci�
    */
   public boolean certificateCallback(X509Certificate[] o, int validateErr) {
      System.out.println(" --- Do Not Use In Production ---\n" +
         " By using this NulledTrustManager, the trust in the" +
         " server's identity is completely lost.\n" +
         " --------------------------------");

      for (int i = 0; i < o.length; i++) {
         System.out.println(" certificate " + i + " -- " + o[i].toString());
      }

      return true;
   }
}
