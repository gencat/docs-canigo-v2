/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.GrantedAuthorityImpl;
import net.sf.acegisecurity.providers.dao.UsernameNotFoundException;

import org.springframework.context.ApplicationContextException;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.MappingSqlQuery;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.8 $
  */
public class AuthoritiesJdbcImplDAO extends JdbcDaoSupport
   implements AuthoritiesDAO {
   //    public static final String DEF_AUTHORITIES_BY_USERNAME_QUERY = "SELECT u.USER_LOGIN_ID, r.role_name FROM USER_LOGIN u, ROLE r, PARTY p, PARTY_ROLE pr WHERE u.party_id = p.party_id AND pr.party_id = p.party_id AND pr.role_id = r.role_id AND u.user_login_id = ?";
   /**
    * Documentaci�.
    */
   private MappingSqlQuery authoritiesByUsernameMapping;

   /**
    * Documentaci�.
    */
   private String authoritiesByUsernameQuery;

   /**
    * Creates a new AuthoritiesJdbcImplDAO object.
    */
   public AuthoritiesJdbcImplDAO() {
   }

   /**
    * Documentaci�.
    *
    * @throws ApplicationContextException Documentaci�
    */
   protected void initDao() throws ApplicationContextException {
      this.authoritiesByUsernameMapping = new AuthoritiesByUsernameMapping(getDataSource());
   }

   /**
    * Documentaci�.
    *
    * @param username Documentaci�
    *
    * @return Documentaci�
    */
   public GrantedAuthority[] getAuthorities(String username) {
      List dbAuths = authoritiesByUsernameMapping.execute(username);

      if (dbAuths.size() == 0) {
         throw new UsernameNotFoundException(
            "UserLogin has no GrantedAuthority");
      }

      GrantedAuthority[] arrayAuths = {  };
      arrayAuths = (GrantedAuthority[]) dbAuths.toArray(arrayAuths);

      return arrayAuths;
   }

   /**
    * Documentaci�.
    *
    * @param username Documentaci�
    *
    * @return Documentaci�
    */
   public GrantedAuthority[] getAuthoritiesIgnoreCase(String username) {
      List dbAuths = authoritiesByUsernameMapping.execute(username);

      if (dbAuths.size() == 0) {
         throw new UsernameNotFoundException(
            "UserLogin has no GrantedAuthority");
      }

      GrantedAuthority[] arrayAuths = {  };
      arrayAuths = (GrantedAuthority[]) dbAuths.toArray(arrayAuths);

      return arrayAuths;
   }
   
   public GrantedAuthority[] getAuthorities(String username, String password) {	   
	   return getAuthorities(username);
	}

   /**
    * Documentaci�.
    *
    * @param authoritiesByUsernameQuery Documentaci�
    */
   public void setAuthoritiesByUsernameQuery(String authoritiesByUsernameQuery) {
      this.authoritiesByUsernameQuery = authoritiesByUsernameQuery;
   }

   //  ~ Inner Classes ==========================================================

   /**
    * Query object to look up a user's authorities.
    */
   protected class AuthoritiesByUsernameMapping extends MappingSqlQuery {
      /**
       * Creates a new AuthoritiesByUsernameMapping object.
       *
       * @param ds DOCUMENT ME.
       */
      protected AuthoritiesByUsernameMapping(DataSource ds) {
         super(ds, authoritiesByUsernameQuery);
         declareParameter(new SqlParameter(Types.VARCHAR));
         compile();
      }

      /**
       * Documentaci�.
       *
       * @param rs Documentaci�
       * @param rownum Documentaci�
       *
       * @return Documentaci�
       *
       * @throws SQLException Documentaci�
       */
      protected Object mapRow(ResultSet rs, int rownum)
         throws SQLException {
         String roleName = rs.getString(2);
         GrantedAuthorityImpl authority = new GrantedAuthorityImpl(roleName);

         return authority;
      }
   }

}
