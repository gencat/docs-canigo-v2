/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers.sace.enums;

import org.apache.commons.lang.enums.Enum;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class SACEUserNameFormatEnum extends Enum {
   /**
    * Documentaci�.
    */
   public static final SACEUserNameFormatEnum INTERNAL_CODE = new SACEUserNameFormatEnum("1",
         "INTERNAL_CODE");

   /**
    * Documentaci�.
    */
   public static final SACEUserNameFormatEnum NIF = new SACEUserNameFormatEnum("2",
         "NIF");

   /**
    * Documentaci�.
    */
   private String label;

   /**
    * Creates a new SACEUserNameFormatEnum object.
    *
    * @param value DOCUMENT ME.
    * @param label DOCUMENT ME.
    */
   private SACEUserNameFormatEnum(String value, String label) {
      super(value);
      this.label = label;
   }

   /**
    * Documentaci�.
    *
    * @param userFormatString Documentaci�
    *
    * @return Documentaci�
    */
   public static SACEUserNameFormatEnum getEnum(String userFormatString) {
      if (userFormatString == null) {
         return null;
      }

      if (userFormatString.equals(INTERNAL_CODE.getLabel())) {
         return INTERNAL_CODE;
      }

      if (userFormatString.equals(NIF.getLabel())) {
         return NIF;
      }

      return null;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getLabel() {
      return this.label;
   }
}
