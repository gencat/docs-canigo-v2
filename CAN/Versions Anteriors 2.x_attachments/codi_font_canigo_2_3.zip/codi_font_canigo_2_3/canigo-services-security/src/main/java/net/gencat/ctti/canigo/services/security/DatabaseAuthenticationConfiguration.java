/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import javax.sql.DataSource;

import net.gencat.ctti.canigo.services.security.acegi.providers.dao.AuthoritiesDAO;
import net.gencat.ctti.canigo.services.security.acegi.providers.dao.DatabaseAuhenticationDAO;
import net.sf.acegisecurity.providers.AuthenticationProvider;
import net.sf.acegisecurity.providers.dao.DaoAuthenticationProvider;
import net.sf.acegisecurity.providers.dao.cache.EhCacheBasedUserCache;
import net.sf.acegisecurity.providers.encoding.PasswordEncoder;

import org.apache.commons.validator.GenericValidator;
import org.springframework.context.ApplicationContext;
import org.springframework.util.Assert;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class DatabaseAuthenticationConfiguration
   extends AbstractAuthenticationConfiguration {
   /**
    * Documentaci�.
    */
   private PasswordEncoder passwordEncoder;

   /**
    * the default value works with the Acegi tables
    */
   private String usersByUserNameQuery;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public PasswordEncoder getPasswordEncoder() {
      return passwordEncoder;
   }

   /**
    * Documentaci�.
    *
    * @param passwordEncoder Documentaci�
    */
   public void setPasswordEncoder(PasswordEncoder passwordEncoder) {
      this.passwordEncoder = passwordEncoder;
   }

   /**
    * Documentaci�.
    *
    * @param passwordEncoderClassName Documentaci�
    *
    * @throws InstantiationException Documentaci�
    * @throws IllegalAccessException Documentaci�
    * @throws ClassNotFoundException Documentaci�
    */
   public void setPasswordEncoderClass(String passwordEncoderClassName)
      throws InstantiationException, IllegalAccessException,
         ClassNotFoundException {
      this.passwordEncoder = (PasswordEncoder) Class.forName(passwordEncoderClassName)
                                                    .newInstance();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getUsersByUserNameQuery() {
      return usersByUserNameQuery;
   }

   /**
    * Documentaci�.
    *
    * @param usersByUserNameQuery Documentaci�
    */
   public void setUsersByUserNameQuery(String usersByUserNameQuery) {
      this.usersByUserNameQuery = usersByUserNameQuery;
   }

   /**
    * Documentaci�.
    *
    * @param applicationContext Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   protected AuthenticationProvider getAuthenticationProvider(
      ApplicationContext applicationContext) throws Exception {
      // Get beans from Spring context TODO Should we just get rid of all of them?
      DataSource dataSource = super.getDataSource();

      // DatabaseAuhenticationDAO set up
      DatabaseAuhenticationDAO databaseAuhenticationDAO = new DatabaseAuhenticationDAO();
      databaseAuhenticationDAO.setDataSource(dataSource);

      // This code is called by the Depedency Injection Framework module of Spring in order to 
      // initialize beans which implements the interface InitializingBean
      // TODO Refactor to use Constructor Injector instead of Setter Injection        
      if (!GenericValidator.isBlankOrNull(this.usersByUserNameQuery)) {
         databaseAuhenticationDAO.setUsersByUsernameQuery(this.usersByUserNameQuery);
      }

      databaseAuhenticationDAO.afterPropertiesSet();

      AuthoritiesDAO authoritiesDAO = getAuthoritiesDAO(applicationContext);
      databaseAuhenticationDAO.setAuthoritiesDAO(authoritiesDAO);

      // DaoAuthenticationProvider
      DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
      daoAuthenticationProvider.setAuthenticationDao(databaseAuhenticationDAO);
      daoAuthenticationProvider.setPasswordEncoder(this.passwordEncoder);

      EhCacheBasedUserCache userCache = (EhCacheBasedUserCache) applicationContext.getBean(
            "userCache");
      daoAuthenticationProvider.setUserCache(userCache);
      daoAuthenticationProvider.afterPropertiesSet();

      return daoAuthenticationProvider;
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void afterPropertiesSet() throws Exception {
      Assert.notNull(this.passwordEncoder, "passwordEncoder must be set");
   }
}
