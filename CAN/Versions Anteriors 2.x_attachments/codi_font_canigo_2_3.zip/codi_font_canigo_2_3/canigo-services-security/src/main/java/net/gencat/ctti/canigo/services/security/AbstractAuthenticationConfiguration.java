/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import javax.sql.DataSource;

import net.gencat.ctti.canigo.services.security.acegi.providers.dao.AuthoritiesDAO;
import net.gencat.ctti.canigo.services.security.acegi.providers.dao.AuthoritiesHibernateImplDAO;
import net.gencat.ctti.canigo.services.security.acegi.providers.dao.AuthoritiesJdbcImplDAO;
import net.gencat.ctti.canigo.services.security.model.dao.UserLoginDAO;
import net.sf.acegisecurity.providers.AuthenticationProvider;
import net.sf.acegisecurity.providers.dao.AuthenticationDao;
import net.sf.acegisecurity.providers.dao.DaoAuthenticationProvider;
import net.sf.acegisecurity.providers.dao.cache.EhCacheBasedUserCache;

import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public abstract class AbstractAuthenticationConfiguration
   implements InitializingBean, ApplicationContextAware {
   /**
    * Documentaci�.
    */
   protected String authoritiesbyUserNameQuery;

   /**
    * Documentaci�.
    */
   private ApplicationContext applicationContext;

   /**
    * Documentaci�.
    *
    * @param applicationContext Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   protected abstract AuthenticationProvider getAuthenticationProvider(
      ApplicationContext applicationContext) throws Exception;

   /**
    * Documentaci�.
    *
    * @param applicationContext Documentaci�
    *
    * @throws BeansException Documentaci�
    */
   public void setApplicationContext(ApplicationContext applicationContext)
      throws BeansException {
      this.applicationContext = applicationContext;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected DataSource getDataSource() {
      DataSource dataSource = (DataSource) applicationContext.getBean(
            "dataSource");

      return dataSource;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getAuthoritiesbyUserNameQuery() {
      return authoritiesbyUserNameQuery;
   }

   /**
    * Documentaci�.
    *
    * @param authoritiesbyUserNameQuery Documentaci�
    */
   public void setAuthoritiesbyUserNameQuery(String authoritiesbyUserNameQuery) {
      this.authoritiesbyUserNameQuery = authoritiesbyUserNameQuery;
   }

   /**
    * Documentaci�.
    *
    * @param dao Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   protected DaoAuthenticationProvider createPasswordDaoAuthenticationProvider(
      AuthenticationDao dao) throws Exception {
      DaoAuthenticationProvider passwordDaoAuthenticationProvider = new DaoAuthenticationProvider();
      EhCacheBasedUserCache userCache = (EhCacheBasedUserCache) applicationContext.getBean(
            "userCache");
      passwordDaoAuthenticationProvider.setUserCache(userCache);
      passwordDaoAuthenticationProvider.setAuthenticationDao(dao);

      passwordDaoAuthenticationProvider.afterPropertiesSet();

      return passwordDaoAuthenticationProvider;
   }

   /**
    * Documentaci�.
    *
    * @param applicationContext Documentaci�
    *
    * @return Documentaci�
    */
   protected AuthoritiesDAO getAuthoritiesDAO(
      ApplicationContext applicationContext) {
      AuthoritiesDAO authoritiesDAO = null;

      if (!GenericValidator.isBlankOrNull(this.authoritiesbyUserNameQuery)) {
         authoritiesDAO = new AuthoritiesJdbcImplDAO();
         ((AuthoritiesJdbcImplDAO) authoritiesDAO).setDataSource(this.getDataSource());
         ((AuthoritiesJdbcImplDAO) authoritiesDAO).setAuthoritiesByUsernameQuery(this.authoritiesbyUserNameQuery);
         ((AuthoritiesJdbcImplDAO) authoritiesDAO).afterPropertiesSet();
      } else {
         // Use Standard Authorities DAO
         UserLoginDAO userLoginDAO = (UserLoginDAO) applicationContext.getBean(
               "userLoginDAO");
         authoritiesDAO = new AuthoritiesHibernateImplDAO(userLoginDAO);
      }

      return authoritiesDAO;
   }
}
