/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import java.util.List;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class SecurityConfigurationFactory implements InitializingBean {
   /**
    * Documentaci�.
    */
   private AuthenticationSecurityConfiguration authenticationConfiguration;

   /**
    * Documentaci�.
    */
   private AuthorizationSecurityConfiguration authorizationConfiguration;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getSecureUrls() {
      return this.authorizationConfiguration.getSecureUrls();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getSecureBusinessObjects() {
      return this.authorizationConfiguration.getSecureBusinessObjects();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getAuthenticationFailureUrlValue() {
      return this.authenticationConfiguration.getAuthenticationFailureUrlValue();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getLoginFormUrlValue() {
      return this.authenticationConfiguration.getLoginFormUrlValue();
   }

   /**
    * Documentaci�.
    *
    * @param securityConfiguration Documentaci�
    */
   public void setAuthenticationConfiguration(
      AuthenticationSecurityConfiguration securityConfiguration) {
      this.authenticationConfiguration = securityConfiguration;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public AuthorizationSecurityConfiguration getAuthorizationConfiguration() {
      return authorizationConfiguration;
   }

   /**
    * Documentaci�.
    *
    * @param authorizationConfiguration Documentaci�
    */
   public void setAuthorizationConfiguration(
      AuthorizationSecurityConfiguration authorizationConfiguration) {
      this.authorizationConfiguration = authorizationConfiguration;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public AuthenticationSecurityConfiguration getAuthenticationConfiguration() {
      return authenticationConfiguration;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List getBeanNamesPatternForMethodInvocationAOP() {
      return this.authorizationConfiguration.getBeanNamesPatternList();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getDomainObjectsIdGettersConf() {
      return this.authorizationConfiguration.getDomainObjectsIdGetters();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List getAclsClassesList() {
      return this.authorizationConfiguration.getAclsClassesList();
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void afterPropertiesSet() throws Exception {
      Assert.notNull(this.authenticationConfiguration,
         "authenticationConfiguration must be set");
   }
}
