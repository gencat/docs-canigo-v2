/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers.sace;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.net.URLEncoder;
import java.security.KeyStore;
import java.security.Principal;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Properties;

import javax.net.ssl.SSLSocketFactory;


import net.gencat.ctti.canigo.services.i18n.I18nService;

import com.sun.net.ssl.HttpsURLConnection;
import com.sun.net.ssl.KeyManagerFactory;
import com.sun.net.ssl.SSLContext;
import com.sun.net.ssl.TrustManager;
import com.sun.net.ssl.X509TrustManager;
import com.sun.net.ssl.internal.ssl.Provider;
import com.sun.net.ssl.internal.www.protocol.https.Handler;

import net.gencat.ctti.canigo.services.i18n.I18nService;

import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.security.acegi.https.HttpsConfigBean;
import net.gencat.ctti.canigo.services.security.acegi.providers.dao.AuthoritiesDAO;
import net.gencat.ctti.canigo.services.security.acegi.providers.sace.enums.SACEReturnedCode;
import net.gencat.ctti.canigo.services.security.acegi.providers.sace.enums.SACEUserNameFormatEnum;
import net.sf.acegisecurity.AuthenticationServiceException;
import net.sf.acegisecurity.BadCredentialsException;
import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.UserDetails;
import net.sf.acegisecurity.providers.dao.AuthenticationDao;
import net.sf.acegisecurity.providers.dao.User;
import net.sf.acegisecurity.providers.dao.UsernameNotFoundException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.dao.DataAccessException;

import com.sun.net.ssl.HttpsURLConnection;
import com.sun.net.ssl.KeyManagerFactory;
import com.sun.net.ssl.SSLContext;
import com.sun.net.ssl.TrustManager;
import com.sun.net.ssl.X509TrustManager;
import com.sun.net.ssl.internal.ssl.Provider;
import com.sun.net.ssl.internal.www.protocol.https.Handler;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.9 $
  */
public class SACEPasswordAuthenticationDao implements AuthenticationDao {
   /**
    * Documentaci�.
    */
   private static final String UTF_8 = "UTF-8";

   static {
      String handlers = System.getProperty("java.protocol.handler.pkgs");
      System.setProperty("java.protocol.handler.pkgs",
         "com.sun.net.ssl.internal.www.protocol|" + handlers);
      Security.addProvider(new Provider());
   }

   /**
    * Documentaci�.
    */
   HttpsConfigBean httpsConfigBean;

   /**
    * Documentaci�.
    */
   SSLSocketFactory sslSF = null;

   /**
    * Documentaci�.
    */
   private AuthoritiesDAO authoritiesDAO;

   /** Gestor de logs. */
   private LoggingService logService = null;

   /** Certificates from application classpath. */
   private Properties certificates;

   /**
    * Documentaci�.
    */
   private SACEUserNameFormatEnum format;

   /**
    * Documentaci�.
    */
   private SACEXMLConverter xmlConverter;

   /** Server KeyStore params. */
   private String keyStore;

   /**
    * Documentaci�.
    */
   private String keyStorePassPhrase;

   /**
    * Documentaci�.
    */
   private URL urlSACEServer;

   /**
    * Documentaci�.
    */
   private boolean wasServer;

   /**
    * Servei d'internacionalitzaci�.
    */
   private I18nService i18nSecurityService;
   
   /**
    * Creates a new SACEPasswordAuthenticationDao object.
    */
   public SACEPasswordAuthenticationDao() {
      super();
      xmlConverter = new SACEXMLConverter();
   }

   /**
    *
    * @param SACEHostName
    */
   public void setSACEHostName(String SACEHostName) {
      try {
         this.urlSACEServer = new URL(null, SACEHostName, new Handler());
      } catch (MalformedURLException e) {
         throw new AuthenticationServiceException("Configuration problem, check the SACEHostName",
            e);
      }
   }

   /**
    * Documentaci�.
    *
    * @param authoritiesDAO Documentaci�
    */
   public void setAuthoritiesDAO(AuthoritiesDAO authoritiesDAO) {
      this.authoritiesDAO = authoritiesDAO;
   }

   /**
    * Documentaci�.
    *
    * @param format Documentaci�
    */
   public void setUserNameFormatEnum(SACEUserNameFormatEnum format) {
      this.format = format;
   }

   /**
    *
    */
   public UserDetails loadUserByUsernameAndPassword(String username,
      String password) throws DataAccessException, BadCredentialsException {
      if (GenericValidator.isBlankOrNull(username) ||
            GenericValidator.isBlankOrNull(password)) {
         throw new AuthenticationServiceException(
            "It should be the front-end application responsability to ensure that both user name and passwords are not empty!");
      }

      if (wasServer || (keyStore == null)) {
         try {
            writeLog(
               "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword(" +
               username + ",******)");

            String sProtocolHandler = System.getProperty(
                  "java.protocol.handler.pkgs");
            writeLog(
               "******* SACEPasswordAuthenticationDao --> sProtocolHandler: " +
               sProtocolHandler);

            // HttpsURLConnection securedHttpURLConnection =
            // (HttpsURLConnection) urlSACEServer.openConnection();
            java.net.URLConnection securedHttpURLConnection = (java.net.URLConnection) urlSACEServer.openConnection();
            writeLog(
               "******* SACEPasswordAuthenticationDao --> securedHttpURLConnection: " +
               securedHttpURLConnection.getClass().getName());

            writeLog(
               "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: connection open");

            // It is set to false by default, which prevent any output
            // action (ProtocolException)
            securedHttpURLConnection.setDoOutput(true);

            OutputStreamWriter wout = new OutputStreamWriter(securedHttpURLConnection.getOutputStream(),
                  UTF_8);

            writeLog(
               "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: after securedHttpURLConnection.getOutputStream()");

            wout.write(getEncodedQuerryString(username, password));
            wout.flush();
            wout.close();

            writeLog(
               "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: after write to out");

            // Process SACE output
            String xmlOutput = IOUtils.toString(securedHttpURLConnection.getInputStream());
            String returnedCode = StringUtils.substringBetween(xmlOutput,
                  "<Resultat>", "</Resultat>");
            SACEReturnedCode.convertReturnedCode2AuthenticationServiceException(returnedCode, i18nSecurityService);
            writeLog(
               "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: end !!");
         } catch (IOException e) {
            writeLog(
               "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: IOException --> " +
               e.getMessage());
            writeException(e);
            throw new AuthenticationServiceException("", e);
         } catch (DataAccessException d) {
            writeLog(
               "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: DataAccessException " +
               d.getMessage());
            writeException(d);
            throw d;
         } catch (BadCredentialsException b) {
            writeLog(
               "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: BadCredentialsException " +
               b.getMessage());
            writeException(b);
            throw b;
         } catch (Exception e) {
            writeLog(
               "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: PETE2 --> " +
               e.getMessage());
            writeException(e);
         }
      } else {
         String resultat = "";

         try {
            char[] keypassphrase = (char[]) null;
            File keystoreHome = null;
            KeyStore ks = null;
            X509TrustManager tm = new AlwaysTrustManager();
            TrustManager[] tma = { tm };
            SSLContext ctx = SSLContext.getInstance("SSL");
            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            kmf.init(ks, keypassphrase);
            ctx.init(kmf.getKeyManagers(), tma, null);
            HttpsURLConnection.setDefaultSSLSocketFactory(ctx.getSocketFactory());
            ks = KeyStore.getInstance("JKS");

            // FileInputStream fileinputstream = new
            // FileInputStream(keystoreHome);
            // Spring Resource Loader
            Resource resource = new DefaultResourceLoader().getResource(keyStore);
            InputStream inputStream = resource.getInputStream();
            keypassphrase = this.keyStorePassPhrase.toCharArray();

            try {
               ks.load(inputStream, keypassphrase);
               inputStream.close();
            } catch (IOException ioexception) {
               ioexception.printStackTrace();
               throw new Exception("Error carregant KeyStore " + ioexception);
            }

            HttpURLConnection conn = (HttpURLConnection) this.urlSACEServer.openConnection();
            conn.setDoInput(true);
            conn.setDoOutput(true);

            PrintWriter out = new PrintWriter(conn.getOutputStream());
            out.write(getEncodedQuerryString(username, password));
            out.close();

            BufferedReader in = new BufferedReader(new InputStreamReader(
                     conn.getInputStream()));

            for (String inputLine = ""; (inputLine = in.readLine()) != null;) {
               resultat = resultat + inputLine;
            }

            in.close();
         } catch (IOException ioe) {
            logService.getLog(SACEPasswordAuthenticationDao.class)
                      .error("Error sace", ioe);
            throw new SecurityException("Error accedint al SACE ");
         } catch (Exception e) {
            logService.getLog(SACEPasswordAuthenticationDao.class)
                      .error("Error sace", e);
            throw new SecurityException("Error general accedint al SACE " + e);
         }
         
         String returnedCode = StringUtils.substringBetween(resultat, "<Resultat>", "</Resultat>");
         SACEReturnedCode.convertReturnedCode2AuthenticationServiceException(returnedCode, i18nSecurityService);
      }

      writeLog(
         "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: before authoritiesDAO.getAuthorities(" +
         username + ")");

      GrantedAuthority[] autorities = authoritiesDAO.getAuthorities(username, password);
      writeLog(
         "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: after authoritiesDAO.getAuthorities(" +
         username + ")");
      writeLog(
         "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: autorities --> ");

      for (int i = 0; i < autorities.length; i++) {
         writeLog("******* SACEPasswordAuthenticationDao --> " +
            autorities[i].getAuthority());
      }

      return new User(username, password, true, true, true, true, autorities);
   }

   /**
    *
    * @param user
    * @param password
    * @return
    */
   protected String getEncodedQuerryString(String user, String password) {
      try {
         SACEInputQueryVO inputVO = new SACEInputQueryVO(this.format, user,
               password);

         // SACE does not accept space or any ctrl character (!)
         String xml = StringUtils.deleteSpaces(this.xmlConverter.toXML(inputVO));

         return "XMLIn=" + URLEncoder.encode(xml, UTF_8);
      } catch (UnsupportedEncodingException e) {
         throw new AuthenticationServiceException("", e);
      }
   }

   /**
    * Documentaci�.
    *
    * @param pMessage Documentaci�
    */
   public void writeLog(String pMessage) {
      try {
         pMessage = "\n" + pMessage;

         if (logService != null) {
            logService.getLog(this.getClass()).debug(pMessage);
         }
      } catch (Exception e) {
      }

      ;
   }

   /**
    * Documentaci�.
    *
    * @param e Documentaci�
    */
   public void writeException(Exception e) {
      try {
         String sMessage = "\n ******* SACEPasswordAuthenticationDao --> stacktrace de la excepci�n " +
            e.getClass().getName() + "\n";

         if (logService != null) {
            logService.getLog(this.getClass()).error(sMessage, e);
         }
      } catch (Exception e1) {
      }

      ;
   }

   /**
    * @return Returns the logService.
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * @param logService
    *            The logService to set.
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * @return Returns the wasServer.
    */
   public boolean isWasServer() {
      return wasServer;
   }

   /**
    * @param wasServer
    *            The wasServer to set.
    */
   public void setWasServer(boolean wasServer) {
      this.wasServer = wasServer;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Properties getCertificates() {
      return certificates;
   }

   /**
    * Documentaci�.
    *
    * @param certificates Documentaci�
    */
   public void setCertificates(Properties certificates) {
      this.certificates = certificates;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getKeyStore() {
      return keyStore;
   }

   /**
    * Documentaci�.
    *
    * @param keyStore Documentaci�
    */
   public void setKeyStore(String keyStore) {
      this.keyStore = keyStore;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getKeyStorePassPhrase() {
      return keyStorePassPhrase;
   }

   /**
    * Documentaci�.
    *
    * @param keyStorePassPhrase Documentaci�
    */
   public void setKeyStorePassPhrase(String keyStorePassPhrase) {
      this.keyStorePassPhrase = keyStorePassPhrase;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public HttpsConfigBean getHttpsConfigBean() {
      return httpsConfigBean;
   }

   /**
    * Documentaci�.
    *
    * @param httpsConfigBean Documentaci�
    */
   public void setHttpsConfigBean(HttpsConfigBean httpsConfigBean) {
      this.httpsConfigBean = httpsConfigBean;
   }

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException, DataAccessException {
		throw new UnsupportedOperationException(
        "Use loadUserByUsernameAndPassword(String username, String password) instead!");
	}
   
	/**
	 * Documentaci�.
	 *
	 * @return Documentaci�
	 */
	public I18nService getI18nSecurityService() {
		return i18nSecurityService;
	}

	/**
	 * Documentaci�.
	 *
	 * @param service Documentaci�
	 */
	public void setI18nSecurityService(I18nService service) {
		i18nSecurityService = service;
	}

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.9 $
     */
   private static class AlwaysTrustManager implements X509TrustManager {
      /**
       * Creates a new AlwaysTrustManager object.
       */
      public AlwaysTrustManager() {
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public X509Certificate[] getAcceptedIssuers() {
         return null;
      }

      /**
       * Documentaci�.
       *
       * @param chain Documentaci�
       *
       * @return Documentaci�
       */
      public boolean isClientTrusted(X509Certificate[] chain) {
         return true;
      }

      /**
       * Documentaci�.
       *
       * @param chain Documentaci�
       *
       * @return Documentaci�
       */
      public boolean isServerTrusted(X509Certificate[] chain) {
         return true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String toString() {
         return "toString: AlwaysTrustManager";
      }

      /**
       * Documentaci�.
       *
       * @param arg0 Documentaci�
       * @param arg1 Documentaci�
       *
       * @return Documentaci�
       */
      public String[] getClientAliases(String arg0, Principal[] arg1) {
         return null;
      }

      /**
       * Documentaci�.
       *
       * @param arg0 Documentaci�
       * @param arg1 Documentaci�
       * @param arg2 Documentaci�
       *
       * @return Documentaci�
       */
      public String chooseClientAlias(String[] arg0, Principal[] arg1,
         Socket arg2) {
         return null;
      }

      /**
       * Documentaci�.
       *
       * @param arg0 Documentaci�
       * @param arg1 Documentaci�
       *
       * @return Documentaci�
       */
      public String[] getServerAliases(String arg0, Principal[] arg1) {
         return null;
      }

      /**
       * Documentaci�.
       *
       * @param arg0 Documentaci�
       * @param arg1 Documentaci�
       * @param arg2 Documentaci�
       *
       * @return Documentaci�
       */
      public String chooseServerAlias(String arg0, Principal[] arg1, Socket arg2) {
         return null;
      }

      /**
       * Documentaci�.
       *
       * @param arg0 Documentaci�
       *
       * @return Documentaci�
       */
      public X509Certificate[] getCertificateChain(String arg0) {
         return null;
      }

      /**
       * Documentaci�.
       *
       * @param arg0 Documentaci�
       *
       * @return Documentaci�
       */
      public PrivateKey getPrivateKey(String arg0) {
         return null;
      }

      /**
       * Documentaci�.
       *
       * @param ax509certificate Documentaci�
       * @param s Documentaci�
       *
       * @throws CertificateException Documentaci�
       */
      public void checkClientTrusted(X509Certificate[] ax509certificate,
         String s) throws CertificateException {
      }

      /**
       * Documentaci�.
       *
       * @param ax509certificate Documentaci�
       * @param s Documentaci�
       *
       * @throws CertificateException Documentaci�
       */
      public void checkServerTrusted(X509Certificate[] ax509certificate,
         String s) throws CertificateException {
      }
   }
}
