/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import java.util.List;

import javax.sql.DataSource;

import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.GrantedAuthorityImpl;
import net.sf.acegisecurity.UserDetails;
import net.sf.acegisecurity.providers.dao.AuthenticationDao;
import net.sf.acegisecurity.providers.dao.User;
import net.sf.acegisecurity.providers.dao.UsernameNotFoundException;

import org.springframework.context.ApplicationContextException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.MappingSqlQuery;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class DatabaseAuhenticationDAO extends JdbcDaoSupport
   implements AuthenticationDao {
   /**
    * Documentaci�.
    */
   public static final String DEF_USERS_BY_USERNAME_QUERY = "SELECT USER_LOGIN_ID, password FROM USER_LOGIN WHERE USER_LOGIN_ID=?";

   /**
    * Documentaci�.
    */
   private AuthoritiesDAO authoritiesDAO;

   /**
    * Documentaci�.
    */
   private MappingSqlQuery usersByUsernameMapping;

   /**
    * Documentaci�.
    */
   private String usersByUsernameQuery;

   /**
    * Documentaci�.
    */
   private boolean usernameBasedPrimaryKey = true;

   /**
    * Creates a new DatabaseAuhenticationDAO object.
    */
   public DatabaseAuhenticationDAO() {
      usersByUsernameQuery = DEF_USERS_BY_USERNAME_QUERY;
   }

   /**
    * If <code>true</code> (the default), indicates the {@link
    * #getUsersByUsernameMapping()} returns a username in response to a
    * query. If <code>false</code>, indicates that a primary key is used
    * instead. If set to <code>true</code>, the class will use the
    * database-derived username in the returned <code>UserDetails</code>. If
    * <code>false</code>, the class will use the {@link
    * #loadUserByUsername(String)} derived username in the returned
    * <code>UserDetails</code>.
    *
    * @param usernameBasedPrimaryKey <code>true</code> if the mapping queries
    *        return the username <code>String</code>, or <code>false</code>
    *        if the mapping returns a database primary key.
    */
   public void setUsernameBasedPrimaryKey(boolean usernameBasedPrimaryKey) {
      this.usernameBasedPrimaryKey = usernameBasedPrimaryKey;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isUsernameBasedPrimaryKey() {
      return usernameBasedPrimaryKey;
   }

   /**
    * Allows the default query string used to retrieve users based on username
    * to be overriden, if default table or column names need to be changed.
    * The default query is {@link #DEF_USERS_BY_USERNAME_QUERY}; when
    * modifying this query, ensure that all returned columns are mapped back
    * to the same column names as in the default query. If the 'enabled'
    * column does not exist in the source db, a permanent true value for this
    * column may be returned by using a query similar to <br>
    * <pre>
    * "SELECT username,password,'true' as enabled FROM users WHERE username = ?"
    * </pre>
    *
    * @param usersByUsernameQueryString The query string to set
    */
   public void setUsersByUsernameQuery(String usersByUsernameQueryString) {
      this.usersByUsernameQuery = usersByUsernameQueryString;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getUsersByUsernameQuery() {
      return usersByUsernameQuery;
   }

   /**
    * Documentaci�.
    *
    * @param username Documentaci�
    *
    * @return Documentaci�
    *
    * @throws UsernameNotFoundException Documentaci�
    * @throws DataAccessException Documentaci�
    */
   public UserDetails loadUserByUsername(String username)
      throws UsernameNotFoundException, DataAccessException {
      List users = usersByUsernameMapping.execute(username);

      if (users.size() == 0) {
         throw new UsernameNotFoundException("User not found");
      }

      UserDetails user = (UserDetails) users.get(0); // contains no GrantedAuthority[]
      String returnUsername = user.getUsername();

      GrantedAuthority[] authorities = authoritiesDAO.getAuthorities(returnUsername);

      if (authorities.length == 0) {
         throw new UsernameNotFoundException("User has no GrantedAuthority");
      }

      if (!usernameBasedPrimaryKey) {
         returnUsername = username;
      }

      return new User(returnUsername, user.getPassword(), user.isEnabled(),
         true, true, true, authorities);
   }

   /**
    * Documentaci�.
    *
    * @throws ApplicationContextException Documentaci�
    */
   protected void initDao() throws ApplicationContextException {
      initMappingSqlQueries();
   }

   /**
    * Extension point to allow other MappingSqlQuery objects to be substituted
    * in a subclass
    */
   protected void initMappingSqlQueries() {
      this.usersByUsernameMapping = new UsersByUsernameMapping(getDataSource());
   }

   /**
    * Documentaci�.
    *
    * @param authoritiesDAO Documentaci�
    */
   public void setAuthoritiesDAO(AuthoritiesDAO authoritiesDAO) {
      this.authoritiesDAO = authoritiesDAO;
   }

   /**
    * Query object to look up a user.
    */
   protected class UsersByUsernameMapping extends MappingSqlQuery {
      /**
       * Creates a new UsersByUsernameMapping object.
       *
       * @param ds DOCUMENT ME.
       */
      protected UsersByUsernameMapping(DataSource ds) {
         super(ds, usersByUsernameQuery);
         declareParameter(new SqlParameter(Types.VARCHAR));
         compile();
      }

      /**
       * Documentaci�.
       *
       * @param rs Documentaci�
       * @param rownum Documentaci�
       *
       * @return Documentaci�
       *
       * @throws SQLException Documentaci�
       */
      protected Object mapRow(ResultSet rs, int rownum)
         throws SQLException {
         String username = rs.getString(1);
         String password = rs.getString(2);

         // enabled = true by default
         UserDetails user = new User(username, password, true, true, true,
               true,
               new GrantedAuthority[] { new GrantedAuthorityImpl("HOLDER") });

         return user;
      }
   }
}
