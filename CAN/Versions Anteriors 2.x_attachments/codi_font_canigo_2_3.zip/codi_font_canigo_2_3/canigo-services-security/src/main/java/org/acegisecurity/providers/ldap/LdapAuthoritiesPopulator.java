/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package org.acegisecurity.providers.ldap;

import javax.naming.directory.Attributes;

import net.sf.acegisecurity.GrantedAuthority;


/**
 * Obtains a list of granted authorities for an Ldap user.
 * <p>
 * Used by the <tt>LdapAuthenticationProvider</tt> once a user has been
 * authenticated to create the final user details object.
 * </p>
 *
 * @author Luke Taylor
 * @version $Id: LdapAuthoritiesPopulator.java,v 1.5 2007/07/16 08:43:59 msabates Exp $
 */
public interface LdapAuthoritiesPopulator {
   /**
    * Get the list of authorities for the user.
    *
    * @param username the login name which was passed to the LDAP provider.
    * @param userDn the full DN of the user
    * @param userAttributes the user's LDAP attributes that were retrieved from the directory.
    * @return the granted authorities for the given user.
    * @throws LdapDataAccessException if there is a problem accessing the directory.
    */
   GrantedAuthority[] getGrantedAuthorities(String username, String userDn,
      Attributes userAttributes) throws LdapDataAccessException;
}
