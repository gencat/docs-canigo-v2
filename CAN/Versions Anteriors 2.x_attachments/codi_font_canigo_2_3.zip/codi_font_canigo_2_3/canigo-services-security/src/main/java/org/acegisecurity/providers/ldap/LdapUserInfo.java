/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package org.acegisecurity.providers.ldap;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;


/**
 * A user representation which is used internally by the Ldap provider.
 *
 * It contains the user's distinguished name and a set of attributes that have
 * been retrieved from the Ldap server.
 * <p>
 * An instance may be created as the result of a search, or when user
 * information is retrieved during authentication.
 * </p>
 * <p>
 * An instance of this class will be used by the
 * <tt>LdapAuthenticationProvider</tt> to construct the final user details
 * object that it returns.
 * </p>
 *
 * @author Luke Taylor
 * @version $Id: LdapUserInfo.java,v 1.5 2007/07/16 08:43:59 msabates Exp $
 */
public class LdapUserInfo {
   /**
    * Documentaci�.
    */
   private Attributes attributes;

   // ~ Instance fields
   /**
    * Documentaci�.
    */
   private String dn;

   // ~ Constructors
   // ===========================================================

   /**
    *
    * @param dn
    *            the full DN of the user
    * @param attributes
    *            any attributes loaded from the user's directory entry.
    */
   public LdapUserInfo(String dn, Attributes attributes) {
      this.dn = dn;
      this.attributes = attributes;
   }

   // ~ Methods
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getDn() {
      return dn;
   }

   /**
    * Documentaci�.
    *
    * @param ctx Documentaci�
    *
    * @return Documentaci�
    *
    * @throws NamingException Documentaci�
    */
   public String getRelativeName(DirContext ctx) throws NamingException {
      return LdapUtils.getRelativeName(dn, ctx);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Attributes getAttributes() {
      return (Attributes) attributes.clone();
   }
}
