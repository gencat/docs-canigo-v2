/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import net.gencat.ctti.canigo.services.security.acegi.providers.dao.AuthoritiesDAO;
import net.gencat.ctti.canigo.services.security.acegi.providers.dao.GICARUser;
import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.UserDetails;
import net.sf.acegisecurity.providers.dao.UsernameNotFoundException;

import org.acegisecurity.userdetails.UserDetailsService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;


/**
 * Classe encarregada d'obtenir les dades del usuari a partir del seu nom
 *
 * @author       ALBERT SANCHO
 * @version      1.0
 */
public class GICARUserDetailsServiceImpl implements UserDetailsService {
   /**
    * Separador dels camps de la cap�alera
    */
   private static final String HEADER_SEPARATOR = ";";

   /**
    * Documentaci�.
    */
   private static final String CODI_INTERN_KEY = "CODIINTERN";

   /**
    * Documentaci�.
    */
   private static final String NIF_KEY = "NIF";

   /**
    * Documentaci�.
    */
   private static final String EMAIL_KEY = "EMAIL";

   /**
    * Documentaci�.
    */
   private static final String UNITAT_MAJOR_KEY = "UNITAT_MAJOR";

   /**
    * Documentaci�.
    */
   private static final String UNITAT_MENOR_KEY = "UNITAT_MENOR";

   /**
    * DAO per obtenir els permissos de l'usuari
    */
   private AuthoritiesDAO authoritiesDAO;

   /**
    * Nom del camp de la cap�alera que cont� el nom del usuari
    */
   private String httpGicarHeaderUsernameKey;

   /**
    * M�tode que carrega la informaci� del usuari
    */
  
   private static final Log logger = LogFactory.getLog(GICARUserDetailsServiceImpl.class);
   
   public UserDetails loadUserByUsername(String userInfo)
      throws UsernameNotFoundException, DataAccessException {
      if (userInfo.indexOf(httpGicarHeaderUsernameKey) != -1) {
    	  logger.debug("Trobada la capcelera: "+userInfo);
         //HTTP GICAR header example -> CODIINTERN=NRDRJN0001;NIF=11112222W;EMAIL=mail.admin@gencat.net;UNITAT_MAJOR=CTTI;UNITAT_MENOR=CTTI Qualitat
         String codiIntern = getHttpGicarHeaderField(userInfo, CODI_INTERN_KEY);
         String nif = getHttpGicarHeaderField(userInfo, NIF_KEY);
         String email = getHttpGicarHeaderField(userInfo, EMAIL_KEY);
         String unitatMajor = getHttpGicarHeaderField(userInfo, UNITAT_MAJOR_KEY);
         String unitatMenor = getHttpGicarHeaderField(userInfo, UNITAT_MENOR_KEY);

         String username = getHttpGicarHeaderField(userInfo,
               httpGicarHeaderUsernameKey);
         UserDetails gicarUser;
		try {
			GrantedAuthority[] authorities = this.authoritiesDAO.getAuthoritiesIgnoreCase(username);
			 gicarUser = new GICARUser(codiIntern, nif, email,
			       unitatMajor, unitatMenor, username, "dummy", true, true, true,
			       true, authorities);
	         logger.debug("User: "+nif);
	         return gicarUser;
		} catch (RuntimeException e) {
	    	  logger.error("Error d'obtenci� a BD de l'usuari: " + username + ". Excepcio: "+e.getMessage());
	    	  throw new UsernameNotFoundException(e.getMessage());
		}
      }
      logger.debug("No s'ha trobat la capcelera");

      return null;
   }

   /**
    * Documentaci�.
    *
    * @param userInfo Documentaci�
    * @param key Documentaci�
    *
    * @return Documentaci�
    */
   public String getHttpGicarHeaderField(String userInfo, String key) {
      int ini = userInfo.trim().indexOf(key) +
         key.length() + 1;
      int end = userInfo.trim().indexOf(HEADER_SEPARATOR, ini);

      if (end == -1) {
         end = userInfo.trim().length();
      }

      String value = userInfo.substring(ini, end);

      return value;
   }

   /**
    * Documentaci�.
    *
    * @param authoritiesDAO Documentaci�
    */
   public void setAuthoritiesDAO(AuthoritiesDAO authoritiesDAO) {
      this.authoritiesDAO = authoritiesDAO;
   }

   /**
    * Documentaci�.
    *
    * @param httpGicarHeaderUsernameKey Documentaci�
    */
   public void setHttpGicarHeaderUsernameKey(String httpGicarHeaderUsernameKey) {
      this.httpGicarHeaderUsernameKey = httpGicarHeaderUsernameKey;
   }
}
