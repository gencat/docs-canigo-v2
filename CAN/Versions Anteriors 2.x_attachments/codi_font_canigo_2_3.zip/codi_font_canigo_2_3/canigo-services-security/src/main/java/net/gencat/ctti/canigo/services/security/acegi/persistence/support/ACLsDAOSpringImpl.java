/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.persistence.support;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import javax.sql.DataSource;

import net.gencat.ctti.canigo.services.security.acegi.AclProviderWithIdRegistration;
import net.gencat.ctti.canigo.services.security.acegi.persistence.ACLsDAO;
import net.sf.acegisecurity.acl.basic.SimpleAclEntry;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.jdbc.object.SqlUpdate;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class ACLsDAOSpringImpl extends JdbcDaoSupport
   implements InitializingBean, ACLsDAO {
   /**
    * Documentaci�.
    */
   private AclObjectIdentityByObjectIdentityQuery AclIdQuery;

   // ~ Instance fields
   /**
    * Documentaci�.
    */
   private AclObjectIdentityInsert aclInsert;

   /**
    * Documentaci�.
    */
   private AclProviderWithIdRegistration aclProvider;

   /**
    * Documentaci�.
    */
   private PermissionInsert permissionInsert;

   // ~ Methods
   /**
    * Documentaci�.
    *
    * @param aclProvider Documentaci�
    */
   public void setAclProvider(AclProviderWithIdRegistration aclProvider) {
      this.aclProvider = aclProvider;
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void initDao() throws Exception {
      this.aclInsert = new AclObjectIdentityInsert(getDataSource());
      this.permissionInsert = new PermissionInsert(getDataSource());
      this.AclIdQuery = new AclObjectIdentityByObjectIdentityQuery(getDataSource());
   }

   /**
    * Documentaci�.
    *
    * @param domainObject Documentaci�
    */
   public void addACLsToDomainObject(Object domainObject) {
      String aclId = this.aclProvider.serializeObjectIdentity(domainObject);
      aclInsert.insert(aclId, null, SimpleAclEntry.class.getName());
   }

   /**
    * Documentaci�.
    *
    * @param principal Documentaci�
    * @param domainObject Documentaci�
    */
   public void addReadPermissionForUser(String principal, Object domainObject) {
      Integer id = getACLIdentity(domainObject);
      this.permissionInsert.insert(id, principal, SimpleAclEntry.READ);
   }

   /**
    * Documentaci�.
    *
    * @param principal Documentaci�
    * @param domainObject Documentaci�
    */
   public void addDeletePermissionForUser(String principal, Object domainObject) {
      Integer id = getACLIdentity(domainObject);
      this.permissionInsert.insert(id, principal, SimpleAclEntry.DELETE);
   }

   /**
    * Documentaci�.
    *
    * @param principal Documentaci�
    * @param domainObject Documentaci�
    */
   public void addCreatePermissionForUser(String principal, Object domainObject) {
      Integer id = getACLIdentity(domainObject);
      this.permissionInsert.insert(id, principal, SimpleAclEntry.CREATE);
   }

   /**
    * Documentaci�.
    *
    * @param principal Documentaci�
    * @param domainObject Documentaci�
    */
   public void addWritePermissionForUser(String principal, Object domainObject) {
      Integer id = getACLIdentity(domainObject);
      this.permissionInsert.insert(id, principal, SimpleAclEntry.WRITE);
   }

   /**
    * Documentaci�.
    *
    * @param domainObject Documentaci�
    *
    * @return Documentaci�
    */
   protected Integer getACLIdentity(Object domainObject) {
      String objectIdentity = this.aclProvider.serializeObjectIdentity(domainObject);

      Integer id = (Integer) this.AclIdQuery.findObject(objectIdentity);

      if (id == null) {
         addACLsToDomainObject(domainObject);
         id = (Integer) this.AclIdQuery.findObject(objectIdentity);
      }

      return id;
   }

   // ~ Inner Classes
   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.5 $
     */
   protected class AclObjectIdentityByObjectIdentityQuery
      extends MappingSqlQuery {
      /**
       * Creates a new AclObjectIdentityByObjectIdentityQuery object.
       *
       * @param ds DOCUMENT ME.
       */
      protected AclObjectIdentityByObjectIdentityQuery(DataSource ds) {
         super(ds,
            "SELECT id FROM acl_object_identity WHERE object_identity = ?");
         declareParameter(new SqlParameter(Types.VARCHAR));
         compile();
      }

      /**
       * Documentaci�.
       *
       * @param rs Documentaci�
       * @param rownum Documentaci�
       *
       * @return Documentaci�
       *
       * @throws SQLException Documentaci�
       */
      protected Object mapRow(ResultSet rs, int rownum)
         throws SQLException {
         return new Integer(rs.getInt("id"));
      }
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.5 $
     */
   protected class AclObjectIdentityInsert extends SqlUpdate {
      /**
       * Creates a new AclObjectIdentityInsert object.
       *
       * @param ds DOCUMENT ME.
       */
      protected AclObjectIdentityInsert(DataSource ds) {
         super(ds, "INSERT INTO acl_object_identity VALUES (?, ?, ?, ?)");
         declareParameter(new SqlParameter(Types.INTEGER));
         declareParameter(new SqlParameter(Types.VARCHAR));
         declareParameter(new SqlParameter(Types.INTEGER));
         declareParameter(new SqlParameter(Types.VARCHAR));
         compile();
      }

      /**
       * Documentaci�.
       *
       * @param objectIdentity Documentaci�
       * @param parentAclObjectIdentity Documentaci�
       * @param aclClass Documentaci�
       */
      protected void insert(String objectIdentity,
         Integer parentAclObjectIdentity, String aclClass) {
         Object[] objs = new Object[] {
               null, objectIdentity, parentAclObjectIdentity, aclClass
            };
         super.update(objs);
      }
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.5 $
     */
   protected class PermissionInsert extends SqlUpdate {
      /**
       * Creates a new PermissionInsert object.
       *
       * @param ds DOCUMENT ME.
       */
      protected PermissionInsert(DataSource ds) {
         super(ds, "INSERT INTO acl_permission VALUES (?, ?, ?, ?)");
         declareParameter(new SqlParameter(Types.INTEGER));
         declareParameter(new SqlParameter(Types.INTEGER));
         declareParameter(new SqlParameter(Types.VARCHAR));
         declareParameter(new SqlParameter(Types.INTEGER));
         compile();
      }

      /**
       * Documentaci�.
       *
       * @param aclObjectIdentity Documentaci�
       * @param recipient Documentaci�
       * @param mask Documentaci�
       */
      protected void insert(Integer aclObjectIdentity, String recipient,
         int mask) {
         Object[] objs = new Object[] {
               null, aclObjectIdentity, recipient, new Integer(mask)
            };
         super.update(objs);
      }
   }
}
