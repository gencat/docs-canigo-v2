/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package org.acegisecurity.providers.ldap.authenticator;

import java.text.MessageFormat;

import java.util.ArrayList;
import java.util.List;

import org.acegisecurity.AcegiMessageSource;
import org.acegisecurity.providers.ldap.InitialDirContextFactory;
import org.acegisecurity.providers.ldap.LdapAuthenticator;
import org.acegisecurity.providers.ldap.LdapUserSearch;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceAware;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.util.Assert;


/**
 * Base class for the authenticator implementations.
 *
 * @author Luke Taylor
 * @version $Id: AbstractLdapAuthenticator.java,v 1.5 2007/07/16 08:43:59 msabates Exp $
 */
public abstract class AbstractLdapAuthenticator implements LdapAuthenticator,
   InitializingBean, MessageSourceAware {
   /**
    * Documentaci�.
    */
   protected MessageSourceAccessor messages = AcegiMessageSource.getAccessor();

   /**
    * Documentaci�.
    */
   private InitialDirContextFactory initialDirContextFactory;

   /** Optional search object which can be used to locate a user when a simple DN match isn't sufficient */
   private LdapUserSearch userSearch;

   /**
    * The suffix to be added to the DN patterns, worked out internally from the root DN of the
    * configured InitialDirContextFactory.
    */
   private String dnSuffix = "";

   /** The attributes which will be retrieved from the directory. Null means all attributes */
   private String[] userAttributes = null;

   //private String[] userDnPattern = null;

   /** Stores the patterns which are used as potential DN matches */
   private MessageFormat[] userDnFormat = null;

   /**
    * Creates a new AbstractLdapAuthenticator object.
    *
    * @param initialDirContextFactory DOCUMENT ME.
    */
   protected AbstractLdapAuthenticator(
      InitialDirContextFactory initialDirContextFactory) {
      Assert.notNull(initialDirContextFactory,
         "initialDirContextFactory must not be null.");
      this.initialDirContextFactory = initialDirContextFactory;

      String rootDn = initialDirContextFactory.getRootDn();

      if (rootDn.length() > 0) {
         dnSuffix = "," + rootDn;
      }
   }

   /**
    * Builds list of possible DNs for the user, worked out from the
    * <tt>userDnPatterns</tt> property. The returned value includes the root DN of
    * the provider URL used to configure the <tt>InitialDirContextfactory</tt>.
    *
    * @param username the user's login name
    * @return the list of possible DN matches, empty if <tt>userDnPatterns</tt> wasn't
    * set.
    */
   protected List getUserDns(String username) {
      if (userDnFormat == null) {
         return new ArrayList(0);
      }

      List userDns = new ArrayList(userDnFormat.length);
      String[] args = new String[] { username };

      synchronized (userDnFormat) {
         for (int i = 0; i < userDnFormat.length; i++) {
            userDns.add(userDnFormat[i].format(args) + dnSuffix);
         }
      }

      return userDns;
   }

   /**
    * Sets the pattern which will be used to supply a DN for the user.
    * The pattern should be the name relative to the root DN.
    * The pattern argument {0} will contain the username.
    * An example would be "cn={0},ou=people".
    */
   public void setUserDnPatterns(String[] dnPattern) {
      Assert.notNull(dnPattern, "The array of DN patterns cannot be set to null");
      //        this.userDnPattern = dnPattern;
      userDnFormat = new MessageFormat[dnPattern.length];

      for (int i = 0; i < dnPattern.length; i++) {
         userDnFormat[i] = new MessageFormat(dnPattern[i]);
      }
   }

   /**
    * Sets the user attributes which will be retrieved from the directory.
    *
    * @param userAttributes
    */
   public void setUserAttributes(String[] userAttributes) {
      Assert.notNull(userAttributes,
         "The userAttributes property cannot be set to null");
      this.userAttributes = userAttributes;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String[] getUserAttributes() {
      return userAttributes;
   }

   /**
    * Documentaci�.
    *
    * @param userSearch Documentaci�
    */
   public void setUserSearch(LdapUserSearch userSearch) {
      Assert.notNull(userSearch, "The userSearch cannot be set to null");
      this.userSearch = userSearch;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected LdapUserSearch getUserSearch() {
      return userSearch;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected InitialDirContextFactory getInitialDirContextFactory() {
      return initialDirContextFactory;
   }

   /**
    * Documentaci�.
    *
    * @param messageSource Documentaci�
    */
   public void setMessageSource(MessageSource messageSource) {
      Assert.notNull("Message source must not be null");
      this.messages = new MessageSourceAccessor(messageSource);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void afterPropertiesSet() throws Exception {
      Assert.isTrue((userDnFormat != null) || (userSearch != null),
         "Either an LdapUserSearch or DN pattern (or both) must be supplied.");
   }
}
