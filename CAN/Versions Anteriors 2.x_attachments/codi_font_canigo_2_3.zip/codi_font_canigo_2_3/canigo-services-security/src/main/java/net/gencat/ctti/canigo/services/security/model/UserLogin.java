/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class UserLogin implements Comparable {
   /**
    * Documentaci�.
    */
   protected Set roles;

   /**
    * Documentaci�.
    */
   private PartyGroup group;

   /**
    * This is not a collection. <=> List "Application Roles" in User Details Edit page.
    * Initialized to null because we NEVER want to pre-select a role but the framework tag
    * requires a "property value"
    */
   private Role applicationRoles = null;

   /**
    * available Roles for that user = {ALL ROLES}
    *                               - {Roles assigned to user}
    *                               - {Roles assigned to group and hierarchy of groups}
    *                               - {Hierarchy of Roles }
    *                               - {The grand-mother of my uncle cousins}
    */
   private Set availableRoles;

   /**
    * Documentaci�.
    */
   private String password;

   /**
    * Documentaci�.
    */
   private String userName;

   /**
    * Documentaci�.
    */
   private int hashCode = Integer.MIN_VALUE;

   /**
    * Creates a new UserLogin object.
    */
   public UserLogin() {
   }

   /**
    * Creates a new UserLogin object.
    *
    * @param userName DOCUMENT ME.
    */
   public UserLogin(String userName) {
      this.userName = userName;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getUserName() {
      return this.userName;
   }

   /**
    * Documentaci�.
    *
    * @param userName Documentaci�
    */
   public void setUserName(String userName) {
      this.userName = userName;
   }

   /**
    * Documentaci�.
    *
    * @param roles Documentaci�
    */
   public void setRoles(Set roles) {
      this.roles = roles;
   }

   /**
    * Documentaci�.
    *
    * @param password Documentaci�
    */
   public void setPassword(String password) {
      this.password = password;
   }

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    */
   public void addRole(Role role) {
      if (this.roles == null) {
         this.roles = new HashSet();
      }

      if (this.hasRole(role)) {
         throw new IllegalArgumentException("User has already the role" + role);
      }

      this.roles.add(role);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private Role[] getAllRolesArray() {
      return (Role[]) this.roles.toArray(new Role[] {  });
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getPassword() {
      return this.password;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public PartyGroup getGroup() {
      return this.group;
   }

   /**
    * Documentaci�.
    *
    * @param group Documentaci�
    */
   public void setGroup(PartyGroup group) {
      this.group = group;
   }

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    *
    * @return Documentaci�
    */
   public boolean hasRole(Role role) {
      List allRoles = new ArrayList(getAllRoles());

      return allRoles.contains(role);
   }

   /**
    * Browse recursively the list of roles, to get all the chain of parents' roles
    * @return
    */
   public Set getAllRoles() {
      Set allRoles = new HashSet();

      if (this.roles != null) {
         for (Iterator iter = this.roles.iterator(); iter.hasNext();) {
            Role role = (Role) iter.next();
            allRoles.add(role);
            allRoles.addAll(role.getRecursiveParentRoles());
         }
      }

      if (this.group != null) {
         allRoles.addAll(this.group.getRecursiveRoles());
      }

      return allRoles;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Role getFirstRole() {
      return this.getAllRolesArray()[0];
   }

   /**
    * Documentaci�.
    *
    * @param obj Documentaci�
    *
    * @return Documentaci�
    */
   public boolean equals(Object obj) {
      if (null == obj) {
         return false;
      }

      if (!(obj instanceof UserLogin)) {
         return false;
      } else {
         UserLogin x = (UserLogin) obj;

         if ((null == this.getUserName()) || (null == x.getUserName())) {
            return false;
         } else {
            return (this.getUserName().equals(x.getUserName()));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int hashCode() {
      if (Integer.MIN_VALUE == this.hashCode) {
         if (null == this.getUserName()) {
            return super.hashCode();
         } else {
            String hashStr = this.getClass().getName() + ":" +
               this.getUserName().hashCode();
            this.hashCode = hashStr.hashCode();
         }
      }

      return this.hashCode;
   }

   /**
    * Documentaci�.
    *
    * @param obj Documentaci�
    *
    * @return Documentaci�
    */
   public int compareTo(Object obj) {
      if (obj.hashCode() > hashCode()) {
         return 1;
      } else if (obj.hashCode() < hashCode()) {
         return -1;
      } else {
         return 0;
      }
   }

   /**
    * Get the roles only specific to the user, does NOT include the hiearchy of roles, neither the user's group role, neither my grand-mother ...
    * @return Roles only specific to the user, does NOT include the hiearchy of roles, neither the user's group roles.
    */
   public Set getRoles() {
      return roles;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Role getApplicationRoles() {
      return applicationRoles;
   }

   /**
    * Documentaci�.
    *
    * @param applicationRoles Documentaci�
    */
   public void setApplicationRoles(Role applicationRoles) {
      this.applicationRoles = applicationRoles;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Set getAvailableRoles() {
      return availableRoles;
   }
}
