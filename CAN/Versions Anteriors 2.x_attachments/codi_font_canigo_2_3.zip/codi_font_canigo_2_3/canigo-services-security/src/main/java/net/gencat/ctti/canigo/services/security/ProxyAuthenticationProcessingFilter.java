/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import java.util.Enumeration;
import java.util.List;

import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.gencat.ctti.canigo.services.security.acegi.providers.SequentialProviderManager;
import net.sf.acegisecurity.Authentication;
import net.sf.acegisecurity.AuthenticationException;
import net.sf.acegisecurity.context.HttpSessionContextIntegrationFilter;
import net.sf.acegisecurity.context.SecurityContext;
import net.sf.acegisecurity.providers.AuthenticationProvider;
import net.sf.acegisecurity.ui.webapp.AuthenticationProcessingFilter;
import net.sf.acegisecurity.ui.webapp.SiteminderAuthenticationProcessingFilter;

import org.acegisecurity.providers.siteminder.SiteminderAuthenticationProvider;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Classe proxy mitjan�ant la qual es decideix si l'autenticaci� �s GICAR
 * (Siteminder) depenent de la configuraci� realitzada en el servei de seguretat
 * 
 * @author ALBERT SANCHO
 * @version 1.0
 */
public class ProxyAuthenticationProcessingFilter extends
		AuthenticationProcessingFilter {
	/**
	 * Filtre per a l'autenticaci� GICAR
	 */
	private SiteminderAuthenticationProcessingFilter siteminderAuthenticationProcessingFilter;

	private String loginFormUrl;

	private static final Log logger = LogFactory
			.getLog(ProxyAuthenticationProcessingFilter.class);
	
	private boolean siteminderAuthentication = false;

	public void init(FilterConfig arg0) throws ServletException {
		super.init(arg0);
		searchGicarProvider();
	}
	
	protected boolean requiresAuthentication(HttpServletRequest request,
			HttpServletResponse response) {
//		if (siteminderAuthenticationProcessingFilter != null && siteminderAuthentication) {
//
//			HttpSession httpSession = null;
//
//			try {
//				httpSession = ((HttpServletRequest) request).getSession(false);
//			} catch (IllegalStateException ignored) {
//			}
//
//			if (httpSession != null) {
//				Object contextFromSessionObject = httpSession
//						.getAttribute(HttpSessionContextIntegrationFilter.ACEGI_SECURITY_CONTEXT_KEY);
//
//				if (contextFromSessionObject != null) {
//					if (contextFromSessionObject instanceof SecurityContext) {
//						return false;
//					}
//				}
//			}
//			String uri = request.getRequestURI();
//			int pathParamIndex = uri.indexOf(';');
//
//			if (pathParamIndex > 0) {
//				// strip everything after the first semi-colon
//				uri = uri.substring(0, pathParamIndex);
//			}
//			return uri.indexOf(request.getContextPath() + loginFormUrl) == -1
//					&& uri.indexOf(request.getContextPath() + "AppJava"
//							+ loginFormUrl) == -1;
//		}
		return super.requiresAuthentication(request, response);
	}

	/**
	 * M�tode que realitza l'autenticaci� pel filtre de Siteminder o per el
	 * filtre gen�ric
	 */
	public Authentication attemptAuthentication(HttpServletRequest request)
			throws AuthenticationException {

		String gic = request.getHeader("GICAR");
		logger.debug("Cabecera Gicar: " + gic);
		if (gic == null || "".equals(gic)) {
			for (Enumeration en = request.getHeaderNames(); en
					.hasMoreElements();) {
				String nom = (String) en.nextElement();
				logger.debug("cabecera " + nom + " con valor "
						+ request.getHeader(nom));
			}
		}
		if (isSiteminderAuthentication()) {
			logger.debug("autenticado");
			return siteminderAuthenticationProcessingFilter
					.attemptAuthentication(request);
		} else {
			return super.attemptAuthentication(request);
		}
	}

	/**
	 * Documentaci�.
	 * 
	 * @param siteminderAuthenticationProcessingFilter
	 *            Documentaci�
	 */
	public void setSiteminderAuthenticationProcessingFilter(
			SiteminderAuthenticationProcessingFilter siteminderAuthenticationProcessingFilter) {
		this.siteminderAuthenticationProcessingFilter = siteminderAuthenticationProcessingFilter;
	}

	public String getLoginFormUrl() {
		return loginFormUrl;
	}

	public void setLoginFormUrl(String loginFormUrl) {
		this.loginFormUrl = loginFormUrl;
	}

	private void searchGicarProvider() {
		List authenticationProvidersList = ((SequentialProviderManager) this
				.getAuthenticationManager()).getProviders();
		for (int i = 0; (i < authenticationProvidersList.size())
				&& !siteminderAuthentication; i++) {
			logger.debug("autenticando");
			AuthenticationProvider authenticationProvider = (AuthenticationProvider) authenticationProvidersList
					.get(i);

			if (authenticationProvider instanceof SiteminderAuthenticationProvider) {
				siteminderAuthentication = true;
			}
		}
	}

	public boolean isSiteminderAuthentication() {
		return siteminderAuthentication;
	}
	
	public void afterPropertiesSet() throws Exception {
		super.afterPropertiesSet();
		searchGicarProvider();
	}
}
