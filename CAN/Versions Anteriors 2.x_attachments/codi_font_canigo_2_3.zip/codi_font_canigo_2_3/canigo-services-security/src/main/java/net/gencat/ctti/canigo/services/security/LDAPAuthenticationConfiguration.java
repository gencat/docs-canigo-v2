/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import net.gencat.ctti.canigo.services.security.acegi.providers.dao.AuthoritiesDAO;
import net.gencat.ctti.canigo.services.security.acegi.providers.ldap.LdapPasswordAuthenticationDao;
import net.sf.acegisecurity.providers.AuthenticationProvider;
import net.sf.acegisecurity.providers.dao.DaoAuthenticationProvider;

import org.springframework.context.ApplicationContext;
import org.springframework.util.Assert;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class LDAPAuthenticationConfiguration
   extends AbstractAuthenticationConfiguration {
   /**
    * Documentaci�.
    */
   private String ldapURL;

   /**
    * Documentaci�.
    */
   private String userLookupNameFormat;

   /**
    * Documentaci�.
    */
   private String usernameFormat;

   //    private String roleAttribute;
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getLdapURL() {
      return ldapURL;
   }

   /**
    * Documentaci�.
    *
    * @param ldapURL Documentaci�
    */
   public void setLdapURL(String ldapURL) {
      this.ldapURL = ldapURL;
   }

   //    public String getRoleAttribute() {
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getUserLookupNameFormat() {
      return userLookupNameFormat;
   }

   /**
    * Documentaci�.
    *
    * @param userLookupNameFormat Documentaci�
    */
   public void setUserLookupNameFormat(String userLookupNameFormat) {
      this.userLookupNameFormat = userLookupNameFormat;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getUsernameFormat() {
      return usernameFormat;
   }

   /**
    * Documentaci�.
    *
    * @param usernameFormat Documentaci�
    */
   public void setUsernameFormat(String usernameFormat) {
      this.usernameFormat = usernameFormat;
   }

   /**
    * Documentaci�.
    *
    * @param applicationContext Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   protected AuthenticationProvider getAuthenticationProvider(
      ApplicationContext applicationContext) throws Exception {
      LdapPasswordAuthenticationDao ldapDAO = new LdapPasswordAuthenticationDao();
      ldapDAO.setUrl(this.getLdapURL());
      ldapDAO.setUserLookupNameFormat(this.userLookupNameFormat);
      ldapDAO.setUsernameFormat(this.usernameFormat);

      AuthoritiesDAO authoritiesDAO = super.getAuthoritiesDAO(applicationContext);
      ldapDAO.setAuthoritiesDAO(authoritiesDAO);

      DaoAuthenticationProvider passwordDaoAuthenticationProvider = createPasswordDaoAuthenticationProvider(ldapDAO);

      return passwordDaoAuthenticationProvider;
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void afterPropertiesSet() throws Exception {
      Assert.notNull(this.ldapURL, "ldapURL is null");
      Assert.notNull(this.userLookupNameFormat, "userLookupNameFormat is null");
      Assert.notNull(this.usernameFormat, "usernameFormat is null");
   }
}
