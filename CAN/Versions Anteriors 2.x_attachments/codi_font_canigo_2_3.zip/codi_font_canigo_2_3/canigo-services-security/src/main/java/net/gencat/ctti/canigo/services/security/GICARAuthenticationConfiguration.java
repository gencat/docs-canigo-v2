/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import net.gencat.ctti.canigo.services.security.acegi.providers.dao.AuthoritiesDAO;
import net.sf.acegisecurity.providers.AuthenticationProvider;

import org.acegisecurity.providers.siteminder.SiteminderAuthenticationProvider;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.util.Assert;


/**
 * Configuraci� per autenticaci� GICAR
 *
 * @author ALBERT SANCHO
 * @version 1.0
 */
public class GICARAuthenticationConfiguration
   extends AbstractAuthenticationConfiguration {
   /**
    * Nom del camp de la cap�alera HTTP amb la informaci� de l'autenticaci� GICAR
    */
   private String httpGicarHeaderUsernameKey;

   /**
    * Obtenci� del provider de GICAR
    */
   private static final Log logger = LogFactory.getLog(GICARAuthenticationConfiguration.class);
   protected AuthenticationProvider getAuthenticationProvider(
      ApplicationContext applicationContext) throws Exception {
	   logger.debug("GetAuthprovider");
	   System.out.println("correcto por ahora");
      GICARUserDetailsServiceImpl userDetailsService = new GICARUserDetailsServiceImpl();

      AuthoritiesDAO authoritiesDAO = this.getAuthoritiesDAO(applicationContext);
      userDetailsService.setAuthoritiesDAO(authoritiesDAO);
      userDetailsService.setHttpGicarHeaderUsernameKey(this.httpGicarHeaderUsernameKey);

      SiteminderAuthenticationProvider siteminderAuthenticationProvider = new SiteminderAuthenticationProvider();

      siteminderAuthenticationProvider.setUserDetailsService(userDetailsService);
      logger.debug("todo correcto");
      return siteminderAuthenticationProvider;
   }

   /**
    * Validaci� httpGicarHeaderUsernameKey no nul
    */
   public void afterPropertiesSet() throws Exception {
      Assert.notNull(this.httpGicarHeaderUsernameKey,
         "A HttpGicarHeaderUsernameKey must be set");
   }

   /**
    * Documentaci�.
    *
    * @param httpGicarHeaderUsernameKey Documentaci�
    */
   public void setHttpGicarHeaderUsernameKey(String httpGicarHeaderUsernameKey) {
      this.httpGicarHeaderUsernameKey = httpGicarHeaderUsernameKey;
   }
}
