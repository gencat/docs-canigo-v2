/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers;

import java.util.Iterator;

import net.sf.acegisecurity.Authentication;
import net.sf.acegisecurity.AuthenticationException;
import net.sf.acegisecurity.providers.AuthenticationProvider;
import net.sf.acegisecurity.providers.ProviderManager;
import net.sf.acegisecurity.providers.ProviderNotFoundException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * Code taken from Acegi 0.90
 *
 * @author A111422
 *
 */
public class SequentialProviderManager extends ProviderManager {
   /**
    * Documentaci�.
    */
   private static final Log logger = LogFactory.getLog(SequentialProviderManager.class);

   /**
    * Attempts to authenticate the passed {@link Authentication} object.
    *
    * <p>
    * The list of {@link AuthenticationProvider}s will be successively tried
    * until an <code>AuthenticationProvider</code> indicates it is capable of
    * authenticating the type of <code>Authentication</code> object passed.
    * Authentication will then be attempted with that
    * <code>AuthenticationProvider</code>.
    * </p>
    *
    * <p>
    * If more than one <code>AuthenticationProvider</code> supports the
    * passed <code>Authentication</code> object, only the first
    * <code>AuthenticationProvider</code> tried will determine the result. No
    * subsequent <code>AuthenticationProvider</code>s will be tried.
    * </p>
    *
    * @param authentication
    *            the authentication request object.
    *
    * @return a fully authenticated object including credentials.
    *
    * @throws AuthenticationException
    *             if authentication fails.
    */
   public Authentication doAuthentication(Authentication authentication)
      throws AuthenticationException {
      Iterator iter = super.getProviders().iterator();

      Class toTest = authentication.getClass();

      AuthenticationException lastException = null;

      while (iter.hasNext()) {
         AuthenticationProvider provider = (AuthenticationProvider) iter.next();

         if (provider.supports(toTest)) {
            logger.debug("Authentication attempt using " +
               provider.getClass().getName());

            Authentication result = null;

            try {
               result = provider.authenticate(authentication);
            } catch (AuthenticationException ae) {
               lastException = ae;
               logger.error("Authentication Exception", ae);
               result = null;
            }

            if (result != null) {
               return result;
            }
         }
      }

      if (lastException == null) {
         lastException = new ProviderNotFoundException(
               "No AuthenticationProvider found for {0}" + toTest.getName());
      }

      // Throw the exception
      throw lastException;
   }
}
