/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi;

import java.lang.reflect.InvocationTargetException;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.security.business.DomainObject;
import net.gencat.ctti.canigo.services.security.business.DomainObjectWithCompositeId;
import net.sf.acegisecurity.acl.basic.NamedEntityObjectIdentity;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class AclProviderWithIdRegistrationTest extends TestCase {
   /**
    * Documentaci�.
    */
   protected AclProviderWithIdRegistration aclProviderTest;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void setUp() throws Exception {
      this.aclProviderTest = new AclProviderWithIdRegistration();
   }

   /**
    * Documentaci�.
    */
   public void testRegisterIdGetter() {
      try {
         aclProviderTest.registerId(DomainObjectWithCompositeId.class,
            "getterWhichDoesNotExist");
         fail("Should have thrown an exception");
      } catch (IllegalArgumentException expected) {
         assertTrue(true);
         assertFalse(aclProviderTest.hasRegistredDomainClass(
               DomainObjectWithCompositeId.class));
      }

      // Should work
      aclProviderTest.registerId(DomainObjectWithCompositeId.class,
         "getCompositeId");
      assertTrue(aclProviderTest.hasRegistredDomainClass(
            DomainObjectWithCompositeId.class));
   }

   /**
    * Documentaci�.
    *
    * @throws IllegalAccessException Documentaci�
    * @throws InvocationTargetException Documentaci�
    */
   public void testObtainIdentityObject()
      throws IllegalAccessException, InvocationTargetException {
      DomainObject objectWithIdGetter = new DomainObject();
      objectWithIdGetter.setId(new Integer(1));

      NamedEntityObjectIdentity expectedId = new NamedEntityObjectIdentity(objectWithIdGetter);
      assertEquals(expectedId,
         aclProviderTest.obtainIdentity(objectWithIdGetter));

      DomainObjectWithCompositeId objectWithCompositeId = new DomainObjectWithCompositeId();

      try {
         aclProviderTest.obtainIdentity(objectWithCompositeId);
         fail("Should have thrown an exception");
      } catch (IllegalArgumentException expected) {
         assertTrue(true);
      }

      aclProviderTest.registerId(DomainObjectWithCompositeId.class,
         "getCompositeId");
      objectWithCompositeId.setCompositeId("1");

      NamedEntityObjectIdentity expectedCompositeId = new NamedEntityObjectIdentity(DomainObjectWithCompositeId.class.getName(),
            "1");
      assertEquals(expectedCompositeId,
         aclProviderTest.obtainIdentity(objectWithCompositeId));
   }
}
