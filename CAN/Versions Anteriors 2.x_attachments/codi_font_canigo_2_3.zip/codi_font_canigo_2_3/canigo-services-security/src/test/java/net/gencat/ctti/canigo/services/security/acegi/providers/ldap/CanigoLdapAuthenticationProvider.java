/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers.ldap;

import java.util.HashMap;
import java.util.Map;

import net.gencat.ctti.canigo.services.security.acegi.providers.dao.AuthoritiesDAO;
import net.sf.acegisecurity.Authentication;
import net.sf.acegisecurity.AuthenticationException;
import net.sf.acegisecurity.providers.AuthenticationProvider;

import org.acegisecurity.providers.ldap.DefaultInitialDirContextFactory;
import org.acegisecurity.providers.ldap.LdapAuthenticationProvider;
import org.acegisecurity.providers.ldap.LdapAuthoritiesPopulator;
import org.acegisecurity.providers.ldap.LdapUserSearch;
import org.acegisecurity.providers.ldap.authenticator.BindAuthenticator;
import org.acegisecurity.providers.ldap.search.FilterBasedLdapUserSearch;
import org.apache.commons.validator.GenericValidator;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class CanigoLdapAuthenticationProvider implements AuthenticationProvider {
   /**
    * Documentaci�.
    */
   protected LdapAuthenticationProvider authenticationProvider;

   /**
    * Documentaci�.
    */
   private AuthoritiesDAO authoritiesDAO;

   /**
    * Documentaci�.
    */
   private String managerDn = "";

   /**
    * Documentaci�.
    */
   private String managerPassword = "";

   /**
    * Documentaci�.
    */
   private String searchBase = "";

   /**
    * Documentaci�.
    */
   private String searchFilter = "";

   /**
    * Documentaci�.
    */
   private String url;

   /**
    * Documentaci�.
    */
   private String[] userDnPatterns = new String[] {  };

   /**
    * Creates a new CanigoLdapAuthenticationProvider object.
    *
    * @param url DOCUMENT ME.
    * @param authoritiesDAO DOCUMENT ME.
    */
   public CanigoLdapAuthenticationProvider(String url,
      AuthoritiesDAO authoritiesDAO) {
      this.url = url;
      this.authoritiesDAO = authoritiesDAO;
   }

   /**
    * Documentaci�.
    */
   protected void initialize() {
      DefaultInitialDirContextFactory initialDirContextFactory = new DefaultInitialDirContextFactory(this.url);

      Map map = new HashMap();
      map.put("java.naming.referral", "follow");
      initialDirContextFactory.setExtraEnvVars(map);

      if (!GenericValidator.isBlankOrNull(this.managerDn)) {
         initialDirContextFactory.setManagerDn(this.managerDn);
         initialDirContextFactory.setManagerPassword(this.managerPassword);
      }

      // TODO This is probably incorrect!
      LdapUserSearch ldapUserSearch = new FilterBasedLdapUserSearch(this.searchBase,
            this.searchFilter, initialDirContextFactory);

      BindAuthenticator ldapAuthenticator = new BindAuthenticator(initialDirContextFactory);
      ldapAuthenticator.setUserDnPatterns(this.userDnPatterns);
      ldapAuthenticator.setUserSearch(ldapUserSearch);

      LdapAuthoritiesPopulator canigoAuthoritiesPopulator = new CanigoLdapAuthoritiesPopulator(this.authoritiesDAO);

      this.authenticationProvider = new LdapAuthenticationProvider(ldapAuthenticator,
            canigoAuthoritiesPopulator);
   }

   /**
    * Documentaci�.
    *
    * @param userDnPatterns Documentaci�
    */
   public void setUserDnPatterns(String[] userDnPatterns) {
      this.userDnPatterns = userDnPatterns;
   }

   /**
    * Documentaci�.
    *
    * @param userDnPattern Documentaci�
    */
   public void setUserDnPattern(String userDnPattern) {
      this.userDnPatterns = new String[] { userDnPattern };
   }

   /**
    * Documentaci�.
    *
    * @param searchFilter Documentaci�
    */
   public void setSearchFilter(String searchFilter) {
      this.searchFilter = searchFilter;
   }

   /**
    * Documentaci�.
    *
    * @param searchBase Documentaci�
    */
   public void setSearchBase(String searchBase) {
      this.searchBase = searchBase;
   }

   /**
    * Documentaci�.
    *
    * @param managerDn Documentaci�
    */
   public void setManagerDn(String managerDn) {
      this.managerDn = managerDn;
   }

   /**
    * Documentaci�.
    *
    * @param managerPassword Documentaci�
    */
   public void setManagerPassword(String managerPassword) {
      this.managerPassword = managerPassword;
   }

   // Methods 
   /**
    * Documentaci�.
    *
    * @param authentication Documentaci�
    *
    * @return Documentaci�
    *
    * @throws AuthenticationException Documentaci�
    */
   public Authentication authenticate(Authentication authentication)
      throws AuthenticationException {
      return this.authenticationProvider.authenticate(authentication);
   }

   /**
    * Documentaci�.
    *
    * @param authentication Documentaci�
    *
    * @return Documentaci�
    */
   public boolean supports(Class authentication) {
      return this.authenticationProvider.supports(authentication);
   }
}
