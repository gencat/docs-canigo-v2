/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.model.dao;

import net.gencat.ctti.canigo.services.exceptions.SystemException;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


/**
 * <p>Insert description here</p>
 * <p>Date: 10-Sep-2004 </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * @author Jean-Michel Garnier
 */
public abstract class HibernateUtils {
   /**
    *
    */
   private static Configuration configuration;

   /**
    * would be better if the field was final
    */
   private static SessionFactory sessionFactory;

   /**
    *
    */
   public static final ThreadLocal threadLocalSession = new ThreadLocal();

   /**
    *
    */
   private static final ThreadLocal threadTransaction = new ThreadLocal();

   /**
    * Documentaci�.
    */
   private static final String TEST_HIBERNATE_CFG_XML = "/test.hibernate.cfg.xml";

   /**
    *
    */
   public static void loadConfiguration() {
      try {
         // Read the configuration from "hibernate.cfg.xml" in the CLASSPATH
         configuration = new Configuration().configure();

         // Initialize session factory
         sessionFactory = configuration.buildSessionFactory();
      } catch (HibernateException ex) {
         throw new RuntimeException("Exception building SessionFactory: " +
            ex.getMessage(), ex);
      }
   }

   /**
   *
   */
   public static void loadTestConfiguration() {
      loadConfiguration(TEST_HIBERNATE_CFG_XML);
   }

   /**
    * @return
    */
   private static void loadConfiguration(String fileNameInTheClassPath) {
      try {
         // Read the configuration from a file in the CLASSPATH
         configuration = new Configuration().configure(fileNameInTheClassPath);

         // Initialize session factory
         sessionFactory = configuration.buildSessionFactory();
      } catch (HibernateException ex) {
         throw new RuntimeException("Exception building SessionFactory: " +
            ex.getMessage(), ex);
      }
   }

   /**
    * @return
    */
   public static Configuration getConfiguration() {
      return configuration;
   }

   /**
    * Returns the SessionFactory used for this static class.
    *
    * @return SessionFactory
    */
   public static SessionFactory getSessionFactory() {
      return sessionFactory;
   }

   /**
    * Retrieves the current Session local to the thread.
    * <p/>
    * If no Session is open, opens a new Session for the running thread.
    *
    * @return Session
    */
   public static Session getCurrentSession() throws SystemException {
      Session s = (Session) threadLocalSession.get();

      try {
         if (s == null) {
            s = getSessionFactory().openSession();
            threadLocalSession.set(s);
         }
      } catch (HibernateException ex) {
         throw new SystemException(ex, "");
      }

      return s;
   }

   /**
     * Closes the Session local to the thread.
     */
   public static void closeSession() throws SystemException {
      try {
         Session s = (Session) threadLocalSession.get();
         threadLocalSession.set(null);

         if ((s != null) && s.isOpen()) {
            s.close();
         }
      } catch (HibernateException ex) {
         throw new SystemException(ex, "");
      }
   }

   /**
    * Start a new database transaction.
    */
   public static void beginTransaction(Session session)
      throws SystemException {
      Transaction tx = (Transaction) threadTransaction.get();

      try {
         if (tx == null) {
            tx = session.beginTransaction();
            threadTransaction.set(tx);
         }
      } catch (HibernateException ex) {
         throw new SystemException(ex, "");
      }
   }

   /**
    * Commit the database transaction.
    */
   public static void commitTransaction() throws SystemException {
      Transaction tx = (Transaction) threadTransaction.get();

      try {
         if ((tx != null) && !tx.wasCommitted() && !tx.wasRolledBack()) {
            tx.commit();
         }

         threadTransaction.set(null);
      } catch (HibernateException ex) {
         rollbackTransaction();
         throw new SystemException(ex, "");
      }
   }

   /**
    * Commit the database transaction.
    */
   public static void rollbackTransaction() throws SystemException {
      Transaction tx = (Transaction) threadTransaction.get();

      try {
         threadTransaction.set(null);

         if ((tx != null) && !tx.wasCommitted() && !tx.wasRolledBack()) {
            tx.rollback();
         }
      } catch (HibernateException ex) {
         throw new SystemException(ex, "");
      } finally {
         closeSession();
      }
   }

   //    /**
   //     * 
   //     */
   //    public static void dropAndCreateTables() throws HibernateException
   //    {
   //        SchemaExport ddlExport = new SchemaExport(HibernateUtils.getConfiguration());
   //        // script - print the DDL to the console , export - export the script to the database
   //        ddlExport.drop(true, true);
   //        ddlExport.create(true, true);        
   //    }

   //	Session session = HibernateUtils.getSessionFactory().openSession();
   //  Connection connection = session.connection();
   //  
   //  try {
   //  	CallableStatement callableStatement = connection.prepareCall("{call dropAndCreateTables}");
   //  	callableStatement.execute();		
   //	} catch (SQLException e) {
   //		throw new RuntimeException(e); 
   //	}
   //	finally
   //	{
   //		session.close();
   //	}

   //    /**
   //     * 
   //     */
   //    public static void createOrUpdateDatabase() throws HibernateException
   //    {
   //        SchemaUpdate ddlUpdate = new SchemaUpdate(HibernateUtils.getConfiguration());
   //        // boolean script, boolean doUpdate
   //        ddlUpdate.execute(true, true);
   //        
   //    }
}
