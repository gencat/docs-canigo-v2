/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.fixtures;

import java.io.IOException;

import java.sql.SQLException;

import javax.sql.DataSource;

import junit.framework.Assert;
import junit.framework.TestFailure;

import net.gencat.ctti.canigo.core.util.tests.SQLScript;
import net.gencat.ctti.canigo.services.security.acegi.fixtures.DatabaseFixture;

import oracle.jdbc.OracleDriver;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;


/**
 * Singleton which provides a populated database connection for all JDBC-related
 * unit tests.
 *
 */
public class OracleDatabaseFixture extends DatabaseFixture {
   // ~ Static fields/initializers
   /**
    * Creates a new OracleDatabaseFixture object.
    */
   private OracleDatabaseFixture() {
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public static DataSource getDataSource() {
      if (dataSource == null) {
         try {
            setupDataSource();
         } catch (SQLException e) {
            Assert.fail(e.getMessage());
         } catch (IOException e) {
            Assert.fail(e.getMessage());
         }
      }

      return dataSource;
   }

   // ~ Methods
   /**
    * Documentaci�.
    *
    * @throws SQLException Documentaci�
    * @throws IOException Documentaci�
    */
   protected static void setupDataSource() throws SQLException, IOException {
      // Create a connection to the database
      String url = "jdbc:oracle:thin:@bna-s007.es.int.atosorigin.com:1521:Legolas";
      String user = "openframe";
      String password = "openframe";

      dataSource = new DriverManagerDataSource(OracleDriver.class.getName(),
            url, user, password);

      SQLScript script = new SQLScript(dataSource,
            "sql/insert-security-testdata.sql");

      //script.execute();
   }

   // TODO Aaaaaaaaaaaahhhhhhhhhhhhh ! Change this code to something meaningfull and logic ...
   /**
    * Documentaci�.
    */
   public static void init() {
      getDataSource();
   }
}
