/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.tests.mock;

import org.jmock.core.matcher.InvokeOnceMatcher;
import org.jmock.core.matcher.MethodNameMatcher;
import org.jmock.core.stub.ReturnStub;
import org.jmock.core.stub.VoidStub;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public abstract class AbstractMockObject {
   /**
    *
    */
   private org.jmock.Mock mockObjectFromInterface;

   /**
    * @param mockedInterfaceOrClass
    */
   protected AbstractMockObject(Class mockedInterfaceOrClass) {
      if (mockedInterfaceOrClass.isInterface()) {
         this.mockObjectFromInterface = new org.jmock.Mock(mockedInterfaceOrClass);
      } else {
         this.mockObjectFromInterface = new org.jmock.cglib.Mock(mockedInterfaceOrClass);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public final Object proxy() {
      return mockObjectFromInterface.proxy();
   }

   /**
    * @todo This method name does not mean anything !!!! REFACTOR
    * @return
    * org.jmock.Mock
    */
   public org.jmock.Mock getJMockConcreteImpl() {
      return this.mockObjectFromInterface;
   }

   /**
    * Assert at the end of a unit test that the correct behaviour has occurred.
    */
   public final void verifyCorrectBehaviourOccurred() {
      this.mockObjectFromInterface.verify();
   }

   /**
    * @param methodName
    * void
    */
   public AbstractMockObject expectsThisMethodToBeCalled(String methodName,
      Object expectedResult) {
      this.getJMockConcreteImpl().expects(new InvokeOnceMatcher())
          .match(new MethodNameMatcher(methodName))
          .will(new ReturnStub(expectedResult));

      return this;
   }

   /**
    * Documentaci�.
    *
    * @param methodName Documentaci�
    *
    * @return Documentaci�
    */
   public AbstractMockObject expectsThisMethodToBeCalled(String methodName) {
      this.getJMockConcreteImpl().expects(new InvokeOnceMatcher())
          .match(new MethodNameMatcher(methodName)).will(new VoidStub());

      return this;
   }
}
