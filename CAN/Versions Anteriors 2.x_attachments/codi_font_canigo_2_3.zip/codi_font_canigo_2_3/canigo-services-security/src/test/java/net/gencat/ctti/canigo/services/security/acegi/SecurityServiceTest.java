/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.security.SecurityService;
import net.gencat.ctti.canigo.services.security.acegi.SecurityServiceAcegiImpl;
import net.sf.acegisecurity.AcegiSecurityException;
import net.sf.acegisecurity.Authentication;
import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.GrantedAuthorityImpl;
import net.sf.acegisecurity.UserDetails;
import net.sf.acegisecurity.context.SecurityContextHolder;
import net.sf.acegisecurity.context.SecurityContext;
import net.sf.acegisecurity.context.SecurityContextImpl;
import net.sf.acegisecurity.providers.TestingAuthenticationToken;
import net.sf.acegisecurity.providers.UsernamePasswordAuthenticationToken;
import net.sf.acegisecurity.providers.dao.User;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class SecurityServiceTest extends TestCase {
   /**
    * Documentaci�.
    */
   private static final String USER_NAME = "UserNameTest";

   /**
    * Documentaci�.
    */
   private static final String EXPECTED_ROLE = "ROLE_USER";

   /**
    * Documentaci�.
    */
   protected SecurityService securityService;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void setUp() throws Exception {
      this.securityService = new SecurityServiceAcegiImpl();
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void tearDown() throws Exception {
      SecurityContextHolder.setContext(null);
   }

   /**
    * Documentaci�.
    */
   protected void setupAcegiContext() {
      GrantedAuthority[] authorities = new GrantedAuthority[] {
            new GrantedAuthorityImpl(EXPECTED_ROLE)
         };
      User user = new User(USER_NAME, "password", true, authorities);

      Authentication authentication = new UsernamePasswordAuthenticationToken(user,
            "credentials", authorities);

      authentication.setAuthenticated(true);

      // Commit the successful Authentication object to the secure
      SecurityContextHolder.setContext(new SecurityContextImpl());

      SecurityContext secureContext = (SecurityContext) SecurityContextHolder.getContext();
      secureContext.setAuthentication(authentication);
      SecurityContextHolder.setContext(secureContext);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testIsAuthenticated() throws Exception {
      assertFalse(this.securityService.isUserAuthenticated());

      setupAcegiContext();

      assertTrue(this.securityService.isUserAuthenticated());
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testGetUser() throws Exception {
      setupAcegiContext();
      assertEquals(USER_NAME, this.securityService.getUserLogin().getUserName());
   }

   /**
    * Documentaci�.
    */
   public void testIsUserInRole() {
      try {
         this.securityService.isUserInRole("");
         fail("should have thrown an excption, empty string not valid");
      } catch (IllegalArgumentException expected) {
         assertTrue(true);
      }

      try {
         this.securityService.isUserInRole(null);
         fail("should have thrown an excption, null not valid");
      } catch (IllegalArgumentException expected) {
         assertTrue(true);
      }

      // TODO Should we test the failure when the role does not exist?
      setupAcegiContext();

      assertFalse(this.securityService.isUserInRole("nono"));
      assertTrue(this.securityService.isUserInRole(EXPECTED_ROLE));
   }

   //    public void testHasUserReadPermission() {
   //        fail();
   //    }
}
