/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi;

import java.util.List;
import java.util.Vector;

import net.gencat.ctti.canigo.services.security.acegi.afterinvocation.ValueListFilteringProvider;
import net.gencat.ctti.canigo.services.security.acegi.persistence.ACLsDAO;
import net.gencat.ctti.canigo.services.security.acegi.testcases.AcegiWithinSpringTestCase;
import net.gencat.ctti.canigo.services.security.business.BusinessService;
import net.gencat.ctti.canigo.services.security.business.DomainObject;
import net.gencat.ctti.canigo.services.security.business.DomainObjectWithoutACLs;
import net.gencat.ctti.canigo.services.security.persistence.DomainObjectDAO;
import net.gencat.ctti.canigo.services.tests.mock.aop.MockMethodInvocation;
import net.mlw.vlh.DefaultListBackedValueList;
import net.mlw.vlh.ValueList;
import net.sf.acegisecurity.AccessDeniedException;
import net.sf.acegisecurity.ConfigAttributeDefinition;
import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.GrantedAuthorityImpl;
import net.sf.acegisecurity.SecurityConfig;
import net.sf.acegisecurity.acl.basic.NamedEntityObjectIdentity;
import net.sf.acegisecurity.acl.basic.jdbc.JdbcExtendedDaoImpl;
import net.sf.acegisecurity.afterinvocation.BasicAclEntryAfterInvocationCollectionFilteringProvider;
import net.sf.acegisecurity.afterinvocation.BasicAclEntryAfterInvocationProvider;
import net.sf.acegisecurity.context.SecurityContextHolder;
import net.sf.acegisecurity.context.SecurityContext;
import net.sf.acegisecurity.providers.ProviderManager;
import net.sf.acegisecurity.providers.TestingAuthenticationToken;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class ACLsTest extends AcegiWithinSpringTestCase {
   // canigo objects
   /**
    * Documentaci�.
    */
   protected ACLsDAO securityDao;

   /**
    * Documentaci�.
    */
   protected BasicAclEntryAfterInvocationProvider afterAclRead;

   /**
    * Documentaci�.
    */
   protected BusinessService businessService;

   /**
    * Documentaci�.
    */
   protected DomainObject domainObjectWITHOUTReadPermission;

   /**
    * Documentaci�.
    */
   protected DomainObject domainObjectWithReadPermission;

   // Dummy objects used by tests
   /**
    * Documentaci�.
    */
   protected DomainObjectDAO domainObjectDAO;

   /**
    * Documentaci�.
    */
   protected JdbcExtendedDaoImpl basicAclExtendedDao;

   // Acegi Objects
   /**
    * Documentaci�.
    */
   protected ProviderManager authenticationManager;

   /**
    * Documentaci�.
    */
   protected ValueListFilteringProvider afterAclCollectionRead;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void onSetUp() throws Exception {
      setUpDatabaseData();

      // Simulate an Authentication as admin: ???? Use Mock Objects
      this.authentication = new TestingAuthenticationToken(this.principalAdminUser,
            "NO CREDENTIALS USED",
            new GrantedAuthority[] { new GrantedAuthorityImpl("ROLE_ADMIN") });
      authentication.setAuthenticated(true);

      setupAcegiContext();
   }

   /**
    * Documentaci�.
    */
   protected void setUpDatabaseData() {
      // Insert DomainObject in the Database and retrieve it
      this.domainObjectWithReadPermission = new DomainObject(new Integer(1),
            "domainObjectWithReadPermission");

      if (this.domainObjectDAO.getById(
               this.domainObjectWithReadPermission.getId()) == null) {
         this.domainObjectDAO.create(this.domainObjectWithReadPermission);
         this.securityDao.addReadPermissionForUser(this.principalAdminUser,
            this.domainObjectWithReadPermission);
      }

      this.domainObjectWITHOUTReadPermission = new DomainObject(new Integer(2),
            "domainObjectWITHOUTReadPermission");

      if (this.domainObjectDAO.getById(
               this.domainObjectWITHOUTReadPermission.getId()) == null) {
         this.domainObjectDAO.create(this.domainObjectWITHOUTReadPermission);
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testACLsFor1InstanceWithReadPermission()
      throws Exception {
      // Check that some ACLS have been definxed for the
      // domainObjectWithReadPermission
      assertTrue(this.basicAclExtendedDao.getAcls(
            new NamedEntityObjectIdentity(this.domainObjectWithReadPermission)).length > 0);

      assertEquals(this.principalAdminUser,
         ((SecurityContext) SecurityContextHolder.getContext()).getAuthentication()
          .getPrincipal());

      // Should not through an exception
      afterInvocationThroughAOP(this.domainObjectWithReadPermission);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testACLsFor1InstanceAccessDeniedException()
      throws Exception {
      try {
         afterInvocationThroughAOP(this.domainObjectWITHOUTReadPermission);
         fail("Should have thrown AccessDeniedException");
      } catch (AccessDeniedException expected) {
         assertTrue(true);
      }
   }

   /**
    * Documentaci�.
    *
    * @param domainObject Documentaci�
    */
   private void afterInvocationThroughAOP(Object domainObject) {
      ConfigAttributeDefinition attr = new ConfigAttributeDefinition();
      String configAttributeString = this.afterAclRead.getProcessConfigAttribute();
      attr.addConfigAttribute(new SecurityConfig(configAttributeString));

      this.afterAclRead.decide(this.authentication, new MockMethodInvocation(),
         attr, domainObject);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected ValueList initFixtureValueList() {
      // Create a Collection containing many items
      List list = new Vector();
      list.add(this.domainObjectWITHOUTReadPermission);
      list.add(this.domainObjectWithReadPermission);

      ValueList valueList = new DefaultListBackedValueList(list);

      return valueList;
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testACLsFilteringCollection() throws Exception {
      ValueList valueList = initFixtureValueList();

      // Apply the collection_read filter
      ConfigAttributeDefinition attr = new ConfigAttributeDefinition();
      attr.addConfigAttribute(new SecurityConfig("AFTER_ACL_COLLECTION_READ"));

      // Add the class DomainObject to the configuration
      this.afterAclCollectionRead.addFilterForBusinessClass(DomainObject.class);

      List filteredList = ((ValueList) this.afterAclCollectionRead.decide(this.authentication,
            new MockMethodInvocation(), attr, valueList)).getList();

      // There should be only 1 element in the filtered list:
      assertEquals(1, filteredList.size());
      assertEquals(this.domainObjectWithReadPermission, filteredList.get(0));
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testBugACLsForCollectionAllBusinessInstanceShouldBeAccessibleByDefault()
      throws Exception {
      DomainObjectWithoutACLs domainObjectWithoutAclsSpecified = new DomainObjectWithoutACLs(new Integer(
               1), "1");
      List list = new Vector();
      list.add(domainObjectWithoutAclsSpecified);

      ValueList valueList = new DefaultListBackedValueList(list);

      // Apply the collection_read filter
      ConfigAttributeDefinition attr = new ConfigAttributeDefinition();
      attr.addConfigAttribute(new SecurityConfig("AFTER_ACL_COLLECTION_READ"));

      List filteredList = ((ValueList) this.afterAclCollectionRead.decide(this.authentication,
            new MockMethodInvocation(), attr, valueList)).getList();

      // The elemeent should still be there because there are no ACLs defined for the class DomainObjectWithoutACLs
      assertEquals(1, filteredList.size());
      assertEquals(domainObjectWithoutAclsSpecified, filteredList.get(0));
   }
}
