/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import java.util.List;

import javax.sql.DataSource;

import net.gencat.ctti.canigo.services.security.business.DomainObject;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.jdbc.object.SqlUpdate;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class DomainObjectDAO extends JdbcDaoSupport {
   /**
    * Documentaci�.
    */
   private ByIdQuery byIdQuery;

   /**
    * Documentaci�.
    */
   private Insert insert;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void initDao() throws Exception {
      this.insert = new Insert(getDataSource());
      this.byIdQuery = new ByIdQuery(getDataSource());
   }

   /**
    * Documentaci�.
    *
    * @param object Documentaci�
    */
   public void create(DomainObject object) {
      this.insert.insert(object);
   }

   /**
    * Documentaci�.
    *
    * @param id Documentaci�
    *
    * @return Documentaci�
    */
   public DomainObject getById(Integer id) {
      List list = byIdQuery.execute(id.intValue());

      if (list.size() == 0) {
         return null;
      } else {
         return (DomainObject) list.get(0);
      }
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   protected class ByIdQuery extends MappingSqlQuery {
      /**
       * Creates a new ByIdQuery object.
       *
       * @param ds DOCUMENT ME.
       */
      protected ByIdQuery(DataSource ds) {
         super(ds,
            "SELECT id, description FROM domain_object WHERE id = ? ORDER BY id");
         declareParameter(new SqlParameter(Types.INTEGER));
         compile();
      }

      /**
       * Documentaci�.
       *
       * @param rs Documentaci�
       * @param rownum Documentaci�
       *
       * @return Documentaci�
       *
       * @throws SQLException Documentaci�
       */
      protected Object mapRow(ResultSet rs, int rownum)
         throws SQLException {
         DomainObject contact = new DomainObject();
         contact.setId(new Integer(rs.getInt("id")));
         contact.setDescription(rs.getString("description"));

         return contact;
      }
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   protected class Insert extends SqlUpdate {
      /**
       * Creates a new Insert object.
       *
       * @param ds DOCUMENT ME.
       */
      protected Insert(DataSource ds) {
         super(ds, "INSERT INTO domain_object VALUES (?, ?)");
         declareParameter(new SqlParameter(Types.INTEGER));
         declareParameter(new SqlParameter(Types.VARCHAR));
         compile();
      }

      /**
       * Documentaci�.
       *
       * @param object Documentaci�
       */
      protected void insert(DomainObject object) {
         Object[] objs = new Object[] { object.getId(), object.getDescription() };
         super.update(objs);
      }
   }
}
