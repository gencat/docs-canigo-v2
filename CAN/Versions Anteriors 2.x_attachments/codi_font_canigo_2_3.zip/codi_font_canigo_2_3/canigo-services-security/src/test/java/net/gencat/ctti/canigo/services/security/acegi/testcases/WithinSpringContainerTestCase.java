/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.testcases;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.AbstractDependencyInjectionSpringContextTests;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public abstract class WithinSpringContainerTestCase
   extends AbstractDependencyInjectionSpringContextTests {
   /**
    * Documentaci�.
    */
   protected static ClassPathXmlApplicationContext applicationContext;

   //    protected static void runOnlyOnceSetup(String applicationContextFile, WithinSpringContainerTestCase testCase) {
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected abstract String getConfigLocationFromClassPath();

   // The default in parent�s class is false!!!
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected String[] getConfigLocations() {
      return new String[] { "classpath:" + getConfigLocationFromClassPath() };
   }

   //    protected static void initDependencies(TestCase testCase) {
   //        
   //        Field[] fields = testCase.getClass().getFields();
   //        
   //        for (int i = 0; i < fields.length; i++) {
   //        
   //            Field field = fields[i];
   //            
   //            int modifiers = field.getModifiers();
   //            
   //            if (!Modifier.isStatic(modifiers)) {
   //                String fieldName = field.getName();
   //                try {
   //                    Object bean = applicationContext.getBean(fieldName);
   //                    field.set(testCase, bean);
   //                } catch (Exception e) {
   //                    e.printStackTrace();
   //                    fail("There is no bean " + fieldName + " in your application context " + applicationContext.getDisplayName()
   //                            + "\n The fiels of your unit test class should match the application context beans names ...");
   //                }
   //            }
   //        }
   //    }
}
