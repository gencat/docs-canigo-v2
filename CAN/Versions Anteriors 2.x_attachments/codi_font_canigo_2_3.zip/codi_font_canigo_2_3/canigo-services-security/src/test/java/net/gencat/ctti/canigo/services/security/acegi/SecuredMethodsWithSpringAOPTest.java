/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi;

import java.util.ArrayList;
import java.util.List;

import net.gencat.ctti.canigo.services.security.acegi.testcases.AcegiWithinSpringTestCase;
import net.gencat.ctti.canigo.services.security.business.BusinessService;
import net.sf.acegisecurity.AccessDeniedException;
import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.GrantedAuthorityImpl;
import net.sf.acegisecurity.providers.ProviderManager;
import net.sf.acegisecurity.providers.TestingAuthenticationProvider;
import net.sf.acegisecurity.providers.TestingAuthenticationToken;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class SecuredMethodsWithSpringAOPTest extends AcegiWithinSpringTestCase {
   /**
    * Documentaci�.
    */
   protected BusinessService businessService;

   /**
    * Documentaci�.
    */
   protected ProviderManager authenticationManager;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void onSetUp() throws Exception {
      // Just for testing, use TestingAuthenticationProvider which simply accepts as valid whatever is contained
      // within the TestingAuthenticationToken.
      List testingProviderList = new ArrayList();
      testingProviderList.add(new TestingAuthenticationProvider());
      this.authenticationManager.setProviders(testingProviderList);

      //  Simulate an Authentication as admin: ???? Use Mock Objects
      this.authentication = new TestingAuthenticationToken(this.principalAdminUser,
            "NO CREDENTIALS USED",
            new GrantedAuthority[] { new GrantedAuthorityImpl("ROLE_USER") });
      authentication.setAuthenticated(true);

      setupAcegiContext();
   }

   /**
    * Documentaci�.
    */
   public void testACLsWhenUserHasPermissionToExecuteMethod() {
      this.businessService.read();
   }

   /**
    * Documentaci�.
    */
   public void testACLsWhenUserHasAccessDeniedToExecuteMethod() {
      try {
         this.businessService.delete();
         fail("Should have thrown an exception!");
      } catch (AccessDeniedException expected) {
         assertTrue(true);
      }
   }
}
