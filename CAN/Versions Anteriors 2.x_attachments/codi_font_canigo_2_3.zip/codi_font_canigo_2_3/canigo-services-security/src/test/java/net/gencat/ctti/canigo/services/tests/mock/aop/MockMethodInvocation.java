/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.tests.mock.aop;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Method;

import org.aopalliance.intercept.MethodInvocation;


/**
 * Represents the AOP Alliance <code>MethodInvocation</code> secure object.
 *
 * @author Ben Alex
 * @version $Id: MockMethodInvocation.java,v 1.4 2007/07/16 08:43:59 msabates Exp $
 */
public class MockMethodInvocation implements MethodInvocation {
   /**
    * Documentaci�.
    */
   private Method method;

   /**
    * Documentaci�.
    */
   private Object[] arguments;

   /**
    * Creates a new MockMethodInvocation object.
    *
    * @param method DOCUMENT ME.
    */
   public MockMethodInvocation(Method method) {
      this.method = method;
      this.arguments = arguments;
   }

   /**
    * Creates a new MockMethodInvocation object.
    */
   public MockMethodInvocation() {
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object[] getArguments() {
      return arguments;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Method getMethod() {
      return method;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public AccessibleObject getStaticPart() {
      throw new UnsupportedOperationException("mock method not implemented");
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getThis() {
      throw new UnsupportedOperationException("mock method not implemented");
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws Throwable Documentaci�
    */
   public Object proceed() throws Throwable {
      //        throw new UnsupportedOperationException("mock method not implemented");
      return null;
   }
}
