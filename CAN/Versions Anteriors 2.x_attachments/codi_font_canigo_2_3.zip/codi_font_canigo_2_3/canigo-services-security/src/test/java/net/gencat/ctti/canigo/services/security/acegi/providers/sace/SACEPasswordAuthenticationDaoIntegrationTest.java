/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers.sace;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.core.util.tests.TestsHelper;
import net.gencat.ctti.canigo.services.security.acegi.providers.dao.AuthoritiesDAO;
import net.gencat.ctti.canigo.services.security.acegi.providers.sace.enums.SACEUserNameFormatEnum;
import net.gencat.ctti.canigo.services.security.fixtures.SecurityServiceTestScenariosFixtures;
import net.gencat.ctti.canigo.services.security.fixtures.SecurityTestScenario;
import net.sf.acegisecurity.AcegiSecurityException;
import net.sf.acegisecurity.AuthenticationServiceException;
import net.sf.acegisecurity.DisabledException;
import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.LockedException;
import net.sf.acegisecurity.UserDetails;
import net.sf.acegisecurity.providers.dao.UsernameNotFoundException;

import org.custommonkey.xmlunit.XMLAssert;
import org.custommonkey.xmlunit.XMLUnit;
import org.xml.sax.SAXException;


/**
 * Project: canigo<br>
 * ClassName:
 * net.gencat.ctti.canigo.services.security.acegi.providers.SACEPasswordAuthenticationDaoIntegrationTest.java<br>
 * Description: <br>
 * Copyright: Copyright (c) 2005<br>
 * Company: ctti<br>
 * Date: 04/01/2006<br>
 *
 * For all the users, the passwords are the same as the user names. Directori
 * Corporatiu de la Generalitat de Catalunya, Guia d�integraci� d�aplicacions
 * v3.7 4.4.1.1 Enviament i retorn de par�metres p.31
 *
 * Codi Descripci� 0 L'operaci� ha finalitzat correctament 1 El fitxer XML rebut
 * esta mal format. No es pot llegir 2 El node 'XMLSace/Entrada/CodiOperacio' no
 * existeix 3 El valor del node 'XMLSace/Entrada/CodiOperacio' no es un num�ric
 * 4 El valor del node 'XMLSace/Entrada/CodiOperacio' ha d'estar entre els
 * valors 1 i 5 5 El node 'XMLSace/Entrada/CodiIntern' no existeix 6 El node
 * 'XMLSace/Entrada/Password' no existeix 7 El node 'XMLSace/Entrada/NIF' no
 * existeix 8 El node 'XMLSace/Entrada/NovaPassword' no existeix 9 El Nif esta
 * duplicat 10 El NIF no existeix 11 L'usuari i/o pasword gen�ric de
 * configuraci� del Frontal IIS es incorrecte 12 No es pot connectar amb el
 * servidor de Directori 13 El Codi Intern no existeix 14 La paraula de pas es
 * incorrecta 15 Aquesta plana nom�s es pot cridar pel m�tode POST 16 El format
 * de la paraula de pas no compleix la policy del Directori 17 L'usuari existeix
 * per� esta desactivat
 *
 * - 18 L'usuari existeix per� esta bloquejat
 * - 19 L'usuari existeix per� t� la paraula de pas expirada 20 El camp CodiIntern no esta
 * informat 21 El camp NIF no esta informat 22 No tenim privilegis per crear
 * EventSources 23 Aquest usuari �s troba en situaci� administrativa d'INACTIU
 * dins el sistema d'informaci� del SIP 24 Aquest usuari es troba en estat de
 * transferibilitat al directori corporatiu.
 *
 *
 * @author jean-michel.garnier@ctti.net
 * @version 1.0
 */
public class SACEPasswordAuthenticationDaoIntegrationTest extends TestCase {
   // Tested object
   /**
    * Documentaci�.
    */
   protected SACEPasswordAuthenticationDao sacePasswordAuthenticationDao;

   /**
    * Documentaci�.
    */
   protected SaceTestUserVO disabledUser_InternalCodeMode;

   /**
    * Documentaci�.
    */
   protected SaceTestUserVO invalidUser_InternalCodeMode;

   /**
    * Documentaci�.
    */
   protected SaceTestUserVO lockedUser_InternalCodeMode;

   // --- Test data
   /**
    * Documentaci�.
    */
   protected SaceTestUserVO validUser_InternalCodeMode;

   /**
    * Documentaci�.
    */
   protected SaceTestUserVO validUser_NIFMode;

   //    protected SaceTestUserVO invalidUser_NIFMode;
   /**
    * Documentaci�.
    */
   protected SecurityTestScenario testScenario;

   // --- Test set up
   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void setUp() throws Exception {
      this.sacePasswordAuthenticationDao = new SACEPasswordAuthenticationDao();
      //this.sacePasswordAuthenticationDao = new SACEPasswordAuthenticationDaoExtension();
      this.sacePasswordAuthenticationDao.setSACEHostName(
         "https://sace.prepdc.gencat.intranet/SACE/SACE_Logon.aspx?XMLIn=");

      // AuthoritiesJdbcImplDAO
      this.testScenario = SecurityServiceTestScenariosFixtures.getSaceScenario();

      AuthoritiesDAO mockAuthoritiesDAO = testScenario.getMockAuthoritiesDAO();
      this.sacePasswordAuthenticationDao.setAuthoritiesDAO(mockAuthoritiesDAO);

      /******************** Codi Intern Users *******************/
      // 0 L'operaci� ha finalitzat correctament
      this.validUser_InternalCodeMode = new SaceTestUserVO("USER_PROVES1",
            "USER_PROVES1");

      // 13 El Codi Intern no existeix
      this.invalidUser_InternalCodeMode = new SaceTestUserVO("ZZZZZUser",
            "ZZZZZPassword");

      // 17 L'usuari existeix per� esta desactivat
      this.disabledUser_InternalCodeMode = new SaceTestUserVO("USER_PROVES2",
            "USER_PROVES2");

      // 18 L'usuari existeix per� esta bloquejat
      this.lockedUser_InternalCodeMode = new SaceTestUserVO("USER_PROVES3",
            "USER_PROVES3");

      /******************** NIF Users *******************/
      //      0 L'operaci� ha finalitzat correctament
      this.validUser_NIFMode = new SaceTestUserVO("46238600K", "USER_PROVES1");
   }

   // --- Tests
   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testParameters() throws Exception {
      try {
         this.sacePasswordAuthenticationDao.setSACEHostName(
            "dfxhdsthh not an url");
         fail("should have thrown an exception!");
      } catch (AuthenticationServiceException expected) {
         assertTrue(true);
      }

      runTestAuthenticationFailure(new SaceTestUserVO(null, null),
         AuthenticationServiceException.class);
      runTestAuthenticationFailure(new SaceTestUserVO(null, "aaa"),
         AuthenticationServiceException.class);
      runTestAuthenticationFailure(new SaceTestUserVO("bbb", null),
         AuthenticationServiceException.class);
   }

   /**
    * Documentaci�.
    *
    * @throws IOException Documentaci�
    * @throws SAXException Documentaci�
    * @throws ParserConfigurationException Documentaci�
    */
   public void testSACEXmlInputString()
      throws IOException, SAXException, ParserConfigurationException {
      // VIP to avoid many headaches and looking for hours for invisible white spaces ...
      XMLUnit.setIgnoreWhitespace(true);

      String expectedXml = TestsHelper.getTestResource("xml/sace.xml");

      // Password composed of the 5 Illegal Characters in XML 
      String password = "<>&'" + "\"";
      SACEXMLConverter converter = new SACEXMLConverter();
      SACEInputQueryVO input = new SACEInputQueryVO(SACEUserNameFormatEnum.INTERNAL_CODE,
            "UserCode", password);
      String xmlTest = converter.toXML(input);

      XMLAssert.assertXMLEqual(xmlTest, expectedXml, xmlTest);
   }

   /**
    * Test that authentication request could not be processed due to a
    * simulated system problem. This might be thrown if a backend
    * authentication repository is unavailable.
    */
   public void testAuthenticationFailure_AuthenticationServiceException() {
      this.sacePasswordAuthenticationDao.setSACEHostName("https://urlInvalid");
      runTestAuthenticationFailure(new SaceTestUserVO("An user", "A password"),
         AuthenticationServiceException.class);
   }

   /** Test that an user whose account is disabled fails. */
   public void testAuthenticationFailure_DisabledException() {
      this.sacePasswordAuthenticationDao.setUserNameFormatEnum(SACEUserNameFormatEnum.INTERNAL_CODE);
      runTestAuthenticationFailure(this.disabledUser_InternalCodeMode,
         DisabledException.class);
   }

   /** Test that an user whose account is locked fails. */
   public void testAuthenticationFailure_LockedException() {
      this.sacePasswordAuthenticationDao.setUserNameFormatEnum(SACEUserNameFormatEnum.INTERNAL_CODE);
      runTestAuthenticationFailure(this.lockedUser_InternalCodeMode,
         LockedException.class);
   }

   /** Test that a login w/ a bad user name fails. */
   public void testAuthenticationFailure_UsernameNotFoundException() {
      this.sacePasswordAuthenticationDao.setUserNameFormatEnum(SACEUserNameFormatEnum.INTERNAL_CODE);
      runTestAuthenticationFailure(this.invalidUser_InternalCodeMode,
         UsernameNotFoundException.class);
   }

   /** Test that a w/ bad login and password fails. Commented because it was locking the user in the SACE system
    * after 3 failed attempts */

   //    public void testAuthenticationFailure_BadCredentialsException() {
   //        this.sacePasswordAuthenticationDao.setUserNameFormatEnum(SACEUserNameFormatEnum.INTERNAL_CODE);
   //        runTestAuthenticationFailure(new SaceTestUserVO(this.validUser_InternalCodeMode.getUser(),
   //                "incorrectPassword"), BadCredentialsException.class);
   //    }

   // --- Authentication Sucess Tests

   /**
    * Test that a login w/ a correct user name and password pass.
    */
   public void testAuthenticationSucess_InternalCode() {
      this.sacePasswordAuthenticationDao.setUserNameFormatEnum(SACEUserNameFormatEnum.INTERNAL_CODE);

      UserDetails userDetail = sacePasswordAuthenticationDao.loadUserByUsernameAndPassword(this.validUser_InternalCodeMode.getUser(),
            this.validUser_InternalCodeMode.getPassword());
      runTestAuthenticationSuccess(userDetail);
   }

   /**
    * Documentaci�.
    */
   public void testAuthenticationSucess_NIF() {
      this.sacePasswordAuthenticationDao.setUserNameFormatEnum(SACEUserNameFormatEnum.NIF);

      UserDetails userDetail = sacePasswordAuthenticationDao.loadUserByUsernameAndPassword(this.validUser_NIFMode.getUser(),
            this.validUser_NIFMode.getPassword());
      runTestAuthenticationSuccess(userDetail);
   }

   // --- Utilities methods and classes (DRY, don't repeat yourself)

   /**
    * The test will fail if the exception has not been thrown as we expected it
    *
    * @param SaceTestUserVO
    * @param expectedAcegiException
    */
   protected void runTestAuthenticationFailure(SaceTestUserVO testDataVO,
      Class expectedAcegiException) {
      try {
         sacePasswordAuthenticationDao.loadUserByUsernameAndPassword(testDataVO.getUser(),
            testDataVO.getPassword());

         // The test will fail if an exception has not been thrown as we
         // expected it
         super.fail("Should have thrown a subclass of AcegiSecurityException");
      } catch (AcegiSecurityException expected) {
         // Check that the exception thrown is an instance of the class we
         // expect
         super.assertTrue(expected.getClass().equals(expectedAcegiException));
      }
   }

   /**
    * Documentaci�.
    *
    * @param userDetail Documentaci�
    */
   private void runTestAuthenticationSuccess(UserDetails userDetail) {
      assertNotNull(userDetail.getUsername());
      assertNotNull(userDetail.getPassword());

      GrantedAuthority[] authorities = userDetail.getAuthorities();

      assertEquals(testScenario.getUserLogin().getAllRoles().size(),
         authorities.length);
      assertFalse(authorities[0].getAuthority().equals(""));
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   class SaceTestUserVO {
      /**
       * Documentaci�.
       */
      private String password;

      /**
       * Documentaci�.
       */
      private String user;

      /**
       * Creates a new SaceTestUserVO object.
       *
       * @param user DOCUMENT ME.
       * @param password DOCUMENT ME.
       */
      public SaceTestUserVO(String user, String password) {
         this.user = user;
         this.password = password;
      }

      // Internal UserLogin name (Codi Intern) or UserLogin id (NIF)
      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getUser() {
         return this.user;
      }

      // In all test data, password is same as user name
      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getPassword() {
         return this.password;
      }
   }
}
