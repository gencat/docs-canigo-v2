/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import net.gencat.ctti.canigo.services.security.acegi.persistence.ACLsDAO;
import net.gencat.ctti.canigo.services.security.acegi.testcases.AcegiWithinSpringTestCase;
import net.gencat.ctti.canigo.services.security.business.BusinessService;
import net.gencat.ctti.canigo.services.security.business.DomainObject;
import net.gencat.ctti.canigo.services.security.persistence.DomainObjectDAO;
import net.mlw.vlh.DefaultListBackedValueList;
import net.mlw.vlh.ValueList;
import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.GrantedAuthorityImpl;
import net.sf.acegisecurity.acl.basic.jdbc.JdbcExtendedDaoImpl;
import net.sf.acegisecurity.afterinvocation.BasicAclEntryAfterInvocationCollectionFilteringProvider;
import net.sf.acegisecurity.afterinvocation.BasicAclEntryAfterInvocationProvider;
import net.sf.acegisecurity.providers.ProviderManager;
import net.sf.acegisecurity.providers.TestingAuthenticationProvider;
import net.sf.acegisecurity.providers.TestingAuthenticationToken;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class ACLsWithAOPSpringTest extends AcegiWithinSpringTestCase {
   // canigo objects
   /**
    * Documentaci�.
    */
   protected ACLsDAO securityDao;

   /**
    * Documentaci�.
    */
   protected BasicAclEntryAfterInvocationCollectionFilteringProvider afterAclCollectionRead;

   /**
    * Documentaci�.
    */
   protected BasicAclEntryAfterInvocationProvider afterAclRead;

   /**
    * Documentaci�.
    */
   protected BusinessService businessService;

   /**
    * Documentaci�.
    */
   protected DomainObject domainObjectWITHOUTReadPermission;

   /**
    * Documentaci�.
    */
   protected DomainObject domainObjectWithReadPermission;

   // Dummy objects used by tests
   /**
    * Documentaci�.
    */
   protected DomainObjectDAO domainObjectDAO;

   /**
    * Documentaci�.
    */
   protected JdbcExtendedDaoImpl basicAclExtendedDao;

   // Acegi Objects
   /**
    * Documentaci�.
    */
   protected ProviderManager authenticationManager;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void onSetUp() throws Exception {
      setUpDatabaseData();

      //      Just for testing, use TestingAuthenticationProvider which simply
      // accepts as valid whatever is contained
      // within the TestingAuthenticationToken.
      List testingProviderList = new ArrayList();
      testingProviderList.add(new TestingAuthenticationProvider());
      this.authenticationManager.setProviders(testingProviderList);

      // Simulate an Authentication as ROLE_USER
      this.authentication = new TestingAuthenticationToken(this.principalAdminUser,
            "NO CREDENTIALS USED",
            new GrantedAuthority[] { new GrantedAuthorityImpl("ROLE_USER") });

      super.setupAcegiContext();
   }

   /**
    * Documentaci�.
    */
   protected void setUpDatabaseData() {
      // Insert DomainObject in the Database and retrieve it
      this.domainObjectWithReadPermission = new DomainObject(new Integer(1),
            "domainObjectWithReadPermission");

      if (this.domainObjectDAO.getById(
               this.domainObjectWithReadPermission.getId()) == null) {
         this.domainObjectDAO.create(this.domainObjectWithReadPermission);
         this.securityDao.addReadPermissionForUser(this.principalAdminUser,
            this.domainObjectWithReadPermission);
      }

      this.domainObjectWITHOUTReadPermission = new DomainObject(new Integer(2),
            "domainObjectWITHOUTReadPermission");

      if (this.domainObjectDAO.getById(
               this.domainObjectWITHOUTReadPermission.getId()) == null) {
         this.domainObjectDAO.create(this.domainObjectWITHOUTReadPermission);
      }
   }

   // @todo a bit a complex to understand, should I move this method to a separate class    
   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testACLsForCollectionIntegrationTestWithAOP()
      throws Exception {
      List list = new Vector();
      list.add(this.domainObjectWITHOUTReadPermission);
      list.add(this.domainObjectWithReadPermission);

      ValueList valueList = new DefaultListBackedValueList(list);

      // Apply the collection_read filter
      ValueList testValueList = businessService.findAll(valueList);

      // Magic AOP should be call now and filter the list ...

      // There should be only 1 element in the filtered list:
      assertEquals(1, testValueList.getList().size());
   }
}
