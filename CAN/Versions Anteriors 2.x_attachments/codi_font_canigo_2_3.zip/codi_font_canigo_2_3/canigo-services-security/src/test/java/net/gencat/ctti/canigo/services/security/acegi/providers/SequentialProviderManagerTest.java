/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers;

import java.util.List;
import java.util.Vector;

import junit.framework.TestCase;

import net.sf.acegisecurity.Authentication;
import net.sf.acegisecurity.AuthenticationException;
import net.sf.acegisecurity.AuthenticationServiceException;
import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.GrantedAuthorityImpl;
import net.sf.acegisecurity.providers.AuthenticationProvider;
import net.sf.acegisecurity.providers.ProviderNotFoundException;
import net.sf.acegisecurity.providers.TestingAuthenticationToken;
import net.sf.acegisecurity.providers.UsernamePasswordAuthenticationToken;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class SequentialProviderManagerTest extends TestCase {
   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testAuthenticationFails() throws Exception {
      UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("Test",
            "Password",
            new GrantedAuthority[] {
               new GrantedAuthorityImpl("ROLE_ONE"),
               new GrantedAuthorityImpl("ROLE_TWO")
            });

      SequentialProviderManager mgr = makeProviderManager();

      try {
         mgr.authenticate(token);
         fail("Should have thrown ProviderNotFoundException");
      } catch (ProviderNotFoundException expected) {
         assertTrue(true);
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testAuthenticationSuccess() throws Exception {
      TestingAuthenticationToken token = new TestingAuthenticationToken("Test",
            "Password",
            new GrantedAuthority[] {
               new GrantedAuthorityImpl("ROLE_ONE"),
               new GrantedAuthorityImpl("ROLE_TWO")
            });

      SequentialProviderManager mgr = makeProviderManager();
      Authentication result = mgr.authenticate(token);

      if (!(result instanceof TestingAuthenticationToken)) {
         fail("Should have returned instance of TestingAuthenticationToken");
      }

      TestingAuthenticationToken castResult = (TestingAuthenticationToken) result;
      assertEquals("Test", castResult.getPrincipal());
      assertEquals("Password", castResult.getCredentials());
      assertEquals("ROLE_ONE", castResult.getAuthorities()[0].getAuthority());
      assertEquals("ROLE_TWO", castResult.getAuthorities()[1].getAuthority());
   }

   /**
    * Documentaci�.
    */
   public void testAuthenticationSuccessWhenFirstProviderReturnsNullButSecondAuthenticates() {
      TestingAuthenticationToken token = new TestingAuthenticationToken("Test",
            "Password",
            new GrantedAuthority[] {
               new GrantedAuthorityImpl("ROLE_ONE"),
               new GrantedAuthorityImpl("ROLE_TWO")
            });

      SequentialProviderManager mgr = makeProviderManagerWithMockProviderWhichReturnsNullInList();
      Authentication result = mgr.authenticate(token);

      if (!(result instanceof TestingAuthenticationToken)) {
         fail("Should have returned instance of TestingAuthenticationToken");
      }

      TestingAuthenticationToken castResult = (TestingAuthenticationToken) result;
      assertEquals("Test", castResult.getPrincipal());
      assertEquals("Password", castResult.getCredentials());
      assertEquals("ROLE_ONE", castResult.getAuthorities()[0].getAuthority());
      assertEquals("ROLE_TWO", castResult.getAuthorities()[1].getAuthority());
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testStartupFailsIfProviderListDoesNotContainingProviders()
      throws Exception {
      List providers = new Vector();
      providers.add("THIS_IS_NOT_A_PROVIDER");

      SequentialProviderManager mgr = new SequentialProviderManager();

      try {
         mgr.setProviders(providers);
         fail("Should have thrown IllegalArgumentException");
      } catch (IllegalArgumentException expected) {
         assertTrue(true);
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testStartupFailsIfProviderListNotSet() throws Exception {
      SequentialProviderManager mgr = new SequentialProviderManager();

      try {
         mgr.afterPropertiesSet();
         fail("Should have thrown IllegalArgumentException");
      } catch (IllegalArgumentException expected) {
         assertTrue(true);
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testStartupFailsIfProviderListNull() throws Exception {
      SequentialProviderManager mgr = new SequentialProviderManager();

      try {
         mgr.setProviders(null);
         fail("Should have thrown IllegalArgumentException");
      } catch (IllegalArgumentException expected) {
         assertTrue(true);
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testSuccessfulStartup() throws Exception {
      SequentialProviderManager mgr = makeProviderManager();
      mgr.afterPropertiesSet();
      assertTrue(true);
      assertEquals(1, mgr.getProviders().size());
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   private SequentialProviderManager makeProviderManager()
      throws Exception {
      MockProvider provider1 = new MockProvider();
      List providers = new Vector();
      providers.add(provider1);

      SequentialProviderManager mgr = new SequentialProviderManager();
      mgr.setProviders(providers);

      mgr.afterPropertiesSet();

      return mgr;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private SequentialProviderManager makeProviderManagerWithMockProviderWhichReturnsNullInList() {
      MockProviderWhichReturnsNull provider1 = new MockProviderWhichReturnsNull();
      MockProvider provider2 = new MockProvider();
      List providers = new Vector();
      providers.add(provider1);
      providers.add(provider2);

      SequentialProviderManager mgr = new SequentialProviderManager();
      mgr.setProviders(providers);

      return mgr;
   }

   // ~ Inner Classes
   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   private class MockProvider implements AuthenticationProvider {
      /**
       * Documentaci�.
       *
       * @param authentication Documentaci�
       *
       * @return Documentaci�
       *
       * @throws AuthenticationException Documentaci�
       * @throws AuthenticationServiceException Documentaci�
       */
      public Authentication authenticate(Authentication authentication)
         throws AuthenticationException {
         if (supports(authentication.getClass())) {
            return authentication;
         } else {
            throw new AuthenticationServiceException("Don't support this class");
         }
      }

      /**
       * Documentaci�.
       *
       * @param authentication Documentaci�
       *
       * @return Documentaci�
       */
      public boolean supports(Class authentication) {
         if (TestingAuthenticationToken.class.isAssignableFrom(authentication)) {
            return true;
         } else {
            return false;
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   private class MockProviderWhichReturnsNull implements AuthenticationProvider {
      /**
       * Documentaci�.
       *
       * @param authentication Documentaci�
       *
       * @return Documentaci�
       *
       * @throws AuthenticationException Documentaci�
       * @throws AuthenticationServiceException Documentaci�
       */
      public Authentication authenticate(Authentication authentication)
         throws AuthenticationException {
         if (supports(authentication.getClass())) {
            return null;
         } else {
            throw new AuthenticationServiceException("Don't support this class");
         }
      }

      /**
       * Documentaci�.
       *
       * @param authentication Documentaci�
       *
       * @return Documentaci�
       */
      public boolean supports(Class authentication) {
         if (TestingAuthenticationToken.class.isAssignableFrom(authentication)) {
            return true;
         } else {
            return false;
         }
      }
   }
}
