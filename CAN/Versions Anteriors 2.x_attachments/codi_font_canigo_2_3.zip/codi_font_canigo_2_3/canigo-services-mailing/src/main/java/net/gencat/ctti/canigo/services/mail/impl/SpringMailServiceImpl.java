/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.mail.impl;

import java.io.File;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.mail.MailService;
import net.gencat.ctti.canigo.services.mail.exception.MailServiceException;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;


/**
 * Implementation to send e-mail using Spring API.
 *
 */
public class SpringMailServiceImpl implements MailService {
   /**
    * Client that sends the e-mail
    */
   private JavaMailSender mailSender = null;

   /**
    * Logging service
    */
   private LoggingService logService = null;

   /**
    * Max. allowed size of attachments (in bytes). "zero" means no limits
    */
   private long maxAttachmentSize = 0L;

   /**
    * Default constructor
    *
    */
   public SpringMailServiceImpl() {
   }

   /**
    * Getter
    * @return the mail sender
    */
   public JavaMailSender getMailSender() {
      return mailSender;
   }

   /**
    * Setter
    * @param mailSender the mail sender
    */
   public void setMailSender(JavaMailSender mailSender) {
      this.mailSender = mailSender;
   }

   /**
    * Sends a message to the given address. All the parameters all required (not null)
    *
    * @param from the origin address
    * @param subject the subject
    * @param aMessage the message (plain texto or html without images)
    * @param isHtml true if the message is html
    * @param to the target address
    * @throws java.lang.Exception if something goes wrong
    */
   public void send(String from, String subject, String aMessage,
      boolean isHtml, String to) throws MailServiceException {
      Map recipients = new HashMap();
      recipients.put(MimeMessage.RecipientType.TO, to);
      this.send(from, subject, aMessage, isHtml, recipients, null);
   }

   /**
    * Sends a message to the given address with an attachment. All the parameters all required (not null)
    *
    * @param from the origin address
    * @param subject the subject
    * @param aMessage the message (plain texto or html without images)
    * @param isHtml true if the message is HTML
    * @param to the target address
    * @param attachment the attachment
    * @throws java.lang.Exception if something goes wrong
    */
   public void send(String from, String subject, String aMessage,
      boolean isHtml, String to, File attachment) throws MailServiceException {
      Map recipients = new HashMap();
      recipients.put(MimeMessage.RecipientType.TO, to);

      List attachments = new ArrayList();
      attachments.add(attachment);
      this.send(from, subject, aMessage, isHtml, recipients, attachments);
   }

   /**
    * Sends a message to the given addresses with a list of attachmens. All the parameters are required (not null)<br>
    * The given addresses (<code>java.util.Map</code>) looks like:<br>
    * <ul>
    *      <li>Key: [MimeMessage.RecipientType.TO,MimeMessage.RecipientType.BCC � MimeMessage.RecipientType.CC]</li>
    *      <li>Value: a string (<code>java.lang.String</code>) or an array of strings(<code>java.lang.String []</code>)
    * </ul>
    * The list of attachments is a file list (<code>java.util.List</code> of <code>java.io.File</code>)
    *
    * @param from the origin address
    * @param subject the subject
    * @param aMessage the message (plain texto or html without images)
    * @param isHtml true if the message is HTML
    * @param recipients the target addresses (TO,BCC or CC)
    * @param attachments the list of attachments
    * @throws java.lang.Exception if something goes wrong
    */
   public void send(String from, String subject, String aMessage,
      boolean isHtml, Map recipients, List attachments)
      throws MailServiceException {
      MimeMessage message = null;
      MimeMessageHelper helper = null;

      if (attachments != null) {
         Iterator it = attachments.iterator();
         this.logService.getLog(this.getClass().getName())
                        .debug("Attachment list size=" + attachments.size());

         while (it.hasNext()) {
            File attachment = (File) it.next();
            this.logService.getLog(this.getClass().getName())
                           .debug("File size=" + attachment.length() +
               " vs Max size=" + this.maxAttachmentSize);

            if ((this.maxAttachmentSize > 0L) &&
                  (attachment.length() > this.maxAttachmentSize)) {
               ExceptionDetails exDetails = new ExceptionDetails("canigo.services.mail.attachment_size_exceeded",
                     new String[] {
                        attachment.length() + "", this.maxAttachmentSize + ""
                     }, Layer.SERVICES, Subsystem.MAIL_SERVICES);
               throw new MailServiceException(exDetails);
            }
         }
      }

      Properties mailProperties = new Properties();
      mailProperties.put("From", from);
      mailProperties.put("Subject", subject);
      mailProperties.put("Message", aMessage);
      mailProperties.put("isHtml", isHtml + "");

      try {
         message = this.mailSender.createMimeMessage();
         helper = new MimeMessageHelper(message,
               (attachments != null) && (attachments.size() > 0));

         Iterator it = recipients.keySet().iterator();

         while (it.hasNext()) {
            Object recipientKey = it.next();
            String[] emailAddress = null;

            if (recipients.get(recipientKey) instanceof String[]) {
               emailAddress = (String[]) recipients.get(recipientKey);
            } else {
               emailAddress = new String[1];
               emailAddress[0] = (String) recipients.get(recipientKey);
            }

            if (MimeMessage.RecipientType.TO.equals(recipientKey)) {
               mailProperties.put("To", emailAddress);
               helper.setTo(emailAddress);
            } else if (MimeMessage.RecipientType.CC.equals(recipientKey)) {
               mailProperties.put("Cc", emailAddress);
               helper.setCc(emailAddress);
            } else if (MimeMessage.RecipientType.BCC.equals(recipientKey)) {
               mailProperties.put("Cc", emailAddress);
               helper.setBcc(emailAddress);
            }
         }

         helper.setFrom(from);
         helper.setSubject(subject);
         helper.setText(aMessage, isHtml);

         if (attachments != null) {
            it = attachments.iterator();

            while (it.hasNext()) {
               File attachment = (File) it.next();
               this.logService.getLog(this.getClass().getName())
                              .debug("Attaching file: " + attachment.getName());
               helper.addAttachment(attachment.getName(), attachment);
            }
         }

         this.logService.getLog(this.getClass().getName())
                        .debug("Sending mail...");
         this.mailSender.send(message);
         this.logService.getLog(this.getClass().getName()).debug("Mail sent!");
      } catch (MessagingException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.mail.error_preparing_addresses",
               null, Layer.SERVICES, Subsystem.MAIL_SERVICES);
         exDetails.setProperties(mailProperties);
         throw new MailServiceException(ex, exDetails);
      } catch (Exception ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.mail.error_sending_mail",
               null, Layer.SERVICES, Subsystem.MAIL_SERVICES);
         exDetails.setProperties(mailProperties);
         throw new MailServiceException(ex, exDetails);
      }
   }

   /**
    * Getter
    * @return long, the max attachment size
    */
   public long getMaxAttachmentSize() {
      return maxAttachmentSize;
   }

   /**
    * Setter
    * @param maxAttachmentLength the max attachment size
    */
   public void setMaxAttachmentSize(long maxAttachmentLength) {
      this.maxAttachmentSize = maxAttachmentLength;
   }

   /**
    * Getter
    * @return net.gencat.ctti.canigo.services.logging.LoggingService
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * Setter
    * @param logService the logging service
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }
}
