/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.mail.impl;

import javax.activation.FileTypeMap;

import javax.mail.Session;
import javax.mail.internet.MimeMessage;


/**
 * Special subclass of the standard JavaMail MimeMessage, carrying a
 * default encoding to be used when populating the message and a default
 * Java Activation FileTypeMap to be used for resolving attachment types.
 *
 * <p>Created by JavaMailSenderImpl in case of a specified default encoding
 * and/or default FileTypeMap. Autodetected by MimeMessageHelper, which will
 * use the carried encoding and FileTypeMap unless explicitly overridden.
 *
 * @author Juergen Hoeller
 * @since 1.2
 * @see JavaMailSenderImpl#createMimeMessage()
 * @see MimeMessageHelper#getDefaultEncoding(javax.mail.internet.MimeMessage)
 * @see MimeMessageHelper#getDefaultFileTypeMap(javax.mail.internet.MimeMessage)
 */
class SmartMimeMessage extends MimeMessage {
   /**
    * Documentaci�.
    */
   private final FileTypeMap defaultFileTypeMap;

   /**
    * Documentaci�.
    */
   private final String defaultEncoding;

   /**
    * Create a new SmartMimeMessage.
    * @param session the JavaMail Session to create the message for
    * @param defaultEncoding the default encoding, or <code>null</code> if none
    * @param defaultFileTypeMap the default FileTypeMap, or <code>null</code> if none
    */
   public SmartMimeMessage(Session session, String defaultEncoding,
      FileTypeMap defaultFileTypeMap) {
      super(session);
      this.defaultEncoding = defaultEncoding;
      this.defaultFileTypeMap = defaultFileTypeMap;
   }

   /**
    * Return the default encoding of this message, or <code>null</code> if none.
    */
   public String getDefaultEncoding() {
      return defaultEncoding;
   }

   /**
    * Return the default FileTypeMap of this message, or <code>null</code> if none.
    */
   public FileTypeMap getDefaultFileTypeMap() {
      return defaultFileTypeMap;
   }
}
