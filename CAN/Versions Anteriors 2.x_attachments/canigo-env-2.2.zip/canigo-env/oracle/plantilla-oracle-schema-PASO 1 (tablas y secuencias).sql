drop index product_category;
drop index product_name;
drop index item_product;
drop index account_category;
drop index account_product;

drop table account;
drop table mail;
drop table lineitem;
drop table orderstatus;
drop table orders;
drop table bannerdata;
drop table profile;
drop table signon;
drop table inventory;
drop table item;
drop table product;
drop table category;
drop table supplier;
drop table sequence;

DROP SEQUENCE mail_seq;

create table supplier (
    suppid int not null,
    name varchar2(80) null,
    status varchar2(2) not null,
    addr1 varchar2(80) null,
    addr2 varchar2(80) null,
    city varchar2(80) null,
    state varchar2(80) null,
    zip varchar2(5) null,
    phone varchar2(80) null,
    constraint pk_supplier primary key (suppid)
);

create table signon (
    username varchar2(25) not null,
    password varchar2(25)  not null,
    constraint pk_signon primary key (username)
);

create table profile (
    userid varchar2(80) not null,
    langpref varchar2(80) not null,
    favcategory varchar2(30),
    mylistopt int,
    banneropt int,
    constraint pk_profile primary key (userid)
);

create table bannerdata (
    favcategory varchar2(80) not null,
    bannername varchar2(255)  null,
    constraint pk_bannerdata primary key (favcategory)
);

create table orders (
      orderid int not null,
      userid varchar2(80) not null,
      orderdate date not null,
      shipaddr1 varchar2(80) not null,
      shipaddr2 varchar2(80) null,
      shipcity varchar2(80) not null,
      shipstate varchar2(80) not null,
      shipzip varchar2(20) not null,
      shipcountry varchar2(20) not null,
      billaddr1 varchar2(80) not null,
      billaddr2 varchar2(80)  null,
      billcity varchar2(80) not null,
      billstate varchar2(80) not null,
      billzip varchar2(20) not null,
      billcountry varchar2(20) not null,
      courier varchar2(80) not null,
      totalprice decimal(10,2) not null,
      billtofirstname varchar2(80) not null,
      billtolastname varchar2(80) not null,
      shiptofirstname varchar2(80) not null,
      shiptolastname varchar2(80) not null,
      creditcard varchar2(80) not null,
      exprdate varchar2(7) not null,
      cardtype varchar2(80) not null,
      locale varchar2(80) not null,
      constraint pk_orders primary key (orderid)
);

create table orderstatus (
      orderid int not null,
      linenum int not null,
      timestamp date not null,
      status varchar2(2) not null,
      constraint pk_orderstatus primary key (orderid, linenum)
);

create table lineitem (
      orderid int not null,
      linenum int not null,
      itemid varchar2(10) not null,
      quantity int not null,
      unitprice decimal(10,2) not null,
      constraint pk_lineitem primary key (orderid, linenum)
);

create table category (
	catid varchar2(10) not null,
	name varchar2(80) null,
	descn varchar2(255) null,
	constraint pk_category primary key (catid)
);

create table product (
    productid varchar2(10) not null,
    category varchar2(10) not null,
    name varchar2(80) null,
    descn varchar2(255) null,
    constraint pk_product primary key (productid),
    constraint fk_product_1 foreign key (category) references category (catid)
);

create index product_category on product (category);
create index product_name on product (name);

create table item (
    itemid varchar2(10) not null,
    productid varchar2(10) not null,
    listprice decimal(10,2) null,
    unitcost decimal(10,2) null,
    supplier int null,
    status varchar2(2) null,
    attr1 varchar2(80) null,
    attr2 varchar2(80) null,
    attr3 varchar2(80) null,
    attr4 varchar2(80) null,
    attr5 varchar2(80) null,
    constraint pk_item primary key (itemid),
        constraint fk_item_1 foreign key (productid)
        references product (productid),
        constraint fk_item_2 foreign key (supplier)
        references supplier (suppid)
);

create index item_product on item (productid);

create table inventory (
    itemid varchar2(10) not null,
    qty int not null,
    constraint pk_inventory primary key (itemid)
);

create table account (
    userid varchar2(80)  null,
    email varchar2(80) not null,
    firstname varchar2(80)  not null,
    lastname varchar2(80) not null,
    status varchar2(2)  null,
    addr1 varchar2(80)  null,
    addr2 varchar2(40) null,
    city varchar2(80)   null,
    state varchar2(80)  null,
    zip varchar2(20)  null,
    country varchar2(20)  null,
    phone varchar2(80)  null,
	birthdate date,
	comments varchar2(255),    	
	is_lower18 varchar2(1),
	password varchar2(80)  null,    	
    preferred_category varchar2(10)  null,
    preferred_product varchar2(10)  null,
    constraint pk_account primary key (userid),
    constraint fk_account_category foreign key (preferred_category) references category (catid),
    constraint fk_account_product foreign key (preferred_product) references product (productid)	
);
create index account_category on account (preferred_category);
create index account_product on account (preferred_product);

create table sequence (
    name varchar2(30) not null,
    nextid int not null,
    constraint pk_sequence primary key (name)
);


create table mail (
    mailid number(10) not null,
    from_address varchar2(80) not null,
    to_address varchar2(80) not null,
    subject varchar2(80) not null,
    message varchar2(255) not null,
    constraint pk_mail primary key (mailid)
);
create sequence mail_seq
start with 1
increment by 1;

DROP SEQUENCE ACL_PERMISSION_SEQ;
DROP SEQUENCE ACL_OBJECT_SEQ;
DROP SEQUENCE PARTY_OBJECT_SEQ;
DROP SEQUENCE ROLE_OBJECT_SEQ;

create sequence ROLE_OBJECT_SEQ
start with 1
increment by 1;

create sequence ACL_OBJECT_SEQ
start with 1
increment by 1;

create sequence ACL_PERMISSION_SEQ
start with 1
increment by 1;

create sequence PARTY_OBJECT_SEQ
start with 1
increment by 1;


DROP TABLE ACL_PERMISSION;
DROP TABLE ACL_OBJECT_IDENTITY;
DROP TABLE PARTY CASCADE CONSTRAINTS;
DROP TABLE GROUP_ROLE CASCADE CONSTRAINTS;
DROP TABLE PARTY_GROUP CASCADE CONSTRAINTS;
DROP TABLE PARTY_RELATIONSHIP CASCADE CONSTRAINTS;
DROP TABLE PARTY_ROLE CASCADE CONSTRAINTS;
DROP TABLE ROLE CASCADE CONSTRAINTS;
DROP TABLE USER_LOGIN CASCADE CONSTRAINTS;

CREATE TABLE acl_object_identity (
     id NUMBER PRIMARY KEY,
     object_identity VARCHAR2(250) NOT NULL,
     parent_object INTEGER,
     acl_class VARCHAR2(250) NOT NULL,
     CONSTRAINT unique_object_identity UNIQUE(object_identity),
     FOREIGN KEY (parent_object) REFERENCES acl_object_identity(id)
);

CREATE TABLE acl_permission (
     id NUMBER PRIMARY KEY,
     acl_object_identity NUMBER NOT NULL,
     recipient VARCHAR2(100) NOT NULL,
     mask NUMBER NOT NULL,
     CONSTRAINT unique_recipient UNIQUE(acl_object_identity, recipient),
     FOREIGN KEY (acl_object_identity) REFERENCES acl_object_identity(id)
);

CREATE TABLE PARTY ( 
	PARTY_ID NUMBER NOT NULL,
	PARTY_TYPE_ID NUMBER,
	EXTERNAL_ID VARCHAR2(20),
	CREATED_DATE VARCHAR2(255),
	CREATED_BY_USER_LOGIN VARCHAR2(255),
	LAST_MODIFIED_DATE VARCHAR2(255),
	LAST_MODIFIED_BY_USER_LOGIN VARCHAR2(255),
	LAST_UPDATED_STAMP VARCHAR2(255),
	LAST_UPDATED_TX_STAMP VARCHAR2(255),
	CREATED_STAMP VARCHAR2(255),
	CREATED_TX_STAMP VARCHAR2(255),
	CONSTRAINT PK_PARTY_ID UNIQUE(PARTY_ID)
)
;

CREATE TABLE PARTY_GROUP ( 
	PARTY_ID NUMBER NOT NULL,
	GROUP_PARENT_ID NUMBER NULL,
	GROUP_NAME VARCHAR2(255) NOT NULL,
	CONSTRAINT PK_PARTY_GROUP UNIQUE(PARTY_ID)
)
;

CREATE TABLE PARTY_RELATIONSHIP ( 
	PARTY_ID_FROM NUMBER NOT NULL,
	PARTY_ID_TO NUMBER NOT NULL,
	TYPE NUMBER NULL,
	CONSTRAINT PK_PARTY_RELATIONSHIP UNIQUE(PARTY_ID_FROM, PARTY_ID_TO),
	FOREIGN KEY (PARTY_ID_FROM) REFERENCES PARTY(PARTY_ID),
	FOREIGN KEY (PARTY_ID_TO) REFERENCES PARTY(PARTY_ID)
)
;

CREATE TABLE ROLE ( 
	ROLE_ID NUMBER NOT NULL,
	ROLE_ID_PARENT NUMBER,
	ROLE_NAME VARCHAR2(50) NOT NULL,
	ROLE_DESCRIPTION VARCHAR2(255),
	CONSTRAINT PK_ROLE UNIQUE(ROLE_ID),
	FOREIGN KEY (ROLE_ID_PARENT) REFERENCES ROLE(ROLE_ID)
)
;

CREATE TABLE USER_LOGIN ( 
	USER_LOGIN_ID VARCHAR2(50) NOT NULL,
	PARTY_ID NUMBER NOT NULL,
	PASSWORD VARCHAR2(50) NOT NULL,
	CONSTRAINT PK_USER_LOGIN UNIQUE(USER_LOGIN_ID),
	FOREIGN KEY (PARTY_ID) REFERENCES PARTY_GROUP(PARTY_ID)
)
;

CREATE TABLE PARTY_ROLE ( 
	USER_LOGIN_ID VARCHAR2(50) NOT NULL,
	ROLE_ID NUMBER NOT NULL,
	CONSTRAINT PK_PARTY_ROLE UNIQUE(USER_LOGIN_ID, ROLE_ID),
	FOREIGN KEY (USER_LOGIN_ID) REFERENCES USER_LOGIN(USER_LOGIN_ID),
	FOREIGN KEY (ROLE_ID) REFERENCES ROLE(ROLE_ID)
)
;

CREATE TABLE GROUP_ROLE ( 
	PARTY_ID NUMBER NOT NULL,
	ROLE_ID NUMBER NOT NULL,
	CONSTRAINT PK_GROUP_ROLE UNIQUE(PARTY_ID, ROLE_ID),
	FOREIGN KEY (PARTY_ID) REFERENCES PARTY_GROUP(PARTY_ID),
	FOREIGN KEY (ROLE_ID) REFERENCES ROLE(ROLE_ID)
)
;