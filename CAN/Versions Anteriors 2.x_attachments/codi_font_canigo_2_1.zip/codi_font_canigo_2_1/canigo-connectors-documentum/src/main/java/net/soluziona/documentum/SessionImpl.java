/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.soluziona.documentum;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;

/**
 *
 *
 * @author SOLUZIONA
 * @version 1.1
 */
import net.soluziona.documentum.exceptions.DocumentumException;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class SessionImpl implements Session {
   /**
    * Documentaci�.
    */
   private IDfSessionManager m_sessionMgr;

   /**
    * Documentaci�.
    */
   private String m_contrasenya;

   /**
    * Documentaci�.
    */
   private String m_docBase;

   /**
    * Documentaci�.
    */
   private String m_usuari;

   /**
    * Creates a new SessionImpl object.
    */
   public SessionImpl() {
   }

   /**
    * Creates a new SessionImpl object.
    *
    * @param SMgr DOCUMENT ME.
    * @param docbase DOCUMENT ME.
    */
   protected SessionImpl(IDfSessionManager SMgr, String docbase) {
      this.m_sessionMgr = SMgr;
      this.m_docBase = docbase;
   }

   /**
    * Creates a new SessionImpl object.
    *
    * @param SMgr DOCUMENT ME.
    * @param usuari DOCUMENT ME.
    * @param contrasenya DOCUMENT ME.
    * @param docBase DOCUMENT ME.
    */
   protected SessionImpl(IDfSessionManager SMgr, String usuari,
      String contrasenya, String docBase) {
      this.m_sessionMgr = SMgr;
      this.m_usuari = usuari;
      this.m_contrasenya = contrasenya;
      this.m_docBase = docBase;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getM_contrasenya() {
      return m_contrasenya;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getM_docBase() {
      return m_docBase;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getM_usuari() {
      return m_usuari;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public IDfSessionManager getM_documentumSMgr() {
      return m_sessionMgr;
   }

   /**
    * Documentaci�.
    *
    * @throws DocumentumException Documentaci�
    */
   public void close() throws DocumentumException {
      DocumentumConnectorImpl myDCS;

      myDCS = new DocumentumConnectorImpl();

      myDCS.closeDfSession(m_sessionMgr);
   }

   /**
    * Documentaci�.
    *
    * @param docBase Documentaci�
    */
   public void reconnectar(String docBase) {
      // TODO Auto-generated method stub
   }
}
