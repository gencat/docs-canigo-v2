/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.soluziona.documentum;

import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Vector;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfACL;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfGroup;
import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfType;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.client.IDfVirtualDocument;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfAttr;
import com.documentum.fc.common.IDfException;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfList;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.operations.IDfCancelCheckoutNode;
import com.documentum.operations.IDfCancelCheckoutOperation;
import com.documentum.operations.IDfCheckinNode;
import com.documentum.operations.IDfCheckinOperation;
import com.documentum.operations.IDfCheckoutNode;
import com.documentum.operations.IDfCheckoutOperation;
import com.documentum.operations.IDfDeleteNode;
import com.documentum.operations.IDfDeleteOperation;
import com.documentum.operations.IDfExportNode;
import com.documentum.operations.IDfExportOperation;
import com.documentum.operations.IDfFile;
import com.documentum.operations.IDfImportNode;
import com.documentum.operations.IDfImportOperation;
import com.documentum.operations.IDfOperation;
import com.documentum.operations.IDfOperationError;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.soluziona.documentum.exceptions.DocumentumException;

import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.IdTransferringMergeEventListener;


/**
 * Connector Documentum 5.x via DFCs
 *
 * @author SOLUZIONA
 * @version 1.1
 */
public class DocumentumConnectorImpl {
   // M�todes d'integraci� amb el FrameWork canigo
   /**
    * Documentaci�.
    */
   private static org.apache.commons.logging.Log log = LogFactory.getLog(DocumentumConnectorImpl.class);

   // Antic m�tode oficial en versi� 1.0.2
   //    /**
   //     * Modifica les propietats d'un objete
   //     *
   //     * @param idObjecte Identificador de l'objecte
   //     * @param propietat Nom de la propietat
   //     * @param valor Nou valor de la propietat
   //     *
   //     * @throws DocumentumException 
   //     */
   //    public void setPropietat(String idObjecte, String propietat, String valor,Session sessio)
   //        throws DocumentumException {
   //      	
   //    	logInfo ("Dins setPropietat(Id:"+idObjecte+",Propietat:"+propietat+",Valor:"+valor+",sessio:"+sessio+")");
   //      	IDfSession m_docSessio=null;
   //      	m_docSessio=solicitarSessio(sessio);
   //    	IDfSysObject sysObj = getExistingObject(idObjecte,m_docSessio);
   //
   //    	try {
   //    		if (sysObj != null) {    		
   //    			sysObj.setString(propietat, valor);    			
   //    			sysObj.save();
   //    		}        
   //            else {
   //               throw new DocumentumException(new Throwable(
   //                    "No s'ha pogut localitzar l'objecte "+idObjecte),
   //                new ExceptionDetails("canigo.services.documentum.bloquejar",
   //                    null, Layer.SERVICES, Subsystem.UNDEFINED));
   //            }
   //    		
   //    	}catch(DfException ex) {
   //    		 ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_setPropietat",
   //                     null, Layer.SERVICES, Subsystem.UNDEFINED);
   //             //exDetails.setProperties(DocumentumProperties);
   //             throw new DocumentumException(ex, exDetails);                
   //    	}
   //    	finally {
   //    		alliberarSessio(sessio.getM_documentumSMgr(),m_docSessio);
   //    	}    	               
   //      	logInfo ("Fi setPropietat()");
   //    }

   /**
    * Accions pel setPropietat.
    */

   /**
    * Afegeix el valor al final de la propietat indexada.
    * Nomes valid per propietats indexades.
    */
   public static final int AFEGIR = -1;

   /**
    * Esborra el valor en la propietat, i si es indexada el valor del index.
    */
   public static final int ESBORRAR = 2;

   /**
    * Insertar el valor en la posici� indexada indicada.
    * Nomes valid per propietats indexades.
    */
   public static final int INSERTAR = 1;

   /**
    * Canviar el valor de la propietat.
    */
   public static final int CANVIAR = 0;

   //private IDfSessionManager m_docSessionManager=null;
   /**
    * Documentaci�.
    */
   private IDfClient dfClient = null;

   /**
   * Crea un nou objecte DocumentumConnectorService.
   *
   * Definim el SessionManager responsable de la connexi� amb la DOCBASE de Documentum
   */
   public DocumentumConnectorImpl() {
      try {
         this.dfClient = new DfClient();
      } catch (DfException ex2) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_creating_dfclient",
               null, Layer.SERVICES, Subsystem.UNDEFINED);
         throw new DocumentumException(ex2, exDetails);
      }

      //this.m_docSessionManager = dfClient.newSessionManager();
   }

   /** ************************** */

   /**
    * LOGGING
    */

   /** ************************** */
   protected void logInfo(String str) {
      //        if(this.logService!=null){
      //        	this.logService.getLog(this.getClass()).info(str);
      //        }
      log.info(str);
   }

   /**
    * Documentaci�.
    *
    * @param str Documentaci�
    */
   protected void logError(String str) {
      //        if(this.logService!=null){
      //        	this.logService.getLog(this.getClass()).error(str);
      //        }
      log.error(str);
   }

   /**
    * Documentaci�.
    *
    * @param str Documentaci�
    * @param ex Documentaci�
    */
   protected void logError(String str, IDfException ex) {
      //        if(this.logService!=null){
      //        	this.logService.getLog(this.getClass()).error(str+ex.getStackTraceAsString());
      //        }
      log.error(str + ex.getStackTraceAsString());
   }

   /**
    * Documentaci�.
    *
    * @param str Documentaci�
    */
   protected void logDebug(String str) {
      //        if(this.logService!=null){
      //        	this.logService.getLog(this.getClass()).debug(str);
      //        }
      log.debug(str);
   }

   /** ************************** */

   /**
    * Classes privades
    */

   /** ************************** */
   private IDfSession solicitarSessio(Session session)
      throws DocumentumException {
      IDfSession sess = null;

      logInfo("solicitarSessio inici");

      try {
         //if (sessionId!=null){
         //sess=dfClient.findSession(sessionId);        
         //sess=this.m_docSessionManager.getSession(sessionId);
         sess = session.getM_documentumSMgr().getSession(session.getM_docBase());

         //}	
      } catch (DfException ex2) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_creating_session",
               null, Layer.SERVICES, Subsystem.UNDEFINED);
         throw new DocumentumException(ex2, exDetails);
      }

      logInfo("solicitarSessio fi");

      return sess;
   }

   /**
    * Documentaci�.
    *
    * @param sMgr Documentaci�
    * @param dfSession Documentaci�
    */
   private void alliberarSessio(IDfSessionManager sMgr, IDfSession dfSession) {
      // Sols eliminem la session quan no es trobem dins d'una transaccio
      logInfo("alliberarSessio inici");

      if (dfSession != null) {
         //dfSession.getSessionManager().release(dfSession);
         sMgr.release(dfSession);
      }

      logInfo("alliberarSessio fi");
   }

   /**
    * Documentaci�.
    *
    * @param operation Documentaci�
    *
    * @throws DocumentumException Documentaci�
    */
   private void executeOperation(IDfOperation operation)
      throws DocumentumException {
      logInfo("Dins executeOperation(Operation:" + operation + ")");

      try {
         //operation.setOperationMonitor( new Progress() );
         // Execute the operation        	
         boolean executeFlag = operation.execute();

         // Check if any errors occured during the execution of the operation
         if (executeFlag == false) {
            // Get the list of errors
            IDfList errorList = operation.getErrors();
            String message = "";
            IDfOperationError error = null;

            // Iterate through the errors and concatenate the error messages
            for (int i = 0; i < errorList.getCount(); i++) {
               error = (IDfOperationError) errorList.get(i);
               message += error.getMessage();
               logError("Error executeOperation: Message:" + message +
                  "  ErrorCode:" + error.getErrorCode() + " Operation:" +
                  error.getOperation() + " Node:" + error.getNode(),
                  error.getException());
            }

            throw new DfException(message);
         }
      } catch (DfException ex) {
         logError("Error internal executeOperation:" + ex.getMessage() + ":" +
            ex.getStackTraceAsString());

         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_executing_operation",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      }

      logInfo("Fi executeOperation");
   }

   /**
    * Documentaci�.
    *
    * @param srcFileOrDir Documentaci�
    * @param destFolderPath Documentaci�
    * @param pObjectType Documentaci�
    * @param pName Documentaci�
    * @param m_docSessio Documentaci�
    *
    * @return Documentaci�
    *
    * @throws DocumentumException Documentaci�
    */
   private String doImport(String srcFileOrDir, String destFolderPath,
      String pObjectType, String pName, IDfSession m_docSessio)
      throws DocumentumException {
      logInfo("Dins doImport(src:" + srcFileOrDir + ",DestFolderPath:" +
         destFolderPath + " Session:" + m_docSessio + ")");

      try {
         IDfClientX clientx = new DfClientX();
         IDfImportOperation operation = clientx.getImportOperation();

         //the Import Opertion requires a session
         operation.setSession(m_docSessio);

         IDfFolder folder = m_docSessio.getFolderByPath(destFolderPath);

         //note: the destination folder must exist- or throws nullPointerDocumentumException
         if (folder == null) {
            throw new DfException("Folder or cabinet " + destFolderPath +
               " no existeix a la Docbase");
         }

         operation.setDestinationFolderId(folder.getObjectId());

         //check if file or directory on file system exists
         IDfFile myFile = clientx.getFile(srcFileOrDir);

         if (myFile.exists() == false) {
            throw new DfException("Fitxer o Directori " + srcFileOrDir +
               " no localitzat al sistema");
         }

         //add the file or directory to the operation            
         IDfImportNode node = (IDfImportNode) operation.add(myFile);

         if (node == null) {
            ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_doing_import_node",
                  null, Layer.SERVICES, Subsystem.UNDEFINED);

            //exDetails.setProperties(DocumentumProperties);
            throw new DocumentumException(exDetails);
         }

         if (pObjectType != null) {
            node.setDocbaseObjectType(pObjectType);
         }

         if (pName != null) {
            node.setNewObjectName(pName);
         }

         executeOperation(operation);

         //Obtenim el nou id
         IDfList myNodes = operation.getNodes();
         IDfImportNode aNode = (IDfImportNode) myNodes.get(0);

         return aNode.getNewObjectId().toString();
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_doing_import",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         logInfo("Fi doImport");
      }
   }

   /**
    * Documentaci�.
    *
    * @param sysObj Documentaci�
    * @param destDir Documentaci�
    * @param exportName Documentaci�
    * @param exportFormat Documentaci�
    *
    * @return Documentaci�
    *
    * @throws DocumentumException Documentaci�
    */
   private String doExport(IDfSysObject sysObj, String destDir,
      String exportName, String exportFormat) throws DocumentumException {
      logInfo("Dins doExport(SysObj:" + sysObj + " DestDir:" + destDir +
         " ExportName:" + exportName + " ExportFormat:" + exportFormat);

      String tmpFilePath = null;

      try {
         sysObj.setObjectName(exportName);

         IDfClientX clientx = new DfClientX();
         IDfExportOperation operation = clientx.getExportOperation();

         operation.setDestinationDirectory(destDir);

         IDfExportNode node = (IDfExportNode) operation.add(sysObj);

         node.setFormat(exportFormat);

         executeOperation(operation);

         logInfo("exported file path: " + node.getFilePath());
         tmpFilePath = node.getFilePath();
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_doing_export",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      }

      logInfo("Fi doExport()" + tmpFilePath);

      return tmpFilePath;
   }

   /**
    * Documentaci�.
    *
    * @param sysObj Documentaci�
    *
    * @throws DocumentumException Documentaci�
    */
   private void doDelete(IDfSysObject sysObj) throws DocumentumException {
      logInfo("Dins doDelete(" + sysObj + ")");

      try {
         String nomObj = sysObj.getObjectName();

         IDfClientX clientx = new DfClientX();
         IDfDeleteOperation operation = clientx.getDeleteOperation();

         // other options for setVersionDeletionPolicy: ALL_VERSIONS,
         //                                             UNUSED_VERSIONS, SELECTED_VERSIONS
         operation.setVersionDeletionPolicy(IDfDeleteOperation.ALL_VERSIONS);

         if (sysObj.isVirtualDocument()) {
            IDfVirtualDocument vDoc = sysObj.asVirtualDocument("CURRENT", false);
            IDfDeleteNode node = (IDfDeleteNode) operation.add(vDoc);
         } else {
            IDfDeleteNode node = (IDfDeleteNode) operation.add(sysObj);
         }

         executeOperation(operation);

         logDebug("Eliminacio del objecte  " + nomObj + " completada.");
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_doing_delete",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         logInfo("Fi doDelete");
      }
   }

   /**
    * Documentaci�.
    *
    * @param sysObj Documentaci�
    * @param dfSession Documentaci�
    *
    * @throws DocumentumException Documentaci�
    */
   private void doCheckout(IDfSysObject sysObj, IDfSession dfSession)
      throws DocumentumException {
      logInfo("Dins doCheckout(SysObj:" + sysObj + " Sessio:" + dfSession);

      try {
         IDfClientX clientx = new DfClientX();
         IDfCheckoutOperation operation = clientx.getCheckoutOperation();
         operation.setSession(dfSession);

         if (sysObj.isCheckedOut() == true) {
            logError("Objecte " + sysObj.getObjectName() +
               " ja est� checkOut.");

            return;
         }

         IDfCheckoutNode node;

         if (sysObj.isVirtualDocument()) {
            IDfVirtualDocument vDoc = sysObj.asVirtualDocument("CURRENT", false);
            node = (IDfCheckoutNode) operation.add(vDoc);
         } else {
            node = (IDfCheckoutNode) operation.add(sysObj);
         }

         executeOperation(operation);

         logDebug("Checkout file path: " + node.getFilePath());
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_doing_checkout",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         logInfo("Fi doCheckout");
      }
   }

   /**
    * Documentaci�.
    *
    * @param sysObj Documentaci�
    *
    * @throws DocumentumException Documentaci�
    */
   private void doCancelCheckout(IDfSysObject sysObj)
      throws DocumentumException {
      logInfo("Dins doCancelCheckout(SysObj:" + sysObj + ")");

      try {
         IDfClientX clientx = new DfClientX();
         IDfCancelCheckoutOperation operation = clientx.getCancelCheckoutOperation();
         operation.setKeepLocalFile(false);

         if (sysObj.isCheckedOut() == false) {
            logError("Objecte " + sysObj.getObjectName() +
               " no est� checked out.");

            return;
         }

         IDfCancelCheckoutNode node = null;

         if (sysObj.isVirtualDocument()) {
            IDfVirtualDocument vDoc = sysObj.asVirtualDocument("CURRENT", false);
            node = (IDfCancelCheckoutNode) operation.add(vDoc);
         } else {
            node = (IDfCancelCheckoutNode) operation.add(sysObj);
         }

         executeOperation(operation);

         logDebug("Canceled checkout para l'objecte " + sysObj.getObjectName());
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_doing_cancelCheckout",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         logInfo("Fi doCancelCheckout");
      }
   }

   /**
    * Documentaci�.
    *
    * @param sysObj Documentaci�
    * @param pathFitxerSrc Documentaci�
    * @param checkinVersion Documentaci�
    *
    * @throws DocumentumException Documentaci�
    */
   private void doCheckin(IDfSysObject sysObj, String pathFitxerSrc,
      int checkinVersion) throws DocumentumException {
      logInfo("doCheckin inici");

      try {
         IDfClientX clientx = new DfClientX();
         IDfCheckinOperation operation = clientx.getCheckinOperation();

         if (sysObj.isCheckedOut() == false) {
            logError("Objecte " + sysObj.getObjectName() +
               " no est� checked out.");

            return;
         }

         IDfCheckinNode node;

         if (sysObj.isVirtualDocument()) {
            IDfVirtualDocument vDoc = sysObj.asVirtualDocument("CURRENT", false);
            node = (IDfCheckinNode) operation.add(vDoc);
         } else {
            node = (IDfCheckinNode) operation.add(sysObj);
         }

         //check if file or directory on file system exists
         if ((pathFitxerSrc != null) && (pathFitxerSrc.length() > 0)) {
            IDfFile myFile = clientx.getFile(pathFitxerSrc);

            if (myFile.exists() == false) {
               throw new DfException("Fitxer o Directori " + pathFitxerSrc +
                  " no localitzat al sistema");
            }

            node.setFilePath(pathFitxerSrc);
         }

         // Other options for checkinVersion: VERSION_NOT_SET, NEXT_MAJOR,
         // NEXT_MINOR, BRANCH_VERSION
         operation.setCheckinVersion(checkinVersion);
         operation.setRetainLock(false);
         operation.setVersionLabels("CURRENT");

         executeOperation(operation);

         logDebug("Old object id: " + node.getObjectId().toString());
         logDebug("New object id: " + node.getNewObjectId().toString());
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_doing_checkin",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         logInfo("doCheckin fi");
      }
   }

   /**
    * Documentaci�.
    *
    * @param queryString Documentaci�
    * @param m_docSessio Documentaci�
    *
    * @return Documentaci�
    *
    * @throws DocumentumException Documentaci�
    */
   private IDfCollection execQuery(String queryString, IDfSession m_docSessio)
      throws DocumentumException {
      logInfo("execQuery inici");

      try {
         IDfCollection col = null;
         IDfClientX clientx = new DfClientX();
         IDfQuery q = clientx.getQuery();

         q.setDQL(queryString);

         col = q.execute(m_docSessio, IDfQuery.DF_READ_QUERY);

         return col;
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.execQuery",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         logInfo("execQuery fi");
      }
   }

   /**
    * Documentaci�.
    *
    * @param col Documentaci�
    *
    * @return Documentaci�
    *
    * @throws DocumentumException Documentaci�
    */
   private HashMap collection2HashMap(IDfCollection col)
      throws DocumentumException {
      try {
         HashMap myHashResult = new HashMap();

         int itemsAdded = 1;

         while (col.next()) {
            Vector myVectorFile = new Vector(col.getAttrCount());

            for (int i = 0; i < col.getAttrCount(); i++) {
               IDfAttr attr = col.getAttr(i);
               myVectorFile.add(col.getString(attr.getName()));
            }

            myHashResult.put(new Integer(itemsAdded), myVectorFile);
            itemsAdded++;
         }

         // Close the collection.
         col.close();

         if (myHashResult.size() > 0) {
            return myHashResult;
         } else {
            return null;
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.displayResults",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         throw new DocumentumException(ex, exDetails);
      } finally {
      }
   }

   /**
    * Documentaci�.
    *
    * @param strObjId Documentaci�
    * @param m_docSessio Documentaci�
    *
    * @return Documentaci�
    *
    * @throws DocumentumException Documentaci�
    */
   private IDfSysObject getExistingObject(String strObjId,
      IDfSession m_docSessio) throws DocumentumException {
      logInfo("Dins getExistingObject(Id:" + strObjId + ",sessio:" +
         m_docSessio + ")");

      IDfSysObject sysObj = null;

      try {
         IDfClientX clientx = new DfClientX();
         IDfId tmpId = clientx.getId(strObjId);

         if ((tmpId != null) && (!tmpId.isNull()) && (tmpId.isObjectId())) {
            sysObj = (IDfSysObject) m_docSessio.getObject(tmpId);
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_doing_getExistingObject",
               null, Layer.SERVICES, Subsystem.UNDEFINED);
         logError(ex.getStackTraceAsString());

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
      }

      logInfo("Fi getExistingObject():" + sysObj + ")");

      return sysObj;
   }

   /**
    * Documentaci�.
    *
    * @param strPath Documentaci�
    * @param m_docSessio Documentaci�
    *
    * @return Documentaci�
    *
    * @throws DocumentumException Documentaci�
    */
   private IDfSysObject getExistingObjectByPath(String strPath,
      IDfSession m_docSessio) throws DocumentumException {
      logInfo("getExistingObjectByPath inici");

      try {
         IDfSysObject sysObj = (IDfSysObject) m_docSessio.getObjectByPath(strPath);

         if (sysObj == null) {
            logDebug("getExistingObjectByPath: No s'han trobat objectes.");

            return null;
         } else {
            logDebug("getExistingObjectByPath: Objecte " +
               sysObj.getObjectName() + " amb id " +
               sysObj.getObjectId().toString() + " trobat.");

            return sysObj;
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_doing_getExistingObjectByPath",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         logInfo("getExistingObjectByPath fi");
      }
   }

   //    private IDfCollection listContentsOfFolderByPath(String strFolderPath,IDfSession m_docSessio)
   /**
    * Documentaci�.
    *
    * @param strFolderId Documentaci�
    * @param m_docSessio Documentaci�
    *
    * @return Documentaci�
    *
    * @throws DocumentumException Documentaci�
    */
   private IDfCollection listContentsOfFolderById(String strFolderId,
      IDfSession m_docSessio) throws DocumentumException {
      logInfo("listContentsOfFolderById inici");

      try {
         IDfClientX clientx = new DfClientX();
         IDfId folderId = clientx.getId(strFolderId);

         IDfFolder folder = (IDfFolder) m_docSessio.getObject(folderId);

         if (folder == null) {
            throw new DfException("No localitzat el directori " + strFolderId);
         }

         // Get the folder contents
         IDfCollection collection = folder.getContents(
               "r_object_id, object_name, r_object_type");

         return collection;
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_doing_listContentsOfFolderById",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         logInfo("listContentsOfFolderById fi");
      }
   }

   /**
    * M�tode utilitzat per coneixer els atributs d'un Tipus a Documentum
    *
    * @param tipus Nom del tipus
    *
    * @throws DocumentumException
    */
   public void llistarAtributs(String tipus, Session sessio)
      throws DocumentumException {
      IDfSession m_docSessio = null;
      logInfo("Dins llistarAtributs(tipus:" + tipus + ",sessio:" + sessio +
         ")");

      try {
         m_docSessio = solicitarSessio(sessio);

         IDfType typeObj = m_docSessio.getType(tipus);
         String myDesc = typeObj.getDescription();
         this.logDebug("Tipus d'atribut " + myDesc);

         for (int i = 0; i < typeObj.getAttrCount(); i++) {
            IDfAttr attrObj = typeObj.getAttr(i);
            this.logDebug("Nom atribut: " + attrObj.getName());
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_doing_llistarAtributs",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi llistarAtributs()");
   }

   /**
    * Obre una transacci�. Qualsevol canvi no es guardar� fins que no es
    * realitzi un COMMIT o un ROLLBACK
    *
    * @throws DocumentumException
    */

   /**
   * Realitza un COMMIT d'una transacci� previament oberta
   *
   * @throws DocumentumException
   */

   /**
   * Realitza un ROLLBACK d'una transacci� previament oberta
   *
   * @throws DocumentumException
   */

   /**
    * Assignar un usuari a un grup
    *
    * @param grup grup de la DocBase
    * @param usuari OS Name de l'usuari
    *
    * @throws DocumentumException
    */
   public void assignarUsuariGrup(String grup, String usuari, Session sessio)
      throws DocumentumException {
      boolean estatAccio = false;
      String nomUsuari = "";
      logInfo("Dins assignarUsuariGrup(grup:" + grup + ",usuari:" + usuari +
         ",sessio:" + sessio + ")");

      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(sessio);
         nomUsuari = buscarNomUsuari(usuari, sessio);

         IDfUser docUser = (IDfUser) m_docSessio.getUser(nomUsuari);

         if (docUser == null) {
            throw new DfException("Usuari [" + usuari +
               "] no localitzat al sistema");
         }

         IDfGroup docGrp = (IDfGroup) m_docSessio.getGroup(grup);

         if (docGrp == null) {
            throw new DfException("Grup [" + grup +
               "] no localitzat al sistema");
         }

         estatAccio = docGrp.addUser(docUser.getUserName());
         docGrp.save();

         if (!estatAccio) {
            throw new DfException("L'usuari " + usuari +
               " ja existia al grup " + grup);
         }

         logDebug("Usuari [" + usuari + "] assignat al grup [" + grup + "]");
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_doing_assignarUsuariGrup",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi assignarUsuariGrup()");
   }

   /**
    * Assignar un usuari a un grup
    *
    * @param grup grup de la DocBase
    * @param usuari OS Name de l'usuari
    *
    * @throws DocumentumException
    */
   public void eliminarUsuariGrup(String grup, String usuari, Session sessio)
      throws DocumentumException {
      boolean estatAccio = false;
      String nomUsuari = "";
      logInfo("Dins eliminarUsuariGrup(grup:" + grup + ",usuari:" + usuari +
         ",sessio:" + sessio + ")");

      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(sessio);
         nomUsuari = buscarNomUsuari(usuari, sessio);

         IDfUser docUser = (IDfUser) m_docSessio.getUser(nomUsuari);

         if (docUser == null) {
            throw new DfException("Usuari [" + usuari +
               "] no localitzat al sistema");
         }

         IDfGroup docGrp = (IDfGroup) m_docSessio.getGroup(grup);

         if (docGrp == null) {
            throw new DfException("Grup [" + grup +
               "] no localitzat al sistema");
         }

         estatAccio = docGrp.removeUser(docUser.getUserName());
         docGrp.save();

         if (!estatAccio) {
            throw new DfException("L'usuari " + usuari +
               " no existia al grup " + grup);
         }

         logDebug("Usuari [" + usuari + "] eliminat del grup [" + grup + "]");
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_doing_eliminarUsuariGrup",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi eliminarUsuariGrup()");
   }

   /**
    * Crea un nou directori a la DocBase
    *
    * @param path (opcional)Ubicaci� en cas de crear un directori. En blanc si �s una cabinet
    * @param nom Nom del directori o cabinet
    * @param tipus Tipus intern "dm_folder" o "dm_cabinet"
    *
    * @throws DocumentumException
    */
   public void nouDirectori(String path, String nom, String tipus,
      Session sessio) throws DocumentumException {
      logInfo("Dins nouDirectori(path:" + path + ",nom:" + nom + ",tipus:" +
         tipus + ",sessio:" + sessio + ")");

      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(sessio);

         if ((tipus == null) || (tipus.length() == 0)) {
            tipus = "dm_folder";
         }

         IDfFolder myDirectori = m_docSessio.getFolderByPath(path + "/" + nom);

         if (myDirectori != null) {
            throw new DfException("El directori " + nom +
               " ja existeix. Path :" + path);
         }

         myDirectori = (IDfFolder) m_docSessio.newObject(tipus);
         myDirectori.setObjectName(nom);

         if (!tipus.equals("dm_cabinet")) {
            myDirectori.link(path);
         }

         myDirectori.save();

         logDebug("Directori [" + nom + "] creat correctament a [" + path +
            "]");
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_nouDirectori",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi nouDirectori()");
   }

   /**
    * Eliminar un directori
    *
    * @param idDirectori Identificador del directori
    *
    * @throws DocumentumException
    */
   public void eliminarDirectori(String idDirectori, Session sessio)
      throws DocumentumException {
      logInfo("Dins eliminarDirectori(" + idDirectori + ",sessio:" + sessio +
         ")");

      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(sessio);

         IDfSysObject sysObj = getExistingObject(idDirectori, m_docSessio);

         if (sysObj != null) {
            doDelete(sysObj);
         }
      }
      finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi eliminarDirectori()");

      //}
   }

   /**
    * Eliminar un directori
    *
    * @param path Ubicaci�/Path del directori a la DocBase
    *
    * @throws DocumentumException
    */
   public void eliminarDirectoriByPath(String path, Session sessio)
      throws DocumentumException {
      logInfo("Dins eliminarDirectoriByPath(path:" + path + ",sessio:" +
         sessio);

      IDfSession m_docSessio = null;
      m_docSessio = solicitarSessio(sessio);

      try {
         IDfSysObject sysObj = getExistingObjectByPath(path, m_docSessio);

         if (sysObj != null) {
            doDelete(sysObj);
         }
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi eliminarDirectoriByPath()");
   }

   /**
    * Obt� tots els objectes d'un directori
    *
    * @param idDirectori Identificador del directori
    *
    * @return objectes del directori.
    *
    * @throws DocumentumException
    */
   public HashMap getObjectesDirectori(String idDirectori, Session sessio)
      throws DocumentumException {
      logInfo("Dins getObjectesDirectori(IdDirectori:" + idDirectori +
         ",sessio:" + sessio + ")");

      IDfSession m_docSessio = null;
      m_docSessio = solicitarSessio(sessio);

      HashMap llistatDocumentsHash = null;

      try {
         IDfCollection resultat = listContentsOfFolderById(idDirectori,
               m_docSessio);
         llistatDocumentsHash = collection2HashMap(resultat);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi getObjectesDirectori()");

      return llistatDocumentsHash;
   }

   /**
    * Realitza una recerca en un directori de la DocBase
    *
    * @param resultats Camps que volem inclou-re en al recerca
    * @param tipus Taula sobre la qual volem realitzar la recerca
    * @param camps Camps pels quals volem filtrar la recerca
    * @param text Text a comparar amb els camps de la recerca
    * @param path Indica el punt de partida dela recerca
    * @param exacte Indicati de si volen filtrar el camp text de manera exacte
    * @param ordre Camps indicant l'ordre de retorn la recerca
    *
    * @return Retorna un HashMap<Integer, Vector>
    *
    * @throws DocumentumException
    */
   public HashMap buscarDirectori(String resultats, String tipus, String camps,
      String text, String path, boolean exacte, String ordre, Session sessio)
      throws DocumentumException {
      logInfo("Dins buscarDirectori(" + resultats + ",tipus:" + tipus +
         ",camps:" + camps + ",text:" + text + ",path:" + path + ",exacte:" +
         exacte + ",ordre:" + ordre + ",sessio:" + sessio + ")");

      HashMap myResult = null;
      IDfSession m_docSessio = null;
      m_docSessio = solicitarSessio(sessio);

      try {
         if ((resultats == null) || (resultats.length() == 0)) {
            throw new DfException(
               "El par�metre [resultats] no pot ser NULL o estar buit");
         }

         if ((tipus == null) || (tipus.length() == 0)) {
            throw new DfException(
               "El par�metre [tipus] no pot ser NULL o estar buit");
         }

         if ((camps == null) || (camps.length() == 0)) {
            throw new DfException(
               "El par�metre [camps] no pot ser NULL o estar buit");
         }

         if ((text == null) || (text.length() == 0)) {
            throw new DfException(
               "El par�metre [text] no pot ser NULL o estar buit");
         }

         StringBuffer myQueryStringB = new StringBuffer();
         myQueryStringB.append("SELECT " + resultats);
         myQueryStringB.append(" FROM  " + tipus);

         if ((path == null) || (path.length() == 0)) {
            myQueryStringB.append(" WHERE ( ");
         } else {
            myQueryStringB.append(" WHERE FOLDER('" + path + "') AND (");
         }

         StringTokenizer myCampsStringT = new StringTokenizer(camps, ",");
         int totalTokens = myCampsStringT.countTokens();
         logDebug("Total de TOKENS " + totalTokens);

         while (myCampsStringT.hasMoreTokens()) {
            myQueryStringB.append(myCampsStringT.nextToken());

            if (exacte) {
               myQueryStringB.append(" = '" + text + "' ");
            } else {
               myQueryStringB.append(" like '%" + text + "%' ");
            }

            if (totalTokens > 1) {
               myQueryStringB.append(" OR ");
               totalTokens--;
            }
         }

         myQueryStringB.append(" ) ");

         if ((ordre != null) && (ordre.length() > 0)) {
            myQueryStringB.append(" ORDER BY " + ordre);
         }

         logDebug("La operacion ser� " + myQueryStringB.toString());

         IDfCollection col = execQuery(myQueryStringB.toString(), m_docSessio);

         myResult = collection2HashMap(col);
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.buscarDocument",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi buscarDirectori()");

      return myResult;
   }

   /**
    * Crea un nou document a la DocBase
    *
    * @param acl ACL del document
    * @param dominiAcl Domini ACL Del document
    * @param srcPath Path on trobem el document en Local
    * @param dstPath Path on s'ubicar� el document a la DocBase
    * @param tipusObj Tipus intern "dm_document" o algun que heredi d'aquest
    * @param sessio sessio.
    *
    * @return Identificador intern del document
    *
    * @throws DocumentumException
    */
   public String nouDocument(String acl, String dominiAcl, String srcPath,
      String dstPath, String tipusObj, Session sessio)
      throws DocumentumException {
      return nouDocument(acl, dominiAcl, srcPath, dstPath, null, tipusObj,
         sessio);
   }

   /**
    * Crea un nou document a la DocBase
    *
    * @param acl ACL del document
    * @param dominiAcl Domini ACL Del document
    * @param srcPath Path on trobem el document en Local
    * @param dstPath Path on s'ubicar� el document a la DocBase
    * @param sessio sessio
    *
    * @param tipusObj Tipus intern "dm_document" o algun que heredi d'aquest
    *
    * @return Identificador intern del document
    *
    * @throws DocumentumException
    */
   public String nouDocument(String acl, String dominiAcl, String srcPath,
      String dstPath, String pName, String tipusObj, Session sessio)
      throws DocumentumException {
      logInfo("Dins nouDocument(acl:" + acl + ",dominiAcl:" + dominiAcl +
         ",srcPath:" + srcPath + ",dstPath:" + dstPath + ",tipusObj:" +
         tipusObj + ",sessio:" + sessio + ")");

      IDfSession m_docSessio = null;
      m_docSessio = solicitarSessio(sessio);

      String sysObjId = null;

      try {
         sysObjId = doImport(srcPath, dstPath, tipusObj, pName, m_docSessio);

         if ((acl != null) && (acl.length() != 0) && (dominiAcl != null) &&
               (dominiAcl.length() != 0)) {
            canviarAcl(sysObjId, acl, dominiAcl, sessio);
         }
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi nouDocument()");

      return sysObjId;
   }

   /**
    * Fa un check-out del document.
    *
    * @param idDocument Identificador del document
    *
    * @throws DocumentumException
    */
   public void bloquejar(String idDocument, Session sessio)
      throws DocumentumException {
      logInfo("Dins bloquejar (IdDocument:" + idDocument + ",sessio:" + sessio +
         ")");

      IDfSession m_docSessio = null;
      m_docSessio = solicitarSessio(sessio);

      try {
         IDfSysObject sysObj = getExistingObject(idDocument, m_docSessio);

         if (sysObj != null) {
            doCheckout(sysObj, m_docSessio);
         } else {
            throw new DocumentumException(new Throwable(
                  "No s'ha pogut localitzar el fitxer " + idDocument),
               new ExceptionDetails("canigo.services.documentum.bloquejar",
                  null, Layer.SERVICES, Subsystem.UNDEFINED));
         }
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi bloquejar()");
   }

   /**
    * Realitza un Cancel Check-out
    *
    * @param idDocument Identificador del document
    *
    * @throws DocumentumException
    */
   public void cancelarBloqueig(String idDocument, Session sessio)
      throws DocumentumException {
      logInfo("Dins cancelarBloqueig(IdDocument:" + idDocument + ",sessio:" +
         sessio + ")");

      IDfSession m_docSessio = null;
      m_docSessio = solicitarSessio(sessio);

      try {
         IDfSysObject sysObj = getExistingObject(idDocument, m_docSessio);

         if (sysObj != null) {
            doCancelCheckout(sysObj);
         } else {
            throw new DocumentumException(new Throwable(
                  "No s'ha pogut localitzar el fitxer " + idDocument),
               new ExceptionDetails("canigo.services.documentum.bloquejar",
                  null, Layer.SERVICES, Subsystem.UNDEFINED));
         }
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi cancelarBloqueig()");
   }

   /**
    * Fa un check-in sense aumentar la versi� del document.
    *
    * @param pathFitxer (Opcional) Indica l'adre�a a local on podem trobar el fitxer
    * @param idDocument Identificador del document
    *
    * @throws DocumentumException
    */
   public void desbloquejar(String pathFitxer, String idDocument, Session sessio)
      throws DocumentumException {
      logInfo("Dins desbloquejar(PathFitxer:" + pathFitxer + ",idDocument:" +
         idDocument + ",sessio:" + sessio + ")");

      IDfSession m_docSessio = null;
      m_docSessio = solicitarSessio(sessio);

      try {
         IDfSysObject sysObj = getExistingObject(idDocument, m_docSessio);

         if (sysObj != null) {
            doCheckin(sysObj, pathFitxer, IDfCheckinOperation.SAME_VERSION);
         } else {
            throw new DocumentumException(new Throwable(
                  "No s'ha pogut localitzar el fitxer " + idDocument),
               new ExceptionDetails("canigo.services.documentum.bloquejar",
                  null, Layer.SERVICES, Subsystem.UNDEFINED));
         }
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi desbloquejar()");
   }

   /**
    * Fa un check-in aumentant la versi� del document.
    *
    * @param pathFitxer (Opcional) Indica l'adre�a a local on podem trobar el fitxer
    * @param idDocument Identificador del document
    *
    * @throws DocumentumException
    */
   public void desbloquejarVersio(String pathFitxer, String idDocument,
      Session sessio) throws DocumentumException {
      logInfo("desbloquejarVersio(pathFitxer:" + pathFitxer + ",idDocument:" +
         idDocument + ",sessio:" + sessio + ")");

      IDfSession m_docSessio = null;
      m_docSessio = solicitarSessio(sessio);

      try {
         IDfSysObject sysObj = getExistingObject(idDocument, m_docSessio);

         if (sysObj != null) {
            doCheckin(sysObj, pathFitxer, IDfCheckinOperation.NEXT_MAJOR);
         } else {
            throw new DocumentumException(new Throwable(
                  "No s'ha pogut localitzar el fitxer " + idDocument),
               new ExceptionDetails("canigo.services.documentum.bloquejar",
                  null, Layer.SERVICES, Subsystem.UNDEFINED));
         }
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi desbloquejarVersio()");
   }

   /**
    * Fa un check-out i un check-in aumentant la versi� del document.
    *
    * @param pathFitxer (Opcional) Indica l'adre�a a local on podem trobar el fitxer
    * @param idDocument Identificador del document
    *
    * @throws DocumentumException
    */
   public void novaVersio(String pathFitxer, String idDocument, Session sessio)
      throws DocumentumException {
      logInfo("Dins novaVersio(PathFitxer:" + pathFitxer + ",idDocument:" +
         idDocument + ",Sessio:" + sessio + ")");

      IDfSession m_docSessio = null;
      m_docSessio = solicitarSessio(sessio);

      try {
         IDfSysObject sysObj = getExistingObject(idDocument, m_docSessio);

         if (sysObj != null) {
            doCheckout(sysObj, m_docSessio);
            doCheckin(sysObj, pathFitxer, IDfCheckinOperation.NEXT_MAJOR);
         } else {
            throw new DocumentumException(new Throwable(
                  "No s'ha pogut localitzar el fitxer " + idDocument),
               new ExceptionDetails("canigo.services.documentum.bloquejar",
                  null, Layer.SERVICES, Subsystem.UNDEFINED));
         }
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi novaVersio()");
   }

   /**
    * Eliminar un document
    *
    * @param idDocument Identificador del document
    *
    * @throws DocumentumException
    */
   public void eliminarDocument(String idDocument, Session sessio)
      throws DocumentumException {
      logInfo("Dins eliminarDocument(IdDocument:" + idDocument + ",sessio:" +
         sessio + ")");

      IDfSession m_docSessio = null;
      m_docSessio = solicitarSessio(sessio);

      try {
         IDfSysObject sysObj = getExistingObject(idDocument, m_docSessio);

         if (sysObj != null) {
            doDelete(sysObj);
         } else {
            throw new DocumentumException(new Throwable(
                  "No s'ha pogut localitzar el fitxer " + idDocument),
               new ExceptionDetails("canigo.services.documentum.bloquejar",
                  null, Layer.SERVICES, Subsystem.UNDEFINED));
         }
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi eliminarDocument()");
   }

   /**
    * Exporta un fitxer de la DocBase a disc Local
    *
    * @param dstPath Path de la m�quina Local on ubicar el document
    * @param idDocument Identificador del document
    *
    * @throws DocumentumException
    */
   public String exportarFitxer(String dstPath, String idDocument,
      Session sessio) throws DocumentumException {
      logInfo("Dins exportarFitxer(DestPath:" + dstPath + " idDocument:" +
         idDocument + "Session:" + sessio);

      IDfSession m_docSessio = null;
      m_docSessio = solicitarSessio(sessio);

      String tmpFilePath = null;

      try {
         IDfSysObject sysObj = getExistingObject(idDocument, m_docSessio);

         if (sysObj != null) {
            tmpFilePath = doExport(sysObj, dstPath, sysObj.getObjectName(),
                  sysObj.getContentType());
         } else {
            throw new DfException("No s'ha pogut localitzar el fitxer " +
               idDocument);
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_getPropietat",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi exportarFitxer():" + tmpFilePath);

      return tmpFilePath;
   }

   /**
    * Canvia la propietat d'un objecte
    * @param pObject, objecte documentum
    * @param pPropietat, nom de la propietat
    * @param pValors, valors a afegir.
    * @param pIndex, posici� indexada, acci� insertar o borrar, 0 per propietats siemples.
    * @param pSessio, sessio documentum
    */
   private void setPropietat(IDfSysObject pObject, String pPropietat,
      Object pValor, int pIndex, int pAccio)
      throws DocumentumException, DfException {
      String tmpId = null;

      if (log.isInfoEnabled()) {
         tmpId = pObject.getObjectId().toString();
      }

      switch (pAccio) {
      case CANVIAR:

         if (pValor == null) {
            //pObject.setNRsetRepeatingNull(pPropietat,pIndex);
         }

         if (pValor instanceof String) {
            pObject.setRepeatingString(pPropietat, pIndex, (String) pValor);
         } else if (pValor instanceof Date) {
            pObject.setRepeatingTime(pPropietat, pIndex,
               new DfTime((Date) pValor));
         } else if (pValor instanceof Integer) {
            pObject.setRepeatingInt(pPropietat, pIndex,
               ((Integer) pValor).intValue());
         } else if (pValor instanceof Double) {
            pObject.setRepeatingDouble(pPropietat, pIndex,
               ((Double) pValor).doubleValue());
         } else if (pValor instanceof Boolean) {
            pObject.setRepeatingBoolean(pPropietat, pIndex,
               ((Boolean) pValor).booleanValue());
         } else {
            throw new DocumentumException("El valor " + pValor +
               " es de un tipus desconegut");
         }

         if (log.isInfoEnabled()) {
            log.info("Canviar propietat:id:" + tmpId + ",propietat:" +
               pPropietat + ",valor:" + pValor + ",Index:" + pIndex);
         }

         break;

      case ESBORRAR:
         pObject.remove(pPropietat, pIndex);

         if (log.isInfoEnabled()) {
            log.info("Esborrar propietat:id:" + tmpId + ",propietat:" +
               pPropietat + ",valor:" + pValor + ",index:" + pIndex);
         }

         break;

      case INSERTAR:

         if (pValor instanceof String) {
            pObject.insertString(pPropietat, pIndex, (String) pValor);
         } else if (pValor instanceof Date) {
            pObject.insertTime(pPropietat, pIndex, new DfTime((Date) pValor));
         } else if (pValor instanceof Integer) {
            pObject.insertInt(pPropietat, pIndex, ((Integer) pValor).intValue());
         } else if (pValor instanceof Double) {
            pObject.insertDouble(pPropietat, pIndex,
               ((Double) pValor).doubleValue());
         } else if (pValor instanceof Boolean) {
            pObject.insertBoolean(pPropietat, pIndex,
               ((Boolean) pValor).booleanValue());
         } else {
            throw new DocumentumException("El valor " + pValor +
               " es de un tipus desconegut");
         }

         if (log.isInfoEnabled()) {
            log.info("Insertar propietat:id:" + tmpId + ",propietat:" +
               pPropietat + ",valor:" + pValor + ",index:" + pIndex);
         }

         break;

      case AFEGIR:

         if (pValor instanceof String) {
            pObject.appendString(pPropietat, (String) pValor);
         } else if (pValor instanceof Date) {
            pObject.appendTime(pPropietat, new DfTime((Date) pValor));
         } else if (pValor instanceof Integer) {
            pObject.appendInt(pPropietat, ((Integer) pValor).intValue());
         } else if (pValor instanceof Double) {
            pObject.appendDouble(pPropietat, ((Double) pValor).doubleValue());
         } else if (pValor instanceof Boolean) {
            pObject.appendBoolean(pPropietat, ((Boolean) pValor).booleanValue());
         } else {
            throw new DocumentumException("El valor " + pValor +
               " es de un tipus desconegut");
         }

         if (log.isInfoEnabled()) {
            log.info("Afegir propietat:id:" + tmpId + ",propietat:" +
               pPropietat + ",valor:" + pValor + " index:" + pIndex);
         }

         break;

      default:
         throw new DocumentumException("L'accio " + pAccio +
            " es deconeguda. Els valors han de ser CANVIAR,AFEGIR,ESBORRAR,INSERTAR");
      }
   }

   /**
    * Modifica les propietats d'un objecte.
    * <br>
    * <b> Nom�s permet modificar propietats string i que no siguin indexades.</b>
    * @param pIdObjecte Identificador de l'objecte
    * @param pPropietat Noms de la propietat ha modificar
    * @param pValor Nou valor de la propietat.
    *
    * @throws DocumentumException
    */
   public void setPropietat(String pIdObjecte, String pPropietat,
      String pValor, Session pSessio) throws DocumentumException {
      this.setPropietat(pIdObjecte, pPropietat, pValor, 0, CANVIAR, pSessio);
   }

   /**
    * Modifica les propietats d'un objecte.
    * Suporta propietats repating  i propietats String,Integer,Boolean,java.util.Date,Double.
    * <br>
    * <b>En cas d'haver de modificar m�s d'una propietat s'aconsella fer la crida amb el setPropietats per questions d'efici�ncia.</b>
    *
    * @param pIdObjecte Identificador de l'objecte
    * @param pPropietat Nom de la propietat ha modificar
    * @param pIndex pIndex de la propietat indexada o repeating. Si la propietat es simple el seu valor ha de ser 0.
    * @param pAccio accio a fer per cada valor. El seu valor �s CANVIAR,AFEGIR,ESBORRAR,INSERTAR.
    * @param pValor Nou valor de la propietat. Les classes que es suporten son: String,Integer,Boolean,Double,Date
    *
    * @throws DocumentumException
    */
   public void setPropietat(String pIdObjecte, String pPropietat,
      Object pValor, int pIndex, int pAccio, Session pSessio)
      throws DocumentumException {
      logInfo("Dins setPropietat(Id:" + pIdObjecte + ",Propietat:" +
         pPropietat + ",Valor:" + pValor + ",sessio:" + pSessio + ")");

      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(pSessio);

         IDfSysObject tmpSysObj = getExistingObject(pIdObjecte, m_docSessio);
         setPropietat(tmpSysObj, pPropietat, pValor, pIndex, pAccio);
         tmpSysObj.save();
      } catch (DfException ex) {
         log.error("Error en el servei de documentum" +
            ex.getStackTraceAsString());

         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_setPropietat",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } catch (DocumentumException ex) {
         log.error("Error en el servei de documentum", ex);
         throw ex;
      } finally {
         alliberarSessio(pSessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi setPropietat()");
   }

   /**
    * Modifica les propietats d'un objecte.
    * Suporta propietats repating  i propietats String,Integer,Boolean,java.util.Date,Double.
    *
    * @param pIdObjecte Identificador de l'objecte
    * @param pPropietats Noms de les propietats
    * @param pIndexs pIndex de les propietats indexada o repeating. Si la propietat es simple el seu valor ha de ser 0.
    * @param pAccions accions a fer per cada valor. El seu valor �s CANVIAR,AFEGIR,ESBORRAR,INSERTAR.
    * @param pValors Nou valor de la propietat. Les classes que es suporten son: String,Integer,Boolean,Double,Date
    *
    * @throws DocumentumException
    */
   public void setPropietats(String pIdObjecte, String[] pPropietats,
      Object[] pValors, int[] pIndexs, int[] pAccions, Session pSessio)
      throws DocumentumException {
      logInfo("Dins setPropietats(Id:" + pIdObjecte + ",Propietat:" +
         pPropietats + ",Valor:" + pValors + ",sessio:" + pSessio + ")");

      IDfSession m_docSessio = null;

      if ((pPropietats.length != pValors.length) ||
            (pValors.length != pIndexs.length) ||
            (pIndexs.length != pAccions.length)) {
         throw new DocumentumException(
            "El m�tode setPropietat t� els arrays amb diferents tamanys");
      }

      try {
         m_docSessio = solicitarSessio(pSessio);

         IDfSysObject tmpSysObj = getExistingObject(pIdObjecte, m_docSessio);

         for (int i = 0; pPropietats.length > i; i++) {
            Object tmpValor = pValors[i];
            int tmpIndex = pIndexs[i];
            String tmpPropietat = pPropietats[i];
            int tmpAccio = pAccions[i];

            setPropietat(tmpSysObj, tmpPropietat, tmpValor, tmpIndex, tmpAccio);
         }

         tmpSysObj.save();
      } catch (DfException ex) {
         log.error("Error en el servei de documentum" +
            ex.getStackTraceAsString());

         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_setPropietat",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } catch (DocumentumException ex) {
         log.error("Error en el servei de documentum", ex);
         throw ex;
      } finally {
         alliberarSessio(pSessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi setPropietats()");
   }

   //    public void setPropietat(String idObjecte, String pTipus, String propietat, String valor, Session sessio)
   //    throws DocumentumException {
   //    IDfSession m_docSessio;
   //    logInfo("Dins setPropietat(Id:" + idObjecte + ",Tipus:" + pTipus + ",Propietat:" + propietat + ",Valor:" + valor + ",sessio:" + sessio + ")");
   //    m_docSessio = null;
   //    try
   //    {
   //        m_docSessio = solicitarSessio(sessio);
   //        String tmpDQL = "update " + pTipus + " object set " + propietat + "= '" + valor + "' where r_object_id = '" + idObjecte + "'";
   //        System.out.println("DQL:"+tmpDQL);
   //        
   //        IDfClientX clientx = new DfClientX();
   //        IDfQuery q = clientx.getQuery();
   //        q.setDQL(tmpDQL);
   //        IDfCollection col = q.execute(m_docSessio, 3);
   //        if(col != null)
   //            col.close();
   //        else
   //            throw new DocumentumException(new Throwable("Problemes updatejant l'objecte " + idObjecte), new ExceptionDetails("canigo.services.documentum.bloquejar", null, Layer.SERVICES, Subsystem.UNDEFINED));
   //    }
   //    catch(DfException ex)
   //    {
   //        log.error("Error en el servei de documentum" + ex.getStackTraceAsString());
   //        ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_setPropietat", null, Layer.SERVICES, Subsystem.UNDEFINED);
   //        throw new DocumentumException(ex, exDetails);
   //    }
   //    finally {    
   //    	alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
   //    }
   //    logInfo("Fi setPropietat()");
   //    
   //}

   /**
    * Begin transaction.
    * @param sessio
    */
   public void beginTrans(Session sessio) {
      logInfo("Dins beginTrans(sessio:" + sessio + ")");

      try {
         sessio.getM_documentumSMgr().beginTransaction();
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_begintransaction",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      }

      logInfo("Fi beginTrans()");
   }

   /**
    * Commit transaction.
    * @param sessio
    */
   public void commitTrans(Session sessio) {
      logInfo("Dins commitTrans(sessio:" + sessio + ")");

      try {
         if (sessio.getM_documentumSMgr().isTransactionActive()) {
            sessio.getM_documentumSMgr().commitTransaction();
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_committransaction",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      }

      logInfo("Fi commitTrans()");
   }

   /**
    * Abort transaction.
    * @param sessio
    */
   public void abortTrans(Session sessio) {
      logInfo("Dins abortTrans(sessio:" + sessio + ")");

      try {
         if (sessio.getM_documentumSMgr().isTransactionActive()) {
            sessio.getM_documentumSMgr().abortTransaction();
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.eerror_aborttransaction",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      }

      logInfo("Fi abortTrans()");
   }

   /**
    * Obt� les propietats d'un objete
    *
    * @param idObjecte Identificador de l'objecte
    * @param propietat Nom de la propietat a mostrar la informaci�
    *
    * @return El valor de la propietat
    *
    * @throws DocumentumException
    */
   public String getPropietat(String idObjecte, String propietat, Session sessio)
      throws DocumentumException {
      logInfo("Dins getPropietat(Id:" + idObjecte + ",Propietat:" + propietat +
         "Sessio:" + sessio + ")");

      String valorPropietat = null;

      IDfSession m_docSessio = null;
      m_docSessio = solicitarSessio(sessio);

      IDfSysObject sysObj = getExistingObject(idObjecte, m_docSessio);

      if (sysObj != null) {
         try {
            //alliberarSessio(sessio.getM_documentumSMgr(),m_docSessio);
            valorPropietat = sysObj.getString(propietat);
         } catch (DfException ex) {
            ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_getPropietat",
                  null, Layer.SERVICES, Subsystem.UNDEFINED);

            //exDetails.setProperties(DocumentumProperties);
            throw new DocumentumException(ex, exDetails);
         } finally {
            alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
         }
      } else {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
         throw new DocumentumException(new Throwable(
               "No s'ha pogut localitzar l'objecte " + idObjecte),
            new ExceptionDetails("canigo.services.documentum.bloquejar", null,
               Layer.SERVICES, Subsystem.UNDEFINED));
      }

      logInfo("Fi getPropietat():" + valorPropietat);

      return valorPropietat;
   }

   /**
    * Obt� les propietats d'un objete de tipus repeating
    *
    * @param idObjecte Identificador de l'objecte
    * @param propietat Nom de la propietat a mostrar la informaci�
    *
    * @return El valors de la propietat separats per "|" (pipes)
    *
    * @throws DocumentumException
    */
   public String getPropietatRepeating(String idObjecte, String propietat,
      Session sessio) throws DocumentumException {
      logInfo("getPropietatRepeating inici");

      IDfSession m_docSessio = null;
      m_docSessio = solicitarSessio(sessio);

      IDfSysObject sysObj = getExistingObject(idObjecte, m_docSessio);

      if (sysObj != null) {
         try {
            logInfo("getPropietatRepeating fi");

            return sysObj.getAllRepeatingStrings(propietat, "|");
         } catch (DfException ex) {
            ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_getPropietatRepeating",
                  null, Layer.SERVICES, Subsystem.UNDEFINED);

            //exDetails.setProperties(DocumentumProperties);
            throw new DocumentumException(ex, exDetails);
         } finally {
            alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
            logInfo("getPropietatRepeating fi");
         }
      }

      alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      logInfo("getPropietatRepeating fi");
      throw new DocumentumException(new Throwable(
            "No s'ha pogut localitzar l'objecte " + idObjecte),
         new ExceptionDetails("canigo.services.documentum.bloquejar", null,
            Layer.SERVICES, Subsystem.UNDEFINED));
   }

   /**
    * Mostra la versi� actual d'un document
    *
    * @param idObjecte Identificador del document
    *
    * @return Versi� actual
    *
    * @throws DocumentumException
    */
   public String getVersio(String idObjecte, Session sessio)
      throws DocumentumException {
      String resVersio;
      logInfo("getVersio inici");

      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(sessio);

         IDfSysObject sysObj = getExistingObject(idObjecte, m_docSessio);

         if (sysObj != null) {
            resVersio = sysObj.getImplicitVersionLabel();
         } else {
            throw new DfException("No s'ha pogut localitzar l'objecte " +
               idObjecte);
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_getVersio",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
         logInfo("getVersio fi");
      }

      return resVersio;
   }

   /**
    * Canvia el ACL d'un document
    *
    * @param idObjecte Identificador de l'objecte
    * @param nomACL Nom del ACL
    * @param dominiACL Domini del ACL
    *
    * @throws DocumentumException
    */
   public void canviarAcl(String idObjecte, String nomACL, String dominiACL,
      Session sessio) throws DocumentumException {
      logInfo("canviarAcl inici");

      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(sessio);

         IDfSysObject sysObj = getExistingObject(idObjecte, m_docSessio);

         if (sysObj != null) {
            IDfACL newACL = m_docSessio.getACL(dominiACL, nomACL);

            if (newACL != null) {
               sysObj.setACL(newACL);
               sysObj.save();
            } else {
               throw new DfException(
                  "No s'ha localitzat al sistema la ACL indicad. ACL Name:" +
                  nomACL + ". ACLDomain: " + dominiACL);
            }

            logInfo("ACL modificada correctament");
         } else {
            throw new DfException("No s'ha pogut localitzar l'objecte " +
               idObjecte);
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_canviarAcl",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
         logInfo("canviarAcl fi");
      }
   }

   /**
    * Canviem el cicle de vida d'un objecte
    *
    * @param idObjecte Identificador de l'objecte
    * @param estat Estat inicial del nou cicle de vida
    * @param nomCicleVida Nom del cicle de vida
    *
    * @throws DocumentumException
    */
   public void canviarCicleVida(String idObjecte, String estat,
      String nomCicleVida, Session sessio) throws DocumentumException {
      logInfo("canviarCicleVida inici");

      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(sessio);

         IDfSysObject sysObj = getExistingObject(idObjecte, m_docSessio);
         IDfSysObject sCicleVida = (IDfSysObject) m_docSessio.getObjectByQualification(
               "dm_sysobject where object_name ='" + nomCicleVida + "'");

         if ((sysObj != null) && (sCicleVida != null)) {
            sysObj.attachPolicy(sCicleVida.getId("r_object_id"), estat, null);
            logDebug("Cicle de vida associat correctament");
         } else {
            throw new DfException("No s'ha pogut localitzar l'objecte " +
               idObjecte);
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_canviarCicleVida",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
         logInfo("canviarCicleVida fi");
      }
   }

   /**
    * Canviem l'estat del cicle de vida d'un objecte
    *
    * @param idObjecte Identificador de l'objecte
    * @param estat Nou Estat de l'objecte
    *
    * @throws DocumentumException
    */
   public void canviarEstat(String idObjecte, String estat, Session sessio)
      throws DocumentumException {
      logInfo("canviarEstat inici");

      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(sessio);

         IDfSysObject sysObj = getExistingObject(idObjecte, m_docSessio);

         if (sysObj != null) {
            sysObj.promote(estat, true, false);
            logDebug("Avan�at estat correctament a " + estat);
         } else {
            throw new DfException("No s'ha pogut localitzar l'objecte " +
               idObjecte);
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.canviarEstat",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
         logInfo("canviarEstat fi");
      }
   }

   /**
    * Avan�a un estat del cicle de vida d'un document
    *
    * @param idObjecte Identificador del document
    *
    * @throws DocumentumException
    */
   public void avancarEstat(String idObjecte, Session sessio)
      throws DocumentumException {
      logInfo("avancarEstat inici");

      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(sessio);

         IDfSysObject sysObj = getExistingObject(idObjecte, m_docSessio);

         if (sysObj != null) {
            sysObj.promote(null, true, false);
            logDebug("Avan�at estat correctament");
         } else {
            throw new DfException("No s'ha pogut localitzar l'objecte " +
               idObjecte);
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.avancarEstat",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
         logInfo("avancarEstat fi");
      }
   }

   /**
    * Retrocedeix un estat del cicle de vida d'un document
    *
    * @param idObjecte Identificador del document
    *
    * @throws DocumentumException
    */
   public void retrocedirEstat(String idObjecte, Session sessio)
      throws DocumentumException {
      logInfo("retrocedirEstat inici");

      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(sessio);

         IDfSysObject sysObj = getExistingObject(idObjecte, m_docSessio);

         if (sysObj != null) {
            sysObj.demote(null, false);
            logDebug("Retrocedit estat correctament");
         } else {
            throw new DfException("No s'ha pogut localitzar l'objecte " +
               idObjecte);
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.retrocedirEstat",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
         logInfo("retrocedirEstat fi");
      }
   }

   /**
    * Modificat l'estat d'un document per a fer-lo virtual
    *
    * @param idDocument Identificador del document
    *
    * @throws DocumentumException
    */
   public void crearVirtual(String idDocument, Session sessio)
      throws DocumentumException {
      logInfo("crearVirtual inici");

      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(sessio);

         IDfSysObject sysObj = getExistingObject(idDocument, m_docSessio);

         if (sysObj != null) {
            if (sysObj.isVirtualDocument()) {
               throw new DfException("El document " + idDocument +
                  " ja est� considerat com Document Virtual");
            }

            sysObj.setIsVirtualDocument(true);

            //IDfVirtualDocument vDoc = sysObj.asVirtualDocument("CURRENT", true );
            //IDfVirtualDocumentNode rootNode = vDoc.getRootNode();
            //sysObj.checkout();
            sysObj.save();

            if (!sysObj.isVirtualDocument()) {
               throw new DfException("Document Virtual NO creat correctament: " +
                  idDocument);
            }
         } else {
            throw new DfException("No s'ha pogut localitzar l'objecte " +
               idDocument);
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_crearVirtual",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
         logInfo("crearVirtual fi");
      }
   }

   /**
    * Annexar un fill a un document virtual
    *
    * @param idDocumentFill identificador del fill
    * @param idDocument identificador del pare
    *
    * @throws DocumentumException
    */
   public void annexarFill(String idDocumentFill, String idDocument,
      Session sessio) throws DocumentumException {
      logInfo("annexarFill inici");

      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(sessio);

         IDfClientX clientx = new DfClientX();
         IDfId myIdFill = clientx.getId(idDocumentFill);
         IDfSysObject sysObj = getExistingObject(idDocument, m_docSessio);

         sysObj.appendPart(myIdFill, "CURRENT", false, false, 1);
         sysObj.save();
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_crearVirtual",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
         logInfo("annexarFill fi");
      }
   }

   /**
    * A partir d'una serie de par�metres d'entrada realitza una recerca a la DocBase per buscar documents
    *
    * @param resultats Camps que volem inclou-re en al recerca
    * @param tipus Taula sobre la qual volem realitzar la recerca
    * @param camps Camps pels quals volem filtrar la recerca
    * @param text Text a comparar amb els camps de la recerca
    * @param path Indica el punt de partida dela recerca
    * @param exacte Indicati de si volen filtrar el camp text de manera exacte
    * @param ordre Camps indicant l'ordre de retorn la recerca
    *
    * @return Retorna un HashMap<Integer, Vector>
    *
    * @throws DocumentumException
    */
   public HashMap buscarDocument(String resultats, String tipus, String camps,
      String text, String path, boolean exacte, String ordre, Session sessio)
      throws DocumentumException {
      logInfo("buscarDocument inici");

      try {
         if ((resultats == null) || (resultats.length() == 0)) {
            throw new DfException(
               "El par�metre [resultats] no pot ser NULL o estar buit");
         }

         if ((tipus == null) || (tipus.length() == 0)) {
            throw new DfException(
               "El par�metre [tipus] no pot ser NULL o estar buit");
         }

         if ((camps == null) || (camps.length() == 0)) {
            throw new DfException(
               "El par�metre [camps] no pot ser NULL o estar buit");
         }

         if ((text == null) || (text.length() == 0)) {
            throw new DfException(
               "El par�metre [text] no pot ser NULL o estar buit");
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.buscarDocument",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      }

      StringBuffer myQueryStringB = new StringBuffer();
      myQueryStringB.append("SELECT " + resultats);
      myQueryStringB.append(" FROM  " + tipus);

      if ((path == null) || (path.length() == 0)) {
         myQueryStringB.append(" WHERE ( ");
      } else {
         myQueryStringB.append(" WHERE FOLDER('" + path + "') AND (");
      }

      StringTokenizer myCampsStringT = new StringTokenizer(camps, ",");
      int totalTokens = myCampsStringT.countTokens();
      logDebug("Total de TOKENS " + totalTokens);

      while (myCampsStringT.hasMoreTokens()) {
         myQueryStringB.append(myCampsStringT.nextToken());

         if (exacte) {
            myQueryStringB.append(" = '" + text + "' ");
         } else {
            myQueryStringB.append(" like '%" + text + "%' ");
         }

         if (totalTokens > 1) {
            myQueryStringB.append(" OR ");
            totalTokens--;
         }
      }

      myQueryStringB.append(" ) ");

      if ((ordre != null) && (ordre.length() > 0)) {
         myQueryStringB.append(" ORDER BY " + ordre);
      }

      logDebug("La operacion ser� " + myQueryStringB.toString());

      IDfSession m_docSessio = null;
      HashMap myResult = null;

      try {
         m_docSessio = solicitarSessio(sessio);

         IDfCollection col = execQuery(myQueryStringB.toString(), m_docSessio);

         //	alliberarSessio(sessio.getM_documentumSMgr(),m_docSessio);
         myResult = collection2HashMap(col);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("buscarDocument fi");

      return myResult;
   }

   /**
    * A partir d'una serie de par�metres d'entrada realitza una recerca a la DocBase per buscar documents
    *
    * @param resultats Camps que volem inclou-re en al recerca
    * @param tipus Taula sobre la qual volem realitzar la recerca
    * @param text Text a comparar amb els camps de la recerca
    * @param path Indica el punt de partida dela recerca
    * @param ordre Camps indicant l'ordre de retorn la recerca
    *
    * @return Retorna un HashMap<Integer, Vector>
    *
    * @throws DocumentumException
    */
   public HashMap buscarDocumentFullText(String resultats, String tipus,
      String text, String path, String ordre, Session sessio)
      throws DocumentumException {
      logInfo("buscarDocumentFullText inici");

      try {
         if ((resultats == null) || (resultats.length() == 0)) {
            throw new DfException(
               "El par�metre [resultats] no pot ser NULL o estar buit");
         }

         if ((tipus == null) || (tipus.length() == 0)) {
            throw new DfException(
               "El par�metre [tipus] no pot ser NULL o estar buit");
         }

         if ((text == null) || (text.length() == 0)) {
            throw new DfException(
               "El par�metre [text] no pot ser NULL o estar buit");
         }
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.buscarDocument",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      }

      StringBuffer myQueryStringB = new StringBuffer();
      myQueryStringB.append("SELECT " + resultats);
      myQueryStringB.append(" FROM  " + tipus);
      myQueryStringB.append(" search document contains '" + text + "' ");

      if ((path != null) && (path.length() > 0)) {
         myQueryStringB.append(" WHERE FOLDER('" + path + "') ");
      }

      if ((ordre != null) && (ordre.length() > 0)) {
         myQueryStringB.append(" ORDER BY " + ordre);
      }

      logDebug("La operaci� ser� " + myQueryStringB.toString());

      IDfSession m_docSessio = null;
      IDfCollection col = null;

      try {
         m_docSessio = solicitarSessio(sessio);
         col = execQuery(myQueryStringB.toString(), m_docSessio);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      HashMap myResult = null;

      if (col != null) {
         myResult = collection2HashMap(col);
      }

      logInfo("buscarDocumentFullText fi");

      return myResult;
   }

   /**
    * Executar DQL.
    */
   public void executarUpdateDQL(String pUpdateDQL, Session sessio)
      throws DocumentumException {
      logInfo("Dins executarUpdateDQL(DQL:" + pUpdateDQL + ",sessio:" + sessio +
         ")");

      IDfSession m_docSessio = null;

      try {
         System.out.println("Update DQL:" + pUpdateDQL);

         if (log.isInfoEnabled()) {
            log.info("Update DQL:" + pUpdateDQL);
         }

         IDfClientX clientx = new DfClientX();
         m_docSessio = solicitarSessio(sessio);

         IDfQuery q = clientx.getQuery();
         q.setDQL(pUpdateDQL);

         IDfCollection col = q.execute(m_docSessio, IDfQuery.DF_EXEC_QUERY);

         if (col != null) {
            col.close();
         } else {
            throw new DocumentumException(new Throwable(
                  "Problemes amb UPDATE DQL " + pUpdateDQL),
               new ExceptionDetails("canigo.services.documentum.bloquejar",
                  null, Layer.SERVICES, Subsystem.UNDEFINED));
         }
      } catch (DfException ex) {
         log.error("Error en el servei de documentum" +
            ex.getStackTraceAsString());

         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_execUpdateObject",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("Fi executarUpdateDQL");
   }

   /**
    * Executa una DQL i retorna els resultats
    *
    * @param sDQL  DQL a executar
    *
    * @return Retorna un HashMap<Integer, Vector>
    *
    * @throws DocumentumException
    */
   public HashMap executarDQL(String sDQL, Session sessio)
      throws DocumentumException {
      logInfo("executarDQL inici");
      logDebug("executarDQL: La DQL a executar ser� " + sDQL);

      IDfSession m_docSessio = null;
      HashMap myResult = null;

      try {
         m_docSessio = solicitarSessio(sessio);

         IDfCollection col = execQuery(sDQL, m_docSessio);
         myResult = collection2HashMap(col);
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("executarDQL fi");

      return myResult;
   }

   /**
    * Retorna el nom d'usuari (user_name) a partir del login (user_login_name)
    *
    * @param usuariLogin  Login Usuari
    *
    * @return Retorna un String
    *
    * @throws DocumentumException
    */
   public String buscarNomUsuari(String usuariLogin, Session sessio)
      throws DocumentumException {
      String nomUsuari = "";
      logInfo("Dins buscarNomUsuari(usuariLogin:" + usuariLogin + ")");

      HashMap sHasMap = executarDQL(
            "SELECT user_name from dm_user where user_login_name='" +
            usuariLogin + "'", sessio);

      if (sHasMap != null) {
         if (sHasMap.size() == 1) {
            Vector vOut = (Vector) sHasMap.get(new Integer(1));
            nomUsuari = (String) vOut.get(0);
            logDebug("buscarNomUsuari: Usuari trobat: " + nomUsuari);
         } else {
            logError("buscarNomUsuari: Usuari NO trobat: " + usuariLogin);
         }
      } else {
         logError("buscarNomUsuari: Usuari NO trobat: " + usuariLogin);
      }

      logInfo("Fi buscarNomUsuari");

      return (nomUsuari);
   }

   /**
    * Sol�licita un SessionManager a una DocBase
    *
    * @param usuari Nom de l'usuari
    * @param contrasenya Contrasenya de l'usuari
    * @param docBase DocBase a la que conectar
    *
    *  @return Retorna un element IDfSessionManager amb el pool de connexions
    *
    * @throws DocumentumException
    */
   public IDfSessionManager createDfSession(String usuari, String contrasenya,
      String docBase) throws DocumentumException {
      IDfSession Dfsession = null;
      //SessionImpl session=null;
      logInfo("createDfSession inici");

      try {
         // create Client objects
         IDfClientX clientx = new DfClientX();

         //IDfClient client = clientx.getLocalClient();

         // create an IDfLoginInfo object named loginInfoObj
         IDfLoginInfo loginInfoObj = clientx.getLoginInfo();
         loginInfoObj.setUser(usuari);
         loginInfoObj.setPassword(contrasenya);
         loginInfoObj.setDomain(null);

         // bind the sessio Manager to the login info
         IDfSessionManager m_docSessionManager = dfClient.newSessionManager();
         m_docSessionManager.clearIdentity(docBase);
         m_docSessionManager.setIdentity(docBase, loginInfoObj);
         logInfo("createSessionManager fi");
         Dfsession = m_docSessionManager.newSession(docBase);
         //session=new SessionImpl(Dfsession.getSessionId());
         //String ret=Dfsession.getSessionId();
         m_docSessionManager.release(Dfsession);

         return m_docSessionManager;
      } catch (DfException ex) {
         ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_creating_session_manager",
               null, Layer.SERVICES, Subsystem.UNDEFINED);

         //exDetails.setProperties(DocumentumProperties);
         throw new DocumentumException(ex, exDetails);
      }
   }

   /**
    * Allibera un SessionManager a una DocBase
    *
    * @param sMgr SessionManager a alliberar
    *
    * @throws DocumentumException
    */
   public void closeDfSession(IDfSessionManager sMgr) {
      //  IDfSession DfSession=null;
      //if (sessionId!=null){
      //try{
      //DfSession=dfClient.findSession(sessionId);
      sMgr.clearIdentities();

      //}
   }

   /**
    * Comprova si l'objecte existeix amb aquest identificador.
    * @param strObjId identificador de l'objecte
    * @param sessio sessio
    * @return si existeix l'objecte.
    * @throws DocumentumException
    */
   public boolean existeixObjecte(String strObjId, Session sessio)
      throws DocumentumException {
      logInfo("existeixObjecte(Id:" + strObjId + ",sessio:" + sessio + ")");

      boolean tmpB = false;
      IDfSession m_docSessio = null;

      try {
         m_docSessio = solicitarSessio(sessio);
         tmpB = this.getExistingObject(strObjId, m_docSessio) != null;
      } finally {
         alliberarSessio(sessio.getM_documentumSMgr(), m_docSessio);
      }

      logInfo("existeixObjecte():" + tmpB);

      return tmpB;
   }
}
