/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.BatchRetorn;


/**
 * Java content class for DadesRetornType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/BatchRetorn.xsd line 33)
 * <p>
 * <pre>
 * &lt;complexType name="DadesRetornType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DadaRetorn" maxOccurs="2">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="SocietatFi">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="4"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Exercici">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="4"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="ClasseDocument">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="2"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="NDocument">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="PosicioDocument">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="3"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="StatusDocument">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;enumeration value="S"/>
 *                       &lt;enumeration value="N"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="CodiPosicioError">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="TextError">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="100"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface DadesRetornType {
   /**
    * Gets the value of the DadaRetorn property.
    *
    * <p>
    * This accessor method returns a reference to the live list,
    * not a snapshot. Therefore any modification you make to the
    * returned list will be present inside the JAXB object.
    * This is why there is not a <CODE>set</CODE> method for the DadaRetorn property.
    *
    * <p>
    * For example, to add a new item, do as follows:
    * <pre>
    *    getDadaRetorn().add(newItem);
    * </pre>
    *
    *
    * <p>
    * Objects of the following type(s) are allowed in the list
    * {@link net.gencat.gecat.batch.BatchRetorn.DadesRetornType.DadaRetornType}
    *
    */
   java.util.List getDadaRetorn();

   /**
    * Gets the value of the order property.
    *
    */
   int getOrder();

   /**
    * Sets the value of the order property.
    *
    */
   void setOrder(int value);

   /**
    * Java content class for anonymous complex type.
    *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/BatchRetorn.xsd line 37)
    * <p>
    * <pre>
    * &lt;complexType>
    *   &lt;complexContent>
    *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
    *       &lt;sequence>
    *         &lt;element name="SocietatFi">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="4"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="Exercici">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="4"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="ClasseDocument">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="2"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="NDocument">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="10"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="PosicioDocument">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="3"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="StatusDocument">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;enumeration value="S"/>
    *             &lt;enumeration value="N"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="CodiPosicioError">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="10"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="TextError">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="100"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *       &lt;/sequence>
    *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
    *     &lt;/restriction>
    *   &lt;/complexContent>
    * &lt;/complexType>
    * </pre>
    *
    */
   public interface DadaRetornType {
      /**
       * Gets the value of the classeDocument property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getClasseDocument();

      /**
       * Sets the value of the classeDocument property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setClasseDocument(java.lang.String value);

      /**
       * Gets the value of the statusDocument property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getStatusDocument();

      /**
       * Sets the value of the statusDocument property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setStatusDocument(java.lang.String value);

      /**
       * Gets the value of the nDocument property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getNDocument();

      /**
       * Sets the value of the nDocument property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setNDocument(java.lang.String value);

      /**
       * Gets the value of the societatFi property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getSocietatFi();

      /**
       * Sets the value of the societatFi property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setSocietatFi(java.lang.String value);

      /**
       * Gets the value of the order property.
       *
       */
      int getOrder();

      /**
       * Sets the value of the order property.
       *
       */
      void setOrder(int value);

      /**
       * Gets the value of the exercici property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getExercici();

      /**
       * Sets the value of the exercici property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setExercici(java.lang.String value);

      /**
       * Gets the value of the textError property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getTextError();

      /**
       * Sets the value of the textError property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setTextError(java.lang.String value);

      /**
       * Gets the value of the posicioDocument property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getPosicioDocument();

      /**
       * Sets the value of the posicioDocument property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setPosicioDocument(java.lang.String value);

      /**
       * Gets the value of the codiPosicioError property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getCodiPosicioError();

      /**
       * Sets the value of the codiPosicioError property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setCodiPosicioError(java.lang.String value);
   }
}
