/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsMPEHelper;


/**
 * Java content class for DadesPagadorAlternatiuType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsMPEHelper.xsd line 206)
 * <p>
 * <pre>
 * &lt;complexType name="DadesPagadorAlternatiuType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="AdrecaLength" type="{http://www.w3.org/2001/XMLSchema}int" default="35" />
 *       &lt;attribute name="AdrecaOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
 *       &lt;attribute name="BlocImputacioLength" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="BlocImputacioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="12" />
 *       &lt;attribute name="ClauBancLength" type="{http://www.w3.org/2001/XMLSchema}int" default="15" />
 *       &lt;attribute name="ClauBancOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="7" />
 *       &lt;attribute name="CodiPostalLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *       &lt;attribute name="CodiPostalOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
 *       &lt;attribute name="CompteLength" type="{http://www.w3.org/2001/XMLSchema}int" default="18" />
 *       &lt;attribute name="CompteOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
 *       &lt;attribute name="DigitsControlLength" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *       &lt;attribute name="DigitsControlOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="9" />
 *       &lt;attribute name="NIFLength" type="{http://www.w3.org/2001/XMLSchema}int" default="16" />
 *       &lt;attribute name="NIFOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="11" />
 *       &lt;attribute name="NomLength" type="{http://www.w3.org/2001/XMLSchema}int" default="35" />
 *       &lt;attribute name="NomOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *       &lt;attribute name="PaisBancLength" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
 *       &lt;attribute name="PaisBancOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *       &lt;attribute name="PaisLength" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
 *       &lt;attribute name="PaisOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="6" />
 *       &lt;attribute name="PoblacioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="35" />
 *       &lt;attribute name="PoblacioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *       &lt;attribute name="TipusRegistreLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *       &lt;attribute name="TipusRegistreOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface DadesPagadorAlternatiuType {
   /**
    * Gets the value of the paisBancLength property.
    *
    */
   int getPaisBancLength();

   /**
    * Sets the value of the paisBancLength property.
    *
    */
   void setPaisBancLength(int value);

   /**
    * Gets the value of the codiPostalOrder property.
    *
    */
   int getCodiPostalOrder();

   /**
    * Sets the value of the codiPostalOrder property.
    *
    */
   void setCodiPostalOrder(int value);

   /**
    * Gets the value of the order property.
    *
    */
   int getOrder();

   /**
    * Sets the value of the order property.
    *
    */
   void setOrder(int value);

   /**
    * Gets the value of the adrecaLength property.
    *
    */
   int getAdrecaLength();

   /**
    * Sets the value of the adrecaLength property.
    *
    */
   void setAdrecaLength(int value);

   /**
    * Gets the value of the adrecaOrder property.
    *
    */
   int getAdrecaOrder();

   /**
    * Sets the value of the adrecaOrder property.
    *
    */
   void setAdrecaOrder(int value);

   /**
    * Gets the value of the poblacioLength property.
    *
    */
   int getPoblacioLength();

   /**
    * Sets the value of the poblacioLength property.
    *
    */
   void setPoblacioLength(int value);

   /**
    * Gets the value of the paisOrder property.
    *
    */
   int getPaisOrder();

   /**
    * Sets the value of the paisOrder property.
    *
    */
   void setPaisOrder(int value);

   /**
    * Gets the value of the paisBancOrder property.
    *
    */
   int getPaisBancOrder();

   /**
    * Sets the value of the paisBancOrder property.
    *
    */
   void setPaisBancOrder(int value);

   /**
    * Gets the value of the digitsControlLength property.
    *
    */
   int getDigitsControlLength();

   /**
    * Sets the value of the digitsControlLength property.
    *
    */
   void setDigitsControlLength(int value);

   /**
    * Gets the value of the digitsControlOrder property.
    *
    */
   int getDigitsControlOrder();

   /**
    * Sets the value of the digitsControlOrder property.
    *
    */
   void setDigitsControlOrder(int value);

   /**
    * Gets the value of the tipusRegistreOrder property.
    *
    */
   int getTipusRegistreOrder();

   /**
    * Sets the value of the tipusRegistreOrder property.
    *
    */
   void setTipusRegistreOrder(int value);

   /**
    * Gets the value of the poblacioOrder property.
    *
    */
   int getPoblacioOrder();

   /**
    * Sets the value of the poblacioOrder property.
    *
    */
   void setPoblacioOrder(int value);

   /**
    * Gets the value of the codiPostalLength property.
    *
    */
   int getCodiPostalLength();

   /**
    * Sets the value of the codiPostalLength property.
    *
    */
   void setCodiPostalLength(int value);

   /**
    * Gets the value of the clauBancLength property.
    *
    */
   int getClauBancLength();

   /**
    * Sets the value of the clauBancLength property.
    *
    */
   void setClauBancLength(int value);

   /**
    * Gets the value of the clauBancOrder property.
    *
    */
   int getClauBancOrder();

   /**
    * Sets the value of the clauBancOrder property.
    *
    */
   void setClauBancOrder(int value);

   /**
    * Gets the value of the nifLength property.
    *
    */
   int getNIFLength();

   /**
    * Sets the value of the nifLength property.
    *
    */
   void setNIFLength(int value);

   /**
    * Gets the value of the tipusRegistreLength property.
    *
    */
   int getTipusRegistreLength();

   /**
    * Sets the value of the tipusRegistreLength property.
    *
    */
   void setTipusRegistreLength(int value);

   /**
    * Gets the value of the nomLength property.
    *
    */
   int getNomLength();

   /**
    * Sets the value of the nomLength property.
    *
    */
   void setNomLength(int value);

   /**
    * Gets the value of the nifOrder property.
    *
    */
   int getNIFOrder();

   /**
    * Sets the value of the nifOrder property.
    *
    */
   void setNIFOrder(int value);

   /**
    * Gets the value of the compteLength property.
    *
    */
   int getCompteLength();

   /**
    * Sets the value of the compteLength property.
    *
    */
   void setCompteLength(int value);

   /**
    * Gets the value of the blocImputacioOrder property.
    *
    */
   int getBlocImputacioOrder();

   /**
    * Sets the value of the blocImputacioOrder property.
    *
    */
   void setBlocImputacioOrder(int value);

   /**
    * Gets the value of the blocImputacioLength property.
    *
    */
   int getBlocImputacioLength();

   /**
    * Sets the value of the blocImputacioLength property.
    *
    */
   void setBlocImputacioLength(int value);

   /**
    * Gets the value of the nomOrder property.
    *
    */
   int getNomOrder();

   /**
    * Sets the value of the nomOrder property.
    *
    */
   void setNomOrder(int value);

   /**
    * Gets the value of the compteOrder property.
    *
    */
   int getCompteOrder();

   /**
    * Sets the value of the compteOrder property.
    *
    */
   void setCompteOrder(int value);

   /**
    * Gets the value of the paisLength property.
    *
    */
   int getPaisLength();

   /**
    * Sets the value of the paisLength property.
    *
    */
   void setPaisLength(int value);
}
