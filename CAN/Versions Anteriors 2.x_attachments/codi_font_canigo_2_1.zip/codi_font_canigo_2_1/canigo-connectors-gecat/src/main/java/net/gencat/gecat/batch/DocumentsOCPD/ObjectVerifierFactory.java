/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPD;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class ObjectVerifierFactory extends de.fzi.dbs.verification.ObjectVerifierFactory {
   static {
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.DadesCreditorCPDType.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesCreditorCPDTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.impl.DadesCreditorCPDTypeImpl.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesCreditorCPDTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.DadesPagadorAlternatiuType.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesPagadorAlternatiuTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.impl.DadesPagadorAlternatiuTypeImpl.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesPagadorAlternatiuTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.DadesDocumentsOCPDType.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesDocumentsOCPDTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.impl.DadesDocumentsOCPDTypeImpl.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesDocumentsOCPDTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.RetencionsTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.impl.RetencionsTypeImpl.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.RetencionsTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.DadesGeneralsType.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesGeneralsTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.impl.DadesGeneralsTypeImpl.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesGeneralsTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.BlocImputacioType.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.BlocImputacioTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.impl.BlocImputacioTypeImpl.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.BlocImputacioTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.DadesPosicioType.DadaPosicioType.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesPosicioTypeVerifier.DadaPosicioTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.impl.DadesPosicioTypeImpl.DadaPosicioTypeImpl.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesPosicioTypeVerifier.DadaPosicioTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.DadesDocumentsOCPD.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesDocumentsOCPDVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.impl.DadesDocumentsOCPDImpl.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesDocumentsOCPDVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.RetencionsTypeVerifier.DadaRetencioTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.impl.RetencionsTypeImpl.DadaRetencioTypeImpl.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.RetencionsTypeVerifier.DadaRetencioTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.DadesPosicioType.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesPosicioTypeVerifier.class);
      objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOCPD.impl.DadesPosicioTypeImpl.class,
         net.gencat.gecat.batch.DocumentsOCPD.verification.DadesPosicioTypeVerifier.class);
   }
}
