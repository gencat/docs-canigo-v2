/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsMPE;


/**
 * Java content class for BlocImputacioType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsMPE.xsd line 422)
 * <p>
 * <pre>
 * &lt;complexType name="BlocImputacioType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Retencions" type="{}RetencionsType"/>
 *         &lt;element name="TipusRegistre">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="1"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="Reference">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="16"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="Vendor">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="10"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface BlocImputacioType {
   /**
    * Gets the value of the tipusRegistre property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getTipusRegistre();

   /**
    * Sets the value of the tipusRegistre property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setTipusRegistre(java.lang.String value);

   /**
    * Gets the value of the reference property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getReference();

   /**
    * Sets the value of the reference property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setReference(java.lang.String value);

   /**
    * Gets the value of the vendor property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getVendor();

   /**
    * Sets the value of the vendor property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setVendor(java.lang.String value);

   /**
    * Gets the value of the retencions property.
    *
    * @return
    *     possible object is
    *     {@link net.gencat.gecat.batch.DocumentsMPE.RetencionsType}
    */
   net.gencat.gecat.batch.DocumentsMPE.RetencionsType getRetencions();

   /**
    * Sets the value of the retencions property.
    *
    * @param value
    *     allowed object is
    *     {@link net.gencat.gecat.batch.DocumentsMPE.RetencionsType}
    */
   void setRetencions(net.gencat.gecat.batch.DocumentsMPE.RetencionsType value);
}
