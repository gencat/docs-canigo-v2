/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsO.impl.runtime;

import javax.xml.bind.ValidationEvent;
import javax.xml.bind.helpers.PrintConversionEventImpl;
import javax.xml.bind.helpers.ValidationEventImpl;
import javax.xml.bind.helpers.ValidationEventLocatorImpl;

import com.sun.xml.bind.Messages;
import com.sun.xml.bind.serializer.AbortSerializationException;
import com.sun.xml.bind.util.ValidationEventLocatorExImpl;

import org.xml.sax.SAXException;


/**
 *
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class Util {
   /**
    * Reports a print conversion error while marshalling.
    */
   public static void handlePrintConversionException(Object caller,
      Exception e, XMLSerializer serializer) throws SAXException {
      if (e instanceof SAXException) {
         // assume this exception is not from application.
         // (e.g., when a marshaller aborts the processing, this exception
         //        will be thrown) 
         throw (SAXException) e;
      }

      String message = e.getMessage();

      if (message == null) {
         message = e.toString();
      }

      ValidationEvent ve = new PrintConversionEventImpl(ValidationEvent.ERROR,
            message, new ValidationEventLocatorImpl(caller), e);
      serializer.reportError(ve);
   }

   /**
    * Reports that the type of an object in a property is unexpected.
    */
   public static void handleTypeMismatchError(XMLSerializer serializer,
      Object parentObject, String fieldName, Object childObject)
      throws AbortSerializationException {
      ValidationEvent ve = new ValidationEventImpl(ValidationEvent.ERROR, // maybe it should be a fatal error.
            Messages.format(Messages.ERR_TYPE_MISMATCH,
               getUserFriendlyTypeName(parentObject), fieldName,
               getUserFriendlyTypeName(childObject)),
            new ValidationEventLocatorExImpl(parentObject, fieldName));

      serializer.reportError(ve);
   }

   /**
    * Documentaci�.
    *
    * @param o Documentaci�
    *
    * @return Documentaci�
    */
   private static String getUserFriendlyTypeName(Object o) {
      if (o instanceof ValidatableObject) {
         return ((ValidatableObject) o).getPrimaryInterface().getName();
      } else {
         return o.getClass().getName();
      }
   }
}
