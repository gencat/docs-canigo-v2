/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.BatchRetorn.impl.runtime;

import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.PropertyException;
import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventHandler;
import javax.xml.bind.ValidationException;
import javax.xml.bind.Validator;
import javax.xml.bind.helpers.DefaultValidationEventHandler;

import com.sun.xml.bind.DatatypeConverterImpl;
import com.sun.xml.bind.validator.Messages;

import org.xml.sax.SAXException;


/**
 * Validator implementation of JAXB RI.
 */
public class ValidatorImpl implements Validator {
   /**
    * Documentaci�.
    */
   final DefaultJAXBContextImpl jaxbContext;

   /** Validation errors will be reported to this object. */
   private ValidationEventHandler eventHandler = new DefaultValidationEventHandler();

   /**
    * Creates a new ValidatorImpl object.
    *
    * @param c DOCUMENT ME.
    */
   public ValidatorImpl(DefaultJAXBContextImpl c) {
      // initialize datatype converter with ours
      DatatypeConverter.setDatatypeConverter(DatatypeConverterImpl.theInstance);

      jaxbContext = c;
   }

   /**
    * Documentaci�.
    *
    * @param o Documentaci�
    *
    * @return Documentaci�
    *
    * @throws ValidationException Documentaci�
    * @throws IllegalArgumentException Documentaci�
    */
   public boolean validateRoot(Object o) throws ValidationException {
      if (o == null) {
         throw new IllegalArgumentException(Messages.format(
               Messages.MUST_NOT_BE_NULL, "rootObj"));
      }

      return validate(o, true);
   }

   /**
    * Documentaci�.
    *
    * @param o Documentaci�
    *
    * @return Documentaci�
    *
    * @throws ValidationException Documentaci�
    * @throws IllegalArgumentException Documentaci�
    */
   public boolean validate(Object o) throws ValidationException {
      if (o == null) {
         throw new IllegalArgumentException(Messages.format(
               Messages.MUST_NOT_BE_NULL, "subrootObj"));
      }

      return validate(o, false);
   }

   /**
    * Documentaci�.
    *
    * @param o Documentaci�
    * @param validateId Documentaci�
    *
    * @return Documentaci�
    *
    * @throws ValidationException Documentaci�
    */
   private boolean validate(Object o, boolean validateId)
      throws ValidationException {
      try {
         //ValidatableObject vo = Util.toValidatableObject(o);
         ValidatableObject vo = jaxbContext.getGrammarInfo()
                                           .castToValidatableObject(o);

         if (vo == null) {
            throw new ValidationException(Messages.format(
                  Messages.NOT_VALIDATABLE));
         }

         EventInterceptor ei = new EventInterceptor(eventHandler);
         ValidationContext context = new ValidationContext(jaxbContext, ei,
               validateId);
         context.validate(vo);
         context.reconcileIDs();

         return !ei.hadError();
      } catch (SAXException e) {
         // we need a consistent mechanism to convert SAXException into JAXBException
         Exception nested = e.getException();

         if (nested != null) {
            throw new ValidationException(nested);
         } else {
            throw new ValidationException(e);
         }

         //return false;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ValidationEventHandler getEventHandler() {
      return eventHandler;
   }

   /**
    * Documentaci�.
    *
    * @param handler Documentaci�
    */
   public void setEventHandler(ValidationEventHandler handler) {
      if (handler == null) {
         eventHandler = new DefaultValidationEventHandler();
      } else {
         eventHandler = handler;
      }
   }

   /**
    * There are no required properties, so simply throw an exception.  Other
    * providers may have support for properties on Validator, but the RI doesn't
    */
   public void setProperty(String name, Object value) throws PropertyException {
      if (name == null) {
         throw new IllegalArgumentException(Messages.format(
               Messages.MUST_NOT_BE_NULL, "name"));
      }

      throw new PropertyException(name, value);
   }

   /**
    * There are no required properties, so simply throw an exception.  Other
    * providers may have support for properties on Validator, but the RI doesn't
    */
   public Object getProperty(String name) throws PropertyException {
      if (name == null) {
         throw new IllegalArgumentException(Messages.format(
               Messages.MUST_NOT_BE_NULL, "name"));
      }

      throw new PropertyException(name);
   }

   /**
    * We need to know whether an validation error was detected or not.
    * For this purpose, we set up the validation so that this interceptor
    * will "intercept" errors before the application receives it.
    */
   private static class EventInterceptor implements ValidationEventHandler {
      /** event will be passed to this component. */
      private final ValidationEventHandler next;

      /**
       * Documentaci�.
       */
      private boolean hadError = false;

      /**
       * Creates a new EventInterceptor object.
       *
       * @param _next DOCUMENT ME.
       */
      EventInterceptor(ValidationEventHandler _next) {
         this.next = _next;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public boolean hadError() {
         return hadError;
      }

      /**
       * Documentaci�.
       *
       * @param e Documentaci�
       *
       * @return Documentaci�
       */
      public boolean handleEvent(ValidationEvent e) {
         hadError = true;

         boolean result;

         if (next != null) {
            // pass it to the application
            try {
               result = next.handleEvent(e);
            } catch (RuntimeException re) {
               // if the client event handler causes a RuntimeException,
               // then we have to return false
               result = false;
            }
         } else {
            // if no error handler was specified, there is no point
            // in continuing the validation.
            result = false;
         }

         return result;
      }
   }
}
