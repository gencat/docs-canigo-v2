/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime;

import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;


/**
 * Receives SAX2 events and send the equivalent events to
 * {@link com.sun.xml.bind.serializer.XMLSerializer}
 *
 * @author
 *     Kohsuke Kawaguchi (kohsuke.kawaguchi@sun.com)
 */
public class ContentHandlerAdaptor implements ContentHandler {
   /** Stores newly declared prefix-URI mapping. */
   private final ArrayList prefixMap = new ArrayList();

   /**
    * Documentaci�.
    */
   private final StringBuffer text = new StringBuffer();

   /** Events will be sent to this object. */
   private final XMLSerializer serializer;

   /**
    * Creates a new ContentHandlerAdaptor object.
    *
    * @param _serializer DOCUMENT ME.
    */
   public ContentHandlerAdaptor(XMLSerializer _serializer) {
      this.serializer = _serializer;
   }

   /**
    * Documentaci�.
    *
    * @throws SAXException Documentaci�
    */
   public void startDocument() throws SAXException {
      prefixMap.clear();
   }

   /**
    * Documentaci�.
    *
    * @throws SAXException Documentaci�
    */
   public void endDocument() throws SAXException {
   }

   /**
    * Documentaci�.
    *
    * @param prefix Documentaci�
    * @param uri Documentaci�
    *
    * @throws SAXException Documentaci�
    */
   public void startPrefixMapping(String prefix, String uri)
      throws SAXException {
      prefixMap.add(prefix);
      prefixMap.add(uri);
   }

   /**
    * Documentaci�.
    *
    * @param prefix Documentaci�
    *
    * @throws SAXException Documentaci�
    */
   public void endPrefixMapping(String prefix) throws SAXException {
   }

   /**
    * Documentaci�.
    *
    * @param namespaceURI Documentaci�
    * @param localName Documentaci�
    * @param qName Documentaci�
    * @param atts Documentaci�
    *
    * @throws SAXException Documentaci�
    */
   public void startElement(String namespaceURI, String localName,
      String qName, Attributes atts) throws SAXException {
      flushText();

      int len = atts.getLength();

      serializer.startElement(namespaceURI, localName);

      // declare namespace events
      for (int i = 0; i < len; i++) {
         String qname = atts.getQName(i);
         int idx = qname.indexOf(':');
         String prefix = (idx == -1) ? qname : qname.substring(0, idx);

         serializer.getNamespaceContext()
                   .declareNamespace(atts.getURI(i), prefix, true);
      }

      for (int i = 0; i < prefixMap.size(); i += 2) {
         String prefix = (String) prefixMap.get(i);
         serializer.getNamespaceContext()
                   .declareNamespace((String) prefixMap.get(i + 1), prefix,
            prefix.length() != 0);
      }

      serializer.endNamespaceDecls();

      // fire attribute events
      for (int i = 0; i < len; i++) {
         serializer.startAttribute(atts.getURI(i), atts.getLocalName(i));
         serializer.text(atts.getValue(i), null);
         serializer.endAttribute();
      }

      prefixMap.clear();
      serializer.endAttributes();
   }

   /**
    * Documentaci�.
    *
    * @param namespaceURI Documentaci�
    * @param localName Documentaci�
    * @param qName Documentaci�
    *
    * @throws SAXException Documentaci�
    */
   public void endElement(String namespaceURI, String localName, String qName)
      throws SAXException {
      flushText();
      serializer.endElement();
   }

   /**
    * Documentaci�.
    *
    * @throws SAXException Documentaci�
    */
   private void flushText() throws SAXException {
      if (text.length() != 0) {
         serializer.text(text.toString(), null);
         text.setLength(0);
      }
   }

   /**
    * Documentaci�.
    *
    * @param ch Documentaci�
    * @param start Documentaci�
    * @param length Documentaci�
    *
    * @throws SAXException Documentaci�
    */
   public void characters(char[] ch, int start, int length)
      throws SAXException {
      text.append(ch, start, length);
   }

   /**
    * Documentaci�.
    *
    * @param ch Documentaci�
    * @param start Documentaci�
    * @param length Documentaci�
    *
    * @throws SAXException Documentaci�
    */
   public void ignorableWhitespace(char[] ch, int start, int length)
      throws SAXException {
      text.append(ch, start, length);
   }

   /**
    * Documentaci�.
    *
    * @param locator Documentaci�
    */
   public void setDocumentLocator(Locator locator) {
   }

   /**
    * Documentaci�.
    *
    * @param target Documentaci�
    * @param data Documentaci�
    *
    * @throws SAXException Documentaci�
    */
   public void processingInstruction(String target, String data)
      throws SAXException {
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    *
    * @throws SAXException Documentaci�
    */
   public void skippedEntity(String name) throws SAXException {
   }
}
