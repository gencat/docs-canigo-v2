/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPDHelper.impl;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class RetencionsTypeImpl implements net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType,
   com.sun.xml.bind.JAXBObject,
   net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.XMLSerializable,
   net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.ValidatableObject {
   /**
    * Documentaci�.
    */
   public static final java.lang.Class version = (net.gencat.gecat.batch.DocumentsOCPDHelper.impl.JAXBVersion.class);

   /**
    * Documentaci�.
    */
   private static com.sun.msv.grammar.Grammar schemaFragment;

   /**
    * Documentaci�.
    */
   protected com.sun.xml.bind.util.ListImpl _DadaRetencio;

   /**
    * Documentaci�.
    */
   protected boolean has_Order;

   /**
    * Documentaci�.
    */
   protected int _Order;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private static final java.lang.Class PRIMARY_INTERFACE_CLASS() {
      return (net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.class);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected com.sun.xml.bind.util.ListImpl _getDadaRetencio() {
      if (_DadaRetencio == null) {
         _DadaRetencio = new com.sun.xml.bind.util.ListImpl(new java.util.ArrayList());
      }

      return _DadaRetencio;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public java.util.List getDadaRetencio() {
      return _getDadaRetencio();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getOrder() {
      if (!has_Order) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "5"));
      } else {
         return _Order;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setOrder(int value) {
      _Order = value;
      has_Order = true;
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeBody(
      net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
      int idx1 = 0;
      final int len1 = ((_DadaRetencio == null) ? 0 : _DadaRetencio.size());

      while (idx1 != len1) {
         context.startElement("", "DadaRetencio");

         int idx_0 = idx1;
         context.childAsURIs(((com.sun.xml.bind.JAXBObject) _DadaRetencio.get(
               idx_0++)), "DadaRetencio");
         context.endNamespaceDecls();

         int idx_1 = idx1;
         context.childAsAttributes(((com.sun.xml.bind.JAXBObject) _DadaRetencio.get(
               idx_1++)), "DadaRetencio");
         context.endAttributes();
         context.childAsBody(((com.sun.xml.bind.JAXBObject) _DadaRetencio.get(
               idx1++)), "DadaRetencio");
         context.endElement();
      }
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeAttributes(
      net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
      int idx1 = 0;
      final int len1 = ((_DadaRetencio == null) ? 0 : _DadaRetencio.size());

      if (has_Order) {
         context.startAttribute("", "order");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _Order)), "Order");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      while (idx1 != len1) {
         idx1 += 1;
      }
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeURIs(
      net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
      int idx1 = 0;
      final int len1 = ((_DadaRetencio == null) ? 0 : _DadaRetencio.size());

      while (idx1 != len1) {
         idx1 += 1;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public java.lang.Class getPrimaryInterface() {
      return (net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.class);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
      if (schemaFragment == null) {
         schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
               "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
               "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
               "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
               "expandedExpq\u0000~\u0000\u0002xpppsr\u0000 com.sun.msv.grammar.OneOrMoreExp\u0000\u0000\u0000\u0000" +
               "\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001ccom.sun.msv.grammar.UnaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0003expq\u0000~\u0000" +
               "\u0002xq\u0000~\u0000\u0003ppsr\u0000\'com.sun.msv.grammar.trex.ElementPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
               "\u0002\u0000\u0001L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/NameClass;xr\u0000\u001ecom.sun" +
               ".msv.grammar.ElementExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aignoreUndeclaredAttribu" +
               "tesL\u0000\fcontentModelq\u0000~\u0000\u0002xq\u0000~\u0000\u0003pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\tpp\u0000sr\u0000\u001dcom.sun" +
               ".msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsq\u0000~\u0000\u0006sr\u0000\u0011java.lang" +
               ".Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000 com.sun.msv.grammar.Attri" +
               "buteExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClassq\u0000~\u0000\nxq\u0000~\u0000\u0003q\u0000~\u0000\u0013psr" +
               "\u00002com.sun.msv.grammar.Expression$AnyStringExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
               "\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\u0012\u0001q\u0000~\u0000\u0017sr\u0000 com.sun.msv.grammar.AnyNameClass\u0000\u0000\u0000" +
               "\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000co" +
               "m.sun.msv.grammar.Expression$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000" +
               "~\u0000\u0003q\u0000~\u0000\u0018q\u0000~\u0000\u001dsr\u0000#com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
               "\u0002\u0000\u0002L\u0000\tlocalNamet\u0000\u0012Ljava/lang/String;L\u0000\fnamespaceURIq\u0000~\u0000\u001fxq\u0000~" +
               "\u0000\u001at\u0000Jnet.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsTy" +
               "pe.DadaRetencioTypet\u0000+http://java.sun.com/jaxb/xjc/dummy-ele" +
               "mentssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0014q\u0000~\u0000\u0013psr\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000" +
               "\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002" +
               "L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util/StringPair;xq\u0000~\u0000\u0003ppsr\u0000\"com.sun.m" +
               "sv.datatype.xsd.QnameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype" +
               ".xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datatype.xs" +
               "d.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype.xsd.XSData" +
               "typeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUriq\u0000~\u0000\u001fL\u0000\btypeNameq\u0000~\u0000\u001fL\u0000\nwh" +
               "iteSpacet\u0000.Lcom/sun/msv/datatype/xsd/WhiteSpaceProcessor;xpt" +
               "\u0000 http://www.w3.org/2001/XMLSchemat\u0000\u0005QNamesr\u00005com.sun.msv.da" +
               "tatype.xsd.WhiteSpaceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.su" +
               "n.msv.datatype.xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000com.s" +
               "un.msv.grammar.Expression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003" +
               "ppsr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000" +
               "\u001fL\u0000\fnamespaceURIq\u0000~\u0000\u001fxpq\u0000~\u00000q\u0000~\u0000/sq\u0000~\u0000\u001et\u0000\u0004typet\u0000)http://www." +
               "w3.org/2001/XMLSchema-instanceq\u0000~\u0000\u001dsq\u0000~\u0000\u001et\u0000\fDadaRetenciot\u0000\u0000s" +
               "q\u0000~\u0000\u000fppsq\u0000~\u0000\u0014q\u0000~\u0000\u0013psq\u0000~\u0000%ppsr\u0000 com.sun.msv.datatype.xsd.IntT" +
               "ype\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000+com.sun.msv.datatype.xsd.IntegerDerivedTyp" +
               "e\u0099\u00f1]\u0090&6k\u00be\u0002\u0000\u0001L\u0000\nbaseFacetst\u0000)Lcom/sun/msv/datatype/xsd/XSData" +
               "typeImpl;xq\u0000~\u0000*q\u0000~\u0000/t\u0000\u0003intq\u0000~\u00003sr\u0000*com.sun.msv.datatype.xsd." +
               "MaxInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.datatype.xsd.Ran" +
               "geFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\nlimitValuet\u0000\u0012Ljava/lang/Object;xr\u00009com." +
               "sun.msv.datatype.xsd.DataTypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008a" +
               "T\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000" +
               "\u0005Z\u0000\fisFacetFixedZ\u0000\u0012needValueCheckFlagL\u0000\bbaseTypeq\u0000~\u0000CL\u0000\fconc" +
               "reteTypet\u0000\'Lcom/sun/msv/datatype/xsd/ConcreteType;L\u0000\tfacetNa" +
               "meq\u0000~\u0000\u001fxq\u0000~\u0000,ppq\u0000~\u00003\u0000\u0001sr\u0000*com.sun.msv.datatype.xsd.MinInclus" +
               "iveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Gppq\u0000~\u00003\u0000\u0000sr\u0000!com.sun.msv.datatype.x" +
               "sd.LongType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Bq\u0000~\u0000/t\u0000\u0004longq\u0000~\u00003sq\u0000~\u0000Fppq\u0000~\u00003\u0000\u0001" +
               "sq\u0000~\u0000Mppq\u0000~\u00003\u0000\u0000sr\u0000$com.sun.msv.datatype.xsd.IntegerType\u0000\u0000\u0000\u0000\u0000" +
               "\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Bq\u0000~\u0000/t\u0000\u0007integerq\u0000~\u00003sr\u0000,com.sun.msv.datatype.xsd" +
               ".FractionDigitsFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scalexr\u0000;com.sun.msv.datat" +
               "ype.xsd.DataTypeWithLexicalConstraintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000Jp" +
               "pq\u0000~\u00003\u0001\u0000sr\u0000#com.sun.msv.datatype.xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq" +
               "\u0000~\u0000*q\u0000~\u0000/t\u0000\u0007decimalq\u0000~\u00003q\u0000~\u0000[t\u0000\u000efractionDigits\u0000\u0000\u0000\u0000q\u0000~\u0000Ut\u0000\fmi" +
               "nInclusivesr\u0000\u000ejava.lang.Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010java.lang" +
               ".Number\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u0000Ut\u0000\fmaxInclusivesq\u0000~\u0000_\u007f\u00ff\u00ff\u00ff\u00ff\u00ff" +
               "\u00ff\u00ffq\u0000~\u0000Pq\u0000~\u0000^sr\u0000\u0011java.lang.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000`\u0080\u0000" +
               "\u0000\u0000q\u0000~\u0000Pq\u0000~\u0000bsq\u0000~\u0000d\u007f\u00ff\u00ff\u00ffq\u0000~\u00005sq\u0000~\u00006q\u0000~\u0000Eq\u0000~\u0000/sq\u0000~\u0000\u001et\u0000\u0005orderq\u0000~" +
               "\u0000=q\u0000~\u0000\u001dsr\u0000\"com.sun.msv.grammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\be" +
               "xpTablet\u0000/Lcom/sun/msv/grammar/ExpressionPool$ClosedHash;xps" +
               "r\u0000-com.sun.msv.grammar.ExpressionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I" +
               "\u0000\u0005countB\u0000\rstreamVersionL\u0000\u0006parentt\u0000$Lcom/sun/msv/grammar/Expr" +
               "essionPool;xp\u0000\u0000\u0000\u0007\u0001pq\u0000~\u0000\u0011q\u0000~\u0000#q\u0000~\u0000\bq\u0000~\u0000>q\u0000~\u0000\u0005q\u0000~\u0000\rq\u0000~\u0000\u0010x"));
      }

      return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   public static class DadaRetencioTypeImpl implements net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType,
      com.sun.xml.bind.JAXBObject,
      net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.XMLSerializable,
      net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.ValidatableObject {
      /**
       * Documentaci�.
       */
      public static final java.lang.Class version = (net.gencat.gecat.batch.DocumentsOCPDHelper.impl.JAXBVersion.class);

      /**
       * Documentaci�.
       */
      private static com.sun.msv.grammar.Grammar schemaFragment;

      /**
       * Documentaci�.
       */
      protected boolean has_ImportBaseFieldType;

      /**
       * Documentaci�.
       */
      protected boolean has_ImportBaseLength;

      /**
       * Documentaci�.
       */
      protected boolean has_ImportBaseOrder;

      /**
       * Documentaci�.
       */
      protected boolean has_ImportRetencioFieldType;

      /**
       * Documentaci�.
       */
      protected boolean has_ImportRetencioLength;

      /**
       * Documentaci�.
       */
      protected boolean has_ImportRetencioOrder;

      /**
       * Documentaci�.
       */
      protected boolean has_IndicadorRetencioLength;

      /**
       * Documentaci�.
       */
      protected boolean has_IndicadorRetencioOrder;

      /**
       * Documentaci�.
       */
      protected boolean has_Order;

      /**
       * Documentaci�.
       */
      protected boolean has_TipusRegistreLength;

      /**
       * Documentaci�.
       */
      protected boolean has_TipusRegistreOrder;

      /**
       * Documentaci�.
       */
      protected int _ImportBaseFieldType;

      /**
       * Documentaci�.
       */
      protected int _ImportBaseLength;

      /**
       * Documentaci�.
       */
      protected int _ImportBaseOrder;

      /**
       * Documentaci�.
       */
      protected int _ImportRetencioFieldType;

      /**
       * Documentaci�.
       */
      protected int _ImportRetencioLength;

      /**
       * Documentaci�.
       */
      protected int _ImportRetencioOrder;

      /**
       * Documentaci�.
       */
      protected int _IndicadorRetencioLength;

      /**
       * Documentaci�.
       */
      protected int _IndicadorRetencioOrder;

      /**
       * Documentaci�.
       */
      protected int _Order;

      /**
       * Documentaci�.
       */
      protected int _TipusRegistreLength;

      /**
       * Documentaci�.
       */
      protected int _TipusRegistreOrder;

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      private static final java.lang.Class PRIMARY_INTERFACE_CLASS() {
         return (net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType.class);
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public int getImportBaseLength() {
         if (!has_ImportBaseLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                  "13"));
         } else {
            return _ImportBaseLength;
         }
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setImportBaseLength(int value) {
         _ImportBaseLength = value;
         has_ImportBaseLength = true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public int getImportBaseFieldType() {
         if (!has_ImportBaseFieldType) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                  "1"));
         } else {
            return _ImportBaseFieldType;
         }
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setImportBaseFieldType(int value) {
         _ImportBaseFieldType = value;
         has_ImportBaseFieldType = true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public int getIndicadorRetencioOrder() {
         if (!has_IndicadorRetencioOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                  "2"));
         } else {
            return _IndicadorRetencioOrder;
         }
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setIndicadorRetencioOrder(int value) {
         _IndicadorRetencioOrder = value;
         has_IndicadorRetencioOrder = true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public int getTipusRegistreLength() {
         if (!has_TipusRegistreLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                  "1"));
         } else {
            return _TipusRegistreLength;
         }
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setTipusRegistreLength(int value) {
         _TipusRegistreLength = value;
         has_TipusRegistreLength = true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public int getImportRetencioFieldType() {
         if (!has_ImportRetencioFieldType) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                  "1"));
         } else {
            return _ImportRetencioFieldType;
         }
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setImportRetencioFieldType(int value) {
         _ImportRetencioFieldType = value;
         has_ImportRetencioFieldType = true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public int getTipusRegistreOrder() {
         if (!has_TipusRegistreOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                  "1"));
         } else {
            return _TipusRegistreOrder;
         }
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setTipusRegistreOrder(int value) {
         _TipusRegistreOrder = value;
         has_TipusRegistreOrder = true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public int getOrder() {
         return _Order;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setOrder(int value) {
         _Order = value;
         has_Order = true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public int getIndicadorRetencioLength() {
         if (!has_IndicadorRetencioLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                  "2"));
         } else {
            return _IndicadorRetencioLength;
         }
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setIndicadorRetencioLength(int value) {
         _IndicadorRetencioLength = value;
         has_IndicadorRetencioLength = true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public int getImportRetencioOrder() {
         if (!has_ImportRetencioOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                  "4"));
         } else {
            return _ImportRetencioOrder;
         }
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setImportRetencioOrder(int value) {
         _ImportRetencioOrder = value;
         has_ImportRetencioOrder = true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public int getImportRetencioLength() {
         if (!has_ImportRetencioLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                  "13"));
         } else {
            return _ImportRetencioLength;
         }
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setImportRetencioLength(int value) {
         _ImportRetencioLength = value;
         has_ImportRetencioLength = true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public int getImportBaseOrder() {
         if (!has_ImportBaseOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                  "3"));
         } else {
            return _ImportBaseOrder;
         }
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setImportBaseOrder(int value) {
         _ImportBaseOrder = value;
         has_ImportBaseOrder = true;
      }

      /**
       * Documentaci�.
       *
       * @param context Documentaci�
       *
       */
      public void serializeBody(
         net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.XMLSerializer context)
         throws org.xml.sax.SAXException {
      }

      /**
       * Documentaci�.
       *
       * @param context Documentaci�
       *
       */
      public void serializeAttributes(
         net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.XMLSerializer context)
         throws org.xml.sax.SAXException {
         if (has_ImportBaseFieldType) {
            context.startAttribute("", "ImportBaseFieldType");

            try {
               context.text(javax.xml.bind.DatatypeConverter.printInt(
                     ((int) _ImportBaseFieldType)), "ImportBaseFieldType");
            } catch (java.lang.Exception e) {
               net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                  e, context);
            }

            context.endAttribute();
         }

         if (has_ImportBaseLength) {
            context.startAttribute("", "ImportBaseLength");

            try {
               context.text(javax.xml.bind.DatatypeConverter.printInt(
                     ((int) _ImportBaseLength)), "ImportBaseLength");
            } catch (java.lang.Exception e) {
               net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                  e, context);
            }

            context.endAttribute();
         }

         if (has_ImportBaseOrder) {
            context.startAttribute("", "ImportBaseOrder");

            try {
               context.text(javax.xml.bind.DatatypeConverter.printInt(
                     ((int) _ImportBaseOrder)), "ImportBaseOrder");
            } catch (java.lang.Exception e) {
               net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                  e, context);
            }

            context.endAttribute();
         }

         if (has_ImportRetencioFieldType) {
            context.startAttribute("", "ImportRetencioFieldType");

            try {
               context.text(javax.xml.bind.DatatypeConverter.printInt(
                     ((int) _ImportRetencioFieldType)),
                  "ImportRetencioFieldType");
            } catch (java.lang.Exception e) {
               net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                  e, context);
            }

            context.endAttribute();
         }

         if (has_ImportRetencioLength) {
            context.startAttribute("", "ImportRetencioLength");

            try {
               context.text(javax.xml.bind.DatatypeConverter.printInt(
                     ((int) _ImportRetencioLength)), "ImportRetencioLength");
            } catch (java.lang.Exception e) {
               net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                  e, context);
            }

            context.endAttribute();
         }

         if (has_ImportRetencioOrder) {
            context.startAttribute("", "ImportRetencioOrder");

            try {
               context.text(javax.xml.bind.DatatypeConverter.printInt(
                     ((int) _ImportRetencioOrder)), "ImportRetencioOrder");
            } catch (java.lang.Exception e) {
               net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                  e, context);
            }

            context.endAttribute();
         }

         if (has_IndicadorRetencioLength) {
            context.startAttribute("", "IndicadorRetencioLength");

            try {
               context.text(javax.xml.bind.DatatypeConverter.printInt(
                     ((int) _IndicadorRetencioLength)),
                  "IndicadorRetencioLength");
            } catch (java.lang.Exception e) {
               net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                  e, context);
            }

            context.endAttribute();
         }

         if (has_IndicadorRetencioOrder) {
            context.startAttribute("", "IndicadorRetencioOrder");

            try {
               context.text(javax.xml.bind.DatatypeConverter.printInt(
                     ((int) _IndicadorRetencioOrder)), "IndicadorRetencioOrder");
            } catch (java.lang.Exception e) {
               net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                  e, context);
            }

            context.endAttribute();
         }

         if (has_TipusRegistreLength) {
            context.startAttribute("", "TipusRegistreLength");

            try {
               context.text(javax.xml.bind.DatatypeConverter.printInt(
                     ((int) _TipusRegistreLength)), "TipusRegistreLength");
            } catch (java.lang.Exception e) {
               net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                  e, context);
            }

            context.endAttribute();
         }

         if (has_TipusRegistreOrder) {
            context.startAttribute("", "TipusRegistreOrder");

            try {
               context.text(javax.xml.bind.DatatypeConverter.printInt(
                     ((int) _TipusRegistreOrder)), "TipusRegistreOrder");
            } catch (java.lang.Exception e) {
               net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                  e, context);
            }

            context.endAttribute();
         }

         if (has_Order) {
            context.startAttribute("", "order");

            try {
               context.text(javax.xml.bind.DatatypeConverter.printInt(
                     ((int) _Order)), "Order");
            } catch (java.lang.Exception e) {
               net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                  e, context);
            }

            context.endAttribute();
         }
      }

      /**
       * Documentaci�.
       *
       * @param context Documentaci�
       *
       */
      public void serializeURIs(
         net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.XMLSerializer context)
         throws org.xml.sax.SAXException {
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.Class getPrimaryInterface() {
         return (net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType.class);
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
         if (schemaFragment == null) {
            schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                  "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                  "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                  "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                  "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                  "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsr\u0000\u001dcom.sun.msv.grammar.Choi" +
                  "ceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsr\u0000 com.sun.msv.grammar.AttributeExp" +
                  "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/Na" +
                  "meClass;xq\u0000~\u0000\u0003sr\u0000\u0011java.lang.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr" +
                  "\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng" +
                  "/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util" +
                  "/StringPair;xq\u0000~\u0000\u0003ppsr\u0000 com.sun.msv.datatype.xsd.IntType\u0000\u0000\u0000\u0000" +
                  "\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000+com.sun.msv.datatype.xsd.IntegerDerivedType\u0099\u00f1]\u0090&6" +
                  "k\u00be\u0002\u0000\u0001L\u0000\nbaseFacetst\u0000)Lcom/sun/msv/datatype/xsd/XSDatatypeImp" +
                  "l;xr\u0000*com.sun.msv.datatype.xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000x" +
                  "r\u0000%com.sun.msv.datatype.xsd.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.s" +
                  "un.msv.datatype.xsd.XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUri" +
                  "t\u0000\u0012Ljava/lang/String;L\u0000\btypeNameq\u0000~\u0000 L\u0000\nwhiteSpacet\u0000.Lcom/su" +
                  "n/msv/datatype/xsd/WhiteSpaceProcessor;xpt\u0000 http://www.w3.or" +
                  "g/2001/XMLSchemat\u0000\u0003intsr\u00005com.sun.msv.datatype.xsd.WhiteSpac" +
                  "eProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datatype.xsd.W" +
                  "hiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u0000*com.sun.msv.datatype.xsd." +
                  "MaxInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.datatype.xsd.Ran" +
                  "geFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\nlimitValuet\u0000\u0012Ljava/lang/Object;xr\u00009com." +
                  "sun.msv.datatype.xsd.DataTypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008a" +
                  "T\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000" +
                  "\u0005Z\u0000\fisFacetFixedZ\u0000\u0012needValueCheckFlagL\u0000\bbaseTypeq\u0000~\u0000\u001cL\u0000\fconc" +
                  "reteTypet\u0000\'Lcom/sun/msv/datatype/xsd/ConcreteType;L\u0000\tfacetNa" +
                  "meq\u0000~\u0000 xq\u0000~\u0000\u001fppq\u0000~\u0000\'\u0000\u0001sr\u0000*com.sun.msv.datatype.xsd.MinInclus" +
                  "iveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000)ppq\u0000~\u0000\'\u0000\u0000sr\u0000!com.sun.msv.datatype.x" +
                  "sd.LongType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u001bq\u0000~\u0000#t\u0000\u0004longq\u0000~\u0000\'sq\u0000~\u0000(ppq\u0000~\u0000\'\u0000\u0001" +
                  "sq\u0000~\u0000/ppq\u0000~\u0000\'\u0000\u0000sr\u0000$com.sun.msv.datatype.xsd.IntegerType\u0000\u0000\u0000\u0000\u0000" +
                  "\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u001bq\u0000~\u0000#t\u0000\u0007integerq\u0000~\u0000\'sr\u0000,com.sun.msv.datatype.xsd" +
                  ".FractionDigitsFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scalexr\u0000;com.sun.msv.datat" +
                  "ype.xsd.DataTypeWithLexicalConstraintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000,p" +
                  "pq\u0000~\u0000\'\u0001\u0000sr\u0000#com.sun.msv.datatype.xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq" +
                  "\u0000~\u0000\u001dq\u0000~\u0000#t\u0000\u0007decimalq\u0000~\u0000\'q\u0000~\u0000=t\u0000\u000efractionDigits\u0000\u0000\u0000\u0000q\u0000~\u00007t\u0000\fmi" +
                  "nInclusivesr\u0000\u000ejava.lang.Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010java.lang" +
                  ".Number\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u00007t\u0000\fmaxInclusivesq\u0000~\u0000A\u007f\u00ff\u00ff\u00ff\u00ff\u00ff" +
                  "\u00ff\u00ffq\u0000~\u00002q\u0000~\u0000@sr\u0000\u0011java.lang.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000B\u0080\u0000" +
                  "\u0000\u0000q\u0000~\u00002q\u0000~\u0000Dsq\u0000~\u0000F\u007f\u00ff\u00ff\u00ffsr\u00000com.sun.msv.grammar.Expression$Nul" +
                  "lSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun.msv.util.String" +
                  "Pair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000 L\u0000\fnamespaceURIq\u0000~\u0000 xpq\u0000~\u0000$q" +
                  "\u0000~\u0000#sr\u0000#com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tloc" +
                  "alNameq\u0000~\u0000 L\u0000\fnamespaceURIq\u0000~\u0000 xr\u0000\u001dcom.sun.msv.grammar.NameC" +
                  "lass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpt\u0000\u0013ImportBaseFieldTypet\u0000\u0000sr\u00000com.sun.msv.gr" +
                  "ammar.Expression$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\u0014\u0001q\u0000" +
                  "~\u0000Ssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0011q\u0000~\u0000\u0015pq\u0000~\u0000\u0019sq\u0000~\u0000Mt\u0000\u0010ImportBaseLengthq\u0000~\u0000Qq\u0000" +
                  "~\u0000Ssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0011q\u0000~\u0000\u0015pq\u0000~\u0000\u0019sq\u0000~\u0000Mt\u0000\u000fImportBaseOrderq\u0000~\u0000Qq\u0000~" +
                  "\u0000Ssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0011q\u0000~\u0000\u0015pq\u0000~\u0000\u0019sq\u0000~\u0000Mt\u0000\u0017ImportRetencioFieldTypeq" +
                  "\u0000~\u0000Qq\u0000~\u0000Ssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0011q\u0000~\u0000\u0015pq\u0000~\u0000\u0019sq\u0000~\u0000Mt\u0000\u0014ImportRetencioLen" +
                  "gthq\u0000~\u0000Qq\u0000~\u0000Ssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0011q\u0000~\u0000\u0015pq\u0000~\u0000\u0019sq\u0000~\u0000Mt\u0000\u0013ImportRetenci" +
                  "oOrderq\u0000~\u0000Qq\u0000~\u0000Ssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0011q\u0000~\u0000\u0015pq\u0000~\u0000\u0019sq\u0000~\u0000Mt\u0000\u0017IndicadorR" +
                  "etencioLengthq\u0000~\u0000Qq\u0000~\u0000Ssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0011q\u0000~\u0000\u0015pq\u0000~\u0000\u0019sq\u0000~\u0000Mt\u0000\u0016Ind" +
                  "icadorRetencioOrderq\u0000~\u0000Qq\u0000~\u0000Ssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0011q\u0000~\u0000\u0015pq\u0000~\u0000\u0019sq\u0000~\u0000M" +
                  "t\u0000\u0013TipusRegistreLengthq\u0000~\u0000Qq\u0000~\u0000Ssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0011q\u0000~\u0000\u0015pq\u0000~\u0000\u0019sq\u0000" +
                  "~\u0000Mt\u0000\u0012TipusRegistreOrderq\u0000~\u0000Qq\u0000~\u0000Ssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0011q\u0000~\u0000\u0015pq\u0000~\u0000\u0019s" +
                  "q\u0000~\u0000Mt\u0000\u0005orderq\u0000~\u0000Qq\u0000~\u0000Ssr\u0000\"com.sun.msv.grammar.ExpressionPoo" +
                  "l\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/sun/msv/grammar/ExpressionPoo" +
                  "l$ClosedHash;xpsr\u0000-com.sun.msv.grammar.ExpressionPool$Closed" +
                  "Hash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamVersionL\u0000\u0006parentt\u0000$Lcom/sun/" +
                  "msv/grammar/ExpressionPool;xp\u0000\u0000\u0000\u0015\u0001pq\u0000~\u0000\rq\u0000~\u0000]q\u0000~\u0000mq\u0000~\u0000eq\u0000~\u0000\u0007" +
                  "q\u0000~\u0000\u0005q\u0000~\u0000Uq\u0000~\u0000yq\u0000~\u0000\u0006q\u0000~\u0000uq\u0000~\u0000qq\u0000~\u0000Yq\u0000~\u0000iq\u0000~\u0000\nq\u0000~\u0000\u000eq\u0000~\u0000\u0010q\u0000~\u0000\t" +
                  "q\u0000~\u0000aq\u0000~\u0000\bq\u0000~\u0000\fq\u0000~\u0000\u000bx"));
         }

         return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
      }
   }
}
