/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsMPEHelper;


/**
 * Java content class for DadesPosicioType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsMPEHelper.xsd line 86)
 * <p>
 * <pre>
 * &lt;complexType name="DadesPosicioType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DadaPosicio" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="BloqueigPagamentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="BloqueigPagamentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="18" />
 *                 &lt;attribute name="CalcularImpostLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="CalcularImpostOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="14" />
 *                 &lt;attribute name="CentreGestorLength" type="{http://www.w3.org/2001/XMLSchema}int" default="16" />
 *                 &lt;attribute name="CentreGestorOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
 *                 &lt;attribute name="CompteMajorLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *                 &lt;attribute name="CompteMajorOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="21" />
 *                 &lt;attribute name="CondicioPagamentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *                 &lt;attribute name="CondicioPagamentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *                 &lt;attribute name="CreditorLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *                 &lt;attribute name="CreditorOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *                 &lt;attribute name="DadesPagadorAlternatiuLength" type="{http://www.w3.org/2001/XMLSchema}int" />
 *                 &lt;attribute name="DadesPagadorAlternatiuOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="22" />
 *                 &lt;attribute name="DataBaseLength" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
 *                 &lt;attribute name="DataBaseOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="19" />
 *                 &lt;attribute name="FonsLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *                 &lt;attribute name="FonsOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="16" />
 *                 &lt;attribute name="ImportFieldType" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="ImportImpostFieldType" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="ImportImpostLength" type="{http://www.w3.org/2001/XMLSchema}int" default="13" />
 *                 &lt;attribute name="ImportImpostOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="12" />
 *                 &lt;attribute name="ImportLength" type="{http://www.w3.org/2001/XMLSchema}int" default="13" />
 *                 &lt;attribute name="ImportOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="11" />
 *                 &lt;attribute name="IndicadorCMELength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="IndicadorCMEOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="6" />
 *                 &lt;attribute name="IndicadorIVALength" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *                 &lt;attribute name="IndicadorIVAOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="13" />
 *                 &lt;attribute name="NExpedientLength" type="{http://www.w3.org/2001/XMLSchema}int" default="30" />
 *                 &lt;attribute name="NExpedientOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
 *                 &lt;attribute name="PagadorAlternatiuLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *                 &lt;attribute name="PagadorAlternatiuOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="20" />
 *                 &lt;attribute name="PosicioPressupostariaLength" type="{http://www.w3.org/2001/XMLSchema}int" default="24" />
 *                 &lt;attribute name="PosicioPressupostariaOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="7" />
 *                 &lt;attribute name="ReferenciaLength" type="{http://www.w3.org/2001/XMLSchema}int" default="16" />
 *                 &lt;attribute name="ReferenciaOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="9" />
 *                 &lt;attribute name="TextDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="25" />
 *                 &lt;attribute name="TextDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *                 &lt;attribute name="TextLength" type="{http://www.w3.org/2001/XMLSchema}int" default="50" />
 *                 &lt;attribute name="TextOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="15" />
 *                 &lt;attribute name="TipusBancInterlocutorLength" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *                 &lt;attribute name="TipusBancInterlocutorOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
 *                 &lt;attribute name="TipusRegistreLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="TipusRegistreOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="ViaPagamentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="ViaPagamentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="17" />
 *                 &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface DadesPosicioType {
   /**
    * Gets the value of the DadaPosicio property.
    *
    * <p>
    * This accessor method returns a reference to the live list,
    * not a snapshot. Therefore any modification you make to the
    * returned list will be present inside the JAXB object.
    * This is why there is not a <CODE>set</CODE> method for the DadaPosicio property.
    *
    * <p>
    * For example, to add a new item, do as follows:
    * <pre>
    *    getDadaPosicio().add(newItem);
    * </pre>
    *
    *
    * <p>
    * Objects of the following type(s) are allowed in the list
    * {@link net.gencat.gecat.batch.DocumentsMPEHelper.DadesPosicioType.DadaPosicioType}
    *
    */
   java.util.List getDadaPosicio();

   /**
    * Gets the value of the order property.
    *
    */
   int getOrder();

   /**
    * Sets the value of the order property.
    *
    */
   void setOrder(int value);

   /**
    * Java content class for anonymous complex type.
    *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsMPEHelper.xsd line 90)
    * <p>
    * <pre>
    * &lt;complexType>
    *   &lt;complexContent>
    *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
    *       &lt;attribute name="BloqueigPagamentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="BloqueigPagamentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="18" />
    *       &lt;attribute name="CalcularImpostLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="CalcularImpostOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="14" />
    *       &lt;attribute name="CentreGestorLength" type="{http://www.w3.org/2001/XMLSchema}int" default="16" />
    *       &lt;attribute name="CentreGestorOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
    *       &lt;attribute name="CompteMajorLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
    *       &lt;attribute name="CompteMajorOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="21" />
    *       &lt;attribute name="CondicioPagamentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
    *       &lt;attribute name="CondicioPagamentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
    *       &lt;attribute name="CreditorLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
    *       &lt;attribute name="CreditorOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
    *       &lt;attribute name="DadesPagadorAlternatiuLength" type="{http://www.w3.org/2001/XMLSchema}int" />
    *       &lt;attribute name="DadesPagadorAlternatiuOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="22" />
    *       &lt;attribute name="DataBaseLength" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
    *       &lt;attribute name="DataBaseOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="19" />
    *       &lt;attribute name="FonsLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
    *       &lt;attribute name="FonsOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="16" />
    *       &lt;attribute name="ImportFieldType" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="ImportImpostFieldType" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="ImportImpostLength" type="{http://www.w3.org/2001/XMLSchema}int" default="13" />
    *       &lt;attribute name="ImportImpostOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="12" />
    *       &lt;attribute name="ImportLength" type="{http://www.w3.org/2001/XMLSchema}int" default="13" />
    *       &lt;attribute name="ImportOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="11" />
    *       &lt;attribute name="IndicadorCMELength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="IndicadorCMEOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="6" />
    *       &lt;attribute name="IndicadorIVALength" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
    *       &lt;attribute name="IndicadorIVAOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="13" />
    *       &lt;attribute name="NExpedientLength" type="{http://www.w3.org/2001/XMLSchema}int" default="30" />
    *       &lt;attribute name="NExpedientOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
    *       &lt;attribute name="PagadorAlternatiuLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
    *       &lt;attribute name="PagadorAlternatiuOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="20" />
    *       &lt;attribute name="PosicioPressupostariaLength" type="{http://www.w3.org/2001/XMLSchema}int" default="24" />
    *       &lt;attribute name="PosicioPressupostariaOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="7" />
    *       &lt;attribute name="ReferenciaLength" type="{http://www.w3.org/2001/XMLSchema}int" default="16" />
    *       &lt;attribute name="ReferenciaOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="9" />
    *       &lt;attribute name="TextDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="25" />
    *       &lt;attribute name="TextDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
    *       &lt;attribute name="TextLength" type="{http://www.w3.org/2001/XMLSchema}int" default="50" />
    *       &lt;attribute name="TextOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="15" />
    *       &lt;attribute name="TipusBancInterlocutorLength" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
    *       &lt;attribute name="TipusBancInterlocutorOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
    *       &lt;attribute name="TipusRegistreLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="TipusRegistreOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="ViaPagamentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="ViaPagamentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="17" />
    *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
    *     &lt;/restriction>
    *   &lt;/complexContent>
    * &lt;/complexType>
    * </pre>
    *
    */
   public interface DadaPosicioType {
      /**
       * Gets the value of the compteMajorLength property.
       *
       */
      int getCompteMajorLength();

      /**
       * Sets the value of the compteMajorLength property.
       *
       */
      void setCompteMajorLength(int value);

      /**
       * Gets the value of the importImpostLength property.
       *
       */
      int getImportImpostLength();

      /**
       * Sets the value of the importImpostLength property.
       *
       */
      void setImportImpostLength(int value);

      /**
       * Gets the value of the textDocumentOrder property.
       *
       */
      int getTextDocumentOrder();

      /**
       * Sets the value of the textDocumentOrder property.
       *
       */
      void setTextDocumentOrder(int value);

      /**
       * Gets the value of the nExpedientOrder property.
       *
       */
      int getNExpedientOrder();

      /**
       * Sets the value of the nExpedientOrder property.
       *
       */
      void setNExpedientOrder(int value);

      /**
       * Gets the value of the importFieldType property.
       *
       */
      int getImportFieldType();

      /**
       * Sets the value of the importFieldType property.
       *
       */
      void setImportFieldType(int value);

      /**
       * Gets the value of the centreGestorLength property.
       *
       */
      int getCentreGestorLength();

      /**
       * Sets the value of the centreGestorLength property.
       *
       */
      void setCentreGestorLength(int value);

      /**
       * Gets the value of the order property.
       *
       */
      int getOrder();

      /**
       * Sets the value of the order property.
       *
       */
      void setOrder(int value);

      /**
       * Gets the value of the referenciaLength property.
       *
       */
      int getReferenciaLength();

      /**
       * Sets the value of the referenciaLength property.
       *
       */
      void setReferenciaLength(int value);

      /**
       * Gets the value of the posicioPressupostariaLength property.
       *
       */
      int getPosicioPressupostariaLength();

      /**
       * Sets the value of the posicioPressupostariaLength property.
       *
       */
      void setPosicioPressupostariaLength(int value);

      /**
       * Gets the value of the indicadorIVAOrder property.
       *
       */
      int getIndicadorIVAOrder();

      /**
       * Sets the value of the indicadorIVAOrder property.
       *
       */
      void setIndicadorIVAOrder(int value);

      /**
       * Gets the value of the importLength property.
       *
       */
      int getImportLength();

      /**
       * Sets the value of the importLength property.
       *
       */
      void setImportLength(int value);

      /**
       * Gets the value of the tipusBancInterlocutorOrder property.
       *
       */
      int getTipusBancInterlocutorOrder();

      /**
       * Sets the value of the tipusBancInterlocutorOrder property.
       *
       */
      void setTipusBancInterlocutorOrder(int value);

      /**
       * Gets the value of the textLength property.
       *
       */
      int getTextLength();

      /**
       * Sets the value of the textLength property.
       *
       */
      void setTextLength(int value);

      /**
       * Gets the value of the referenciaOrder property.
       *
       */
      int getReferenciaOrder();

      /**
       * Sets the value of the referenciaOrder property.
       *
       */
      void setReferenciaOrder(int value);

      /**
       * Gets the value of the textDocumentLength property.
       *
       */
      int getTextDocumentLength();

      /**
       * Sets the value of the textDocumentLength property.
       *
       */
      void setTextDocumentLength(int value);

      /**
       * Gets the value of the importOrder property.
       *
       */
      int getImportOrder();

      /**
       * Sets the value of the importOrder property.
       *
       */
      void setImportOrder(int value);

      /**
       * Gets the value of the creditorOrder property.
       *
       */
      int getCreditorOrder();

      /**
       * Sets the value of the creditorOrder property.
       *
       */
      void setCreditorOrder(int value);

      /**
       * Gets the value of the importImpostFieldType property.
       *
       */
      int getImportImpostFieldType();

      /**
       * Sets the value of the importImpostFieldType property.
       *
       */
      void setImportImpostFieldType(int value);

      /**
       * Gets the value of the creditorLength property.
       *
       */
      int getCreditorLength();

      /**
       * Sets the value of the creditorLength property.
       *
       */
      void setCreditorLength(int value);

      /**
       * Gets the value of the textOrder property.
       *
       */
      int getTextOrder();

      /**
       * Sets the value of the textOrder property.
       *
       */
      void setTextOrder(int value);

      /**
       * Gets the value of the dadesPagadorAlternatiuLength property.
       *
       */
      int getDadesPagadorAlternatiuLength();

      /**
       * Sets the value of the dadesPagadorAlternatiuLength property.
       *
       */
      void setDadesPagadorAlternatiuLength(int value);

      /**
       * Gets the value of the viaPagamentOrder property.
       *
       */
      int getViaPagamentOrder();

      /**
       * Sets the value of the viaPagamentOrder property.
       *
       */
      void setViaPagamentOrder(int value);

      /**
       * Gets the value of the fonsOrder property.
       *
       */
      int getFonsOrder();

      /**
       * Sets the value of the fonsOrder property.
       *
       */
      void setFonsOrder(int value);

      /**
       * Gets the value of the pagadorAlternatiuOrder property.
       *
       */
      int getPagadorAlternatiuOrder();

      /**
       * Sets the value of the pagadorAlternatiuOrder property.
       *
       */
      void setPagadorAlternatiuOrder(int value);

      /**
       * Gets the value of the compteMajorOrder property.
       *
       */
      int getCompteMajorOrder();

      /**
       * Sets the value of the compteMajorOrder property.
       *
       */
      void setCompteMajorOrder(int value);

      /**
       * Gets the value of the posicioPressupostariaOrder property.
       *
       */
      int getPosicioPressupostariaOrder();

      /**
       * Sets the value of the posicioPressupostariaOrder property.
       *
       */
      void setPosicioPressupostariaOrder(int value);

      /**
       * Gets the value of the tipusRegistreOrder property.
       *
       */
      int getTipusRegistreOrder();

      /**
       * Sets the value of the tipusRegistreOrder property.
       *
       */
      void setTipusRegistreOrder(int value);

      /**
       * Gets the value of the bloqueigPagamentOrder property.
       *
       */
      int getBloqueigPagamentOrder();

      /**
       * Sets the value of the bloqueigPagamentOrder property.
       *
       */
      void setBloqueigPagamentOrder(int value);

      /**
       * Gets the value of the dadesPagadorAlternatiuOrder property.
       *
       */
      int getDadesPagadorAlternatiuOrder();

      /**
       * Sets the value of the dadesPagadorAlternatiuOrder property.
       *
       */
      void setDadesPagadorAlternatiuOrder(int value);

      /**
       * Gets the value of the dataBaseOrder property.
       *
       */
      int getDataBaseOrder();

      /**
       * Sets the value of the dataBaseOrder property.
       *
       */
      void setDataBaseOrder(int value);

      /**
       * Gets the value of the fonsLength property.
       *
       */
      int getFonsLength();

      /**
       * Sets the value of the fonsLength property.
       *
       */
      void setFonsLength(int value);

      /**
       * Gets the value of the tipusBancInterlocutorLength property.
       *
       */
      int getTipusBancInterlocutorLength();

      /**
       * Sets the value of the tipusBancInterlocutorLength property.
       *
       */
      void setTipusBancInterlocutorLength(int value);

      /**
       * Gets the value of the pagadorAlternatiuLength property.
       *
       */
      int getPagadorAlternatiuLength();

      /**
       * Sets the value of the pagadorAlternatiuLength property.
       *
       */
      void setPagadorAlternatiuLength(int value);

      /**
       * Gets the value of the tipusRegistreLength property.
       *
       */
      int getTipusRegistreLength();

      /**
       * Sets the value of the tipusRegistreLength property.
       *
       */
      void setTipusRegistreLength(int value);

      /**
       * Gets the value of the condicioPagamentLength property.
       *
       */
      int getCondicioPagamentLength();

      /**
       * Sets the value of the condicioPagamentLength property.
       *
       */
      void setCondicioPagamentLength(int value);

      /**
       * Gets the value of the calcularImpostOrder property.
       *
       */
      int getCalcularImpostOrder();

      /**
       * Sets the value of the calcularImpostOrder property.
       *
       */
      void setCalcularImpostOrder(int value);

      /**
       * Gets the value of the importImpostOrder property.
       *
       */
      int getImportImpostOrder();

      /**
       * Sets the value of the importImpostOrder property.
       *
       */
      void setImportImpostOrder(int value);

      /**
       * Gets the value of the bloqueigPagamentLength property.
       *
       */
      int getBloqueigPagamentLength();

      /**
       * Sets the value of the bloqueigPagamentLength property.
       *
       */
      void setBloqueigPagamentLength(int value);

      /**
       * Gets the value of the calcularImpostLength property.
       *
       */
      int getCalcularImpostLength();

      /**
       * Sets the value of the calcularImpostLength property.
       *
       */
      void setCalcularImpostLength(int value);

      /**
       * Gets the value of the condicioPagamentOrder property.
       *
       */
      int getCondicioPagamentOrder();

      /**
       * Sets the value of the condicioPagamentOrder property.
       *
       */
      void setCondicioPagamentOrder(int value);

      /**
       * Gets the value of the centreGestorOrder property.
       *
       */
      int getCentreGestorOrder();

      /**
       * Sets the value of the centreGestorOrder property.
       *
       */
      void setCentreGestorOrder(int value);

      /**
       * Gets the value of the nExpedientLength property.
       *
       */
      int getNExpedientLength();

      /**
       * Sets the value of the nExpedientLength property.
       *
       */
      void setNExpedientLength(int value);

      /**
       * Gets the value of the dataBaseLength property.
       *
       */
      int getDataBaseLength();

      /**
       * Sets the value of the dataBaseLength property.
       *
       */
      void setDataBaseLength(int value);

      /**
       * Gets the value of the indicadorCMELength property.
       *
       */
      int getIndicadorCMELength();

      /**
       * Sets the value of the indicadorCMELength property.
       *
       */
      void setIndicadorCMELength(int value);

      /**
       * Gets the value of the indicadorCMEOrder property.
       *
       */
      int getIndicadorCMEOrder();

      /**
       * Sets the value of the indicadorCMEOrder property.
       *
       */
      void setIndicadorCMEOrder(int value);

      /**
       * Gets the value of the indicadorIVALength property.
       *
       */
      int getIndicadorIVALength();

      /**
       * Sets the value of the indicadorIVALength property.
       *
       */
      void setIndicadorIVALength(int value);

      /**
       * Gets the value of the viaPagamentLength property.
       *
       */
      int getViaPagamentLength();

      /**
       * Sets the value of the viaPagamentLength property.
       *
       */
      void setViaPagamentLength(int value);
   }
}
