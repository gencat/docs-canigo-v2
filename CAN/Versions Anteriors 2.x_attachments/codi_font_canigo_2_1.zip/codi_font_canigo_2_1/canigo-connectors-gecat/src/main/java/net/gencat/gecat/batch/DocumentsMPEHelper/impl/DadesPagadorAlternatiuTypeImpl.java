/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsMPEHelper.impl;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class DadesPagadorAlternatiuTypeImpl implements net.gencat.gecat.batch.DocumentsMPEHelper.DadesPagadorAlternatiuType,
   com.sun.xml.bind.JAXBObject,
   net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.XMLSerializable,
   net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.ValidatableObject {
   /**
    * Documentaci�.
    */
   public static final java.lang.Class version = (net.gencat.gecat.batch.DocumentsMPEHelper.impl.JAXBVersion.class);

   /**
    * Documentaci�.
    */
   private static com.sun.msv.grammar.Grammar schemaFragment;

   /**
    * Documentaci�.
    */
   protected boolean has_AdrecaLength;

   /**
    * Documentaci�.
    */
   protected boolean has_AdrecaOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_BlocImputacioLength;

   /**
    * Documentaci�.
    */
   protected boolean has_BlocImputacioOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_ClauBancLength;

   /**
    * Documentaci�.
    */
   protected boolean has_ClauBancOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_CodiPostalLength;

   /**
    * Documentaci�.
    */
   protected boolean has_CodiPostalOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_CompteLength;

   /**
    * Documentaci�.
    */
   protected boolean has_CompteOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_DigitsControlLength;

   /**
    * Documentaci�.
    */
   protected boolean has_DigitsControlOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_NIFLength;

   /**
    * Documentaci�.
    */
   protected boolean has_NIFOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_NomLength;

   /**
    * Documentaci�.
    */
   protected boolean has_NomOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_Order;

   /**
    * Documentaci�.
    */
   protected boolean has_PaisBancLength;

   /**
    * Documentaci�.
    */
   protected boolean has_PaisBancOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_PaisLength;

   /**
    * Documentaci�.
    */
   protected boolean has_PaisOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_PoblacioLength;

   /**
    * Documentaci�.
    */
   protected boolean has_PoblacioOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_TipusRegistreLength;

   /**
    * Documentaci�.
    */
   protected boolean has_TipusRegistreOrder;

   /**
    * Documentaci�.
    */
   protected int _AdrecaLength;

   /**
    * Documentaci�.
    */
   protected int _AdrecaOrder;

   /**
    * Documentaci�.
    */
   protected int _BlocImputacioLength;

   /**
    * Documentaci�.
    */
   protected int _BlocImputacioOrder;

   /**
    * Documentaci�.
    */
   protected int _ClauBancLength;

   /**
    * Documentaci�.
    */
   protected int _ClauBancOrder;

   /**
    * Documentaci�.
    */
   protected int _CodiPostalLength;

   /**
    * Documentaci�.
    */
   protected int _CodiPostalOrder;

   /**
    * Documentaci�.
    */
   protected int _CompteLength;

   /**
    * Documentaci�.
    */
   protected int _CompteOrder;

   /**
    * Documentaci�.
    */
   protected int _DigitsControlLength;

   /**
    * Documentaci�.
    */
   protected int _DigitsControlOrder;

   /**
    * Documentaci�.
    */
   protected int _NIFLength;

   /**
    * Documentaci�.
    */
   protected int _NIFOrder;

   /**
    * Documentaci�.
    */
   protected int _NomLength;

   /**
    * Documentaci�.
    */
   protected int _NomOrder;

   /**
    * Documentaci�.
    */
   protected int _Order;

   /**
    * Documentaci�.
    */
   protected int _PaisBancLength;

   /**
    * Documentaci�.
    */
   protected int _PaisBancOrder;

   /**
    * Documentaci�.
    */
   protected int _PaisLength;

   /**
    * Documentaci�.
    */
   protected int _PaisOrder;

   /**
    * Documentaci�.
    */
   protected int _PoblacioLength;

   /**
    * Documentaci�.
    */
   protected int _PoblacioOrder;

   /**
    * Documentaci�.
    */
   protected int _TipusRegistreLength;

   /**
    * Documentaci�.
    */
   protected int _TipusRegistreOrder;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private static final java.lang.Class PRIMARY_INTERFACE_CLASS() {
      return (net.gencat.gecat.batch.DocumentsMPEHelper.DadesPagadorAlternatiuType.class);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getPaisBancLength() {
      if (!has_PaisBancLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "3"));
      } else {
         return _PaisBancLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setPaisBancLength(int value) {
      _PaisBancLength = value;
      has_PaisBancLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getCodiPostalOrder() {
      if (!has_CodiPostalOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "5"));
      } else {
         return _CodiPostalOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setCodiPostalOrder(int value) {
      _CodiPostalOrder = value;
      has_CodiPostalOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getOrder() {
      if (!has_Order) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "5"));
      } else {
         return _Order;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setOrder(int value) {
      _Order = value;
      has_Order = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getAdrecaLength() {
      if (!has_AdrecaLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "35"));
      } else {
         return _AdrecaLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setAdrecaLength(int value) {
      _AdrecaLength = value;
      has_AdrecaLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getAdrecaOrder() {
      if (!has_AdrecaOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "3"));
      } else {
         return _AdrecaOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setAdrecaOrder(int value) {
      _AdrecaOrder = value;
      has_AdrecaOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getPoblacioLength() {
      if (!has_PoblacioLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "35"));
      } else {
         return _PoblacioLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setPoblacioLength(int value) {
      _PoblacioLength = value;
      has_PoblacioLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getPaisOrder() {
      if (!has_PaisOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "6"));
      } else {
         return _PaisOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setPaisOrder(int value) {
      _PaisOrder = value;
      has_PaisOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getPaisBancOrder() {
      if (!has_PaisBancOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "10"));
      } else {
         return _PaisBancOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setPaisBancOrder(int value) {
      _PaisBancOrder = value;
      has_PaisBancOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getDigitsControlLength() {
      if (!has_DigitsControlLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "2"));
      } else {
         return _DigitsControlLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setDigitsControlLength(int value) {
      _DigitsControlLength = value;
      has_DigitsControlLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getDigitsControlOrder() {
      if (!has_DigitsControlOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "9"));
      } else {
         return _DigitsControlOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setDigitsControlOrder(int value) {
      _DigitsControlOrder = value;
      has_DigitsControlOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getTipusRegistreOrder() {
      if (!has_TipusRegistreOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "1"));
      } else {
         return _TipusRegistreOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setTipusRegistreOrder(int value) {
      _TipusRegistreOrder = value;
      has_TipusRegistreOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getPoblacioOrder() {
      if (!has_PoblacioOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "4"));
      } else {
         return _PoblacioOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setPoblacioOrder(int value) {
      _PoblacioOrder = value;
      has_PoblacioOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getCodiPostalLength() {
      if (!has_CodiPostalLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "10"));
      } else {
         return _CodiPostalLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setCodiPostalLength(int value) {
      _CodiPostalLength = value;
      has_CodiPostalLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getClauBancLength() {
      if (!has_ClauBancLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "15"));
      } else {
         return _ClauBancLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setClauBancLength(int value) {
      _ClauBancLength = value;
      has_ClauBancLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getClauBancOrder() {
      if (!has_ClauBancOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "7"));
      } else {
         return _ClauBancOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setClauBancOrder(int value) {
      _ClauBancOrder = value;
      has_ClauBancOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getNIFLength() {
      if (!has_NIFLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "16"));
      } else {
         return _NIFLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setNIFLength(int value) {
      _NIFLength = value;
      has_NIFLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getTipusRegistreLength() {
      if (!has_TipusRegistreLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "1"));
      } else {
         return _TipusRegistreLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setTipusRegistreLength(int value) {
      _TipusRegistreLength = value;
      has_TipusRegistreLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getNomLength() {
      if (!has_NomLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "35"));
      } else {
         return _NomLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setNomLength(int value) {
      _NomLength = value;
      has_NomLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getNIFOrder() {
      if (!has_NIFOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "11"));
      } else {
         return _NIFOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setNIFOrder(int value) {
      _NIFOrder = value;
      has_NIFOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getCompteLength() {
      if (!has_CompteLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "18"));
      } else {
         return _CompteLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setCompteLength(int value) {
      _CompteLength = value;
      has_CompteLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getBlocImputacioOrder() {
      if (!has_BlocImputacioOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "12"));
      } else {
         return _BlocImputacioOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setBlocImputacioOrder(int value) {
      _BlocImputacioOrder = value;
      has_BlocImputacioOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getBlocImputacioLength() {
      return _BlocImputacioLength;
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setBlocImputacioLength(int value) {
      _BlocImputacioLength = value;
      has_BlocImputacioLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getNomOrder() {
      if (!has_NomOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "2"));
      } else {
         return _NomOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setNomOrder(int value) {
      _NomOrder = value;
      has_NomOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getCompteOrder() {
      if (!has_CompteOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "8"));
      } else {
         return _CompteOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setCompteOrder(int value) {
      _CompteOrder = value;
      has_CompteOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getPaisLength() {
      if (!has_PaisLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "3"));
      } else {
         return _PaisLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setPaisLength(int value) {
      _PaisLength = value;
      has_PaisLength = true;
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeBody(
      net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeAttributes(
      net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
      if (has_AdrecaLength) {
         context.startAttribute("", "AdrecaLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _AdrecaLength)), "AdrecaLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_AdrecaOrder) {
         context.startAttribute("", "AdrecaOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _AdrecaOrder)), "AdrecaOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_BlocImputacioLength) {
         context.startAttribute("", "BlocImputacioLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _BlocImputacioLength)), "BlocImputacioLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_BlocImputacioOrder) {
         context.startAttribute("", "BlocImputacioOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _BlocImputacioOrder)), "BlocImputacioOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_ClauBancLength) {
         context.startAttribute("", "ClauBancLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _ClauBancLength)), "ClauBancLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_ClauBancOrder) {
         context.startAttribute("", "ClauBancOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _ClauBancOrder)), "ClauBancOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_CodiPostalLength) {
         context.startAttribute("", "CodiPostalLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _CodiPostalLength)), "CodiPostalLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_CodiPostalOrder) {
         context.startAttribute("", "CodiPostalOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _CodiPostalOrder)), "CodiPostalOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_CompteLength) {
         context.startAttribute("", "CompteLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _CompteLength)), "CompteLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_CompteOrder) {
         context.startAttribute("", "CompteOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _CompteOrder)), "CompteOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_DigitsControlLength) {
         context.startAttribute("", "DigitsControlLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _DigitsControlLength)), "DigitsControlLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_DigitsControlOrder) {
         context.startAttribute("", "DigitsControlOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _DigitsControlOrder)), "DigitsControlOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_NIFLength) {
         context.startAttribute("", "NIFLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _NIFLength)), "NIFLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_NIFOrder) {
         context.startAttribute("", "NIFOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _NIFOrder)), "NIFOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_NomLength) {
         context.startAttribute("", "NomLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _NomLength)), "NomLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_NomOrder) {
         context.startAttribute("", "NomOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _NomOrder)), "NomOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_PaisBancLength) {
         context.startAttribute("", "PaisBancLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _PaisBancLength)), "PaisBancLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_PaisBancOrder) {
         context.startAttribute("", "PaisBancOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _PaisBancOrder)), "PaisBancOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_PaisLength) {
         context.startAttribute("", "PaisLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _PaisLength)), "PaisLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_PaisOrder) {
         context.startAttribute("", "PaisOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _PaisOrder)), "PaisOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_PoblacioLength) {
         context.startAttribute("", "PoblacioLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _PoblacioLength)), "PoblacioLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_PoblacioOrder) {
         context.startAttribute("", "PoblacioOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _PoblacioOrder)), "PoblacioOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_TipusRegistreLength) {
         context.startAttribute("", "TipusRegistreLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _TipusRegistreLength)), "TipusRegistreLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_TipusRegistreOrder) {
         context.startAttribute("", "TipusRegistreOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _TipusRegistreOrder)), "TipusRegistreOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_Order) {
         context.startAttribute("", "order");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _Order)), "Order");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeURIs(
      net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public java.lang.Class getPrimaryInterface() {
      return (net.gencat.gecat.batch.DocumentsMPEHelper.DadesPagadorAlternatiuType.class);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
      if (schemaFragment == null) {
         schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
               "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
               "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
               "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
               "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
               "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~" +
               "\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
               "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsr\u0000\u001dcom.sun.msv.grammar.ChoiceExp\u0000\u0000\u0000" +
               "\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsr\u0000 com.sun.msv.grammar.AttributeExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
               "\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/NameClass;" +
               "xq\u0000~\u0000\u0003sr\u0000\u0011java.lang.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000\u001bcom.su" +
               "n.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatyp" +
               "e/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util/StringP" +
               "air;xq\u0000~\u0000\u0003ppsr\u0000 com.sun.msv.datatype.xsd.IntType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000x" +
               "r\u0000+com.sun.msv.datatype.xsd.IntegerDerivedType\u0099\u00f1]\u0090&6k\u00be\u0002\u0000\u0001L\u0000\n" +
               "baseFacetst\u0000)Lcom/sun/msv/datatype/xsd/XSDatatypeImpl;xr\u0000*co" +
               "m.sun.msv.datatype.xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.s" +
               "un.msv.datatype.xsd.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.d" +
               "atatype.xsd.XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUrit\u0000\u0012Ljava" +
               "/lang/String;L\u0000\btypeNameq\u0000~\u0000.L\u0000\nwhiteSpacet\u0000.Lcom/sun/msv/da" +
               "tatype/xsd/WhiteSpaceProcessor;xpt\u0000 http://www.w3.org/2001/X" +
               "MLSchemat\u0000\u0003intsr\u00005com.sun.msv.datatype.xsd.WhiteSpaceProcess" +
               "or$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datatype.xsd.WhiteSpac" +
               "eProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u0000*com.sun.msv.datatype.xsd.MaxInclu" +
               "siveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.datatype.xsd.RangeFacet\u0000" +
               "\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\nlimitValuet\u0000\u0012Ljava/lang/Object;xr\u00009com.sun.msv." +
               "datatype.xsd.DataTypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*" +
               "com.sun.msv.datatype.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFa" +
               "cetFixedZ\u0000\u0012needValueCheckFlagL\u0000\bbaseTypeq\u0000~\u0000*L\u0000\fconcreteType" +
               "t\u0000\'Lcom/sun/msv/datatype/xsd/ConcreteType;L\u0000\tfacetNameq\u0000~\u0000.x" +
               "q\u0000~\u0000-ppq\u0000~\u00005\u0000\u0001sr\u0000*com.sun.msv.datatype.xsd.MinInclusiveFacet" +
               "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u00007ppq\u0000~\u00005\u0000\u0000sr\u0000!com.sun.msv.datatype.xsd.LongT" +
               "ype\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000)q\u0000~\u00001t\u0000\u0004longq\u0000~\u00005sq\u0000~\u00006ppq\u0000~\u00005\u0000\u0001sq\u0000~\u0000=pp" +
               "q\u0000~\u00005\u0000\u0000sr\u0000$com.sun.msv.datatype.xsd.IntegerType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq" +
               "\u0000~\u0000)q\u0000~\u00001t\u0000\u0007integerq\u0000~\u00005sr\u0000,com.sun.msv.datatype.xsd.Fractio" +
               "nDigitsFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scalexr\u0000;com.sun.msv.datatype.xsd." +
               "DataTypeWithLexicalConstraintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000:ppq\u0000~\u00005\u0001\u0000" +
               "sr\u0000#com.sun.msv.datatype.xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000+q\u0000~\u0000" +
               "1t\u0000\u0007decimalq\u0000~\u00005q\u0000~\u0000Kt\u0000\u000efractionDigits\u0000\u0000\u0000\u0000q\u0000~\u0000Et\u0000\fminInclusi" +
               "vesr\u0000\u000ejava.lang.Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010java.lang.Number\u0086" +
               "\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u0000Et\u0000\fmaxInclusivesq\u0000~\u0000O\u007f\u00ff\u00ff\u00ff\u00ff\u00ff\u00ff\u00ffq\u0000~\u0000@q" +
               "\u0000~\u0000Nsr\u0000\u0011java.lang.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000P\u0080\u0000\u0000\u0000q\u0000~\u0000@q" +
               "\u0000~\u0000Rsq\u0000~\u0000T\u007f\u00ff\u00ff\u00ffsr\u00000com.sun.msv.grammar.Expression$NullSetExpr" +
               "ession\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ej" +
               "B\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000.L\u0000\fnamespaceURIq\u0000~\u0000.xpq\u0000~\u00002q\u0000~\u00001sr\u0000#" +
               "com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlocalNameq\u0000" +
               "~\u0000.L\u0000\fnamespaceURIq\u0000~\u0000.xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000" +
               "\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpt\u0000\fAdrecaLengtht\u0000\u0000sr\u00000com.sun.msv.grammar.Expressio" +
               "n$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\"\u0001q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~" +
               "\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u000bAdrecaOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~" +
               "\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0013BlocImputacioLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001f" +
               "q\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0012BlocImputacioOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~" +
               "\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u000eClauBancLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001f" +
               "q\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\rClauBancOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~" +
               "\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0010CodiPostalLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~" +
               "\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u000fCodiPostalOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000" +
               "#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\fCompteLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000" +
               "~\u0000\'sq\u0000~\u0000[t\u0000\u000bCompteOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq" +
               "\u0000~\u0000[t\u0000\u0013DigitsControlLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000" +
               "\'sq\u0000~\u0000[t\u0000\u0012DigitsControlOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000" +
               "~\u0000\'sq\u0000~\u0000[t\u0000\tNIFLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~" +
               "\u0000[t\u0000\bNIFOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\tNom" +
               "Lengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\bNomOrderq\u0000" +
               "~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u000ePaisBancLengthq\u0000~\u0000" +
               "_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\rPaisBancOrderq\u0000~\u0000_q\u0000" +
               "~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\nPaisLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000" +
               "~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\tPaisOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq" +
               "\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u000ePoblacioLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~" +
               "\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\rPoblacioOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq" +
               "\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0013TipusRegistreLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~" +
               "\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0012TipusRegistreOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq" +
               "\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0005orderq\u0000~\u0000_q\u0000~\u0000asr\u0000\"com.sun.msv.gramm" +
               "ar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/sun/msv/gramm" +
               "ar/ExpressionPool$ClosedHash;xpsr\u0000-com.sun.msv.grammar.Expre" +
               "ssionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamVersionL\u0000\u0006pa" +
               "rentt\u0000$Lcom/sun/msv/grammar/ExpressionPool;xp\u0000\u0000\u00001\u0001pq\u0000~\u0000\bq\u0000~\u0000" +
               "\u00b3q\u0000~\u0000{q\u0000~\u0000\u009bq\u0000~\u0000oq\u0000~\u0000\u0010q\u0000~\u0000\u00a7q\u0000~\u0000\u000fq\u0000~\u0000\u0019q\u0000~\u0000\u00b7q\u0000~\u0000\u007fq\u0000~\u0000\u00a3q\u0000~\u0000\fq\u0000~\u0000" +
               "\u001aq\u0000~\u0000\u0006q\u0000~\u0000kq\u0000~\u0000\u0087q\u0000~\u0000\u0013q\u0000~\u0000\u0007q\u0000~\u0000\u00bfq\u0000~\u0000sq\u0000~\u0000\u000bq\u0000~\u0000\u0015q\u0000~\u0000\tq\u0000~\u0000\u0083q\u0000~\u0000" +
               "\u00afq\u0000~\u0000cq\u0000~\u0000\u0017q\u0000~\u0000\u0012q\u0000~\u0000\u0097q\u0000~\u0000\u001cq\u0000~\u0000\u0018q\u0000~\u0000wq\u0000~\u0000\u008fq\u0000~\u0000\u0014q\u0000~\u0000\u0011q\u0000~\u0000\nq\u0000~\u0000" +
               "\u0016q\u0000~\u0000\u009fq\u0000~\u0000\u001bq\u0000~\u0000\u008bq\u0000~\u0000\u00bbq\u0000~\u0000\rq\u0000~\u0000\u00abq\u0000~\u0000\u000eq\u0000~\u0000\u0005q\u0000~\u0000\u001eq\u0000~\u0000\u0093q\u0000~\u0000gx"));
      }

      return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
   }
}
