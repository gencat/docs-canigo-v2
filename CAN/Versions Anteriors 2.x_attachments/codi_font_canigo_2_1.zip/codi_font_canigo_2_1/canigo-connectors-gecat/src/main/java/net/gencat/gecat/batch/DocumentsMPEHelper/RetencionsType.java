/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsMPEHelper;


/**
 * Java content class for RetencionsType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsMPEHelper.xsd line 263)
 * <p>
 * <pre>
 * &lt;complexType name="RetencionsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DadaRetencio" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="ImportBaseFieldType" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="ImportBaseLength" type="{http://www.w3.org/2001/XMLSchema}int" default="13" />
 *                 &lt;attribute name="ImportBaseOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
 *                 &lt;attribute name="ImportRetencioFieldType" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="ImportRetencioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="13" />
 *                 &lt;attribute name="ImportRetencioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *                 &lt;attribute name="IndicadorRetencioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *                 &lt;attribute name="IndicadorRetencioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *                 &lt;attribute name="TipusRegistreLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="TipusRegistreOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface RetencionsType {
   /**
    * Gets the value of the DadaRetencio property.
    *
    * <p>
    * This accessor method returns a reference to the live list,
    * not a snapshot. Therefore any modification you make to the
    * returned list will be present inside the JAXB object.
    * This is why there is not a <CODE>set</CODE> method for the DadaRetencio property.
    *
    * <p>
    * For example, to add a new item, do as follows:
    * <pre>
    *    getDadaRetencio().add(newItem);
    * </pre>
    *
    *
    * <p>
    * Objects of the following type(s) are allowed in the list
    * {@link net.gencat.gecat.batch.DocumentsMPEHelper.RetencionsType.DadaRetencioType}
    *
    */
   java.util.List getDadaRetencio();

   /**
    * Gets the value of the order property.
    *
    */
   int getOrder();

   /**
    * Sets the value of the order property.
    *
    */
   void setOrder(int value);

   /**
    * Java content class for anonymous complex type.
    *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsMPEHelper.xsd line 267)
    * <p>
    * <pre>
    * &lt;complexType>
    *   &lt;complexContent>
    *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
    *       &lt;attribute name="ImportBaseFieldType" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="ImportBaseLength" type="{http://www.w3.org/2001/XMLSchema}int" default="13" />
    *       &lt;attribute name="ImportBaseOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
    *       &lt;attribute name="ImportRetencioFieldType" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="ImportRetencioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="13" />
    *       &lt;attribute name="ImportRetencioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
    *       &lt;attribute name="IndicadorRetencioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
    *       &lt;attribute name="IndicadorRetencioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
    *       &lt;attribute name="TipusRegistreLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="TipusRegistreOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
    *     &lt;/restriction>
    *   &lt;/complexContent>
    * &lt;/complexType>
    * </pre>
    *
    */
   public interface DadaRetencioType {
      /**
       * Gets the value of the importBaseLength property.
       *
       */
      int getImportBaseLength();

      /**
       * Sets the value of the importBaseLength property.
       *
       */
      void setImportBaseLength(int value);

      /**
       * Gets the value of the importBaseFieldType property.
       *
       */
      int getImportBaseFieldType();

      /**
       * Sets the value of the importBaseFieldType property.
       *
       */
      void setImportBaseFieldType(int value);

      /**
       * Gets the value of the indicadorRetencioOrder property.
       *
       */
      int getIndicadorRetencioOrder();

      /**
       * Sets the value of the indicadorRetencioOrder property.
       *
       */
      void setIndicadorRetencioOrder(int value);

      /**
       * Gets the value of the tipusRegistreLength property.
       *
       */
      int getTipusRegistreLength();

      /**
       * Sets the value of the tipusRegistreLength property.
       *
       */
      void setTipusRegistreLength(int value);

      /**
       * Gets the value of the importRetencioFieldType property.
       *
       */
      int getImportRetencioFieldType();

      /**
       * Sets the value of the importRetencioFieldType property.
       *
       */
      void setImportRetencioFieldType(int value);

      /**
       * Gets the value of the tipusRegistreOrder property.
       *
       */
      int getTipusRegistreOrder();

      /**
       * Sets the value of the tipusRegistreOrder property.
       *
       */
      void setTipusRegistreOrder(int value);

      /**
       * Gets the value of the order property.
       *
       */
      int getOrder();

      /**
       * Sets the value of the order property.
       *
       */
      void setOrder(int value);

      /**
       * Gets the value of the indicadorRetencioLength property.
       *
       */
      int getIndicadorRetencioLength();

      /**
       * Sets the value of the indicadorRetencioLength property.
       *
       */
      void setIndicadorRetencioLength(int value);

      /**
       * Gets the value of the importRetencioOrder property.
       *
       */
      int getImportRetencioOrder();

      /**
       * Sets the value of the importRetencioOrder property.
       *
       */
      void setImportRetencioOrder(int value);

      /**
       * Gets the value of the importRetencioLength property.
       *
       */
      int getImportRetencioLength();

      /**
       * Sets the value of the importRetencioLength property.
       *
       */
      void setImportRetencioLength(int value);

      /**
       * Gets the value of the importBaseOrder property.
       *
       */
      int getImportBaseOrder();

      /**
       * Sets the value of the importBaseOrder property.
       *
       */
      void setImportBaseOrder(int value);
   }
}
