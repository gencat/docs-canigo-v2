/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.BatchRetornHelper.impl.runtime;

import java.io.InputStream;
import java.io.ObjectInputStream;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBException;
import javax.xml.namespace.QName;

import com.sun.xml.bind.Messages;


/**
 * Keeps the information about the grammar as a whole.
 *
 * This object is immutable and thread-safe.
 *
 * @author
 *  <a href="mailto:kohsuke.kawaguchi@sun.com">Kohsuke KAWAGUCHI</a>
 */
public class GrammarInfoImpl implements GrammarInfo {
   /**
    * Enclosing ObjectFactory class. Used to load resources.
    */
   private final Class objectFactoryClass;

   /**
    * ClassLoader that should be used to load impl classes.
    */
   private final ClassLoader classLoader;

   /**
    * Map from {@link Class}es that represent content interfaces
    * to {@link String}s that represent names of the corresponding
    * implementation classes.
    */
   private final Map defaultImplementationMap;

   /**
    * Map from {@link QName}s (root tag names) to {@link Class}es of the
    * content interface that should be instanciated.
    */
   private final Map rootTagMap;

   /**
    * Creates a new GrammarInfoImpl object.
    *
    * @param _rootTagMap DOCUMENT ME.
    * @param _defaultImplementationMap DOCUMENT ME.
    * @param _objectFactoryClass DOCUMENT ME.
    */
   public GrammarInfoImpl(Map _rootTagMap, Map _defaultImplementationMap,
      Class _objectFactoryClass) {
      this.rootTagMap = _rootTagMap;
      this.defaultImplementationMap = _defaultImplementationMap;
      this.objectFactoryClass = _objectFactoryClass;
      // the assumption is that the content interfaces and their impls
      // are loaded from the same class loader. 
      this.classLoader = objectFactoryClass.getClassLoader();
   }

   /**
    * Documentaci�.
    *
    * @param javaContentInterface Documentaci�
    *
    * @return Documentaci�
    */
   public final Class getDefaultImplementation(Class javaContentInterface) {
      try {
         // by caching the obtained Class objects.
         return Class.forName((String) defaultImplementationMap.get(
               javaContentInterface), true, classLoader);
      } catch (ClassNotFoundException e) {
         throw new NoClassDefFoundError(e.toString());
      }
   }

   /**
    * @see com.sun.tools.xjc.runtime.GrammarInfo#castToXMLSerializable(java.lang.Object)
    */
   public XMLSerializable castToXMLSerializable(Object o) {
      if (o instanceof XMLSerializable) {
         return (XMLSerializable) o;
      } else {
         return null;
      }
   }

   /**
    * @see com.sun.tools.xjc.runtime.GrammarInfo#castToValidatableObject(java.lang.Object)
    */
   public ValidatableObject castToValidatableObject(Object o) {
      if (o instanceof ValidatableObject) {
         return (ValidatableObject) o;
      } else {
         return null;
      }
   }
}
