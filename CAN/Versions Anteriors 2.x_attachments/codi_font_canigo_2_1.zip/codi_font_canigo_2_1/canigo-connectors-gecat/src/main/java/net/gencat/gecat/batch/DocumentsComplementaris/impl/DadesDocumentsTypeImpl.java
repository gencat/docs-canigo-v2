/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsComplementaris.impl;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class DadesDocumentsTypeImpl implements net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType,
   com.sun.xml.bind.JAXBObject,
   net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.XMLSerializable,
   net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.ValidatableObject {
   /**
    * Documentaci�.
    */
   public static final java.lang.Class version = (net.gencat.gecat.batch.DocumentsComplementaris.impl.JAXBVersion.class);

   /**
    * Documentaci�.
    */
   private static com.sun.msv.grammar.Grammar schemaFragment;

   /**
    * Documentaci�.
    */
   protected com.sun.xml.bind.util.ListImpl _DadaDocument;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private static final java.lang.Class PRIMARY_INTERFACE_CLASS() {
      return (net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.class);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected com.sun.xml.bind.util.ListImpl _getDadaDocument() {
      if (_DadaDocument == null) {
         _DadaDocument = new com.sun.xml.bind.util.ListImpl(new java.util.ArrayList());
      }

      return _DadaDocument;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public java.util.List getDadaDocument() {
      return _getDadaDocument();
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeBody(
      net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
      int idx1 = 0;
      final int len1 = ((_DadaDocument == null) ? 0 : _DadaDocument.size());

      while (idx1 != len1) {
         context.startElement("", "DadaDocument");

         int idx_0 = idx1;
         context.childAsURIs(((com.sun.xml.bind.JAXBObject) _DadaDocument.get(
               idx_0++)), "DadaDocument");
         context.endNamespaceDecls();

         int idx_1 = idx1;
         context.childAsAttributes(((com.sun.xml.bind.JAXBObject) _DadaDocument.get(
               idx_1++)), "DadaDocument");
         context.endAttributes();
         context.childAsBody(((com.sun.xml.bind.JAXBObject) _DadaDocument.get(
               idx1++)), "DadaDocument");
         context.endElement();
      }
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeAttributes(
      net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
      int idx1 = 0;
      final int len1 = ((_DadaDocument == null) ? 0 : _DadaDocument.size());

      while (idx1 != len1) {
         idx1 += 1;
      }
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeURIs(
      net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
      int idx1 = 0;
      final int len1 = ((_DadaDocument == null) ? 0 : _DadaDocument.size());

      while (idx1 != len1) {
         idx1 += 1;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public java.lang.Class getPrimaryInterface() {
      return (net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.class);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
      if (schemaFragment == null) {
         schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000 com.sun.msv.grammar.OneOrMoreExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001ccom.s" +
               "un.msv.grammar.UnaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0003expt\u0000 Lcom/sun/msv/gram" +
               "mar/Expression;xr\u0000\u001ecom.sun.msv.grammar.Expression\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002" +
               "L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000bexpandedExpq\u0000" +
               "~\u0000\u0002xpppsr\u0000\'com.sun.msv.grammar.trex.ElementPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000" +
               "\u0001L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/NameClass;xr\u0000\u001ecom.sun.m" +
               "sv.grammar.ElementExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aignoreUndeclaredAttribute" +
               "sL\u0000\fcontentModelq\u0000~\u0000\u0002xq\u0000~\u0000\u0003pp\u0000sr\u0000\u001fcom.sun.msv.grammar.Sequen" +
               "ceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.sun.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002" +
               "L\u0000\u0004exp1q\u0000~\u0000\u0002L\u0000\u0004exp2q\u0000~\u0000\u0002xq\u0000~\u0000\u0003ppsq\u0000~\u0000\u0006pp\u0000sr\u0000\u001dcom.sun.msv.gra" +
               "mmar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u000bppsq\u0000~\u0000\u0000sr\u0000\u0011java.lang.Boolean" +
               "\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000 com.sun.msv.grammar.AttributeExp\u0000" +
               "\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClassq\u0000~\u0000\u0007xq\u0000~\u0000\u0003q\u0000~\u0000\u0012psr\u00002com.su" +
               "n.msv.grammar.Expression$AnyStringExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000" +
               "\u0003sq\u0000~\u0000\u0011\u0001q\u0000~\u0000\u0016sr\u0000 com.sun.msv.grammar.AnyNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000" +
               "xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000com.sun.ms" +
               "v.grammar.Expression$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003q\u0000~\u0000\u0017" +
               "q\u0000~\u0000\u001csr\u0000#com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlo" +
               "calNamet\u0000\u0012Ljava/lang/String;L\u0000\fnamespaceURIq\u0000~\u0000\u001exq\u0000~\u0000\u0019t\u0000Rnet" +
               ".gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsTy" +
               "pe.DadaDocumentTypet\u0000+http://java.sun.com/jaxb/xjc/dummy-ele" +
               "mentssq\u0000~\u0000\u000eppsq\u0000~\u0000\u0013q\u0000~\u0000\u0012psr\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000" +
               "\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002" +
               "L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util/StringPair;xq\u0000~\u0000\u0003ppsr\u0000\"com.sun.m" +
               "sv.datatype.xsd.QnameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype" +
               ".xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datatype.xs" +
               "d.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype.xsd.XSData" +
               "typeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUriq\u0000~\u0000\u001eL\u0000\btypeNameq\u0000~\u0000\u001eL\u0000\nwh" +
               "iteSpacet\u0000.Lcom/sun/msv/datatype/xsd/WhiteSpaceProcessor;xpt" +
               "\u0000 http://www.w3.org/2001/XMLSchemat\u0000\u0005QNamesr\u00005com.sun.msv.da" +
               "tatype.xsd.WhiteSpaceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.su" +
               "n.msv.datatype.xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000com.s" +
               "un.msv.grammar.Expression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003" +
               "ppsr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000" +
               "\u001eL\u0000\fnamespaceURIq\u0000~\u0000\u001expq\u0000~\u0000/q\u0000~\u0000.sq\u0000~\u0000\u001dt\u0000\u0004typet\u0000)http://www." +
               "w3.org/2001/XMLSchema-instanceq\u0000~\u0000\u001csq\u0000~\u0000\u001dt\u0000\fDadaDocumentt\u0000\u0000s" +
               "r\u0000\"com.sun.msv.grammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet" +
               "\u0000/Lcom/sun/msv/grammar/ExpressionPool$ClosedHash;xpsr\u0000-com.s" +
               "un.msv.grammar.ExpressionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB" +
               "\u0000\rstreamVersionL\u0000\u0006parentt\u0000$Lcom/sun/msv/grammar/ExpressionPo" +
               "ol;xp\u0000\u0000\u0000\u0005\u0001pq\u0000~\u0000\u0010q\u0000~\u0000\fq\u0000~\u0000\"q\u0000~\u0000\u0005q\u0000~\u0000\u000fx"));
      }

      return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   public static class DadaDocumentTypeImpl implements net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType,
      com.sun.xml.bind.JAXBObject,
      net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.XMLSerializable,
      net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.ValidatableObject {
      /**
       * Documentaci�.
       */
      public static final java.lang.Class version = (net.gencat.gecat.batch.DocumentsComplementaris.impl.JAXBVersion.class);

      /**
       * Documentaci�.
       */
      private static com.sun.msv.grammar.Grammar schemaFragment;

      /**
       * Documentaci�.
       */
      protected java.lang.String _ClasseDocument;

      /**
       * Documentaci�.
       */
      protected java.lang.String _DataCompt;

      /**
       * Documentaci�.
       */
      protected java.lang.String _DataDocument;

      /**
       * Documentaci�.
       */
      protected java.lang.String _Import;

      /**
       * Documentaci�.
       */
      protected java.lang.String _NDocumentCrear;

      /**
       * Documentaci�.
       */
      protected java.lang.String _NDocumentModificar;

      /**
       * Documentaci�.
       */
      protected java.lang.String _Posicio;

      /**
       * Documentaci�.
       */
      protected java.lang.String _Societat;

      /**
       * Documentaci�.
       */
      protected java.lang.String _Text;

      /**
       * Documentaci�.
       */
      protected java.lang.String _TipusOperacio;

      /**
       * Documentaci�.
       */
      protected java.lang.String _TipusRegistre;

      /**
       * Documentaci�.
       */
      protected java.lang.String _Transaccio;

      /**
       * Documentaci�.
       */
      protected boolean has_Order;

      /**
       * Documentaci�.
       */
      protected int _Order;

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      private static final java.lang.Class PRIMARY_INTERFACE_CLASS() {
         return (net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType.class);
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.String getClasseDocument() {
         return _ClasseDocument;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setClasseDocument(java.lang.String value) {
         _ClasseDocument = value;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public int getOrder() {
         return _Order;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setOrder(int value) {
         _Order = value;
         has_Order = true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.String getNDocumentModificar() {
         return _NDocumentModificar;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setNDocumentModificar(java.lang.String value) {
         _NDocumentModificar = value;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.String getPosicio() {
         return _Posicio;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setPosicio(java.lang.String value) {
         _Posicio = value;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.String getSocietat() {
         return _Societat;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setSocietat(java.lang.String value) {
         _Societat = value;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.String getImport() {
         return _Import;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setImport(java.lang.String value) {
         _Import = value;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.String getText() {
         return _Text;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setText(java.lang.String value) {
         _Text = value;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.String getTipusOperacio() {
         return _TipusOperacio;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setTipusOperacio(java.lang.String value) {
         _TipusOperacio = value;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.String getTransaccio() {
         return _Transaccio;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setTransaccio(java.lang.String value) {
         _Transaccio = value;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.String getNDocumentCrear() {
         return _NDocumentCrear;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setNDocumentCrear(java.lang.String value) {
         _NDocumentCrear = value;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.String getDataDocument() {
         return _DataDocument;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setDataDocument(java.lang.String value) {
         _DataDocument = value;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.String getTipusRegistre() {
         return _TipusRegistre;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setTipusRegistre(java.lang.String value) {
         _TipusRegistre = value;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.String getDataCompt() {
         return _DataCompt;
      }

      /**
       * Documentaci�.
       *
       * @param value Documentaci�
       */
      public void setDataCompt(java.lang.String value) {
         _DataCompt = value;
      }

      /**
       * Documentaci�.
       *
       * @param context Documentaci�
       *
       */
      public void serializeBody(
         net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.XMLSerializer context)
         throws org.xml.sax.SAXException {
         context.startElement("", "TipusRegistre");
         context.endNamespaceDecls();
         context.endAttributes();

         try {
            context.text(((java.lang.String) _TipusRegistre), "TipusRegistre");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endElement();
         context.startElement("", "Transaccio");
         context.endNamespaceDecls();
         context.endAttributes();

         try {
            context.text(((java.lang.String) _Transaccio), "Transaccio");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endElement();
         context.startElement("", "TipusOperacio");
         context.endNamespaceDecls();
         context.endAttributes();

         try {
            context.text(((java.lang.String) _TipusOperacio), "TipusOperacio");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endElement();
         context.startElement("", "Societat");
         context.endNamespaceDecls();
         context.endAttributes();

         try {
            context.text(((java.lang.String) _Societat), "Societat");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endElement();
         context.startElement("", "DataDocument");
         context.endNamespaceDecls();
         context.endAttributes();

         try {
            context.text(((java.lang.String) _DataDocument), "DataDocument");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endElement();
         context.startElement("", "DataCompt");
         context.endNamespaceDecls();
         context.endAttributes();

         try {
            context.text(((java.lang.String) _DataCompt), "DataCompt");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endElement();
         context.startElement("", "ClasseDocument");
         context.endNamespaceDecls();
         context.endAttributes();

         try {
            context.text(((java.lang.String) _ClasseDocument), "ClasseDocument");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endElement();
         context.startElement("", "NDocumentModificar");
         context.endNamespaceDecls();
         context.endAttributes();

         try {
            context.text(((java.lang.String) _NDocumentModificar),
               "NDocumentModificar");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endElement();
         context.startElement("", "Posicio");
         context.endNamespaceDecls();
         context.endAttributes();

         try {
            context.text(((java.lang.String) _Posicio), "Posicio");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endElement();
         context.startElement("", "NDocumentCrear");
         context.endNamespaceDecls();
         context.endAttributes();

         try {
            context.text(((java.lang.String) _NDocumentCrear), "NDocumentCrear");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endElement();
         context.startElement("", "Import");
         context.endNamespaceDecls();
         context.endAttributes();

         try {
            context.text(((java.lang.String) _Import), "Import");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endElement();
         context.startElement("", "Text");
         context.endNamespaceDecls();
         context.endAttributes();

         try {
            context.text(((java.lang.String) _Text), "Text");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endElement();
      }

      /**
       * Documentaci�.
       *
       * @param context Documentaci�
       *
       */
      public void serializeAttributes(
         net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.XMLSerializer context)
         throws org.xml.sax.SAXException {
         if (has_Order) {
            context.startAttribute("", "order");

            try {
               context.text(javax.xml.bind.DatatypeConverter.printInt(
                     ((int) _Order)), "Order");
            } catch (java.lang.Exception e) {
               net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.Util.handlePrintConversionException(this,
                  e, context);
            }

            context.endAttribute();
         }
      }

      /**
       * Documentaci�.
       *
       * @param context Documentaci�
       *
       */
      public void serializeURIs(
         net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.XMLSerializer context)
         throws org.xml.sax.SAXException {
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.lang.Class getPrimaryInterface() {
         return (net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType.class);
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
         if (schemaFragment == null) {
            schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                  "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                  "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                  "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                  "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                  "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsr\u0000\'com.sun." +
                  "msv.grammar.trex.ElementPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\tnameClasst\u0000\u001fLco" +
                  "m/sun/msv/grammar/NameClass;xr\u0000\u001ecom.sun.msv.grammar.ElementE" +
                  "xp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aignoreUndeclaredAttributesL\u0000\fcontentModelq\u0000~" +
                  "\u0000\u0002xq\u0000~\u0000\u0003pp\u0000sq\u0000~\u0000\u0000ppsr\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000" +
                  "\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004nam" +
                  "et\u0000\u001dLcom/sun/msv/util/StringPair;xq\u0000~\u0000\u0003ppsr\u0000)com.sun.msv.dat" +
                  "atype.xsd.EnumerationFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0006valuest\u0000\u000fLjava/util/" +
                  "Set;xr\u00009com.sun.msv.datatype.xsd.DataTypeWithValueConstraint" +
                  "Facet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.xsd.DataTypeWithFac" +
                  "et\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFacetFixedZ\u0000\u0012needValueCheckFlagL\u0000\bbaseType" +
                  "t\u0000)Lcom/sun/msv/datatype/xsd/XSDatatypeImpl;L\u0000\fconcreteTypet" +
                  "\u0000\'Lcom/sun/msv/datatype/xsd/ConcreteType;L\u0000\tfacetNamet\u0000\u0012Ljav" +
                  "a/lang/String;xr\u0000\'com.sun.msv.datatype.xsd.XSDatatypeImpl\u0000\u0000\u0000" +
                  "\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUriq\u0000~\u0000 L\u0000\btypeNameq\u0000~\u0000 L\u0000\nwhiteSpacet\u0000." +
                  "Lcom/sun/msv/datatype/xsd/WhiteSpaceProcessor;xpt\u0000\u0000psr\u00005com." +
                  "sun.msv.datatype.xsd.WhiteSpaceProcessor$Preserve\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000" +
                  "xr\u0000,com.sun.msv.datatype.xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000x" +
                  "p\u0000\u0000sr\u0000#com.sun.msv.datatype.xsd.StringType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001Z\u0000\risAl" +
                  "waysValidxr\u0000*com.sun.msv.datatype.xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000" +
                  "\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datatype.xsd.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq" +
                  "\u0000~\u0000!t\u0000 http://www.w3.org/2001/XMLSchemat\u0000\u0006stringq\u0000~\u0000\'\u0001q\u0000~\u0000+t" +
                  "\u0000\u000benumerationsr\u0000\u0011java.util.HashSet\u00baD\u0085\u0095\u0096\u00b8\u00b74\u0003\u0000\u0000xpw\f\u0000\u0000\u0000\u0010?@\u0000\u0000\u0000\u0000\u0000" +
                  "\u0001t\u0000\u00011xsr\u00000com.sun.msv.grammar.Expression$NullSetExpression\u0000\u0000" +
                  "\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L" +
                  "\u0000\tlocalNameq\u0000~\u0000 L\u0000\fnamespaceURIq\u0000~\u0000 xpt\u0000\u000estring-derivedq\u0000~\u0000$" +
                  "sr\u0000\u001dcom.sun.msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsr\u0000 com." +
                  "sun.msv.grammar.AttributeExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameCla" +
                  "ssq\u0000~\u0000\u0012xq\u0000~\u0000\u0003sr\u0000\u0011java.lang.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psq\u0000" +
                  "~\u0000\u0016ppsr\u0000\"com.sun.msv.datatype.xsd.QnameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000)" +
                  "q\u0000~\u0000,t\u0000\u0005QNamesr\u00005com.sun.msv.datatype.xsd.WhiteSpaceProcesso" +
                  "r$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000&q\u0000~\u00003sq\u0000~\u00004q\u0000~\u0000@q\u0000~\u0000,sr\u0000#com.sun." +
                  "msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000 L\u0000\fna" +
                  "mespaceURIq\u0000~\u0000 xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000x" +
                  "pt\u0000\u0004typet\u0000)http://www.w3.org/2001/XMLSchema-instancesr\u00000com." +
                  "sun.msv.grammar.Expression$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000" +
                  "\u0003sq\u0000~\u0000;\u0001q\u0000~\u0000Jsq\u0000~\u0000Dt\u0000\rTipusRegistreq\u0000~\u0000$sq\u0000~\u0000\u0011pp\u0000sq\u0000~\u0000\u0000ppsq\u0000" +
                  "~\u0000\u0016ppsr\u0000\'com.sun.msv.datatype.xsd.MaxLengthFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I" +
                  "\u0000\tmaxLengthxq\u0000~\u0000\u001cq\u0000~\u0000$pq\u0000~\u0000\'\u0000\u0000q\u0000~\u0000+q\u0000~\u0000+t\u0000\tmaxLength\u0000\u0000\u0000\u0014q\u0000~\u0000" +
                  "3sq\u0000~\u00004t\u0000\u000estring-derivedq\u0000~\u0000$sq\u0000~\u00007ppsq\u0000~\u00009q\u0000~\u0000<pq\u0000~\u0000=q\u0000~\u0000Fq" +
                  "\u0000~\u0000Jsq\u0000~\u0000Dt\u0000\nTransaccioq\u0000~\u0000$sq\u0000~\u0000\u0011pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0016ppsq\u0000~\u0000\u001aq" +
                  "\u0000~\u0000$pq\u0000~\u0000\'\u0000\u0000q\u0000~\u0000+q\u0000~\u0000+q\u0000~\u0000.sq\u0000~\u0000/w\f\u0000\u0000\u0000\u0010?@\u0000\u0000\u0000\u0000\u0000\u0002t\u0000\u00012t\u0000\u00011xq\u0000~\u0000" +
                  "3sq\u0000~\u00004t\u0000\u000estring-derivedq\u0000~\u0000$sq\u0000~\u00007ppsq\u0000~\u00009q\u0000~\u0000<pq\u0000~\u0000=q\u0000~\u0000Fq" +
                  "\u0000~\u0000Jsq\u0000~\u0000Dt\u0000\rTipusOperacioq\u0000~\u0000$sq\u0000~\u0000\u0011pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0016ppsq\u0000~" +
                  "\u0000Qq\u0000~\u0000$pq\u0000~\u0000\'\u0000\u0000q\u0000~\u0000+q\u0000~\u0000+q\u0000~\u0000S\u0000\u0000\u0000\u0004q\u0000~\u00003sq\u0000~\u00004t\u0000\u000estring-deriv" +
                  "edq\u0000~\u0000$sq\u0000~\u00007ppsq\u0000~\u00009q\u0000~\u0000<pq\u0000~\u0000=q\u0000~\u0000Fq\u0000~\u0000Jsq\u0000~\u0000Dt\u0000\bSocietatq" +
                  "\u0000~\u0000$sq\u0000~\u0000\u0011pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0016ppsq\u0000~\u0000Qq\u0000~\u0000$pq\u0000~\u0000\'\u0000\u0000q\u0000~\u0000+q\u0000~\u0000+q\u0000" +
                  "~\u0000S\u0000\u0000\u0000\bq\u0000~\u00003sq\u0000~\u00004t\u0000\u000estring-derivedq\u0000~\u0000$sq\u0000~\u00007ppsq\u0000~\u00009q\u0000~\u0000<p" +
                  "q\u0000~\u0000=q\u0000~\u0000Fq\u0000~\u0000Jsq\u0000~\u0000Dt\u0000\fDataDocumentq\u0000~\u0000$sq\u0000~\u0000\u0011pp\u0000sq\u0000~\u0000\u0000ppsq" +
                  "\u0000~\u0000\u0016ppsq\u0000~\u0000Qq\u0000~\u0000$pq\u0000~\u0000\'\u0000\u0000q\u0000~\u0000+q\u0000~\u0000+q\u0000~\u0000S\u0000\u0000\u0000\bq\u0000~\u00003sq\u0000~\u00004t\u0000\u000est" +
                  "ring-derivedq\u0000~\u0000$sq\u0000~\u00007ppsq\u0000~\u00009q\u0000~\u0000<pq\u0000~\u0000=q\u0000~\u0000Fq\u0000~\u0000Jsq\u0000~\u0000Dt\u0000" +
                  "\tDataComptq\u0000~\u0000$sq\u0000~\u0000\u0011pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0016ppsq\u0000~\u0000Qq\u0000~\u0000$pq\u0000~\u0000\'\u0000\u0000q" +
                  "\u0000~\u0000+q\u0000~\u0000+q\u0000~\u0000S\u0000\u0000\u0000\u0002q\u0000~\u00003sq\u0000~\u00004t\u0000\u000estring-derivedq\u0000~\u0000$sq\u0000~\u00007pps" +
                  "q\u0000~\u00009q\u0000~\u0000<pq\u0000~\u0000=q\u0000~\u0000Fq\u0000~\u0000Jsq\u0000~\u0000Dt\u0000\u000eClasseDocumentq\u0000~\u0000$sq\u0000~\u0000\u0011" +
                  "pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0016ppsq\u0000~\u0000Qq\u0000~\u0000$pq\u0000~\u0000\'\u0000\u0000q\u0000~\u0000+q\u0000~\u0000+q\u0000~\u0000S\u0000\u0000\u0000\nq\u0000~" +
                  "\u00003sq\u0000~\u00004t\u0000\u000estring-derivedq\u0000~\u0000$sq\u0000~\u00007ppsq\u0000~\u00009q\u0000~\u0000<pq\u0000~\u0000=q\u0000~\u0000F" +
                  "q\u0000~\u0000Jsq\u0000~\u0000Dt\u0000\u0012NDocumentModificarq\u0000~\u0000$sq\u0000~\u0000\u0011pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0016" +
                  "ppsq\u0000~\u0000Qq\u0000~\u0000$pq\u0000~\u0000\'\u0000\u0000q\u0000~\u0000+q\u0000~\u0000+q\u0000~\u0000S\u0000\u0000\u0000\u0003q\u0000~\u00003sq\u0000~\u00004t\u0000\u000estring" +
                  "-derivedq\u0000~\u0000$sq\u0000~\u00007ppsq\u0000~\u00009q\u0000~\u0000<pq\u0000~\u0000=q\u0000~\u0000Fq\u0000~\u0000Jsq\u0000~\u0000Dt\u0000\u0007Pos" +
                  "icioq\u0000~\u0000$sq\u0000~\u0000\u0011pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0016ppsq\u0000~\u0000Qq\u0000~\u0000$pq\u0000~\u0000\'\u0000\u0000q\u0000~\u0000+q\u0000" +
                  "~\u0000+q\u0000~\u0000S\u0000\u0000\u0000\nq\u0000~\u00003sq\u0000~\u00004t\u0000\u000estring-derivedq\u0000~\u0000$sq\u0000~\u00007ppsq\u0000~\u00009q" +
                  "\u0000~\u0000<pq\u0000~\u0000=q\u0000~\u0000Fq\u0000~\u0000Jsq\u0000~\u0000Dt\u0000\u000eNDocumentCrearq\u0000~\u0000$sq\u0000~\u0000\u0011pp\u0000sq\u0000" +
                  "~\u0000\u0000ppsq\u0000~\u0000\u0016ppsq\u0000~\u0000Qq\u0000~\u0000$pq\u0000~\u0000\'\u0000\u0000q\u0000~\u0000+q\u0000~\u0000+q\u0000~\u0000S\u0000\u0000\u0000\rq\u0000~\u00003sq\u0000~" +
                  "\u00004t\u0000\u000estring-derivedq\u0000~\u0000$sq\u0000~\u00007ppsq\u0000~\u00009q\u0000~\u0000<pq\u0000~\u0000=q\u0000~\u0000Fq\u0000~\u0000Js" +
                  "q\u0000~\u0000Dt\u0000\u0006Importq\u0000~\u0000$sq\u0000~\u0000\u0011pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0016ppsq\u0000~\u0000Qq\u0000~\u0000$pq\u0000~\u0000" +
                  "\'\u0000\u0000q\u0000~\u0000+q\u0000~\u0000+q\u0000~\u0000S\u0000\u0000\u00002q\u0000~\u00003sq\u0000~\u00004t\u0000\u000estring-derivedq\u0000~\u0000$sq\u0000~\u0000" +
                  "7ppsq\u0000~\u00009q\u0000~\u0000<pq\u0000~\u0000=q\u0000~\u0000Fq\u0000~\u0000Jsq\u0000~\u0000Dt\u0000\u0004Textq\u0000~\u0000$sq\u0000~\u00007ppsq\u0000~" +
                  "\u00009q\u0000~\u0000<psq\u0000~\u0000\u0016ppsr\u0000 com.sun.msv.datatype.xsd.IntType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                  "\u0002\u0000\u0000xr\u0000+com.sun.msv.datatype.xsd.IntegerDerivedType\u0099\u00f1]\u0090&6k\u00be\u0002\u0000" +
                  "\u0001L\u0000\nbaseFacetsq\u0000~\u0000\u001exq\u0000~\u0000)q\u0000~\u0000,t\u0000\u0003intq\u0000~\u0000Bsr\u0000*com.sun.msv.dat" +
                  "atype.xsd.MaxInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.dataty" +
                  "pe.xsd.RangeFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\nlimitValuet\u0000\u0012Ljava/lang/Objec" +
                  "t;xq\u0000~\u0000\u001cppq\u0000~\u0000B\u0000\u0001sr\u0000*com.sun.msv.datatype.xsd.MinInclusiveFa" +
                  "cet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u00c9ppq\u0000~\u0000B\u0000\u0000sr\u0000!com.sun.msv.datatype.xsd.Lo" +
                  "ngType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u00c5q\u0000~\u0000,t\u0000\u0004longq\u0000~\u0000Bsq\u0000~\u0000\u00c8ppq\u0000~\u0000B\u0000\u0001sq\u0000~\u0000" +
                  "\u00ccppq\u0000~\u0000B\u0000\u0000sr\u0000$com.sun.msv.datatype.xsd.IntegerType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000" +
                  "\u0000xq\u0000~\u0000\u00c5q\u0000~\u0000,t\u0000\u0007integerq\u0000~\u0000Bsr\u0000,com.sun.msv.datatype.xsd.Frac" +
                  "tionDigitsFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scalexr\u0000;com.sun.msv.datatype.x" +
                  "sd.DataTypeWithLexicalConstraintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000\u001dppq\u0000~\u0000" +
                  "B\u0001\u0000sr\u0000#com.sun.msv.datatype.xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000)q" +
                  "\u0000~\u0000,t\u0000\u0007decimalq\u0000~\u0000Bq\u0000~\u0000\u00dat\u0000\u000efractionDigits\u0000\u0000\u0000\u0000q\u0000~\u0000\u00d4t\u0000\fminIncl" +
                  "usivesr\u0000\u000ejava.lang.Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010java.lang.Numb" +
                  "er\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u0000\u00d4t\u0000\fmaxInclusivesq\u0000~\u0000\u00de\u007f\u00ff\u00ff\u00ff\u00ff\u00ff\u00ff\u00ffq\u0000~" +
                  "\u0000\u00cfq\u0000~\u0000\u00ddsr\u0000\u0011java.lang.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000\u00df\u0080\u0000\u0000\u0000q\u0000~" +
                  "\u0000\u00cfq\u0000~\u0000\u00e1sq\u0000~\u0000\u00e3\u007f\u00ff\u00ff\u00ffq\u0000~\u00003sq\u0000~\u00004q\u0000~\u0000\u00c7q\u0000~\u0000,sq\u0000~\u0000Dt\u0000\u0005orderq\u0000~\u0000$q\u0000~" +
                  "\u0000Jsr\u0000\"com.sun.msv.grammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTab" +
                  "let\u0000/Lcom/sun/msv/grammar/ExpressionPool$ClosedHash;xpsr\u0000-co" +
                  "m.sun.msv.grammar.ExpressionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005cou" +
                  "ntB\u0000\rstreamVersionL\u0000\u0006parentt\u0000$Lcom/sun/msv/grammar/Expressio" +
                  "nPool;xp\u0000\u0000\u0000%\u0001pq\u0000~\u0000\u000bq\u0000~\u0000\u0007q\u0000~\u0000\u0005q\u0000~\u0000|q\u0000~\u0000\tq\u0000~\u0000\nq\u0000~\u0000\u00c1q\u0000~\u0000\u0090q\u0000~\u0000rq" +
                  "\u0000~\u0000\fq\u0000~\u0000\u00a4q\u0000~\u0000\bq\u0000~\u0000\u000eq\u0000~\u0000\u000fq\u0000~\u0000Oq\u0000~\u0000\u00b8q\u0000~\u00008q\u0000~\u0000Vq\u0000~\u0000cq\u0000~\u0000mq\u0000~\u0000wq" +
                  "\u0000~\u0000\u0081q\u0000~\u0000\u008bq\u0000~\u0000hq\u0000~\u0000\u0095q\u0000~\u0000\u009fq\u0000~\u0000\u00a9q\u0000~\u0000\u0086q\u0000~\u0000\u00b3q\u0000~\u0000[q\u0000~\u0000\u00bdq\u0000~\u0000\u0006q\u0000~\u0000\u00aeq" +
                  "\u0000~\u0000\u0015q\u0000~\u0000\u009aq\u0000~\u0000\rq\u0000~\u0000\u0010x"));
         }

         return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
      }
   }
}
