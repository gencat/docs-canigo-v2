/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPDHelper.verification;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class RetencionsTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    */
   public void check(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType master) {
      if (true) {
         // If left exists
         // No check for primitive values
         checkOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getOrder()));
      }

      if (null == master.getDadaRetencio()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "DadaRetencio"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check count
         if (master.getDadaRetencio().size() < 1) {
            // Report minimum of occurences violated
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "DadaRetencio"),
                  new de.fzi.dbs.verification.event.structure.TooFewElementsProblem(
                     master.getDadaRetencio().size(), 1)));
         }

         // Check value
         checkDadaRetencio(parentLocator, handler, master,
            master.getDadaRetencio());
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param values Documentaci�
    */
   public void checkDadaRetencio(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType master,
      java.util.List values) {
      for (int index = 0; (index < values.size()); index++) {
         java.lang.Object item = values.get(index);
         checkDadaRetencio(parentLocator, handler, master, index, item);
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param index Documentaci�
    * @param value Documentaci�
    */
   public void checkDadaRetencio(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType master,
      int index, java.lang.Object value) {
      if (value instanceof net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType) {
         net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType realValue =
            ((net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType) value);

         {
            // Check complex value
            net.gencat.gecat.batch.DocumentsOCPDHelper.verification.RetencionsTypeVerifier.DadaRetencioTypeVerifier verifier =
               new net.gencat.gecat.batch.DocumentsOCPDHelper.verification.RetencionsTypeVerifier.DadaRetencioTypeVerifier();
            verifier.check(new de.fzi.dbs.verification.event.EntryLocator(
                  parentLocator, master, "DadaRetencio", index), handler,
               realValue);
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.EntryLocator(
                     parentLocator, master, "DadaRetencio", index),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Order"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Order"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param object Documentaci�
    */
   public void check(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
      check(parentLocator, handler,
         ((net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType) object));
   }

   /**
    * Documentaci�.
    *
    * @param handler Documentaci�
    * @param object Documentaci�
    */
   public void check(javax.xml.bind.ValidationEventHandler handler,
      java.lang.Object object) {
      check(null, handler,
         ((net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType) object));
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   public static class DadaRetencioTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       */
      public void check(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType master) {
         if (true) {
            // If left exists
            // No check for primitive values
            checkImportBaseFieldType(parentLocator, handler, master,
               new java.lang.Integer(master.getImportBaseFieldType()));
         }

         if (true) {
            // If left exists
            // No check for primitive values
            checkImportBaseLength(parentLocator, handler, master,
               new java.lang.Integer(master.getImportBaseLength()));
         }

         if (true) {
            // If left exists
            // No check for primitive values
            checkImportBaseOrder(parentLocator, handler, master,
               new java.lang.Integer(master.getImportBaseOrder()));
         }

         if (true) {
            // If left exists
            // No check for primitive values
            checkImportRetencioFieldType(parentLocator, handler, master,
               new java.lang.Integer(master.getImportRetencioFieldType()));
         }

         if (true) {
            // If left exists
            // No check for primitive values
            checkImportRetencioLength(parentLocator, handler, master,
               new java.lang.Integer(master.getImportRetencioLength()));
         }

         if (true) {
            // If left exists
            // No check for primitive values
            checkImportRetencioOrder(parentLocator, handler, master,
               new java.lang.Integer(master.getImportRetencioOrder()));
         }

         if (true) {
            // If left exists
            // No check for primitive values
            checkIndicadorRetencioLength(parentLocator, handler, master,
               new java.lang.Integer(master.getIndicadorRetencioLength()));
         }

         if (true) {
            // If left exists
            // No check for primitive values
            checkIndicadorRetencioOrder(parentLocator, handler, master,
               new java.lang.Integer(master.getIndicadorRetencioOrder()));
         }

         if (true) {
            // If left exists
            // No check for primitive values
            checkTipusRegistreLength(parentLocator, handler, master,
               new java.lang.Integer(master.getTipusRegistreLength()));
         }

         if (true) {
            // If left exists
            // No check for primitive values
            checkTipusRegistreOrder(parentLocator, handler, master,
               new java.lang.Integer(master.getTipusRegistreOrder()));
         }

         if (true) {
            // If left exists
            // No check for primitive values
            checkOrder(parentLocator, handler, master,
               new java.lang.Integer(master.getOrder()));
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkImportBaseLength(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType master,
         java.lang.Integer value) {
         if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.IntType datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "ImportBaseLength"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "ImportBaseLength"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkImportBaseFieldType(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType master,
         java.lang.Integer value) {
         if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.IntType datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "ImportBaseFieldType"),
                        problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "ImportBaseFieldType"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkIndicadorRetencioOrder(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType master,
         java.lang.Integer value) {
         if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.IntType datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "IndicadorRetencioOrder"),
                        problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "IndicadorRetencioOrder"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkTipusRegistreLength(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType master,
         java.lang.Integer value) {
         if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.IntType datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "TipusRegistreLength"),
                        problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "TipusRegistreLength"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkImportRetencioFieldType(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType master,
         java.lang.Integer value) {
         if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.IntType datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "ImportRetencioFieldType"),
                        problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "ImportRetencioFieldType"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkTipusRegistreOrder(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType master,
         java.lang.Integer value) {
         if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.IntType datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "TipusRegistreOrder"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "TipusRegistreOrder"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkOrder(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType master,
         java.lang.Integer value) {
         if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.IntType datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "Order"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Order"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkIndicadorRetencioLength(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType master,
         java.lang.Integer value) {
         if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.IntType datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "IndicadorRetencioLength"),
                        problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "IndicadorRetencioLength"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkImportRetencioOrder(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType master,
         java.lang.Integer value) {
         if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.IntType datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "ImportRetencioOrder"),
                        problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "ImportRetencioOrder"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkImportRetencioLength(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType master,
         java.lang.Integer value) {
         if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.IntType datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "ImportRetencioLength"),
                        problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "ImportRetencioLength"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkImportBaseOrder(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType master,
         java.lang.Integer value) {
         if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.IntType datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "ImportBaseOrder"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "ImportBaseOrder"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param object Documentaci�
       */
      public void check(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
         check(parentLocator, handler,
            ((net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType) object));
      }

      /**
       * Documentaci�.
       *
       * @param handler Documentaci�
       * @param object Documentaci�
       */
      public void check(javax.xml.bind.ValidationEventHandler handler,
         java.lang.Object object) {
         check(null, handler,
            ((net.gencat.gecat.batch.DocumentsOCPDHelper.RetencionsType.DadaRetencioType) object));
      }
   }
}
