/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DesbloqueigOxInterficieHelper;


/**
 * Java content class for DadesType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DesbloqueigOxInterficieHelper.xsd line 34)
 * <p>
 * <pre>
 * &lt;complexType name="DadesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="LiniaDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
 *       &lt;attribute name="LiniaDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *       &lt;attribute name="NDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *       &lt;attribute name="NDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
 *       &lt;attribute name="SocietatLength" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *       &lt;attribute name="SocietatOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *       &lt;attribute name="TransaccioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="20" />
 *       &lt;attribute name="TransaccioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface DadesType {
   /**
    * Gets the value of the liniaDocumentLength property.
    *
    */
   int getLiniaDocumentLength();

   /**
    * Sets the value of the liniaDocumentLength property.
    *
    */
   void setLiniaDocumentLength(int value);

   /**
    * Gets the value of the nDocumentLength property.
    *
    */
   int getNDocumentLength();

   /**
    * Sets the value of the nDocumentLength property.
    *
    */
   void setNDocumentLength(int value);

   /**
    * Gets the value of the order property.
    *
    */
   int getOrder();

   /**
    * Sets the value of the order property.
    *
    */
   void setOrder(int value);

   /**
    * Gets the value of the transaccioOrder property.
    *
    */
   int getTransaccioOrder();

   /**
    * Sets the value of the transaccioOrder property.
    *
    */
   void setTransaccioOrder(int value);

   /**
    * Gets the value of the transaccioLength property.
    *
    */
   int getTransaccioLength();

   /**
    * Sets the value of the transaccioLength property.
    *
    */
   void setTransaccioLength(int value);

   /**
    * Gets the value of the liniaDocumentOrder property.
    *
    */
   int getLiniaDocumentOrder();

   /**
    * Sets the value of the liniaDocumentOrder property.
    *
    */
   void setLiniaDocumentOrder(int value);

   /**
    * Gets the value of the nDocumentOrder property.
    *
    */
   int getNDocumentOrder();

   /**
    * Sets the value of the nDocumentOrder property.
    *
    */
   void setNDocumentOrder(int value);

   /**
    * Gets the value of the societatOrder property.
    *
    */
   int getSocietatOrder();

   /**
    * Sets the value of the societatOrder property.
    *
    */
   void setSocietatOrder(int value);

   /**
    * Gets the value of the societatLength property.
    *
    */
   int getSocietatLength();

   /**
    * Sets the value of the societatLength property.
    *
    */
   void setSocietatLength(int value);
}
