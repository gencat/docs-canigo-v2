/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsComplementaris;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the net.gencat.gecat.batch.DocumentsComplementaris package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 *
 */
public class ObjectFactory extends net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.DefaultJAXBContextImpl {
   /**
    * Documentaci�.
    */
   private static java.util.HashMap defaultImplementations = new java.util.HashMap(16,
         0.75F);

   /**
    * Documentaci�.
    */
   private static java.util.HashMap rootTagMap = new java.util.HashMap();

   /**
    * Documentaci�.
    */
   public static final net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.GrammarInfo grammarInfo =
      new net.gencat.gecat.batch.DocumentsComplementaris.impl.runtime.GrammarInfoImpl(rootTagMap,
         defaultImplementations,
         (net.gencat.gecat.batch.DocumentsComplementaris.ObjectFactory.class));

   /**
    * Documentaci�.
    */
   public static final java.lang.Class version = (net.gencat.gecat.batch.DocumentsComplementaris.impl.JAXBVersion.class);

   static {
      defaultImplementations.put((net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsComplementaris.class),
         "net.gencat.gecat.batch.DocumentsComplementaris.impl.DadesDocumentsComplementarisImpl");
      defaultImplementations.put((net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType.class),
         "net.gencat.gecat.batch.DocumentsComplementaris.impl.DadesDocumentsTypeImpl.DadaDocumentTypeImpl");
      defaultImplementations.put((net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.class),
         "net.gencat.gecat.batch.DocumentsComplementaris.impl.DadesDocumentsTypeImpl");
      defaultImplementations.put((net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsComplementarisType.class),
         "net.gencat.gecat.batch.DocumentsComplementaris.impl.DadesDocumentsComplementarisTypeImpl");
   }

   /**
    * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: net.gencat.gecat.batch.DocumentsComplementaris
    *
    */
   public ObjectFactory() {
      super(grammarInfo);
   }

   /**
    * Create an instance of the specified Java content interface.
    *
    * @param javaContentInterface
    *     the Class object of the javacontent interface to instantiate
    * @return
    *     a new instance
    * @throws JAXBException
    *     if an error occurs
    */
   public java.lang.Object newInstance(java.lang.Class javaContentInterface)
      throws javax.xml.bind.JAXBException {
      return super.newInstance(javaContentInterface);
   }

   /**
    * Get the specified property. This method can only be
    * used to get provider specific properties.
    * Attempting to get an undefined property will result
    * in a PropertyException being thrown.
    *
    * @param name
    *     the name of the property to retrieve
    * @return
    *     the value of the requested property
    * @throws PropertyException
    *     when there is an error retrieving the given property or value
    */
   public java.lang.Object getProperty(java.lang.String name)
      throws javax.xml.bind.PropertyException {
      return super.getProperty(name);
   }

   /**
    * Set the specified property. This method can only be
    * used to set provider specific properties.
    * Attempting to set an undefined property will result
    * in a PropertyException being thrown.
    *
    * @param value
    *     the value of the property to be set
    * @param name
    *     the name of the property to retrieve
    * @throws PropertyException
    *     when there is an error processing the given property or value
    */
   public void setProperty(java.lang.String name, java.lang.Object value)
      throws javax.xml.bind.PropertyException {
      super.setProperty(name, value);
   }

   /**
    * Create an instance of DadesDocumentsComplementaris
    *
    * @throws JAXBException
    *     if an error occurs
    */
   public net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsComplementaris createDadesDocumentsComplementaris()
      throws javax.xml.bind.JAXBException {
      return new net.gencat.gecat.batch.DocumentsComplementaris.impl.DadesDocumentsComplementarisImpl();
   }

   /**
    * Create an instance of DadesDocumentsTypeDadaDocumentType
    *
    * @throws JAXBException
    *     if an error occurs
    */
   public net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType createDadesDocumentsTypeDadaDocumentType()
      throws javax.xml.bind.JAXBException {
      return new net.gencat.gecat.batch.DocumentsComplementaris.impl.DadesDocumentsTypeImpl.DadaDocumentTypeImpl();
   }

   /**
    * Create an instance of DadesDocumentsType
    *
    * @throws JAXBException
    *     if an error occurs
    */
   public net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType createDadesDocumentsType()
      throws javax.xml.bind.JAXBException {
      return new net.gencat.gecat.batch.DocumentsComplementaris.impl.DadesDocumentsTypeImpl();
   }

   /**
    * Create an instance of DadesDocumentsComplementarisType
    *
    * @throws JAXBException
    *     if an error occurs
    */
   public net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsComplementarisType createDadesDocumentsComplementarisType()
      throws javax.xml.bind.JAXBException {
      return new net.gencat.gecat.batch.DocumentsComplementaris.impl.DadesDocumentsComplementarisTypeImpl();
   }
}
