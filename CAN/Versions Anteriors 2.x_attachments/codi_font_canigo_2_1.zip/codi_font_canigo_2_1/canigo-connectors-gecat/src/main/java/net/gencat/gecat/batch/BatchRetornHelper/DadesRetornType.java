/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.BatchRetornHelper;


/**
 * Java content class for DadesRetornType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/BatchRetornHelper.xsd line 33)
 * <p>
 * <pre>
 * &lt;complexType name="DadesRetornType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DadaRetorn" maxOccurs="2">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="ClasseDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *                 &lt;attribute name="ClasseDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
 *                 &lt;attribute name="CodiPosicioErrorLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *                 &lt;attribute name="CodiPosicioErrorOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="7" />
 *                 &lt;attribute name="ExerciciLength" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *                 &lt;attribute name="ExerciciOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *                 &lt;attribute name="NDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *                 &lt;attribute name="NDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *                 &lt;attribute name="PosicioDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
 *                 &lt;attribute name="PosicioDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
 *                 &lt;attribute name="SocietatFiLength" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *                 &lt;attribute name="SocietatFiOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="StatusDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="StatusDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="6" />
 *                 &lt;attribute name="TextErrorLength" type="{http://www.w3.org/2001/XMLSchema}int" default="100" />
 *                 &lt;attribute name="TextErrorOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface DadesRetornType {
   /**
    * Gets the value of the DadaRetorn property.
    *
    * <p>
    * This accessor method returns a reference to the live list,
    * not a snapshot. Therefore any modification you make to the
    * returned list will be present inside the JAXB object.
    * This is why there is not a <CODE>set</CODE> method for the DadaRetorn property.
    *
    * <p>
    * For example, to add a new item, do as follows:
    * <pre>
    *    getDadaRetorn().add(newItem);
    * </pre>
    *
    *
    * <p>
    * Objects of the following type(s) are allowed in the list
    * {@link net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType}
    *
    */
   java.util.List getDadaRetorn();

   /**
    * Gets the value of the order property.
    *
    */
   int getOrder();

   /**
    * Sets the value of the order property.
    *
    */
   void setOrder(int value);

   /**
    * Java content class for anonymous complex type.
    *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/BatchRetornHelper.xsd line 37)
    * <p>
    * <pre>
    * &lt;complexType>
    *   &lt;complexContent>
    *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
    *       &lt;attribute name="ClasseDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
    *       &lt;attribute name="ClasseDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
    *       &lt;attribute name="CodiPosicioErrorLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
    *       &lt;attribute name="CodiPosicioErrorOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="7" />
    *       &lt;attribute name="ExerciciLength" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
    *       &lt;attribute name="ExerciciOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
    *       &lt;attribute name="NDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
    *       &lt;attribute name="NDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
    *       &lt;attribute name="PosicioDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
    *       &lt;attribute name="PosicioDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
    *       &lt;attribute name="SocietatFiLength" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
    *       &lt;attribute name="SocietatFiOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="StatusDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
    *       &lt;attribute name="StatusDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="6" />
    *       &lt;attribute name="TextErrorLength" type="{http://www.w3.org/2001/XMLSchema}int" default="100" />
    *       &lt;attribute name="TextErrorOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
    *     &lt;/restriction>
    *   &lt;/complexContent>
    * &lt;/complexType>
    * </pre>
    *
    */
   public interface DadaRetornType {
      /**
       * Gets the value of the classeDocumentLength property.
       *
       */
      int getClasseDocumentLength();

      /**
       * Sets the value of the classeDocumentLength property.
       *
       */
      void setClasseDocumentLength(int value);

      /**
       * Gets the value of the exerciciOrder property.
       *
       */
      int getExerciciOrder();

      /**
       * Sets the value of the exerciciOrder property.
       *
       */
      void setExerciciOrder(int value);

      /**
       * Gets the value of the textErrorOrder property.
       *
       */
      int getTextErrorOrder();

      /**
       * Sets the value of the textErrorOrder property.
       *
       */
      void setTextErrorOrder(int value);

      /**
       * Gets the value of the exerciciLength property.
       *
       */
      int getExerciciLength();

      /**
       * Sets the value of the exerciciLength property.
       *
       */
      void setExerciciLength(int value);

      /**
       * Gets the value of the nDocumentLength property.
       *
       */
      int getNDocumentLength();

      /**
       * Sets the value of the nDocumentLength property.
       *
       */
      void setNDocumentLength(int value);

      /**
       * Gets the value of the codiPosicioErrorOrder property.
       *
       */
      int getCodiPosicioErrorOrder();

      /**
       * Sets the value of the codiPosicioErrorOrder property.
       *
       */
      void setCodiPosicioErrorOrder(int value);

      /**
       * Gets the value of the statusDocumentOrder property.
       *
       */
      int getStatusDocumentOrder();

      /**
       * Sets the value of the statusDocumentOrder property.
       *
       */
      void setStatusDocumentOrder(int value);

      /**
       * Gets the value of the codiPosicioErrorLength property.
       *
       */
      int getCodiPosicioErrorLength();

      /**
       * Sets the value of the codiPosicioErrorLength property.
       *
       */
      void setCodiPosicioErrorLength(int value);

      /**
       * Gets the value of the societatFiOrder property.
       *
       */
      int getSocietatFiOrder();

      /**
       * Sets the value of the societatFiOrder property.
       *
       */
      void setSocietatFiOrder(int value);

      /**
       * Gets the value of the statusDocumentLength property.
       *
       */
      int getStatusDocumentLength();

      /**
       * Sets the value of the statusDocumentLength property.
       *
       */
      void setStatusDocumentLength(int value);

      /**
       * Gets the value of the textErrorLength property.
       *
       */
      int getTextErrorLength();

      /**
       * Sets the value of the textErrorLength property.
       *
       */
      void setTextErrorLength(int value);

      /**
       * Gets the value of the posicioDocumentOrder property.
       *
       */
      int getPosicioDocumentOrder();

      /**
       * Sets the value of the posicioDocumentOrder property.
       *
       */
      void setPosicioDocumentOrder(int value);

      /**
       * Gets the value of the posicioDocumentLength property.
       *
       */
      int getPosicioDocumentLength();

      /**
       * Sets the value of the posicioDocumentLength property.
       *
       */
      void setPosicioDocumentLength(int value);

      /**
       * Gets the value of the nDocumentOrder property.
       *
       */
      int getNDocumentOrder();

      /**
       * Sets the value of the nDocumentOrder property.
       *
       */
      void setNDocumentOrder(int value);

      /**
       * Gets the value of the societatFiLength property.
       *
       */
      int getSocietatFiLength();

      /**
       * Sets the value of the societatFiLength property.
       *
       */
      void setSocietatFiLength(int value);

      /**
       * Gets the value of the classeDocumentOrder property.
       *
       */
      int getClasseDocumentOrder();

      /**
       * Sets the value of the classeDocumentOrder property.
       *
       */
      void setClasseDocumentOrder(int value);
   }
}
