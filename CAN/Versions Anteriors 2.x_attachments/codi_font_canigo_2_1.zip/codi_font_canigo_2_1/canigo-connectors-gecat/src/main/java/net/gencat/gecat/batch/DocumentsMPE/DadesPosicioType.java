/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsMPE;


/**
 * Java content class for DadesPosicioType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsMPE.xsd line 124)
 * <p>
 * <pre>
 * &lt;complexType name="DadesPosicioType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DadaPosicio" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;choice>
 *                     &lt;element name="DadesPagadorAlternatiu" type="{}DadesPagadorAlternatiuType"/>
 *                     &lt;element name="BlocImputacio" type="{}BlocImputacioType"/>
 *                   &lt;/choice>
 *                   &lt;element name="TipusRegistre">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="1"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="TextDocument">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="25"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="NExpedient">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="30"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Creditor">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="TipusBancInterlocutor">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="4"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="IndicadorCME">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="1"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="PosicioPressupostaria">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="24"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="CentreGestor">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="16"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Referencia">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="16"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="CondicioPagament">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="4"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Import">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="13"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="ImportImpost">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="13"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="IndicadorIVA">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="2"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="CalcularImpost">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="1"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Text">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="50"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Fons">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="ViaPagament">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="1"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="BloqueigPagament">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="1"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="DataBase">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="8"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="PagadorAlternatiu">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="CompteMajor">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface DadesPosicioType {
   /**
    * Gets the value of the DadaPosicio property.
    *
    * <p>
    * This accessor method returns a reference to the live list,
    * not a snapshot. Therefore any modification you make to the
    * returned list will be present inside the JAXB object.
    * This is why there is not a <CODE>set</CODE> method for the DadaPosicio property.
    *
    * <p>
    * For example, to add a new item, do as follows:
    * <pre>
    *    getDadaPosicio().add(newItem);
    * </pre>
    *
    *
    * <p>
    * Objects of the following type(s) are allowed in the list
    * {@link net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType}
    *
    */
   java.util.List getDadaPosicio();

   /**
    * Java content class for anonymous complex type.
    *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsMPE.xsd line 128)
    * <p>
    * <pre>
    * &lt;complexType>
    *   &lt;complexContent>
    *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
    *       &lt;sequence>
    *         &lt;choice>
    *           &lt;element name="DadesPagadorAlternatiu" type="{}DadesPagadorAlternatiuType"/>
    *           &lt;element name="BlocImputacio" type="{}BlocImputacioType"/>
    *         &lt;/choice>
    *         &lt;element name="TipusRegistre">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="1"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="TextDocument">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="25"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="NExpedient">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="30"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="Creditor">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="10"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="TipusBancInterlocutor">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="4"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="IndicadorCME">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="1"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="PosicioPressupostaria">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="24"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="CentreGestor">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="16"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="Referencia">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="16"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="CondicioPagament">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="4"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="Import">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="13"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="ImportImpost">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="13"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="IndicadorIVA">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="2"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="CalcularImpost">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="1"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="Text">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="50"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="Fons">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="10"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="ViaPagament">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="1"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="BloqueigPagament">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="1"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="DataBase">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="8"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="PagadorAlternatiu">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="10"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="CompteMajor">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="10"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *       &lt;/sequence>
    *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
    *     &lt;/restriction>
    *   &lt;/complexContent>
    * &lt;/complexType>
    * </pre>
    *
    */
   public interface DadaPosicioType {
      /**
       * Gets the value of the tipusBancInterlocutor property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getTipusBancInterlocutor();

      /**
       * Sets the value of the tipusBancInterlocutor property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setTipusBancInterlocutor(java.lang.String value);

      /**
       * Gets the value of the pagadorAlternatiu property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getPagadorAlternatiu();

      /**
       * Sets the value of the pagadorAlternatiu property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setPagadorAlternatiu(java.lang.String value);

      /**
       * Gets the value of the indicadorCME property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getIndicadorCME();

      /**
       * Sets the value of the indicadorCME property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setIndicadorCME(java.lang.String value);

      /**
       * Gets the value of the indicadorIVA property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getIndicadorIVA();

      /**
       * Sets the value of the indicadorIVA property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setIndicadorIVA(java.lang.String value);

      /**
       * Gets the value of the order property.
       *
       */
      int getOrder();

      /**
       * Sets the value of the order property.
       *
       */
      void setOrder(int value);

      /**
       * Gets the value of the text property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getText();

      /**
       * Sets the value of the text property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setText(java.lang.String value);

      /**
       * Gets the value of the import property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getImport();

      /**
       * Sets the value of the import property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setImport(java.lang.String value);

      /**
       * Gets the value of the textDocument property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getTextDocument();

      /**
       * Sets the value of the textDocument property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setTextDocument(java.lang.String value);

      /**
       * Gets the value of the dataBase property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getDataBase();

      /**
       * Sets the value of the dataBase property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setDataBase(java.lang.String value);

      /**
       * Gets the value of the bloqueigPagament property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getBloqueigPagament();

      /**
       * Sets the value of the bloqueigPagament property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setBloqueigPagament(java.lang.String value);

      /**
       * Gets the value of the importImpost property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getImportImpost();

      /**
       * Sets the value of the importImpost property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setImportImpost(java.lang.String value);

      /**
       * Gets the value of the blocImputacio property.
       *
       * @return
       *     possible object is
       *     {@link net.gencat.gecat.batch.DocumentsMPE.BlocImputacioType}
       */
      net.gencat.gecat.batch.DocumentsMPE.BlocImputacioType getBlocImputacio();

      /**
       * Sets the value of the blocImputacio property.
       *
       * @param value
       *     allowed object is
       *     {@link net.gencat.gecat.batch.DocumentsMPE.BlocImputacioType}
       */
      void setBlocImputacio(
         net.gencat.gecat.batch.DocumentsMPE.BlocImputacioType value);

      /**
       * Gets the value of the referencia property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getReferencia();

      /**
       * Sets the value of the referencia property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setReferencia(java.lang.String value);

      /**
       * Gets the value of the posicioPressupostaria property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getPosicioPressupostaria();

      /**
       * Sets the value of the posicioPressupostaria property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setPosicioPressupostaria(java.lang.String value);

      /**
       * Gets the value of the centreGestor property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getCentreGestor();

      /**
       * Sets the value of the centreGestor property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setCentreGestor(java.lang.String value);

      /**
       * Gets the value of the compteMajor property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getCompteMajor();

      /**
       * Sets the value of the compteMajor property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setCompteMajor(java.lang.String value);

      /**
       * Gets the value of the fons property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getFons();

      /**
       * Sets the value of the fons property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setFons(java.lang.String value);

      /**
       * Gets the value of the dadesPagadorAlternatiu property.
       *
       * @return
       *     possible object is
       *     {@link net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType}
       */
      net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType getDadesPagadorAlternatiu();

      /**
       * Sets the value of the dadesPagadorAlternatiu property.
       *
       * @param value
       *     allowed object is
       *     {@link net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType}
       */
      void setDadesPagadorAlternatiu(
         net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType value);

      /**
       * Gets the value of the tipusRegistre property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getTipusRegistre();

      /**
       * Sets the value of the tipusRegistre property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setTipusRegistre(java.lang.String value);

      /**
       * Gets the value of the nExpedient property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getNExpedient();

      /**
       * Sets the value of the nExpedient property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setNExpedient(java.lang.String value);

      /**
       * Gets the value of the calcularImpost property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getCalcularImpost();

      /**
       * Sets the value of the calcularImpost property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setCalcularImpost(java.lang.String value);

      /**
       * Gets the value of the condicioPagament property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getCondicioPagament();

      /**
       * Sets the value of the condicioPagament property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setCondicioPagament(java.lang.String value);

      /**
       * Gets the value of the viaPagament property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getViaPagament();

      /**
       * Sets the value of the viaPagament property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setViaPagament(java.lang.String value);

      /**
       * Gets the value of the creditor property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getCreditor();

      /**
       * Sets the value of the creditor property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setCreditor(java.lang.String value);
   }
}
