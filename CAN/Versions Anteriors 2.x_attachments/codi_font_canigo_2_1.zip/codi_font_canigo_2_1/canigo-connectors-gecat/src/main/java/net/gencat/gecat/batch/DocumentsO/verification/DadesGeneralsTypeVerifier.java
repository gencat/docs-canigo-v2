/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsO.verification;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class DadesGeneralsTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
   /**
    * Documentaci�.
    */
   protected java.lang.Object[] values = new java.lang.Object[] { "1" };

   /**
    * Documentaci�.
    */
   protected java.util.Set valueSet = java.util.Collections.unmodifiableSet(new java.util.HashSet(
            java.util.Arrays.asList(values)));

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    */
   public void check(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsO.DadesGeneralsType master) {
      if (null == master.getDadesPosicio()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "DadesPosicio"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkDadesPosicio(parentLocator, handler, master,
            master.getDadesPosicio());
      }

      if (null == master.getTipusRegistre()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "TipusRegistre"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkTipusRegistre(parentLocator, handler, master,
            master.getTipusRegistre());
      }

      if (null == master.getTransaccio()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "Transaccio"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkTransaccio(parentLocator, handler, master, master.getTransaccio());
      }

      if (null == master.getNDocument()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "NDocument"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkNDocument(parentLocator, handler, master, master.getNDocument());
      }

      if (null == master.getClasseDocument()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "ClasseDocument"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkClasseDocument(parentLocator, handler, master,
            master.getClasseDocument());
      }

      if (null == master.getDataDocument()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "DataDocument"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkDataDocument(parentLocator, handler, master,
            master.getDataDocument());
      }

      if (null == master.getDataCompt()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "DataCompt"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkDataCompt(parentLocator, handler, master, master.getDataCompt());
      }

      if (null == master.getSocietat()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "Societat"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkSocietat(parentLocator, handler, master, master.getSocietat());
      }

      if (null == master.getTipusCanvi()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "TipusCanvi"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkTipusCanvi(parentLocator, handler, master, master.getTipusCanvi());
      }

      if (null == master.getDataConversio()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "DataConversio"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkDataConversio(parentLocator, handler, master,
            master.getDataConversio());
      }

      if (null == master.getMoneda()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "Moneda"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkMoneda(parentLocator, handler, master, master.getMoneda());
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkClasseDocument(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsO.DadesGeneralsType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 2) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 2);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "ClasseDocument"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "ClasseDocument"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkTransaccio(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsO.DadesGeneralsType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 20) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 20);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Transaccio"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Transaccio"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkDadesPosicio(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsO.DadesGeneralsType master,
      net.gencat.gecat.batch.DocumentsO.DadesPosicioType value) {
      if (value instanceof net.gencat.gecat.batch.DocumentsO.DadesPosicioType) {
         net.gencat.gecat.batch.DocumentsO.DadesPosicioType realValue = ((net.gencat.gecat.batch.DocumentsO.DadesPosicioType) value);

         {
            // Check complex value
            net.gencat.gecat.batch.DocumentsO.verification.DadesPosicioTypeVerifier verifier =
               new net.gencat.gecat.batch.DocumentsO.verification.DadesPosicioTypeVerifier();
            verifier.check(new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "DadesPosicio"), handler, realValue);
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "DadesPosicio"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkDataConversio(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsO.DadesGeneralsType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 8) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 8);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "DataConversio"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "DataConversio"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkNDocument(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsO.DadesGeneralsType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 10) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 10);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "NDocument"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "NDocument"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkDataDocument(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsO.DadesGeneralsType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 8) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 8);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "DataDocument"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "DataDocument"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkTipusRegistre(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsO.DadesGeneralsType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.EnumerationFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (valueSet.contains(realValue)) {
               // Value is found in the enumeration, it is valid
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.EnumerationProblem(realValue,
                     valueSet);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "TipusRegistre"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "TipusRegistre"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkSocietat(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsO.DadesGeneralsType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 4) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 4);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Societat"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Societat"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkDataCompt(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsO.DadesGeneralsType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 8) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 8);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "DataCompt"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "DataCompt"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkMoneda(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsO.DadesGeneralsType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 5) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 5);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Moneda"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Moneda"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkTipusCanvi(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsO.DadesGeneralsType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 9) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 9);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "TipusCanvi"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "TipusCanvi"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param object Documentaci�
    */
   public void check(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
      check(parentLocator, handler,
         ((net.gencat.gecat.batch.DocumentsO.DadesGeneralsType) object));
   }

   /**
    * Documentaci�.
    *
    * @param handler Documentaci�
    * @param object Documentaci�
    */
   public void check(javax.xml.bind.ValidationEventHandler handler,
      java.lang.Object object) {
      check(null, handler,
         ((net.gencat.gecat.batch.DocumentsO.DadesGeneralsType) object));
   }
}
