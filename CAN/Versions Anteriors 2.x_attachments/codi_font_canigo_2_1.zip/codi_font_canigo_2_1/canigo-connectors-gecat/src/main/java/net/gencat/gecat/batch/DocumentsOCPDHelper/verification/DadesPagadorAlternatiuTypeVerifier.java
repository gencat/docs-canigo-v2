/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPDHelper.verification;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class DadesPagadorAlternatiuTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    */
   public void check(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master) {
      if (true) {
         // If left exists
         // No check for primitive values
         checkAdrecaLength(parentLocator, handler, master,
            new java.lang.Integer(master.getAdrecaLength()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkAdrecaOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getAdrecaOrder()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkBlocImputacioLength(parentLocator, handler, master,
            new java.lang.Integer(master.getBlocImputacioLength()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkBlocImputacioOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getBlocImputacioOrder()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkClauBancLength(parentLocator, handler, master,
            new java.lang.Integer(master.getClauBancLength()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkClauBancOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getClauBancOrder()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkCodiPostalLength(parentLocator, handler, master,
            new java.lang.Integer(master.getCodiPostalLength()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkCodiPostalOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getCodiPostalOrder()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkCompteLength(parentLocator, handler, master,
            new java.lang.Integer(master.getCompteLength()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkCompteOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getCompteOrder()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkDigitsControlLength(parentLocator, handler, master,
            new java.lang.Integer(master.getDigitsControlLength()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkDigitsControlOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getDigitsControlOrder()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkNIFLength(parentLocator, handler, master,
            new java.lang.Integer(master.getNIFLength()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkNIFOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getNIFOrder()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkNomLength(parentLocator, handler, master,
            new java.lang.Integer(master.getNomLength()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkNomOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getNomOrder()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkPaisBancLength(parentLocator, handler, master,
            new java.lang.Integer(master.getPaisBancLength()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkPaisBancOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getPaisBancOrder()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkPaisLength(parentLocator, handler, master,
            new java.lang.Integer(master.getPaisLength()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkPaisOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getPaisOrder()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkPoblacioLength(parentLocator, handler, master,
            new java.lang.Integer(master.getPoblacioLength()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkPoblacioOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getPoblacioOrder()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkTipusRegistreLength(parentLocator, handler, master,
            new java.lang.Integer(master.getTipusRegistreLength()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkTipusRegistreOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getTipusRegistreOrder()));
      }

      if (true) {
         // If left exists
         // No check for primitive values
         checkOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getOrder()));
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkPaisBancLength(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "PaisBancLength"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "PaisBancLength"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkCodiPostalOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "CodiPostalOrder"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "CodiPostalOrder"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Order"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Order"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkAdrecaLength(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "AdrecaLength"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "AdrecaLength"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkAdrecaOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "AdrecaOrder"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "AdrecaOrder"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkPoblacioLength(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "PoblacioLength"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "PoblacioLength"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkPaisOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "PaisOrder"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "PaisOrder"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkPaisBancOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "PaisBancOrder"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "PaisBancOrder"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkDigitsControlLength(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "DigitsControlLength"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "DigitsControlLength"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkDigitsControlOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "DigitsControlOrder"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "DigitsControlOrder"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkTipusRegistreOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "TipusRegistreOrder"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "TipusRegistreOrder"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkPoblacioOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "PoblacioOrder"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "PoblacioOrder"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkCodiPostalLength(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "CodiPostalLength"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "CodiPostalLength"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkClauBancLength(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "ClauBancLength"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "ClauBancLength"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkClauBancOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "ClauBancOrder"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "ClauBancOrder"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkNIFLength(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "NIFLength"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "NIFLength"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkTipusRegistreLength(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "TipusRegistreLength"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "TipusRegistreLength"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkNomLength(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "NomLength"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "NomLength"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkNIFOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "NIFOrder"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "NIFOrder"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkCompteLength(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "CompteLength"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "CompteLength"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkBlocImputacioOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "BlocImputacioOrder"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "BlocImputacioOrder"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkBlocImputacioLength(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "BlocImputacioLength"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "BlocImputacioLength"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkNomOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "NomOrder"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "NomOrder"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkCompteOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "CompteOrder"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "CompteOrder"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkPaisLength(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "PaisLength"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "PaisLength"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param object Documentaci�
    */
   public void check(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
      check(parentLocator, handler,
         ((net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType) object));
   }

   /**
    * Documentaci�.
    *
    * @param handler Documentaci�
    * @param object Documentaci�
    */
   public void check(javax.xml.bind.ValidationEventHandler handler,
      java.lang.Object object) {
      check(null, handler,
         ((net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPagadorAlternatiuType) object));
   }
}
