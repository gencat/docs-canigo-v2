/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsComplementaris.verification;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class DadesDocumentsTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    */
   public void check(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType master) {
      if (null == master.getDadaDocument()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "DadaDocument"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check count
         if (master.getDadaDocument().size() < 1) {
            // Report minimum of occurences violated
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "DadaDocument"),
                  new de.fzi.dbs.verification.event.structure.TooFewElementsProblem(
                     master.getDadaDocument().size(), 1)));
         }

         // Check value
         checkDadaDocument(parentLocator, handler, master,
            master.getDadaDocument());
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param values Documentaci�
    */
   public void checkDadaDocument(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType master,
      java.util.List values) {
      for (int index = 0; (index < values.size()); index++) {
         java.lang.Object item = values.get(index);
         checkDadaDocument(parentLocator, handler, master, index, item);
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param index Documentaci�
    * @param value Documentaci�
    */
   public void checkDadaDocument(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType master,
      int index, java.lang.Object value) {
      if (value instanceof net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType) {
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType realValue =
            ((net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType) value);

         {
            // Check complex value
            net.gencat.gecat.batch.DocumentsComplementaris.verification.DadesDocumentsTypeVerifier.DadaDocumentTypeVerifier verifier =
               new net.gencat.gecat.batch.DocumentsComplementaris.verification.DadesDocumentsTypeVerifier.DadaDocumentTypeVerifier();
            verifier.check(new de.fzi.dbs.verification.event.EntryLocator(
                  parentLocator, master, "DadaDocument", index), handler,
               realValue);
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.EntryLocator(
                     parentLocator, master, "DadaDocument", index),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param object Documentaci�
    */
   public void check(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
      check(parentLocator, handler,
         ((net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType) object));
   }

   /**
    * Documentaci�.
    *
    * @param handler Documentaci�
    * @param object Documentaci�
    */
   public void check(javax.xml.bind.ValidationEventHandler handler,
      java.lang.Object object) {
      check(null, handler,
         ((net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType) object));
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   public static class DadaDocumentTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
      /**
       * Documentaci�.
       */
      protected java.lang.Object[] values = new java.lang.Object[] { "2", "1" };

      /**
       * Documentaci�.
       */
      protected java.util.Set valueSet = java.util.Collections.unmodifiableSet(new java.util.HashSet(
               java.util.Arrays.asList(values)));

      /**
       * Documentaci�.
       */
      protected java.lang.Object[] values0 = new java.lang.Object[] { "1" };

      /**
       * Documentaci�.
       */
      protected java.util.Set valueSet0 = java.util.Collections.unmodifiableSet(new java.util.HashSet(
               java.util.Arrays.asList(values0)));

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       */
      public void check(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master) {
         if (true) {
            // If left exists
            // No check for primitive values
            checkOrder(parentLocator, handler, master,
               new java.lang.Integer(master.getOrder()));
         }

         if (null == master.getTipusRegistre()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "TipusRegistre"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkTipusRegistre(parentLocator, handler, master,
               master.getTipusRegistre());
         }

         if (null == master.getTransaccio()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Transaccio"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkTransaccio(parentLocator, handler, master,
               master.getTransaccio());
         }

         if (null == master.getTipusOperacio()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "TipusOperacio"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkTipusOperacio(parentLocator, handler, master,
               master.getTipusOperacio());
         }

         if (null == master.getSocietat()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Societat"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkSocietat(parentLocator, handler, master, master.getSocietat());
         }

         if (null == master.getDataDocument()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "DataDocument"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkDataDocument(parentLocator, handler, master,
               master.getDataDocument());
         }

         if (null == master.getDataCompt()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "DataCompt"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkDataCompt(parentLocator, handler, master, master.getDataCompt());
         }

         if (null == master.getClasseDocument()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "ClasseDocument"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkClasseDocument(parentLocator, handler, master,
               master.getClasseDocument());
         }

         if (null == master.getNDocumentModificar()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "NDocumentModificar"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkNDocumentModificar(parentLocator, handler, master,
               master.getNDocumentModificar());
         }

         if (null == master.getPosicio()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Posicio"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkPosicio(parentLocator, handler, master, master.getPosicio());
         }

         if (null == master.getNDocumentCrear()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "NDocumentCrear"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkNDocumentCrear(parentLocator, handler, master,
               master.getNDocumentCrear());
         }

         if (null == master.getImport()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Import"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkImport(parentLocator, handler, master, master.getImport());
         }

         if (null == master.getText()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Text"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkText(parentLocator, handler, master, master.getText());
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkClasseDocument(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 2) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 2);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "ClasseDocument"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "ClasseDocument"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkOrder(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master,
         java.lang.Integer value) {
         if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.IntType datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "Order"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Order"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkNDocumentModificar(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 10) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 10);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "NDocumentModificar"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "NDocumentModificar"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkPosicio(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 3) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 3);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "Posicio"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Posicio"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkSocietat(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 4) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 4);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "Societat"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Societat"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkImport(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 13) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 13);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "Import"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Import"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkText(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 50) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 50);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "Text"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Text"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkTipusOperacio(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.EnumerationFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (valueSet.contains(realValue)) {
                  // Value is found in the enumeration, it is valid
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.EnumerationProblem(realValue,
                        valueSet);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "TipusOperacio"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "TipusOperacio"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkTransaccio(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 20) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 20);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "Transaccio"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Transaccio"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkNDocumentCrear(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 10) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 10);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "NDocumentCrear"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "NDocumentCrear"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkDataDocument(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 8) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 8);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "DataDocument"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "DataDocument"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkTipusRegistre(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.EnumerationFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (valueSet0.contains(realValue)) {
                  // Value is found in the enumeration, it is valid
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.EnumerationProblem(realValue,
                        valueSet0);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "TipusRegistre"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "TipusRegistre"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkDataCompt(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 8) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 8);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "DataCompt"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "DataCompt"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param object Documentaci�
       */
      public void check(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
         check(parentLocator, handler,
            ((net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType) object));
      }

      /**
       * Documentaci�.
       *
       * @param handler Documentaci�
       * @param object Documentaci�
       */
      public void check(javax.xml.bind.ValidationEventHandler handler,
         java.lang.Object object) {
         check(null, handler,
            ((net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType) object));
      }
   }
}
