/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsO;


/**
 * Java content class for DadesPagadorAlternatiuType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsO.xsd line 345)
 * <p>
 * <pre>
 * &lt;complexType name="DadesPagadorAlternatiuType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BlocImputacio" type="{}BlocImputacioType"/>
 *         &lt;element name="TipusRegistre">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;enumeration value="3"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="Nom">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="35"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="Adreca">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="35"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="Poblacio">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="35"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="CodiPostal">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="10"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="Pais">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="3"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="ClauBanc">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="15"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="Compte">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="18"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="DigitsControl">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="2"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="PaisBanc">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="3"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="NIF">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="16"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface DadesPagadorAlternatiuType {
   /**
    * Gets the value of the clauBanc property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getClauBanc();

   /**
    * Sets the value of the clauBanc property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setClauBanc(java.lang.String value);

   /**
    * Gets the value of the paisBanc property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getPaisBanc();

   /**
    * Sets the value of the paisBanc property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setPaisBanc(java.lang.String value);

   /**
    * Gets the value of the nom property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getNom();

   /**
    * Sets the value of the nom property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setNom(java.lang.String value);

   /**
    * Gets the value of the codiPostal property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getCodiPostal();

   /**
    * Sets the value of the codiPostal property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setCodiPostal(java.lang.String value);

   /**
    * Gets the value of the compte property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getCompte();

   /**
    * Sets the value of the compte property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setCompte(java.lang.String value);

   /**
    * Gets the value of the tipusRegistre property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getTipusRegistre();

   /**
    * Sets the value of the tipusRegistre property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setTipusRegistre(java.lang.String value);

   /**
    * Gets the value of the adreca property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getAdreca();

   /**
    * Sets the value of the adreca property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setAdreca(java.lang.String value);

   /**
    * Gets the value of the pais property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getPais();

   /**
    * Sets the value of the pais property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setPais(java.lang.String value);

   /**
    * Gets the value of the poblacio property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getPoblacio();

   /**
    * Sets the value of the poblacio property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setPoblacio(java.lang.String value);

   /**
    * Gets the value of the digitsControl property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getDigitsControl();

   /**
    * Sets the value of the digitsControl property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setDigitsControl(java.lang.String value);

   /**
    * Gets the value of the nif property.
    *
    * @return
    *     possible object is
    *     {@link java.lang.String}
    */
   java.lang.String getNIF();

   /**
    * Sets the value of the nif property.
    *
    * @param value
    *     allowed object is
    *     {@link java.lang.String}
    */
   void setNIF(java.lang.String value);

   /**
    * Gets the value of the blocImputacio property.
    *
    * @return
    *     possible object is
    *     {@link net.gencat.gecat.batch.DocumentsO.BlocImputacioType}
    */
   net.gencat.gecat.batch.DocumentsO.BlocImputacioType getBlocImputacio();

   /**
    * Sets the value of the blocImputacio property.
    *
    * @param value
    *     allowed object is
    *     {@link net.gencat.gecat.batch.DocumentsO.BlocImputacioType}
    */
   void setBlocImputacio(
      net.gencat.gecat.batch.DocumentsO.BlocImputacioType value);
}
