/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsComplementaris;


/**
 * Java content class for DadesDocumentsType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsComplementaris.xsd line 33)
 * <p>
 * <pre>
 * &lt;complexType name="DadesDocumentsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DadaDocument" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TipusRegistre">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;enumeration value="1"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Transaccio">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="20"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="TipusOperacio">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;enumeration value="1"/>
 *                       &lt;enumeration value="2"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Societat">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="4"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="DataDocument">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="8"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="DataCompt">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="8"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="ClasseDocument">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="2"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="NDocumentModificar">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Posicio">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="3"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="NDocumentCrear">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Import">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="13"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Text">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="50"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface DadesDocumentsType {
   /**
    * Gets the value of the DadaDocument property.
    *
    * <p>
    * This accessor method returns a reference to the live list,
    * not a snapshot. Therefore any modification you make to the
    * returned list will be present inside the JAXB object.
    * This is why there is not a <CODE>set</CODE> method for the DadaDocument property.
    *
    * <p>
    * For example, to add a new item, do as follows:
    * <pre>
    *    getDadaDocument().add(newItem);
    * </pre>
    *
    *
    * <p>
    * Objects of the following type(s) are allowed in the list
    * {@link net.gencat.gecat.batch.DocumentsComplementaris.DadesDocumentsType.DadaDocumentType}
    *
    */
   java.util.List getDadaDocument();

   /**
    * Java content class for anonymous complex type.
    *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsComplementaris.xsd line 36)
    * <p>
    * <pre>
    * &lt;complexType>
    *   &lt;complexContent>
    *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
    *       &lt;sequence>
    *         &lt;element name="TipusRegistre">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;enumeration value="1"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="Transaccio">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="20"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="TipusOperacio">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;enumeration value="1"/>
    *             &lt;enumeration value="2"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="Societat">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="4"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="DataDocument">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="8"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="DataCompt">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="8"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="ClasseDocument">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="2"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="NDocumentModificar">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="10"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="Posicio">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="3"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="NDocumentCrear">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="10"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="Import">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="13"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *         &lt;element name="Text">
    *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
    *             &lt;maxLength value="50"/>
    *           &lt;/restriction>
    *         &lt;/element>
    *       &lt;/sequence>
    *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
    *     &lt;/restriction>
    *   &lt;/complexContent>
    * &lt;/complexType>
    * </pre>
    *
    */
   public interface DadaDocumentType {
      /**
       * Gets the value of the classeDocument property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getClasseDocument();

      /**
       * Sets the value of the classeDocument property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setClasseDocument(java.lang.String value);

      /**
       * Gets the value of the order property.
       *
       */
      int getOrder();

      /**
       * Sets the value of the order property.
       *
       */
      void setOrder(int value);

      /**
       * Gets the value of the nDocumentModificar property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getNDocumentModificar();

      /**
       * Sets the value of the nDocumentModificar property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setNDocumentModificar(java.lang.String value);

      /**
       * Gets the value of the posicio property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getPosicio();

      /**
       * Sets the value of the posicio property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setPosicio(java.lang.String value);

      /**
       * Gets the value of the societat property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getSocietat();

      /**
       * Sets the value of the societat property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setSocietat(java.lang.String value);

      /**
       * Gets the value of the import property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getImport();

      /**
       * Sets the value of the import property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setImport(java.lang.String value);

      /**
       * Gets the value of the text property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getText();

      /**
       * Sets the value of the text property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setText(java.lang.String value);

      /**
       * Gets the value of the tipusOperacio property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getTipusOperacio();

      /**
       * Sets the value of the tipusOperacio property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setTipusOperacio(java.lang.String value);

      /**
       * Gets the value of the transaccio property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getTransaccio();

      /**
       * Sets the value of the transaccio property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setTransaccio(java.lang.String value);

      /**
       * Gets the value of the nDocumentCrear property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getNDocumentCrear();

      /**
       * Sets the value of the nDocumentCrear property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setNDocumentCrear(java.lang.String value);

      /**
       * Gets the value of the dataDocument property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getDataDocument();

      /**
       * Sets the value of the dataDocument property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setDataDocument(java.lang.String value);

      /**
       * Gets the value of the tipusRegistre property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getTipusRegistre();

      /**
       * Sets the value of the tipusRegistre property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setTipusRegistre(java.lang.String value);

      /**
       * Gets the value of the dataCompt property.
       *
       * @return
       *     possible object is
       *     {@link java.lang.String}
       */
      java.lang.String getDataCompt();

      /**
       * Sets the value of the dataCompt property.
       *
       * @param value
       *     allowed object is
       *     {@link java.lang.String}
       */
      void setDataCompt(java.lang.String value);
   }
}
