/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime;

import com.sun.xml.bind.JAXBObject;

import org.xml.sax.SAXException;


/**
 * For a generated class to be serializable, it has to
 * implement this interface.
 *
 * @author Kohsuke Kawaguchi
 */
public interface XMLSerializable extends JAXBObject {
   /**
    * Serializes child elements and texts into the specified target.
    */
   void serializeBody(XMLSerializer target) throws SAXException;

   /**
    * Serializes attributes into the specified target.
    */
   void serializeAttributes(XMLSerializer target) throws SAXException;

   /**
    * Declares all the namespace URIs this object is using at
    * its top-level scope into the specified target.
    */
   void serializeURIs(XMLSerializer target) throws SAXException;
}
