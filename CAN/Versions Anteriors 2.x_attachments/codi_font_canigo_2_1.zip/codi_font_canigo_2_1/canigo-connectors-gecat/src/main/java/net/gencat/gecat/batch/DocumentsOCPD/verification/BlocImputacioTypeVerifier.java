/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPD.verification;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class BlocImputacioTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    */
   public void check(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPD.BlocImputacioType master) {
      if (null != master.getRetencions()) {
         // If left exists
         if (null == master.getRetencions()) {
            // Optional field - nothing to report
         } else {
            // Check value
            checkRetencions(parentLocator, handler, master,
               master.getRetencions());
         }
      }

      if (null == master.getTipusRegistre()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "TipusRegistre"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkTipusRegistre(parentLocator, handler, master,
            master.getTipusRegistre());
      }

      if (null == master.getReference()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "Reference"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkReference(parentLocator, handler, master, master.getReference());
      }

      if (null == master.getCodiPIP()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "CodiPIP"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkCodiPIP(parentLocator, handler, master, master.getCodiPIP());
      }

      if (null == master.getVendor()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "Vendor"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkVendor(parentLocator, handler, master, master.getVendor());
      }

      if (null == master.getPagadorAlternatiu()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "PagadorAlternatiu"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check value
         checkPagadorAlternatiu(parentLocator, handler, master,
            master.getPagadorAlternatiu());
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkCodiPIP(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPD.BlocImputacioType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 12) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 12);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "CodiPIP"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "CodiPIP"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkPagadorAlternatiu(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPD.BlocImputacioType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 10) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 10);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "PagadorAlternatiu"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "PagadorAlternatiu"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkTipusRegistre(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPD.BlocImputacioType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 1) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 1);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "TipusRegistre"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "TipusRegistre"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkReference(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPD.BlocImputacioType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 16) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 16);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Reference"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Reference"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkVendor(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPD.BlocImputacioType master,
      java.lang.String value) {
      if (value instanceof java.lang.String) {
         java.lang.String realValue = ((java.lang.String) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (((null == realValue) ? 0 : realValue.length()) <= 10) {
               // Value length is correct
            } else {
               problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                     ((null == realValue) ? 0 : realValue.length()), 10);
            }

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Vendor"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Vendor"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkRetencions(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsOCPD.BlocImputacioType master,
      net.gencat.gecat.batch.DocumentsOCPD.RetencionsType value) {
      if (value instanceof net.gencat.gecat.batch.DocumentsOCPD.RetencionsType) {
         net.gencat.gecat.batch.DocumentsOCPD.RetencionsType realValue = ((net.gencat.gecat.batch.DocumentsOCPD.RetencionsType) value);

         {
            // Check complex value
            net.gencat.gecat.batch.DocumentsOCPD.verification.RetencionsTypeVerifier verifier =
               new net.gencat.gecat.batch.DocumentsOCPD.verification.RetencionsTypeVerifier();
            verifier.check(new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "Retencions"), handler, realValue);
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Retencions"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param object Documentaci�
    */
   public void check(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
      check(parentLocator, handler,
         ((net.gencat.gecat.batch.DocumentsOCPD.BlocImputacioType) object));
   }

   /**
    * Documentaci�.
    *
    * @param handler Documentaci�
    * @param object Documentaci�
    */
   public void check(javax.xml.bind.ValidationEventHandler handler,
      java.lang.Object object) {
      check(null, handler,
         ((net.gencat.gecat.batch.DocumentsOCPD.BlocImputacioType) object));
   }
}
