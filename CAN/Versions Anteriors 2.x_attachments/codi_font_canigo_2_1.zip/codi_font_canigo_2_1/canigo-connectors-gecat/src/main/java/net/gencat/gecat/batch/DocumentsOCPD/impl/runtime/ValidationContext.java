/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPD.impl.runtime;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventHandler;
import javax.xml.bind.helpers.NotIdentifiableEventImpl;
import javax.xml.bind.helpers.ValidationEventImpl;
import javax.xml.bind.helpers.ValidationEventLocatorImpl;

import com.sun.xml.bind.ProxyGroup;
import com.sun.xml.bind.serializer.AbortSerializationException;
import com.sun.xml.bind.validator.Messages;

import org.xml.sax.SAXException;


/**
 * Maintains information that needs to be stored across
 * validations of multiple objects.
 *
 * Specifically, this object is responsible for:
 *
 * <ol>
 *   <li>detecting a cycle in a content tree by keeping track of
 *       objects that were validated.
 *
 *   <li>keeping an instance of NamespaceContextImpl, which is
 *       shared by all MSVValidators.
 *
 *   <li>keeping a reference to {@link ValidationErrorHandler}.
 *       MSVValidators should use this error handler to report any error.
 * </ol>
 */
class ValidationContext {
   /**
    * Documentaci�.
    */
   final DefaultJAXBContextImpl jaxbContext;

   /**
    * Documentaci�.
    */
   private final HashMap IDREFs = new HashMap();

   /**
    * Documentaci�.
    */
   private final HashSet IDs = new HashSet();

   //
   //
   // detecting cycles.
   //
   //

   /** Set of all validated objects. Used to detect a cycle. */
   private final IdentityHashSet validatedObjects = new IdentityHashSet();

   //
   //
   // Keeping track of namespace bindings.
   //
   //

   /** namespace context. */
   private final NamespaceContextImpl nsContext = new NamespaceContextImpl(null);

   //
   /**
    * Documentaci�.
    */
   private final ValidationEventHandler eventHandler;

   //
   //
   // ID/IDREF validation
   //
   //
   /** ID/IDREF validation is done only when this flag is true. */
   private final boolean validateID;

   /**
    * @param validateID
    *      if true, ID/IDREF validation will be performed.
    */
   ValidationContext(DefaultJAXBContextImpl _context,
      ValidationEventHandler _eventHandler, boolean validateID) {
      this.jaxbContext = _context;
      this.eventHandler = _eventHandler;
      this.validateID = validateID;
   }

   /**
    * Validates the sub-tree rooted at <code>vo</code> and reports
    * any errors/warnings to the error handler.
    */
   public void validate(ValidatableObject vo) throws SAXException {
      if (validatedObjects.add(ProxyGroup.unwrap(vo))) {
         // setup a new validator for this object and validate it.
         MSVValidator.validate(jaxbContext, this, vo);
      } else {
         // this object has already been validated once.
         reportEvent(vo, Messages.format(Messages.CYCLE_DETECTED));
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public NamespaceContextImpl getNamespaceContext() {
      return nsContext;
   }

   /**
    * Documentaci�.
    *
    * @param owner Documentaci�
    * @param value Documentaci�
    *
    * @return Documentaci�
    *
    * @throws SAXException Documentaci�
    */
   public String onID(XMLSerializable owner, String value)
      throws SAXException {
      if (!validateID) {
         return value;
      }

      if (!IDs.add(value)) {
         // this ID value has already been used.
         //reportEvent(Util.toValidatableObject(owner),
         //    Messages.format(Messages.DUPLICATE_ID,value));
         reportEvent(jaxbContext.getGrammarInfo().castToValidatableObject(owner),
            Messages.format(Messages.DUPLICATE_ID, value));
      }

      return value;
   }

   /**
    * Documentaci�.
    *
    * @param referer Documentaci�
    * @param value Documentaci�
    *
    * @return Documentaci�
    *
    * @throws SAXException Documentaci�
    */
   public String onIDREF(XMLSerializable referer, String value)
      throws SAXException {
      if (!validateID) {
         return value;
      }

      if (IDs.contains(value)) {
         return value; // this IDREF has the corresponding ID.
      }

      // remember the value to check the value later.
      IDREFs.put(value, referer);

      return value;
   }

   /** Tests if all IDREFs have corresponding IDs. */
   protected void reconcileIDs() throws SAXException {
      if (!validateID) {
         return;
      }

      for (Iterator itr = IDREFs.entrySet().iterator(); itr.hasNext();) {
         Map.Entry e = (Map.Entry) itr.next();

         if (IDs.contains(e.getKey())) {
            continue; // OK.
         }

         // ID was not found.
         ValidatableObject source = (ValidatableObject) e.getValue();
         reportEvent(source,
            new NotIdentifiableEventImpl(ValidationEvent.ERROR,
               Messages.format(Messages.ID_NOT_FOUND, e.getKey()),
               new ValidationEventLocatorImpl(source)));
      }

      IDREFs.clear();
   }

   /**
    * Reports an error to the application.
    */
   public void reportEvent(ValidatableObject source, String formattedMessage)
      throws AbortSerializationException {
      reportEvent(source,
         new ValidationEventImpl(ValidationEvent.ERROR, formattedMessage,
            new ValidationEventLocatorImpl(source)));
   }

   /**
    * Reports an error to the client.
    * This version should be used when an exception is thrown from sub-modules.
    */
   public void reportEvent(ValidatableObject source, Exception nestedException)
      throws AbortSerializationException {
      reportEvent(source,
         new ValidationEventImpl(ValidationEvent.ERROR,
            nestedException.toString(), new ValidationEventLocatorImpl(source),
            nestedException));
   }

   /**
    * Documentaci�.
    *
    * @param source Documentaci�
    * @param event Documentaci�
    *
    * @throws AbortSerializationException Documentaci�
    */
   public void reportEvent(ValidatableObject source, ValidationEvent event)
      throws AbortSerializationException {
      boolean r;

      try {
         r = eventHandler.handleEvent(event);
      } catch (RuntimeException re) {
         // if the client event handler causes a RuntimeException, then
         // we have to return false.
         r = false;
      }

      if (!r) {
         // throw an exception to abort validation
         throw new AbortSerializationException(event.getMessage());
      }
   }
}
