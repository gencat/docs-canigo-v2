/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsO.impl;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class DadesDocumentsOImpl extends net.gencat.gecat.batch.DocumentsO.impl.DadesDocumentsOTypeImpl
   implements net.gencat.gecat.batch.DocumentsO.DadesDocumentsO,
      com.sun.xml.bind.RIElement, com.sun.xml.bind.JAXBObject,
      net.gencat.gecat.batch.DocumentsO.impl.runtime.XMLSerializable,
      net.gencat.gecat.batch.DocumentsO.impl.runtime.ValidatableObject {
   /**
    * Documentaci�.
    */
   public static final java.lang.Class version = (net.gencat.gecat.batch.DocumentsO.impl.JAXBVersion.class);

   /**
    * Documentaci�.
    */
   private static com.sun.msv.grammar.Grammar schemaFragment;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private static final java.lang.Class PRIMARY_INTERFACE_CLASS() {
      return (net.gencat.gecat.batch.DocumentsO.DadesDocumentsO.class);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public java.lang.String ____jaxb_ri____getNamespaceURI() {
      return "";
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public java.lang.String ____jaxb_ri____getLocalName() {
      return "DadesDocumentsO";
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeBody(
      net.gencat.gecat.batch.DocumentsO.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
      context.startElement("", "DadesDocumentsO");
      super.serializeURIs(context);
      context.endNamespaceDecls();
      super.serializeAttributes(context);
      context.endAttributes();
      super.serializeBody(context);
      context.endElement();
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeAttributes(
      net.gencat.gecat.batch.DocumentsO.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeURIs(
      net.gencat.gecat.batch.DocumentsO.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public java.lang.Class getPrimaryInterface() {
      return (net.gencat.gecat.batch.DocumentsO.DadesDocumentsO.class);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
      if (schemaFragment == null) {
         schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\'com.sun.msv.grammar.trex.ElementPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000" +
               "\tnameClasst\u0000\u001fLcom/sun/msv/grammar/NameClass;xr\u0000\u001ecom.sun.msv." +
               "grammar.ElementExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aignoreUndeclaredAttributesL\u0000" +
               "\fcontentModelt\u0000 Lcom/sun/msv/grammar/Expression;xr\u0000\u001ecom.sun." +
               "msv.grammar.Expression\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Lj" +
               "ava/lang/Boolean;L\u0000\u000bexpandedExpq\u0000~\u0000\u0003xppp\u0000sr\u0000\u001fcom.sun.msv.gra" +
               "mmar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.sun.msv.grammar.BinaryExp" +
               "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1q\u0000~\u0000\u0003L\u0000\u0004exp2q\u0000~\u0000\u0003xq\u0000~\u0000\u0004ppsq\u0000~\u0000\u0000pp\u0000sq\u0000~\u0000\u0007pp" +
               "sq\u0000~\u0000\u0000pp\u0000sr\u0000\u001dcom.sun.msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\bp" +
               "psr\u0000 com.sun.msv.grammar.OneOrMoreExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001ccom.sun." +
               "msv.grammar.UnaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0003expq\u0000~\u0000\u0003xq\u0000~\u0000\u0004sr\u0000\u0011java.lan" +
               "g.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000 com.sun.msv.grammar.Attr" +
               "ibuteExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0003L\u0000\tnameClassq\u0000~\u0000\u0001xq\u0000~\u0000\u0004q\u0000~\u0000\u0013ps" +
               "r\u00002com.sun.msv.grammar.Expression$AnyStringExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000" +
               "\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0004sq\u0000~\u0000\u0012\u0001q\u0000~\u0000\u0017sr\u0000 com.sun.msv.grammar.AnyNameClass\u0000\u0000" +
               "\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000c" +
               "om.sun.msv.grammar.Expression$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq" +
               "\u0000~\u0000\u0004q\u0000~\u0000\u0018q\u0000~\u0000\u001dsr\u0000#com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000" +
               "\u0001\u0002\u0000\u0002L\u0000\tlocalNamet\u0000\u0012Ljava/lang/String;L\u0000\fnamespaceURIq\u0000~\u0000\u001fxq\u0000" +
               "~\u0000\u001at\u00003net.gencat.gecat.batch.DocumentsO.DadesGeneralsTypet\u0000+" +
               "http://java.sun.com/jaxb/xjc/dummy-elementssq\u0000~\u0000\rppsq\u0000~\u0000\u0014q\u0000~" +
               "\u0000\u0013psr\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/re" +
               "laxng/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0003L\u0000\u0004namet\u0000\u001dLcom/sun/msv" +
               "/util/StringPair;xq\u0000~\u0000\u0004ppsr\u0000\"com.sun.msv.datatype.xsd.QnameT" +
               "ype\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.xsd.BuiltinAtomicType" +
               "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datatype.xsd.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
               "\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype.xsd.XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\f" +
               "namespaceUriq\u0000~\u0000\u001fL\u0000\btypeNameq\u0000~\u0000\u001fL\u0000\nwhiteSpacet\u0000.Lcom/sun/ms" +
               "v/datatype/xsd/WhiteSpaceProcessor;xpt\u0000 http://www.w3.org/20" +
               "01/XMLSchemat\u0000\u0005QNamesr\u00005com.sun.msv.datatype.xsd.WhiteSpaceP" +
               "rocessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datatype.xsd.Whi" +
               "teSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000com.sun.msv.grammar.Express" +
               "ion$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0004ppsr\u0000\u001bcom.sun.msv.util" +
               ".StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000\u001fL\u0000\fnamespaceURIq\u0000~\u0000\u001fx" +
               "pq\u0000~\u00000q\u0000~\u0000/sq\u0000~\u0000\u001et\u0000\u0004typet\u0000)http://www.w3.org/2001/XMLSchema-" +
               "instanceq\u0000~\u0000\u001dsq\u0000~\u0000\u001et\u0000\rDadesGeneralst\u0000\u0000sq\u0000~\u0000\rppsq\u0000~\u0000\u0014q\u0000~\u0000\u0013pq\u0000" +
               "~\u0000(q\u0000~\u00008q\u0000~\u0000\u001dsq\u0000~\u0000\u001et\u0000\u000fDadesDocumentsOq\u0000~\u0000=sr\u0000\"com.sun.msv.gr" +
               "ammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/sun/msv/gr" +
               "ammar/ExpressionPool$ClosedHash;xpsr\u0000-com.sun.msv.grammar.Ex" +
               "pressionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamVersionL\u0000" +
               "\u0006parentt\u0000$Lcom/sun/msv/grammar/ExpressionPool;xp\u0000\u0000\u0000\u0006\u0001pq\u0000~\u0000\u0011q" +
               "\u0000~\u0000\tq\u0000~\u0000\u000bq\u0000~\u0000\u000eq\u0000~\u0000#q\u0000~\u0000>x"));
      }

      return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
   }
}
