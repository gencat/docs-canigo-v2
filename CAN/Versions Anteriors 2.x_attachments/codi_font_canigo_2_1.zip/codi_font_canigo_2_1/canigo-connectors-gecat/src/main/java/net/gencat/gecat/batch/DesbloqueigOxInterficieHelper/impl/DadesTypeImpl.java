/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class DadesTypeImpl implements net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType,
   com.sun.xml.bind.JAXBObject,
   net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.XMLSerializable,
   net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.ValidatableObject {
   /**
    * Documentaci�.
    */
   public static final java.lang.Class version = (net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.JAXBVersion.class);

   /**
    * Documentaci�.
    */
   private static com.sun.msv.grammar.Grammar schemaFragment;

   /**
    * Documentaci�.
    */
   protected boolean has_LiniaDocumentLength;

   /**
    * Documentaci�.
    */
   protected boolean has_LiniaDocumentOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_NDocumentLength;

   /**
    * Documentaci�.
    */
   protected boolean has_NDocumentOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_Order;

   /**
    * Documentaci�.
    */
   protected boolean has_SocietatLength;

   /**
    * Documentaci�.
    */
   protected boolean has_SocietatOrder;

   /**
    * Documentaci�.
    */
   protected boolean has_TransaccioLength;

   /**
    * Documentaci�.
    */
   protected boolean has_TransaccioOrder;

   /**
    * Documentaci�.
    */
   protected int _LiniaDocumentLength;

   /**
    * Documentaci�.
    */
   protected int _LiniaDocumentOrder;

   /**
    * Documentaci�.
    */
   protected int _NDocumentLength;

   /**
    * Documentaci�.
    */
   protected int _NDocumentOrder;

   /**
    * Documentaci�.
    */
   protected int _Order;

   /**
    * Documentaci�.
    */
   protected int _SocietatLength;

   /**
    * Documentaci�.
    */
   protected int _SocietatOrder;

   /**
    * Documentaci�.
    */
   protected int _TransaccioLength;

   /**
    * Documentaci�.
    */
   protected int _TransaccioOrder;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private static final java.lang.Class PRIMARY_INTERFACE_CLASS() {
      return (net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType.class);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getLiniaDocumentLength() {
      if (!has_LiniaDocumentLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "3"));
      } else {
         return _LiniaDocumentLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setLiniaDocumentLength(int value) {
      _LiniaDocumentLength = value;
      has_LiniaDocumentLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getNDocumentLength() {
      if (!has_NDocumentLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "10"));
      } else {
         return _NDocumentLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setNDocumentLength(int value) {
      _NDocumentLength = value;
      has_NDocumentLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getOrder() {
      if (!has_Order) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "1"));
      } else {
         return _Order;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setOrder(int value) {
      _Order = value;
      has_Order = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getTransaccioOrder() {
      if (!has_TransaccioOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "2"));
      } else {
         return _TransaccioOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setTransaccioOrder(int value) {
      _TransaccioOrder = value;
      has_TransaccioOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getTransaccioLength() {
      if (!has_TransaccioLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "20"));
      } else {
         return _TransaccioLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setTransaccioLength(int value) {
      _TransaccioLength = value;
      has_TransaccioLength = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getLiniaDocumentOrder() {
      if (!has_LiniaDocumentOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "4"));
      } else {
         return _LiniaDocumentOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setLiniaDocumentOrder(int value) {
      _LiniaDocumentOrder = value;
      has_LiniaDocumentOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getNDocumentOrder() {
      if (!has_NDocumentOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "3"));
      } else {
         return _NDocumentOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setNDocumentOrder(int value) {
      _NDocumentOrder = value;
      has_NDocumentOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getSocietatOrder() {
      if (!has_SocietatOrder) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "1"));
      } else {
         return _SocietatOrder;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setSocietatOrder(int value) {
      _SocietatOrder = value;
      has_SocietatOrder = true;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getSocietatLength() {
      if (!has_SocietatLength) {
         return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
               "4"));
      } else {
         return _SocietatLength;
      }
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setSocietatLength(int value) {
      _SocietatLength = value;
      has_SocietatLength = true;
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeBody(
      net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeAttributes(
      net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
      if (has_LiniaDocumentLength) {
         context.startAttribute("", "LiniaDocumentLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _LiniaDocumentLength)), "LiniaDocumentLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_LiniaDocumentOrder) {
         context.startAttribute("", "LiniaDocumentOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _LiniaDocumentOrder)), "LiniaDocumentOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_NDocumentLength) {
         context.startAttribute("", "NDocumentLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _NDocumentLength)), "NDocumentLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_NDocumentOrder) {
         context.startAttribute("", "NDocumentOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _NDocumentOrder)), "NDocumentOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_SocietatLength) {
         context.startAttribute("", "SocietatLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _SocietatLength)), "SocietatLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_SocietatOrder) {
         context.startAttribute("", "SocietatOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _SocietatOrder)), "SocietatOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_TransaccioLength) {
         context.startAttribute("", "TransaccioLength");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _TransaccioLength)), "TransaccioLength");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_TransaccioOrder) {
         context.startAttribute("", "TransaccioOrder");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _TransaccioOrder)), "TransaccioOrder");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }

      if (has_Order) {
         context.startAttribute("", "order");

         try {
            context.text(javax.xml.bind.DatatypeConverter.printInt(
                  ((int) _Order)), "Order");
         } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.Util.handlePrintConversionException(this,
               e, context);
         }

         context.endAttribute();
      }
   }

   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    */
   public void serializeURIs(
      net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.runtime.XMLSerializer context)
      throws org.xml.sax.SAXException {
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public java.lang.Class getPrimaryInterface() {
      return (net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType.class);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
      if (schemaFragment == null) {
         schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
               "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
               "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
               "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
               "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
               "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsr\u0000\u001dcom.sun.msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000" +
               "xq\u0000~\u0000\u0001ppsr\u0000 com.sun.msv.grammar.AttributeExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003ex" +
               "pq\u0000~\u0000\u0002L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/NameClass;xq\u0000~\u0000\u0003sr" +
               "\u0000\u0011java.lang.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000\u001bcom.sun.msv.gr" +
               "ammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatype/Dataty" +
               "pe;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util/StringPair;xq\u0000~" +
               "\u0000\u0003ppsr\u0000 com.sun.msv.datatype.xsd.IntType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000+com.s" +
               "un.msv.datatype.xsd.IntegerDerivedType\u0099\u00f1]\u0090&6k\u00be\u0002\u0000\u0001L\u0000\nbaseFace" +
               "tst\u0000)Lcom/sun/msv/datatype/xsd/XSDatatypeImpl;xr\u0000*com.sun.ms" +
               "v.datatype.xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.d" +
               "atatype.xsd.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype." +
               "xsd.XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUrit\u0000\u0012Ljava/lang/St" +
               "ring;L\u0000\btypeNameq\u0000~\u0000\u001eL\u0000\nwhiteSpacet\u0000.Lcom/sun/msv/datatype/x" +
               "sd/WhiteSpaceProcessor;xpt\u0000 http://www.w3.org/2001/XMLSchema" +
               "t\u0000\u0003intsr\u00005com.sun.msv.datatype.xsd.WhiteSpaceProcessor$Colla" +
               "pse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datatype.xsd.WhiteSpaceProcess" +
               "or\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u0000*com.sun.msv.datatype.xsd.MaxInclusiveFace" +
               "t\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.datatype.xsd.RangeFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002" +
               "\u0000\u0001L\u0000\nlimitValuet\u0000\u0012Ljava/lang/Object;xr\u00009com.sun.msv.datatype" +
               ".xsd.DataTypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*com.sun." +
               "msv.datatype.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFacetFixed" +
               "Z\u0000\u0012needValueCheckFlagL\u0000\bbaseTypeq\u0000~\u0000\u001aL\u0000\fconcreteTypet\u0000\'Lcom/" +
               "sun/msv/datatype/xsd/ConcreteType;L\u0000\tfacetNameq\u0000~\u0000\u001exq\u0000~\u0000\u001dppq" +
               "\u0000~\u0000%\u0000\u0001sr\u0000*com.sun.msv.datatype.xsd.MinInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
               "\u0002\u0000\u0000xq\u0000~\u0000\'ppq\u0000~\u0000%\u0000\u0000sr\u0000!com.sun.msv.datatype.xsd.LongType\u0000\u0000\u0000\u0000\u0000" +
               "\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0019q\u0000~\u0000!t\u0000\u0004longq\u0000~\u0000%sq\u0000~\u0000&ppq\u0000~\u0000%\u0000\u0001sq\u0000~\u0000-ppq\u0000~\u0000%\u0000\u0000s" +
               "r\u0000$com.sun.msv.datatype.xsd.IntegerType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0019q\u0000~\u0000" +
               "!t\u0000\u0007integerq\u0000~\u0000%sr\u0000,com.sun.msv.datatype.xsd.FractionDigitsF" +
               "acet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scalexr\u0000;com.sun.msv.datatype.xsd.DataType" +
               "WithLexicalConstraintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000*ppq\u0000~\u0000%\u0001\u0000sr\u0000#com." +
               "sun.msv.datatype.xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u001bq\u0000~\u0000!t\u0000\u0007deci" +
               "malq\u0000~\u0000%q\u0000~\u0000;t\u0000\u000efractionDigits\u0000\u0000\u0000\u0000q\u0000~\u00005t\u0000\fminInclusivesr\u0000\u000eja" +
               "va.lang.Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010java.lang.Number\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002" +
               "\u0000\u0000xp\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u00005t\u0000\fmaxInclusivesq\u0000~\u0000?\u007f\u00ff\u00ff\u00ff\u00ff\u00ff\u00ff\u00ffq\u0000~\u00000q\u0000~\u0000>sr\u0000\u0011" +
               "java.lang.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000@\u0080\u0000\u0000\u0000q\u0000~\u00000q\u0000~\u0000Bsq\u0000~" +
               "\u0000D\u007f\u00ff\u00ff\u00ffsr\u00000com.sun.msv.grammar.Expression$NullSetExpression\u0000\u0000" +
               "\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L" +
               "\u0000\tlocalNameq\u0000~\u0000\u001eL\u0000\fnamespaceURIq\u0000~\u0000\u001expq\u0000~\u0000\"q\u0000~\u0000!sr\u0000#com.sun." +
               "msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000\u001eL\u0000\fna" +
               "mespaceURIq\u0000~\u0000\u001exr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000x" +
               "pt\u0000\u0013LiniaDocumentLengtht\u0000\u0000sr\u00000com.sun.msv.grammar.Expression" +
               "$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\u0012\u0001q\u0000~\u0000Qsq\u0000~\u0000\rppsq\u0000~\u0000" +
               "\u000fq\u0000~\u0000\u0013pq\u0000~\u0000\u0017sq\u0000~\u0000Kt\u0000\u0012LiniaDocumentOrderq\u0000~\u0000Oq\u0000~\u0000Qsq\u0000~\u0000\rppsq\u0000" +
               "~\u0000\u000fq\u0000~\u0000\u0013pq\u0000~\u0000\u0017sq\u0000~\u0000Kt\u0000\u000fNDocumentLengthq\u0000~\u0000Oq\u0000~\u0000Qsq\u0000~\u0000\rppsq\u0000~" +
               "\u0000\u000fq\u0000~\u0000\u0013pq\u0000~\u0000\u0017sq\u0000~\u0000Kt\u0000\u000eNDocumentOrderq\u0000~\u0000Oq\u0000~\u0000Qsq\u0000~\u0000\rppsq\u0000~\u0000\u000f" +
               "q\u0000~\u0000\u0013pq\u0000~\u0000\u0017sq\u0000~\u0000Kt\u0000\u000eSocietatLengthq\u0000~\u0000Oq\u0000~\u0000Qsq\u0000~\u0000\rppsq\u0000~\u0000\u000fq\u0000" +
               "~\u0000\u0013pq\u0000~\u0000\u0017sq\u0000~\u0000Kt\u0000\rSocietatOrderq\u0000~\u0000Oq\u0000~\u0000Qsq\u0000~\u0000\rppsq\u0000~\u0000\u000fq\u0000~\u0000\u0013" +
               "pq\u0000~\u0000\u0017sq\u0000~\u0000Kt\u0000\u0010TransaccioLengthq\u0000~\u0000Oq\u0000~\u0000Qsq\u0000~\u0000\rppsq\u0000~\u0000\u000fq\u0000~\u0000\u0013" +
               "pq\u0000~\u0000\u0017sq\u0000~\u0000Kt\u0000\u000fTransaccioOrderq\u0000~\u0000Oq\u0000~\u0000Qsq\u0000~\u0000\rppsq\u0000~\u0000\u000fq\u0000~\u0000\u0013p" +
               "q\u0000~\u0000\u0017sq\u0000~\u0000Kt\u0000\u0005orderq\u0000~\u0000Oq\u0000~\u0000Qsr\u0000\"com.sun.msv.grammar.Express" +
               "ionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/sun/msv/grammar/Express" +
               "ionPool$ClosedHash;xpsr\u0000-com.sun.msv.grammar.ExpressionPool$" +
               "ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamVersionL\u0000\u0006parentt\u0000$Lco" +
               "m/sun/msv/grammar/ExpressionPool;xp\u0000\u0000\u0000\u0011\u0001pq\u0000~\u0000\u0007q\u0000~\u0000Sq\u0000~\u0000\tq\u0000~\u0000" +
               "\nq\u0000~\u0000oq\u0000~\u0000_q\u0000~\u0000\fq\u0000~\u0000\u000bq\u0000~\u0000\u000eq\u0000~\u0000\u0006q\u0000~\u0000\bq\u0000~\u0000[q\u0000~\u0000cq\u0000~\u0000Wq\u0000~\u0000kq\u0000~\u0000" +
               "\u0005q\u0000~\u0000gx"));
      }

      return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
   }
}
