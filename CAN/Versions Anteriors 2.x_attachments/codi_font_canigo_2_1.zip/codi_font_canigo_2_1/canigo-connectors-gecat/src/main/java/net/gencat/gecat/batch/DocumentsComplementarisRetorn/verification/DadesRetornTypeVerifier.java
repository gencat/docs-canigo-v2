/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsComplementarisRetorn.verification;

/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class DadesRetornTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    */
   public void check(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType master) {
      if (true) {
         // If left exists
         // No check for primitive values
         checkOrder(parentLocator, handler, master,
            new java.lang.Integer(master.getOrder()));
      }

      if (null == master.getDadaRetorn()) {
         // Report missing object
         handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
               new de.fzi.dbs.verification.event.VerificationEventLocator(
                  parentLocator, master, "DadaRetorn"),
               new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
      } else {
         // Check count
         if (master.getDadaRetorn().size() < 1) {
            // Report minimum of occurences violated
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "DadaRetorn"),
                  new de.fzi.dbs.verification.event.structure.TooFewElementsProblem(
                     master.getDadaRetorn().size(), 1)));
         }

         // Check value
         checkDadaRetorn(parentLocator, handler, master, master.getDadaRetorn());
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param values Documentaci�
    */
   public void checkDadaRetorn(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType master,
      java.util.List values) {
      for (int index = 0; (index < values.size()); index++) {
         java.lang.Object item = values.get(index);
         checkDadaRetorn(parentLocator, handler, master, index, item);
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param index Documentaci�
    * @param value Documentaci�
    */
   public void checkDadaRetorn(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType master,
      int index, java.lang.Object value) {
      if (value instanceof net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType) {
         net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType realValue =
            ((net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType) value);

         {
            // Check complex value
            net.gencat.gecat.batch.DocumentsComplementarisRetorn.verification.DadesRetornTypeVerifier.DadaRetornTypeVerifier verifier =
               new net.gencat.gecat.batch.DocumentsComplementarisRetorn.verification.DadesRetornTypeVerifier.DadaRetornTypeVerifier();
            verifier.check(new de.fzi.dbs.verification.event.EntryLocator(
                  parentLocator, master, "DadaRetorn", index), handler,
               realValue);
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.EntryLocator(
                     parentLocator, master, "DadaRetorn", index),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param master Documentaci�
    * @param value Documentaci�
    */
   public void checkOrder(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler,
      net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType master,
      java.lang.Integer value) {
      if (value instanceof java.lang.Integer) {
         java.lang.Integer realValue = ((java.lang.Integer) value);
         // Check primitive value
         {
            // Perform the check
            // Checking class com.sun.msv.datatype.xsd.IntType datatype
            de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

            if (null != problem) {
               // Handle event
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Order"), problem));
            }
         }
      } else {
         if (null == value) {
            // todo: report null
         } else {
            // Report wrong class
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Order"),
                  new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                     value.getClass())));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param parentLocator Documentaci�
    * @param handler Documentaci�
    * @param object Documentaci�
    */
   public void check(
      de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
      javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
      check(parentLocator, handler,
         ((net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType) object));
   }

   /**
    * Documentaci�.
    *
    * @param handler Documentaci�
    * @param object Documentaci�
    */
   public void check(javax.xml.bind.ValidationEventHandler handler,
      java.lang.Object object) {
      check(null, handler,
         ((net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType) object));
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   public static class DadaRetornTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
      /**
       * Documentaci�.
       */
      protected java.lang.Object[] values = new java.lang.Object[] { "S", "N" };

      /**
       * Documentaci�.
       */
      protected java.util.Set valueSet = java.util.Collections.unmodifiableSet(new java.util.HashSet(
               java.util.Arrays.asList(values)));

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       */
      public void check(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType master) {
         if (true) {
            // If left exists
            // No check for primitive values
            checkOrder(parentLocator, handler, master,
               new java.lang.Integer(master.getOrder()));
         }

         if (null == master.getSocietatFi()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "SocietatFi"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkSocietatFi(parentLocator, handler, master,
               master.getSocietatFi());
         }

         if (null == master.getExercici()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "Exercici"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkExercici(parentLocator, handler, master, master.getExercici());
         }

         if (null == master.getClasseDocument()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "ClasseDocument"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkClasseDocument(parentLocator, handler, master,
               master.getClasseDocument());
         }

         if (null == master.getNDocument()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "NDocument"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkNDocument(parentLocator, handler, master, master.getNDocument());
         }

         if (null == master.getPosicioDocument()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "PosicioDocument"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkPosicioDocument(parentLocator, handler, master,
               master.getPosicioDocument());
         }

         if (null == master.getStatusDocument()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "StatusDocument"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkStatusDocument(parentLocator, handler, master,
               master.getStatusDocument());
         }

         if (null == master.getCodiPosicioError()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "CodiPosicioError"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkCodiPosicioError(parentLocator, handler, master,
               master.getCodiPosicioError());
         }

         if (null == master.getTextError()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "TextError"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkTextError(parentLocator, handler, master, master.getTextError());
         }

         if (null == master.getPosicioModificacio()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                  new de.fzi.dbs.verification.event.VerificationEventLocator(
                     parentLocator, master, "PosicioModificacio"),
                  new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
         } else {
            // Check value
            checkPosicioModificacio(parentLocator, handler, master,
               master.getPosicioModificacio());
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkClasseDocument(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 2) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 2);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "ClasseDocument"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "ClasseDocument"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkStatusDocument(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.EnumerationFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (valueSet.contains(realValue)) {
                  // Value is found in the enumeration, it is valid
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.EnumerationProblem(realValue,
                        valueSet);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "StatusDocument"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "StatusDocument"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkNDocument(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 10) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 10);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "NDocument"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "NDocument"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkSocietatFi(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 4) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 4);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "SocietatFi"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "SocietatFi"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkOrder(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType master,
         java.lang.Integer value) {
         if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.IntType datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "Order"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Order"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkExercici(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 4) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 4);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "Exercici"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Exercici"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkPosicioModificacio(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 3) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 3);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "PosicioModificacio"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "PosicioModificacio"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkTextError(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 100) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 100);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "TextError"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "TextError"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkPosicioDocument(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 3) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 3);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "PosicioDocument"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "PosicioDocument"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param master Documentaci�
       * @param value Documentaci�
       */
      public void checkCodiPosicioError(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler,
         net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType master,
         java.lang.String value) {
         if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
               // Perform the check
               // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
               de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

               if (((null == realValue) ? 0 : realValue.length()) <= 10) {
                  // Value length is correct
               } else {
                  problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                        ((null == realValue) ? 0 : realValue.length()), 10);
               }

               if (null != problem) {
                  // Handle event
                  handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                           parentLocator, master, "CodiPosicioError"), problem));
               }
            }
         } else {
            if (null == value) {
               // todo: report null
            } else {
               // Report wrong class
               handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                     new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "CodiPosicioError"),
                     new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                        value.getClass())));
            }
         }
      }

      /**
       * Documentaci�.
       *
       * @param parentLocator Documentaci�
       * @param handler Documentaci�
       * @param object Documentaci�
       */
      public void check(
         de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
         javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
         check(parentLocator, handler,
            ((net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType) object));
      }

      /**
       * Documentaci�.
       *
       * @param handler Documentaci�
       * @param object Documentaci�
       */
      public void check(javax.xml.bind.ValidationEventHandler handler,
         java.lang.Object object) {
         check(null, handler,
            ((net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType) object));
      }
   }
}
