/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.catcert.www.ValidateWS_wsdl;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class ValidateWSLocator extends org.apache.axis.client.Service
   implements net.catcert.www.ValidateWS_wsdl.ValidateWS {
   // The WSDD service name defaults to the port name.
   /**
    * Documentaci�.
    */
   private java.lang.String ValidateWSPortWSDDServiceName = "ValidateWSPort";

   // Use to get a proxy class for ValidateWSPort
   /**
    * Documentaci�.
    */
   private java.lang.String ValidateWSPort_address = "http://www10.gencat.net/pki/AppJava/ValidateWS";

   /**
    * Documentaci�.
    */
   private java.util.HashSet ports = null;

   /**
    * Creates a new ValidateWSLocator object.
    */
   public ValidateWSLocator() {
   }

   /**
    * Creates a new ValidateWSLocator object.
    *
    * @param config DOCUMENT ME.
    */
   public ValidateWSLocator(org.apache.axis.EngineConfiguration config) {
      super(config);
   }

   /**
    * Creates a new ValidateWSLocator object.
    *
    * @param wsdlLoc DOCUMENT ME.
    * @param sName DOCUMENT ME.
    *
    */
   public ValidateWSLocator(java.lang.String wsdlLoc,
      javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
      super(wsdlLoc, sName);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public java.lang.String getValidateWSPortAddress() {
      return ValidateWSPort_address;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public java.lang.String getValidateWSPortWSDDServiceName() {
      return ValidateWSPortWSDDServiceName;
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    */
   public void setValidateWSPortWSDDServiceName(java.lang.String name) {
      ValidateWSPortWSDDServiceName = name;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws . Documentaci�
    */
   public net.catcert.www.ValidateWS_wsdl.ValidateWSPortType getValidateWSPort()
      throws javax.xml.rpc.ServiceException {
      java.net.URL endpoint;

      try {
         endpoint = new java.net.URL(ValidateWSPort_address);
      } catch (java.net.MalformedURLException e) {
         throw new javax.xml.rpc.ServiceException(e);
      }

      return getValidateWSPort(endpoint);
   }

   /**
    * Documentaci�.
    *
    * @param portAddress Documentaci�
    *
    * @return Documentaci�
    *
    */
   public net.catcert.www.ValidateWS_wsdl.ValidateWSPortType getValidateWSPort(
      java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
      try {
         net.catcert.www.ValidateWS_wsdl.ValidateWSBindingStub _stub = new net.catcert.www.ValidateWS_wsdl.ValidateWSBindingStub(portAddress,
               this);
         _stub.setPortName(getValidateWSPortWSDDServiceName());

         return _stub;
      } catch (org.apache.axis.AxisFault e) {
         return null;
      }
   }

   /**
    * Documentaci�.
    *
    * @param address Documentaci�
    */
   public void setValidateWSPortEndpointAddress(java.lang.String address) {
      ValidateWSPort_address = address;
   }

   /**
    * For the given interface, get the stub implementation.
    * If this service has no port for the given interface,
    * then ServiceException is thrown.
    */
   public java.rmi.Remote getPort(Class serviceEndpointInterface)
      throws javax.xml.rpc.ServiceException {
      try {
         if (net.catcert.www.ValidateWS_wsdl.ValidateWSPortType.class.isAssignableFrom(
                  serviceEndpointInterface)) {
            net.catcert.www.ValidateWS_wsdl.ValidateWSBindingStub _stub = new net.catcert.www.ValidateWS_wsdl.ValidateWSBindingStub(new java.net.URL(
                     ValidateWSPort_address), this);
            _stub.setPortName(getValidateWSPortWSDDServiceName());

            return _stub;
         }
      } catch (java.lang.Throwable t) {
         throw new javax.xml.rpc.ServiceException(t);
      }

      throw new javax.xml.rpc.ServiceException(
         "There is no stub implementation for the interface:  " +
         ((serviceEndpointInterface == null) ? "null"
                                             : serviceEndpointInterface.getName()));
   }

   /**
    * For the given interface, get the stub implementation.
    * If this service has no port for the given interface,
    * then ServiceException is thrown.
    */
   public java.rmi.Remote getPort(javax.xml.namespace.QName portName,
      Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
      if (portName == null) {
         return getPort(serviceEndpointInterface);
      }

      java.lang.String inputPortName = portName.getLocalPart();

      if ("ValidateWSPort".equals(inputPortName)) {
         return getValidateWSPort();
      } else {
         java.rmi.Remote _stub = getPort(serviceEndpointInterface);
         ((org.apache.axis.client.Stub) _stub).setPortName(portName);

         return _stub;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public javax.xml.namespace.QName getServiceName() {
      return new javax.xml.namespace.QName("http://www.catcert.net/ValidateWS.wsdl",
         "ValidateWS");
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public java.util.Iterator getPorts() {
      if (ports == null) {
         ports = new java.util.HashSet();
         ports.add(new javax.xml.namespace.QName(
               "http://www.catcert.net/ValidateWS.wsdl", "ValidateWSPort"));
      }

      return ports.iterator();
   }

   /**
   * Set the endpoint address for the specified port name.
   */
   public void setEndpointAddress(java.lang.String portName,
      java.lang.String address) throws javax.xml.rpc.ServiceException {
      if ("ValidateWSPort".equals(portName)) {
         setValidateWSPortEndpointAddress(address);
      } else { // Unknown Port Name
         throw new javax.xml.rpc.ServiceException(
            " Cannot set Endpoint Address for Unknown Port" + portName);
      }
   }

   /**
   * Set the endpoint address for the specified port name.
   */
   public void setEndpointAddress(javax.xml.namespace.QName portName,
      java.lang.String address) throws javax.xml.rpc.ServiceException {
      setEndpointAddress(portName.getLocalPart(), address);
   }
}
