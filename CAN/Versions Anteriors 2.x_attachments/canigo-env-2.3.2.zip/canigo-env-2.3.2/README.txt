Aquesta plantilla cont� un petit manteniment i un exemple de com fer un llistat
dels logs a trav�s de XML.

Per usar la plantilla nom�s cal utilitzar l'eina d'importaci� d'eclipse.

Tanmateix aquesta plantilla tamb� t� els scripts, les imatges i els css.


==========
= DEPLOY =
==========

Per tal de desplegar l'aplicaci� canigo-env en eclipse 3.2 s'ha creat un altre projecte
canigo-env-deploy amb l'estructura de projecte que crea el plugin Web Standard Tools (wst)
per aquesta versi� d'eclipse. Aquest projecte obt� els recursos del projecte canigo-env
i els organitza segons l'estructura que necessita el plugin wst a eclipse 3.2.


===================
= Starting TOMCAT =
===================

(1) Para iniciar la aplicaci�n desde eclipse con tomcat, hay que a�adir al contexto 
  (poner dentro del tag <Context/> del 'server.xml') el siguiente datasource:


<Resource name="formacioDS" auth="Container" type="javax.sql.DataSource"/> 		
			<ResourceParams name="formacioDS">
			<parameter>
							<name>driverClassName</name>
							<value>
								oracle.jdbc.driver.OracleDriver
							</value>
						</parameter>
						<parameter>
							<name>url</name>
							<value>
								jdbc:oracle:thin:@bna-s007.es.int.atosorigin.com:1521:Legolas
							</value>
						</parameter>
						<parameter>
							<name>username</name>
							<value>openframe</value>
						</parameter>
						<parameter>
							<name>password</name>
							<value>openframe</value>
						</parameter>
						<parameter>
							<name>maxActive</name>
							<value>20</value>
						</parameter>
						<parameter>
							<name>maxIdle</name>
							<value>10</value>
						</parameter>
						<parameter>
							<name>maxWait</name>
							<value>-1</value>
						</parameter>
			</ResourceParams>
			
Para Tomcat 5.5 usar este otro
	

<Resource name="formacioDS" auth="Container"
              type="javax.sql.DataSource" driverClassName="oracle.jdbc.OracleDriver"
              url="jdbc:oracle:thin:@ravel:1521:ravel"
              username="canigo" password="canigo" maxActive="20" maxIdle="10"
              maxWait="-1"/> 


(2) Poner el jar con los drivers de oracle en 
		$CATALINA_HOME$/common/lib

(3) Republicar el contexto desde el eclipse (importante)
