/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.bo.admin.impl;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import net.gencat.ctti.canigo.services.exceptions.BusinessException;
import net.gencat.ctti.canigo.services.persistence.UniversalHibernateDAO;
import net.gencat.ctti.canigo.services.security.bo.admin.AdminBO;
import net.gencat.ctti.canigo.services.security.exceptions.InvalidUsernameException;
import net.gencat.ctti.canigo.services.security.model.PartyGroup;
import net.gencat.ctti.canigo.services.security.model.Role;
import net.gencat.ctti.canigo.services.security.model.UserLogin;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;


// TODO Refactor: Extract dupplicate code to methods (DRY)
/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class AdminBOImpl implements AdminBO, InitializingBean {
   /**
    * Documentaci�.
    */
   private UniversalHibernateDAO securityServiceDAO = null;

   /**
    * Creates a new AdminBOImpl object.
    */
   public AdminBOImpl() {
      super();
   }

   /**
    * Documentaci�.
    *
    * @param userLogin Documentaci�
    *
    * @throws Exception Documentaci�
    * @throws InvalidUsernameException Documentaci�
    */
   public void save(UserLogin userLogin) throws Exception {
      UserLogin existingUser = (UserLogin) this.securityServiceDAO.get(UserLogin.class,
            userLogin.getUserName());

      if (existingUser != null) {
         throw new InvalidUsernameException("business_error.existing_user",
            new Object[] { existingUser.getUserName() });
      }

      if (userLogin.getGroup().getId() == null) {
         userLogin.setGroup(null);
      } else {
         this.securityServiceDAO.refresh(userLogin.getGroup());
      }

      if ((userLogin.getRoles() != null) && !userLogin.getRoles().isEmpty()) {
         Iterator it = userLogin.getRoles().iterator();

         while (it.hasNext()) {
            Role r = (Role) it.next();
            this.securityServiceDAO.refresh(r);
         }
      }

      this.securityServiceDAO.save(userLogin);
   }

   /**
    * Documentaci�.
    *
    * @param userLogin Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void delete(UserLogin userLogin) throws Exception {
      this.securityServiceDAO.refresh(userLogin);
      this.securityServiceDAO.delete(userLogin);
   }

   /**
    * @return Returns the dao.
    */
   public UniversalHibernateDAO getSecurityServiceDAO() {
      return securityServiceDAO;
   }

   /**
    * @param dao The dao to set.
    */
   public void setSecurityServiceDAO(UniversalHibernateDAO dao) {
      this.securityServiceDAO = dao;
   }

   /**
    * Documentaci�.
    *
    * @param userLogin Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void saveOrUpdate(UserLogin userLogin) throws Exception {
      if (userLogin.getGroup().getId() == null) {
         userLogin.setGroup(null);
      } else {
         this.securityServiceDAO.refresh(userLogin.getGroup());
      }

      if ((userLogin.getRoles() != null) && !userLogin.getRoles().isEmpty()) {
         Iterator it = userLogin.getRoles().iterator();

         while (it.hasNext()) {
            Role r = (Role) it.next();
            this.securityServiceDAO.refresh(r);
         }
      }

      this.securityServiceDAO.saveOrUpdate(userLogin);
   }

   /**
    * Documentaci�.
    *
    * @param userLogin Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void refresh(UserLogin userLogin) throws Exception {
      this.securityServiceDAO.refresh(userLogin);
   }

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void save(Role role) throws Exception {
      // TODO check ifExists object with same name

      // TODO This SUCKS!!!!!!
      if (role.getParent() != null) {
         if (role.getParent().getId() == null) {
            role.setParent(null);
         } else {
            Role assignedParent = role.getParent();
            this.securityServiceDAO.refresh(assignedParent);
         }
      }

      this.securityServiceDAO.save(role);
   }

   /**
    * Documentaci�.
    *
    * @param group Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void save(PartyGroup group) throws Exception {
      // TODO check repeated groups        
      //        if (condition) {
      //            
      //        }
      if (group.getParent() != null) {
         if (group.getParent().getId() == null) {
            group.setParent(null);
         } else {
            this.securityServiceDAO.refresh(group.getParent());
         }
      }

      this.securityServiceDAO.save(group);
   }

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void refresh(Role role) throws Exception {
      this.securityServiceDAO.refresh(role);
   }

   /**
    * Documentaci�.
    *
    * @param group Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void refresh(PartyGroup group) throws Exception {
      this.securityServiceDAO.refresh(group);
   }

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    *
    * @throws Exception Documentaci�
    * @throws BusinessException Documentaci�
    */
   public void saveOrUpdate(Role role) throws Exception {
      if (role.getParent().getId() == null) {
         role.setParent(null);
      } else {
         Role assignedParent = role.getParent();
         this.securityServiceDAO.refresh(assignedParent);

         role.setParent(null);

         // Can't assigned a parent who is my son or my grand-son  
         if (role.isAParentOf(assignedParent)) {
            throw new BusinessException("business_error.role_hierachy");
         }

         role.setParent(assignedParent);
      }

      this.securityServiceDAO.saveOrUpdate(role);
   }

   /**
    * Documentaci�.
    *
    * @param group Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void saveOrUpdate(PartyGroup group) throws Exception {
      if (group.getParent() != null) {
         if (group.getParent().getId() == null) {
            group.setParent(null);
         } else {
            this.securityServiceDAO.refresh(group.getParent());
         }
      }

      if ((group.getRoles() != null) && !group.getRoles().isEmpty()) {
         Iterator it = group.getRoles().iterator();

         while (it.hasNext()) {
            Role r = (Role) it.next();
            this.securityServiceDAO.refresh(r);
         }
      }

      this.securityServiceDAO.saveOrUpdate(group);
   }

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void delete(Role role) throws Exception {
      // TODO check integrity constrains
      this.securityServiceDAO.refresh(role);
      this.securityServiceDAO.delete(role);
   }

   /**
    * Documentaci�.
    *
    * @param group Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void delete(PartyGroup group) throws Exception {
      // TODO check integrity constrains
      this.securityServiceDAO.refresh(group);
      this.securityServiceDAO.delete(group);
   }

   /**
    * Documentaci�.
    *
    * @param pojo Documentaci�
    * @param property Documentaci�
    *
    * @throws BusinessException Documentaci�
    */
   protected void validateBusinessRuleUniqueNameContraint(Object pojo,
      String property) throws BusinessException {
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List findAllApplicationRoles() {
      return this.securityServiceDAO.findAll(Role.class);
   }

   /**
    * Documentaci�.
    *
    * @param user Documentaci�
    *
    * @return Documentaci�
    */
   public Collection getAvailableRoles(UserLogin user) {
      List applicationRoles = this.securityServiceDAO.findAll(Role.class);

      return CollectionUtils.subtract(applicationRoles, user.getAllRoles());
   }

   /**
    * Documentaci�.
    *
    * @param group Documentaci�
    *
    * @return Documentaci�
    */
   public Collection getAvailableRoles(PartyGroup group) {
      List applicationRoles = this.securityServiceDAO.findAll(Role.class);

      return CollectionUtils.subtract(applicationRoles,
         group.getRecursiveRoles());
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void afterPropertiesSet() throws Exception {
      Assert.notNull(this.securityServiceDAO);
   }
}
