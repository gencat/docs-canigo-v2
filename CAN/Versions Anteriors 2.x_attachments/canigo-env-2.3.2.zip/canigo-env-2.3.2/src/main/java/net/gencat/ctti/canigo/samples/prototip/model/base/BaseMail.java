/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.samples.prototip.model.base;

import java.io.Serializable;

import java.lang.Comparable;


/**
 * This is an object that contains data related to the MAIL table.
 * Do not modify this class because it will be overwritten if the configuration file
 * related to this class is modified.
 *
 * @hibernate.class
 *  table="MAIL"
 */
public abstract class BaseMail implements Comparable, Serializable {
   /**
    * Documentaci�.
    */
   public static String REF = "Mail";

   /**
    * Documentaci�.
    */
   public static String PROP_SUBJECT = "subject";

   /**
    * Documentaci�.
    */
   public static String PROP_MESSAGE = "message";

   /**
    * Documentaci�.
    */
   public static String PROP_TO_ADDRESS = "toAddress";

   /**
    * Documentaci�.
    */
   public static String PROP_ID = "id";

   /**
    * Documentaci�.
    */
   public static String PROP_FROM_ADDRESS = "fromAddress";

   // fields
   /**
    * Documentaci�.
    */
   private java.lang.String fromAddress;

   // primary key
   /**
    * Documentaci�.
    */
   private java.lang.String id;

   /**
    * Documentaci�.
    */
   private java.lang.String message;

   /**
    * Documentaci�.
    */
   private java.lang.String subject;

   /**
    * Documentaci�.
    */
   private java.lang.String toAddress;

   /**
    * Documentaci�.
    */
   private int hashCode = Integer.MIN_VALUE;

   // constructors
   /**
    * Creates a new BaseMail object.
    */
   public BaseMail() {
      initialize();
   }

   /**
    * Constructor for primary key
    */
   public BaseMail(java.lang.String id) {
      this.setId(id);
      initialize();
   }

   /**
    * Constructor for required fields
    */
   public BaseMail(java.lang.String id, java.lang.String fromAddress,
      java.lang.String toAddress, java.lang.String subject,
      java.lang.String message) {
      this.setId(id);
      this.setFromAddress(fromAddress);
      this.setToAddress(toAddress);
      this.setSubject(subject);
      this.setMessage(message);
      initialize();
   }

   /**
    * Documentaci�.
    */
   protected void initialize() {
   }

   /**
    * Return the unique identifier of this class
   * @hibernate.id
   *  generator-class="sequence"
   *  column="MAILID"
   */
   public java.lang.String getId() {
      return id;
   }

   /**
    * Set the unique identifier of this class
    * @param id the new ID
    */
   public void setId(java.lang.String id) {
      this.id = id;
      this.hashCode = Integer.MIN_VALUE;
   }

   /**
    * Return the value associated with the column: FROM_ADDRESS
    */
   public java.lang.String getFromAddress() {
      return fromAddress;
   }

   /**
    * Set the value related to the column: FROM_ADDRESS
    * @param fromAddress the FROM_ADDRESS value
    */
   public void setFromAddress(java.lang.String fromAddress) {
      this.fromAddress = fromAddress;
   }

   /**
    * Return the value associated with the column: TO_ADDRESS
    */
   public java.lang.String getToAddress() {
      return toAddress;
   }

   /**
    * Set the value related to the column: TO_ADDRESS
    * @param toAddress the TO_ADDRESS value
    */
   public void setToAddress(java.lang.String toAddress) {
      this.toAddress = toAddress;
   }

   /**
    * Return the value associated with the column: SUBJECT
    */
   public java.lang.String getSubject() {
      return subject;
   }

   /**
    * Set the value related to the column: SUBJECT
    * @param subject the SUBJECT value
    */
   public void setSubject(java.lang.String subject) {
      this.subject = subject;
   }

   /**
    * Return the value associated with the column: MESSAGE
    */
   public java.lang.String getMessage() {
      return message;
   }

   /**
    * Set the value related to the column: MESSAGE
    * @param message the MESSAGE value
    */
   public void setMessage(java.lang.String message) {
      this.message = message;
   }

   /**
    * Documentaci�.
    *
    * @param obj Documentaci�
    *
    * @return Documentaci�
    */
   public boolean equals(Object obj) {
      if (null == obj) {
         return false;
      }

      if (!(obj instanceof net.gencat.ctti.canigo.samples.prototip.model.Mail)) {
         return false;
      } else {
         net.gencat.ctti.canigo.samples.prototip.model.Mail mail = (net.gencat.ctti.canigo.samples.prototip.model.Mail) obj;

         if ((null == this.getId()) || (null == mail.getId())) {
            return false;
         } else {
            return (this.getId().equals(mail.getId()));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int hashCode() {
      if (Integer.MIN_VALUE == this.hashCode) {
         if (null == this.getId()) {
            return super.hashCode();
         } else {
            String hashStr = this.getClass().getName() + ":" +
               this.getId().hashCode();
            this.hashCode = hashStr.hashCode();
         }
      }

      return this.hashCode;
   }

   /**
    * Documentaci�.
    *
    * @param obj Documentaci�
    *
    * @return Documentaci�
    */
   public int compareTo(Object obj) {
      if (obj.hashCode() > hashCode()) {
         return 1;
      } else if (obj.hashCode() < hashCode()) {
         return -1;
      } else {
         return 0;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String toString() {
      return super.toString();
   }
}
