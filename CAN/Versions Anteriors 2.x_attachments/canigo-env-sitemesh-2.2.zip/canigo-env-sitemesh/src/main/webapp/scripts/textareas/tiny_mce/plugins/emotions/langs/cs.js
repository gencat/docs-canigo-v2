/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2007/07/16 11:20:58 cbernal Exp $ 
 */  

tinyMCE.addToLang('',{
insert_emotions_title : 'Vložit emotikonu',
emotions_desc : 'Emotikony'
});

