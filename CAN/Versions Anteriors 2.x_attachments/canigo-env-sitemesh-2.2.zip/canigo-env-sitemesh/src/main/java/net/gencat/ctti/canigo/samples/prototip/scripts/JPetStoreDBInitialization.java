/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.samples.prototip.scripts;

import javax.sql.DataSource;

import net.gencat.ctti.canigo.core.util.tests.HSQLDatabaseFixture;
import net.gencat.ctti.canigo.core.util.tests.SQLScript;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;


/**
 * To be used only in a development context. Does 3 things:
 * - start HSQL db
 * - run script db creation
 * - run script dataload
 * @author jean-michel.garnier
 *
 */
public class JPetStoreDBInitialization implements InitializingBean,
   DisposableBean {
   /**
    * Documentaci�.
    */
   private DataSource dataSource;

   /**
    * Documentaci�.
    *
    * @param dataSource Documentaci�
    */
   public void setDataSource(DataSource dataSource) {
      this.dataSource = dataSource;
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void afterPropertiesSet() throws Exception {
      HSQLDatabaseFixture.start("jpetstore");

      // TODO add a test to check if db exists ...
      SQLScript schemaScript = new SQLScript(this.dataSource,
            "sql/prototip-hsqldb-schema.sql");
      schemaScript.execute();

      SQLScript loadScript = new SQLScript(this.dataSource,
            "sql/prototip-hsqldb-dataload.sql");
      loadScript.execute();
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void destroy() throws Exception {
      HSQLDatabaseFixture.stopServer();
   }
}
