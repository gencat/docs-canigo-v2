/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.samples.prototip.struts.menu;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.security.SecurityService;
import net.gencat.ctti.canigo.services.web.spring.util.WebApplicationContextUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.1 $
  */
public class AcegiPermissionsFilter implements Filter {
   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @throws ServletException Documentaci�
    */
   public void init(FilterConfig arg0) throws ServletException {
   }

   /**
    * Documentaci�.
    */
   public void destroy() {
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    * @param arg2 Documentaci�
    *
    * @throws IOException Documentaci�
    * @throws ServletException Documentaci�
    */
   public void doFilter(ServletRequest arg0, ServletResponse arg1,
      FilterChain arg2) throws IOException, ServletException {
      HttpServletRequest request = (HttpServletRequest) arg0;
      HttpSession session = request.getSession();
      Object obj = session.getAttribute("acegiPermissionsAdapter");

      if (obj == null) {
         SecurityService securityService = (SecurityService) WebApplicationContextUtils.getBeanOfType(((HttpServletRequest) arg0).getSession()
                                                                                                       .getServletContext(),
               SecurityService.class);
         LoggingService logService = (LoggingService) WebApplicationContextUtils.getBeanOfType(((HttpServletRequest) arg0).getSession()
                                                                                                .getServletContext(),
               LoggingService.class);
         session.setAttribute("acegiPermissionsAdapter",
            new AcegiPermissionsAdapter(securityService, logService));
      }

      arg2.doFilter(arg0, arg1);
   }
}
