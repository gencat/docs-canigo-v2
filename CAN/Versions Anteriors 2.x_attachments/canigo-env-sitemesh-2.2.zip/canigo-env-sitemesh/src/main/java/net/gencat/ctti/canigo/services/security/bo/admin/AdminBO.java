/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.bo.admin;

import java.util.Collection;
import java.util.List;

import net.gencat.ctti.canigo.services.security.model.PartyGroup;
import net.gencat.ctti.canigo.services.security.model.Role;
import net.gencat.ctti.canigo.services.security.model.UserLogin;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.1 $
  */
public interface AdminBO {
   /**
    * Documentaci�.
    *
    * @param userLogin Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void save(UserLogin userLogin) throws Exception;

   /**
    * Documentaci�.
    *
    * @param userLogin Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void refresh(UserLogin userLogin) throws Exception;

   /**
    * Documentaci�.
    *
    * @param userLogin Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void saveOrUpdate(UserLogin userLogin) throws Exception;

   /**
    * Documentaci�.
    *
    * @param userLogin Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void delete(UserLogin userLogin) throws Exception;

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void save(Role role) throws Exception;

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void refresh(Role role) throws Exception;

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void saveOrUpdate(Role role) throws Exception;

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void delete(Role role) throws Exception;

   /**
    * Documentaci�.
    *
    * @param group Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void save(PartyGroup group) throws Exception;

   /**
    * Documentaci�.
    *
    * @param group Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void refresh(PartyGroup group) throws Exception;

   /**
    * Documentaci�.
    *
    * @param group Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void saveOrUpdate(PartyGroup group) throws Exception;

   /**
    * Documentaci�.
    *
    * @param group Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void delete(PartyGroup group) throws Exception;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List findAllApplicationRoles();

   /**
    * Documentaci�.
    *
    * @param user Documentaci�
    *
    * @return Documentaci�
    */
   public Collection getAvailableRoles(UserLogin user);

   /**
    * Documentaci�.
    *
    * @param group Documentaci�
    *
    * @return Documentaci�
    */
   public Collection getAvailableRoles(PartyGroup group);
}
