/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.samples.prototip.struts.action;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.gencat.ctti.canigo.samples.prototip.model.Category;
import net.gencat.ctti.canigo.samples.prototip.model.bo.CategoryBO;
import net.gencat.ctti.canigo.services.reporting.ReportingController;
import net.gencat.ctti.canigo.services.reporting.SpringBindingFormJRDataSource;
import net.gencat.ctti.canigo.services.web.lists.ValueListActionHelper;
import net.gencat.ctti.canigo.services.web.struts.DispatchActionSupport;
import net.gencat.ctti.canigo.services.web.struts.SpringBindingActionForm;
import net.gencat.ctti.canigo.services.xml.XMLSerializationService;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.1 $
  */
public class CategoryAction extends DispatchActionSupport {
   /**
    * Documentaci�.
    */
   private CategoryBO bo;

   /**
    * Documentaci�.
    */
   private ValueListActionHelper valueListActionHelper;

   /**
    * Documentaci�.
    */
   private XMLSerializationService serializationService;

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward create(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      return mapping.findForward("create");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward edit(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      SpringBindingActionForm actionForm = (SpringBindingActionForm) form;
      Category vo = (Category) actionForm.getTarget();

      if (vo.getId() != null) {
         bo.refresh(vo);
      }

      return mapping.findForward("edit");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward save(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      SpringBindingActionForm actionForm = (SpringBindingActionForm) form;
      Category vo = (Category) actionForm.getTarget();

      if (vo.getId() != null) {
         bo.saveOrUpdate(vo);
      }

      return mapping.findForward("success");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward saveWithError(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      this.logService.getLog(this.getClass()).debug("Voy a producir un error...");

      SpringBindingActionForm actionForm = (SpringBindingActionForm) form;
      Category vo = (Category) actionForm.getTarget();

      new ExceptionBO().execute();

      if (vo.getId() != null) {
         bo.saveOrUpdate(vo);
      }

      return mapping.findForward("success");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward search(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      valueListActionHelper.search(mapping, form, request, response);

      return mapping.findForward("list");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward searchExportPDF(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      request.setAttribute("displayProvider", "ExportPDF");

      return this.search(mapping, form, request, response);
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward searchExportXML(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      this.logService.getLog(this.getClass()).debug("Searching categories...");

      List list = (this.bo).findAll();
      this.logService.getLog(this.getClass())
                     .debug("La lista tiene " + list.size() + " elementos");

      if (list != null) {
         request.setAttribute("__list__", list);
      }

      if (serializationService != null) {
         request.setAttribute("__serializationService__", serializationService);
      }

      return mapping.findForward("xml");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward searchExportExcel(ActionMapping mapping,
      ActionForm form, javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      request.setAttribute("displayProvider", "ExportExcel");

      return this.search(mapping, form, request, response);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public CategoryBO getDao() {
      return bo;
   }

   /**
    * Documentaci�.
    *
    * @param bo Documentaci�
    */
   public void setDao(CategoryBO bo) {
      this.bo = bo;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ValueListActionHelper getValueListActionHelper() {
      return valueListActionHelper;
   }

   /**
    * Documentaci�.
    *
    * @param valueListActionHelper Documentaci�
    */
   public void setValueListActionHelper(
      ValueListActionHelper valueListActionHelper) {
      this.valueListActionHelper = valueListActionHelper;
   }

   /**
    * @return Returns the serializationService.
    */
   public XMLSerializationService getSerializationService() {
      return serializationService;
   }

   /**
    * @param serializationService The serializationService to set.
    */
   public void setSerializationService(
      XMLSerializationService serializationService) {
      this.serializationService = serializationService;
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward report(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      this.logService.getLog(this.getClass()).debug("Finding categories...");

      List list = (this.bo).findAll();
      this.logService.getLog(this.getClass()).debug("List size=" + list.size());

      if (list != null) {
         Map model = new HashMap();
         Iterator it = list.iterator();

         if (it.hasNext()) {
            // Solo cogemos la primera categoria para mostrar un ejemplo de report+subreport
            Category c = (Category) it.next();
            this.logService.getLog(this.getClass())
                           .debug("Getting first category (" + c.getId() +
               ")...");

            SpringBindingActionForm springForm = (SpringBindingActionForm) form;
            springForm.expose(c);

            SpringBindingFormJRDataSource wrapper = new SpringBindingFormJRDataSource(springForm);
            wrapper.setLogService(this.logService);
            this.logService.getLog(this.getClass())
                           .debug("Setting category wrapper...");
            model.put("category", wrapper);
            this.logService.getLog(this.getClass())
                           .debug("Setting products (" +
               c.getProducts().size() + ")...");
            model.put("products", c.getProducts());
         }

         request.getSession()
                .setAttribute(ReportingController.REPORTING_CONTROLLER_MODEL,
            model);
         request.getSession()
                .setAttribute(ReportingController.REPORTING_CONTROLLER_REPORTID,
            "categoriesReportView");
      }

      return mapping.findForward("reportsController");
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public CategoryBO getBo() {
      return bo;
   }

   /**
    * Documentaci�.
    *
    * @param bo Documentaci�
    */
   public void setBo(CategoryBO bo) {
      this.bo = bo;
   }
}
