// French lang variables by Laurent Dran

tinyMCE.addToLang('',{
print_desc : 'Imprimer'
});
