/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2007/04/18 11:16:04 msabates Exp $ 
 */  

tinyMCE.addToLang('',{
save_desc : 'Uložit'
});

