/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2007/04/18 11:16:04 msabates Exp $ 
 */  

tinyMCE.addToLang('',{
insert_advhr_desc : 'Vložit/editovat vodorovný oddělovač',
insert_advhr_width : 'Šířka',
insert_advhr_size : 'Výška',
insert_advhr_noshade : 'Nestínovat'
});

