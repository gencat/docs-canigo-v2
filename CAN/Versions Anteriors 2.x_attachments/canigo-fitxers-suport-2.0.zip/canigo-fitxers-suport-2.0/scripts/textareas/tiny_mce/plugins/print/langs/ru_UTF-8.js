// RU lang variables UTF-8

tinyMCE.addToLang('',{
print_desc : 'Распечатать'
});
