// SE lang variables

tinyMCE.addToLang('',{
preview_desc : 'F&ouml;rhandsgranska'
});
