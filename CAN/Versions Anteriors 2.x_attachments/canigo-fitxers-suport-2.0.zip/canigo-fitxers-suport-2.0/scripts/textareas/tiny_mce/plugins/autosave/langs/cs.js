/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2007/04/18 11:16:01 msabates Exp $ 
 */  

tinyMCE.addToLang('',{
autosave_unload_msg : 'Změny, které jste udělal(a) budou ztraceny, jestliže opustíte tuto stránku.'
});

