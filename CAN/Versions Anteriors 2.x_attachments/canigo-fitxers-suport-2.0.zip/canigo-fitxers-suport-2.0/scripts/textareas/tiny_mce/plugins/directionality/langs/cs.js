/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2007/04/18 11:16:01 msabates Exp $ 
 */  

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Směr z leva doprava',
directionality_rtl_desc : 'Směr z prava doleva'
});

