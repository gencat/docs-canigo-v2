// NL lang variables

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Zoeken',
searchreplace_searchnext_desc : 'Opnieuw zoeken',
searchreplace_replace_desc : 'Zoeken/Vervang',
searchreplace_notfound : 'De zoekopdracht is klaar. Het zoekargument was niet gevonden.',
searchreplace_search_title : 'Zoeken',
searchreplace_replace_title : 'Zoeken/Vervangen',
searchreplace_allreplaced : 'Alle zoekargumenten werden vervangen.',
searchreplace_findwhat : 'Zoek argument',
searchreplace_replacewith : 'Vervang met',
searchreplace_direction : 'Richting',
searchreplace_up : 'Op',
searchreplace_down : 'Neer',
searchreplace_case : 'Identieke hoofdletters',
searchreplace_findnext : 'Volgende zoeken',
searchreplace_replace : 'Vervang',
searchreplace_replaceall : 'Vervang&nbsp;alles',
searchreplace_cancel : 'Annuleer'
});
