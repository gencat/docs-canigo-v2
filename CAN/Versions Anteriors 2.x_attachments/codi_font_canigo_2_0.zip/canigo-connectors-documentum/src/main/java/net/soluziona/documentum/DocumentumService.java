/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.soluziona.documentum;

import net.soluziona.documentum.exceptions.DocumentumException;


/**
 * Implementa el login/ logout a Documentum a trav�s de la creaci� d'una classe SessionManager
 *
 * @author SOLUZIONA
 * @version 1.1
 */
public interface DocumentumService {
    /**
     * Obre una nova sessio o recull una previa ja existent per al usuari
     *
     * @param usuari Usuari
     * @param contrasenya Contrasenya
     * @param docBase docBase de connexi�
     *
     * @return SessionManager
     */
    public Session login(String usuari, String contrasenya, String docBase,
        DocumentumConnectorImpl myDCS) throws DocumentumException;

    /**
     * Tanca la sessi�
     *
     * @param usuari Usuari
     * @param unicUsuari DOCUMENT ME!
     *
     * @return Resultat de l'operaci�
     *
     * @throws DocumentumException DOCUMENT ME!
     */

    //public boolean logout(String usuari, boolean unicUsuari)
    //throws DocumentumException;

    /**
     * Solament per debug: retorna el total de sessionManagers creats
     *
     * @return numeric
     */

    //public int numSessionManager ();
}
