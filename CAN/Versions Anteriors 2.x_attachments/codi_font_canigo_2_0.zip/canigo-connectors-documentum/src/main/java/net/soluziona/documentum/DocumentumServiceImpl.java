/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.soluziona.documentum;

import com.documentum.fc.client.IDfSessionManager;

import net.gencat.ctti.canigo.services.logging.LoggingService;

import net.soluziona.documentum.exceptions.DocumentumException;

import java.util.HashMap;


/**
 *
 *
 * @author SOLUZIONA
 * @version 1.1
 */
public class DocumentumServiceImpl implements DocumentumService {
    static private DocumentumService instance;

    /* v5.0
     * static private HashMap<String, SessionManager> poolConexions;
     * */
    static private HashMap poolConexions;

    // M�todes d'integraci� amb el FrameWork canigo
    private LoggingService logService = null;

    private DocumentumServiceImpl() {
    }

    /** ************************** */
    /**
     * LOGGING
     */

    /** ************************** */
    protected void logInfo(String str) {
        if (this.logService != null) {
            this.logService.getLog(this.getClass()).info(str);
        }
    }

    protected void logError(String str) {
        if (this.logService != null) {
            this.logService.getLog(this.getClass()).error(str);
        }
    }

    protected void logDebug(String str) {
        if (this.logService != null) {
            this.logService.getLog(this.getClass()).debug(str);
        }
    }

    /**
     * Obt� una �nica instancia de la classe
     *
     * @return instancia
     */
    public static DocumentumService getInstance() {
        if (instance == null) {
            instance = new DocumentumServiceImpl();

            //poolConexions = new HashMap();
        }

        return instance;
    }

    /**
     * Obre una nova sessio o recull una previa ja existent per al usuari
     *
     * @param usuari Usuari
     * @param contrasenya Contrasenya
     * @param docBase docBase de connexi�
     */
    public Session login(String usuari, String contrasenya, String docBase,
        DocumentumConnectorImpl myDCS) throws DocumentumException {
        // Se ha de comprobar en el HashMap si existe el usuario para ver si previamente ha solicitado conexi�n.
        //   en caso afirmativo validar que sigue activa, y sino volver a crearla.
        // Sino, solicitar nueva conexi�n y a�adirla al HashMap.
        logInfo("login inici");

        String DfSession = null;
        Session session = null;

        IDfSessionManager sMgr = null;

        //myDCS = new DocumentumConnectorImpl();
        sMgr = myDCS.createDfSession(usuari, contrasenya, docBase);
        //try{
        session = new SessionImpl(sMgr, usuari, contrasenya, docBase);
        /*}catch (DfException ex) {
            ExceptionDetails exDetails = new ExceptionDetails("canigo.services.documentum.error_creating_session_object",
                    null, Layer.SERVICES, Subsystem.UNDEFINED);
        
            //exDetails.setProperties(DocumentumProperties);
            throw new DocumentumException(ex, exDetails);
        }*/
        logInfo("login fi");

        return session;
    }
}
