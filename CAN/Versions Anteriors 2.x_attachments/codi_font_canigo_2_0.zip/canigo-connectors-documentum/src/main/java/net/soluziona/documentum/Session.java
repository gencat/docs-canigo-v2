/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.soluziona.documentum;

import com.documentum.fc.client.IDfSessionManager;

import net.soluziona.documentum.exceptions.DocumentumException;


/**
 * Classe que implementa un gestor de sessions d'un usuari a Documentum.
 *
 * @author SOLUZIONA
 * @version 1.1
 */
public interface Session {
    public IDfSessionManager getM_documentumSMgr();

    public String getM_contrasenya();

    public String getM_docBase();

    public String getM_usuari();

    //public String getM_sessioId();

    /**
     * Tanca la sessi� de Documentum
     *
     * @throws DocumentumException DOCUMENT ME!
     */
    public void close() throws DocumentumException;

    /**
     * Valida que la connexi� amb Documentum estigui activa
     *
     * @param docBase docBase
     *
     * @return Estat de la connexi�
     *
     * @throws DocumentumException DOCUMENT ME!
     */

    //public boolean connexioActiva(String docBase) throws DocumentumException;

    /**
     * Reactiva una connexi� previa
     *
     * @param docBase docBase
     *
     * @throws DocumentumException DOCUMENT ME!
     */

    //public void reconnectar(String docBase) throws DocumentumException;
}
