/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.soluziona.documentum;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;

/**
 *
 *
 * @author SOLUZIONA
 * @version 1.1
 */
import net.soluziona.documentum.exceptions.DocumentumException;


public class SessionManagerImpl implements SessionManager {
    private IDfSessionManager m_documentumSMgr;
    private String m_usuari;
    private String m_contrasenya;
    private String m_docBase;

    public SessionManagerImpl() {
    }

    protected SessionManagerImpl(IDfSessionManager sMgr, String usuari,
        String contrasenya, String docBase) {
        this.m_documentumSMgr = sMgr;
        this.m_usuari = usuari;
        this.m_contrasenya = contrasenya;
        this.m_docBase = docBase;
    }

    public IDfSessionManager getM_documentumSMgr() {
        return m_documentumSMgr;
    }

    public String getM_contrasenya() {
        return m_contrasenya;
    }

    public String getM_docBase() {
        return m_docBase;
    }

    public String getM_usuari() {
        return m_usuari;
    }

    public void close() throws DocumentumException {
        DocumentumConnectorService myDCS = new DocumentumConnectorService();
        ;
        myDCS.releaseSessionManager(m_documentumSMgr);
    }

    public boolean connexioActiva(String docBase) throws DocumentumException {
        if ((docBase == null) || (docBase.length() == 0)) {
            throw new DocumentumException("Es deu indicar una DOCBASE coneguda");
        }

        try {
            IDfSession mySess = m_documentumSMgr.getSession(docBase);
            m_documentumSMgr.release(mySess);
        } catch (DfException e) {
            e.printStackTrace();

            return false;
        }

        return true;
    }

    public void reconnectar(String docBase) {
        // TODO Auto-generated method stub
    }
}
