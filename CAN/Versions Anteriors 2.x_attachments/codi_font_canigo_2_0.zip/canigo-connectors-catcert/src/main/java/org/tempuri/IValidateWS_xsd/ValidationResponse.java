/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
/**
 * ValidationResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */
package org.tempuri.IValidateWS_xsd;

public class ValidationResponse implements java.io.Serializable {
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc = new org.apache.axis.description.TypeDesc(ValidationResponse.class,
            true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName(
                "http://tempuri.org/IValidateWS.xsd", "ValidationResponse"));

        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value");
        elemField.setXmlName(new javax.xml.namespace.QName("", "value"));
        elemField.setXmlType(new javax.xml.namespace.QName(
                "http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codeError");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codeError"));
        elemField.setXmlType(new javax.xml.namespace.QName(
                "http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "status"));
        elemField.setXmlType(new javax.xml.namespace.QName(
                "http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusReason");
        elemField.setXmlName(new javax.xml.namespace.QName("", "statusReason"));
        elemField.setXmlType(new javax.xml.namespace.QName(
                "http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fields");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fields"));
        elemField.setXmlType(new javax.xml.namespace.QName(
                "http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signature");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signature"));
        elemField.setXmlType(new javax.xml.namespace.QName(
                "http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    private java.lang.String value;
    private java.lang.String codeError;
    private java.lang.String status;
    private java.lang.String statusReason;
    private java.lang.String fields;
    private java.lang.String signature;
    private java.lang.Object __equalsCalc = null;
    private boolean __hashCodeCalc = false;

    public ValidationResponse() {
    }

    public ValidationResponse(java.lang.String value,
        java.lang.String codeError, java.lang.String status,
        java.lang.String statusReason, java.lang.String fields,
        java.lang.String signature) {
        this.value = value;
        this.codeError = codeError;
        this.status = status;
        this.statusReason = statusReason;
        this.fields = fields;
        this.signature = signature;
    }

    /**
     * Gets the value value for this ValidationResponse.
     *
     * @return value
     */
    public java.lang.String getValue() {
        return value;
    }

    /**
     * Sets the value value for this ValidationResponse.
     *
     * @param value
     */
    public void setValue(java.lang.String value) {
        this.value = value;
    }

    /**
     * Gets the codeError value for this ValidationResponse.
     *
     * @return codeError
     */
    public java.lang.String getCodeError() {
        return codeError;
    }

    /**
     * Sets the codeError value for this ValidationResponse.
     *
     * @param codeError
     */
    public void setCodeError(java.lang.String codeError) {
        this.codeError = codeError;
    }

    /**
     * Gets the status value for this ValidationResponse.
     *
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }

    /**
     * Sets the status value for this ValidationResponse.
     *
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }

    /**
     * Gets the statusReason value for this ValidationResponse.
     *
     * @return statusReason
     */
    public java.lang.String getStatusReason() {
        return statusReason;
    }

    /**
     * Sets the statusReason value for this ValidationResponse.
     *
     * @param statusReason
     */
    public void setStatusReason(java.lang.String statusReason) {
        this.statusReason = statusReason;
    }

    /**
     * Gets the fields value for this ValidationResponse.
     *
     * @return fields
     */
    public java.lang.String getFields() {
        return fields;
    }

    /**
     * Sets the fields value for this ValidationResponse.
     *
     * @param fields
     */
    public void setFields(java.lang.String fields) {
        this.fields = fields;
    }

    /**
     * Gets the signature value for this ValidationResponse.
     *
     * @return signature
     */
    public java.lang.String getSignature() {
        return signature;
    }

    /**
     * Sets the signature value for this ValidationResponse.
     *
     * @param signature
     */
    public void setSignature(java.lang.String signature) {
        this.signature = signature;
    }

    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ValidationResponse)) {
            return false;
        }

        ValidationResponse other = (ValidationResponse) obj;

        if (obj == null) {
            return false;
        }

        if (this == obj) {
            return true;
        }

        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }

        __equalsCalc = obj;

        boolean _equals;
        _equals = true &&
            (((this.value == null) && (other.getValue() == null)) ||
            ((this.value != null) && this.value.equals(other.getValue()))) &&
            (((this.codeError == null) && (other.getCodeError() == null)) ||
            ((this.codeError != null) &&
            this.codeError.equals(other.getCodeError()))) &&
            (((this.status == null) && (other.getStatus() == null)) ||
            ((this.status != null) && this.status.equals(other.getStatus()))) &&
            (((this.statusReason == null) && (other.getStatusReason() == null)) ||
            ((this.statusReason != null) &&
            this.statusReason.equals(other.getStatusReason()))) &&
            (((this.fields == null) && (other.getFields() == null)) ||
            ((this.fields != null) && this.fields.equals(other.getFields()))) &&
            (((this.signature == null) && (other.getSignature() == null)) ||
            ((this.signature != null) &&
            this.signature.equals(other.getSignature())));
        __equalsCalc = null;

        return _equals;
    }

    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }

        __hashCodeCalc = true;

        int _hashCode = 1;

        if (getValue() != null) {
            _hashCode += getValue().hashCode();
        }

        if (getCodeError() != null) {
            _hashCode += getCodeError().hashCode();
        }

        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }

        if (getStatusReason() != null) {
            _hashCode += getStatusReason().hashCode();
        }

        if (getFields() != null) {
            _hashCode += getFields().hashCode();
        }

        if (getSignature() != null) {
            _hashCode += getSignature().hashCode();
        }

        __hashCodeCalc = false;

        return _hashCode;
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
        java.lang.String mechType, java.lang.Class _javaType,
        javax.xml.namespace.QName _xmlType) {
        return new org.apache.axis.encoding.ser.BeanSerializer(_javaType,
            _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
        java.lang.String mechType, java.lang.Class _javaType,
        javax.xml.namespace.QName _xmlType) {
        return new org.apache.axis.encoding.ser.BeanDeserializer(_javaType,
            _xmlType, typeDesc);
    }
}
