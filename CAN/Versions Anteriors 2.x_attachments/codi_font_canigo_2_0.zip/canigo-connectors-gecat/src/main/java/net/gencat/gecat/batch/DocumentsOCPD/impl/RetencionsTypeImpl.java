/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPD.impl;

public class RetencionsTypeImpl implements net.gencat.gecat.batch.DocumentsOCPD.RetencionsType,
    com.sun.xml.bind.JAXBObject,
    net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.XMLSerializable,
    net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.ValidatableObject {
    public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsOCPD.impl.JAXBVersion.class);
    private static com.sun.msv.grammar.Grammar schemaFragment;
    protected com.sun.xml.bind.util.ListImpl _DadaRetencio;

    private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
        return (net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.class);
    }

    protected com.sun.xml.bind.util.ListImpl _getDadaRetencio() {
        if (_DadaRetencio == null) {
            _DadaRetencio = new com.sun.xml.bind.util.ListImpl(new java.util.ArrayList());
        }

        return _DadaRetencio;
    }

    public java.util.List getDadaRetencio() {
        return _getDadaRetencio();
    }

    public void serializeBody(
        net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx1 = 0;
        final int len1 = ((_DadaRetencio == null) ? 0 : _DadaRetencio.size());

        while (idx1 != len1) {
            context.startElement("", "DadaRetencio");

            int idx_0 = idx1;
            context.childAsURIs(((com.sun.xml.bind.JAXBObject) _DadaRetencio.get(
                    idx_0++)), "DadaRetencio");
            context.endNamespaceDecls();

            int idx_1 = idx1;
            context.childAsAttributes(((com.sun.xml.bind.JAXBObject) _DadaRetencio.get(
                    idx_1++)), "DadaRetencio");
            context.endAttributes();
            context.childAsBody(((com.sun.xml.bind.JAXBObject) _DadaRetencio.get(
                    idx1++)), "DadaRetencio");
            context.endElement();
        }
    }

    public void serializeAttributes(
        net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx1 = 0;
        final int len1 = ((_DadaRetencio == null) ? 0 : _DadaRetencio.size());

        while (idx1 != len1) {
            idx1 += 1;
        }
    }

    public void serializeURIs(
        net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx1 = 0;
        final int len1 = ((_DadaRetencio == null) ? 0 : _DadaRetencio.size());

        while (idx1 != len1) {
            idx1 += 1;
        }
    }

    public java.lang.Class getPrimaryInterface() {
        return (net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.class);
    }

    public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
        if (schemaFragment == null) {
            schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000 com.sun.msv.grammar.OneOrMoreExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001ccom.s" +
                    "un.msv.grammar.UnaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0003expt\u0000 Lcom/sun/msv/gram" +
                    "mar/Expression;xr\u0000\u001ecom.sun.msv.grammar.Expression\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002" +
                    "L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000bexpandedExpq\u0000" +
                    "~\u0000\u0002xpppsr\u0000\'com.sun.msv.grammar.trex.ElementPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000" +
                    "\u0001L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/NameClass;xr\u0000\u001ecom.sun.m" +
                    "sv.grammar.ElementExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aignoreUndeclaredAttribute" +
                    "sL\u0000\fcontentModelq\u0000~\u0000\u0002xq\u0000~\u0000\u0003pp\u0000sr\u0000\u001fcom.sun.msv.grammar.Sequen" +
                    "ceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.sun.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002" +
                    "L\u0000\u0004exp1q\u0000~\u0000\u0002L\u0000\u0004exp2q\u0000~\u0000\u0002xq\u0000~\u0000\u0003ppsq\u0000~\u0000\u0006pp\u0000sr\u0000\u001dcom.sun.msv.gra" +
                    "mmar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u000bppsq\u0000~\u0000\u0000sr\u0000\u0011java.lang.Boolean" +
                    "\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000 com.sun.msv.grammar.AttributeExp\u0000" +
                    "\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClassq\u0000~\u0000\u0007xq\u0000~\u0000\u0003q\u0000~\u0000\u0012psr\u00002com.su" +
                    "n.msv.grammar.Expression$AnyStringExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000" +
                    "\u0003sq\u0000~\u0000\u0011\u0001q\u0000~\u0000\u0016sr\u0000 com.sun.msv.grammar.AnyNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000" +
                    "xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000com.sun.ms" +
                    "v.grammar.Expression$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003q\u0000~\u0000\u0017" +
                    "q\u0000~\u0000\u001csr\u0000#com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlo" +
                    "calNamet\u0000\u0012Ljava/lang/String;L\u0000\fnamespaceURIq\u0000~\u0000\u001exq\u0000~\u0000\u0019t\u0000Dnet" +
                    ".gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetenci" +
                    "oTypet\u0000+http://java.sun.com/jaxb/xjc/dummy-elementssq\u0000~\u0000\u000epps" +
                    "q\u0000~\u0000\u0013q\u0000~\u0000\u0012psr\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000" +
                    "\u001fLorg/relaxng/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dLcom" +
                    "/sun/msv/util/StringPair;xq\u0000~\u0000\u0003ppsr\u0000\"com.sun.msv.datatype.xs" +
                    "d.QnameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.xsd.BuiltinAt" +
                    "omicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datatype.xsd.ConcreteType" +
                    "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype.xsd.XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000" +
                    "\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUriq\u0000~\u0000\u001eL\u0000\btypeNameq\u0000~\u0000\u001eL\u0000\nwhiteSpacet\u0000.Lco" +
                    "m/sun/msv/datatype/xsd/WhiteSpaceProcessor;xpt\u0000 http://www.w" +
                    "3.org/2001/XMLSchemat\u0000\u0005QNamesr\u00005com.sun.msv.datatype.xsd.Whi" +
                    "teSpaceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datatype" +
                    ".xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000com.sun.msv.grammar" +
                    ".Expression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun." +
                    "msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000\u001eL\u0000\fnamespaceU" +
                    "RIq\u0000~\u0000\u001expq\u0000~\u0000/q\u0000~\u0000.sq\u0000~\u0000\u001dt\u0000\u0004typet\u0000)http://www.w3.org/2001/XM" +
                    "LSchema-instanceq\u0000~\u0000\u001csq\u0000~\u0000\u001dt\u0000\fDadaRetenciot\u0000\u0000sr\u0000\"com.sun.msv" +
                    ".grammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/sun/msv" +
                    "/grammar/ExpressionPool$ClosedHash;xpsr\u0000-com.sun.msv.grammar" +
                    ".ExpressionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamVersio" +
                    "nL\u0000\u0006parentt\u0000$Lcom/sun/msv/grammar/ExpressionPool;xp\u0000\u0000\u0000\u0005\u0001pq\u0000~" +
                    "\u0000\fq\u0000~\u0000\u0010q\u0000~\u0000\"q\u0000~\u0000\u0005q\u0000~\u0000\u000fx"));
        }

        return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
    }

    public static class DadaRetencioTypeImpl implements net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType,
        com.sun.xml.bind.JAXBObject,
        net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.XMLSerializable,
        net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.ValidatableObject {
        public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsOCPD.impl.JAXBVersion.class);
        private static com.sun.msv.grammar.Grammar schemaFragment;
        protected java.lang.String _ImportBase;
        protected java.lang.String _ImportRetencio;
        protected java.lang.String _IndicadorRetencio;
        protected boolean has_Order;
        protected int _Order;
        protected java.lang.String _TipusRegistre;

        private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
            return (net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType.class);
        }

        public java.lang.String getImportBase() {
            return _ImportBase;
        }

        public void setImportBase(java.lang.String value) {
            _ImportBase = value;
        }

        public java.lang.String getImportRetencio() {
            return _ImportRetencio;
        }

        public void setImportRetencio(java.lang.String value) {
            _ImportRetencio = value;
        }

        public java.lang.String getIndicadorRetencio() {
            return _IndicadorRetencio;
        }

        public void setIndicadorRetencio(java.lang.String value) {
            _IndicadorRetencio = value;
        }

        public int getOrder() {
            return _Order;
        }

        public void setOrder(int value) {
            _Order = value;
            has_Order = true;
        }

        public java.lang.String getTipusRegistre() {
            return _TipusRegistre;
        }

        public void setTipusRegistre(java.lang.String value) {
            _TipusRegistre = value;
        }

        public void serializeBody(
            net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
            context.startElement("", "TipusRegistre");
            context.endNamespaceDecls();
            context.endAttributes();

            try {
                context.text(((java.lang.String) _TipusRegistre),
                    "TipusRegistre");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endElement();
            context.startElement("", "IndicadorRetencio");
            context.endNamespaceDecls();
            context.endAttributes();

            try {
                context.text(((java.lang.String) _IndicadorRetencio),
                    "IndicadorRetencio");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endElement();
            context.startElement("", "ImportBase");
            context.endNamespaceDecls();
            context.endAttributes();

            try {
                context.text(((java.lang.String) _ImportBase), "ImportBase");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endElement();
            context.startElement("", "ImportRetencio");
            context.endNamespaceDecls();
            context.endAttributes();

            try {
                context.text(((java.lang.String) _ImportRetencio),
                    "ImportRetencio");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endElement();
        }

        public void serializeAttributes(
            net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
            if (has_Order) {
                context.startAttribute("", "order");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _Order)), "Order");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }
        }

        public void serializeURIs(
            net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
        }

        public java.lang.Class getPrimaryInterface() {
            return (net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType.class);
        }

        public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
            if (schemaFragment == null) {
                schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                        "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                        "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                        "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                        "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsr\u0000\'com.sun.msv." +
                        "grammar.trex.ElementPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\tnameClasst\u0000\u001fLcom/su" +
                        "n/msv/grammar/NameClass;xr\u0000\u001ecom.sun.msv.grammar.ElementExp\u0000\u0000" +
                        "\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aignoreUndeclaredAttributesL\u0000\fcontentModelq\u0000~\u0000\u0002xq" +
                        "\u0000~\u0000\u0003pp\u0000sq\u0000~\u0000\u0000ppsr\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002" +
                        "dtt\u0000\u001fLorg/relaxng/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001d" +
                        "Lcom/sun/msv/util/StringPair;xq\u0000~\u0000\u0003ppsr\u0000\'com.sun.msv.datatyp" +
                        "e.xsd.MaxLengthFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\tmaxLengthxr\u00009com.sun.msv.d" +
                        "atatype.xsd.DataTypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*c" +
                        "om.sun.msv.datatype.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFac" +
                        "etFixedZ\u0000\u0012needValueCheckFlagL\u0000\bbaseTypet\u0000)Lcom/sun/msv/datat" +
                        "ype/xsd/XSDatatypeImpl;L\u0000\fconcreteTypet\u0000\'Lcom/sun/msv/dataty" +
                        "pe/xsd/ConcreteType;L\u0000\tfacetNamet\u0000\u0012Ljava/lang/String;xr\u0000\'com" +
                        ".sun.msv.datatype.xsd.XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceU" +
                        "riq\u0000~\u0000\u0017L\u0000\btypeNameq\u0000~\u0000\u0017L\u0000\nwhiteSpacet\u0000.Lcom/sun/msv/datatype" +
                        "/xsd/WhiteSpaceProcessor;xpt\u0000\u0000psr\u00005com.sun.msv.datatype.xsd." +
                        "WhiteSpaceProcessor$Preserve\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datat" +
                        "ype.xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xp\u0000\u0000sr\u0000#com.sun.msv.da" +
                        "tatype.xsd.StringType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001Z\u0000\risAlwaysValidxr\u0000*com.sun." +
                        "msv.datatype.xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv" +
                        ".datatype.xsd.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0018t\u0000 http://www.w3." +
                        "org/2001/XMLSchemat\u0000\u0006stringq\u0000~\u0000\u001e\u0001q\u0000~\u0000\"t\u0000\tmaxLength\u0000\u0000\u0000\u0001sr\u00000co" +
                        "m.sun.msv.grammar.Expression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000" +
                        "~\u0000\u0003ppsr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq" +
                        "\u0000~\u0000\u0017L\u0000\fnamespaceURIq\u0000~\u0000\u0017xpt\u0000\u000estring-derivedq\u0000~\u0000\u001bsr\u0000\u001dcom.sun." +
                        "msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsr\u0000 com.sun.msv.gram" +
                        "mar.AttributeExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClassq\u0000~\u0000\nxq\u0000~\u0000" +
                        "\u0003sr\u0000\u0011java.lang.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psq\u0000~\u0000\u000eppsr\u0000\"com" +
                        ".sun.msv.datatype.xsd.QnameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000 q\u0000~\u0000#t\u0000\u0005QNam" +
                        "esr\u00005com.sun.msv.datatype.xsd.WhiteSpaceProcessor$Collapse\u0000\u0000" +
                        "\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u001dq\u0000~\u0000\'sq\u0000~\u0000(q\u0000~\u00004q\u0000~\u0000#sr\u0000#com.sun.msv.grammar." +
                        "SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000\u0017L\u0000\fnamespaceURIq\u0000" +
                        "~\u0000\u0017xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpt\u0000\u0004typet\u0000)h" +
                        "ttp://www.w3.org/2001/XMLSchema-instancesr\u00000com.sun.msv.gram" +
                        "mar.Expression$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000/\u0001q\u0000~\u0000" +
                        ">sq\u0000~\u00008t\u0000\rTipusRegistreq\u0000~\u0000\u001bsq\u0000~\u0000\tpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u000eppsq\u0000~\u0000\u0012q" +
                        "\u0000~\u0000\u001bpq\u0000~\u0000\u001e\u0000\u0000q\u0000~\u0000\"q\u0000~\u0000\"q\u0000~\u0000%\u0000\u0000\u0000\u0002q\u0000~\u0000\'sq\u0000~\u0000(t\u0000\u000estring-derivedq" +
                        "\u0000~\u0000\u001bsq\u0000~\u0000+ppsq\u0000~\u0000-q\u0000~\u00000pq\u0000~\u00001q\u0000~\u0000:q\u0000~\u0000>sq\u0000~\u00008t\u0000\u0011IndicadorRet" +
                        "encioq\u0000~\u0000\u001bsq\u0000~\u0000\tpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u000eppsq\u0000~\u0000\u0012q\u0000~\u0000\u001bpq\u0000~\u0000\u001e\u0000\u0000q\u0000~\u0000\"q" +
                        "\u0000~\u0000\"q\u0000~\u0000%\u0000\u0000\u0000\rq\u0000~\u0000\'sq\u0000~\u0000(t\u0000\u000estring-derivedq\u0000~\u0000\u001bsq\u0000~\u0000+ppsq\u0000~\u0000-" +
                        "q\u0000~\u00000pq\u0000~\u00001q\u0000~\u0000:q\u0000~\u0000>sq\u0000~\u00008t\u0000\nImportBaseq\u0000~\u0000\u001bsq\u0000~\u0000\tpp\u0000sq\u0000~\u0000\u0000" +
                        "ppsq\u0000~\u0000\u000eppsq\u0000~\u0000\u0012q\u0000~\u0000\u001bpq\u0000~\u0000\u001e\u0000\u0000q\u0000~\u0000\"q\u0000~\u0000\"q\u0000~\u0000%\u0000\u0000\u0000\rq\u0000~\u0000\'sq\u0000~\u0000(t" +
                        "\u0000\u000estring-derivedq\u0000~\u0000\u001bsq\u0000~\u0000+ppsq\u0000~\u0000-q\u0000~\u00000pq\u0000~\u00001q\u0000~\u0000:q\u0000~\u0000>sq\u0000~" +
                        "\u00008t\u0000\u000eImportRetencioq\u0000~\u0000\u001bsq\u0000~\u0000+ppsq\u0000~\u0000-q\u0000~\u00000psq\u0000~\u0000\u000eppsr\u0000 com." +
                        "sun.msv.datatype.xsd.IntType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000+com.sun.msv.datat" +
                        "ype.xsd.IntegerDerivedType\u0099\u00f1]\u0090&6k\u00be\u0002\u0000\u0001L\u0000\nbaseFacetsq\u0000~\u0000\u0015xq\u0000~\u0000" +
                        " q\u0000~\u0000#t\u0000\u0003intq\u0000~\u00006sr\u0000*com.sun.msv.datatype.xsd.MaxInclusiveFa" +
                        "cet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.datatype.xsd.RangeFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000" +
                        "\u0001\u0002\u0000\u0001L\u0000\nlimitValuet\u0000\u0012Ljava/lang/Object;xq\u0000~\u0000\u0013ppq\u0000~\u00006\u0000\u0001sr\u0000*com" +
                        ".sun.msv.datatype.xsd.MinInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000hppq\u0000" +
                        "~\u00006\u0000\u0000sr\u0000!com.sun.msv.datatype.xsd.LongType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000dq" +
                        "\u0000~\u0000#t\u0000\u0004longq\u0000~\u00006sq\u0000~\u0000gppq\u0000~\u00006\u0000\u0001sq\u0000~\u0000kppq\u0000~\u00006\u0000\u0000sr\u0000$com.sun.ms" +
                        "v.datatype.xsd.IntegerType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000dq\u0000~\u0000#t\u0000\u0007integerq\u0000" +
                        "~\u00006sr\u0000,com.sun.msv.datatype.xsd.FractionDigitsFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002" +
                        "\u0000\u0001I\u0000\u0005scalexr\u0000;com.sun.msv.datatype.xsd.DataTypeWithLexicalCo" +
                        "nstraintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000\u0014ppq\u0000~\u00006\u0001\u0000sr\u0000#com.sun.msv.datat" +
                        "ype.xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000 q\u0000~\u0000#t\u0000\u0007decimalq\u0000~\u00006q\u0000~\u0000y" +
                        "t\u0000\u000efractionDigits\u0000\u0000\u0000\u0000q\u0000~\u0000st\u0000\fminInclusivesr\u0000\u000ejava.lang.Long;" +
                        "\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010java.lang.Number\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q" +
                        "\u0000~\u0000st\u0000\fmaxInclusivesq\u0000~\u0000}\u007f\u00ff\u00ff\u00ff\u00ff\u00ff\u00ff\u00ffq\u0000~\u0000nq\u0000~\u0000|sr\u0000\u0011java.lang.Int" +
                        "eger\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000~\u0080\u0000\u0000\u0000q\u0000~\u0000nq\u0000~\u0000\u0080sq\u0000~\u0000\u0082\u007f\u00ff\u00ff\u00ffq\u0000~\u0000\'sq" +
                        "\u0000~\u0000(q\u0000~\u0000fq\u0000~\u0000#sq\u0000~\u00008t\u0000\u0005orderq\u0000~\u0000\u001bq\u0000~\u0000>sr\u0000\"com.sun.msv.gramma" +
                        "r.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/sun/msv/gramma" +
                        "r/ExpressionPool$ClosedHash;xpsr\u0000-com.sun.msv.grammar.Expres" +
                        "sionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamVersionL\u0000\u0006par" +
                        "entt\u0000$Lcom/sun/msv/grammar/ExpressionPool;xp\u0000\u0000\u0000\r\u0001pq\u0000~\u0000Wq\u0000~\u0000M" +
                        "q\u0000~\u0000\rq\u0000~\u0000\u0005q\u0000~\u0000\u0006q\u0000~\u0000,q\u0000~\u0000Hq\u0000~\u0000Rq\u0000~\u0000\\q\u0000~\u0000\bq\u0000~\u0000Cq\u0000~\u0000\u0007q\u0000~\u0000`x"));
            }

            return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
        }
    }
}
