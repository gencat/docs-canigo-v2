/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsMPE.impl;

public class DadesGeneralsTypeImpl implements net.gencat.gecat.batch.DocumentsMPE.DadesGeneralsType,
    com.sun.xml.bind.JAXBObject,
    net.gencat.gecat.batch.DocumentsMPE.impl.runtime.XMLSerializable,
    net.gencat.gecat.batch.DocumentsMPE.impl.runtime.ValidatableObject {
    public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsMPE.impl.JAXBVersion.class);
    private static com.sun.msv.grammar.Grammar schemaFragment;
    protected java.lang.String _ClasseDocument;
    protected java.lang.String _Transaccio;
    protected net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType _DadesPosicio;
    protected java.lang.String _DataConversio;
    protected java.lang.String _NDocument;
    protected java.lang.String _DataDocument;
    protected java.lang.String _TipusRegistre;
    protected java.lang.String _Societat;
    protected java.lang.String _DataCompt;
    protected java.lang.String _Moneda;
    protected java.lang.String _TipusCanvi;

    private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
        return (net.gencat.gecat.batch.DocumentsMPE.DadesGeneralsType.class);
    }

    public java.lang.String getClasseDocument() {
        return _ClasseDocument;
    }

    public void setClasseDocument(java.lang.String value) {
        _ClasseDocument = value;
    }

    public java.lang.String getTransaccio() {
        return _Transaccio;
    }

    public void setTransaccio(java.lang.String value) {
        _Transaccio = value;
    }

    public net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType getDadesPosicio() {
        return _DadesPosicio;
    }

    public void setDadesPosicio(
        net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType value) {
        _DadesPosicio = value;
    }

    public java.lang.String getDataConversio() {
        return _DataConversio;
    }

    public void setDataConversio(java.lang.String value) {
        _DataConversio = value;
    }

    public java.lang.String getNDocument() {
        return _NDocument;
    }

    public void setNDocument(java.lang.String value) {
        _NDocument = value;
    }

    public java.lang.String getDataDocument() {
        return _DataDocument;
    }

    public void setDataDocument(java.lang.String value) {
        _DataDocument = value;
    }

    public java.lang.String getTipusRegistre() {
        return _TipusRegistre;
    }

    public void setTipusRegistre(java.lang.String value) {
        _TipusRegistre = value;
    }

    public java.lang.String getSocietat() {
        return _Societat;
    }

    public void setSocietat(java.lang.String value) {
        _Societat = value;
    }

    public java.lang.String getDataCompt() {
        return _DataCompt;
    }

    public void setDataCompt(java.lang.String value) {
        _DataCompt = value;
    }

    public java.lang.String getMoneda() {
        return _Moneda;
    }

    public void setMoneda(java.lang.String value) {
        _Moneda = value;
    }

    public java.lang.String getTipusCanvi() {
        return _TipusCanvi;
    }

    public void setTipusCanvi(java.lang.String value) {
        _TipusCanvi = value;
    }

    public void serializeBody(
        net.gencat.gecat.batch.DocumentsMPE.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        context.startElement("", "DadesPosicio");
        context.childAsURIs(((com.sun.xml.bind.JAXBObject) _DadesPosicio),
            "DadesPosicio");
        context.endNamespaceDecls();
        context.childAsAttributes(((com.sun.xml.bind.JAXBObject) _DadesPosicio),
            "DadesPosicio");
        context.endAttributes();
        context.childAsBody(((com.sun.xml.bind.JAXBObject) _DadesPosicio),
            "DadesPosicio");
        context.endElement();
        context.startElement("", "TipusRegistre");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _TipusRegistre), "TipusRegistre");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPE.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "Transaccio");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _Transaccio), "Transaccio");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPE.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "NDocument");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _NDocument), "NDocument");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPE.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "ClasseDocument");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _ClasseDocument), "ClasseDocument");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPE.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "DataDocument");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _DataDocument), "DataDocument");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPE.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "DataCompt");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _DataCompt), "DataCompt");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPE.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "Societat");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _Societat), "Societat");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPE.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "TipusCanvi");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _TipusCanvi), "TipusCanvi");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPE.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "DataConversio");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _DataConversio), "DataConversio");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPE.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "Moneda");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _Moneda), "Moneda");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsMPE.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
    }

    public void serializeAttributes(
        net.gencat.gecat.batch.DocumentsMPE.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
    }

    public void serializeURIs(
        net.gencat.gecat.batch.DocumentsMPE.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
    }

    public java.lang.Class getPrimaryInterface() {
        return (net.gencat.gecat.batch.DocumentsMPE.DadesGeneralsType.class);
    }

    public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
        if (schemaFragment == null) {
            schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                    "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                    "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                    "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                    "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                    "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsr\u0000\'com.sun.msv.grammar.trex" +
                    ".ElementPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/gramma" +
                    "r/NameClass;xr\u0000\u001ecom.sun.msv.grammar.ElementExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001a" +
                    "ignoreUndeclaredAttributesL\u0000\fcontentModelq\u0000~\u0000\u0002xq\u0000~\u0000\u0003pp\u0000sq\u0000~\u0000" +
                    "\u0000ppsq\u0000~\u0000\u000fpp\u0000sr\u0000\u001dcom.sun.msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~" +
                    "\u0000\u0001ppsr\u0000 com.sun.msv.grammar.OneOrMoreExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001ccom.s" +
                    "un.msv.grammar.UnaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0003expq\u0000~\u0000\u0002xq\u0000~\u0000\u0003sr\u0000\u0011java." +
                    "lang.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000 com.sun.msv.grammar.A" +
                    "ttributeExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClassq\u0000~\u0000\u0010xq\u0000~\u0000\u0003q\u0000~\u0000" +
                    "\u001bpsr\u00002com.sun.msv.grammar.Expression$AnyStringExpression\u0000\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\u001a\u0001q\u0000~\u0000\u001fsr\u0000 com.sun.msv.grammar.AnyNameClas" +
                    "s\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr" +
                    "\u00000com.sun.msv.grammar.Expression$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000" +
                    "\u0000xq\u0000~\u0000\u0003q\u0000~\u0000 q\u0000~\u0000%sr\u0000#com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlocalNamet\u0000\u0012Ljava/lang/String;L\u0000\fnamespaceURIq\u0000~\u0000\'" +
                    "xq\u0000~\u0000\"t\u00004net.gencat.gecat.batch.DocumentsMPE.DadesPosicioTyp" +
                    "et\u0000+http://java.sun.com/jaxb/xjc/dummy-elementssq\u0000~\u0000\u0015ppsq\u0000~\u0000" +
                    "\u001cq\u0000~\u0000\u001bpsr\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLor" +
                    "g/relaxng/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dLcom/sun" +
                    "/msv/util/StringPair;xq\u0000~\u0000\u0003ppsr\u0000\"com.sun.msv.datatype.xsd.Qn" +
                    "ameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.xsd.BuiltinAtomic" +
                    "Type\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datatype.xsd.ConcreteType\u0000\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype.xsd.XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000" +
                    "\u0003L\u0000\fnamespaceUriq\u0000~\u0000\'L\u0000\btypeNameq\u0000~\u0000\'L\u0000\nwhiteSpacet\u0000.Lcom/su" +
                    "n/msv/datatype/xsd/WhiteSpaceProcessor;xpt\u0000 http://www.w3.or" +
                    "g/2001/XMLSchemat\u0000\u0005QNamesr\u00005com.sun.msv.datatype.xsd.WhiteSp" +
                    "aceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datatype.xsd" +
                    ".WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000com.sun.msv.grammar.Exp" +
                    "ression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun.msv." +
                    "util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000\'L\u0000\fnamespaceURIq\u0000" +
                    "~\u0000\'xpq\u0000~\u00008q\u0000~\u00007sq\u0000~\u0000&t\u0000\u0004typet\u0000)http://www.w3.org/2001/XMLSch" +
                    "ema-instanceq\u0000~\u0000%sq\u0000~\u0000&t\u0000\fDadesPosiciot\u0000\u0000sq\u0000~\u0000\u000fpp\u0000sq\u0000~\u0000\u0000ppsq" +
                    "\u0000~\u0000-ppsr\u0000)com.sun.msv.datatype.xsd.EnumerationFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002" +
                    "\u0000\u0001L\u0000\u0006valuest\u0000\u000fLjava/util/Set;xr\u00009com.sun.msv.datatype.xsd.Da" +
                    "taTypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*com.sun.msv.dat" +
                    "atype.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFacetFixedZ\u0000\u0012need" +
                    "ValueCheckFlagL\u0000\bbaseTypet\u0000)Lcom/sun/msv/datatype/xsd/XSData" +
                    "typeImpl;L\u0000\fconcreteTypet\u0000\'Lcom/sun/msv/datatype/xsd/Concret" +
                    "eType;L\u0000\tfacetNameq\u0000~\u0000\'xq\u0000~\u00004q\u0000~\u0000Epsr\u00005com.sun.msv.datatype." +
                    "xsd.WhiteSpaceProcessor$Preserve\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000:\u0000\u0000sr\u0000#com.s" +
                    "un.msv.datatype.xsd.StringType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001Z\u0000\risAlwaysValidxq\u0000" +
                    "~\u00002q\u0000~\u00007t\u0000\u0006stringq\u0000~\u0000Q\u0001q\u0000~\u0000St\u0000\u000benumerationsr\u0000\u0011java.util.Hash" +
                    "Set\u00baD\u0085\u0095\u0096\u00b8\u00b74\u0003\u0000\u0000xpw\f\u0000\u0000\u0000\u0010?@\u0000\u0000\u0000\u0000\u0000\u0001t\u0000\u00011xq\u0000~\u0000=sq\u0000~\u0000>t\u0000\u000estring-deri" +
                    "vedq\u0000~\u0000Esq\u0000~\u0000\u0015ppsq\u0000~\u0000\u001cq\u0000~\u0000\u001bpq\u0000~\u00000q\u0000~\u0000@q\u0000~\u0000%sq\u0000~\u0000&t\u0000\rTipusReg" +
                    "istreq\u0000~\u0000Esq\u0000~\u0000\u000fpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000-ppsr\u0000\'com.sun.msv.datatype." +
                    "xsd.MaxLengthFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\tmaxLengthxq\u0000~\u0000Kq\u0000~\u0000Epq\u0000~\u0000Q\u0000\u0000" +
                    "q\u0000~\u0000Sq\u0000~\u0000St\u0000\tmaxLength\u0000\u0000\u0000\u0014q\u0000~\u0000=sq\u0000~\u0000>t\u0000\u000estring-derivedq\u0000~\u0000Es" +
                    "q\u0000~\u0000\u0015ppsq\u0000~\u0000\u001cq\u0000~\u0000\u001bpq\u0000~\u00000q\u0000~\u0000@q\u0000~\u0000%sq\u0000~\u0000&t\u0000\nTransaccioq\u0000~\u0000Esq" +
                    "\u0000~\u0000\u000fpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000-ppsq\u0000~\u0000bq\u0000~\u0000Epq\u0000~\u0000Q\u0000\u0000q\u0000~\u0000Sq\u0000~\u0000Sq\u0000~\u0000d\u0000\u0000\u0000" +
                    "\nq\u0000~\u0000=sq\u0000~\u0000>t\u0000\u000estring-derivedq\u0000~\u0000Esq\u0000~\u0000\u0015ppsq\u0000~\u0000\u001cq\u0000~\u0000\u001bpq\u0000~\u00000q" +
                    "\u0000~\u0000@q\u0000~\u0000%sq\u0000~\u0000&t\u0000\tNDocumentq\u0000~\u0000Esq\u0000~\u0000\u000fpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000-ppsq\u0000" +
                    "~\u0000bq\u0000~\u0000Epq\u0000~\u0000Q\u0000\u0000q\u0000~\u0000Sq\u0000~\u0000Sq\u0000~\u0000d\u0000\u0000\u0000\u0002q\u0000~\u0000=sq\u0000~\u0000>t\u0000\u000estring-deri" +
                    "vedq\u0000~\u0000Esq\u0000~\u0000\u0015ppsq\u0000~\u0000\u001cq\u0000~\u0000\u001bpq\u0000~\u00000q\u0000~\u0000@q\u0000~\u0000%sq\u0000~\u0000&t\u0000\u000eClasseDo" +
                    "cumentq\u0000~\u0000Esq\u0000~\u0000\u000fpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000-ppsq\u0000~\u0000bq\u0000~\u0000Epq\u0000~\u0000Q\u0000\u0000q\u0000~\u0000S" +
                    "q\u0000~\u0000Sq\u0000~\u0000d\u0000\u0000\u0000\bq\u0000~\u0000=sq\u0000~\u0000>t\u0000\u000estring-derivedq\u0000~\u0000Esq\u0000~\u0000\u0015ppsq\u0000~\u0000" +
                    "\u001cq\u0000~\u0000\u001bpq\u0000~\u00000q\u0000~\u0000@q\u0000~\u0000%sq\u0000~\u0000&t\u0000\fDataDocumentq\u0000~\u0000Esq\u0000~\u0000\u000fpp\u0000sq\u0000" +
                    "~\u0000\u0000ppsq\u0000~\u0000-ppsq\u0000~\u0000bq\u0000~\u0000Epq\u0000~\u0000Q\u0000\u0000q\u0000~\u0000Sq\u0000~\u0000Sq\u0000~\u0000d\u0000\u0000\u0000\bq\u0000~\u0000=sq\u0000~" +
                    "\u0000>t\u0000\u000estring-derivedq\u0000~\u0000Esq\u0000~\u0000\u0015ppsq\u0000~\u0000\u001cq\u0000~\u0000\u001bpq\u0000~\u00000q\u0000~\u0000@q\u0000~\u0000%s" +
                    "q\u0000~\u0000&t\u0000\tDataComptq\u0000~\u0000Esq\u0000~\u0000\u000fpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000-ppsq\u0000~\u0000bq\u0000~\u0000Epq" +
                    "\u0000~\u0000Q\u0000\u0000q\u0000~\u0000Sq\u0000~\u0000Sq\u0000~\u0000d\u0000\u0000\u0000\u0004q\u0000~\u0000=sq\u0000~\u0000>t\u0000\u000estring-derivedq\u0000~\u0000Esq" +
                    "\u0000~\u0000\u0015ppsq\u0000~\u0000\u001cq\u0000~\u0000\u001bpq\u0000~\u00000q\u0000~\u0000@q\u0000~\u0000%sq\u0000~\u0000&t\u0000\bSocietatq\u0000~\u0000Esq\u0000~\u0000" +
                    "\u000fpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000-ppsq\u0000~\u0000bq\u0000~\u0000Epq\u0000~\u0000Q\u0000\u0000q\u0000~\u0000Sq\u0000~\u0000Sq\u0000~\u0000d\u0000\u0000\u0000\tq\u0000" +
                    "~\u0000=sq\u0000~\u0000>t\u0000\u000estring-derivedq\u0000~\u0000Esq\u0000~\u0000\u0015ppsq\u0000~\u0000\u001cq\u0000~\u0000\u001bpq\u0000~\u00000q\u0000~\u0000" +
                    "@q\u0000~\u0000%sq\u0000~\u0000&t\u0000\nTipusCanviq\u0000~\u0000Esq\u0000~\u0000\u000fpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000-ppsq\u0000~\u0000" +
                    "bq\u0000~\u0000Epq\u0000~\u0000Q\u0000\u0000q\u0000~\u0000Sq\u0000~\u0000Sq\u0000~\u0000d\u0000\u0000\u0000\bq\u0000~\u0000=sq\u0000~\u0000>t\u0000\u000estring-derive" +
                    "dq\u0000~\u0000Esq\u0000~\u0000\u0015ppsq\u0000~\u0000\u001cq\u0000~\u0000\u001bpq\u0000~\u00000q\u0000~\u0000@q\u0000~\u0000%sq\u0000~\u0000&t\u0000\rDataConver" +
                    "sioq\u0000~\u0000Esq\u0000~\u0000\u000fpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000-ppsq\u0000~\u0000bq\u0000~\u0000Epq\u0000~\u0000Q\u0000\u0000q\u0000~\u0000Sq\u0000~" +
                    "\u0000Sq\u0000~\u0000d\u0000\u0000\u0000\u0005q\u0000~\u0000=sq\u0000~\u0000>t\u0000\u000estring-derivedq\u0000~\u0000Esq\u0000~\u0000\u0015ppsq\u0000~\u0000\u001cq\u0000" +
                    "~\u0000\u001bpq\u0000~\u00000q\u0000~\u0000@q\u0000~\u0000%sq\u0000~\u0000&t\u0000\u0006Monedaq\u0000~\u0000Esr\u0000\"com.sun.msv.gramm" +
                    "ar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/sun/msv/gramm" +
                    "ar/ExpressionPool$ClosedHash;xpsr\u0000-com.sun.msv.grammar.Expre" +
                    "ssionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamVersionL\u0000\u0006pa" +
                    "rentt\u0000$Lcom/sun/msv/grammar/ExpressionPool;xp\u0000\u0000\u0000\"\u0001pq\u0000~\u0000vq\u0000~\u0000" +
                    "+q\u0000~\u0000[q\u0000~\u0000gq\u0000~\u0000qq\u0000~\u0000{q\u0000~\u0000\u0085q\u0000~\u0000\u008fq\u0000~\u0000\u0099q\u0000~\u0000\bq\u0000~\u0000\u00a3q\u0000~\u0000\u00adq\u0000~\u0000\u00b7q\u0000~\u0000" +
                    "\u000eq\u0000~\u0000\u0019q\u0000~\u0000\tq\u0000~\u0000\u009eq\u0000~\u0000\u00a8q\u0000~\u0000\u0005q\u0000~\u0000\rq\u0000~\u0000lq\u0000~\u0000\u00b2q\u0000~\u0000\u0007q\u0000~\u0000\fq\u0000~\u0000\u000bq\u0000~\u0000" +
                    "Gq\u0000~\u0000\u0094q\u0000~\u0000\u0006q\u0000~\u0000\u0080q\u0000~\u0000\u0013q\u0000~\u0000\nq\u0000~\u0000\u008aq\u0000~\u0000`q\u0000~\u0000\u0016x"));
        }

        return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
    }
}
