/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl;

public class DadesRetornTypeImpl implements net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType,
    com.sun.xml.bind.JAXBObject,
    net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.XMLSerializable,
    net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.ValidatableObject {
    public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.JAXBVersion.class);
    private static com.sun.msv.grammar.Grammar schemaFragment;
    protected com.sun.xml.bind.util.ListImpl _DadaRetorn;
    protected boolean has_Order;
    protected int _Order;

    private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
        return (net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.class);
    }

    protected com.sun.xml.bind.util.ListImpl _getDadaRetorn() {
        if (_DadaRetorn == null) {
            _DadaRetorn = new com.sun.xml.bind.util.ListImpl(new java.util.ArrayList());
        }

        return _DadaRetorn;
    }

    public java.util.List getDadaRetorn() {
        return _getDadaRetorn();
    }

    public int getOrder() {
        if (!has_Order) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "1"));
        } else {
            return _Order;
        }
    }

    public void setOrder(int value) {
        _Order = value;
        has_Order = true;
    }

    public void serializeBody(
        net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx1 = 0;
        final int len1 = ((_DadaRetorn == null) ? 0 : _DadaRetorn.size());

        while (idx1 != len1) {
            context.startElement("", "DadaRetorn");

            int idx_0 = idx1;
            context.childAsURIs(((com.sun.xml.bind.JAXBObject) _DadaRetorn.get(
                    idx_0++)), "DadaRetorn");
            context.endNamespaceDecls();

            int idx_1 = idx1;
            context.childAsAttributes(((com.sun.xml.bind.JAXBObject) _DadaRetorn.get(
                    idx_1++)), "DadaRetorn");
            context.endAttributes();
            context.childAsBody(((com.sun.xml.bind.JAXBObject) _DadaRetorn.get(
                    idx1++)), "DadaRetorn");
            context.endElement();
        }
    }

    public void serializeAttributes(
        net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx1 = 0;
        final int len1 = ((_DadaRetorn == null) ? 0 : _DadaRetorn.size());

        if (has_Order) {
            context.startAttribute("", "order");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _Order)), "Order");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        while (idx1 != len1) {
            idx1 += 1;
        }
    }

    public void serializeURIs(
        net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx1 = 0;
        final int len1 = ((_DadaRetorn == null) ? 0 : _DadaRetorn.size());

        while (idx1 != len1) {
            idx1 += 1;
        }
    }

    public java.lang.Class getPrimaryInterface() {
        return (net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.class);
    }

    public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
        if (schemaFragment == null) {
            schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                    "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                    "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                    "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                    "expandedExpq\u0000~\u0000\u0002xpppsr\u0000 com.sun.msv.grammar.OneOrMoreExp\u0000\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001ccom.sun.msv.grammar.UnaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0003expq\u0000~\u0000" +
                    "\u0002xq\u0000~\u0000\u0003ppsr\u0000\'com.sun.msv.grammar.trex.ElementPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0001L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/NameClass;xr\u0000\u001ecom.sun" +
                    ".msv.grammar.ElementExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aignoreUndeclaredAttribu" +
                    "tesL\u0000\fcontentModelq\u0000~\u0000\u0002xq\u0000~\u0000\u0003pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\tpp\u0000sr\u0000\u001dcom.sun" +
                    ".msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsq\u0000~\u0000\u0006sr\u0000\u0011java.lang" +
                    ".Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000 com.sun.msv.grammar.Attri" +
                    "buteExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClassq\u0000~\u0000\nxq\u0000~\u0000\u0003q\u0000~\u0000\u0013psr" +
                    "\u00002com.sun.msv.grammar.Expression$AnyStringExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\u0012\u0001q\u0000~\u0000\u0017sr\u0000 com.sun.msv.grammar.AnyNameClass\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000co" +
                    "m.sun.msv.grammar.Expression$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000" +
                    "~\u0000\u0003q\u0000~\u0000\u0018q\u0000~\u0000\u001dsr\u0000#com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0002L\u0000\tlocalNamet\u0000\u0012Ljava/lang/String;L\u0000\fnamespaceURIq\u0000~\u0000\u001fxq\u0000~" +
                    "\u0000\u001at\u0000Snet.gencat.gecat.batch.DocumentsComplementarisRetorn.Da" +
                    "desRetornType.DadaRetornTypet\u0000+http://java.sun.com/jaxb/xjc/" +
                    "dummy-elementssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0014q\u0000~\u0000\u0013psr\u0000\u001bcom.sun.msv.grammar.Da" +
                    "taExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatype/Datatype;L\u0000\u0006ex" +
                    "ceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util/StringPair;xq\u0000~\u0000\u0003ppsr\u0000\"" +
                    "com.sun.msv.datatype.xsd.QnameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000*com.sun.msv" +
                    ".datatype.xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.da" +
                    "tatype.xsd.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype.x" +
                    "sd.XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUriq\u0000~\u0000\u001fL\u0000\btypeNameq" +
                    "\u0000~\u0000\u001fL\u0000\nwhiteSpacet\u0000.Lcom/sun/msv/datatype/xsd/WhiteSpaceProc" +
                    "essor;xpt\u0000 http://www.w3.org/2001/XMLSchemat\u0000\u0005QNamesr\u00005com.s" +
                    "un.msv.datatype.xsd.WhiteSpaceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000x" +
                    "r\u0000,com.sun.msv.datatype.xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xp" +
                    "sr\u00000com.sun.msv.grammar.Expression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tloca" +
                    "lNameq\u0000~\u0000\u001fL\u0000\fnamespaceURIq\u0000~\u0000\u001fxpq\u0000~\u00000q\u0000~\u0000/sq\u0000~\u0000\u001et\u0000\u0004typet\u0000)ht" +
                    "tp://www.w3.org/2001/XMLSchema-instanceq\u0000~\u0000\u001dsq\u0000~\u0000\u001et\u0000\nDadaRet" +
                    "ornt\u0000\u0000sq\u0000~\u0000\u000fppsq\u0000~\u0000\u0014q\u0000~\u0000\u0013psq\u0000~\u0000%ppsr\u0000 com.sun.msv.datatype.x" +
                    "sd.IntType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000+com.sun.msv.datatype.xsd.IntegerDer" +
                    "ivedType\u0099\u00f1]\u0090&6k\u00be\u0002\u0000\u0001L\u0000\nbaseFacetst\u0000)Lcom/sun/msv/datatype/xsd" +
                    "/XSDatatypeImpl;xq\u0000~\u0000*q\u0000~\u0000/t\u0000\u0003intq\u0000~\u00003sr\u0000*com.sun.msv.dataty" +
                    "pe.xsd.MaxInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.datatype." +
                    "xsd.RangeFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\nlimitValuet\u0000\u0012Ljava/lang/Object;x" +
                    "r\u00009com.sun.msv.datatype.xsd.DataTypeWithValueConstraintFacet" +
                    "\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.xsd.DataTypeWithFacet\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFacetFixedZ\u0000\u0012needValueCheckFlagL\u0000\bbaseTypeq\u0000~\u0000C" +
                    "L\u0000\fconcreteTypet\u0000\'Lcom/sun/msv/datatype/xsd/ConcreteType;L\u0000\t" +
                    "facetNameq\u0000~\u0000\u001fxq\u0000~\u0000,ppq\u0000~\u00003\u0000\u0001sr\u0000*com.sun.msv.datatype.xsd.Mi" +
                    "nInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Gppq\u0000~\u00003\u0000\u0000sr\u0000!com.sun.msv.dat" +
                    "atype.xsd.LongType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Bq\u0000~\u0000/t\u0000\u0004longq\u0000~\u00003sq\u0000~\u0000Fpp" +
                    "q\u0000~\u00003\u0000\u0001sq\u0000~\u0000Mppq\u0000~\u00003\u0000\u0000sr\u0000$com.sun.msv.datatype.xsd.IntegerTy" +
                    "pe\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Bq\u0000~\u0000/t\u0000\u0007integerq\u0000~\u00003sr\u0000,com.sun.msv.datat" +
                    "ype.xsd.FractionDigitsFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scalexr\u0000;com.sun.ms" +
                    "v.datatype.xsd.DataTypeWithLexicalConstraintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000" +
                    "xq\u0000~\u0000Jppq\u0000~\u00003\u0001\u0000sr\u0000#com.sun.msv.datatype.xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000" +
                    "\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000*q\u0000~\u0000/t\u0000\u0007decimalq\u0000~\u00003q\u0000~\u0000[t\u0000\u000efractionDigits\u0000\u0000\u0000\u0000q\u0000~" +
                    "\u0000Ut\u0000\fminInclusivesr\u0000\u000ejava.lang.Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010ja" +
                    "va.lang.Number\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u0000Ut\u0000\fmaxInclusivesq\u0000~\u0000" +
                    "_\u007f\u00ff\u00ff\u00ff\u00ff\u00ff\u00ff\u00ffq\u0000~\u0000Pq\u0000~\u0000^sr\u0000\u0011java.lang.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuex" +
                    "q\u0000~\u0000`\u0080\u0000\u0000\u0000q\u0000~\u0000Pq\u0000~\u0000bsq\u0000~\u0000d\u007f\u00ff\u00ff\u00ffq\u0000~\u00005sq\u0000~\u00006q\u0000~\u0000Eq\u0000~\u0000/sq\u0000~\u0000\u001et\u0000\u0005o" +
                    "rderq\u0000~\u0000=q\u0000~\u0000\u001dsr\u0000\"com.sun.msv.grammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/sun/msv/grammar/ExpressionPool$ClosedH" +
                    "ash;xpsr\u0000-com.sun.msv.grammar.ExpressionPool$ClosedHash\u00d7j\u00d0N\u00ef" +
                    "\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamVersionL\u0000\u0006parentt\u0000$Lcom/sun/msv/gramm" +
                    "ar/ExpressionPool;xp\u0000\u0000\u0000\u0007\u0001pq\u0000~\u0000\u0011q\u0000~\u0000\rq\u0000~\u0000\u0005q\u0000~\u0000>q\u0000~\u0000\bq\u0000~\u0000\u0010q\u0000~\u0000" +
                    "#x"));
        }

        return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
    }

    public static class DadaRetornTypeImpl implements net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType,
        com.sun.xml.bind.JAXBObject,
        net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.XMLSerializable,
        net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.ValidatableObject {
        public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.JAXBVersion.class);
        private static com.sun.msv.grammar.Grammar schemaFragment;
        protected java.lang.String _ClasseDocument;
        protected java.lang.String _StatusDocument;
        protected java.lang.String _NDocument;
        protected java.lang.String _SocietatFi;
        protected boolean has_Order;
        protected int _Order;
        protected java.lang.String _Exercici;
        protected java.lang.String _PosicioModificacio;
        protected java.lang.String _TextError;
        protected java.lang.String _PosicioDocument;
        protected java.lang.String _CodiPosicioError;

        private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
            return (net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType.class);
        }

        public java.lang.String getClasseDocument() {
            return _ClasseDocument;
        }

        public void setClasseDocument(java.lang.String value) {
            _ClasseDocument = value;
        }

        public java.lang.String getStatusDocument() {
            return _StatusDocument;
        }

        public void setStatusDocument(java.lang.String value) {
            _StatusDocument = value;
        }

        public java.lang.String getNDocument() {
            return _NDocument;
        }

        public void setNDocument(java.lang.String value) {
            _NDocument = value;
        }

        public java.lang.String getSocietatFi() {
            return _SocietatFi;
        }

        public void setSocietatFi(java.lang.String value) {
            _SocietatFi = value;
        }

        public int getOrder() {
            return _Order;
        }

        public void setOrder(int value) {
            _Order = value;
            has_Order = true;
        }

        public java.lang.String getExercici() {
            return _Exercici;
        }

        public void setExercici(java.lang.String value) {
            _Exercici = value;
        }

        public java.lang.String getPosicioModificacio() {
            return _PosicioModificacio;
        }

        public void setPosicioModificacio(java.lang.String value) {
            _PosicioModificacio = value;
        }

        public java.lang.String getTextError() {
            return _TextError;
        }

        public void setTextError(java.lang.String value) {
            _TextError = value;
        }

        public java.lang.String getPosicioDocument() {
            return _PosicioDocument;
        }

        public void setPosicioDocument(java.lang.String value) {
            _PosicioDocument = value;
        }

        public java.lang.String getCodiPosicioError() {
            return _CodiPosicioError;
        }

        public void setCodiPosicioError(java.lang.String value) {
            _CodiPosicioError = value;
        }

        public void serializeBody(
            net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
            context.startElement("", "SocietatFi");
            context.endNamespaceDecls();
            context.endAttributes();

            try {
                context.text(((java.lang.String) _SocietatFi), "SocietatFi");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endElement();
            context.startElement("", "Exercici");
            context.endNamespaceDecls();
            context.endAttributes();

            try {
                context.text(((java.lang.String) _Exercici), "Exercici");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endElement();
            context.startElement("", "ClasseDocument");
            context.endNamespaceDecls();
            context.endAttributes();

            try {
                context.text(((java.lang.String) _ClasseDocument),
                    "ClasseDocument");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endElement();
            context.startElement("", "NDocument");
            context.endNamespaceDecls();
            context.endAttributes();

            try {
                context.text(((java.lang.String) _NDocument), "NDocument");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endElement();
            context.startElement("", "PosicioDocument");
            context.endNamespaceDecls();
            context.endAttributes();

            try {
                context.text(((java.lang.String) _PosicioDocument),
                    "PosicioDocument");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endElement();
            context.startElement("", "StatusDocument");
            context.endNamespaceDecls();
            context.endAttributes();

            try {
                context.text(((java.lang.String) _StatusDocument),
                    "StatusDocument");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endElement();
            context.startElement("", "CodiPosicioError");
            context.endNamespaceDecls();
            context.endAttributes();

            try {
                context.text(((java.lang.String) _CodiPosicioError),
                    "CodiPosicioError");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endElement();
            context.startElement("", "TextError");
            context.endNamespaceDecls();
            context.endAttributes();

            try {
                context.text(((java.lang.String) _TextError), "TextError");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endElement();
            context.startElement("", "PosicioModificacio");
            context.endNamespaceDecls();
            context.endAttributes();

            try {
                context.text(((java.lang.String) _PosicioModificacio),
                    "PosicioModificacio");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endElement();
        }

        public void serializeAttributes(
            net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
            if (has_Order) {
                context.startAttribute("", "order");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _Order)), "Order");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }
        }

        public void serializeURIs(
            net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
        }

        public java.lang.Class getPrimaryInterface() {
            return (net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType.class);
        }

        public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
            if (schemaFragment == null) {
                schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                        "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                        "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                        "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                        "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                        "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsr\u0000\'com.sun.msv.grammar.trex.Element" +
                        "Pattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/NameCl" +
                        "ass;xr\u0000\u001ecom.sun.msv.grammar.ElementExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aignoreUn" +
                        "declaredAttributesL\u0000\fcontentModelq\u0000~\u0000\u0002xq\u0000~\u0000\u0003pp\u0000sq\u0000~\u0000\u0000ppsr\u0000\u001bc" +
                        "om.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/da" +
                        "tatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util/St" +
                        "ringPair;xq\u0000~\u0000\u0003ppsr\u0000\'com.sun.msv.datatype.xsd.MaxLengthFacet" +
                        "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\tmaxLengthxr\u00009com.sun.msv.datatype.xsd.DataType" +
                        "WithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype." +
                        "xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFacetFixedZ\u0000\u0012needValueC" +
                        "heckFlagL\u0000\bbaseTypet\u0000)Lcom/sun/msv/datatype/xsd/XSDatatypeIm" +
                        "pl;L\u0000\fconcreteTypet\u0000\'Lcom/sun/msv/datatype/xsd/ConcreteType;" +
                        "L\u0000\tfacetNamet\u0000\u0012Ljava/lang/String;xr\u0000\'com.sun.msv.datatype.xs" +
                        "d.XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUriq\u0000~\u0000\u001cL\u0000\btypeNameq\u0000" +
                        "~\u0000\u001cL\u0000\nwhiteSpacet\u0000.Lcom/sun/msv/datatype/xsd/WhiteSpaceProce" +
                        "ssor;xpt\u0000\u0000psr\u00005com.sun.msv.datatype.xsd.WhiteSpaceProcessor$" +
                        "Preserve\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datatype.xsd.WhiteSpacePr" +
                        "ocessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xp\u0000\u0000sr\u0000#com.sun.msv.datatype.xsd.StringTyp" +
                        "e\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001Z\u0000\risAlwaysValidxr\u0000*com.sun.msv.datatype.xsd.Bui" +
                        "ltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datatype.xsd.Concre" +
                        "teType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u001dt\u0000 http://www.w3.org/2001/XMLSchemat\u0000" +
                        "\u0006stringq\u0000~\u0000#\u0001q\u0000~\u0000\'t\u0000\tmaxLength\u0000\u0000\u0000\u0004sr\u00000com.sun.msv.grammar.Ex" +
                        "pression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun.msv" +
                        ".util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000\u001cL\u0000\fnamespaceURIq" +
                        "\u0000~\u0000\u001cxpt\u0000\u000estring-derivedq\u0000~\u0000 sr\u0000\u001dcom.sun.msv.grammar.ChoiceEx" +
                        "p\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsr\u0000 com.sun.msv.grammar.AttributeExp\u0000\u0000\u0000\u0000" +
                        "\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClassq\u0000~\u0000\u000fxq\u0000~\u0000\u0003sr\u0000\u0011java.lang.Boole" +
                        "an\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psq\u0000~\u0000\u0013ppsr\u0000\"com.sun.msv.datatype.xs" +
                        "d.QnameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000%q\u0000~\u0000(t\u0000\u0005QNamesr\u00005com.sun.msv.dat" +
                        "atype.xsd.WhiteSpaceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\"q\u0000~\u0000," +
                        "sq\u0000~\u0000-q\u0000~\u00009q\u0000~\u0000(sr\u0000#com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000" +
                        "\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000\u001cL\u0000\fnamespaceURIq\u0000~\u0000\u001cxr\u0000\u001dcom.sun.msv.g" +
                        "rammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpt\u0000\u0004typet\u0000)http://www.w3.org/200" +
                        "1/XMLSchema-instancesr\u00000com.sun.msv.grammar.Expression$Epsil" +
                        "onExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u00004\u0001q\u0000~\u0000Csq\u0000~\u0000=t\u0000\nSocietatFi" +
                        "q\u0000~\u0000 sq\u0000~\u0000\u000epp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0013ppsq\u0000~\u0000\u0017q\u0000~\u0000 pq\u0000~\u0000#\u0000\u0000q\u0000~\u0000\'q\u0000~\u0000\'q" +
                        "\u0000~\u0000*\u0000\u0000\u0000\u0004q\u0000~\u0000,sq\u0000~\u0000-t\u0000\u000estring-derivedq\u0000~\u0000 sq\u0000~\u00000ppsq\u0000~\u00002q\u0000~\u00005" +
                        "pq\u0000~\u00006q\u0000~\u0000?q\u0000~\u0000Csq\u0000~\u0000=t\u0000\bExerciciq\u0000~\u0000 sq\u0000~\u0000\u000epp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000" +
                        "\u0013ppsq\u0000~\u0000\u0017q\u0000~\u0000 pq\u0000~\u0000#\u0000\u0000q\u0000~\u0000\'q\u0000~\u0000\'q\u0000~\u0000*\u0000\u0000\u0000\u0002q\u0000~\u0000,sq\u0000~\u0000-t\u0000\u000estrin" +
                        "g-derivedq\u0000~\u0000 sq\u0000~\u00000ppsq\u0000~\u00002q\u0000~\u00005pq\u0000~\u00006q\u0000~\u0000?q\u0000~\u0000Csq\u0000~\u0000=t\u0000\u000eCl" +
                        "asseDocumentq\u0000~\u0000 sq\u0000~\u0000\u000epp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0013ppsq\u0000~\u0000\u0017q\u0000~\u0000 pq\u0000~\u0000#\u0000" +
                        "\u0000q\u0000~\u0000\'q\u0000~\u0000\'q\u0000~\u0000*\u0000\u0000\u0000\nq\u0000~\u0000,sq\u0000~\u0000-t\u0000\u000estring-derivedq\u0000~\u0000 sq\u0000~\u00000p" +
                        "psq\u0000~\u00002q\u0000~\u00005pq\u0000~\u00006q\u0000~\u0000?q\u0000~\u0000Csq\u0000~\u0000=t\u0000\tNDocumentq\u0000~\u0000 sq\u0000~\u0000\u000epp\u0000" +
                        "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0013ppsq\u0000~\u0000\u0017q\u0000~\u0000 pq\u0000~\u0000#\u0000\u0000q\u0000~\u0000\'q\u0000~\u0000\'q\u0000~\u0000*\u0000\u0000\u0000\u0003q\u0000~\u0000,s" +
                        "q\u0000~\u0000-t\u0000\u000estring-derivedq\u0000~\u0000 sq\u0000~\u00000ppsq\u0000~\u00002q\u0000~\u00005pq\u0000~\u00006q\u0000~\u0000?q\u0000~" +
                        "\u0000Csq\u0000~\u0000=t\u0000\u000fPosicioDocumentq\u0000~\u0000 sq\u0000~\u0000\u000epp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0013ppsr\u0000)" +
                        "com.sun.msv.datatype.xsd.EnumerationFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0006value" +
                        "st\u0000\u000fLjava/util/Set;xq\u0000~\u0000\u0018q\u0000~\u0000 pq\u0000~\u0000#\u0000\u0000q\u0000~\u0000\'q\u0000~\u0000\'t\u0000\u000benumerati" +
                        "onsr\u0000\u0011java.util.HashSet\u00baD\u0085\u0095\u0096\u00b8\u00b74\u0003\u0000\u0000xpw\f\u0000\u0000\u0000\u0010?@\u0000\u0000\u0000\u0000\u0000\u0002t\u0000\u0001St\u0000\u0001Nxq" +
                        "\u0000~\u0000,sq\u0000~\u0000-t\u0000\u000estring-derivedq\u0000~\u0000 sq\u0000~\u00000ppsq\u0000~\u00002q\u0000~\u00005pq\u0000~\u00006q\u0000~" +
                        "\u0000?q\u0000~\u0000Csq\u0000~\u0000=t\u0000\u000eStatusDocumentq\u0000~\u0000 sq\u0000~\u0000\u000epp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0013pp" +
                        "sq\u0000~\u0000\u0017q\u0000~\u0000 pq\u0000~\u0000#\u0000\u0000q\u0000~\u0000\'q\u0000~\u0000\'q\u0000~\u0000*\u0000\u0000\u0000\nq\u0000~\u0000,sq\u0000~\u0000-t\u0000\u000estring-d" +
                        "erivedq\u0000~\u0000 sq\u0000~\u00000ppsq\u0000~\u00002q\u0000~\u00005pq\u0000~\u00006q\u0000~\u0000?q\u0000~\u0000Csq\u0000~\u0000=t\u0000\u0010CodiP" +
                        "osicioErrorq\u0000~\u0000 sq\u0000~\u0000\u000epp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0013ppsq\u0000~\u0000\u0017q\u0000~\u0000 pq\u0000~\u0000#\u0000\u0000" +
                        "q\u0000~\u0000\'q\u0000~\u0000\'q\u0000~\u0000*\u0000\u0000\u0000dq\u0000~\u0000,sq\u0000~\u0000-t\u0000\u000estring-derivedq\u0000~\u0000 sq\u0000~\u00000pp" +
                        "sq\u0000~\u00002q\u0000~\u00005pq\u0000~\u00006q\u0000~\u0000?q\u0000~\u0000Csq\u0000~\u0000=t\u0000\tTextErrorq\u0000~\u0000 sq\u0000~\u0000\u000epp\u0000s" +
                        "q\u0000~\u0000\u0000ppsq\u0000~\u0000\u0013ppsq\u0000~\u0000\u0017q\u0000~\u0000 pq\u0000~\u0000#\u0000\u0000q\u0000~\u0000\'q\u0000~\u0000\'q\u0000~\u0000*\u0000\u0000\u0000\u0003q\u0000~\u0000,sq" +
                        "\u0000~\u0000-t\u0000\u000estring-derivedq\u0000~\u0000 sq\u0000~\u00000ppsq\u0000~\u00002q\u0000~\u00005pq\u0000~\u00006q\u0000~\u0000?q\u0000~\u0000" +
                        "Csq\u0000~\u0000=t\u0000\u0012PosicioModificacioq\u0000~\u0000 sq\u0000~\u00000ppsq\u0000~\u00002q\u0000~\u00005psq\u0000~\u0000\u0013p" +
                        "psr\u0000 com.sun.msv.datatype.xsd.IntType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000+com.sun." +
                        "msv.datatype.xsd.IntegerDerivedType\u0099\u00f1]\u0090&6k\u00be\u0002\u0000\u0001L\u0000\nbaseFacetsq" +
                        "\u0000~\u0000\u001axq\u0000~\u0000%q\u0000~\u0000(t\u0000\u0003intq\u0000~\u0000;sr\u0000*com.sun.msv.datatype.xsd.MaxIn" +
                        "clusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.datatype.xsd.RangeFac" +
                        "et\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\nlimitValuet\u0000\u0012Ljava/lang/Object;xq\u0000~\u0000\u0018ppq\u0000~\u0000;" +
                        "\u0000\u0001sr\u0000*com.sun.msv.datatype.xsd.MinInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000x" +
                        "q\u0000~\u0000\u00a6ppq\u0000~\u0000;\u0000\u0000sr\u0000!com.sun.msv.datatype.xsd.LongType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002" +
                        "\u0000\u0000xq\u0000~\u0000\u00a2q\u0000~\u0000(t\u0000\u0004longq\u0000~\u0000;sq\u0000~\u0000\u00a5ppq\u0000~\u0000;\u0000\u0001sq\u0000~\u0000\u00a9ppq\u0000~\u0000;\u0000\u0000sr\u0000$c" +
                        "om.sun.msv.datatype.xsd.IntegerType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u00a2q\u0000~\u0000(t\u0000\u0007" +
                        "integerq\u0000~\u0000;sr\u0000,com.sun.msv.datatype.xsd.FractionDigitsFacet" +
                        "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scalexr\u0000;com.sun.msv.datatype.xsd.DataTypeWith" +
                        "LexicalConstraintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000\u0019ppq\u0000~\u0000;\u0001\u0000sr\u0000#com.sun." +
                        "msv.datatype.xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000%q\u0000~\u0000(t\u0000\u0007decimalq" +
                        "\u0000~\u0000;q\u0000~\u0000\u00b7t\u0000\u000efractionDigits\u0000\u0000\u0000\u0000q\u0000~\u0000\u00b1t\u0000\fminInclusivesr\u0000\u000ejava.l" +
                        "ang.Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010java.lang.Number\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp" +
                        "\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u0000\u00b1t\u0000\fmaxInclusivesq\u0000~\u0000\u00bb\u007f\u00ff\u00ff\u00ff\u00ff\u00ff\u00ff\u00ffq\u0000~\u0000\u00acq\u0000~\u0000\u00basr\u0000\u0011java" +
                        ".lang.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000\u00bc\u0080\u0000\u0000\u0000q\u0000~\u0000\u00acq\u0000~\u0000\u00besq\u0000~\u0000\u00c0\u007f\u00ff" +
                        "\u00ff\u00ffq\u0000~\u0000,sq\u0000~\u0000-q\u0000~\u0000\u00a4q\u0000~\u0000(sq\u0000~\u0000=t\u0000\u0005orderq\u0000~\u0000 q\u0000~\u0000Csr\u0000\"com.sun.m" +
                        "sv.grammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/sun/m" +
                        "sv/grammar/ExpressionPool$ClosedHash;xpsr\u0000-com.sun.msv.gramm" +
                        "ar.ExpressionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamVers" +
                        "ionL\u0000\u0006parentt\u0000$Lcom/sun/msv/grammar/ExpressionPool;xp\u0000\u0000\u0000\u001c\u0001pq" +
                        "\u0000~\u0000\\q\u0000~\u0000\u009eq\u0000~\u0000\rq\u0000~\u0000Hq\u0000~\u0000\u0007q\u0000~\u0000\tq\u0000~\u0000\nq\u0000~\u0000\u0081q\u0000~\u0000\u0006q\u0000~\u0000\bq\u0000~\u0000pq\u0000~\u0000\u0095q" +
                        "\u0000~\u0000\u0012q\u0000~\u0000\u008bq\u0000~\u0000\u0005q\u0000~\u0000fq\u0000~\u0000\u000bq\u0000~\u0000\fq\u0000~\u0000Rq\u0000~\u00001q\u0000~\u0000Mq\u0000~\u0000Wq\u0000~\u0000aq\u0000~\u0000kq" +
                        "\u0000~\u0000|q\u0000~\u0000\u0086q\u0000~\u0000\u0090q\u0000~\u0000\u009ax"));
            }

            return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
        }
    }
}
