/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsMPE.verification;

public class DadesPosicioTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType master) {
        if (null == master.getDadaPosicio()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "DadaPosicio"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check count
            if (master.getDadaPosicio().size() < 1) {
                // Report minimum of occurences violated
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DadaPosicio"),
                        new de.fzi.dbs.verification.event.structure.TooFewElementsProblem(
                            master.getDadaPosicio().size(), 1)));
            }

            // Check value
            checkDadaPosicio(parentLocator, handler, master,
                master.getDadaPosicio());
        }
    }

    public void checkDadaPosicio(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType master,
        java.util.List values) {
        for (int index = 0; (index < values.size()); index++) {
            java.lang.Object item = values.get(index);
            checkDadaPosicio(parentLocator, handler, master, index, item);
        }
    }

    public void checkDadaPosicio(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType master, int index,
        java.lang.Object value) {
        if (value instanceof net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType) {
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType realValue =
                ((net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType) value);

            {
                // Check complex value
                net.gencat.gecat.batch.DocumentsMPE.verification.DadesPosicioTypeVerifier.DadaPosicioTypeVerifier verifier =
                    new net.gencat.gecat.batch.DocumentsMPE.verification.DadesPosicioTypeVerifier.DadaPosicioTypeVerifier();
                verifier.check(new de.fzi.dbs.verification.event.EntryLocator(
                        parentLocator, master, "DadaPosicio", index), handler,
                    realValue);
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.EntryLocator(
                            parentLocator, master, "DadaPosicio", index),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
        check(parentLocator, handler,
            ((net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType) object));
    }

    public void check(javax.xml.bind.ValidationEventHandler handler,
        java.lang.Object object) {
        check(null, handler,
            ((net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType) object));
    }

    public static class DadaPosicioTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
        public void check(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master) {
            if (true) {
                // If left exists
                // No check for primitive values
                checkOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getOrder()));
            }

            // Choice
            // If right exists
            if (null != master.getBlocImputacio()) {
                // Right left
                if (null == master.getBlocImputacio()) {
                    // Optional field - nothing to report
                } else {
                    // Check value
                    checkBlocImputacio(parentLocator, handler, master,
                        master.getBlocImputacio());
                }

                // todo: check left does not exists???
            } else {
                // Right does not exist, left must exist
                if (null == master.getDadesPagadorAlternatiu()) {
                    // Optional field - nothing to report
                } else {
                    // Check value
                    checkDadesPagadorAlternatiu(parentLocator, handler, master,
                        master.getDadesPagadorAlternatiu());
                }
            }

            if (null == master.getTipusRegistre()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "TipusRegistre"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkTipusRegistre(parentLocator, handler, master,
                    master.getTipusRegistre());
            }

            if (null == master.getTextDocument()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "TextDocument"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkTextDocument(parentLocator, handler, master,
                    master.getTextDocument());
            }

            if (null == master.getNExpedient()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "NExpedient"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkNExpedient(parentLocator, handler, master,
                    master.getNExpedient());
            }

            if (null == master.getCreditor()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Creditor"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkCreditor(parentLocator, handler, master,
                    master.getCreditor());
            }

            if (null == master.getTipusBancInterlocutor()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "TipusBancInterlocutor"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkTipusBancInterlocutor(parentLocator, handler, master,
                    master.getTipusBancInterlocutor());
            }

            if (null == master.getIndicadorCME()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "IndicadorCME"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkIndicadorCME(parentLocator, handler, master,
                    master.getIndicadorCME());
            }

            if (null == master.getPosicioPressupostaria()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "PosicioPressupostaria"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkPosicioPressupostaria(parentLocator, handler, master,
                    master.getPosicioPressupostaria());
            }

            if (null == master.getCentreGestor()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "CentreGestor"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkCentreGestor(parentLocator, handler, master,
                    master.getCentreGestor());
            }

            if (null == master.getReferencia()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Referencia"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkReferencia(parentLocator, handler, master,
                    master.getReferencia());
            }

            if (null == master.getCondicioPagament()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "CondicioPagament"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkCondicioPagament(parentLocator, handler, master,
                    master.getCondicioPagament());
            }

            if (null == master.getImport()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Import"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkImport(parentLocator, handler, master, master.getImport());
            }

            if (null == master.getImportImpost()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "ImportImpost"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkImportImpost(parentLocator, handler, master,
                    master.getImportImpost());
            }

            if (null == master.getIndicadorIVA()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "IndicadorIVA"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkIndicadorIVA(parentLocator, handler, master,
                    master.getIndicadorIVA());
            }

            if (null == master.getCalcularImpost()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "CalcularImpost"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkCalcularImpost(parentLocator, handler, master,
                    master.getCalcularImpost());
            }

            if (null == master.getText()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Text"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkText(parentLocator, handler, master, master.getText());
            }

            if (null == master.getFons()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Fons"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkFons(parentLocator, handler, master, master.getFons());
            }

            if (null == master.getViaPagament()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "ViaPagament"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkViaPagament(parentLocator, handler, master,
                    master.getViaPagament());
            }

            if (null == master.getBloqueigPagament()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "BloqueigPagament"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkBloqueigPagament(parentLocator, handler, master,
                    master.getBloqueigPagament());
            }

            if (null == master.getDataBase()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DataBase"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkDataBase(parentLocator, handler, master,
                    master.getDataBase());
            }

            if (null == master.getPagadorAlternatiu()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "PagadorAlternatiu"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkPagadorAlternatiu(parentLocator, handler, master,
                    master.getPagadorAlternatiu());
            }

            if (null == master.getCompteMajor()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "CompteMajor"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkCompteMajor(parentLocator, handler, master,
                    master.getCompteMajor());
            }
        }

        public void checkTipusBancInterlocutor(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 4) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                4);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "TipusBancInterlocutor"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusBancInterlocutor"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkPagadorAlternatiu(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 10) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                10);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "PagadorAlternatiu"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "PagadorAlternatiu"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkIndicadorCME(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 1) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                1);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "IndicadorCME"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "IndicadorCME"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkIndicadorIVA(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 2) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                2);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "IndicadorIVA"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "IndicadorIVA"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "Order"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Order"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkText(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 50) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                50);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "Text"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Text"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkImport(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 13) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                13);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "Import"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Import"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTextDocument(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 25) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                25);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TextDocument"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TextDocument"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkDataBase(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 8) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                8);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "DataBase"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DataBase"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkBloqueigPagament(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 1) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                1);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "BloqueigPagament"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "BloqueigPagament"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkImportImpost(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 13) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                13);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ImportImpost"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ImportImpost"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkBlocImputacio(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            net.gencat.gecat.batch.DocumentsMPE.BlocImputacioType value) {
            if (value instanceof net.gencat.gecat.batch.DocumentsMPE.BlocImputacioType) {
                net.gencat.gecat.batch.DocumentsMPE.BlocImputacioType realValue = ((net.gencat.gecat.batch.DocumentsMPE.BlocImputacioType) value);

                {
                    // Check complex value
                    net.gencat.gecat.batch.DocumentsMPE.verification.BlocImputacioTypeVerifier verifier =
                        new net.gencat.gecat.batch.DocumentsMPE.verification.BlocImputacioTypeVerifier();
                    verifier.check(new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "BlocImputacio"), handler,
                        realValue);
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "BlocImputacio"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkReferencia(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 16) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                16);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "Referencia"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Referencia"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkPosicioPressupostaria(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 24) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                24);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "PosicioPressupostaria"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "PosicioPressupostaria"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCentreGestor(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 16) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                16);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "CentreGestor"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CentreGestor"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCompteMajor(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 10) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                10);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "CompteMajor"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CompteMajor"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkFons(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 10) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                10);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "Fons"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Fons"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkDadesPagadorAlternatiu(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType value) {
            if (value instanceof net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType) {
                net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType realValue =
                    ((net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType) value);

                {
                    // Check complex value
                    net.gencat.gecat.batch.DocumentsMPE.verification.DadesPagadorAlternatiuTypeVerifier verifier =
                        new net.gencat.gecat.batch.DocumentsMPE.verification.DadesPagadorAlternatiuTypeVerifier();
                    verifier.check(new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DadesPagadorAlternatiu"),
                        handler, realValue);
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DadesPagadorAlternatiu"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTipusRegistre(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 1) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                1);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TipusRegistre"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusRegistre"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkNExpedient(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 30) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                30);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "NExpedient"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "NExpedient"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCalcularImpost(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 1) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                1);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "CalcularImpost"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CalcularImpost"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCondicioPagament(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 4) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                4);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "CondicioPagament"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CondicioPagament"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkViaPagament(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 1) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                1);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ViaPagament"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ViaPagament"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCreditor(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 10) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                10);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "Creditor"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Creditor"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void check(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            java.lang.Object object) {
            check(parentLocator, handler,
                ((net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType) object));
        }

        public void check(javax.xml.bind.ValidationEventHandler handler,
            java.lang.Object object) {
            check(null, handler,
                ((net.gencat.gecat.batch.DocumentsMPE.DadesPosicioType.DadaPosicioType) object));
        }
    }
}
