/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPDHelper.verification;

public class DadesPosicioTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType master) {
        if (true) {
            // If left exists
            // No check for primitive values
            checkOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getOrder()));
        }

        if (null == master.getDadaPosicio()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "DadaPosicio"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check count
            if (master.getDadaPosicio().size() < 1) {
                // Report minimum of occurences violated
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DadaPosicio"),
                        new de.fzi.dbs.verification.event.structure.TooFewElementsProblem(
                            master.getDadaPosicio().size(), 1)));
            }

            // Check value
            checkDadaPosicio(parentLocator, handler, master,
                master.getDadaPosicio());
        }
    }

    public void checkDadaPosicio(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType master,
        java.util.List values) {
        for (int index = 0; (index < values.size()); index++) {
            java.lang.Object item = values.get(index);
            checkDadaPosicio(parentLocator, handler, master, index, item);
        }
    }

    public void checkDadaPosicio(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType master,
        int index, java.lang.Object value) {
        if (value instanceof net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType) {
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType realValue =
                ((net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType) value);

            {
                // Check complex value
                net.gencat.gecat.batch.DocumentsOCPDHelper.verification.DadesPosicioTypeVerifier.DadaPosicioTypeVerifier verifier =
                    new net.gencat.gecat.batch.DocumentsOCPDHelper.verification.DadesPosicioTypeVerifier.DadaPosicioTypeVerifier();
                verifier.check(new de.fzi.dbs.verification.event.EntryLocator(
                        parentLocator, master, "DadaPosicio", index), handler,
                    realValue);
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.EntryLocator(
                            parentLocator, master, "DadaPosicio", index),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Order"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Order"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
        check(parentLocator, handler,
            ((net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType) object));
    }

    public void check(javax.xml.bind.ValidationEventHandler handler,
        java.lang.Object object) {
        check(null, handler,
            ((net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType) object));
    }

    public static class DadaPosicioTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
        public void check(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master) {
            if (true) {
                // If left exists
                // No check for primitive values
                checkAssignacioLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getAssignacioLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkAssignacioOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getAssignacioOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkBloqueigPagamentLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getBloqueigPagamentLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkBloqueigPagamentOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getBloqueigPagamentOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkCalcularImpostLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getCalcularImpostLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkCalcularImpostOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getCalcularImpostOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkCentreGestorLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getCentreGestorLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkCentreGestorOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getCentreGestorOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkCompteMajorLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getCompteMajorLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkCompteMajorOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getCompteMajorOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkCondicioPagamentLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getCondicioPagamentLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkCondicioPagamentOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getCondicioPagamentOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkCreditorLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getCreditorLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkCreditorOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getCreditorOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkDadesCreditorCPDLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getDadesCreditorCPDLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkDadesCreditorCPDOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getDadesCreditorCPDOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkDadesPagadorAlternatiuLength(parentLocator, handler,
                    master,
                    new java.lang.Integer(master.getDadesPagadorAlternatiuLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkDadesPagadorAlternatiuOrder(parentLocator, handler,
                    master,
                    new java.lang.Integer(master.getDadesPagadorAlternatiuOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkDataBaseLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getDataBaseLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkDataBaseOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getDataBaseOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkFonsLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getFonsLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkFonsOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getFonsOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkImportFieldType(parentLocator, handler, master,
                    new java.lang.Integer(master.getImportFieldType()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkImportImpostFieldType(parentLocator, handler, master,
                    new java.lang.Integer(master.getImportImpostFieldType()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkImportImpostLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getImportImpostLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkImportImpostOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getImportImpostOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkImportLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getImportLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkImportOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getImportOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkIndicadorIVALength(parentLocator, handler, master,
                    new java.lang.Integer(master.getIndicadorIVALength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkIndicadorIVAOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getIndicadorIVAOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkNExpedientLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getNExpedientLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkNExpedientOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getNExpedientOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkPagadorAlternatiuLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getPagadorAlternatiuLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkPagadorAlternatiuOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getPagadorAlternatiuOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkPosicioLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getPosicioLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkPosicioOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getPosicioOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkPosicioPressupostariaLength(parentLocator, handler,
                    master,
                    new java.lang.Integer(master.getPosicioPressupostariaLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkPosicioPressupostariaOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getPosicioPressupostariaOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkReferenciaLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getReferenciaLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkReferenciaOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getReferenciaOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkRegioLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getRegioLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkRegioOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getRegioOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkReservaFondosLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getReservaFondosLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkReservaFondosOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getReservaFondosOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTextDocumentLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getTextDocumentLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTextDocumentOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getTextDocumentOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTextLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getTextLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTextOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getTextOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTipusBancInterlocutorLength(parentLocator, handler,
                    master,
                    new java.lang.Integer(master.getTipusBancInterlocutorLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTipusBancInterlocutorOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getTipusBancInterlocutorOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTipusRegistreLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getTipusRegistreLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTipusRegistreOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getTipusRegistreOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkViaPagamentLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getViaPagamentLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkViaPagamentOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getViaPagamentOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getOrder()));
            }
        }

        public void checkReservaFondosOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ReservaFondosOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ReservaFondosOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCompteMajorLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "CompteMajorLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CompteMajorLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkNExpedientOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "NExpedientOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "NExpedientOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCentreGestorLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "CentreGestorLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CentreGestorLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "Order"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Order"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkReferenciaLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ReferenciaLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ReferenciaLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkDadesCreditorCPDOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "DadesCreditorCPDOrder"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DadesCreditorCPDOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkImportLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ImportLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ImportLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkReferenciaOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ReferenciaOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ReferenciaOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTextLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TextLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TextLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkPosicioLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "PosicioLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "PosicioLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCreditorOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "CreditorOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CreditorOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkImportImpostFieldType(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "ImportImpostFieldType"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ImportImpostFieldType"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCreditorLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "CreditorLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CreditorLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkDadesPagadorAlternatiuLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "DadesPagadorAlternatiuLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master,
                                "DadesPagadorAlternatiuLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkViaPagamentOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ViaPagamentOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ViaPagamentOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkFonsOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "FonsOrder"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "FonsOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkPosicioOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "PosicioOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "PosicioOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCompteMajorOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "CompteMajorOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CompteMajorOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkAssignacioOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "AssignacioOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "AssignacioOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkDadesCreditorCPDLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "DadesCreditorCPDLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DadesCreditorCPDLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkAssignacioLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "AssignacioLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "AssignacioLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkDataBaseOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "DataBaseOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DataBaseOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkFonsLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "FonsLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "FonsLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkPagadorAlternatiuLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "PagadorAlternatiuLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "PagadorAlternatiuLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTipusRegistreLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TipusRegistreLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusRegistreLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCalcularImpostOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "CalcularImpostOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CalcularImpostOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkImportImpostOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ImportImpostOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ImportImpostOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCalcularImpostLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "CalcularImpostLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CalcularImpostLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkDataBaseLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "DataBaseLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DataBaseLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkViaPagamentLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ViaPagamentLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ViaPagamentLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkImportImpostLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ImportImpostLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ImportImpostLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkImportFieldType(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ImportFieldType"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ImportFieldType"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTextDocumentOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TextDocumentOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TextDocumentOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkIndicadorIVAOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "IndicadorIVAOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "IndicadorIVAOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkPosicioPressupostariaLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "PosicioPressupostariaLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master,
                                "PosicioPressupostariaLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTipusBancInterlocutorOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "TipusBancInterlocutorOrder"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master,
                                "TipusBancInterlocutorOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTextDocumentLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TextDocumentLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TextDocumentLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkImportOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ImportOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ImportOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkRegioOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "RegioOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "RegioOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTextOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TextOrder"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TextOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkPagadorAlternatiuOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "PagadorAlternatiuOrder"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "PagadorAlternatiuOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkPosicioPressupostariaOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "PosicioPressupostariaOrder"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master,
                                "PosicioPressupostariaOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTipusRegistreOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TipusRegistreOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusRegistreOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkRegioLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "RegioLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "RegioLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkDadesPagadorAlternatiuOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "DadesPagadorAlternatiuOrder"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master,
                                "DadesPagadorAlternatiuOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkBloqueigPagamentOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "BloqueigPagamentOrder"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "BloqueigPagamentOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTipusBancInterlocutorLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "TipusBancInterlocutorLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master,
                                "TipusBancInterlocutorLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCondicioPagamentLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "CondicioPagamentLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CondicioPagamentLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkBloqueigPagamentLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "BloqueigPagamentLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "BloqueigPagamentLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCentreGestorOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "CentreGestorOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CentreGestorOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCondicioPagamentOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "CondicioPagamentOrder"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CondicioPagamentOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkNExpedientLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "NExpedientLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "NExpedientLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkIndicadorIVALength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "IndicadorIVALength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "IndicadorIVALength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkReservaFondosLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ReservaFondosLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ReservaFondosLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void check(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            java.lang.Object object) {
            check(parentLocator, handler,
                ((net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType) object));
        }

        public void check(javax.xml.bind.ValidationEventHandler handler,
            java.lang.Object object) {
            check(null, handler,
                ((net.gencat.gecat.batch.DocumentsOCPDHelper.DadesPosicioType.DadaPosicioType) object));
        }
    }
}
