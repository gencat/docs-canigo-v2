/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsO.impl;

public class DadesPagadorAlternatiuTypeImpl implements net.gencat.gecat.batch.DocumentsO.DadesPagadorAlternatiuType,
    com.sun.xml.bind.JAXBObject,
    net.gencat.gecat.batch.DocumentsO.impl.runtime.XMLSerializable,
    net.gencat.gecat.batch.DocumentsO.impl.runtime.ValidatableObject {
    public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsO.impl.JAXBVersion.class);
    private static com.sun.msv.grammar.Grammar schemaFragment;
    protected java.lang.String _ClauBanc;
    protected java.lang.String _PaisBanc;
    protected java.lang.String _Nom;
    protected java.lang.String _CodiPostal;
    protected java.lang.String _Compte;
    protected java.lang.String _TipusRegistre;
    protected java.lang.String _Adreca;
    protected java.lang.String _Pais;
    protected java.lang.String _Poblacio;
    protected java.lang.String _DigitsControl;
    protected java.lang.String _NIF;
    protected net.gencat.gecat.batch.DocumentsO.BlocImputacioType _BlocImputacio;

    private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
        return (net.gencat.gecat.batch.DocumentsO.DadesPagadorAlternatiuType.class);
    }

    public java.lang.String getClauBanc() {
        return _ClauBanc;
    }

    public void setClauBanc(java.lang.String value) {
        _ClauBanc = value;
    }

    public java.lang.String getPaisBanc() {
        return _PaisBanc;
    }

    public void setPaisBanc(java.lang.String value) {
        _PaisBanc = value;
    }

    public java.lang.String getNom() {
        return _Nom;
    }

    public void setNom(java.lang.String value) {
        _Nom = value;
    }

    public java.lang.String getCodiPostal() {
        return _CodiPostal;
    }

    public void setCodiPostal(java.lang.String value) {
        _CodiPostal = value;
    }

    public java.lang.String getCompte() {
        return _Compte;
    }

    public void setCompte(java.lang.String value) {
        _Compte = value;
    }

    public java.lang.String getTipusRegistre() {
        return _TipusRegistre;
    }

    public void setTipusRegistre(java.lang.String value) {
        _TipusRegistre = value;
    }

    public java.lang.String getAdreca() {
        return _Adreca;
    }

    public void setAdreca(java.lang.String value) {
        _Adreca = value;
    }

    public java.lang.String getPais() {
        return _Pais;
    }

    public void setPais(java.lang.String value) {
        _Pais = value;
    }

    public java.lang.String getPoblacio() {
        return _Poblacio;
    }

    public void setPoblacio(java.lang.String value) {
        _Poblacio = value;
    }

    public java.lang.String getDigitsControl() {
        return _DigitsControl;
    }

    public void setDigitsControl(java.lang.String value) {
        _DigitsControl = value;
    }

    public java.lang.String getNIF() {
        return _NIF;
    }

    public void setNIF(java.lang.String value) {
        _NIF = value;
    }

    public net.gencat.gecat.batch.DocumentsO.BlocImputacioType getBlocImputacio() {
        return _BlocImputacio;
    }

    public void setBlocImputacio(
        net.gencat.gecat.batch.DocumentsO.BlocImputacioType value) {
        _BlocImputacio = value;
    }

    public void serializeBody(
        net.gencat.gecat.batch.DocumentsO.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        context.startElement("", "BlocImputacio");
        context.childAsURIs(((com.sun.xml.bind.JAXBObject) _BlocImputacio),
            "BlocImputacio");
        context.endNamespaceDecls();
        context.childAsAttributes(((com.sun.xml.bind.JAXBObject) _BlocImputacio),
            "BlocImputacio");
        context.endAttributes();
        context.childAsBody(((com.sun.xml.bind.JAXBObject) _BlocImputacio),
            "BlocImputacio");
        context.endElement();
        context.startElement("", "TipusRegistre");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _TipusRegistre), "TipusRegistre");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "Nom");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _Nom), "Nom");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "Adreca");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _Adreca), "Adreca");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "Poblacio");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _Poblacio), "Poblacio");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "CodiPostal");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _CodiPostal), "CodiPostal");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "Pais");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _Pais), "Pais");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "ClauBanc");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _ClauBanc), "ClauBanc");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "Compte");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _Compte), "Compte");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "DigitsControl");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _DigitsControl), "DigitsControl");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "PaisBanc");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _PaisBanc), "PaisBanc");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "NIF");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _NIF), "NIF");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
    }

    public void serializeAttributes(
        net.gencat.gecat.batch.DocumentsO.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
    }

    public void serializeURIs(
        net.gencat.gecat.batch.DocumentsO.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
    }

    public java.lang.Class getPrimaryInterface() {
        return (net.gencat.gecat.batch.DocumentsO.DadesPagadorAlternatiuType.class);
    }

    public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
        if (schemaFragment == null) {
            schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                    "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                    "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                    "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                    "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                    "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsr\u0000\'com.sun.msv.gram" +
                    "mar.trex.ElementPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\tnameClasst\u0000\u001fLcom/sun/ms" +
                    "v/grammar/NameClass;xr\u0000\u001ecom.sun.msv.grammar.ElementExp\u0000\u0000\u0000\u0000\u0000\u0000" +
                    "\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aignoreUndeclaredAttributesL\u0000\fcontentModelq\u0000~\u0000\u0002xq\u0000~\u0000\u0003" +
                    "pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0010pp\u0000sr\u0000\u001dcom.sun.msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000" +
                    "\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsr\u0000 com.sun.msv.grammar.OneOrMoreExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000x" +
                    "r\u0000\u001ccom.sun.msv.grammar.UnaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0003expq\u0000~\u0000\u0002xq\u0000~\u0000\u0003s" +
                    "r\u0000\u0011java.lang.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000 com.sun.msv.g" +
                    "rammar.AttributeExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClassq\u0000~\u0000\u0011xq" +
                    "\u0000~\u0000\u0003q\u0000~\u0000\u001cpsr\u00002com.sun.msv.grammar.Expression$AnyStringExpres" +
                    "sion\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\u001b\u0001q\u0000~\u0000 sr\u0000 com.sun.msv.grammar.Any" +
                    "NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000" +
                    "\u0001\u0002\u0000\u0000xpsr\u00000com.sun.msv.grammar.Expression$EpsilonExpression\u0000\u0000" +
                    "\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003q\u0000~\u0000!q\u0000~\u0000&sr\u0000#com.sun.msv.grammar.SimpleNameC" +
                    "lass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlocalNamet\u0000\u0012Ljava/lang/String;L\u0000\fnamespace" +
                    "URIq\u0000~\u0000(xq\u0000~\u0000#t\u00003net.gencat.gecat.batch.DocumentsO.BlocImput" +
                    "acioTypet\u0000+http://java.sun.com/jaxb/xjc/dummy-elementssq\u0000~\u0000\u0016" +
                    "ppsq\u0000~\u0000\u001dq\u0000~\u0000\u001cpsr\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002d" +
                    "tt\u0000\u001fLorg/relaxng/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dL" +
                    "com/sun/msv/util/StringPair;xq\u0000~\u0000\u0003ppsr\u0000\"com.sun.msv.datatype" +
                    ".xsd.QnameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.xsd.Builti" +
                    "nAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datatype.xsd.ConcreteT" +
                    "ype\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype.xsd.XSDatatypeImpl\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUriq\u0000~\u0000(L\u0000\btypeNameq\u0000~\u0000(L\u0000\nwhiteSpacet\u0000." +
                    "Lcom/sun/msv/datatype/xsd/WhiteSpaceProcessor;xpt\u0000 http://ww" +
                    "w.w3.org/2001/XMLSchemat\u0000\u0005QNamesr\u00005com.sun.msv.datatype.xsd." +
                    "WhiteSpaceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datat" +
                    "ype.xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000com.sun.msv.gram" +
                    "mar.Expression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.s" +
                    "un.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000(L\u0000\fnamespa" +
                    "ceURIq\u0000~\u0000(xpq\u0000~\u00009q\u0000~\u00008sq\u0000~\u0000\'t\u0000\u0004typet\u0000)http://www.w3.org/2001" +
                    "/XMLSchema-instanceq\u0000~\u0000&sq\u0000~\u0000\'t\u0000\rBlocImputaciot\u0000\u0000sq\u0000~\u0000\u0010pp\u0000sq" +
                    "\u0000~\u0000\u0000ppsq\u0000~\u0000.ppsr\u0000)com.sun.msv.datatype.xsd.EnumerationFacet\u0000" +
                    "\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0006valuest\u0000\u000fLjava/util/Set;xr\u00009com.sun.msv.datatyp" +
                    "e.xsd.DataTypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*com.sun" +
                    ".msv.datatype.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFacetFixe" +
                    "dZ\u0000\u0012needValueCheckFlagL\u0000\bbaseTypet\u0000)Lcom/sun/msv/datatype/xs" +
                    "d/XSDatatypeImpl;L\u0000\fconcreteTypet\u0000\'Lcom/sun/msv/datatype/xsd" +
                    "/ConcreteType;L\u0000\tfacetNameq\u0000~\u0000(xq\u0000~\u00005q\u0000~\u0000Fpsr\u00005com.sun.msv.d" +
                    "atatype.xsd.WhiteSpaceProcessor$Preserve\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000;\u0000\u0000s" +
                    "r\u0000#com.sun.msv.datatype.xsd.StringType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001Z\u0000\risAlways" +
                    "Validxq\u0000~\u00003q\u0000~\u00008t\u0000\u0006stringq\u0000~\u0000R\u0001q\u0000~\u0000Tt\u0000\u000benumerationsr\u0000\u0011java.u" +
                    "til.HashSet\u00baD\u0085\u0095\u0096\u00b8\u00b74\u0003\u0000\u0000xpw\f\u0000\u0000\u0000\u0010?@\u0000\u0000\u0000\u0000\u0000\u0001t\u0000\u00013xq\u0000~\u0000>sq\u0000~\u0000?t\u0000\u000estr" +
                    "ing-derivedq\u0000~\u0000Fsq\u0000~\u0000\u0016ppsq\u0000~\u0000\u001dq\u0000~\u0000\u001cpq\u0000~\u00001q\u0000~\u0000Aq\u0000~\u0000&sq\u0000~\u0000\'t\u0000\r" +
                    "TipusRegistreq\u0000~\u0000Fsq\u0000~\u0000\u0010pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000.ppsr\u0000\'com.sun.msv.d" +
                    "atatype.xsd.MaxLengthFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\tmaxLengthxq\u0000~\u0000Lq\u0000~\u0000F" +
                    "pq\u0000~\u0000R\u0000\u0000q\u0000~\u0000Tq\u0000~\u0000Tt\u0000\tmaxLength\u0000\u0000\u0000#q\u0000~\u0000>sq\u0000~\u0000?t\u0000\u000estring-deriv" +
                    "edq\u0000~\u0000Fsq\u0000~\u0000\u0016ppsq\u0000~\u0000\u001dq\u0000~\u0000\u001cpq\u0000~\u00001q\u0000~\u0000Aq\u0000~\u0000&sq\u0000~\u0000\'t\u0000\u0003Nomq\u0000~\u0000Fs" +
                    "q\u0000~\u0000\u0010pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000.ppsq\u0000~\u0000cq\u0000~\u0000Fpq\u0000~\u0000R\u0000\u0000q\u0000~\u0000Tq\u0000~\u0000Tq\u0000~\u0000e\u0000\u0000" +
                    "\u0000#q\u0000~\u0000>sq\u0000~\u0000?t\u0000\u000estring-derivedq\u0000~\u0000Fsq\u0000~\u0000\u0016ppsq\u0000~\u0000\u001dq\u0000~\u0000\u001cpq\u0000~\u00001" +
                    "q\u0000~\u0000Aq\u0000~\u0000&sq\u0000~\u0000\'t\u0000\u0006Adrecaq\u0000~\u0000Fsq\u0000~\u0000\u0010pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000.ppsq\u0000~\u0000" +
                    "cq\u0000~\u0000Fpq\u0000~\u0000R\u0000\u0000q\u0000~\u0000Tq\u0000~\u0000Tq\u0000~\u0000e\u0000\u0000\u0000#q\u0000~\u0000>sq\u0000~\u0000?t\u0000\u000estring-derive" +
                    "dq\u0000~\u0000Fsq\u0000~\u0000\u0016ppsq\u0000~\u0000\u001dq\u0000~\u0000\u001cpq\u0000~\u00001q\u0000~\u0000Aq\u0000~\u0000&sq\u0000~\u0000\'t\u0000\bPoblacioq\u0000" +
                    "~\u0000Fsq\u0000~\u0000\u0010pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000.ppsq\u0000~\u0000cq\u0000~\u0000Fpq\u0000~\u0000R\u0000\u0000q\u0000~\u0000Tq\u0000~\u0000Tq\u0000~" +
                    "\u0000e\u0000\u0000\u0000\nq\u0000~\u0000>sq\u0000~\u0000?t\u0000\u000estring-derivedq\u0000~\u0000Fsq\u0000~\u0000\u0016ppsq\u0000~\u0000\u001dq\u0000~\u0000\u001cpq" +
                    "\u0000~\u00001q\u0000~\u0000Aq\u0000~\u0000&sq\u0000~\u0000\'t\u0000\nCodiPostalq\u0000~\u0000Fsq\u0000~\u0000\u0010pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000" +
                    ".ppsq\u0000~\u0000cq\u0000~\u0000Fpq\u0000~\u0000R\u0000\u0000q\u0000~\u0000Tq\u0000~\u0000Tq\u0000~\u0000e\u0000\u0000\u0000\u0003q\u0000~\u0000>sq\u0000~\u0000?t\u0000\u000estrin" +
                    "g-derivedq\u0000~\u0000Fsq\u0000~\u0000\u0016ppsq\u0000~\u0000\u001dq\u0000~\u0000\u001cpq\u0000~\u00001q\u0000~\u0000Aq\u0000~\u0000&sq\u0000~\u0000\'t\u0000\u0004Pa" +
                    "isq\u0000~\u0000Fsq\u0000~\u0000\u0010pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000.ppsq\u0000~\u0000cq\u0000~\u0000Fpq\u0000~\u0000R\u0000\u0000q\u0000~\u0000Tq\u0000~\u0000" +
                    "Tq\u0000~\u0000e\u0000\u0000\u0000\u000fq\u0000~\u0000>sq\u0000~\u0000?t\u0000\u000estring-derivedq\u0000~\u0000Fsq\u0000~\u0000\u0016ppsq\u0000~\u0000\u001dq\u0000~" +
                    "\u0000\u001cpq\u0000~\u00001q\u0000~\u0000Aq\u0000~\u0000&sq\u0000~\u0000\'t\u0000\bClauBancq\u0000~\u0000Fsq\u0000~\u0000\u0010pp\u0000sq\u0000~\u0000\u0000ppsq\u0000" +
                    "~\u0000.ppsq\u0000~\u0000cq\u0000~\u0000Fpq\u0000~\u0000R\u0000\u0000q\u0000~\u0000Tq\u0000~\u0000Tq\u0000~\u0000e\u0000\u0000\u0000\u0012q\u0000~\u0000>sq\u0000~\u0000?t\u0000\u000estr" +
                    "ing-derivedq\u0000~\u0000Fsq\u0000~\u0000\u0016ppsq\u0000~\u0000\u001dq\u0000~\u0000\u001cpq\u0000~\u00001q\u0000~\u0000Aq\u0000~\u0000&sq\u0000~\u0000\'t\u0000\u0006" +
                    "Compteq\u0000~\u0000Fsq\u0000~\u0000\u0010pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000.ppsq\u0000~\u0000cq\u0000~\u0000Fpq\u0000~\u0000R\u0000\u0000q\u0000~\u0000T" +
                    "q\u0000~\u0000Tq\u0000~\u0000e\u0000\u0000\u0000\u0002q\u0000~\u0000>sq\u0000~\u0000?t\u0000\u000estring-derivedq\u0000~\u0000Fsq\u0000~\u0000\u0016ppsq\u0000~\u0000" +
                    "\u001dq\u0000~\u0000\u001cpq\u0000~\u00001q\u0000~\u0000Aq\u0000~\u0000&sq\u0000~\u0000\'t\u0000\rDigitsControlq\u0000~\u0000Fsq\u0000~\u0000\u0010pp\u0000sq" +
                    "\u0000~\u0000\u0000ppsq\u0000~\u0000.ppsq\u0000~\u0000cq\u0000~\u0000Fpq\u0000~\u0000R\u0000\u0000q\u0000~\u0000Tq\u0000~\u0000Tq\u0000~\u0000e\u0000\u0000\u0000\u0003q\u0000~\u0000>sq\u0000" +
                    "~\u0000?t\u0000\u000estring-derivedq\u0000~\u0000Fsq\u0000~\u0000\u0016ppsq\u0000~\u0000\u001dq\u0000~\u0000\u001cpq\u0000~\u00001q\u0000~\u0000Aq\u0000~\u0000&" +
                    "sq\u0000~\u0000\'t\u0000\bPaisBancq\u0000~\u0000Fsq\u0000~\u0000\u0010pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000.ppsq\u0000~\u0000cq\u0000~\u0000Fpq" +
                    "\u0000~\u0000R\u0000\u0000q\u0000~\u0000Tq\u0000~\u0000Tq\u0000~\u0000e\u0000\u0000\u0000\u0010q\u0000~\u0000>sq\u0000~\u0000?t\u0000\u000estring-derivedq\u0000~\u0000Fsq" +
                    "\u0000~\u0000\u0016ppsq\u0000~\u0000\u001dq\u0000~\u0000\u001cpq\u0000~\u00001q\u0000~\u0000Aq\u0000~\u0000&sq\u0000~\u0000\'t\u0000\u0003NIFq\u0000~\u0000Fsr\u0000\"com.su" +
                    "n.msv.grammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/su" +
                    "n/msv/grammar/ExpressionPool$ClosedHash;xpsr\u0000-com.sun.msv.gr" +
                    "ammar.ExpressionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamV" +
                    "ersionL\u0000\u0006parentt\u0000$Lcom/sun/msv/grammar/ExpressionPool;xp\u0000\u0000\u0000%" +
                    "\u0001pq\u0000~\u0000\u000eq\u0000~\u0000\tq\u0000~\u0000\fq\u0000~\u0000\u00bdq\u0000~\u0000\u001aq\u0000~\u0000\u0006q\u0000~\u0000\nq\u0000~\u0000\u0005q\u0000~\u0000\rq\u0000~\u0000\u0081q\u0000~\u0000\bq\u0000~" +
                    "\u0000\u008bq\u0000~\u0000\u0014q\u0000~\u0000Hq\u0000~\u0000\u000bq\u0000~\u0000\u0095q\u0000~\u0000\u00a9q\u0000~\u0000\u009fq\u0000~\u0000\u0007q\u0000~\u0000wq\u0000~\u0000aq\u0000~\u0000\u000fq\u0000~\u0000\u00b3q\u0000~" +
                    "\u0000\u0017q\u0000~\u0000mq\u0000~\u0000,q\u0000~\u0000\\q\u0000~\u0000hq\u0000~\u0000rq\u0000~\u0000|q\u0000~\u0000\u0086q\u0000~\u0000\u0090q\u0000~\u0000\u009aq\u0000~\u0000\u00a4q\u0000~\u0000\u00aeq\u0000~" +
                    "\u0000\u00b8q\u0000~\u0000\u00c2x"));
        }

        return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
    }
}
