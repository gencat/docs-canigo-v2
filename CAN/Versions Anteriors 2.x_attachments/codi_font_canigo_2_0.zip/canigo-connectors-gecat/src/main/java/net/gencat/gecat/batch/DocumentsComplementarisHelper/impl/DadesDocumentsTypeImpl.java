/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsComplementarisHelper.impl;

public class DadesDocumentsTypeImpl implements net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType,
    com.sun.xml.bind.JAXBObject,
    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.XMLSerializable,
    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.ValidatableObject {
    public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.JAXBVersion.class);
    private static com.sun.msv.grammar.Grammar schemaFragment;
    protected boolean has_Order;
    protected int _Order;
    protected com.sun.xml.bind.util.ListImpl _DadaDocument;

    private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
        return (net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.class);
    }

    public int getOrder() {
        if (!has_Order) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "1"));
        } else {
            return _Order;
        }
    }

    public void setOrder(int value) {
        _Order = value;
        has_Order = true;
    }

    protected com.sun.xml.bind.util.ListImpl _getDadaDocument() {
        if (_DadaDocument == null) {
            _DadaDocument = new com.sun.xml.bind.util.ListImpl(new java.util.ArrayList());
        }

        return _DadaDocument;
    }

    public java.util.List getDadaDocument() {
        return _getDadaDocument();
    }

    public void serializeBody(
        net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx2 = 0;
        final int len2 = ((_DadaDocument == null) ? 0 : _DadaDocument.size());

        while (idx2 != len2) {
            context.startElement("", "DadaDocument");

            int idx_0 = idx2;
            context.childAsURIs(((com.sun.xml.bind.JAXBObject) _DadaDocument.get(
                    idx_0++)), "DadaDocument");
            context.endNamespaceDecls();

            int idx_1 = idx2;
            context.childAsAttributes(((com.sun.xml.bind.JAXBObject) _DadaDocument.get(
                    idx_1++)), "DadaDocument");
            context.endAttributes();
            context.childAsBody(((com.sun.xml.bind.JAXBObject) _DadaDocument.get(
                    idx2++)), "DadaDocument");
            context.endElement();
        }
    }

    public void serializeAttributes(
        net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx2 = 0;
        final int len2 = ((_DadaDocument == null) ? 0 : _DadaDocument.size());

        if (has_Order) {
            context.startAttribute("", "order");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _Order)), "Order");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        while (idx2 != len2) {
            idx2 += 1;
        }
    }

    public void serializeURIs(
        net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx2 = 0;
        final int len2 = ((_DadaDocument == null) ? 0 : _DadaDocument.size());

        while (idx2 != len2) {
            idx2 += 1;
        }
    }

    public java.lang.Class getPrimaryInterface() {
        return (net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.class);
    }

    public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
        if (schemaFragment == null) {
            schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                    "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                    "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                    "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                    "expandedExpq\u0000~\u0000\u0002xpppsr\u0000 com.sun.msv.grammar.OneOrMoreExp\u0000\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001ccom.sun.msv.grammar.UnaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0003expq\u0000~\u0000" +
                    "\u0002xq\u0000~\u0000\u0003ppsr\u0000\'com.sun.msv.grammar.trex.ElementPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0001L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/NameClass;xr\u0000\u001ecom.sun" +
                    ".msv.grammar.ElementExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aignoreUndeclaredAttribu" +
                    "tesL\u0000\fcontentModelq\u0000~\u0000\u0002xq\u0000~\u0000\u0003pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\tpp\u0000sr\u0000\u001dcom.sun" +
                    ".msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsq\u0000~\u0000\u0006sr\u0000\u0011java.lang" +
                    ".Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000 com.sun.msv.grammar.Attri" +
                    "buteExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClassq\u0000~\u0000\nxq\u0000~\u0000\u0003q\u0000~\u0000\u0013psr" +
                    "\u00002com.sun.msv.grammar.Expression$AnyStringExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\u0012\u0001q\u0000~\u0000\u0017sr\u0000 com.sun.msv.grammar.AnyNameClass\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000co" +
                    "m.sun.msv.grammar.Expression$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000" +
                    "~\u0000\u0003q\u0000~\u0000\u0018q\u0000~\u0000\u001dsr\u0000#com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0002L\u0000\tlocalNamet\u0000\u0012Ljava/lang/String;L\u0000\fnamespaceURIq\u0000~\u0000\u001fxq\u0000~" +
                    "\u0000\u001at\u0000Xnet.gencat.gecat.batch.DocumentsComplementarisHelper.Da" +
                    "desDocumentsType.DadaDocumentTypet\u0000+http://java.sun.com/jaxb" +
                    "/xjc/dummy-elementssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0014q\u0000~\u0000\u0013psr\u0000\u001bcom.sun.msv.gramm" +
                    "ar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatype/Datatype;" +
                    "L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util/StringPair;xq\u0000~\u0000\u0003p" +
                    "psr\u0000\"com.sun.msv.datatype.xsd.QnameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000*com.su" +
                    "n.msv.datatype.xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.m" +
                    "sv.datatype.xsd.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datat" +
                    "ype.xsd.XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUriq\u0000~\u0000\u001fL\u0000\btype" +
                    "Nameq\u0000~\u0000\u001fL\u0000\nwhiteSpacet\u0000.Lcom/sun/msv/datatype/xsd/WhiteSpac" +
                    "eProcessor;xpt\u0000 http://www.w3.org/2001/XMLSchemat\u0000\u0005QNamesr\u00005" +
                    "com.sun.msv.datatype.xsd.WhiteSpaceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000" +
                    "\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datatype.xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0000xpsr\u00000com.sun.msv.grammar.Expression$NullSetExpression\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000" +
                    "\tlocalNameq\u0000~\u0000\u001fL\u0000\fnamespaceURIq\u0000~\u0000\u001fxpq\u0000~\u00000q\u0000~\u0000/sq\u0000~\u0000\u001et\u0000\u0004type" +
                    "t\u0000)http://www.w3.org/2001/XMLSchema-instanceq\u0000~\u0000\u001dsq\u0000~\u0000\u001et\u0000\fDa" +
                    "daDocumentt\u0000\u0000sq\u0000~\u0000\u000fppsq\u0000~\u0000\u0014q\u0000~\u0000\u0013psq\u0000~\u0000%ppsr\u0000 com.sun.msv.dat" +
                    "atype.xsd.IntType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000+com.sun.msv.datatype.xsd.Int" +
                    "egerDerivedType\u0099\u00f1]\u0090&6k\u00be\u0002\u0000\u0001L\u0000\nbaseFacetst\u0000)Lcom/sun/msv/datat" +
                    "ype/xsd/XSDatatypeImpl;xq\u0000~\u0000*q\u0000~\u0000/t\u0000\u0003intq\u0000~\u00003sr\u0000*com.sun.msv" +
                    ".datatype.xsd.MaxInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.da" +
                    "tatype.xsd.RangeFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\nlimitValuet\u0000\u0012Ljava/lang/O" +
                    "bject;xr\u00009com.sun.msv.datatype.xsd.DataTypeWithValueConstrai" +
                    "ntFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.xsd.DataTypeWithF" +
                    "acet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFacetFixedZ\u0000\u0012needValueCheckFlagL\u0000\bbaseTy" +
                    "peq\u0000~\u0000CL\u0000\fconcreteTypet\u0000\'Lcom/sun/msv/datatype/xsd/ConcreteT" +
                    "ype;L\u0000\tfacetNameq\u0000~\u0000\u001fxq\u0000~\u0000,ppq\u0000~\u00003\u0000\u0001sr\u0000*com.sun.msv.datatype" +
                    ".xsd.MinInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Gppq\u0000~\u00003\u0000\u0000sr\u0000!com.sun." +
                    "msv.datatype.xsd.LongType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Bq\u0000~\u0000/t\u0000\u0004longq\u0000~\u00003s" +
                    "q\u0000~\u0000Fppq\u0000~\u00003\u0000\u0001sq\u0000~\u0000Mppq\u0000~\u00003\u0000\u0000sr\u0000$com.sun.msv.datatype.xsd.In" +
                    "tegerType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Bq\u0000~\u0000/t\u0000\u0007integerq\u0000~\u00003sr\u0000,com.sun.ms" +
                    "v.datatype.xsd.FractionDigitsFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scalexr\u0000;com" +
                    ".sun.msv.datatype.xsd.DataTypeWithLexicalConstraintFacetT\u0090\u001c>" +
                    "\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000Jppq\u0000~\u00003\u0001\u0000sr\u0000#com.sun.msv.datatype.xsd.NumberTyp" +
                    "e\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000*q\u0000~\u0000/t\u0000\u0007decimalq\u0000~\u00003q\u0000~\u0000[t\u0000\u000efractionDigits" +
                    "\u0000\u0000\u0000\u0000q\u0000~\u0000Ut\u0000\fminInclusivesr\u0000\u000ejava.lang.Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valu" +
                    "exr\u0000\u0010java.lang.Number\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u0000Ut\u0000\fmaxInclusi" +
                    "vesq\u0000~\u0000_\u007f\u00ff\u00ff\u00ff\u00ff\u00ff\u00ff\u00ffq\u0000~\u0000Pq\u0000~\u0000^sr\u0000\u0011java.lang.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000" +
                    "\u0005valuexq\u0000~\u0000`\u0080\u0000\u0000\u0000q\u0000~\u0000Pq\u0000~\u0000bsq\u0000~\u0000d\u007f\u00ff\u00ff\u00ffq\u0000~\u00005sq\u0000~\u00006q\u0000~\u0000Eq\u0000~\u0000/sq\u0000" +
                    "~\u0000\u001et\u0000\u0005orderq\u0000~\u0000=q\u0000~\u0000\u001dsr\u0000\"com.sun.msv.grammar.ExpressionPool\u0000" +
                    "\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/sun/msv/grammar/ExpressionPool$" +
                    "ClosedHash;xpsr\u0000-com.sun.msv.grammar.ExpressionPool$ClosedHa" +
                    "sh\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamVersionL\u0000\u0006parentt\u0000$Lcom/sun/ms" +
                    "v/grammar/ExpressionPool;xp\u0000\u0000\u0000\u0007\u0001pq\u0000~\u0000\u0011q\u0000~\u0000\u0005q\u0000~\u0000\rq\u0000~\u0000\bq\u0000~\u0000>q\u0000" +
                    "~\u0000#q\u0000~\u0000\u0010x"));
        }

        return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
    }

    public static class DadaDocumentTypeImpl implements net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType,
        com.sun.xml.bind.JAXBObject,
        net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.XMLSerializable,
        net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.ValidatableObject {
        public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.JAXBVersion.class);
        private static com.sun.msv.grammar.Grammar schemaFragment;
        protected boolean has_ClasseDocumentLength;
        protected int _ClasseDocumentLength;
        protected boolean has_DataDocumentLength;
        protected int _DataDocumentLength;
        protected boolean has_ImportFieldType;
        protected int _ImportFieldType;
        protected boolean has_Order;
        protected int _Order;
        protected boolean has_ImportLength;
        protected int _ImportLength;
        protected boolean has_TextLength;
        protected int _TextLength;
        protected boolean has_PosicioLength;
        protected int _PosicioLength;
        protected boolean has_ImportOrder;
        protected int _ImportOrder;
        protected boolean has_TextOrder;
        protected int _TextOrder;
        protected boolean has_PosicioOrder;
        protected int _PosicioOrder;
        protected boolean has_SocietatOrder;
        protected int _SocietatOrder;
        protected boolean has_DataComptOrder;
        protected int _DataComptOrder;
        protected boolean has_NDocumentCrearLength;
        protected int _NDocumentCrearLength;
        protected boolean has_TipusOperacioOrder;
        protected int _TipusOperacioOrder;
        protected boolean has_TipusRegistreOrder;
        protected int _TipusRegistreOrder;
        protected boolean has_DataDocumentOrder;
        protected int _DataDocumentOrder;
        protected boolean has_NDocumentCrearOrder;
        protected int _NDocumentCrearOrder;
        protected boolean has_NDocumentModificarOrder;
        protected int _NDocumentModificarOrder;
        protected boolean has_TipusOperacioLength;
        protected int _TipusOperacioLength;
        protected boolean has_DataComptLength;
        protected int _DataComptLength;
        protected boolean has_TipusRegistreLength;
        protected int _TipusRegistreLength;
        protected boolean has_TransaccioOrder;
        protected int _TransaccioOrder;
        protected boolean has_TransaccioLength;
        protected int _TransaccioLength;
        protected boolean has_NDocumentModificarLength;
        protected int _NDocumentModificarLength;
        protected boolean has_ClasseDocumentOrder;
        protected int _ClasseDocumentOrder;
        protected boolean has_SocietatLength;
        protected int _SocietatLength;

        private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
            return (net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType.class);
        }

        public int getClasseDocumentLength() {
            if (!has_ClasseDocumentLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "2"));
            } else {
                return _ClasseDocumentLength;
            }
        }

        public void setClasseDocumentLength(int value) {
            _ClasseDocumentLength = value;
            has_ClasseDocumentLength = true;
        }

        public int getDataDocumentLength() {
            if (!has_DataDocumentLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "8"));
            } else {
                return _DataDocumentLength;
            }
        }

        public void setDataDocumentLength(int value) {
            _DataDocumentLength = value;
            has_DataDocumentLength = true;
        }

        public int getImportFieldType() {
            if (!has_ImportFieldType) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "1"));
            } else {
                return _ImportFieldType;
            }
        }

        public void setImportFieldType(int value) {
            _ImportFieldType = value;
            has_ImportFieldType = true;
        }

        public int getOrder() {
            return _Order;
        }

        public void setOrder(int value) {
            _Order = value;
            has_Order = true;
        }

        public int getImportLength() {
            if (!has_ImportLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "9"));
            } else {
                return _ImportLength;
            }
        }

        public void setImportLength(int value) {
            _ImportLength = value;
            has_ImportLength = true;
        }

        public int getTextLength() {
            if (!has_TextLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "50"));
            } else {
                return _TextLength;
            }
        }

        public void setTextLength(int value) {
            _TextLength = value;
            has_TextLength = true;
        }

        public int getPosicioLength() {
            if (!has_PosicioLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "5"));
            } else {
                return _PosicioLength;
            }
        }

        public void setPosicioLength(int value) {
            _PosicioLength = value;
            has_PosicioLength = true;
        }

        public int getImportOrder() {
            if (!has_ImportOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "11"));
            } else {
                return _ImportOrder;
            }
        }

        public void setImportOrder(int value) {
            _ImportOrder = value;
            has_ImportOrder = true;
        }

        public int getTextOrder() {
            if (!has_TextOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "12"));
            } else {
                return _TextOrder;
            }
        }

        public void setTextOrder(int value) {
            _TextOrder = value;
            has_TextOrder = true;
        }

        public int getPosicioOrder() {
            if (!has_PosicioOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "9"));
            } else {
                return _PosicioOrder;
            }
        }

        public void setPosicioOrder(int value) {
            _PosicioOrder = value;
            has_PosicioOrder = true;
        }

        public int getSocietatOrder() {
            if (!has_SocietatOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "4"));
            } else {
                return _SocietatOrder;
            }
        }

        public void setSocietatOrder(int value) {
            _SocietatOrder = value;
            has_SocietatOrder = true;
        }

        public int getDataComptOrder() {
            if (!has_DataComptOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "6"));
            } else {
                return _DataComptOrder;
            }
        }

        public void setDataComptOrder(int value) {
            _DataComptOrder = value;
            has_DataComptOrder = true;
        }

        public int getNDocumentCrearLength() {
            if (!has_NDocumentCrearLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "10"));
            } else {
                return _NDocumentCrearLength;
            }
        }

        public void setNDocumentCrearLength(int value) {
            _NDocumentCrearLength = value;
            has_NDocumentCrearLength = true;
        }

        public int getTipusOperacioOrder() {
            if (!has_TipusOperacioOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "3"));
            } else {
                return _TipusOperacioOrder;
            }
        }

        public void setTipusOperacioOrder(int value) {
            _TipusOperacioOrder = value;
            has_TipusOperacioOrder = true;
        }

        public int getTipusRegistreOrder() {
            if (!has_TipusRegistreOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "1"));
            } else {
                return _TipusRegistreOrder;
            }
        }

        public void setTipusRegistreOrder(int value) {
            _TipusRegistreOrder = value;
            has_TipusRegistreOrder = true;
        }

        public int getDataDocumentOrder() {
            if (!has_DataDocumentOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "5"));
            } else {
                return _DataDocumentOrder;
            }
        }

        public void setDataDocumentOrder(int value) {
            _DataDocumentOrder = value;
            has_DataDocumentOrder = true;
        }

        public int getNDocumentCrearOrder() {
            if (!has_NDocumentCrearOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "10"));
            } else {
                return _NDocumentCrearOrder;
            }
        }

        public void setNDocumentCrearOrder(int value) {
            _NDocumentCrearOrder = value;
            has_NDocumentCrearOrder = true;
        }

        public int getNDocumentModificarOrder() {
            if (!has_NDocumentModificarOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "8"));
            } else {
                return _NDocumentModificarOrder;
            }
        }

        public void setNDocumentModificarOrder(int value) {
            _NDocumentModificarOrder = value;
            has_NDocumentModificarOrder = true;
        }

        public int getTipusOperacioLength() {
            if (!has_TipusOperacioLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "1"));
            } else {
                return _TipusOperacioLength;
            }
        }

        public void setTipusOperacioLength(int value) {
            _TipusOperacioLength = value;
            has_TipusOperacioLength = true;
        }

        public int getDataComptLength() {
            if (!has_DataComptLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "8"));
            } else {
                return _DataComptLength;
            }
        }

        public void setDataComptLength(int value) {
            _DataComptLength = value;
            has_DataComptLength = true;
        }

        public int getTipusRegistreLength() {
            if (!has_TipusRegistreLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "1"));
            } else {
                return _TipusRegistreLength;
            }
        }

        public void setTipusRegistreLength(int value) {
            _TipusRegistreLength = value;
            has_TipusRegistreLength = true;
        }

        public int getTransaccioOrder() {
            if (!has_TransaccioOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "2"));
            } else {
                return _TransaccioOrder;
            }
        }

        public void setTransaccioOrder(int value) {
            _TransaccioOrder = value;
            has_TransaccioOrder = true;
        }

        public int getTransaccioLength() {
            if (!has_TransaccioLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "20"));
            } else {
                return _TransaccioLength;
            }
        }

        public void setTransaccioLength(int value) {
            _TransaccioLength = value;
            has_TransaccioLength = true;
        }

        public int getNDocumentModificarLength() {
            if (!has_NDocumentModificarLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "10"));
            } else {
                return _NDocumentModificarLength;
            }
        }

        public void setNDocumentModificarLength(int value) {
            _NDocumentModificarLength = value;
            has_NDocumentModificarLength = true;
        }

        public int getClasseDocumentOrder() {
            if (!has_ClasseDocumentOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "7"));
            } else {
                return _ClasseDocumentOrder;
            }
        }

        public void setClasseDocumentOrder(int value) {
            _ClasseDocumentOrder = value;
            has_ClasseDocumentOrder = true;
        }

        public int getSocietatLength() {
            if (!has_SocietatLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "4"));
            } else {
                return _SocietatLength;
            }
        }

        public void setSocietatLength(int value) {
            _SocietatLength = value;
            has_SocietatLength = true;
        }

        public void serializeBody(
            net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
        }

        public void serializeAttributes(
            net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
            if (has_ClasseDocumentLength) {
                context.startAttribute("", "ClasseDocumentLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ClasseDocumentLength)),
                        "ClasseDocumentLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ClasseDocumentOrder) {
                context.startAttribute("", "ClasseDocumentOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ClasseDocumentOrder)), "ClasseDocumentOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_DataComptLength) {
                context.startAttribute("", "DataComptLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _DataComptLength)), "DataComptLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_DataComptOrder) {
                context.startAttribute("", "DataComptOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _DataComptOrder)), "DataComptOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_DataDocumentLength) {
                context.startAttribute("", "DataDocumentLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _DataDocumentLength)), "DataDocumentLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_DataDocumentOrder) {
                context.startAttribute("", "DataDocumentOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _DataDocumentOrder)), "DataDocumentOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ImportFieldType) {
                context.startAttribute("", "ImportFieldType");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ImportFieldType)), "ImportFieldType");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ImportLength) {
                context.startAttribute("", "ImportLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ImportLength)), "ImportLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ImportOrder) {
                context.startAttribute("", "ImportOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ImportOrder)), "ImportOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_NDocumentCrearLength) {
                context.startAttribute("", "NDocumentCrearLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _NDocumentCrearLength)),
                        "NDocumentCrearLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_NDocumentCrearOrder) {
                context.startAttribute("", "NDocumentCrearOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _NDocumentCrearOrder)), "NDocumentCrearOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_NDocumentModificarLength) {
                context.startAttribute("", "NDocumentModificarLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _NDocumentModificarLength)),
                        "NDocumentModificarLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_NDocumentModificarOrder) {
                context.startAttribute("", "NDocumentModificarOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _NDocumentModificarOrder)),
                        "NDocumentModificarOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_PosicioLength) {
                context.startAttribute("", "PosicioLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _PosicioLength)), "PosicioLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_PosicioOrder) {
                context.startAttribute("", "PosicioOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _PosicioOrder)), "PosicioOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_SocietatLength) {
                context.startAttribute("", "SocietatLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _SocietatLength)), "SocietatLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_SocietatOrder) {
                context.startAttribute("", "SocietatOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _SocietatOrder)), "SocietatOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TextLength) {
                context.startAttribute("", "TextLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TextLength)), "TextLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TextOrder) {
                context.startAttribute("", "TextOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TextOrder)), "TextOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TipusOperacioLength) {
                context.startAttribute("", "TipusOperacioLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TipusOperacioLength)), "TipusOperacioLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TipusOperacioOrder) {
                context.startAttribute("", "TipusOperacioOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TipusOperacioOrder)), "TipusOperacioOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TipusRegistreLength) {
                context.startAttribute("", "TipusRegistreLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TipusRegistreLength)), "TipusRegistreLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TipusRegistreOrder) {
                context.startAttribute("", "TipusRegistreOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TipusRegistreOrder)), "TipusRegistreOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TransaccioLength) {
                context.startAttribute("", "TransaccioLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TransaccioLength)), "TransaccioLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TransaccioOrder) {
                context.startAttribute("", "TransaccioOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TransaccioOrder)), "TransaccioOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_Order) {
                context.startAttribute("", "order");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _Order)), "Order");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }
        }

        public void serializeURIs(
            net.gencat.gecat.batch.DocumentsComplementarisHelper.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
        }

        public java.lang.Class getPrimaryInterface() {
            return (net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType.class);
        }

        public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
            if (schemaFragment == null) {
                schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                        "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                        "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                        "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                        "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                        "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~" +
                        "\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                        "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsr\u0000\u001dcom.sun.msv.grammar.Choi" +
                        "ceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsr\u0000 com.sun.msv.grammar.AttributeExp" +
                        "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/Na" +
                        "meClass;xq\u0000~\u0000\u0003sr\u0000\u0011java.lang.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr" +
                        "\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng" +
                        "/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util" +
                        "/StringPair;xq\u0000~\u0000\u0003ppsr\u0000 com.sun.msv.datatype.xsd.IntType\u0000\u0000\u0000\u0000" +
                        "\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000+com.sun.msv.datatype.xsd.IntegerDerivedType\u0099\u00f1]\u0090&6" +
                        "k\u00be\u0002\u0000\u0001L\u0000\nbaseFacetst\u0000)Lcom/sun/msv/datatype/xsd/XSDatatypeImp" +
                        "l;xr\u0000*com.sun.msv.datatype.xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000x" +
                        "r\u0000%com.sun.msv.datatype.xsd.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.s" +
                        "un.msv.datatype.xsd.XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUri" +
                        "t\u0000\u0012Ljava/lang/String;L\u0000\btypeNameq\u0000~\u0000/L\u0000\nwhiteSpacet\u0000.Lcom/su" +
                        "n/msv/datatype/xsd/WhiteSpaceProcessor;xpt\u0000 http://www.w3.or" +
                        "g/2001/XMLSchemat\u0000\u0003intsr\u00005com.sun.msv.datatype.xsd.WhiteSpac" +
                        "eProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datatype.xsd.W" +
                        "hiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u0000*com.sun.msv.datatype.xsd." +
                        "MaxInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.datatype.xsd.Ran" +
                        "geFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\nlimitValuet\u0000\u0012Ljava/lang/Object;xr\u00009com." +
                        "sun.msv.datatype.xsd.DataTypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008a" +
                        "T\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000" +
                        "\u0005Z\u0000\fisFacetFixedZ\u0000\u0012needValueCheckFlagL\u0000\bbaseTypeq\u0000~\u0000+L\u0000\fconc" +
                        "reteTypet\u0000\'Lcom/sun/msv/datatype/xsd/ConcreteType;L\u0000\tfacetNa" +
                        "meq\u0000~\u0000/xq\u0000~\u0000.ppq\u0000~\u00006\u0000\u0001sr\u0000*com.sun.msv.datatype.xsd.MinInclus" +
                        "iveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u00008ppq\u0000~\u00006\u0000\u0000sr\u0000!com.sun.msv.datatype.x" +
                        "sd.LongType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000*q\u0000~\u00002t\u0000\u0004longq\u0000~\u00006sq\u0000~\u00007ppq\u0000~\u00006\u0000\u0001" +
                        "sq\u0000~\u0000>ppq\u0000~\u00006\u0000\u0000sr\u0000$com.sun.msv.datatype.xsd.IntegerType\u0000\u0000\u0000\u0000\u0000" +
                        "\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000*q\u0000~\u00002t\u0000\u0007integerq\u0000~\u00006sr\u0000,com.sun.msv.datatype.xsd" +
                        ".FractionDigitsFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scalexr\u0000;com.sun.msv.datat" +
                        "ype.xsd.DataTypeWithLexicalConstraintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000;p" +
                        "pq\u0000~\u00006\u0001\u0000sr\u0000#com.sun.msv.datatype.xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq" +
                        "\u0000~\u0000,q\u0000~\u00002t\u0000\u0007decimalq\u0000~\u00006q\u0000~\u0000Lt\u0000\u000efractionDigits\u0000\u0000\u0000\u0000q\u0000~\u0000Ft\u0000\fmi" +
                        "nInclusivesr\u0000\u000ejava.lang.Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010java.lang" +
                        ".Number\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u0000Ft\u0000\fmaxInclusivesq\u0000~\u0000P\u007f\u00ff\u00ff\u00ff\u00ff\u00ff" +
                        "\u00ff\u00ffq\u0000~\u0000Aq\u0000~\u0000Osr\u0000\u0011java.lang.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000Q\u0080\u0000" +
                        "\u0000\u0000q\u0000~\u0000Aq\u0000~\u0000Ssq\u0000~\u0000U\u007f\u00ff\u00ff\u00ffsr\u00000com.sun.msv.grammar.Expression$Nul" +
                        "lSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun.msv.util.String" +
                        "Pair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000/L\u0000\fnamespaceURIq\u0000~\u0000/xpq\u0000~\u00003q" +
                        "\u0000~\u00002sr\u0000#com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tloc" +
                        "alNameq\u0000~\u0000/L\u0000\fnamespaceURIq\u0000~\u0000/xr\u0000\u001dcom.sun.msv.grammar.NameC" +
                        "lass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpt\u0000\u0014ClasseDocumentLengtht\u0000\u0000sr\u00000com.sun.msv.g" +
                        "rammar.Expression$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000#\u0001q" +
                        "\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u0013ClasseDocumentOrderq\u0000~" +
                        "\u0000`q\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u000fDataComptLengthq\u0000~\u0000" +
                        "`q\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u000eDataComptOrderq\u0000~\u0000`q" +
                        "\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u0012DataDocumentLengthq\u0000~\u0000" +
                        "`q\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u0011DataDocumentOrderq\u0000~" +
                        "\u0000`q\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u000fImportFieldTypeq\u0000~\u0000" +
                        "`q\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\fImportLengthq\u0000~\u0000`q\u0000~" +
                        "\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u000bImportOrderq\u0000~\u0000`q\u0000~\u0000bsq\u0000" +
                        "~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u0014NDocumentCrearLengthq\u0000~\u0000`q\u0000~\u0000" +
                        "bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u0013NDocumentCrearOrderq\u0000~\u0000`q" +
                        "\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u0018NDocumentModificarLeng" +
                        "thq\u0000~\u0000`q\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u0017NDocumentModif" +
                        "icarOrderq\u0000~\u0000`q\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\rPosicio" +
                        "Lengthq\u0000~\u0000`q\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\fPosicioOrd" +
                        "erq\u0000~\u0000`q\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u000eSocietatLength" +
                        "q\u0000~\u0000`q\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\rSocietatOrderq\u0000~" +
                        "\u0000`q\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\nTextLengthq\u0000~\u0000`q\u0000~\u0000" +
                        "bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\tTextOrderq\u0000~\u0000`q\u0000~\u0000bsq\u0000~\u0000\u001e" +
                        "ppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u0013TipusOperacioLengthq\u0000~\u0000`q\u0000~\u0000bsq\u0000" +
                        "~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u0012TipusOperacioOrderq\u0000~\u0000`q\u0000~\u0000bs" +
                        "q\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u0013TipusRegistreLengthq\u0000~\u0000`q\u0000~" +
                        "\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u0012TipusRegistreOrderq\u0000~\u0000`q" +
                        "\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u0010TransaccioLengthq\u0000~\u0000`q" +
                        "\u0000~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u000fTransaccioOrderq\u0000~\u0000`q\u0000" +
                        "~\u0000bsq\u0000~\u0000\u001eppsq\u0000~\u0000 q\u0000~\u0000$pq\u0000~\u0000(sq\u0000~\u0000\\t\u0000\u0005orderq\u0000~\u0000`q\u0000~\u0000bsr\u0000\"com." +
                        "sun.msv.grammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/" +
                        "sun/msv/grammar/ExpressionPool$ClosedHash;xpsr\u0000-com.sun.msv." +
                        "grammar.ExpressionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstrea" +
                        "mVersionL\u0000\u0006parentt\u0000$Lcom/sun/msv/grammar/ExpressionPool;xp\u0000\u0000" +
                        "\u00003\u0001pq\u0000~\u0000\u000bq\u0000~\u0000\u0080q\u0000~\u0000\u001cq\u0000~\u0000\u0005q\u0000~\u0000\u0018q\u0000~\u0000\u000eq\u0000~\u0000\bq\u0000~\u0000\u00c0q\u0000~\u0000\u0098q\u0000~\u0000\u000fq\u0000~\u0000\u00a4q" +
                        "\u0000~\u0000\u00b0q\u0000~\u0000\u00c4q\u0000~\u0000\u0014q\u0000~\u0000|q\u0000~\u0000\u00bcq\u0000~\u0000\u0006q\u0000~\u0000tq\u0000~\u0000dq\u0000~\u0000\u001aq\u0000~\u0000\u0010q\u0000~\u0000xq\u0000~\u0000\u001bq" +
                        "\u0000~\u0000\u0017q\u0000~\u0000\u008cq\u0000~\u0000\u0011q\u0000~\u0000\fq\u0000~\u0000\u0013q\u0000~\u0000\tq\u0000~\u0000\nq\u0000~\u0000\u0016q\u0000~\u0000\u0088q\u0000~\u0000\u00b4q\u0000~\u0000\u001fq\u0000~\u0000hq" +
                        "\u0000~\u0000\u00acq\u0000~\u0000\u00a8q\u0000~\u0000\u0012q\u0000~\u0000pq\u0000~\u0000\u00b8q\u0000~\u0000\rq\u0000~\u0000\u00a0q\u0000~\u0000\u0015q\u0000~\u0000lq\u0000~\u0000\u001dq\u0000~\u0000\u0084q\u0000~\u0000\u0007q" +
                        "\u0000~\u0000\u0019q\u0000~\u0000\u009cq\u0000~\u0000\u0090q\u0000~\u0000\u0094x"));
            }

            return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
        }
    }
}
