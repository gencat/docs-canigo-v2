/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsMPE.verification;

public class DadesPagadorAlternatiuTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
    protected java.lang.Object[] values = new java.lang.Object[] { "3" };
    protected java.util.Set valueSet = java.util.Collections.unmodifiableSet(new java.util.HashSet(
                java.util.Arrays.asList(values)));

    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType master) {
        if (null == master.getBlocImputacio()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "BlocImputacio"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check value
            checkBlocImputacio(parentLocator, handler, master,
                master.getBlocImputacio());
        }

        if (null == master.getTipusRegistre()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "TipusRegistre"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check value
            checkTipusRegistre(parentLocator, handler, master,
                master.getTipusRegistre());
        }

        if (null == master.getNom()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Nom"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check value
            checkNom(parentLocator, handler, master, master.getNom());
        }

        if (null == master.getAdreca()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Adreca"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check value
            checkAdreca(parentLocator, handler, master, master.getAdreca());
        }

        if (null == master.getPoblacio()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Poblacio"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check value
            checkPoblacio(parentLocator, handler, master, master.getPoblacio());
        }

        if (null == master.getCodiPostal()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "CodiPostal"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check value
            checkCodiPostal(parentLocator, handler, master,
                master.getCodiPostal());
        }

        if (null == master.getPais()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Pais"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check value
            checkPais(parentLocator, handler, master, master.getPais());
        }

        if (null == master.getClauBanc()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "ClauBanc"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check value
            checkClauBanc(parentLocator, handler, master, master.getClauBanc());
        }

        if (null == master.getCompte()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "Compte"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check value
            checkCompte(parentLocator, handler, master, master.getCompte());
        }

        if (null == master.getDigitsControl()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "DigitsControl"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check value
            checkDigitsControl(parentLocator, handler, master,
                master.getDigitsControl());
        }

        if (null == master.getPaisBanc()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "PaisBanc"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check value
            checkPaisBanc(parentLocator, handler, master, master.getPaisBanc());
        }

        if (null == master.getNIF()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "NIF"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check value
            checkNIF(parentLocator, handler, master, master.getNIF());
        }
    }

    public void checkClauBanc(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType master,
        java.lang.String value) {
        if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (((null == realValue) ? 0 : realValue.length()) <= 15) {
                    // Value length is correct
                } else {
                    problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                            ((null == realValue) ? 0 : realValue.length()), 15);
                }

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ClauBanc"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "ClauBanc"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkPaisBanc(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType master,
        java.lang.String value) {
        if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (((null == realValue) ? 0 : realValue.length()) <= 3) {
                    // Value length is correct
                } else {
                    problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                            ((null == realValue) ? 0 : realValue.length()), 3);
                }

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "PaisBanc"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "PaisBanc"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkNom(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType master,
        java.lang.String value) {
        if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (((null == realValue) ? 0 : realValue.length()) <= 35) {
                    // Value length is correct
                } else {
                    problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                            ((null == realValue) ? 0 : realValue.length()), 35);
                }

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Nom"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Nom"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkCodiPostal(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType master,
        java.lang.String value) {
        if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (((null == realValue) ? 0 : realValue.length()) <= 10) {
                    // Value length is correct
                } else {
                    problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                            ((null == realValue) ? 0 : realValue.length()), 10);
                }

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CodiPostal"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "CodiPostal"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkCompte(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType master,
        java.lang.String value) {
        if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (((null == realValue) ? 0 : realValue.length()) <= 18) {
                    // Value length is correct
                } else {
                    problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                            ((null == realValue) ? 0 : realValue.length()), 18);
                }

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Compte"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Compte"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkTipusRegistre(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType master,
        java.lang.String value) {
        if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.EnumerationFacet datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (valueSet.contains(realValue)) {
                    // Value is found in the enumeration, it is valid
                } else {
                    problem = new de.fzi.dbs.verification.event.datatype.EnumerationProblem(realValue,
                            valueSet);
                }

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusRegistre"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "TipusRegistre"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkAdreca(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType master,
        java.lang.String value) {
        if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (((null == realValue) ? 0 : realValue.length()) <= 35) {
                    // Value length is correct
                } else {
                    problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                            ((null == realValue) ? 0 : realValue.length()), 35);
                }

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Adreca"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Adreca"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkPais(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType master,
        java.lang.String value) {
        if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (((null == realValue) ? 0 : realValue.length()) <= 3) {
                    // Value length is correct
                } else {
                    problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                            ((null == realValue) ? 0 : realValue.length()), 3);
                }

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Pais"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Pais"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkPoblacio(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType master,
        java.lang.String value) {
        if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (((null == realValue) ? 0 : realValue.length()) <= 35) {
                    // Value length is correct
                } else {
                    problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                            ((null == realValue) ? 0 : realValue.length()), 35);
                }

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Poblacio"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Poblacio"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkDigitsControl(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType master,
        java.lang.String value) {
        if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (((null == realValue) ? 0 : realValue.length()) <= 2) {
                    // Value length is correct
                } else {
                    problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                            ((null == realValue) ? 0 : realValue.length()), 2);
                }

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DigitsControl"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DigitsControl"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkNIF(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType master,
        java.lang.String value) {
        if (value instanceof java.lang.String) {
            java.lang.String realValue = ((java.lang.String) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (((null == realValue) ? 0 : realValue.length()) <= 16) {
                    // Value length is correct
                } else {
                    problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                            ((null == realValue) ? 0 : realValue.length()), 16);
                }

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "NIF"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "NIF"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkBlocImputacio(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType master,
        net.gencat.gecat.batch.DocumentsMPE.BlocImputacioType value) {
        if (value instanceof net.gencat.gecat.batch.DocumentsMPE.BlocImputacioType) {
            net.gencat.gecat.batch.DocumentsMPE.BlocImputacioType realValue = ((net.gencat.gecat.batch.DocumentsMPE.BlocImputacioType) value);

            {
                // Check complex value
                net.gencat.gecat.batch.DocumentsMPE.verification.BlocImputacioTypeVerifier verifier =
                    new net.gencat.gecat.batch.DocumentsMPE.verification.BlocImputacioTypeVerifier();
                verifier.check(new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "BlocImputacio"), handler,
                    realValue);
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "BlocImputacio"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
        check(parentLocator, handler,
            ((net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType) object));
    }

    public void check(javax.xml.bind.ValidationEventHandler handler,
        java.lang.Object object) {
        check(null, handler,
            ((net.gencat.gecat.batch.DocumentsMPE.DadesPagadorAlternatiuType) object));
    }
}
