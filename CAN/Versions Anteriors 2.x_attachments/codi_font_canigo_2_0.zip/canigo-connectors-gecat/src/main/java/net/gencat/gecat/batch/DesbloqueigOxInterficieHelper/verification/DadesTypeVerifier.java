/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.verification;

public class DadesTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType master) {
        if (true) {
            // If left exists
            // No check for primitive values
            checkLiniaDocumentLength(parentLocator, handler, master,
                new java.lang.Integer(master.getLiniaDocumentLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkLiniaDocumentOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getLiniaDocumentOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkNDocumentLength(parentLocator, handler, master,
                new java.lang.Integer(master.getNDocumentLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkNDocumentOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getNDocumentOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkSocietatLength(parentLocator, handler, master,
                new java.lang.Integer(master.getSocietatLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkSocietatOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getSocietatOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkTransaccioLength(parentLocator, handler, master,
                new java.lang.Integer(master.getTransaccioLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkTransaccioOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getTransaccioOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getOrder()));
        }
    }

    public void checkLiniaDocumentLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "LiniaDocumentLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "LiniaDocumentLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkNDocumentLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "NDocumentLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "NDocumentLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Order"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Order"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkTransaccioOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TransaccioOrder"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "TransaccioOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkTransaccioLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TransaccioLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "TransaccioLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkLiniaDocumentOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "LiniaDocumentOrder"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "LiniaDocumentOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkNDocumentOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "NDocumentOrder"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "NDocumentOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkSocietatOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "SocietatOrder"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "SocietatOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkSocietatLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "SocietatLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "SocietatLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
        check(parentLocator, handler,
            ((net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType) object));
    }

    public void check(javax.xml.bind.ValidationEventHandler handler,
        java.lang.Object object) {
        check(null, handler,
            ((net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType) object));
    }
}
