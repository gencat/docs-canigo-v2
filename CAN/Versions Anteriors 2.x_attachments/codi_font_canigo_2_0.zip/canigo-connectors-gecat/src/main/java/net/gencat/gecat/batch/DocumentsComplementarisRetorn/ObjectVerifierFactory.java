/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsComplementarisRetorn;

public class ObjectVerifierFactory extends de.fzi.dbs.verification.ObjectVerifierFactory {
    static {
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.DadaRetornType.class,
            net.gencat.gecat.batch.DocumentsComplementarisRetorn.verification.DadesRetornTypeVerifier.DadaRetornTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.DadesRetornTypeImpl.DadaRetornTypeImpl.class,
            net.gencat.gecat.batch.DocumentsComplementarisRetorn.verification.DadesRetornTypeVerifier.DadaRetornTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesDocumentsComplementarisRetorn.class,
            net.gencat.gecat.batch.DocumentsComplementarisRetorn.verification.DadesDocumentsComplementarisRetornVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.DadesDocumentsComplementarisRetornImpl.class,
            net.gencat.gecat.batch.DocumentsComplementarisRetorn.verification.DadesDocumentsComplementarisRetornVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesRetornType.class,
            net.gencat.gecat.batch.DocumentsComplementarisRetorn.verification.DadesRetornTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.DadesRetornTypeImpl.class,
            net.gencat.gecat.batch.DocumentsComplementarisRetorn.verification.DadesRetornTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsComplementarisRetorn.DadesDocumentsComplementarisRetornType.class,
            net.gencat.gecat.batch.DocumentsComplementarisRetorn.verification.DadesDocumentsComplementarisRetornTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsComplementarisRetorn.impl.DadesDocumentsComplementarisRetornTypeImpl.class,
            net.gencat.gecat.batch.DocumentsComplementarisRetorn.verification.DadesDocumentsComplementarisRetornTypeVerifier.class);
    }
}
