/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOHelper;

public class ObjectVerifierFactory extends de.fzi.dbs.verification.ObjectVerifierFactory {
    static {
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.RetencionsType.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.RetencionsTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.impl.RetencionsTypeImpl.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.RetencionsTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.BlocImputacioType.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.BlocImputacioTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.impl.BlocImputacioTypeImpl.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.BlocImputacioTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.DadesPosicioType.DadaPosicioType.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.DadesPosicioTypeVerifier.DadaPosicioTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.impl.DadesPosicioTypeImpl.DadaPosicioTypeImpl.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.DadesPosicioTypeVerifier.DadaPosicioTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.DadesDocumentsOType.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.DadesDocumentsOTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.impl.DadesDocumentsOTypeImpl.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.DadesDocumentsOTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.DadesPagadorAlternatiuType.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.DadesPagadorAlternatiuTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.impl.DadesPagadorAlternatiuTypeImpl.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.DadesPagadorAlternatiuTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.DadesPosicioType.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.DadesPosicioTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.impl.DadesPosicioTypeImpl.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.DadesPosicioTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.RetencionsType.DadaRetencioType.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.RetencionsTypeVerifier.DadaRetencioTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.impl.RetencionsTypeImpl.DadaRetencioTypeImpl.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.RetencionsTypeVerifier.DadaRetencioTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.DadesDocumentsO.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.DadesDocumentsOVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.impl.DadesDocumentsOImpl.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.DadesDocumentsOVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.DadesGeneralsType.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.DadesGeneralsTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DocumentsOHelper.impl.DadesGeneralsTypeImpl.class,
            net.gencat.gecat.batch.DocumentsOHelper.verification.DadesGeneralsTypeVerifier.class);
    }
}
