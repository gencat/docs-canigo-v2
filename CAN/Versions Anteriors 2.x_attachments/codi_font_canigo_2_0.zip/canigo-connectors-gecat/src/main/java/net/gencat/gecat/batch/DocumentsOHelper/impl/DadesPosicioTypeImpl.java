/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOHelper.impl;

public class DadesPosicioTypeImpl implements net.gencat.gecat.batch.DocumentsOHelper.DadesPosicioType,
    com.sun.xml.bind.JAXBObject,
    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.XMLSerializable,
    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.ValidatableObject {
    public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsOHelper.impl.JAXBVersion.class);
    private static com.sun.msv.grammar.Grammar schemaFragment;
    protected com.sun.xml.bind.util.ListImpl _DadaPosicio;
    protected boolean has_Order;
    protected int _Order;

    private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
        return (net.gencat.gecat.batch.DocumentsOHelper.DadesPosicioType.class);
    }

    protected com.sun.xml.bind.util.ListImpl _getDadaPosicio() {
        if (_DadaPosicio == null) {
            _DadaPosicio = new com.sun.xml.bind.util.ListImpl(new java.util.ArrayList());
        }

        return _DadaPosicio;
    }

    public java.util.List getDadaPosicio() {
        return _getDadaPosicio();
    }

    public int getOrder() {
        if (!has_Order) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "2"));
        } else {
            return _Order;
        }
    }

    public void setOrder(int value) {
        _Order = value;
        has_Order = true;
    }

    public void serializeBody(
        net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx1 = 0;
        final int len1 = ((_DadaPosicio == null) ? 0 : _DadaPosicio.size());

        while (idx1 != len1) {
            context.startElement("", "DadaPosicio");

            int idx_0 = idx1;
            context.childAsURIs(((com.sun.xml.bind.JAXBObject) _DadaPosicio.get(
                    idx_0++)), "DadaPosicio");
            context.endNamespaceDecls();

            int idx_1 = idx1;
            context.childAsAttributes(((com.sun.xml.bind.JAXBObject) _DadaPosicio.get(
                    idx_1++)), "DadaPosicio");
            context.endAttributes();
            context.childAsBody(((com.sun.xml.bind.JAXBObject) _DadaPosicio.get(
                    idx1++)), "DadaPosicio");
            context.endElement();
        }
    }

    public void serializeAttributes(
        net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx1 = 0;
        final int len1 = ((_DadaPosicio == null) ? 0 : _DadaPosicio.size());

        if (has_Order) {
            context.startAttribute("", "order");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _Order)), "Order");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        while (idx1 != len1) {
            idx1 += 1;
        }
    }

    public void serializeURIs(
        net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx1 = 0;
        final int len1 = ((_DadaPosicio == null) ? 0 : _DadaPosicio.size());

        while (idx1 != len1) {
            idx1 += 1;
        }
    }

    public java.lang.Class getPrimaryInterface() {
        return (net.gencat.gecat.batch.DocumentsOHelper.DadesPosicioType.class);
    }

    public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
        if (schemaFragment == null) {
            schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                    "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                    "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                    "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                    "expandedExpq\u0000~\u0000\u0002xpppsr\u0000 com.sun.msv.grammar.OneOrMoreExp\u0000\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001ccom.sun.msv.grammar.UnaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0003expq\u0000~\u0000" +
                    "\u0002xq\u0000~\u0000\u0003ppsr\u0000\'com.sun.msv.grammar.trex.ElementPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0001L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/NameClass;xr\u0000\u001ecom.sun" +
                    ".msv.grammar.ElementExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aignoreUndeclaredAttribu" +
                    "tesL\u0000\fcontentModelq\u0000~\u0000\u0002xq\u0000~\u0000\u0003pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\tpp\u0000sr\u0000\u001dcom.sun" +
                    ".msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsq\u0000~\u0000\u0006sr\u0000\u0011java.lang" +
                    ".Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000 com.sun.msv.grammar.Attri" +
                    "buteExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClassq\u0000~\u0000\nxq\u0000~\u0000\u0003q\u0000~\u0000\u0013psr" +
                    "\u00002com.sun.msv.grammar.Expression$AnyStringExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\u0012\u0001q\u0000~\u0000\u0017sr\u0000 com.sun.msv.grammar.AnyNameClass\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000co" +
                    "m.sun.msv.grammar.Expression$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000" +
                    "~\u0000\u0003q\u0000~\u0000\u0018q\u0000~\u0000\u001dsr\u0000#com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0002L\u0000\tlocalNamet\u0000\u0012Ljava/lang/String;L\u0000\fnamespaceURIq\u0000~\u0000\u001fxq\u0000~" +
                    "\u0000\u001at\u0000Hnet.gencat.gecat.batch.DocumentsOHelper.DadesPosicioTyp" +
                    "e.DadaPosicioTypet\u0000+http://java.sun.com/jaxb/xjc/dummy-eleme" +
                    "ntssq\u0000~\u0000\u000fppsq\u0000~\u0000\u0014q\u0000~\u0000\u0013psr\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000" +
                    "\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000" +
                    "\u0004namet\u0000\u001dLcom/sun/msv/util/StringPair;xq\u0000~\u0000\u0003ppsr\u0000\"com.sun.msv" +
                    ".datatype.xsd.QnameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.x" +
                    "sd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datatype.xsd." +
                    "ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype.xsd.XSDataty" +
                    "peImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUriq\u0000~\u0000\u001fL\u0000\btypeNameq\u0000~\u0000\u001fL\u0000\nwhit" +
                    "eSpacet\u0000.Lcom/sun/msv/datatype/xsd/WhiteSpaceProcessor;xpt\u0000 " +
                    "http://www.w3.org/2001/XMLSchemat\u0000\u0005QNamesr\u00005com.sun.msv.data" +
                    "type.xsd.WhiteSpaceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun." +
                    "msv.datatype.xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000com.sun" +
                    ".msv.grammar.Expression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003pp" +
                    "sr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000\u001fL" +
                    "\u0000\fnamespaceURIq\u0000~\u0000\u001fxpq\u0000~\u00000q\u0000~\u0000/sq\u0000~\u0000\u001et\u0000\u0004typet\u0000)http://www.w3" +
                    ".org/2001/XMLSchema-instanceq\u0000~\u0000\u001dsq\u0000~\u0000\u001et\u0000\u000bDadaPosiciot\u0000\u0000sq\u0000~" +
                    "\u0000\u000fppsq\u0000~\u0000\u0014q\u0000~\u0000\u0013psq\u0000~\u0000%ppsr\u0000 com.sun.msv.datatype.xsd.IntType" +
                    "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000+com.sun.msv.datatype.xsd.IntegerDerivedType\u0099\u00f1" +
                    "]\u0090&6k\u00be\u0002\u0000\u0001L\u0000\nbaseFacetst\u0000)Lcom/sun/msv/datatype/xsd/XSDatatyp" +
                    "eImpl;xq\u0000~\u0000*q\u0000~\u0000/t\u0000\u0003intq\u0000~\u00003sr\u0000*com.sun.msv.datatype.xsd.Max" +
                    "InclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.datatype.xsd.RangeF" +
                    "acet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\nlimitValuet\u0000\u0012Ljava/lang/Object;xr\u00009com.sun" +
                    ".msv.datatype.xsd.DataTypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000" +
                    "\u0000xr\u0000*com.sun.msv.datatype.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000" +
                    "\fisFacetFixedZ\u0000\u0012needValueCheckFlagL\u0000\bbaseTypeq\u0000~\u0000CL\u0000\fconcret" +
                    "eTypet\u0000\'Lcom/sun/msv/datatype/xsd/ConcreteType;L\u0000\tfacetNameq" +
                    "\u0000~\u0000\u001fxq\u0000~\u0000,ppq\u0000~\u00003\u0000\u0001sr\u0000*com.sun.msv.datatype.xsd.MinInclusive" +
                    "Facet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Gppq\u0000~\u00003\u0000\u0000sr\u0000!com.sun.msv.datatype.xsd." +
                    "LongType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Bq\u0000~\u0000/t\u0000\u0004longq\u0000~\u00003sq\u0000~\u0000Fppq\u0000~\u00003\u0000\u0001sq\u0000" +
                    "~\u0000Mppq\u0000~\u00003\u0000\u0000sr\u0000$com.sun.msv.datatype.xsd.IntegerType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0000xq\u0000~\u0000Bq\u0000~\u0000/t\u0000\u0007integerq\u0000~\u00003sr\u0000,com.sun.msv.datatype.xsd.Fr" +
                    "actionDigitsFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scalexr\u0000;com.sun.msv.datatype" +
                    ".xsd.DataTypeWithLexicalConstraintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000Jppq\u0000" +
                    "~\u00003\u0001\u0000sr\u0000#com.sun.msv.datatype.xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000" +
                    "*q\u0000~\u0000/t\u0000\u0007decimalq\u0000~\u00003q\u0000~\u0000[t\u0000\u000efractionDigits\u0000\u0000\u0000\u0000q\u0000~\u0000Ut\u0000\fminIn" +
                    "clusivesr\u0000\u000ejava.lang.Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010java.lang.Nu" +
                    "mber\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u0000Ut\u0000\fmaxInclusivesq\u0000~\u0000_\u007f\u00ff\u00ff\u00ff\u00ff\u00ff\u00ff\u00ffq" +
                    "\u0000~\u0000Pq\u0000~\u0000^sr\u0000\u0011java.lang.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000`\u0080\u0000\u0000\u0000q" +
                    "\u0000~\u0000Pq\u0000~\u0000bsq\u0000~\u0000d\u007f\u00ff\u00ff\u00ffq\u0000~\u00005sq\u0000~\u00006q\u0000~\u0000Eq\u0000~\u0000/sq\u0000~\u0000\u001et\u0000\u0005orderq\u0000~\u0000=q" +
                    "\u0000~\u0000\u001dsr\u0000\"com.sun.msv.grammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpT" +
                    "ablet\u0000/Lcom/sun/msv/grammar/ExpressionPool$ClosedHash;xpsr\u0000-" +
                    "com.sun.msv.grammar.ExpressionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005c" +
                    "ountB\u0000\rstreamVersionL\u0000\u0006parentt\u0000$Lcom/sun/msv/grammar/Express" +
                    "ionPool;xp\u0000\u0000\u0000\u0007\u0001pq\u0000~\u0000\u0011q\u0000~\u0000#q\u0000~\u0000\bq\u0000~\u0000>q\u0000~\u0000\u0005q\u0000~\u0000\rq\u0000~\u0000\u0010x"));
        }

        return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
    }

    public static class DadaPosicioTypeImpl implements net.gencat.gecat.batch.DocumentsOHelper.DadesPosicioType.DadaPosicioType,
        com.sun.xml.bind.JAXBObject,
        net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.XMLSerializable,
        net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.ValidatableObject {
        public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsOHelper.impl.JAXBVersion.class);
        private static com.sun.msv.grammar.Grammar schemaFragment;
        protected boolean has_ReservaFondosOrder;
        protected int _ReservaFondosOrder;
        protected boolean has_CompteMajorLength;
        protected int _CompteMajorLength;
        protected boolean has_NExpedientOrder;
        protected int _NExpedientOrder;
        protected boolean has_CentreGestorLength;
        protected int _CentreGestorLength;
        protected boolean has_Order;
        protected int _Order;
        protected boolean has_ReferenciaLength;
        protected int _ReferenciaLength;
        protected boolean has_ImportLength;
        protected int _ImportLength;
        protected boolean has_ReferenciaOrder;
        protected int _ReferenciaOrder;
        protected boolean has_TextLength;
        protected int _TextLength;
        protected boolean has_PosicioLength;
        protected int _PosicioLength;
        protected boolean has_CreditorOrder;
        protected int _CreditorOrder;
        protected boolean has_ImportImpostFieldType;
        protected int _ImportImpostFieldType;
        protected boolean has_CreditorLength;
        protected int _CreditorLength;
        protected boolean has_DadesPagadorAlternatiuLength;
        protected int _DadesPagadorAlternatiuLength;
        protected boolean has_ViaPagamentOrder;
        protected int _ViaPagamentOrder;
        protected boolean has_FonsOrder;
        protected int _FonsOrder;
        protected boolean has_PosicioOrder;
        protected int _PosicioOrder;
        protected boolean has_CompteMajorOrder;
        protected int _CompteMajorOrder;
        protected boolean has_AssignacioOrder;
        protected int _AssignacioOrder;
        protected boolean has_AssignacioLength;
        protected int _AssignacioLength;
        protected boolean has_DataBaseOrder;
        protected int _DataBaseOrder;
        protected boolean has_FonsLength;
        protected int _FonsLength;
        protected boolean has_PagadorAlternatiuLength;
        protected int _PagadorAlternatiuLength;
        protected boolean has_TipusRegistreLength;
        protected int _TipusRegistreLength;
        protected boolean has_CalcularImpostOrder;
        protected int _CalcularImpostOrder;
        protected boolean has_ImportImpostOrder;
        protected int _ImportImpostOrder;
        protected boolean has_CalcularImpostLength;
        protected int _CalcularImpostLength;
        protected boolean has_DataBaseLength;
        protected int _DataBaseLength;
        protected boolean has_ViaPagamentLength;
        protected int _ViaPagamentLength;
        protected boolean has_ImportImpostLength;
        protected int _ImportImpostLength;
        protected boolean has_ImportFieldType;
        protected int _ImportFieldType;
        protected boolean has_TextDocumentOrder;
        protected int _TextDocumentOrder;
        protected boolean has_IndicadorIVAOrder;
        protected int _IndicadorIVAOrder;
        protected boolean has_PosicioPressupostariaLength;
        protected int _PosicioPressupostariaLength;
        protected boolean has_TipusBancInterlocutorOrder;
        protected int _TipusBancInterlocutorOrder;
        protected boolean has_TextDocumentLength;
        protected int _TextDocumentLength;
        protected boolean has_ImportOrder;
        protected int _ImportOrder;
        protected boolean has_RegioOrder;
        protected int _RegioOrder;
        protected boolean has_TextOrder;
        protected int _TextOrder;
        protected boolean has_PagadorAlternatiuOrder;
        protected int _PagadorAlternatiuOrder;
        protected boolean has_PosicioPressupostariaOrder;
        protected int _PosicioPressupostariaOrder;
        protected boolean has_TipusRegistreOrder;
        protected int _TipusRegistreOrder;
        protected boolean has_RegioLength;
        protected int _RegioLength;
        protected boolean has_DadesPagadorAlternatiuOrder;
        protected int _DadesPagadorAlternatiuOrder;
        protected boolean has_BloqueigPagamentOrder;
        protected int _BloqueigPagamentOrder;
        protected boolean has_TipusBancInterlocutorLength;
        protected int _TipusBancInterlocutorLength;
        protected boolean has_CondicioPagamentLength;
        protected int _CondicioPagamentLength;
        protected boolean has_BloqueigPagamentLength;
        protected int _BloqueigPagamentLength;
        protected boolean has_CentreGestorOrder;
        protected int _CentreGestorOrder;
        protected boolean has_CondicioPagamentOrder;
        protected int _CondicioPagamentOrder;
        protected boolean has_NExpedientLength;
        protected int _NExpedientLength;
        protected boolean has_IndicadorIVALength;
        protected int _IndicadorIVALength;
        protected boolean has_ReservaFondosLength;
        protected int _ReservaFondosLength;

        private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
            return (net.gencat.gecat.batch.DocumentsOHelper.DadesPosicioType.DadaPosicioType.class);
        }

        public int getReservaFondosOrder() {
            if (!has_ReservaFondosOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "7"));
            } else {
                return _ReservaFondosOrder;
            }
        }

        public void setReservaFondosOrder(int value) {
            _ReservaFondosOrder = value;
            has_ReservaFondosOrder = true;
        }

        public int getCompteMajorLength() {
            if (!has_CompteMajorLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "10"));
            } else {
                return _CompteMajorLength;
            }
        }

        public void setCompteMajorLength(int value) {
            _CompteMajorLength = value;
            has_CompteMajorLength = true;
        }

        public int getNExpedientOrder() {
            if (!has_NExpedientOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "3"));
            } else {
                return _NExpedientOrder;
            }
        }

        public void setNExpedientOrder(int value) {
            _NExpedientOrder = value;
            has_NExpedientOrder = true;
        }

        public int getCentreGestorLength() {
            if (!has_CentreGestorLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "16"));
            } else {
                return _CentreGestorLength;
            }
        }

        public void setCentreGestorLength(int value) {
            _CentreGestorLength = value;
            has_CentreGestorLength = true;
        }

        public int getOrder() {
            return _Order;
        }

        public void setOrder(int value) {
            _Order = value;
            has_Order = true;
        }

        public int getReferenciaLength() {
            if (!has_ReferenciaLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "16"));
            } else {
                return _ReferenciaLength;
            }
        }

        public void setReferenciaLength(int value) {
            _ReferenciaLength = value;
            has_ReferenciaLength = true;
        }

        public int getImportLength() {
            if (!has_ImportLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "13"));
            } else {
                return _ImportLength;
            }
        }

        public void setImportLength(int value) {
            _ImportLength = value;
            has_ImportLength = true;
        }

        public int getReferenciaOrder() {
            if (!has_ReferenciaOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "10"));
            } else {
                return _ReferenciaOrder;
            }
        }

        public void setReferenciaOrder(int value) {
            _ReferenciaOrder = value;
            has_ReferenciaOrder = true;
        }

        public int getTextLength() {
            if (!has_TextLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "50"));
            } else {
                return _TextLength;
            }
        }

        public void setTextLength(int value) {
            _TextLength = value;
            has_TextLength = true;
        }

        public int getPosicioLength() {
            if (!has_PosicioLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "3"));
            } else {
                return _PosicioLength;
            }
        }

        public void setPosicioLength(int value) {
            _PosicioLength = value;
            has_PosicioLength = true;
        }

        public int getCreditorOrder() {
            if (!has_CreditorOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "4"));
            } else {
                return _CreditorOrder;
            }
        }

        public void setCreditorOrder(int value) {
            _CreditorOrder = value;
            has_CreditorOrder = true;
        }

        public int getImportImpostFieldType() {
            if (!has_ImportImpostFieldType) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "1"));
            } else {
                return _ImportImpostFieldType;
            }
        }

        public void setImportImpostFieldType(int value) {
            _ImportImpostFieldType = value;
            has_ImportImpostFieldType = true;
        }

        public int getCreditorLength() {
            if (!has_CreditorLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "10"));
            } else {
                return _CreditorLength;
            }
        }

        public void setCreditorLength(int value) {
            _CreditorLength = value;
            has_CreditorLength = true;
        }

        public int getDadesPagadorAlternatiuLength() {
            return _DadesPagadorAlternatiuLength;
        }

        public void setDadesPagadorAlternatiuLength(int value) {
            _DadesPagadorAlternatiuLength = value;
            has_DadesPagadorAlternatiuLength = true;
        }

        public int getViaPagamentOrder() {
            if (!has_ViaPagamentOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "19"));
            } else {
                return _ViaPagamentOrder;
            }
        }

        public void setViaPagamentOrder(int value) {
            _ViaPagamentOrder = value;
            has_ViaPagamentOrder = true;
        }

        public int getFonsOrder() {
            if (!has_FonsOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "18"));
            } else {
                return _FonsOrder;
            }
        }

        public void setFonsOrder(int value) {
            _FonsOrder = value;
            has_FonsOrder = true;
        }

        public int getPosicioOrder() {
            if (!has_PosicioOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "8"));
            } else {
                return _PosicioOrder;
            }
        }

        public void setPosicioOrder(int value) {
            _PosicioOrder = value;
            has_PosicioOrder = true;
        }

        public int getCompteMajorOrder() {
            if (!has_CompteMajorOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "23"));
            } else {
                return _CompteMajorOrder;
            }
        }

        public void setCompteMajorOrder(int value) {
            _CompteMajorOrder = value;
            has_CompteMajorOrder = true;
        }

        public int getAssignacioOrder() {
            if (!has_AssignacioOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "24"));
            } else {
                return _AssignacioOrder;
            }
        }

        public void setAssignacioOrder(int value) {
            _AssignacioOrder = value;
            has_AssignacioOrder = true;
        }

        public int getAssignacioLength() {
            if (!has_AssignacioLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "18"));
            } else {
                return _AssignacioLength;
            }
        }

        public void setAssignacioLength(int value) {
            _AssignacioLength = value;
            has_AssignacioLength = true;
        }

        public int getDataBaseOrder() {
            if (!has_DataBaseOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "21"));
            } else {
                return _DataBaseOrder;
            }
        }

        public void setDataBaseOrder(int value) {
            _DataBaseOrder = value;
            has_DataBaseOrder = true;
        }

        public int getFonsLength() {
            if (!has_FonsLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "10"));
            } else {
                return _FonsLength;
            }
        }

        public void setFonsLength(int value) {
            _FonsLength = value;
            has_FonsLength = true;
        }

        public int getPagadorAlternatiuLength() {
            if (!has_PagadorAlternatiuLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "10"));
            } else {
                return _PagadorAlternatiuLength;
            }
        }

        public void setPagadorAlternatiuLength(int value) {
            _PagadorAlternatiuLength = value;
            has_PagadorAlternatiuLength = true;
        }

        public int getTipusRegistreLength() {
            if (!has_TipusRegistreLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "1"));
            } else {
                return _TipusRegistreLength;
            }
        }

        public void setTipusRegistreLength(int value) {
            _TipusRegistreLength = value;
            has_TipusRegistreLength = true;
        }

        public int getCalcularImpostOrder() {
            if (!has_CalcularImpostOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "16"));
            } else {
                return _CalcularImpostOrder;
            }
        }

        public void setCalcularImpostOrder(int value) {
            _CalcularImpostOrder = value;
            has_CalcularImpostOrder = true;
        }

        public int getImportImpostOrder() {
            if (!has_ImportImpostOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "14"));
            } else {
                return _ImportImpostOrder;
            }
        }

        public void setImportImpostOrder(int value) {
            _ImportImpostOrder = value;
            has_ImportImpostOrder = true;
        }

        public int getCalcularImpostLength() {
            if (!has_CalcularImpostLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "1"));
            } else {
                return _CalcularImpostLength;
            }
        }

        public void setCalcularImpostLength(int value) {
            _CalcularImpostLength = value;
            has_CalcularImpostLength = true;
        }

        public int getDataBaseLength() {
            if (!has_DataBaseLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "8"));
            } else {
                return _DataBaseLength;
            }
        }

        public void setDataBaseLength(int value) {
            _DataBaseLength = value;
            has_DataBaseLength = true;
        }

        public int getViaPagamentLength() {
            if (!has_ViaPagamentLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "1"));
            } else {
                return _ViaPagamentLength;
            }
        }

        public void setViaPagamentLength(int value) {
            _ViaPagamentLength = value;
            has_ViaPagamentLength = true;
        }

        public int getImportImpostLength() {
            if (!has_ImportImpostLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "13"));
            } else {
                return _ImportImpostLength;
            }
        }

        public void setImportImpostLength(int value) {
            _ImportImpostLength = value;
            has_ImportImpostLength = true;
        }

        public int getImportFieldType() {
            if (!has_ImportFieldType) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "1"));
            } else {
                return _ImportFieldType;
            }
        }

        public void setImportFieldType(int value) {
            _ImportFieldType = value;
            has_ImportFieldType = true;
        }

        public int getTextDocumentOrder() {
            if (!has_TextDocumentOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "2"));
            } else {
                return _TextDocumentOrder;
            }
        }

        public void setTextDocumentOrder(int value) {
            _TextDocumentOrder = value;
            has_TextDocumentOrder = true;
        }

        public int getIndicadorIVAOrder() {
            if (!has_IndicadorIVAOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "15"));
            } else {
                return _IndicadorIVAOrder;
            }
        }

        public void setIndicadorIVAOrder(int value) {
            _IndicadorIVAOrder = value;
            has_IndicadorIVAOrder = true;
        }

        public int getPosicioPressupostariaLength() {
            if (!has_PosicioPressupostariaLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "24"));
            } else {
                return _PosicioPressupostariaLength;
            }
        }

        public void setPosicioPressupostariaLength(int value) {
            _PosicioPressupostariaLength = value;
            has_PosicioPressupostariaLength = true;
        }

        public int getTipusBancInterlocutorOrder() {
            if (!has_TipusBancInterlocutorOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "5"));
            } else {
                return _TipusBancInterlocutorOrder;
            }
        }

        public void setTipusBancInterlocutorOrder(int value) {
            _TipusBancInterlocutorOrder = value;
            has_TipusBancInterlocutorOrder = true;
        }

        public int getTextDocumentLength() {
            if (!has_TextDocumentLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "25"));
            } else {
                return _TextDocumentLength;
            }
        }

        public void setTextDocumentLength(int value) {
            _TextDocumentLength = value;
            has_TextDocumentLength = true;
        }

        public int getImportOrder() {
            if (!has_ImportOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "13"));
            } else {
                return _ImportOrder;
            }
        }

        public void setImportOrder(int value) {
            _ImportOrder = value;
            has_ImportOrder = true;
        }

        public int getRegioOrder() {
            if (!has_RegioOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "11"));
            } else {
                return _RegioOrder;
            }
        }

        public void setRegioOrder(int value) {
            _RegioOrder = value;
            has_RegioOrder = true;
        }

        public int getTextOrder() {
            if (!has_TextOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "17"));
            } else {
                return _TextOrder;
            }
        }

        public void setTextOrder(int value) {
            _TextOrder = value;
            has_TextOrder = true;
        }

        public int getPagadorAlternatiuOrder() {
            if (!has_PagadorAlternatiuOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "22"));
            } else {
                return _PagadorAlternatiuOrder;
            }
        }

        public void setPagadorAlternatiuOrder(int value) {
            _PagadorAlternatiuOrder = value;
            has_PagadorAlternatiuOrder = true;
        }

        public int getPosicioPressupostariaOrder() {
            if (!has_PosicioPressupostariaOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "6"));
            } else {
                return _PosicioPressupostariaOrder;
            }
        }

        public void setPosicioPressupostariaOrder(int value) {
            _PosicioPressupostariaOrder = value;
            has_PosicioPressupostariaOrder = true;
        }

        public int getTipusRegistreOrder() {
            if (!has_TipusRegistreOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "1"));
            } else {
                return _TipusRegistreOrder;
            }
        }

        public void setTipusRegistreOrder(int value) {
            _TipusRegistreOrder = value;
            has_TipusRegistreOrder = true;
        }

        public int getRegioLength() {
            if (!has_RegioLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "10"));
            } else {
                return _RegioLength;
            }
        }

        public void setRegioLength(int value) {
            _RegioLength = value;
            has_RegioLength = true;
        }

        public int getDadesPagadorAlternatiuOrder() {
            if (!has_DadesPagadorAlternatiuOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "25"));
            } else {
                return _DadesPagadorAlternatiuOrder;
            }
        }

        public void setDadesPagadorAlternatiuOrder(int value) {
            _DadesPagadorAlternatiuOrder = value;
            has_DadesPagadorAlternatiuOrder = true;
        }

        public int getBloqueigPagamentOrder() {
            if (!has_BloqueigPagamentOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "20"));
            } else {
                return _BloqueigPagamentOrder;
            }
        }

        public void setBloqueigPagamentOrder(int value) {
            _BloqueigPagamentOrder = value;
            has_BloqueigPagamentOrder = true;
        }

        public int getTipusBancInterlocutorLength() {
            if (!has_TipusBancInterlocutorLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "4"));
            } else {
                return _TipusBancInterlocutorLength;
            }
        }

        public void setTipusBancInterlocutorLength(int value) {
            _TipusBancInterlocutorLength = value;
            has_TipusBancInterlocutorLength = true;
        }

        public int getCondicioPagamentLength() {
            if (!has_CondicioPagamentLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "4"));
            } else {
                return _CondicioPagamentLength;
            }
        }

        public void setCondicioPagamentLength(int value) {
            _CondicioPagamentLength = value;
            has_CondicioPagamentLength = true;
        }

        public int getBloqueigPagamentLength() {
            if (!has_BloqueigPagamentLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "1"));
            } else {
                return _BloqueigPagamentLength;
            }
        }

        public void setBloqueigPagamentLength(int value) {
            _BloqueigPagamentLength = value;
            has_BloqueigPagamentLength = true;
        }

        public int getCentreGestorOrder() {
            if (!has_CentreGestorOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "9"));
            } else {
                return _CentreGestorOrder;
            }
        }

        public void setCentreGestorOrder(int value) {
            _CentreGestorOrder = value;
            has_CentreGestorOrder = true;
        }

        public int getCondicioPagamentOrder() {
            if (!has_CondicioPagamentOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "12"));
            } else {
                return _CondicioPagamentOrder;
            }
        }

        public void setCondicioPagamentOrder(int value) {
            _CondicioPagamentOrder = value;
            has_CondicioPagamentOrder = true;
        }

        public int getNExpedientLength() {
            if (!has_NExpedientLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "30"));
            } else {
                return _NExpedientLength;
            }
        }

        public void setNExpedientLength(int value) {
            _NExpedientLength = value;
            has_NExpedientLength = true;
        }

        public int getIndicadorIVALength() {
            if (!has_IndicadorIVALength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "2"));
            } else {
                return _IndicadorIVALength;
            }
        }

        public void setIndicadorIVALength(int value) {
            _IndicadorIVALength = value;
            has_IndicadorIVALength = true;
        }

        public int getReservaFondosLength() {
            if (!has_ReservaFondosLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "10"));
            } else {
                return _ReservaFondosLength;
            }
        }

        public void setReservaFondosLength(int value) {
            _ReservaFondosLength = value;
            has_ReservaFondosLength = true;
        }

        public void serializeBody(
            net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
        }

        public void serializeAttributes(
            net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
            if (has_AssignacioLength) {
                context.startAttribute("", "AssignacioLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _AssignacioLength)), "AssignacioLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_AssignacioOrder) {
                context.startAttribute("", "AssignacioOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _AssignacioOrder)), "AssignacioOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_BloqueigPagamentLength) {
                context.startAttribute("", "BloqueigPagamentLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _BloqueigPagamentLength)),
                        "BloqueigPagamentLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_BloqueigPagamentOrder) {
                context.startAttribute("", "BloqueigPagamentOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _BloqueigPagamentOrder)),
                        "BloqueigPagamentOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_CalcularImpostLength) {
                context.startAttribute("", "CalcularImpostLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _CalcularImpostLength)),
                        "CalcularImpostLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_CalcularImpostOrder) {
                context.startAttribute("", "CalcularImpostOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _CalcularImpostOrder)), "CalcularImpostOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_CentreGestorLength) {
                context.startAttribute("", "CentreGestorLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _CentreGestorLength)), "CentreGestorLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_CentreGestorOrder) {
                context.startAttribute("", "CentreGestorOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _CentreGestorOrder)), "CentreGestorOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_CompteMajorLength) {
                context.startAttribute("", "CompteMajorLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _CompteMajorLength)), "CompteMajorLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_CompteMajorOrder) {
                context.startAttribute("", "CompteMajorOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _CompteMajorOrder)), "CompteMajorOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_CondicioPagamentLength) {
                context.startAttribute("", "CondicioPagamentLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _CondicioPagamentLength)),
                        "CondicioPagamentLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_CondicioPagamentOrder) {
                context.startAttribute("", "CondicioPagamentOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _CondicioPagamentOrder)),
                        "CondicioPagamentOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_CreditorLength) {
                context.startAttribute("", "CreditorLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _CreditorLength)), "CreditorLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_CreditorOrder) {
                context.startAttribute("", "CreditorOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _CreditorOrder)), "CreditorOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_DadesPagadorAlternatiuLength) {
                context.startAttribute("", "DadesPagadorAlternatiuLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _DadesPagadorAlternatiuLength)),
                        "DadesPagadorAlternatiuLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_DadesPagadorAlternatiuOrder) {
                context.startAttribute("", "DadesPagadorAlternatiuOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _DadesPagadorAlternatiuOrder)),
                        "DadesPagadorAlternatiuOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_DataBaseLength) {
                context.startAttribute("", "DataBaseLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _DataBaseLength)), "DataBaseLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_DataBaseOrder) {
                context.startAttribute("", "DataBaseOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _DataBaseOrder)), "DataBaseOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_FonsLength) {
                context.startAttribute("", "FonsLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _FonsLength)), "FonsLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_FonsOrder) {
                context.startAttribute("", "FonsOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _FonsOrder)), "FonsOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ImportFieldType) {
                context.startAttribute("", "ImportFieldType");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ImportFieldType)), "ImportFieldType");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ImportImpostFieldType) {
                context.startAttribute("", "ImportImpostFieldType");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ImportImpostFieldType)),
                        "ImportImpostFieldType");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ImportImpostLength) {
                context.startAttribute("", "ImportImpostLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ImportImpostLength)), "ImportImpostLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ImportImpostOrder) {
                context.startAttribute("", "ImportImpostOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ImportImpostOrder)), "ImportImpostOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ImportLength) {
                context.startAttribute("", "ImportLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ImportLength)), "ImportLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ImportOrder) {
                context.startAttribute("", "ImportOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ImportOrder)), "ImportOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_IndicadorIVALength) {
                context.startAttribute("", "IndicadorIVALength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _IndicadorIVALength)), "IndicadorIVALength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_IndicadorIVAOrder) {
                context.startAttribute("", "IndicadorIVAOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _IndicadorIVAOrder)), "IndicadorIVAOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_NExpedientLength) {
                context.startAttribute("", "NExpedientLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _NExpedientLength)), "NExpedientLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_NExpedientOrder) {
                context.startAttribute("", "NExpedientOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _NExpedientOrder)), "NExpedientOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_PagadorAlternatiuLength) {
                context.startAttribute("", "PagadorAlternatiuLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _PagadorAlternatiuLength)),
                        "PagadorAlternatiuLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_PagadorAlternatiuOrder) {
                context.startAttribute("", "PagadorAlternatiuOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _PagadorAlternatiuOrder)),
                        "PagadorAlternatiuOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_PosicioLength) {
                context.startAttribute("", "PosicioLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _PosicioLength)), "PosicioLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_PosicioOrder) {
                context.startAttribute("", "PosicioOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _PosicioOrder)), "PosicioOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_PosicioPressupostariaLength) {
                context.startAttribute("", "PosicioPressupostariaLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _PosicioPressupostariaLength)),
                        "PosicioPressupostariaLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_PosicioPressupostariaOrder) {
                context.startAttribute("", "PosicioPressupostariaOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _PosicioPressupostariaOrder)),
                        "PosicioPressupostariaOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ReferenciaLength) {
                context.startAttribute("", "ReferenciaLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ReferenciaLength)), "ReferenciaLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ReferenciaOrder) {
                context.startAttribute("", "ReferenciaOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ReferenciaOrder)), "ReferenciaOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_RegioLength) {
                context.startAttribute("", "RegioLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _RegioLength)), "RegioLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_RegioOrder) {
                context.startAttribute("", "RegioOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _RegioOrder)), "RegioOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ReservaFondosLength) {
                context.startAttribute("", "ReservaFondosLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ReservaFondosLength)), "ReservaFondosLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ReservaFondosOrder) {
                context.startAttribute("", "ReservaFondosOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ReservaFondosOrder)), "ReservaFondosOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TextDocumentLength) {
                context.startAttribute("", "TextDocumentLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TextDocumentLength)), "TextDocumentLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TextDocumentOrder) {
                context.startAttribute("", "TextDocumentOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TextDocumentOrder)), "TextDocumentOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TextLength) {
                context.startAttribute("", "TextLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TextLength)), "TextLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TextOrder) {
                context.startAttribute("", "TextOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TextOrder)), "TextOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TipusBancInterlocutorLength) {
                context.startAttribute("", "TipusBancInterlocutorLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TipusBancInterlocutorLength)),
                        "TipusBancInterlocutorLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TipusBancInterlocutorOrder) {
                context.startAttribute("", "TipusBancInterlocutorOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TipusBancInterlocutorOrder)),
                        "TipusBancInterlocutorOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TipusRegistreLength) {
                context.startAttribute("", "TipusRegistreLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TipusRegistreLength)), "TipusRegistreLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TipusRegistreOrder) {
                context.startAttribute("", "TipusRegistreOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TipusRegistreOrder)), "TipusRegistreOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ViaPagamentLength) {
                context.startAttribute("", "ViaPagamentLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ViaPagamentLength)), "ViaPagamentLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ViaPagamentOrder) {
                context.startAttribute("", "ViaPagamentOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ViaPagamentOrder)), "ViaPagamentOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_Order) {
                context.startAttribute("", "order");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _Order)), "Order");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }
        }

        public void serializeURIs(
            net.gencat.gecat.batch.DocumentsOHelper.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
        }

        public java.lang.Class getPrimaryInterface() {
            return (net.gencat.gecat.batch.DocumentsOHelper.DadesPosicioType.DadaPosicioType.class);
        }

        public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
            if (schemaFragment == null) {
                schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                        "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                        "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                        "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                        "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                        "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~" +
                        "\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                        "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~" +
                        "\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                        "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~" +
                        "\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                        "sq\u0000~\u0000\u0000ppsr\u0000\u001dcom.sun.msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001pp" +
                        "sr\u0000 com.sun.msv.grammar.AttributeExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000" +
                        "\tnameClasst\u0000\u001fLcom/sun/msv/grammar/NameClass;xq\u0000~\u0000\u0003sr\u0000\u0011java.l" +
                        "ang.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000\u001bcom.sun.msv.grammar.Da" +
                        "taExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatype/Datatype;L\u0000\u0006ex" +
                        "ceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util/StringPair;xq\u0000~\u0000\u0003ppsr\u0000 " +
                        "com.sun.msv.datatype.xsd.IntType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000+com.sun.msv.d" +
                        "atatype.xsd.IntegerDerivedType\u0099\u00f1]\u0090&6k\u00be\u0002\u0000\u0001L\u0000\nbaseFacetst\u0000)Lco" +
                        "m/sun/msv/datatype/xsd/XSDatatypeImpl;xr\u0000*com.sun.msv.dataty" +
                        "pe.xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datatype." +
                        "xsd.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype.xsd.XSDa" +
                        "tatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUrit\u0000\u0012Ljava/lang/String;L\u0000\b" +
                        "typeNameq\u0000~\u0000JL\u0000\nwhiteSpacet\u0000.Lcom/sun/msv/datatype/xsd/White" +
                        "SpaceProcessor;xpt\u0000 http://www.w3.org/2001/XMLSchemat\u0000\u0003intsr" +
                        "\u00005com.sun.msv.datatype.xsd.WhiteSpaceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000" +
                        "\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datatype.xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000" +
                        "\u0000\u0001\u0002\u0000\u0000xpsr\u0000*com.sun.msv.datatype.xsd.MaxInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000" +
                        "\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.datatype.xsd.RangeFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\nlim" +
                        "itValuet\u0000\u0012Ljava/lang/Object;xr\u00009com.sun.msv.datatype.xsd.Dat" +
                        "aTypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*com.sun.msv.data" +
                        "type.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFacetFixedZ\u0000\u0012needV" +
                        "alueCheckFlagL\u0000\bbaseTypeq\u0000~\u0000FL\u0000\fconcreteTypet\u0000\'Lcom/sun/msv/" +
                        "datatype/xsd/ConcreteType;L\u0000\tfacetNameq\u0000~\u0000Jxq\u0000~\u0000Ippq\u0000~\u0000Q\u0000\u0001sr" +
                        "\u0000*com.sun.msv.datatype.xsd.MinInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000" +
                        "Sppq\u0000~\u0000Q\u0000\u0000sr\u0000!com.sun.msv.datatype.xsd.LongType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq" +
                        "\u0000~\u0000Eq\u0000~\u0000Mt\u0000\u0004longq\u0000~\u0000Qsq\u0000~\u0000Rppq\u0000~\u0000Q\u0000\u0001sq\u0000~\u0000Yppq\u0000~\u0000Q\u0000\u0000sr\u0000$com.s" +
                        "un.msv.datatype.xsd.IntegerType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Eq\u0000~\u0000Mt\u0000\u0007inte" +
                        "gerq\u0000~\u0000Qsr\u0000,com.sun.msv.datatype.xsd.FractionDigitsFacet\u0000\u0000\u0000\u0000" +
                        "\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scalexr\u0000;com.sun.msv.datatype.xsd.DataTypeWithLexi" +
                        "calConstraintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000Vppq\u0000~\u0000Q\u0001\u0000sr\u0000#com.sun.msv." +
                        "datatype.xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Gq\u0000~\u0000Mt\u0000\u0007decimalq\u0000~\u0000Q" +
                        "q\u0000~\u0000gt\u0000\u000efractionDigits\u0000\u0000\u0000\u0000q\u0000~\u0000at\u0000\fminInclusivesr\u0000\u000ejava.lang." +
                        "Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010java.lang.Number\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp\u0080\u0000\u0000\u0000" +
                        "\u0000\u0000\u0000\u0000q\u0000~\u0000at\u0000\fmaxInclusivesq\u0000~\u0000k\u007f\u00ff\u00ff\u00ff\u00ff\u00ff\u00ff\u00ffq\u0000~\u0000\\q\u0000~\u0000jsr\u0000\u0011java.lan" +
                        "g.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000l\u0080\u0000\u0000\u0000q\u0000~\u0000\\q\u0000~\u0000nsq\u0000~\u0000p\u007f\u00ff\u00ff\u00ffsr" +
                        "\u00000com.sun.msv.grammar.Expression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000" +
                        "\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalN" +
                        "ameq\u0000~\u0000JL\u0000\fnamespaceURIq\u0000~\u0000Jxpq\u0000~\u0000Nq\u0000~\u0000Msr\u0000#com.sun.msv.gram" +
                        "mar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000JL\u0000\fnamespaceU" +
                        "RIq\u0000~\u0000Jxr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpt\u0000\u0010Assi" +
                        "gnacioLengtht\u0000\u0000sr\u00000com.sun.msv.grammar.Expression$EpsilonExp" +
                        "ression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000>\u0001q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000" +
                        "Csq\u0000~\u0000wt\u0000\u000fAssignacioOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000C" +
                        "sq\u0000~\u0000wt\u0000\u0016BloqueigPagamentLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?" +
                        "pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0015BloqueigPagamentOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;" +
                        "q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0014CalcularImpostLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq" +
                        "\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0013CalcularImpostOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009p" +
                        "psq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0012CentreGestorLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u0000" +
                        "9ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0011CentreGestorOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~" +
                        "\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0011CompteMajorLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000" +
                        "~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0010CompteMajorOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000" +
                        "~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0016CondicioPagamentLengthq\u0000~\u0000{q\u0000" +
                        "~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0015CondicioPagamentOrderq\u0000" +
                        "~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u000eCreditorLengthq\u0000~\u0000" +
                        "{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\rCreditorOrderq\u0000~\u0000{q\u0000" +
                        "~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u001cDadesPagadorAlternatiuL" +
                        "engthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u001bDadesPagado" +
                        "rAlternatiuOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u000e" +
                        "DataBaseLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\rDa" +
                        "taBaseOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\nFonsL" +
                        "engthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\tFonsOrderq\u0000" +
                        "~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u000fImportFieldTypeq\u0000~" +
                        "\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0015ImportImpostFieldTy" +
                        "peq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0012ImportImpostLe" +
                        "ngthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0011ImportImpost" +
                        "Orderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\fImportLengt" +
                        "hq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u000bImportOrderq\u0000~\u0000" +
                        "{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0012IndicadorIVALengthq\u0000" +
                        "~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0011IndicadorIVAOrderq" +
                        "\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0010NExpedientLengthq" +
                        "\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u000fNExpedientOrderq\u0000" +
                        "~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0017PagadorAlternatiuL" +
                        "engthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0016PagadorAlte" +
                        "rnatiuOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\rPosic" +
                        "ioLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\fPosicioO" +
                        "rderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u001bPosicioPress" +
                        "upostariaLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u001aP" +
                        "osicioPressupostariaOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000C" +
                        "sq\u0000~\u0000wt\u0000\u0010ReferenciaLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000C" +
                        "sq\u0000~\u0000wt\u0000\u000fReferenciaOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Cs" +
                        "q\u0000~\u0000wt\u0000\u000bRegioLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000w" +
                        "t\u0000\nRegioOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0013Res" +
                        "ervaFondosLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0012" +
                        "ReservaFondosOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt" +
                        "\u0000\u0012TextDocumentLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000" +
                        "wt\u0000\u0011TextDocumentOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~" +
                        "\u0000wt\u0000\nTextLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\tT" +
                        "extOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u001bTipusBan" +
                        "cInterlocutorLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000w" +
                        "t\u0000\u001aTipusBancInterlocutorOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000?pq" +
                        "\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0013TipusRegistreLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000~\u0000" +
                        "?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0012TipusRegistreOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q\u0000" +
                        "~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0011ViaPagamentLengthq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q" +
                        "\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0010ViaPagamentOrderq\u0000~\u0000{q\u0000~\u0000}sq\u0000~\u00009ppsq\u0000~\u0000;q" +
                        "\u0000~\u0000?pq\u0000~\u0000Csq\u0000~\u0000wt\u0000\u0005orderq\u0000~\u0000{q\u0000~\u0000}sr\u0000\"com.sun.msv.grammar.Ex" +
                        "pressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/sun/msv/grammar/Ex" +
                        "pressionPool$ClosedHash;xpsr\u0000-com.sun.msv.grammar.Expression" +
                        "Pool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamVersionL\u0000\u0006parentt" +
                        "\u0000$Lcom/sun/msv/grammar/ExpressionPool;xp\u0000\u0000\u0000i\u0001pq\u0000~\u0001\u001fq\u0000~\u0001#q\u0000~\u0000" +
                        "-q\u0000~\u0000\u0016q\u0000~\u0000\u001eq\u0000~\u0001\u001bq\u0000~\u0000\u001bq\u0000~\u00008q\u0000~\u0001\u0007q\u0000~\u0000\u0005q\u0000~\u00001q\u0000~\u0000%q\u0000~\u0000\u00e3q\u0000~\u0000*q\u0000~\u0000" +
                        "\"q\u0000~\u0000\u000bq\u0000~\u0000\u00dbq\u0000~\u0001+q\u0000~\u0001;q\u0000~\u0000\nq\u0000~\u00017q\u0000~\u0000$q\u0000~\u0000\u00e7q\u0000~\u0000&q\u0000~\u0000\u00f7q\u0000~\u0000\u00ebq\u0000~\u0000" +
                        "\u0018q\u0000~\u0000\u00efq\u0000~\u0000\u0093q\u0000~\u0000\fq\u0000~\u0000.q\u0000~\u0001\u0013q\u0000~\u0000\u007fq\u0000~\u0000\u00f3q\u0000~\u0000 q\u0000~\u0000\u001fq\u0000~\u0000\u00b7q\u0000~\u00005q\u0000~\u0000" +
                        "\'q\u0000~\u0000\u00a7q\u0000~\u0000\u000eq\u0000~\u0001Cq\u0000~\u0000\u008fq\u0000~\u0000\u0011q\u0000~\u0000\u0083q\u0000~\u0000\tq\u0000~\u0000\bq\u0000~\u0000\u00bfq\u0000~\u0000\u00dfq\u0000~\u0000\u009bq\u0000~\u0000" +
                        "\u00d3q\u0000~\u0001\u0003q\u0000~\u0000\u00cbq\u0000~\u0000\u0017q\u0000~\u0001\u000bq\u0000~\u0000\u00b3q\u0000~\u0000\u0007q\u0000~\u0000\u0087q\u0000~\u00013q\u0000~\u0000\u00cfq\u0000~\u0000)q\u0000~\u00000q\u0000~\u0001" +
                        "Kq\u0000~\u0000\u000fq\u0000~\u0000,q\u0000~\u0000\u0015q\u0000~\u0000\u00abq\u0000~\u0000\u00c7q\u0000~\u0001Gq\u0000~\u0000\rq\u0000~\u0000\u001aq\u0000~\u0000\u0013q\u0000~\u0000\u0006q\u0000~\u0000\u0012q\u0000~\u0001" +
                        "\u0017q\u0000~\u0000\u0010q\u0000~\u0000\u0014q\u0000~\u0000\u00a3q\u0000~\u0000(q\u0000~\u00007q\u0000~\u00002q\u0000~\u00006q\u0000~\u0001\u000fq\u0000~\u0000\u008bq\u0000~\u0000\u0097q\u0000~\u0000\u00c3q\u0000~\u0001" +
                        "/q\u0000~\u0001?q\u0000~\u0000\u0019q\u0000~\u0000+q\u0000~\u0000\u00ffq\u0000~\u0000\u00bbq\u0000~\u0001\'q\u0000~\u00003q\u0000~\u0000\u001cq\u0000~\u0000\u001dq\u0000~\u0000:q\u0000~\u0000#q\u0000~\u0000" +
                        "\u009fq\u0000~\u0000!q\u0000~\u0000/q\u0000~\u0000\u00afq\u0000~\u0000\u00d7q\u0000~\u0000\u00fbq\u0000~\u00004x"));
            }

            return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
        }
    }
}
