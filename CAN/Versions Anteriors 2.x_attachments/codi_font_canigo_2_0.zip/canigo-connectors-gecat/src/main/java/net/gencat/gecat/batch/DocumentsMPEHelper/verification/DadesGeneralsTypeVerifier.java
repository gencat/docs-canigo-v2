/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsMPEHelper.verification;

public class DadesGeneralsTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master) {
        if (true) {
            // If left exists
            // No check for primitive values
            checkClasseDocumentLength(parentLocator, handler, master,
                new java.lang.Integer(master.getClasseDocumentLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkClasseDocumentOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getClasseDocumentOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkDadesPosicioLength(parentLocator, handler, master,
                new java.lang.Integer(master.getDadesPosicioLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkDadesPosicioOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getDadesPosicioOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkDataComptLength(parentLocator, handler, master,
                new java.lang.Integer(master.getDataComptLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkDataComptOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getDataComptOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkDataConversioLength(parentLocator, handler, master,
                new java.lang.Integer(master.getDataConversioLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkDataConversioOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getDataConversioOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkDataDocumentLength(parentLocator, handler, master,
                new java.lang.Integer(master.getDataDocumentLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkDataDocumentOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getDataDocumentOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkMonedaLength(parentLocator, handler, master,
                new java.lang.Integer(master.getMonedaLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkMonedaOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getMonedaOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkNDocumentLength(parentLocator, handler, master,
                new java.lang.Integer(master.getNDocumentLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkNDocumentOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getNDocumentOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkSocietatLength(parentLocator, handler, master,
                new java.lang.Integer(master.getSocietatLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkSocietatOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getSocietatOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkTipusCanviLength(parentLocator, handler, master,
                new java.lang.Integer(master.getTipusCanviLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkTipusCanviOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getTipusCanviOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkTipusRegistreLength(parentLocator, handler, master,
                new java.lang.Integer(master.getTipusRegistreLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkTipusRegistreOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getTipusRegistreOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkTransaccioLength(parentLocator, handler, master,
                new java.lang.Integer(master.getTransaccioLength()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkTransaccioOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getTransaccioOrder()));
        }

        if (true) {
            // If left exists
            // No check for primitive values
            checkOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getOrder()));
        }
    }

    public void checkClasseDocumentLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ClasseDocumentLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "ClasseDocumentLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkDataDocumentLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DataDocumentLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DataDocumentLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkNDocumentLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "NDocumentLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "NDocumentLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkTipusRegistreOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusRegistreOrder"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "TipusRegistreOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkDataDocumentOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DataDocumentOrder"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DataDocumentOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Order"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Order"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkDataConversioOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DataConversioOrder"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DataConversioOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkDataComptLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DataComptLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DataComptLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkTipusRegistreLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusRegistreLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "TipusRegistreLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkDataConversioLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DataConversioLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DataConversioLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkDadesPosicioOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DadesPosicioOrder"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DadesPosicioOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkMonedaLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "MonedaLength"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "MonedaLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkTransaccioOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TransaccioOrder"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "TransaccioOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkTransaccioLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TransaccioLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "TransaccioLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkDadesPosicioLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DadesPosicioLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DadesPosicioLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkNDocumentOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "NDocumentOrder"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "NDocumentOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkSocietatOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "SocietatOrder"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "SocietatOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkTipusCanviLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusCanviLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "TipusCanviLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkClasseDocumentOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ClasseDocumentOrder"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "ClasseDocumentOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkTipusCanviOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusCanviOrder"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "TipusCanviOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkMonedaOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "MonedaOrder"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "MonedaOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkDataComptOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DataComptOrder"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DataComptOrder"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkSocietatLength(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "SocietatLength"),
                            problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "SocietatLength"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
        check(parentLocator, handler,
            ((net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType) object));
    }

    public void check(javax.xml.bind.ValidationEventHandler handler,
        java.lang.Object object) {
        check(null, handler,
            ((net.gencat.gecat.batch.DocumentsMPEHelper.DadesGeneralsType) object));
    }
}
