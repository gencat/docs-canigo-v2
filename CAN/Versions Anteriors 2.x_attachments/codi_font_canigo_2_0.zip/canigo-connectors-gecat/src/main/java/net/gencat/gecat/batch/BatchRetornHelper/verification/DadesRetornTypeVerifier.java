/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.BatchRetornHelper.verification;

public class DadesRetornTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType master) {
        if (true) {
            // If left exists
            // No check for primitive values
            checkOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getOrder()));
        }

        if (null == master.getDadaRetorn()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "DadaRetorn"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check count
            if (master.getDadaRetorn().size() < 1) {
                // Report minimum of occurences violated
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DadaRetorn"),
                        new de.fzi.dbs.verification.event.structure.TooFewElementsProblem(
                            master.getDadaRetorn().size(), 1)));
            }

            if (master.getDadaRetorn().size() > 2) {
                // Report maximum of occurences violated
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DadaRetorn"),
                        new de.fzi.dbs.verification.event.structure.TooManyElementsProblem(
                            master.getDadaRetorn().size(), 2)));
            }

            // Check value
            checkDadaRetorn(parentLocator, handler, master,
                master.getDadaRetorn());
        }
    }

    public void checkDadaRetorn(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType master,
        java.util.List values) {
        for (int index = 0; (index < values.size()); index++) {
            java.lang.Object item = values.get(index);
            checkDadaRetorn(parentLocator, handler, master, index, item);
        }
    }

    public void checkDadaRetorn(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType master,
        int index, java.lang.Object value) {
        if (value instanceof net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType) {
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType realValue =
                ((net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType) value);

            {
                // Check complex value
                net.gencat.gecat.batch.BatchRetornHelper.verification.DadesRetornTypeVerifier.DadaRetornTypeVerifier verifier =
                    new net.gencat.gecat.batch.BatchRetornHelper.verification.DadesRetornTypeVerifier.DadaRetornTypeVerifier();
                verifier.check(new de.fzi.dbs.verification.event.EntryLocator(
                        parentLocator, master, "DadaRetorn", index), handler,
                    realValue);
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.EntryLocator(
                            parentLocator, master, "DadaRetorn", index),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Order"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Order"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
        check(parentLocator, handler,
            ((net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType) object));
    }

    public void check(javax.xml.bind.ValidationEventHandler handler,
        java.lang.Object object) {
        check(null, handler,
            ((net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType) object));
    }

    public static class DadaRetornTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
        public void check(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master) {
            if (true) {
                // If left exists
                // No check for primitive values
                checkClasseDocumentLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getClasseDocumentLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkClasseDocumentOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getClasseDocumentOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkCodiPosicioErrorLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getCodiPosicioErrorLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkCodiPosicioErrorOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getCodiPosicioErrorOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkExerciciLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getExerciciLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkExerciciOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getExerciciOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkNDocumentLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getNDocumentLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkNDocumentOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getNDocumentOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkPosicioDocumentLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getPosicioDocumentLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkPosicioDocumentOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getPosicioDocumentOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkSocietatFiLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getSocietatFiLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkSocietatFiOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getSocietatFiOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkStatusDocumentLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getStatusDocumentLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkStatusDocumentOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getStatusDocumentOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTextErrorLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getTextErrorLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTextErrorOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getTextErrorOrder()));
            }
        }

        public void checkClasseDocumentLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "ClasseDocumentLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ClasseDocumentLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkExerciciOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ExerciciOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ExerciciOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTextErrorOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TextErrorOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TextErrorOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkExerciciLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ExerciciLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ExerciciLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkNDocumentLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "NDocumentLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "NDocumentLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCodiPosicioErrorOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "CodiPosicioErrorOrder"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CodiPosicioErrorOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkStatusDocumentOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "StatusDocumentOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "StatusDocumentOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkCodiPosicioErrorLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "CodiPosicioErrorLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "CodiPosicioErrorLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkSocietatFiOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "SocietatFiOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "SocietatFiOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkStatusDocumentLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "StatusDocumentLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "StatusDocumentLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTextErrorLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TextErrorLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TextErrorLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkPosicioDocumentOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "PosicioDocumentOrder"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "PosicioDocumentOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkPosicioDocumentLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "PosicioDocumentLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "PosicioDocumentLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkNDocumentOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "NDocumentOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "NDocumentOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkSocietatFiLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "SocietatFiLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "SocietatFiLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkClasseDocumentOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ClasseDocumentOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ClasseDocumentOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void check(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            java.lang.Object object) {
            check(parentLocator, handler,
                ((net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType) object));
        }

        public void check(javax.xml.bind.ValidationEventHandler handler,
            java.lang.Object object) {
            check(null, handler,
                ((net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType) object));
        }
    }
}
