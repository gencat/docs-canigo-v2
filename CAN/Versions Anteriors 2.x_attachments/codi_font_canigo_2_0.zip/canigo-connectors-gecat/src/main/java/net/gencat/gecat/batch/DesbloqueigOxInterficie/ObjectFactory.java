/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DesbloqueigOxInterficie;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the net.gencat.gecat.batch.DesbloqueigOxInterficie package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 *
 */
public class ObjectFactory extends net.gencat.gecat.batch.DesbloqueigOxInterficie.impl.runtime.DefaultJAXBContextImpl {
    private static java.util.HashMap defaultImplementations = new java.util.HashMap(16,
            0.75F);
    private static java.util.HashMap rootTagMap = new java.util.HashMap();
    public final static net.gencat.gecat.batch.DesbloqueigOxInterficie.impl.runtime.GrammarInfo grammarInfo =
        new net.gencat.gecat.batch.DesbloqueigOxInterficie.impl.runtime.GrammarInfoImpl(rootTagMap,
            defaultImplementations,
            (net.gencat.gecat.batch.DesbloqueigOxInterficie.ObjectFactory.class));
    public final static java.lang.Class version = (net.gencat.gecat.batch.DesbloqueigOxInterficie.impl.JAXBVersion.class);

    static {
        defaultImplementations.put((net.gencat.gecat.batch.DesbloqueigOxInterficie.DesbloqueigOxInterficie.class),
            "net.gencat.gecat.batch.DesbloqueigOxInterficie.impl.DesbloqueigOxInterficieImpl");
        defaultImplementations.put((net.gencat.gecat.batch.DesbloqueigOxInterficie.DadesType.class),
            "net.gencat.gecat.batch.DesbloqueigOxInterficie.impl.DadesTypeImpl");
        defaultImplementations.put((net.gencat.gecat.batch.DesbloqueigOxInterficie.DesbloqueigOxInterficieType.class),
            "net.gencat.gecat.batch.DesbloqueigOxInterficie.impl.DesbloqueigOxInterficieTypeImpl");
    }

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: net.gencat.gecat.batch.DesbloqueigOxInterficie
     *
     */
    public ObjectFactory() {
        super(grammarInfo);
    }

    /**
     * Create an instance of the specified Java content interface.
     *
     * @param javaContentInterface
     *     the Class object of the javacontent interface to instantiate
     * @return
     *     a new instance
     * @throws JAXBException
     *     if an error occurs
     */
    public java.lang.Object newInstance(java.lang.Class javaContentInterface)
        throws javax.xml.bind.JAXBException {
        return super.newInstance(javaContentInterface);
    }

    /**
     * Get the specified property. This method can only be
     * used to get provider specific properties.
     * Attempting to get an undefined property will result
     * in a PropertyException being thrown.
     *
     * @param name
     *     the name of the property to retrieve
     * @return
     *     the value of the requested property
     * @throws PropertyException
     *     when there is an error retrieving the given property or value
     */
    public java.lang.Object getProperty(java.lang.String name)
        throws javax.xml.bind.PropertyException {
        return super.getProperty(name);
    }

    /**
     * Set the specified property. This method can only be
     * used to set provider specific properties.
     * Attempting to set an undefined property will result
     * in a PropertyException being thrown.
     *
     * @param value
     *     the value of the property to be set
     * @param name
     *     the name of the property to retrieve
     * @throws PropertyException
     *     when there is an error processing the given property or value
     */
    public void setProperty(java.lang.String name, java.lang.Object value)
        throws javax.xml.bind.PropertyException {
        super.setProperty(name, value);
    }

    /**
     * Create an instance of DesbloqueigOxInterficie
     *
     * @throws JAXBException
     *     if an error occurs
     */
    public net.gencat.gecat.batch.DesbloqueigOxInterficie.DesbloqueigOxInterficie createDesbloqueigOxInterficie()
        throws javax.xml.bind.JAXBException {
        return new net.gencat.gecat.batch.DesbloqueigOxInterficie.impl.DesbloqueigOxInterficieImpl();
    }

    /**
     * Create an instance of DadesType
     *
     * @throws JAXBException
     *     if an error occurs
     */
    public net.gencat.gecat.batch.DesbloqueigOxInterficie.DadesType createDadesType()
        throws javax.xml.bind.JAXBException {
        return new net.gencat.gecat.batch.DesbloqueigOxInterficie.impl.DadesTypeImpl();
    }

    /**
     * Create an instance of DesbloqueigOxInterficieType
     *
     * @throws JAXBException
     *     if an error occurs
     */
    public net.gencat.gecat.batch.DesbloqueigOxInterficie.DesbloqueigOxInterficieType createDesbloqueigOxInterficieType()
        throws javax.xml.bind.JAXBException {
        return new net.gencat.gecat.batch.DesbloqueigOxInterficie.impl.DesbloqueigOxInterficieTypeImpl();
    }
}
