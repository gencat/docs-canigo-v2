/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsMPE;


/**
 * Java content class for RetencionsType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsMPE.xsd line 458)
 * <p>
 * <pre>
 * &lt;complexType name="RetencionsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DadaRetencio" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TipusRegistre">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="1"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="IndicadorRetencio">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="2"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="ImportBase">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="13"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="ImportRetencio">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="13"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface RetencionsType {
    /**
     * Gets the value of the DadaRetencio property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the DadaRetencio property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDadaRetencio().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link net.gencat.gecat.batch.DocumentsMPE.RetencionsType.DadaRetencioType}
     *
     */
    java.util.List getDadaRetencio();

    /**
     * Java content class for anonymous complex type.
     *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsMPE.xsd line 461)
     * <p>
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TipusRegistre">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="1"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="IndicadorRetencio">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="2"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="ImportBase">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="13"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="ImportRetencio">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="13"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     *
     */
    public interface DadaRetencioType {
        /**
         * Gets the value of the importBase property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getImportBase();

        /**
         * Sets the value of the importBase property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setImportBase(java.lang.String value);

        /**
         * Gets the value of the importRetencio property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getImportRetencio();

        /**
         * Sets the value of the importRetencio property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setImportRetencio(java.lang.String value);

        /**
         * Gets the value of the indicadorRetencio property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getIndicadorRetencio();

        /**
         * Sets the value of the indicadorRetencio property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setIndicadorRetencio(java.lang.String value);

        /**
         * Gets the value of the order property.
         *
         */
        int getOrder();

        /**
         * Sets the value of the order property.
         *
         */
        void setOrder(int value);

        /**
         * Gets the value of the tipusRegistre property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getTipusRegistre();

        /**
         * Sets the value of the tipusRegistre property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setTipusRegistre(java.lang.String value);
    }
}
