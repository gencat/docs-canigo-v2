/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DesbloqueigOxInterficie;


/**
 * Java content class for DadesType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DesbloqueigOxInterficie.xsd line 35)
 * <p>
 * <pre>
 * &lt;complexType name="DadesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Societat">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="4"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="Transaccio">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="20"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="NDocument">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="10"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="LiniaDocument">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="3"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface DadesType {
    /**
     * Gets the value of the transaccio property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getTransaccio();

    /**
     * Sets the value of the transaccio property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setTransaccio(java.lang.String value);

    /**
     * Gets the value of the nDocument property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getNDocument();

    /**
     * Sets the value of the nDocument property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setNDocument(java.lang.String value);

    /**
     * Gets the value of the societat property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getSocietat();

    /**
     * Sets the value of the societat property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setSocietat(java.lang.String value);

    /**
     * Gets the value of the liniaDocument property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getLiniaDocument();

    /**
     * Sets the value of the liniaDocument property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setLiniaDocument(java.lang.String value);
}
