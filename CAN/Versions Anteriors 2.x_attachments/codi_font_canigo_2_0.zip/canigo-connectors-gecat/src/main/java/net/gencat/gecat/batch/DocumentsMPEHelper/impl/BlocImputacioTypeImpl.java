/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsMPEHelper.impl;

public class BlocImputacioTypeImpl implements net.gencat.gecat.batch.DocumentsMPEHelper.BlocImputacioType,
    com.sun.xml.bind.JAXBObject,
    net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.XMLSerializable,
    net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.ValidatableObject {
    public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsMPEHelper.impl.JAXBVersion.class);
    private static com.sun.msv.grammar.Grammar schemaFragment;
    protected boolean has_TipusRegistreLength;
    protected int _TipusRegistreLength;
    protected boolean has_TipusRegistreOrder;
    protected int _TipusRegistreOrder;
    protected boolean has_VendorLength;
    protected int _VendorLength;
    protected boolean has_Order;
    protected int _Order;
    protected boolean has_ReferenceLength;
    protected int _ReferenceLength;
    protected boolean has_ReferenceOrder;
    protected int _ReferenceOrder;
    protected boolean has_VendorOrder;
    protected int _VendorOrder;

    private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
        return (net.gencat.gecat.batch.DocumentsMPEHelper.BlocImputacioType.class);
    }

    public int getTipusRegistreLength() {
        if (!has_TipusRegistreLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "1"));
        } else {
            return _TipusRegistreLength;
        }
    }

    public void setTipusRegistreLength(int value) {
        _TipusRegistreLength = value;
        has_TipusRegistreLength = true;
    }

    public int getTipusRegistreOrder() {
        if (!has_TipusRegistreOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "1"));
        } else {
            return _TipusRegistreOrder;
        }
    }

    public void setTipusRegistreOrder(int value) {
        _TipusRegistreOrder = value;
        has_TipusRegistreOrder = true;
    }

    public int getVendorLength() {
        if (!has_VendorLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "10"));
        } else {
            return _VendorLength;
        }
    }

    public void setVendorLength(int value) {
        _VendorLength = value;
        has_VendorLength = true;
    }

    public int getOrder() {
        if (!has_Order) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "3"));
        } else {
            return _Order;
        }
    }

    public void setOrder(int value) {
        _Order = value;
        has_Order = true;
    }

    public int getReferenceLength() {
        if (!has_ReferenceLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "16"));
        } else {
            return _ReferenceLength;
        }
    }

    public void setReferenceLength(int value) {
        _ReferenceLength = value;
        has_ReferenceLength = true;
    }

    public int getReferenceOrder() {
        if (!has_ReferenceOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "2"));
        } else {
            return _ReferenceOrder;
        }
    }

    public void setReferenceOrder(int value) {
        _ReferenceOrder = value;
        has_ReferenceOrder = true;
    }

    public int getVendorOrder() {
        if (!has_VendorOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "3"));
        } else {
            return _VendorOrder;
        }
    }

    public void setVendorOrder(int value) {
        _VendorOrder = value;
        has_VendorOrder = true;
    }

    public void serializeBody(
        net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
    }

    public void serializeAttributes(
        net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        if (has_ReferenceLength) {
            context.startAttribute("", "ReferenceLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _ReferenceLength)), "ReferenceLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_ReferenceOrder) {
            context.startAttribute("", "ReferenceOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _ReferenceOrder)), "ReferenceOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_TipusRegistreLength) {
            context.startAttribute("", "TipusRegistreLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _TipusRegistreLength)), "TipusRegistreLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_TipusRegistreOrder) {
            context.startAttribute("", "TipusRegistreOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _TipusRegistreOrder)), "TipusRegistreOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_VendorLength) {
            context.startAttribute("", "VendorLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _VendorLength)), "VendorLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_VendorOrder) {
            context.startAttribute("", "VendorOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _VendorOrder)), "VendorOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_Order) {
            context.startAttribute("", "order");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _Order)), "Order");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }
    }

    public void serializeURIs(
        net.gencat.gecat.batch.DocumentsMPEHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
    }

    public java.lang.Class getPrimaryInterface() {
        return (net.gencat.gecat.batch.DocumentsMPEHelper.BlocImputacioType.class);
    }

    public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
        if (schemaFragment == null) {
            schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                    "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                    "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                    "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                    "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                    "sr\u0000\u001dcom.sun.msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsr\u0000 com." +
                    "sun.msv.grammar.AttributeExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameCla" +
                    "sst\u0000\u001fLcom/sun/msv/grammar/NameClass;xq\u0000~\u0000\u0003sr\u0000\u0011java.lang.Bool" +
                    "ean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000" +
                    "\u0002L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util/StringPair;xq\u0000~\u0000\u0003ppsr\u0000 com.sun." +
                    "msv.datatype.xsd.IntType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000+com.sun.msv.datatype." +
                    "xsd.IntegerDerivedType\u0099\u00f1]\u0090&6k\u00be\u0002\u0000\u0001L\u0000\nbaseFacetst\u0000)Lcom/sun/ms" +
                    "v/datatype/xsd/XSDatatypeImpl;xr\u0000*com.sun.msv.datatype.xsd.B" +
                    "uiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datatype.xsd.Conc" +
                    "reteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype.xsd.XSDatatypeIm" +
                    "pl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUrit\u0000\u0012Ljava/lang/String;L\u0000\btypeName" +
                    "q\u0000~\u0000\u001cL\u0000\nwhiteSpacet\u0000.Lcom/sun/msv/datatype/xsd/WhiteSpacePro" +
                    "cessor;xpt\u0000 http://www.w3.org/2001/XMLSchemat\u0000\u0003intsr\u00005com.su" +
                    "n.msv.datatype.xsd.WhiteSpaceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr" +
                    "\u0000,com.sun.msv.datatype.xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xps" +
                    "r\u0000*com.sun.msv.datatype.xsd.MaxInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#" +
                    "com.sun.msv.datatype.xsd.RangeFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\nlimitValuet" +
                    "\u0000\u0012Ljava/lang/Object;xr\u00009com.sun.msv.datatype.xsd.DataTypeWit" +
                    "hValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.xsd" +
                    ".DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFacetFixedZ\u0000\u0012needValueChec" +
                    "kFlagL\u0000\bbaseTypeq\u0000~\u0000\u0018L\u0000\fconcreteTypet\u0000\'Lcom/sun/msv/datatype" +
                    "/xsd/ConcreteType;L\u0000\tfacetNameq\u0000~\u0000\u001cxq\u0000~\u0000\u001bppq\u0000~\u0000#\u0000\u0001sr\u0000*com.su" +
                    "n.msv.datatype.xsd.MinInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000%ppq\u0000~\u0000#" +
                    "\u0000\u0000sr\u0000!com.sun.msv.datatype.xsd.LongType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0017q\u0000~\u0000" +
                    "\u001ft\u0000\u0004longq\u0000~\u0000#sq\u0000~\u0000$ppq\u0000~\u0000#\u0000\u0001sq\u0000~\u0000+ppq\u0000~\u0000#\u0000\u0000sr\u0000$com.sun.msv.d" +
                    "atatype.xsd.IntegerType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0017q\u0000~\u0000\u001ft\u0000\u0007integerq\u0000~\u0000#" +
                    "sr\u0000,com.sun.msv.datatype.xsd.FractionDigitsFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I" +
                    "\u0000\u0005scalexr\u0000;com.sun.msv.datatype.xsd.DataTypeWithLexicalConst" +
                    "raintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000(ppq\u0000~\u0000#\u0001\u0000sr\u0000#com.sun.msv.datatype" +
                    ".xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0019q\u0000~\u0000\u001ft\u0000\u0007decimalq\u0000~\u0000#q\u0000~\u00009t\u0000\u000e" +
                    "fractionDigits\u0000\u0000\u0000\u0000q\u0000~\u00003t\u0000\fminInclusivesr\u0000\u000ejava.lang.Long;\u008b\u00e4\u0090" +
                    "\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010java.lang.Number\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u0000" +
                    "3t\u0000\fmaxInclusivesq\u0000~\u0000=\u007f\u00ff\u00ff\u00ff\u00ff\u00ff\u00ff\u00ffq\u0000~\u0000.q\u0000~\u0000<sr\u0000\u0011java.lang.Intege" +
                    "r\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000>\u0080\u0000\u0000\u0000q\u0000~\u0000.q\u0000~\u0000@sq\u0000~\u0000B\u007f\u00ff\u00ff\u00ffsr\u00000com.su" +
                    "n.msv.grammar.Expression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003p" +
                    "psr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000\u001c" +
                    "L\u0000\fnamespaceURIq\u0000~\u0000\u001cxpq\u0000~\u0000 q\u0000~\u0000\u001fsr\u0000#com.sun.msv.grammar.Simp" +
                    "leNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000\u001cL\u0000\fnamespaceURIq\u0000~\u0000\u001cx" +
                    "r\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpt\u0000\u000fReferenceLen" +
                    "gtht\u0000\u0000sr\u00000com.sun.msv.grammar.Expression$EpsilonExpression\u0000\u0000" +
                    "\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\u0010\u0001q\u0000~\u0000Osq\u0000~\u0000\u000bppsq\u0000~\u0000\rq\u0000~\u0000\u0011pq\u0000~\u0000\u0015sq\u0000~\u0000It\u0000" +
                    "\u000eReferenceOrderq\u0000~\u0000Mq\u0000~\u0000Osq\u0000~\u0000\u000bppsq\u0000~\u0000\rq\u0000~\u0000\u0011pq\u0000~\u0000\u0015sq\u0000~\u0000It\u0000\u0013T" +
                    "ipusRegistreLengthq\u0000~\u0000Mq\u0000~\u0000Osq\u0000~\u0000\u000bppsq\u0000~\u0000\rq\u0000~\u0000\u0011pq\u0000~\u0000\u0015sq\u0000~\u0000It" +
                    "\u0000\u0012TipusRegistreOrderq\u0000~\u0000Mq\u0000~\u0000Osq\u0000~\u0000\u000bppsq\u0000~\u0000\rq\u0000~\u0000\u0011pq\u0000~\u0000\u0015sq\u0000~\u0000" +
                    "It\u0000\fVendorLengthq\u0000~\u0000Mq\u0000~\u0000Osq\u0000~\u0000\u000bppsq\u0000~\u0000\rq\u0000~\u0000\u0011pq\u0000~\u0000\u0015sq\u0000~\u0000It\u0000\u000b" +
                    "VendorOrderq\u0000~\u0000Mq\u0000~\u0000Osq\u0000~\u0000\u000bppsq\u0000~\u0000\rq\u0000~\u0000\u0011pq\u0000~\u0000\u0015sq\u0000~\u0000It\u0000\u0005order" +
                    "q\u0000~\u0000Mq\u0000~\u0000Osr\u0000\"com.sun.msv.grammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L" +
                    "\u0000\bexpTablet\u0000/Lcom/sun/msv/grammar/ExpressionPool$ClosedHash;" +
                    "xpsr\u0000-com.sun.msv.grammar.ExpressionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003" +
                    "\u0000\u0003I\u0000\u0005countB\u0000\rstreamVersionL\u0000\u0006parentt\u0000$Lcom/sun/msv/grammar/E" +
                    "xpressionPool;xp\u0000\u0000\u0000\r\u0001pq\u0000~\u0000\bq\u0000~\u0000\tq\u0000~\u0000\u0005q\u0000~\u0000\fq\u0000~\u0000aq\u0000~\u0000\u0006q\u0000~\u0000\nq\u0000~" +
                    "\u0000Yq\u0000~\u0000]q\u0000~\u0000Uq\u0000~\u0000Qq\u0000~\u0000\u0007q\u0000~\u0000ex"));
        }

        return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
    }
}
