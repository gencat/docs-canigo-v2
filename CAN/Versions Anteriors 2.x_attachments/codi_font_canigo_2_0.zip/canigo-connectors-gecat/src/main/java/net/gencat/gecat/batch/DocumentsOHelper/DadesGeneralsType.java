/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOHelper;


/**
 * Java content class for DadesGeneralsType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsOHelper.xsd line 35)
 * <p>
 * <pre>
 * &lt;complexType name="DadesGeneralsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="ClasseDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *       &lt;attribute name="ClasseDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *       &lt;attribute name="DadesPosicioLength" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="DadesPosicioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="11" />
 *       &lt;attribute name="DataComptLength" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
 *       &lt;attribute name="DataComptOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="6" />
 *       &lt;attribute name="DataConversioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
 *       &lt;attribute name="DataConversioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="9" />
 *       &lt;attribute name="DataDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
 *       &lt;attribute name="DataDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
 *       &lt;attribute name="MonedaLength" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
 *       &lt;attribute name="MonedaOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *       &lt;attribute name="NDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *       &lt;attribute name="NDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
 *       &lt;attribute name="SocietatLength" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *       &lt;attribute name="SocietatOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="7" />
 *       &lt;attribute name="TipusCanviLength" type="{http://www.w3.org/2001/XMLSchema}int" default="9" />
 *       &lt;attribute name="TipusCanviOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
 *       &lt;attribute name="TipusRegistreLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *       &lt;attribute name="TipusRegistreOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *       &lt;attribute name="TransaccioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="20" />
 *       &lt;attribute name="TransaccioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface DadesGeneralsType {
    /**
     * Gets the value of the classeDocumentLength property.
     *
     */
    int getClasseDocumentLength();

    /**
     * Sets the value of the classeDocumentLength property.
     *
     */
    void setClasseDocumentLength(int value);

    /**
     * Gets the value of the dataDocumentLength property.
     *
     */
    int getDataDocumentLength();

    /**
     * Sets the value of the dataDocumentLength property.
     *
     */
    void setDataDocumentLength(int value);

    /**
     * Gets the value of the nDocumentLength property.
     *
     */
    int getNDocumentLength();

    /**
     * Sets the value of the nDocumentLength property.
     *
     */
    void setNDocumentLength(int value);

    /**
     * Gets the value of the tipusRegistreOrder property.
     *
     */
    int getTipusRegistreOrder();

    /**
     * Sets the value of the tipusRegistreOrder property.
     *
     */
    void setTipusRegistreOrder(int value);

    /**
     * Gets the value of the dataDocumentOrder property.
     *
     */
    int getDataDocumentOrder();

    /**
     * Sets the value of the dataDocumentOrder property.
     *
     */
    void setDataDocumentOrder(int value);

    /**
     * Gets the value of the order property.
     *
     */
    int getOrder();

    /**
     * Sets the value of the order property.
     *
     */
    void setOrder(int value);

    /**
     * Gets the value of the dataConversioOrder property.
     *
     */
    int getDataConversioOrder();

    /**
     * Sets the value of the dataConversioOrder property.
     *
     */
    void setDataConversioOrder(int value);

    /**
     * Gets the value of the dataComptLength property.
     *
     */
    int getDataComptLength();

    /**
     * Sets the value of the dataComptLength property.
     *
     */
    void setDataComptLength(int value);

    /**
     * Gets the value of the tipusRegistreLength property.
     *
     */
    int getTipusRegistreLength();

    /**
     * Sets the value of the tipusRegistreLength property.
     *
     */
    void setTipusRegistreLength(int value);

    /**
     * Gets the value of the dataConversioLength property.
     *
     */
    int getDataConversioLength();

    /**
     * Sets the value of the dataConversioLength property.
     *
     */
    void setDataConversioLength(int value);

    /**
     * Gets the value of the dadesPosicioOrder property.
     *
     */
    int getDadesPosicioOrder();

    /**
     * Sets the value of the dadesPosicioOrder property.
     *
     */
    void setDadesPosicioOrder(int value);

    /**
     * Gets the value of the monedaLength property.
     *
     */
    int getMonedaLength();

    /**
     * Sets the value of the monedaLength property.
     *
     */
    void setMonedaLength(int value);

    /**
     * Gets the value of the transaccioOrder property.
     *
     */
    int getTransaccioOrder();

    /**
     * Sets the value of the transaccioOrder property.
     *
     */
    void setTransaccioOrder(int value);

    /**
     * Gets the value of the transaccioLength property.
     *
     */
    int getTransaccioLength();

    /**
     * Sets the value of the transaccioLength property.
     *
     */
    void setTransaccioLength(int value);

    /**
     * Gets the value of the dadesPosicioLength property.
     *
     */
    int getDadesPosicioLength();

    /**
     * Sets the value of the dadesPosicioLength property.
     *
     */
    void setDadesPosicioLength(int value);

    /**
     * Gets the value of the nDocumentOrder property.
     *
     */
    int getNDocumentOrder();

    /**
     * Sets the value of the nDocumentOrder property.
     *
     */
    void setNDocumentOrder(int value);

    /**
     * Gets the value of the societatOrder property.
     *
     */
    int getSocietatOrder();

    /**
     * Sets the value of the societatOrder property.
     *
     */
    void setSocietatOrder(int value);

    /**
     * Gets the value of the tipusCanviLength property.
     *
     */
    int getTipusCanviLength();

    /**
     * Sets the value of the tipusCanviLength property.
     *
     */
    void setTipusCanviLength(int value);

    /**
     * Gets the value of the classeDocumentOrder property.
     *
     */
    int getClasseDocumentOrder();

    /**
     * Sets the value of the classeDocumentOrder property.
     *
     */
    void setClasseDocumentOrder(int value);

    /**
     * Gets the value of the tipusCanviOrder property.
     *
     */
    int getTipusCanviOrder();

    /**
     * Sets the value of the tipusCanviOrder property.
     *
     */
    void setTipusCanviOrder(int value);

    /**
     * Gets the value of the monedaOrder property.
     *
     */
    int getMonedaOrder();

    /**
     * Sets the value of the monedaOrder property.
     *
     */
    void setMonedaOrder(int value);

    /**
     * Gets the value of the dataComptOrder property.
     *
     */
    int getDataComptOrder();

    /**
     * Sets the value of the dataComptOrder property.
     *
     */
    void setDataComptOrder(int value);

    /**
     * Gets the value of the societatLength property.
     *
     */
    int getSocietatLength();

    /**
     * Sets the value of the societatLength property.
     *
     */
    void setSocietatLength(int value);
}
