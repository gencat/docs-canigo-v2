/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPD.impl;

public class BlocImputacioTypeImpl implements net.gencat.gecat.batch.DocumentsOCPD.BlocImputacioType,
    com.sun.xml.bind.JAXBObject,
    net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.XMLSerializable,
    net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.ValidatableObject {
    public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsOCPD.impl.JAXBVersion.class);
    private static com.sun.msv.grammar.Grammar schemaFragment;
    protected java.lang.String _CodiPIP;
    protected java.lang.String _PagadorAlternatiu;
    protected java.lang.String _TipusRegistre;
    protected java.lang.String _Reference;
    protected java.lang.String _Vendor;
    protected net.gencat.gecat.batch.DocumentsOCPD.RetencionsType _Retencions;

    private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
        return (net.gencat.gecat.batch.DocumentsOCPD.BlocImputacioType.class);
    }

    public java.lang.String getCodiPIP() {
        return _CodiPIP;
    }

    public void setCodiPIP(java.lang.String value) {
        _CodiPIP = value;
    }

    public java.lang.String getPagadorAlternatiu() {
        return _PagadorAlternatiu;
    }

    public void setPagadorAlternatiu(java.lang.String value) {
        _PagadorAlternatiu = value;
    }

    public java.lang.String getTipusRegistre() {
        return _TipusRegistre;
    }

    public void setTipusRegistre(java.lang.String value) {
        _TipusRegistre = value;
    }

    public java.lang.String getReference() {
        return _Reference;
    }

    public void setReference(java.lang.String value) {
        _Reference = value;
    }

    public java.lang.String getVendor() {
        return _Vendor;
    }

    public void setVendor(java.lang.String value) {
        _Vendor = value;
    }

    public net.gencat.gecat.batch.DocumentsOCPD.RetencionsType getRetencions() {
        return _Retencions;
    }

    public void setRetencions(
        net.gencat.gecat.batch.DocumentsOCPD.RetencionsType value) {
        _Retencions = value;
    }

    public void serializeBody(
        net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        if (_Retencions != null) {
            context.startElement("", "Retencions");
            context.childAsURIs(((com.sun.xml.bind.JAXBObject) _Retencions),
                "Retencions");
            context.endNamespaceDecls();
            context.childAsAttributes(((com.sun.xml.bind.JAXBObject) _Retencions),
                "Retencions");
            context.endAttributes();
            context.childAsBody(((com.sun.xml.bind.JAXBObject) _Retencions),
                "Retencions");
            context.endElement();
        }

        context.startElement("", "TipusRegistre");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _TipusRegistre), "TipusRegistre");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "Reference");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _Reference), "Reference");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "CodiPIP");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _CodiPIP), "CodiPIP");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "Vendor");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _Vendor), "Vendor");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "PagadorAlternatiu");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _PagadorAlternatiu),
                "PagadorAlternatiu");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
    }

    public void serializeAttributes(
        net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
    }

    public void serializeURIs(
        net.gencat.gecat.batch.DocumentsOCPD.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
    }

    public java.lang.Class getPrimaryInterface() {
        return (net.gencat.gecat.batch.DocumentsOCPD.BlocImputacioType.class);
    }

    public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
        if (schemaFragment == null) {
            schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                    "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                    "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                    "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                    "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsr\u0000\u001dcom." +
                    "sun.msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsr\u0000\'com.sun.msv." +
                    "grammar.trex.ElementPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\tnameClasst\u0000\u001fLcom/su" +
                    "n/msv/grammar/NameClass;xr\u0000\u001ecom.sun.msv.grammar.ElementExp\u0000\u0000" +
                    "\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aignoreUndeclaredAttributesL\u0000\fcontentModelq\u0000~\u0000\u0002xq" +
                    "\u0000~\u0000\u0003sr\u0000\u0011java.lang.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000p\u0000sq\u0000~\u0000\u0000ppsq\u0000" +
                    "~\u0000\fpp\u0000sq\u0000~\u0000\nppsr\u0000 com.sun.msv.grammar.OneOrMoreExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000" +
                    "\u0000xr\u0000\u001ccom.sun.msv.grammar.UnaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0003expq\u0000~\u0000\u0002xq\u0000~\u0000" +
                    "\u0003q\u0000~\u0000\u0011psr\u0000 com.sun.msv.grammar.AttributeExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003exp" +
                    "q\u0000~\u0000\u0002L\u0000\tnameClassq\u0000~\u0000\rxq\u0000~\u0000\u0003q\u0000~\u0000\u0011psr\u00002com.sun.msv.grammar.Ex" +
                    "pression$AnyStringExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\u0010\u0001q\u0000~\u0000\u001bsr\u0000" +
                    " com.sun.msv.grammar.AnyNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.sun.msv." +
                    "grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000com.sun.msv.grammar.Expres" +
                    "sion$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003q\u0000~\u0000\u001cq\u0000~\u0000!sr\u0000#com.sun" +
                    ".msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlocalNamet\u0000\u0012Ljava/" +
                    "lang/String;L\u0000\fnamespaceURIq\u0000~\u0000#xq\u0000~\u0000\u001et\u00003net.gencat.gecat.ba" +
                    "tch.DocumentsOCPD.RetencionsTypet\u0000+http://java.sun.com/jaxb/" +
                    "xjc/dummy-elementssq\u0000~\u0000\nppsq\u0000~\u0000\u0018q\u0000~\u0000\u0011psr\u0000\u001bcom.sun.msv.gramma" +
                    "r.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatype/Datatype;L" +
                    "\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util/StringPair;xq\u0000~\u0000\u0003pp" +
                    "sr\u0000\"com.sun.msv.datatype.xsd.QnameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000*com.sun" +
                    ".msv.datatype.xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.ms" +
                    "v.datatype.xsd.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.dataty" +
                    "pe.xsd.XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUriq\u0000~\u0000#L\u0000\btypeN" +
                    "ameq\u0000~\u0000#L\u0000\nwhiteSpacet\u0000.Lcom/sun/msv/datatype/xsd/WhiteSpace" +
                    "Processor;xpt\u0000 http://www.w3.org/2001/XMLSchemat\u0000\u0005QNamesr\u00005c" +
                    "om.sun.msv.datatype.xsd.WhiteSpaceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0000xr\u0000,com.sun.msv.datatype.xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002" +
                    "\u0000\u0000xpsr\u00000com.sun.msv.grammar.Expression$NullSetExpression\u0000\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\t" +
                    "localNameq\u0000~\u0000#L\u0000\fnamespaceURIq\u0000~\u0000#xpq\u0000~\u00004q\u0000~\u00003sq\u0000~\u0000\"t\u0000\u0004typet" +
                    "\u0000)http://www.w3.org/2001/XMLSchema-instanceq\u0000~\u0000!sq\u0000~\u0000\"t\u0000\nRet" +
                    "encionst\u0000\u0000q\u0000~\u0000!sq\u0000~\u0000\fpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000)ppsr\u0000\'com.sun.msv.data" +
                    "type.xsd.MaxLengthFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\tmaxLengthxr\u00009com.sun.ms" +
                    "v.datatype.xsd.DataTypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr" +
                    "\u0000*com.sun.msv.datatype.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fis" +
                    "FacetFixedZ\u0000\u0012needValueCheckFlagL\u0000\bbaseTypet\u0000)Lcom/sun/msv/da" +
                    "tatype/xsd/XSDatatypeImpl;L\u0000\fconcreteTypet\u0000\'Lcom/sun/msv/dat" +
                    "atype/xsd/ConcreteType;L\u0000\tfacetNameq\u0000~\u0000#xq\u0000~\u00000q\u0000~\u0000Apsr\u00005com." +
                    "sun.msv.datatype.xsd.WhiteSpaceProcessor$Preserve\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000" +
                    "xq\u0000~\u00006\u0000\u0000sr\u0000#com.sun.msv.datatype.xsd.StringType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001Z\u0000" +
                    "\risAlwaysValidxq\u0000~\u0000.q\u0000~\u00003t\u0000\u0006stringq\u0000~\u0000L\u0001q\u0000~\u0000Nt\u0000\tmaxLength\u0000\u0000\u0000" +
                    "\u0001q\u0000~\u00009sq\u0000~\u0000:t\u0000\u000estring-derivedq\u0000~\u0000Asq\u0000~\u0000\nppsq\u0000~\u0000\u0018q\u0000~\u0000\u0011pq\u0000~\u0000,q" +
                    "\u0000~\u0000<q\u0000~\u0000!sq\u0000~\u0000\"t\u0000\rTipusRegistreq\u0000~\u0000Asq\u0000~\u0000\fpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000)p" +
                    "psq\u0000~\u0000Eq\u0000~\u0000Apq\u0000~\u0000L\u0000\u0000q\u0000~\u0000Nq\u0000~\u0000Nq\u0000~\u0000P\u0000\u0000\u0000\u0010q\u0000~\u00009sq\u0000~\u0000:t\u0000\u000estring-" +
                    "derivedq\u0000~\u0000Asq\u0000~\u0000\nppsq\u0000~\u0000\u0018q\u0000~\u0000\u0011pq\u0000~\u0000,q\u0000~\u0000<q\u0000~\u0000!sq\u0000~\u0000\"t\u0000\tRefe" +
                    "renceq\u0000~\u0000Asq\u0000~\u0000\fpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000)ppsq\u0000~\u0000Eq\u0000~\u0000Apq\u0000~\u0000L\u0000\u0000q\u0000~\u0000Nq" +
                    "\u0000~\u0000Nq\u0000~\u0000P\u0000\u0000\u0000\fq\u0000~\u00009sq\u0000~\u0000:t\u0000\u000estring-derivedq\u0000~\u0000Asq\u0000~\u0000\nppsq\u0000~\u0000\u0018" +
                    "q\u0000~\u0000\u0011pq\u0000~\u0000,q\u0000~\u0000<q\u0000~\u0000!sq\u0000~\u0000\"t\u0000\u0007CodiPIPq\u0000~\u0000Asq\u0000~\u0000\fpp\u0000sq\u0000~\u0000\u0000pps" +
                    "q\u0000~\u0000)ppsq\u0000~\u0000Eq\u0000~\u0000Apq\u0000~\u0000L\u0000\u0000q\u0000~\u0000Nq\u0000~\u0000Nq\u0000~\u0000P\u0000\u0000\u0000\nq\u0000~\u00009sq\u0000~\u0000:t\u0000\u000es" +
                    "tring-derivedq\u0000~\u0000Asq\u0000~\u0000\nppsq\u0000~\u0000\u0018q\u0000~\u0000\u0011pq\u0000~\u0000,q\u0000~\u0000<q\u0000~\u0000!sq\u0000~\u0000\"t" +
                    "\u0000\u0006Vendorq\u0000~\u0000Asq\u0000~\u0000\fpp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000)ppsq\u0000~\u0000Eq\u0000~\u0000Apq\u0000~\u0000L\u0000\u0000q\u0000~" +
                    "\u0000Nq\u0000~\u0000Nq\u0000~\u0000P\u0000\u0000\u0000\nq\u0000~\u00009sq\u0000~\u0000:t\u0000\u000estring-derivedq\u0000~\u0000Asq\u0000~\u0000\nppsq\u0000" +
                    "~\u0000\u0018q\u0000~\u0000\u0011pq\u0000~\u0000,q\u0000~\u0000<q\u0000~\u0000!sq\u0000~\u0000\"t\u0000\u0011PagadorAlternatiuq\u0000~\u0000Asr\u0000\"c" +
                    "om.sun.msv.grammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lc" +
                    "om/sun/msv/grammar/ExpressionPool$ClosedHash;xpsr\u0000-com.sun.m" +
                    "sv.grammar.ExpressionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rst" +
                    "reamVersionL\u0000\u0006parentt\u0000$Lcom/sun/msv/grammar/ExpressionPool;x" +
                    "p\u0000\u0000\u0000\u0014\u0001pq\u0000~\u0000\u0012q\u0000~\u0000\u0017q\u0000~\u0000\u0005q\u0000~\u0000\u000bq\u0000~\u0000\u0007q\u0000~\u0000\'q\u0000~\u0000Sq\u0000~\u0000]q\u0000~\u0000gq\u0000~\u0000qq\u0000~" +
                    "\u0000{q\u0000~\u0000Cq\u0000~\u0000\tq\u0000~\u0000Xq\u0000~\u0000vq\u0000~\u0000\bq\u0000~\u0000bq\u0000~\u0000lq\u0000~\u0000\u0014q\u0000~\u0000\u0006x"));
        }

        return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
    }
}
