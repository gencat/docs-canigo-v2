/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsO.impl;

public class BlocImputacioTypeImpl implements net.gencat.gecat.batch.DocumentsO.BlocImputacioType,
    com.sun.xml.bind.JAXBObject,
    net.gencat.gecat.batch.DocumentsO.impl.runtime.XMLSerializable,
    net.gencat.gecat.batch.DocumentsO.impl.runtime.ValidatableObject {
    public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsO.impl.JAXBVersion.class);
    private static com.sun.msv.grammar.Grammar schemaFragment;
    protected java.lang.String _CodiPIP;
    protected java.lang.String _PagadorAlternatiu;
    protected java.lang.String _TipusRegistre;
    protected java.lang.String _Reference;
    protected java.lang.String _Vendor;
    protected net.gencat.gecat.batch.DocumentsO.RetencionsType _Retencions;

    private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
        return (net.gencat.gecat.batch.DocumentsO.BlocImputacioType.class);
    }

    public java.lang.String getCodiPIP() {
        return _CodiPIP;
    }

    public void setCodiPIP(java.lang.String value) {
        _CodiPIP = value;
    }

    public java.lang.String getPagadorAlternatiu() {
        return _PagadorAlternatiu;
    }

    public void setPagadorAlternatiu(java.lang.String value) {
        _PagadorAlternatiu = value;
    }

    public java.lang.String getTipusRegistre() {
        return _TipusRegistre;
    }

    public void setTipusRegistre(java.lang.String value) {
        _TipusRegistre = value;
    }

    public java.lang.String getReference() {
        return _Reference;
    }

    public void setReference(java.lang.String value) {
        _Reference = value;
    }

    public java.lang.String getVendor() {
        return _Vendor;
    }

    public void setVendor(java.lang.String value) {
        _Vendor = value;
    }

    public net.gencat.gecat.batch.DocumentsO.RetencionsType getRetencions() {
        return _Retencions;
    }

    public void setRetencions(
        net.gencat.gecat.batch.DocumentsO.RetencionsType value) {
        _Retencions = value;
    }

    public void serializeBody(
        net.gencat.gecat.batch.DocumentsO.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        context.startElement("", "Retencions");
        context.childAsURIs(((com.sun.xml.bind.JAXBObject) _Retencions),
            "Retencions");
        context.endNamespaceDecls();
        context.childAsAttributes(((com.sun.xml.bind.JAXBObject) _Retencions),
            "Retencions");
        context.endAttributes();
        context.childAsBody(((com.sun.xml.bind.JAXBObject) _Retencions),
            "Retencions");
        context.endElement();
        context.startElement("", "TipusRegistre");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _TipusRegistre), "TipusRegistre");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "Reference");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _Reference), "Reference");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "CodiPIP");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _CodiPIP), "CodiPIP");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "Vendor");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _Vendor), "Vendor");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
        context.startElement("", "PagadorAlternatiu");
        context.endNamespaceDecls();
        context.endAttributes();

        try {
            context.text(((java.lang.String) _PagadorAlternatiu),
                "PagadorAlternatiu");
        } catch (java.lang.Exception e) {
            net.gencat.gecat.batch.DocumentsO.impl.runtime.Util.handlePrintConversionException(this,
                e, context);
        }

        context.endElement();
    }

    public void serializeAttributes(
        net.gencat.gecat.batch.DocumentsO.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
    }

    public void serializeURIs(
        net.gencat.gecat.batch.DocumentsO.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
    }

    public java.lang.Class getPrimaryInterface() {
        return (net.gencat.gecat.batch.DocumentsO.BlocImputacioType.class);
    }

    public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
        if (schemaFragment == null) {
            schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                    "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                    "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                    "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                    "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsr\u0000\'com." +
                    "sun.msv.grammar.trex.ElementPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\tnameClasst\u0000" +
                    "\u001fLcom/sun/msv/grammar/NameClass;xr\u0000\u001ecom.sun.msv.grammar.Elem" +
                    "entExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aignoreUndeclaredAttributesL\u0000\fcontentMode" +
                    "lq\u0000~\u0000\u0002xq\u0000~\u0000\u0003pp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\npp\u0000sr\u0000\u001dcom.sun.msv.grammar.Choi" +
                    "ceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsr\u0000 com.sun.msv.grammar.OneOrMoreExp" +
                    "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001ccom.sun.msv.grammar.UnaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0003exp" +
                    "q\u0000~\u0000\u0002xq\u0000~\u0000\u0003sr\u0000\u0011java.lang.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000 c" +
                    "om.sun.msv.grammar.AttributeExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tname" +
                    "Classq\u0000~\u0000\u000bxq\u0000~\u0000\u0003q\u0000~\u0000\u0016psr\u00002com.sun.msv.grammar.Expression$Any" +
                    "StringExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\u0015\u0001q\u0000~\u0000\u001asr\u0000 com.sun.msv" +
                    ".grammar.AnyNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.sun.msv.grammar.Name" +
                    "Class\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000com.sun.msv.grammar.Expression$Epsilon" +
                    "Expression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003q\u0000~\u0000\u001bq\u0000~\u0000 sr\u0000#com.sun.msv.grammar" +
                    ".SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlocalNamet\u0000\u0012Ljava/lang/String;" +
                    "L\u0000\fnamespaceURIq\u0000~\u0000\"xq\u0000~\u0000\u001dt\u00000net.gencat.gecat.batch.Document" +
                    "sO.RetencionsTypet\u0000+http://java.sun.com/jaxb/xjc/dummy-eleme" +
                    "ntssq\u0000~\u0000\u0010ppsq\u0000~\u0000\u0017q\u0000~\u0000\u0016psr\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000" +
                    "\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000" +
                    "\u0004namet\u0000\u001dLcom/sun/msv/util/StringPair;xq\u0000~\u0000\u0003ppsr\u0000\"com.sun.msv" +
                    ".datatype.xsd.QnameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.x" +
                    "sd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datatype.xsd." +
                    "ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype.xsd.XSDataty" +
                    "peImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUriq\u0000~\u0000\"L\u0000\btypeNameq\u0000~\u0000\"L\u0000\nwhit" +
                    "eSpacet\u0000.Lcom/sun/msv/datatype/xsd/WhiteSpaceProcessor;xpt\u0000 " +
                    "http://www.w3.org/2001/XMLSchemat\u0000\u0005QNamesr\u00005com.sun.msv.data" +
                    "type.xsd.WhiteSpaceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun." +
                    "msv.datatype.xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000com.sun" +
                    ".msv.grammar.Expression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003pp" +
                    "sr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000\"L" +
                    "\u0000\fnamespaceURIq\u0000~\u0000\"xpq\u0000~\u00003q\u0000~\u00002sq\u0000~\u0000!t\u0000\u0004typet\u0000)http://www.w3" +
                    ".org/2001/XMLSchema-instanceq\u0000~\u0000 sq\u0000~\u0000!t\u0000\nRetencionst\u0000\u0000sq\u0000~\u0000" +
                    "\npp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000(ppsr\u0000\'com.sun.msv.datatype.xsd.MaxLengthFa" +
                    "cet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\tmaxLengthxr\u00009com.sun.msv.datatype.xsd.DataT" +
                    "ypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*com.sun.msv.dataty" +
                    "pe.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFacetFixedZ\u0000\u0012needVal" +
                    "ueCheckFlagL\u0000\bbaseTypet\u0000)Lcom/sun/msv/datatype/xsd/XSDatatyp" +
                    "eImpl;L\u0000\fconcreteTypet\u0000\'Lcom/sun/msv/datatype/xsd/ConcreteTy" +
                    "pe;L\u0000\tfacetNameq\u0000~\u0000\"xq\u0000~\u0000/q\u0000~\u0000@psr\u00005com.sun.msv.datatype.xsd" +
                    ".WhiteSpaceProcessor$Preserve\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u00005\u0000\u0000sr\u0000#com.sun." +
                    "msv.datatype.xsd.StringType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001Z\u0000\risAlwaysValidxq\u0000~\u0000-" +
                    "q\u0000~\u00002t\u0000\u0006stringq\u0000~\u0000K\u0001q\u0000~\u0000Mt\u0000\tmaxLength\u0000\u0000\u0000\u0001q\u0000~\u00008sq\u0000~\u00009t\u0000\u000estrin" +
                    "g-derivedq\u0000~\u0000@sq\u0000~\u0000\u0010ppsq\u0000~\u0000\u0017q\u0000~\u0000\u0016pq\u0000~\u0000+q\u0000~\u0000;q\u0000~\u0000 sq\u0000~\u0000!t\u0000\rTi" +
                    "pusRegistreq\u0000~\u0000@sq\u0000~\u0000\npp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000(ppsq\u0000~\u0000Dq\u0000~\u0000@pq\u0000~\u0000K\u0000\u0000" +
                    "q\u0000~\u0000Mq\u0000~\u0000Mq\u0000~\u0000O\u0000\u0000\u0000\u0010q\u0000~\u00008sq\u0000~\u00009t\u0000\u000estring-derivedq\u0000~\u0000@sq\u0000~\u0000\u0010pp" +
                    "sq\u0000~\u0000\u0017q\u0000~\u0000\u0016pq\u0000~\u0000+q\u0000~\u0000;q\u0000~\u0000 sq\u0000~\u0000!t\u0000\tReferenceq\u0000~\u0000@sq\u0000~\u0000\npp\u0000s" +
                    "q\u0000~\u0000\u0000ppsq\u0000~\u0000(ppsq\u0000~\u0000Dq\u0000~\u0000@pq\u0000~\u0000K\u0000\u0000q\u0000~\u0000Mq\u0000~\u0000Mq\u0000~\u0000O\u0000\u0000\u0000\fq\u0000~\u00008sq" +
                    "\u0000~\u00009t\u0000\u000estring-derivedq\u0000~\u0000@sq\u0000~\u0000\u0010ppsq\u0000~\u0000\u0017q\u0000~\u0000\u0016pq\u0000~\u0000+q\u0000~\u0000;q\u0000~\u0000" +
                    " sq\u0000~\u0000!t\u0000\u0007CodiPIPq\u0000~\u0000@sq\u0000~\u0000\npp\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000(ppsq\u0000~\u0000Dq\u0000~\u0000@pq" +
                    "\u0000~\u0000K\u0000\u0000q\u0000~\u0000Mq\u0000~\u0000Mq\u0000~\u0000O\u0000\u0000\u0000\nq\u0000~\u00008sq\u0000~\u00009t\u0000\u000estring-derivedq\u0000~\u0000@sq" +
                    "\u0000~\u0000\u0010ppsq\u0000~\u0000\u0017q\u0000~\u0000\u0016pq\u0000~\u0000+q\u0000~\u0000;q\u0000~\u0000 sq\u0000~\u0000!t\u0000\u0006Vendorq\u0000~\u0000@sq\u0000~\u0000\np" +
                    "p\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000(ppsq\u0000~\u0000Dq\u0000~\u0000@pq\u0000~\u0000K\u0000\u0000q\u0000~\u0000Mq\u0000~\u0000Mq\u0000~\u0000O\u0000\u0000\u0000\nq\u0000~\u0000" +
                    "8sq\u0000~\u00009t\u0000\u000estring-derivedq\u0000~\u0000@sq\u0000~\u0000\u0010ppsq\u0000~\u0000\u0017q\u0000~\u0000\u0016pq\u0000~\u0000+q\u0000~\u0000;q" +
                    "\u0000~\u0000 sq\u0000~\u0000!t\u0000\u0011PagadorAlternatiuq\u0000~\u0000@sr\u0000\"com.sun.msv.grammar.E" +
                    "xpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/sun/msv/grammar/E" +
                    "xpressionPool$ClosedHash;xpsr\u0000-com.sun.msv.grammar.Expressio" +
                    "nPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamVersionL\u0000\u0006parent" +
                    "t\u0000$Lcom/sun/msv/grammar/ExpressionPool;xp\u0000\u0000\u0000\u0013\u0001pq\u0000~\u0000uq\u0000~\u0000\u0014q\u0000~" +
                    "\u0000\tq\u0000~\u0000\u0007q\u0000~\u0000Wq\u0000~\u0000kq\u0000~\u0000\u000eq\u0000~\u0000\u0006q\u0000~\u0000\bq\u0000~\u0000Bq\u0000~\u0000\u0005q\u0000~\u0000aq\u0000~\u0000\u0011q\u0000~\u0000&q\u0000~" +
                    "\u0000Rq\u0000~\u0000\\q\u0000~\u0000fq\u0000~\u0000pq\u0000~\u0000zx"));
        }

        return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
    }
}
