/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPDHelper.impl;

public class DadesCreditorCPDTypeImpl implements net.gencat.gecat.batch.DocumentsOCPDHelper.DadesCreditorCPDType,
    com.sun.xml.bind.JAXBObject,
    net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.XMLSerializable,
    net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.ValidatableObject {
    public final static java.lang.Class version = (net.gencat.gecat.batch.DocumentsOCPDHelper.impl.JAXBVersion.class);
    private static com.sun.msv.grammar.Grammar schemaFragment;
    protected boolean has_PaisBancLength;
    protected int _PaisBancLength;
    protected boolean has_CodiPostalOrder;
    protected int _CodiPostalOrder;
    protected boolean has_Order;
    protected int _Order;
    protected boolean has_CompteBancariLength;
    protected int _CompteBancariLength;
    protected boolean has_AdrecaLength;
    protected int _AdrecaLength;
    protected boolean has_AdrecaOrder;
    protected int _AdrecaOrder;
    protected boolean has_PoblacioLength;
    protected int _PoblacioLength;
    protected boolean has_PaisOrder;
    protected int _PaisOrder;
    protected boolean has_PaisBancOrder;
    protected int _PaisBancOrder;
    protected boolean has_DigitsControlLength;
    protected int _DigitsControlLength;
    protected boolean has_DigitsControlOrder;
    protected int _DigitsControlOrder;
    protected boolean has_TipusRegistreOrder;
    protected int _TipusRegistreOrder;
    protected boolean has_CompteBancariOrder;
    protected int _CompteBancariOrder;
    protected boolean has_PoblacioOrder;
    protected int _PoblacioOrder;
    protected boolean has_CodiPostalLength;
    protected int _CodiPostalLength;
    protected boolean has_ClauBancLength;
    protected int _ClauBancLength;
    protected boolean has_ClauBancOrder;
    protected int _ClauBancOrder;
    protected boolean has_NIFLength;
    protected int _NIFLength;
    protected boolean has_TipusRegistreLength;
    protected int _TipusRegistreLength;
    protected boolean has_NomLength;
    protected int _NomLength;
    protected boolean has_NIFOrder;
    protected int _NIFOrder;
    protected boolean has_BlocImputacioOrder;
    protected int _BlocImputacioOrder;
    protected boolean has_BlocImputacioLength;
    protected int _BlocImputacioLength;
    protected boolean has_NomOrder;
    protected int _NomOrder;
    protected boolean has_PaisLength;
    protected int _PaisLength;

    private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
        return (net.gencat.gecat.batch.DocumentsOCPDHelper.DadesCreditorCPDType.class);
    }

    public int getPaisBancLength() {
        if (!has_PaisBancLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "3"));
        } else {
            return _PaisBancLength;
        }
    }

    public void setPaisBancLength(int value) {
        _PaisBancLength = value;
        has_PaisBancLength = true;
    }

    public int getCodiPostalOrder() {
        if (!has_CodiPostalOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "5"));
        } else {
            return _CodiPostalOrder;
        }
    }

    public void setCodiPostalOrder(int value) {
        _CodiPostalOrder = value;
        has_CodiPostalOrder = true;
    }

    public int getOrder() {
        if (!has_Order) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "6"));
        } else {
            return _Order;
        }
    }

    public void setOrder(int value) {
        _Order = value;
        has_Order = true;
    }

    public int getCompteBancariLength() {
        if (!has_CompteBancariLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "18"));
        } else {
            return _CompteBancariLength;
        }
    }

    public void setCompteBancariLength(int value) {
        _CompteBancariLength = value;
        has_CompteBancariLength = true;
    }

    public int getAdrecaLength() {
        if (!has_AdrecaLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "35"));
        } else {
            return _AdrecaLength;
        }
    }

    public void setAdrecaLength(int value) {
        _AdrecaLength = value;
        has_AdrecaLength = true;
    }

    public int getAdrecaOrder() {
        if (!has_AdrecaOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "3"));
        } else {
            return _AdrecaOrder;
        }
    }

    public void setAdrecaOrder(int value) {
        _AdrecaOrder = value;
        has_AdrecaOrder = true;
    }

    public int getPoblacioLength() {
        if (!has_PoblacioLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "35"));
        } else {
            return _PoblacioLength;
        }
    }

    public void setPoblacioLength(int value) {
        _PoblacioLength = value;
        has_PoblacioLength = true;
    }

    public int getPaisOrder() {
        if (!has_PaisOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "6"));
        } else {
            return _PaisOrder;
        }
    }

    public void setPaisOrder(int value) {
        _PaisOrder = value;
        has_PaisOrder = true;
    }

    public int getPaisBancOrder() {
        if (!has_PaisBancOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "10"));
        } else {
            return _PaisBancOrder;
        }
    }

    public void setPaisBancOrder(int value) {
        _PaisBancOrder = value;
        has_PaisBancOrder = true;
    }

    public int getDigitsControlLength() {
        if (!has_DigitsControlLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "2"));
        } else {
            return _DigitsControlLength;
        }
    }

    public void setDigitsControlLength(int value) {
        _DigitsControlLength = value;
        has_DigitsControlLength = true;
    }

    public int getDigitsControlOrder() {
        if (!has_DigitsControlOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "9"));
        } else {
            return _DigitsControlOrder;
        }
    }

    public void setDigitsControlOrder(int value) {
        _DigitsControlOrder = value;
        has_DigitsControlOrder = true;
    }

    public int getTipusRegistreOrder() {
        if (!has_TipusRegistreOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "1"));
        } else {
            return _TipusRegistreOrder;
        }
    }

    public void setTipusRegistreOrder(int value) {
        _TipusRegistreOrder = value;
        has_TipusRegistreOrder = true;
    }

    public int getCompteBancariOrder() {
        if (!has_CompteBancariOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "8"));
        } else {
            return _CompteBancariOrder;
        }
    }

    public void setCompteBancariOrder(int value) {
        _CompteBancariOrder = value;
        has_CompteBancariOrder = true;
    }

    public int getPoblacioOrder() {
        if (!has_PoblacioOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "4"));
        } else {
            return _PoblacioOrder;
        }
    }

    public void setPoblacioOrder(int value) {
        _PoblacioOrder = value;
        has_PoblacioOrder = true;
    }

    public int getCodiPostalLength() {
        if (!has_CodiPostalLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "10"));
        } else {
            return _CodiPostalLength;
        }
    }

    public void setCodiPostalLength(int value) {
        _CodiPostalLength = value;
        has_CodiPostalLength = true;
    }

    public int getClauBancLength() {
        if (!has_ClauBancLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "15"));
        } else {
            return _ClauBancLength;
        }
    }

    public void setClauBancLength(int value) {
        _ClauBancLength = value;
        has_ClauBancLength = true;
    }

    public int getClauBancOrder() {
        if (!has_ClauBancOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "7"));
        } else {
            return _ClauBancOrder;
        }
    }

    public void setClauBancOrder(int value) {
        _ClauBancOrder = value;
        has_ClauBancOrder = true;
    }

    public int getNIFLength() {
        if (!has_NIFLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "16"));
        } else {
            return _NIFLength;
        }
    }

    public void setNIFLength(int value) {
        _NIFLength = value;
        has_NIFLength = true;
    }

    public int getTipusRegistreLength() {
        if (!has_TipusRegistreLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "1"));
        } else {
            return _TipusRegistreLength;
        }
    }

    public void setTipusRegistreLength(int value) {
        _TipusRegistreLength = value;
        has_TipusRegistreLength = true;
    }

    public int getNomLength() {
        if (!has_NomLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "35"));
        } else {
            return _NomLength;
        }
    }

    public void setNomLength(int value) {
        _NomLength = value;
        has_NomLength = true;
    }

    public int getNIFOrder() {
        if (!has_NIFOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "11"));
        } else {
            return _NIFOrder;
        }
    }

    public void setNIFOrder(int value) {
        _NIFOrder = value;
        has_NIFOrder = true;
    }

    public int getBlocImputacioOrder() {
        if (!has_BlocImputacioOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "12"));
        } else {
            return _BlocImputacioOrder;
        }
    }

    public void setBlocImputacioOrder(int value) {
        _BlocImputacioOrder = value;
        has_BlocImputacioOrder = true;
    }

    public int getBlocImputacioLength() {
        if (!has_BlocImputacioLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "3"));
        } else {
            return _BlocImputacioLength;
        }
    }

    public void setBlocImputacioLength(int value) {
        _BlocImputacioLength = value;
        has_BlocImputacioLength = true;
    }

    public int getNomOrder() {
        if (!has_NomOrder) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "2"));
        } else {
            return _NomOrder;
        }
    }

    public void setNomOrder(int value) {
        _NomOrder = value;
        has_NomOrder = true;
    }

    public int getPaisLength() {
        if (!has_PaisLength) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "3"));
        } else {
            return _PaisLength;
        }
    }

    public void setPaisLength(int value) {
        _PaisLength = value;
        has_PaisLength = true;
    }

    public void serializeBody(
        net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
    }

    public void serializeAttributes(
        net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        if (has_AdrecaLength) {
            context.startAttribute("", "AdrecaLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _AdrecaLength)), "AdrecaLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_AdrecaOrder) {
            context.startAttribute("", "AdrecaOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _AdrecaOrder)), "AdrecaOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_BlocImputacioLength) {
            context.startAttribute("", "BlocImputacioLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _BlocImputacioLength)), "BlocImputacioLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_BlocImputacioOrder) {
            context.startAttribute("", "BlocImputacioOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _BlocImputacioOrder)), "BlocImputacioOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_ClauBancLength) {
            context.startAttribute("", "ClauBancLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _ClauBancLength)), "ClauBancLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_ClauBancOrder) {
            context.startAttribute("", "ClauBancOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _ClauBancOrder)), "ClauBancOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_CodiPostalLength) {
            context.startAttribute("", "CodiPostalLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _CodiPostalLength)), "CodiPostalLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_CodiPostalOrder) {
            context.startAttribute("", "CodiPostalOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _CodiPostalOrder)), "CodiPostalOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_CompteBancariLength) {
            context.startAttribute("", "CompteBancariLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _CompteBancariLength)), "CompteBancariLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_CompteBancariOrder) {
            context.startAttribute("", "CompteBancariOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _CompteBancariOrder)), "CompteBancariOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_DigitsControlLength) {
            context.startAttribute("", "DigitsControlLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _DigitsControlLength)), "DigitsControlLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_DigitsControlOrder) {
            context.startAttribute("", "DigitsControlOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _DigitsControlOrder)), "DigitsControlOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_NIFLength) {
            context.startAttribute("", "NIFLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _NIFLength)), "NIFLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_NIFOrder) {
            context.startAttribute("", "NIFOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _NIFOrder)), "NIFOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_NomLength) {
            context.startAttribute("", "NomLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _NomLength)), "NomLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_NomOrder) {
            context.startAttribute("", "NomOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _NomOrder)), "NomOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_PaisBancLength) {
            context.startAttribute("", "PaisBancLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _PaisBancLength)), "PaisBancLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_PaisBancOrder) {
            context.startAttribute("", "PaisBancOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _PaisBancOrder)), "PaisBancOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_PaisLength) {
            context.startAttribute("", "PaisLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _PaisLength)), "PaisLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_PaisOrder) {
            context.startAttribute("", "PaisOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _PaisOrder)), "PaisOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_PoblacioLength) {
            context.startAttribute("", "PoblacioLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _PoblacioLength)), "PoblacioLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_PoblacioOrder) {
            context.startAttribute("", "PoblacioOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _PoblacioOrder)), "PoblacioOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_TipusRegistreLength) {
            context.startAttribute("", "TipusRegistreLength");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _TipusRegistreLength)), "TipusRegistreLength");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_TipusRegistreOrder) {
            context.startAttribute("", "TipusRegistreOrder");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _TipusRegistreOrder)), "TipusRegistreOrder");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        if (has_Order) {
            context.startAttribute("", "order");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _Order)), "Order");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }
    }

    public void serializeURIs(
        net.gencat.gecat.batch.DocumentsOCPDHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
    }

    public java.lang.Class getPrimaryInterface() {
        return (net.gencat.gecat.batch.DocumentsOCPDHelper.DadesCreditorCPDType.class);
    }

    public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
        if (schemaFragment == null) {
            schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                    "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                    "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                    "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                    "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                    "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~" +
                    "\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                    "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsr\u0000\u001dcom.sun.msv.grammar.ChoiceExp\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001ppsr\u0000 com.sun.msv.grammar.AttributeExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/NameClass;" +
                    "xq\u0000~\u0000\u0003sr\u0000\u0011java.lang.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000\u001bcom.su" +
                    "n.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatyp" +
                    "e/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util/StringP" +
                    "air;xq\u0000~\u0000\u0003ppsr\u0000 com.sun.msv.datatype.xsd.IntType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000x" +
                    "r\u0000+com.sun.msv.datatype.xsd.IntegerDerivedType\u0099\u00f1]\u0090&6k\u00be\u0002\u0000\u0001L\u0000\n" +
                    "baseFacetst\u0000)Lcom/sun/msv/datatype/xsd/XSDatatypeImpl;xr\u0000*co" +
                    "m.sun.msv.datatype.xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.s" +
                    "un.msv.datatype.xsd.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.d" +
                    "atatype.xsd.XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUrit\u0000\u0012Ljava" +
                    "/lang/String;L\u0000\btypeNameq\u0000~\u0000.L\u0000\nwhiteSpacet\u0000.Lcom/sun/msv/da" +
                    "tatype/xsd/WhiteSpaceProcessor;xpt\u0000 http://www.w3.org/2001/X" +
                    "MLSchemat\u0000\u0003intsr\u00005com.sun.msv.datatype.xsd.WhiteSpaceProcess" +
                    "or$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datatype.xsd.WhiteSpac" +
                    "eProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u0000*com.sun.msv.datatype.xsd.MaxInclu" +
                    "siveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.datatype.xsd.RangeFacet\u0000" +
                    "\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\nlimitValuet\u0000\u0012Ljava/lang/Object;xr\u00009com.sun.msv." +
                    "datatype.xsd.DataTypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*" +
                    "com.sun.msv.datatype.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFa" +
                    "cetFixedZ\u0000\u0012needValueCheckFlagL\u0000\bbaseTypeq\u0000~\u0000*L\u0000\fconcreteType" +
                    "t\u0000\'Lcom/sun/msv/datatype/xsd/ConcreteType;L\u0000\tfacetNameq\u0000~\u0000.x" +
                    "q\u0000~\u0000-ppq\u0000~\u00005\u0000\u0001sr\u0000*com.sun.msv.datatype.xsd.MinInclusiveFacet" +
                    "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u00007ppq\u0000~\u00005\u0000\u0000sr\u0000!com.sun.msv.datatype.xsd.LongT" +
                    "ype\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000)q\u0000~\u00001t\u0000\u0004longq\u0000~\u00005sq\u0000~\u00006ppq\u0000~\u00005\u0000\u0001sq\u0000~\u0000=pp" +
                    "q\u0000~\u00005\u0000\u0000sr\u0000$com.sun.msv.datatype.xsd.IntegerType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq" +
                    "\u0000~\u0000)q\u0000~\u00001t\u0000\u0007integerq\u0000~\u00005sr\u0000,com.sun.msv.datatype.xsd.Fractio" +
                    "nDigitsFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scalexr\u0000;com.sun.msv.datatype.xsd." +
                    "DataTypeWithLexicalConstraintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000:ppq\u0000~\u00005\u0001\u0000" +
                    "sr\u0000#com.sun.msv.datatype.xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000+q\u0000~\u0000" +
                    "1t\u0000\u0007decimalq\u0000~\u00005q\u0000~\u0000Kt\u0000\u000efractionDigits\u0000\u0000\u0000\u0000q\u0000~\u0000Et\u0000\fminInclusi" +
                    "vesr\u0000\u000ejava.lang.Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010java.lang.Number\u0086" +
                    "\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u0000Et\u0000\fmaxInclusivesq\u0000~\u0000O\u007f\u00ff\u00ff\u00ff\u00ff\u00ff\u00ff\u00ffq\u0000~\u0000@q" +
                    "\u0000~\u0000Nsr\u0000\u0011java.lang.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000P\u0080\u0000\u0000\u0000q\u0000~\u0000@q" +
                    "\u0000~\u0000Rsq\u0000~\u0000T\u007f\u00ff\u00ff\u00ffsr\u00000com.sun.msv.grammar.Expression$NullSetExpr" +
                    "ession\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ej" +
                    "B\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000.L\u0000\fnamespaceURIq\u0000~\u0000.xpq\u0000~\u00002q\u0000~\u00001sr\u0000#" +
                    "com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlocalNameq\u0000" +
                    "~\u0000.L\u0000\fnamespaceURIq\u0000~\u0000.xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpt\u0000\fAdrecaLengtht\u0000\u0000sr\u00000com.sun.msv.grammar.Expressio" +
                    "n$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\"\u0001q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~" +
                    "\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u000bAdrecaOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~" +
                    "\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0013BlocImputacioLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001f" +
                    "q\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0012BlocImputacioOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~" +
                    "\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u000eClauBancLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001f" +
                    "q\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\rClauBancOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~" +
                    "\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0010CodiPostalLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~" +
                    "\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u000fCodiPostalOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000" +
                    "#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0013CompteBancariLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq" +
                    "\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0012CompteBancariOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000" +
                    "\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0013DigitsControlLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq" +
                    "\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0012DigitsControlOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dpp" +
                    "sq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\tNIFLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq" +
                    "\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\bNIFOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~" +
                    "\u0000\'sq\u0000~\u0000[t\u0000\tNomLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000" +
                    "[t\u0000\bNomOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u000ePais" +
                    "BancLengthq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\rPaisBa" +
                    "ncOrderq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\nPaisLengt" +
                    "hq\u0000~\u0000_q\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\tPaisOrderq\u0000~\u0000_q" +
                    "\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u000ePoblacioLengthq\u0000~\u0000_q\u0000~" +
                    "\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\rPoblacioOrderq\u0000~\u0000_q\u0000~\u0000as" +
                    "q\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0013TipusRegistreLengthq\u0000~\u0000_q\u0000~" +
                    "\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0012TipusRegistreOrderq\u0000~\u0000_q" +
                    "\u0000~\u0000asq\u0000~\u0000\u001dppsq\u0000~\u0000\u001fq\u0000~\u0000#pq\u0000~\u0000\'sq\u0000~\u0000[t\u0000\u0005orderq\u0000~\u0000_q\u0000~\u0000asr\u0000\"com" +
                    ".sun.msv.grammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom" +
                    "/sun/msv/grammar/ExpressionPool$ClosedHash;xpsr\u0000-com.sun.msv" +
                    ".grammar.ExpressionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstre" +
                    "amVersionL\u0000\u0006parentt\u0000$Lcom/sun/msv/grammar/ExpressionPool;xp\u0000" +
                    "\u0000\u00001\u0001pq\u0000~\u0000\u00a7q\u0000~\u0000\u008bq\u0000~\u0000\u0010q\u0000~\u0000\u0007q\u0000~\u0000\u001aq\u0000~\u0000cq\u0000~\u0000wq\u0000~\u0000\u0015q\u0000~\u0000\u0097q\u0000~\u0000\u0005q\u0000~\u0000\u000f" +
                    "q\u0000~\u0000\u00a3q\u0000~\u0000gq\u0000~\u0000\u0006q\u0000~\u0000\rq\u0000~\u0000\bq\u0000~\u0000\u0012q\u0000~\u0000\u0017q\u0000~\u0000\u0019q\u0000~\u0000\u0087q\u0000~\u0000{q\u0000~\u0000\u0093q\u0000~\u0000\u0013" +
                    "q\u0000~\u0000\u00b7q\u0000~\u0000\u001eq\u0000~\u0000\u0083q\u0000~\u0000kq\u0000~\u0000\u0011q\u0000~\u0000\u0018q\u0000~\u0000\u009fq\u0000~\u0000\u0014q\u0000~\u0000\u000eq\u0000~\u0000\u000bq\u0000~\u0000oq\u0000~\u0000\u001c" +
                    "q\u0000~\u0000\fq\u0000~\u0000\u00afq\u0000~\u0000\u0016q\u0000~\u0000\u00b3q\u0000~\u0000sq\u0000~\u0000\u00abq\u0000~\u0000\u007fq\u0000~\u0000\u008fq\u0000~\u0000\u00bbq\u0000~\u0000\u001bq\u0000~\u0000\tq\u0000~\u0000\n" +
                    "q\u0000~\u0000\u009bq\u0000~\u0000\u00bfx"));
        }

        return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
    }
}
