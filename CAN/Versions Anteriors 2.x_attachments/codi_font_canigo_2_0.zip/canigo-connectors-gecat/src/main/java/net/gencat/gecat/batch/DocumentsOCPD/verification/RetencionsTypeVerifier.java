/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPD.verification;

public class RetencionsTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsOCPD.RetencionsType master) {
        if (null == master.getDadaRetencio()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "DadaRetencio"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check count
            if (master.getDadaRetencio().size() < 1) {
                // Report minimum of occurences violated
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DadaRetencio"),
                        new de.fzi.dbs.verification.event.structure.TooFewElementsProblem(
                            master.getDadaRetencio().size(), 1)));
            }

            // Check value
            checkDadaRetencio(parentLocator, handler, master,
                master.getDadaRetencio());
        }
    }

    public void checkDadaRetencio(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsOCPD.RetencionsType master,
        java.util.List values) {
        for (int index = 0; (index < values.size()); index++) {
            java.lang.Object item = values.get(index);
            checkDadaRetencio(parentLocator, handler, master, index, item);
        }
    }

    public void checkDadaRetencio(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsOCPD.RetencionsType master, int index,
        java.lang.Object value) {
        if (value instanceof net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType) {
            net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType realValue =
                ((net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType) value);

            {
                // Check complex value
                net.gencat.gecat.batch.DocumentsOCPD.verification.RetencionsTypeVerifier.DadaRetencioTypeVerifier verifier =
                    new net.gencat.gecat.batch.DocumentsOCPD.verification.RetencionsTypeVerifier.DadaRetencioTypeVerifier();
                verifier.check(new de.fzi.dbs.verification.event.EntryLocator(
                        parentLocator, master, "DadaRetencio", index), handler,
                    realValue);
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.EntryLocator(
                            parentLocator, master, "DadaRetencio", index),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
        check(parentLocator, handler,
            ((net.gencat.gecat.batch.DocumentsOCPD.RetencionsType) object));
    }

    public void check(javax.xml.bind.ValidationEventHandler handler,
        java.lang.Object object) {
        check(null, handler,
            ((net.gencat.gecat.batch.DocumentsOCPD.RetencionsType) object));
    }

    public static class DadaRetencioTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
        public void check(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType master) {
            if (true) {
                // If left exists
                // No check for primitive values
                checkOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getOrder()));
            }

            if (null == master.getTipusRegistre()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "TipusRegistre"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkTipusRegistre(parentLocator, handler, master,
                    master.getTipusRegistre());
            }

            if (null == master.getIndicadorRetencio()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "IndicadorRetencio"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkIndicadorRetencio(parentLocator, handler, master,
                    master.getIndicadorRetencio());
            }

            if (null == master.getImportBase()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "ImportBase"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkImportBase(parentLocator, handler, master,
                    master.getImportBase());
            }

            if (null == master.getImportRetencio()) {
                // Report missing object
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "ImportRetencio"),
                        new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
            } else {
                // Check value
                checkImportRetencio(parentLocator, handler, master,
                    master.getImportRetencio());
            }
        }

        public void checkImportBase(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 13) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                13);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ImportBase"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ImportBase"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkImportRetencio(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 13) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                13);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ImportRetencio"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ImportRetencio"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkIndicadorRetencio(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 2) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                2);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "IndicadorRetencio"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "IndicadorRetencio"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "Order"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Order"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTipusRegistre(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType master,
            java.lang.String value) {
            if (value instanceof java.lang.String) {
                java.lang.String realValue = ((java.lang.String) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.MaxLengthFacet datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (((null == realValue) ? 0 : realValue.length()) <= 1) {
                        // Value length is correct
                    } else {
                        problem = new de.fzi.dbs.verification.event.datatype.TooLongProblem(realValue,
                                ((null == realValue) ? 0 : realValue.length()),
                                1);
                    }

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TipusRegistre"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusRegistre"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void check(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            java.lang.Object object) {
            check(parentLocator, handler,
                ((net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType) object));
        }

        public void check(javax.xml.bind.ValidationEventHandler handler,
            java.lang.Object object) {
            check(null, handler,
                ((net.gencat.gecat.batch.DocumentsOCPD.RetencionsType.DadaRetencioType) object));
        }
    }
}
