/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPDHelper;


/**
 * Java content class for BlocImputacioType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsOCPDHelper.xsd line 292)
 * <p>
 * <pre>
 * &lt;complexType name="BlocImputacioType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="CodiPIPLength" type="{http://www.w3.org/2001/XMLSchema}int" default="12" />
 *       &lt;attribute name="CodiPIPOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
 *       &lt;attribute name="ReferenceLength" type="{http://www.w3.org/2001/XMLSchema}int" default="16" />
 *       &lt;attribute name="ReferenceOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *       &lt;attribute name="RetencionsLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *       &lt;attribute name="RetencionsOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
 *       &lt;attribute name="TipusRegistreLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *       &lt;attribute name="TipusRegistreOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *       &lt;attribute name="VendorLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *       &lt;attribute name="VendorOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface BlocImputacioType {
    /**
     * Gets the value of the tipusRegistreLength property.
     *
     */
    int getTipusRegistreLength();

    /**
     * Sets the value of the tipusRegistreLength property.
     *
     */
    void setTipusRegistreLength(int value);

    /**
     * Gets the value of the codiPIPLength property.
     *
     */
    int getCodiPIPLength();

    /**
     * Sets the value of the codiPIPLength property.
     *
     */
    void setCodiPIPLength(int value);

    /**
     * Gets the value of the tipusRegistreOrder property.
     *
     */
    int getTipusRegistreOrder();

    /**
     * Sets the value of the tipusRegistreOrder property.
     *
     */
    void setTipusRegistreOrder(int value);

    /**
     * Gets the value of the vendorLength property.
     *
     */
    int getVendorLength();

    /**
     * Sets the value of the vendorLength property.
     *
     */
    void setVendorLength(int value);

    /**
     * Gets the value of the codiPIPOrder property.
     *
     */
    int getCodiPIPOrder();

    /**
     * Sets the value of the codiPIPOrder property.
     *
     */
    void setCodiPIPOrder(int value);

    /**
     * Gets the value of the order property.
     *
     */
    int getOrder();

    /**
     * Sets the value of the order property.
     *
     */
    void setOrder(int value);

    /**
     * Gets the value of the referenceLength property.
     *
     */
    int getReferenceLength();

    /**
     * Sets the value of the referenceLength property.
     *
     */
    void setReferenceLength(int value);

    /**
     * Gets the value of the referenceOrder property.
     *
     */
    int getReferenceOrder();

    /**
     * Sets the value of the referenceOrder property.
     *
     */
    void setReferenceOrder(int value);

    /**
     * Gets the value of the retencionsLength property.
     *
     */
    int getRetencionsLength();

    /**
     * Sets the value of the retencionsLength property.
     *
     */
    void setRetencionsLength(int value);

    /**
     * Gets the value of the vendorOrder property.
     *
     */
    int getVendorOrder();

    /**
     * Sets the value of the vendorOrder property.
     *
     */
    void setVendorOrder(int value);

    /**
     * Gets the value of the retencionsOrder property.
     *
     */
    int getRetencionsOrder();

    /**
     * Sets the value of the retencionsOrder property.
     *
     */
    void setRetencionsOrder(int value);
}
