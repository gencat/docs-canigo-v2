/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.BatchRetornHelper.impl;

public class DadesRetornTypeImpl implements net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType,
    com.sun.xml.bind.JAXBObject,
    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.XMLSerializable,
    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.ValidatableObject {
    public final static java.lang.Class version = (net.gencat.gecat.batch.BatchRetornHelper.impl.JAXBVersion.class);
    private static com.sun.msv.grammar.Grammar schemaFragment;
    protected com.sun.xml.bind.util.ListImpl _DadaRetorn;
    protected boolean has_Order;
    protected int _Order;

    private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
        return (net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.class);
    }

    protected com.sun.xml.bind.util.ListImpl _getDadaRetorn() {
        if (_DadaRetorn == null) {
            _DadaRetorn = new com.sun.xml.bind.util.ListImpl(new java.util.ArrayList());
        }

        return _DadaRetorn;
    }

    public java.util.List getDadaRetorn() {
        return _getDadaRetorn();
    }

    public int getOrder() {
        if (!has_Order) {
            return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                    "1"));
        } else {
            return _Order;
        }
    }

    public void setOrder(int value) {
        _Order = value;
        has_Order = true;
    }

    public void serializeBody(
        net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx1 = 0;
        final int len1 = ((_DadaRetorn == null) ? 0 : _DadaRetorn.size());

        while (idx1 != len1) {
            context.startElement("", "DadaRetorn");

            int idx_0 = idx1;
            context.childAsURIs(((com.sun.xml.bind.JAXBObject) _DadaRetorn.get(
                    idx_0++)), "DadaRetorn");
            context.endNamespaceDecls();

            int idx_1 = idx1;
            context.childAsAttributes(((com.sun.xml.bind.JAXBObject) _DadaRetorn.get(
                    idx_1++)), "DadaRetorn");
            context.endAttributes();
            context.childAsBody(((com.sun.xml.bind.JAXBObject) _DadaRetorn.get(
                    idx1++)), "DadaRetorn");
            context.endElement();
        }
    }

    public void serializeAttributes(
        net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx1 = 0;
        final int len1 = ((_DadaRetorn == null) ? 0 : _DadaRetorn.size());

        if (has_Order) {
            context.startAttribute("", "order");

            try {
                context.text(javax.xml.bind.DatatypeConverter.printInt(
                        ((int) _Order)), "Order");
            } catch (java.lang.Exception e) {
                net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                    e, context);
            }

            context.endAttribute();
        }

        while (idx1 != len1) {
            idx1 += 1;
        }
    }

    public void serializeURIs(
        net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.XMLSerializer context)
        throws org.xml.sax.SAXException {
        int idx1 = 0;
        final int len1 = ((_DadaRetorn == null) ? 0 : _DadaRetorn.size());

        while (idx1 != len1) {
            idx1 += 1;
        }
    }

    public java.lang.Class getPrimaryInterface() {
        return (net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.class);
    }

    public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
        if (schemaFragment == null) {
            schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                    "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                    "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                    "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                    "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsr\u0000\'com.sun.msv.grammar.trex.Ele" +
                    "mentPattern\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/Na" +
                    "meClass;xr\u0000\u001ecom.sun.msv.grammar.ElementExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002Z\u0000\u001aigno" +
                    "reUndeclaredAttributesL\u0000\fcontentModelq\u0000~\u0000\u0002xq\u0000~\u0000\u0003pp\u0000sq\u0000~\u0000\u0000pps" +
                    "q\u0000~\u0000\u0007pp\u0000sr\u0000\u001dcom.sun.msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0001pp" +
                    "sr\u0000 com.sun.msv.grammar.OneOrMoreExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001ccom.sun.m" +
                    "sv.grammar.UnaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\u0003expq\u0000~\u0000\u0002xq\u0000~\u0000\u0003sr\u0000\u0011java.lang" +
                    ".Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000 com.sun.msv.grammar.Attri" +
                    "buteExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~\u0000\u0002L\u0000\tnameClassq\u0000~\u0000\bxq\u0000~\u0000\u0003q\u0000~\u0000\u0013psr" +
                    "\u00002com.sun.msv.grammar.Expression$AnyStringExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\u0012\u0001q\u0000~\u0000\u0017sr\u0000 com.sun.msv.grammar.AnyNameClass\u0000\u0000\u0000" +
                    "\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000co" +
                    "m.sun.msv.grammar.Expression$EpsilonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000" +
                    "~\u0000\u0003q\u0000~\u0000\u0018q\u0000~\u0000\u001dsr\u0000#com.sun.msv.grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001" +
                    "\u0002\u0000\u0002L\u0000\tlocalNamet\u0000\u0012Ljava/lang/String;L\u0000\fnamespaceURIq\u0000~\u0000\u001fxq\u0000~" +
                    "\u0000\u001at\u0000Gnet.gencat.gecat.batch.BatchRetornHelper.DadesRetornTyp" +
                    "e.DadaRetornTypet\u0000+http://java.sun.com/jaxb/xjc/dummy-elemen" +
                    "tssq\u0000~\u0000\rppsq\u0000~\u0000\u0014q\u0000~\u0000\u0013psr\u0000\u001bcom.sun.msv.grammar.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000" +
                    "\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatype/Datatype;L\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004" +
                    "namet\u0000\u001dLcom/sun/msv/util/StringPair;xq\u0000~\u0000\u0003ppsr\u0000\"com.sun.msv." +
                    "datatype.xsd.QnameType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.xs" +
                    "d.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datatype.xsd.C" +
                    "oncreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype.xsd.XSDatatyp" +
                    "eImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUriq\u0000~\u0000\u001fL\u0000\btypeNameq\u0000~\u0000\u001fL\u0000\nwhite" +
                    "Spacet\u0000.Lcom/sun/msv/datatype/xsd/WhiteSpaceProcessor;xpt\u0000 h" +
                    "ttp://www.w3.org/2001/XMLSchemat\u0000\u0005QNamesr\u00005com.sun.msv.datat" +
                    "ype.xsd.WhiteSpaceProcessor$Collapse\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.m" +
                    "sv.datatype.xsd.WhiteSpaceProcessor\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u00000com.sun." +
                    "msv.grammar.Expression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003pps" +
                    "r\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000\u001fL\u0000" +
                    "\fnamespaceURIq\u0000~\u0000\u001fxpq\u0000~\u00000q\u0000~\u0000/sq\u0000~\u0000\u001et\u0000\u0004typet\u0000)http://www.w3." +
                    "org/2001/XMLSchema-instanceq\u0000~\u0000\u001dsq\u0000~\u0000\u001et\u0000\nDadaRetornt\u0000\u0000sq\u0000~\u0000\r" +
                    "ppsq\u0000~\u0000\u0007q\u0000~\u0000\u0013p\u0000sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0007pp\u0000sq\u0000~\u0000\rppsq\u0000~\u0000\u000fq\u0000~\u0000\u0013psq\u0000~\u0000\u0014q\u0000" +
                    "~\u0000\u0013pq\u0000~\u0000\u0017q\u0000~\u0000\u001bq\u0000~\u0000\u001dsq\u0000~\u0000\u001eq\u0000~\u0000!q\u0000~\u0000\"sq\u0000~\u0000\rppsq\u0000~\u0000\u0014q\u0000~\u0000\u0013pq\u0000~\u0000(" +
                    "q\u0000~\u00008q\u0000~\u0000\u001dq\u0000~\u0000;q\u0000~\u0000\u001dsq\u0000~\u0000\rppsq\u0000~\u0000\u0014q\u0000~\u0000\u0013psq\u0000~\u0000%ppsr\u0000 com.sun." +
                    "msv.datatype.xsd.IntType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000+com.sun.msv.datatype." +
                    "xsd.IntegerDerivedType\u0099\u00f1]\u0090&6k\u00be\u0002\u0000\u0001L\u0000\nbaseFacetst\u0000)Lcom/sun/ms" +
                    "v/datatype/xsd/XSDatatypeImpl;xq\u0000~\u0000*q\u0000~\u0000/t\u0000\u0003intq\u0000~\u00003sr\u0000*com." +
                    "sun.msv.datatype.xsd.MaxInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun" +
                    ".msv.datatype.xsd.RangeFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\nlimitValuet\u0000\u0012Ljava" +
                    "/lang/Object;xr\u00009com.sun.msv.datatype.xsd.DataTypeWithValueC" +
                    "onstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*com.sun.msv.datatype.xsd.DataTy" +
                    "peWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFacetFixedZ\u0000\u0012needValueCheckFlagL\u0000" +
                    "\bbaseTypeq\u0000~\u0000ML\u0000\fconcreteTypet\u0000\'Lcom/sun/msv/datatype/xsd/Co" +
                    "ncreteType;L\u0000\tfacetNameq\u0000~\u0000\u001fxq\u0000~\u0000,ppq\u0000~\u00003\u0000\u0001sr\u0000*com.sun.msv.d" +
                    "atatype.xsd.MinInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Qppq\u0000~\u00003\u0000\u0000sr\u0000!c" +
                    "om.sun.msv.datatype.xsd.LongType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Lq\u0000~\u0000/t\u0000\u0004lon" +
                    "gq\u0000~\u00003sq\u0000~\u0000Pppq\u0000~\u00003\u0000\u0001sq\u0000~\u0000Wppq\u0000~\u00003\u0000\u0000sr\u0000$com.sun.msv.datatype" +
                    ".xsd.IntegerType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000Lq\u0000~\u0000/t\u0000\u0007integerq\u0000~\u00003sr\u0000,com" +
                    ".sun.msv.datatype.xsd.FractionDigitsFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scale" +
                    "xr\u0000;com.sun.msv.datatype.xsd.DataTypeWithLexicalConstraintFa" +
                    "cetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u0000Tppq\u0000~\u00003\u0001\u0000sr\u0000#com.sun.msv.datatype.xsd.Nu" +
                    "mberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000*q\u0000~\u0000/t\u0000\u0007decimalq\u0000~\u00003q\u0000~\u0000et\u0000\u000efractio" +
                    "nDigits\u0000\u0000\u0000\u0000q\u0000~\u0000_t\u0000\fminInclusivesr\u0000\u000ejava.lang.Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001" +
                    "J\u0000\u0005valuexr\u0000\u0010java.lang.Number\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u0000_t\u0000\fmax" +
                    "Inclusivesq\u0000~\u0000i\u007f\u00ff\u00ff\u00ff\u00ff\u00ff\u00ff\u00ffq\u0000~\u0000Zq\u0000~\u0000hsr\u0000\u0011java.lang.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081" +
                    "\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000j\u0080\u0000\u0000\u0000q\u0000~\u0000Zq\u0000~\u0000lsq\u0000~\u0000n\u007f\u00ff\u00ff\u00ffq\u0000~\u00005sq\u0000~\u00006q\u0000~\u0000Oq" +
                    "\u0000~\u0000/sq\u0000~\u0000\u001et\u0000\u0005orderq\u0000~\u0000=q\u0000~\u0000\u001dsr\u0000\"com.sun.msv.grammar.Expressi" +
                    "onPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTablet\u0000/Lcom/sun/msv/grammar/Expressi" +
                    "onPool$ClosedHash;xpsr\u0000-com.sun.msv.grammar.ExpressionPool$C" +
                    "losedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005countB\u0000\rstreamVersionL\u0000\u0006parentt\u0000$Lcom" +
                    "/sun/msv/grammar/ExpressionPool;xp\u0000\u0000\u0000\f\u0001pq\u0000~\u0000>q\u0000~\u0000\u000eq\u0000~\u0000Bq\u0000~\u0000\u0011" +
                    "q\u0000~\u0000Cq\u0000~\u0000\u0006q\u0000~\u0000\u0005q\u0000~\u0000\u000bq\u0000~\u0000#q\u0000~\u0000Fq\u0000~\u0000@q\u0000~\u0000Hx"));
        }

        return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
    }

    public static class DadaRetornTypeImpl implements net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType,
        com.sun.xml.bind.JAXBObject,
        net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.XMLSerializable,
        net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.ValidatableObject {
        public final static java.lang.Class version = (net.gencat.gecat.batch.BatchRetornHelper.impl.JAXBVersion.class);
        private static com.sun.msv.grammar.Grammar schemaFragment;
        protected boolean has_ClasseDocumentLength;
        protected int _ClasseDocumentLength;
        protected boolean has_ExerciciOrder;
        protected int _ExerciciOrder;
        protected boolean has_TextErrorOrder;
        protected int _TextErrorOrder;
        protected boolean has_ExerciciLength;
        protected int _ExerciciLength;
        protected boolean has_NDocumentLength;
        protected int _NDocumentLength;
        protected boolean has_CodiPosicioErrorOrder;
        protected int _CodiPosicioErrorOrder;
        protected boolean has_StatusDocumentOrder;
        protected int _StatusDocumentOrder;
        protected boolean has_CodiPosicioErrorLength;
        protected int _CodiPosicioErrorLength;
        protected boolean has_SocietatFiOrder;
        protected int _SocietatFiOrder;
        protected boolean has_StatusDocumentLength;
        protected int _StatusDocumentLength;
        protected boolean has_TextErrorLength;
        protected int _TextErrorLength;
        protected boolean has_PosicioDocumentOrder;
        protected int _PosicioDocumentOrder;
        protected boolean has_PosicioDocumentLength;
        protected int _PosicioDocumentLength;
        protected boolean has_NDocumentOrder;
        protected int _NDocumentOrder;
        protected boolean has_SocietatFiLength;
        protected int _SocietatFiLength;
        protected boolean has_ClasseDocumentOrder;
        protected int _ClasseDocumentOrder;

        private final static java.lang.Class PRIMARY_INTERFACE_CLASS() {
            return (net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType.class);
        }

        public int getClasseDocumentLength() {
            if (!has_ClasseDocumentLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "2"));
            } else {
                return _ClasseDocumentLength;
            }
        }

        public void setClasseDocumentLength(int value) {
            _ClasseDocumentLength = value;
            has_ClasseDocumentLength = true;
        }

        public int getExerciciOrder() {
            if (!has_ExerciciOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "2"));
            } else {
                return _ExerciciOrder;
            }
        }

        public void setExerciciOrder(int value) {
            _ExerciciOrder = value;
            has_ExerciciOrder = true;
        }

        public int getTextErrorOrder() {
            if (!has_TextErrorOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "8"));
            } else {
                return _TextErrorOrder;
            }
        }

        public void setTextErrorOrder(int value) {
            _TextErrorOrder = value;
            has_TextErrorOrder = true;
        }

        public int getExerciciLength() {
            if (!has_ExerciciLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "4"));
            } else {
                return _ExerciciLength;
            }
        }

        public void setExerciciLength(int value) {
            _ExerciciLength = value;
            has_ExerciciLength = true;
        }

        public int getNDocumentLength() {
            if (!has_NDocumentLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "10"));
            } else {
                return _NDocumentLength;
            }
        }

        public void setNDocumentLength(int value) {
            _NDocumentLength = value;
            has_NDocumentLength = true;
        }

        public int getCodiPosicioErrorOrder() {
            if (!has_CodiPosicioErrorOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "7"));
            } else {
                return _CodiPosicioErrorOrder;
            }
        }

        public void setCodiPosicioErrorOrder(int value) {
            _CodiPosicioErrorOrder = value;
            has_CodiPosicioErrorOrder = true;
        }

        public int getStatusDocumentOrder() {
            if (!has_StatusDocumentOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "6"));
            } else {
                return _StatusDocumentOrder;
            }
        }

        public void setStatusDocumentOrder(int value) {
            _StatusDocumentOrder = value;
            has_StatusDocumentOrder = true;
        }

        public int getCodiPosicioErrorLength() {
            if (!has_CodiPosicioErrorLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "10"));
            } else {
                return _CodiPosicioErrorLength;
            }
        }

        public void setCodiPosicioErrorLength(int value) {
            _CodiPosicioErrorLength = value;
            has_CodiPosicioErrorLength = true;
        }

        public int getSocietatFiOrder() {
            if (!has_SocietatFiOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "1"));
            } else {
                return _SocietatFiOrder;
            }
        }

        public void setSocietatFiOrder(int value) {
            _SocietatFiOrder = value;
            has_SocietatFiOrder = true;
        }

        public int getStatusDocumentLength() {
            if (!has_StatusDocumentLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "1"));
            } else {
                return _StatusDocumentLength;
            }
        }

        public void setStatusDocumentLength(int value) {
            _StatusDocumentLength = value;
            has_StatusDocumentLength = true;
        }

        public int getTextErrorLength() {
            if (!has_TextErrorLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "100"));
            } else {
                return _TextErrorLength;
            }
        }

        public void setTextErrorLength(int value) {
            _TextErrorLength = value;
            has_TextErrorLength = true;
        }

        public int getPosicioDocumentOrder() {
            if (!has_PosicioDocumentOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "5"));
            } else {
                return _PosicioDocumentOrder;
            }
        }

        public void setPosicioDocumentOrder(int value) {
            _PosicioDocumentOrder = value;
            has_PosicioDocumentOrder = true;
        }

        public int getPosicioDocumentLength() {
            if (!has_PosicioDocumentLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "3"));
            } else {
                return _PosicioDocumentLength;
            }
        }

        public void setPosicioDocumentLength(int value) {
            _PosicioDocumentLength = value;
            has_PosicioDocumentLength = true;
        }

        public int getNDocumentOrder() {
            if (!has_NDocumentOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "4"));
            } else {
                return _NDocumentOrder;
            }
        }

        public void setNDocumentOrder(int value) {
            _NDocumentOrder = value;
            has_NDocumentOrder = true;
        }

        public int getSocietatFiLength() {
            if (!has_SocietatFiLength) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "4"));
            } else {
                return _SocietatFiLength;
            }
        }

        public void setSocietatFiLength(int value) {
            _SocietatFiLength = value;
            has_SocietatFiLength = true;
        }

        public int getClasseDocumentOrder() {
            if (!has_ClasseDocumentOrder) {
                return javax.xml.bind.DatatypeConverter.parseInt(com.sun.xml.bind.DatatypeConverterImpl.installHook(
                        "3"));
            } else {
                return _ClasseDocumentOrder;
            }
        }

        public void setClasseDocumentOrder(int value) {
            _ClasseDocumentOrder = value;
            has_ClasseDocumentOrder = true;
        }

        public void serializeBody(
            net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
        }

        public void serializeAttributes(
            net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
            if (has_ClasseDocumentLength) {
                context.startAttribute("", "ClasseDocumentLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ClasseDocumentLength)),
                        "ClasseDocumentLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ClasseDocumentOrder) {
                context.startAttribute("", "ClasseDocumentOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ClasseDocumentOrder)), "ClasseDocumentOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_CodiPosicioErrorLength) {
                context.startAttribute("", "CodiPosicioErrorLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _CodiPosicioErrorLength)),
                        "CodiPosicioErrorLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_CodiPosicioErrorOrder) {
                context.startAttribute("", "CodiPosicioErrorOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _CodiPosicioErrorOrder)),
                        "CodiPosicioErrorOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ExerciciLength) {
                context.startAttribute("", "ExerciciLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ExerciciLength)), "ExerciciLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_ExerciciOrder) {
                context.startAttribute("", "ExerciciOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _ExerciciOrder)), "ExerciciOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_NDocumentLength) {
                context.startAttribute("", "NDocumentLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _NDocumentLength)), "NDocumentLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_NDocumentOrder) {
                context.startAttribute("", "NDocumentOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _NDocumentOrder)), "NDocumentOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_PosicioDocumentLength) {
                context.startAttribute("", "PosicioDocumentLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _PosicioDocumentLength)),
                        "PosicioDocumentLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_PosicioDocumentOrder) {
                context.startAttribute("", "PosicioDocumentOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _PosicioDocumentOrder)),
                        "PosicioDocumentOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_SocietatFiLength) {
                context.startAttribute("", "SocietatFiLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _SocietatFiLength)), "SocietatFiLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_SocietatFiOrder) {
                context.startAttribute("", "SocietatFiOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _SocietatFiOrder)), "SocietatFiOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_StatusDocumentLength) {
                context.startAttribute("", "StatusDocumentLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _StatusDocumentLength)),
                        "StatusDocumentLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_StatusDocumentOrder) {
                context.startAttribute("", "StatusDocumentOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _StatusDocumentOrder)), "StatusDocumentOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TextErrorLength) {
                context.startAttribute("", "TextErrorLength");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TextErrorLength)), "TextErrorLength");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }

            if (has_TextErrorOrder) {
                context.startAttribute("", "TextErrorOrder");

                try {
                    context.text(javax.xml.bind.DatatypeConverter.printInt(
                            ((int) _TextErrorOrder)), "TextErrorOrder");
                } catch (java.lang.Exception e) {
                    net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.Util.handlePrintConversionException(this,
                        e, context);
                }

                context.endAttribute();
            }
        }

        public void serializeURIs(
            net.gencat.gecat.batch.BatchRetornHelper.impl.runtime.XMLSerializer context)
            throws org.xml.sax.SAXException {
        }

        public java.lang.Class getPrimaryInterface() {
            return (net.gencat.gecat.batch.BatchRetornHelper.DadesRetornType.DadaRetornType.class);
        }

        public com.sun.msv.verifier.DocumentDeclaration createRawValidator() {
            if (schemaFragment == null) {
                schemaFragment = com.sun.xml.bind.validator.SchemaDeserializer.deserialize(("\u00ac\u00ed\u0000\u0005sr\u0000\u001fcom.sun.msv.grammar.SequenceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\u001dcom.su" +
                        "n.msv.grammar.BinaryExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0004exp1t\u0000 Lcom/sun/msv/gra" +
                        "mmar/Expression;L\u0000\u0004exp2q\u0000~\u0000\u0002xr\u0000\u001ecom.sun.msv.grammar.Expressi" +
                        "on\u00f8\u0018\u0082\u00e8N5~O\u0002\u0000\u0002L\u0000\u0013epsilonReducibilityt\u0000\u0013Ljava/lang/Boolean;L\u0000\u000b" +
                        "expandedExpq\u0000~\u0000\u0002xpppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000pp" +
                        "sq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~\u0000\u0000ppsq\u0000~" +
                        "\u0000\u0000ppsq\u0000~\u0000\u0000ppsr\u0000\u001dcom.sun.msv.grammar.ChoiceExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~" +
                        "\u0000\u0001ppsr\u0000 com.sun.msv.grammar.AttributeExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\u0003expq\u0000~" +
                        "\u0000\u0002L\u0000\tnameClasst\u0000\u001fLcom/sun/msv/grammar/NameClass;xq\u0000~\u0000\u0003sr\u0000\u0011ja" +
                        "va.lang.Boolean\u00cd r\u0080\u00d5\u009c\u00fa\u00ee\u0002\u0000\u0001Z\u0000\u0005valuexp\u0000psr\u0000\u001bcom.sun.msv.gramma" +
                        "r.DataExp\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\u0002dtt\u0000\u001fLorg/relaxng/datatype/Datatype;L" +
                        "\u0000\u0006exceptq\u0000~\u0000\u0002L\u0000\u0004namet\u0000\u001dLcom/sun/msv/util/StringPair;xq\u0000~\u0000\u0003pp" +
                        "sr\u0000 com.sun.msv.datatype.xsd.IntType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000+com.sun.m" +
                        "sv.datatype.xsd.IntegerDerivedType\u0099\u00f1]\u0090&6k\u00be\u0002\u0000\u0001L\u0000\nbaseFacetst\u0000" +
                        ")Lcom/sun/msv/datatype/xsd/XSDatatypeImpl;xr\u0000*com.sun.msv.da" +
                        "tatype.xsd.BuiltinAtomicType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000%com.sun.msv.datat" +
                        "ype.xsd.ConcreteType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000\'com.sun.msv.datatype.xsd." +
                        "XSDatatypeImpl\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0003L\u0000\fnamespaceUrit\u0000\u0012Ljava/lang/String" +
                        ";L\u0000\btypeNameq\u0000~\u0000%L\u0000\nwhiteSpacet\u0000.Lcom/sun/msv/datatype/xsd/W" +
                        "hiteSpaceProcessor;xpt\u0000 http://www.w3.org/2001/XMLSchemat\u0000\u0003i" +
                        "ntsr\u00005com.sun.msv.datatype.xsd.WhiteSpaceProcessor$Collapse\u0000" +
                        "\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000,com.sun.msv.datatype.xsd.WhiteSpaceProcessor\u0000\u0000" +
                        "\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpsr\u0000*com.sun.msv.datatype.xsd.MaxInclusiveFacet\u0000\u0000\u0000" +
                        "\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xr\u0000#com.sun.msv.datatype.xsd.RangeFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000" +
                        "\nlimitValuet\u0000\u0012Ljava/lang/Object;xr\u00009com.sun.msv.datatype.xsd" +
                        ".DataTypeWithValueConstraintFacet\"\u00a7Ro\u00ca\u00c7\u008aT\u0002\u0000\u0000xr\u0000*com.sun.msv." +
                        "datatype.xsd.DataTypeWithFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0005Z\u0000\fisFacetFixedZ\u0000\u0012n" +
                        "eedValueCheckFlagL\u0000\bbaseTypeq\u0000~\u0000!L\u0000\fconcreteTypet\u0000\'Lcom/sun/" +
                        "msv/datatype/xsd/ConcreteType;L\u0000\tfacetNameq\u0000~\u0000%xq\u0000~\u0000$ppq\u0000~\u0000," +
                        "\u0000\u0001sr\u0000*com.sun.msv.datatype.xsd.MinInclusiveFacet\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000x" +
                        "q\u0000~\u0000.ppq\u0000~\u0000,\u0000\u0000sr\u0000!com.sun.msv.datatype.xsd.LongType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002" +
                        "\u0000\u0000xq\u0000~\u0000 q\u0000~\u0000(t\u0000\u0004longq\u0000~\u0000,sq\u0000~\u0000-ppq\u0000~\u0000,\u0000\u0001sq\u0000~\u00004ppq\u0000~\u0000,\u0000\u0000sr\u0000$c" +
                        "om.sun.msv.datatype.xsd.IntegerType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000 q\u0000~\u0000(t\u0000\u0007" +
                        "integerq\u0000~\u0000,sr\u0000,com.sun.msv.datatype.xsd.FractionDigitsFacet" +
                        "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001I\u0000\u0005scalexr\u0000;com.sun.msv.datatype.xsd.DataTypeWith" +
                        "LexicalConstraintFacetT\u0090\u001c>\u001azb\u00ea\u0002\u0000\u0000xq\u0000~\u00001ppq\u0000~\u0000,\u0001\u0000sr\u0000#com.sun." +
                        "msv.datatype.xsd.NumberType\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\"q\u0000~\u0000(t\u0000\u0007decimalq" +
                        "\u0000~\u0000,q\u0000~\u0000Bt\u0000\u000efractionDigits\u0000\u0000\u0000\u0000q\u0000~\u0000<t\u0000\fminInclusivesr\u0000\u000ejava.l" +
                        "ang.Long;\u008b\u00e4\u0090\u00cc\u008f#\u00df\u0002\u0000\u0001J\u0000\u0005valuexr\u0000\u0010java.lang.Number\u0086\u00ac\u0095\u001d\u000b\u0094\u00e0\u008b\u0002\u0000\u0000xp" +
                        "\u0080\u0000\u0000\u0000\u0000\u0000\u0000\u0000q\u0000~\u0000<t\u0000\fmaxInclusivesq\u0000~\u0000F\u007f\u00ff\u00ff\u00ff\u00ff\u00ff\u00ff\u00ffq\u0000~\u00007q\u0000~\u0000Esr\u0000\u0011java" +
                        ".lang.Integer\u0012\u00e2\u00a0\u00a4\u00f7\u0081\u00878\u0002\u0000\u0001I\u0000\u0005valuexq\u0000~\u0000G\u0080\u0000\u0000\u0000q\u0000~\u00007q\u0000~\u0000Isq\u0000~\u0000K\u007f\u00ff" +
                        "\u00ff\u00ffsr\u00000com.sun.msv.grammar.Expression$NullSetExpression\u0000\u0000\u0000\u0000\u0000\u0000" +
                        "\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003ppsr\u0000\u001bcom.sun.msv.util.StringPair\u00d0t\u001ejB\u008f\u008d\u00a0\u0002\u0000\u0002L\u0000\tlo" +
                        "calNameq\u0000~\u0000%L\u0000\fnamespaceURIq\u0000~\u0000%xpq\u0000~\u0000)q\u0000~\u0000(sr\u0000#com.sun.msv." +
                        "grammar.SimpleNameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0002L\u0000\tlocalNameq\u0000~\u0000%L\u0000\fnamesp" +
                        "aceURIq\u0000~\u0000%xr\u0000\u001dcom.sun.msv.grammar.NameClass\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xpt\u0000\u0014" +
                        "ClasseDocumentLengtht\u0000\u0000sr\u00000com.sun.msv.grammar.Expression$Ep" +
                        "silonExpression\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0000xq\u0000~\u0000\u0003sq\u0000~\u0000\u0019\u0001q\u0000~\u0000Xsq\u0000~\u0000\u0014ppsq\u0000~\u0000\u0016q\u0000" +
                        "~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u0013ClasseDocumentOrderq\u0000~\u0000Vq\u0000~\u0000Xsq\u0000~\u0000\u0014ppsq\u0000~\u0000" +
                        "\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u0016CodiPosicioErrorLengthq\u0000~\u0000Vq\u0000~\u0000Xsq\u0000~\u0000\u0014p" +
                        "psq\u0000~\u0000\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u0015CodiPosicioErrorOrderq\u0000~\u0000Vq\u0000~\u0000Xsq" +
                        "\u0000~\u0000\u0014ppsq\u0000~\u0000\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u000eExerciciLengthq\u0000~\u0000Vq\u0000~\u0000Xsq\u0000~" +
                        "\u0000\u0014ppsq\u0000~\u0000\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\rExerciciOrderq\u0000~\u0000Vq\u0000~\u0000Xsq\u0000~\u0000\u0014p" +
                        "psq\u0000~\u0000\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u000fNDocumentLengthq\u0000~\u0000Vq\u0000~\u0000Xsq\u0000~\u0000\u0014pp" +
                        "sq\u0000~\u0000\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u000eNDocumentOrderq\u0000~\u0000Vq\u0000~\u0000Xsq\u0000~\u0000\u0014ppsq" +
                        "\u0000~\u0000\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u0015PosicioDocumentLengthq\u0000~\u0000Vq\u0000~\u0000Xsq\u0000~\u0000" +
                        "\u0014ppsq\u0000~\u0000\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u0014PosicioDocumentOrderq\u0000~\u0000Vq\u0000~\u0000Xs" +
                        "q\u0000~\u0000\u0014ppsq\u0000~\u0000\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u0010SocietatFiLengthq\u0000~\u0000Vq\u0000~\u0000Xs" +
                        "q\u0000~\u0000\u0014ppsq\u0000~\u0000\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u000fSocietatFiOrderq\u0000~\u0000Vq\u0000~\u0000Xsq" +
                        "\u0000~\u0000\u0014ppsq\u0000~\u0000\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u0014StatusDocumentLengthq\u0000~\u0000Vq\u0000~" +
                        "\u0000Xsq\u0000~\u0000\u0014ppsq\u0000~\u0000\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u0013StatusDocumentOrderq\u0000~\u0000V" +
                        "q\u0000~\u0000Xsq\u0000~\u0000\u0014ppsq\u0000~\u0000\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u000fTextErrorLengthq\u0000~\u0000Vq" +
                        "\u0000~\u0000Xsq\u0000~\u0000\u0014ppsq\u0000~\u0000\u0016q\u0000~\u0000\u001apq\u0000~\u0000\u001esq\u0000~\u0000Rt\u0000\u000eTextErrorOrderq\u0000~\u0000Vq\u0000~" +
                        "\u0000Xsr\u0000\"com.sun.msv.grammar.ExpressionPool\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0002\u0000\u0001L\u0000\bexpTab" +
                        "let\u0000/Lcom/sun/msv/grammar/ExpressionPool$ClosedHash;xpsr\u0000-co" +
                        "m.sun.msv.grammar.ExpressionPool$ClosedHash\u00d7j\u00d0N\u00ef\u00e8\u00ed\u001c\u0003\u0000\u0003I\u0000\u0005cou" +
                        "ntB\u0000\rstreamVersionL\u0000\u0006parentt\u0000$Lcom/sun/msv/grammar/Expressio" +
                        "nPool;xp\u0000\u0000\u0000\u001f\u0001pq\u0000~\u0000\tq\u0000~\u0000\u0082q\u0000~\u0000\u0011q\u0000~\u0000\u0005q\u0000~\u0000\nq\u0000~\u0000\u000bq\u0000~\u0000fq\u0000~\u0000^q\u0000~\u0000\u0012q" +
                        "\u0000~\u0000\u008aq\u0000~\u0000jq\u0000~\u0000\u0086q\u0000~\u0000\bq\u0000~\u0000rq\u0000~\u0000\u0007q\u0000~\u0000\u0013q\u0000~\u0000\u000fq\u0000~\u0000bq\u0000~\u0000zq\u0000~\u0000~q\u0000~\u0000\u0092q" +
                        "\u0000~\u0000\u000eq\u0000~\u0000\rq\u0000~\u0000\u0006q\u0000~\u0000nq\u0000~\u0000\u0010q\u0000~\u0000vq\u0000~\u0000\u0015q\u0000~\u0000\fq\u0000~\u0000\u008eq\u0000~\u0000Zx"));
            }

            return new com.sun.msv.verifier.regexp.REDocumentDeclaration(schemaFragment);
        }
    }
}
