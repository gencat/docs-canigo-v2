/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsComplementarisHelper.verification;

public class DadesDocumentsTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType master) {
        if (true) {
            // If left exists
            // No check for primitive values
            checkOrder(parentLocator, handler, master,
                new java.lang.Integer(master.getOrder()));
        }

        if (null == master.getDadaDocument()) {
            // Report missing object
            handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                    new de.fzi.dbs.verification.event.VerificationEventLocator(
                        parentLocator, master, "DadaDocument"),
                    new de.fzi.dbs.verification.event.structure.EmptyFieldProblem()));
        } else {
            // Check count
            if (master.getDadaDocument().size() < 1) {
                // Report minimum of occurences violated
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "DadaDocument"),
                        new de.fzi.dbs.verification.event.structure.TooFewElementsProblem(
                            master.getDadaDocument().size(), 1)));
            }

            // Check value
            checkDadaDocument(parentLocator, handler, master,
                master.getDadaDocument());
        }
    }

    public void checkOrder(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType master,
        java.lang.Integer value) {
        if (value instanceof java.lang.Integer) {
            java.lang.Integer realValue = ((java.lang.Integer) value);
            // Check primitive value
            {
                // Perform the check
                // Checking class com.sun.msv.datatype.xsd.IntType datatype
                de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                if (null != problem) {
                    // Handle event
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Order"), problem));
                }
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.VerificationEventLocator(
                            parentLocator, master, "Order"),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void checkDadaDocument(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType master,
        java.util.List values) {
        for (int index = 0; (index < values.size()); index++) {
            java.lang.Object item = values.get(index);
            checkDadaDocument(parentLocator, handler, master, index, item);
        }
    }

    public void checkDadaDocument(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler,
        net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType master,
        int index, java.lang.Object value) {
        if (value instanceof net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType) {
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType realValue =
                ((net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType) value);

            {
                // Check complex value
                net.gencat.gecat.batch.DocumentsComplementarisHelper.verification.DadesDocumentsTypeVerifier.DadaDocumentTypeVerifier verifier =
                    new net.gencat.gecat.batch.DocumentsComplementarisHelper.verification.DadesDocumentsTypeVerifier.DadaDocumentTypeVerifier();
                verifier.check(new de.fzi.dbs.verification.event.EntryLocator(
                        parentLocator, master, "DadaDocument", index), handler,
                    realValue);
            }
        } else {
            if (null == value) {
                // todo: report null
            } else {
                // Report wrong class
                handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                        new de.fzi.dbs.verification.event.EntryLocator(
                            parentLocator, master, "DadaDocument", index),
                        new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                            value.getClass())));
            }
        }
    }

    public void check(
        de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
        javax.xml.bind.ValidationEventHandler handler, java.lang.Object object) {
        check(parentLocator, handler,
            ((net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType) object));
    }

    public void check(javax.xml.bind.ValidationEventHandler handler,
        java.lang.Object object) {
        check(null, handler,
            ((net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType) object));
    }

    public static class DadaDocumentTypeVerifier implements de.fzi.dbs.verification.ObjectVerifier {
        public void check(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master) {
            if (true) {
                // If left exists
                // No check for primitive values
                checkClasseDocumentLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getClasseDocumentLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkClasseDocumentOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getClasseDocumentOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkDataComptLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getDataComptLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkDataComptOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getDataComptOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkDataDocumentLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getDataDocumentLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkDataDocumentOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getDataDocumentOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkImportFieldType(parentLocator, handler, master,
                    new java.lang.Integer(master.getImportFieldType()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkImportLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getImportLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkImportOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getImportOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkNDocumentCrearLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getNDocumentCrearLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkNDocumentCrearOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getNDocumentCrearOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkNDocumentModificarLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getNDocumentModificarLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkNDocumentModificarOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getNDocumentModificarOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkPosicioLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getPosicioLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkPosicioOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getPosicioOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkSocietatLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getSocietatLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkSocietatOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getSocietatOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTextLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getTextLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTextOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getTextOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTipusOperacioLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getTipusOperacioLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTipusOperacioOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getTipusOperacioOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTipusRegistreLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getTipusRegistreLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTipusRegistreOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getTipusRegistreOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTransaccioLength(parentLocator, handler, master,
                    new java.lang.Integer(master.getTransaccioLength()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkTransaccioOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getTransaccioOrder()));
            }

            if (true) {
                // If left exists
                // No check for primitive values
                checkOrder(parentLocator, handler, master,
                    new java.lang.Integer(master.getOrder()));
            }
        }

        public void checkClasseDocumentLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "ClasseDocumentLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ClasseDocumentLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkDataDocumentLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "DataDocumentLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DataDocumentLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkImportFieldType(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ImportFieldType"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ImportFieldType"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "Order"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "Order"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkImportLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ImportLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ImportLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTextLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TextLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TextLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkPosicioLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "PosicioLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "PosicioLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkImportOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ImportOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ImportOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTextOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TextOrder"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TextOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkPosicioOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "PosicioOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "PosicioOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkSocietatOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "SocietatOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "SocietatOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkDataComptOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "DataComptOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DataComptOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkNDocumentCrearLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "NDocumentCrearLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "NDocumentCrearLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTipusOperacioOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TipusOperacioOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusOperacioOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTipusRegistreOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TipusRegistreOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusRegistreOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkDataDocumentOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "DataDocumentOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DataDocumentOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkNDocumentCrearOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "NDocumentCrearOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "NDocumentCrearOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkNDocumentModificarOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "NDocumentModificarOrder"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "NDocumentModificarOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTipusOperacioLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TipusOperacioLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusOperacioLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkDataComptLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "DataComptLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "DataComptLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTipusRegistreLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TipusRegistreLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TipusRegistreLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTransaccioOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TransaccioOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TransaccioOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkTransaccioLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "TransaccioLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "TransaccioLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkNDocumentModificarLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master,
                                    "NDocumentModificarLength"), problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master,
                                "NDocumentModificarLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkClasseDocumentOrder(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "ClasseDocumentOrder"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "ClasseDocumentOrder"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void checkSocietatLength(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType master,
            java.lang.Integer value) {
            if (value instanceof java.lang.Integer) {
                java.lang.Integer realValue = ((java.lang.Integer) value);
                // Check primitive value
                {
                    // Perform the check
                    // Checking class com.sun.msv.datatype.xsd.IntType datatype
                    de.fzi.dbs.verification.event.datatype.ValueProblem problem = null;

                    if (null != problem) {
                        // Handle event
                        handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                                new de.fzi.dbs.verification.event.VerificationEventLocator(
                                    parentLocator, master, "SocietatLength"),
                                problem));
                    }
                }
            } else {
                if (null == value) {
                    // todo: report null
                } else {
                    // Report wrong class
                    handler.handleEvent(new de.fzi.dbs.verification.event.VerificationEvent(
                            new de.fzi.dbs.verification.event.VerificationEventLocator(
                                parentLocator, master, "SocietatLength"),
                            new de.fzi.dbs.verification.event.structure.NonExpectedClassProblem(
                                value.getClass())));
                }
            }
        }

        public void check(
            de.fzi.dbs.verification.event.AbstractVerificationEventLocator parentLocator,
            javax.xml.bind.ValidationEventHandler handler,
            java.lang.Object object) {
            check(parentLocator, handler,
                ((net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType) object));
        }

        public void check(javax.xml.bind.ValidationEventHandler handler,
            java.lang.Object object) {
            check(null, handler,
                ((net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType) object));
        }
    }
}
