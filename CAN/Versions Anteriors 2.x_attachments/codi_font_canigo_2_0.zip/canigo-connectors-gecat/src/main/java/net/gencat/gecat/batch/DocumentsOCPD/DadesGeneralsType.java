/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPD;


/**
 * Java content class for DadesGeneralsType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsOCPD.xsd line 33)
 * <p>
 * <pre>
 * &lt;complexType name="DadesGeneralsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DadesPosicio" type="{}DadesPosicioType"/>
 *         &lt;element name="TipusRegistre">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;enumeration value="1"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="Transaccio">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="20"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="NDocument">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="10"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="ClasseDocument">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="2"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="DataDocument">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="8"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="DataCompt">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="8"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="Societat">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="4"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="TipusCanvi">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="9"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="DataConversio">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="8"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *         &lt;element name="Moneda">
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;maxLength value="5"/>
 *           &lt;/restriction>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface DadesGeneralsType {
    /**
     * Gets the value of the classeDocument property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getClasseDocument();

    /**
     * Sets the value of the classeDocument property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setClasseDocument(java.lang.String value);

    /**
     * Gets the value of the transaccio property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getTransaccio();

    /**
     * Sets the value of the transaccio property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setTransaccio(java.lang.String value);

    /**
     * Gets the value of the dadesPosicio property.
     *
     * @return
     *     possible object is
     *     {@link net.gencat.gecat.batch.DocumentsOCPD.DadesPosicioType}
     */
    net.gencat.gecat.batch.DocumentsOCPD.DadesPosicioType getDadesPosicio();

    /**
     * Sets the value of the dadesPosicio property.
     *
     * @param value
     *     allowed object is
     *     {@link net.gencat.gecat.batch.DocumentsOCPD.DadesPosicioType}
     */
    void setDadesPosicio(
        net.gencat.gecat.batch.DocumentsOCPD.DadesPosicioType value);

    /**
     * Gets the value of the dataConversio property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getDataConversio();

    /**
     * Sets the value of the dataConversio property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setDataConversio(java.lang.String value);

    /**
     * Gets the value of the nDocument property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getNDocument();

    /**
     * Sets the value of the nDocument property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setNDocument(java.lang.String value);

    /**
     * Gets the value of the dataDocument property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getDataDocument();

    /**
     * Sets the value of the dataDocument property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setDataDocument(java.lang.String value);

    /**
     * Gets the value of the tipusRegistre property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getTipusRegistre();

    /**
     * Sets the value of the tipusRegistre property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setTipusRegistre(java.lang.String value);

    /**
     * Gets the value of the societat property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getSocietat();

    /**
     * Sets the value of the societat property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setSocietat(java.lang.String value);

    /**
     * Gets the value of the dataCompt property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getDataCompt();

    /**
     * Sets the value of the dataCompt property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setDataCompt(java.lang.String value);

    /**
     * Gets the value of the moneda property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getMoneda();

    /**
     * Sets the value of the moneda property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setMoneda(java.lang.String value);

    /**
     * Gets the value of the tipusCanvi property.
     *
     * @return
     *     possible object is
     *     {@link java.lang.String}
     */
    java.lang.String getTipusCanvi();

    /**
     * Sets the value of the tipusCanvi property.
     *
     * @param value
     *     allowed object is
     *     {@link java.lang.String}
     */
    void setTipusCanvi(java.lang.String value);
}
