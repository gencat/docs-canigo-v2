/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsOCPD;


/**
 * Java content class for DadesPosicioType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsOCPD.xsd line 124)
 * <p>
 * <pre>
 * &lt;complexType name="DadesPosicioType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DadaPosicio" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;choice>
 *                     &lt;element name="DadesPagadorAlternatiu" type="{}DadesPagadorAlternatiuType"/>
 *                     &lt;element name="DadesCreditorCPD" type="{}DadesCreditorCPDType"/>
 *                   &lt;/choice>
 *                   &lt;element name="TipusRegistre">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="1"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="TextDocument">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="25"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="NExpedient">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="30"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Creditor">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="TipusBancInterlocutor">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="4"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="PosicioPressupostaria">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="24"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="ReservaFondos">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Posicio">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="3"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="CentreGestor">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="16"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Referencia">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="16"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Regio">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="CondicioPagament">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="4"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Import">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="13"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="ImportImpost">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="13"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="IndicadorIVA">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="2"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="CalcularImpost">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="1"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Text">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="50"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Fons">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="ViaPagament">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="1"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="BloqueigPagament">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="1"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="DataBase">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="8"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="PagadorAlternatiu">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="CompteMajor">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                   &lt;element name="Assignacio">
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="18"/>
 *                     &lt;/restriction>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface DadesPosicioType {
    /**
     * Gets the value of the DadaPosicio property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the DadaPosicio property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDadaPosicio().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link net.gencat.gecat.batch.DocumentsOCPD.DadesPosicioType.DadaPosicioType}
     *
     */
    java.util.List getDadaPosicio();

    /**
     * Java content class for anonymous complex type.
     *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsOCPD.xsd line 128)
     * <p>
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;choice>
     *           &lt;element name="DadesPagadorAlternatiu" type="{}DadesPagadorAlternatiuType"/>
     *           &lt;element name="DadesCreditorCPD" type="{}DadesCreditorCPDType"/>
     *         &lt;/choice>
     *         &lt;element name="TipusRegistre">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="1"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="TextDocument">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="25"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="NExpedient">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="30"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="Creditor">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="10"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="TipusBancInterlocutor">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="4"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="PosicioPressupostaria">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="24"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="ReservaFondos">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="10"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="Posicio">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="3"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="CentreGestor">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="16"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="Referencia">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="16"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="Regio">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="10"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="CondicioPagament">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="4"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="Import">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="13"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="ImportImpost">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="13"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="IndicadorIVA">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="2"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="CalcularImpost">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="1"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="Text">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="50"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="Fons">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="10"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="ViaPagament">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="1"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="BloqueigPagament">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="1"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="DataBase">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="8"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="PagadorAlternatiu">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="10"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="CompteMajor">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="10"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *         &lt;element name="Assignacio">
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="18"/>
     *           &lt;/restriction>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     *
     */
    public interface DadaPosicioType {
        /**
         * Gets the value of the pagadorAlternatiu property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getPagadorAlternatiu();

        /**
         * Sets the value of the pagadorAlternatiu property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setPagadorAlternatiu(java.lang.String value);

        /**
         * Gets the value of the order property.
         *
         */
        int getOrder();

        /**
         * Sets the value of the order property.
         *
         */
        void setOrder(int value);

        /**
         * Gets the value of the regio property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getRegio();

        /**
         * Sets the value of the regio property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setRegio(java.lang.String value);

        /**
         * Gets the value of the posicio property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getPosicio();

        /**
         * Sets the value of the posicio property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setPosicio(java.lang.String value);

        /**
         * Gets the value of the import property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getImport();

        /**
         * Sets the value of the import property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setImport(java.lang.String value);

        /**
         * Gets the value of the text property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getText();

        /**
         * Sets the value of the text property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setText(java.lang.String value);

        /**
         * Gets the value of the assignacio property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getAssignacio();

        /**
         * Sets the value of the assignacio property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setAssignacio(java.lang.String value);

        /**
         * Gets the value of the textDocument property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getTextDocument();

        /**
         * Sets the value of the textDocument property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setTextDocument(java.lang.String value);

        /**
         * Gets the value of the dataBase property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getDataBase();

        /**
         * Sets the value of the dataBase property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setDataBase(java.lang.String value);

        /**
         * Gets the value of the posicioPressupostaria property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getPosicioPressupostaria();

        /**
         * Sets the value of the posicioPressupostaria property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setPosicioPressupostaria(java.lang.String value);

        /**
         * Gets the value of the dadesCreditorCPD property.
         *
         * @return
         *     possible object is
         *     {@link net.gencat.gecat.batch.DocumentsOCPD.DadesCreditorCPDType}
         */
        net.gencat.gecat.batch.DocumentsOCPD.DadesCreditorCPDType getDadesCreditorCPD();

        /**
         * Sets the value of the dadesCreditorCPD property.
         *
         * @param value
         *     allowed object is
         *     {@link net.gencat.gecat.batch.DocumentsOCPD.DadesCreditorCPDType}
         */
        void setDadesCreditorCPD(
            net.gencat.gecat.batch.DocumentsOCPD.DadesCreditorCPDType value);

        /**
         * Gets the value of the centreGestor property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getCentreGestor();

        /**
         * Sets the value of the centreGestor property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setCentreGestor(java.lang.String value);

        /**
         * Gets the value of the dadesPagadorAlternatiu property.
         *
         * @return
         *     possible object is
         *     {@link net.gencat.gecat.batch.DocumentsOCPD.DadesPagadorAlternatiuType}
         */
        net.gencat.gecat.batch.DocumentsOCPD.DadesPagadorAlternatiuType getDadesPagadorAlternatiu();

        /**
         * Sets the value of the dadesPagadorAlternatiu property.
         *
         * @param value
         *     allowed object is
         *     {@link net.gencat.gecat.batch.DocumentsOCPD.DadesPagadorAlternatiuType}
         */
        void setDadesPagadorAlternatiu(
            net.gencat.gecat.batch.DocumentsOCPD.DadesPagadorAlternatiuType value);

        /**
         * Gets the value of the tipusRegistre property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getTipusRegistre();

        /**
         * Sets the value of the tipusRegistre property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setTipusRegistre(java.lang.String value);

        /**
         * Gets the value of the nExpedient property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getNExpedient();

        /**
         * Sets the value of the nExpedient property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setNExpedient(java.lang.String value);

        /**
         * Gets the value of the condicioPagament property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getCondicioPagament();

        /**
         * Sets the value of the condicioPagament property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setCondicioPagament(java.lang.String value);

        /**
         * Gets the value of the calcularImpost property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getCalcularImpost();

        /**
         * Sets the value of the calcularImpost property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setCalcularImpost(java.lang.String value);

        /**
         * Gets the value of the viaPagament property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getViaPagament();

        /**
         * Sets the value of the viaPagament property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setViaPagament(java.lang.String value);

        /**
         * Gets the value of the reservaFondos property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getReservaFondos();

        /**
         * Sets the value of the reservaFondos property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setReservaFondos(java.lang.String value);

        /**
         * Gets the value of the tipusBancInterlocutor property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getTipusBancInterlocutor();

        /**
         * Sets the value of the tipusBancInterlocutor property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setTipusBancInterlocutor(java.lang.String value);

        /**
         * Gets the value of the indicadorIVA property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getIndicadorIVA();

        /**
         * Sets the value of the indicadorIVA property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setIndicadorIVA(java.lang.String value);

        /**
         * Gets the value of the importImpost property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getImportImpost();

        /**
         * Sets the value of the importImpost property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setImportImpost(java.lang.String value);

        /**
         * Gets the value of the bloqueigPagament property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getBloqueigPagament();

        /**
         * Sets the value of the bloqueigPagament property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setBloqueigPagament(java.lang.String value);

        /**
         * Gets the value of the referencia property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getReferencia();

        /**
         * Sets the value of the referencia property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setReferencia(java.lang.String value);

        /**
         * Gets the value of the compteMajor property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getCompteMajor();

        /**
         * Sets the value of the compteMajor property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setCompteMajor(java.lang.String value);

        /**
         * Gets the value of the fons property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getFons();

        /**
         * Sets the value of the fons property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setFons(java.lang.String value);

        /**
         * Gets the value of the creditor property.
         *
         * @return
         *     possible object is
         *     {@link java.lang.String}
         */
        java.lang.String getCreditor();

        /**
         * Sets the value of the creditor property.
         *
         * @param value
         *     allowed object is
         *     {@link java.lang.String}
         */
        void setCreditor(java.lang.String value);
    }
}
