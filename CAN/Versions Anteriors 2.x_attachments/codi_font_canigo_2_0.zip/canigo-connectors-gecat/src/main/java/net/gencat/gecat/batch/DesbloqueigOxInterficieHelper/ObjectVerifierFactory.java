/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DesbloqueigOxInterficieHelper;

public class ObjectVerifierFactory extends de.fzi.dbs.verification.ObjectVerifierFactory {
    static {
        objectVerifierClasses.put(net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DesbloqueigOxInterficieType.class,
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.verification.DesbloqueigOxInterficieTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.DesbloqueigOxInterficieTypeImpl.class,
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.verification.DesbloqueigOxInterficieTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DesbloqueigOxInterficie.class,
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.verification.DesbloqueigOxInterficieVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.DesbloqueigOxInterficieImpl.class,
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.verification.DesbloqueigOxInterficieVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.DadesType.class,
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.verification.DadesTypeVerifier.class);
        objectVerifierClasses.put(net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.impl.DadesTypeImpl.class,
            net.gencat.gecat.batch.DesbloqueigOxInterficieHelper.verification.DadesTypeVerifier.class);
    }
}
