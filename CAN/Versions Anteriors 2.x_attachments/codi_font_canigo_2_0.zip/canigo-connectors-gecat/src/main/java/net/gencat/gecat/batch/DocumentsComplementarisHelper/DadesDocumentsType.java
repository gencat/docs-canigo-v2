/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canig�, el Framework J2EE de la Generalitat de Catalunya
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!
 * ,.W,d##  M#F  ##r ,##2J$.
 * JJ,4H##  M#F` ##r`,##d3`J
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.gecat.batch.DocumentsComplementarisHelper;


/**
 * Java content class for DadesDocumentsType complex type.
 *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsComplementarisHelper.xsd line 33)
 * <p>
 * <pre>
 * &lt;complexType name="DadesDocumentsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DadaDocument" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="ClasseDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *                 &lt;attribute name="ClasseDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="7" />
 *                 &lt;attribute name="DataComptLength" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
 *                 &lt;attribute name="DataComptOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="6" />
 *                 &lt;attribute name="DataDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
 *                 &lt;attribute name="DataDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
 *                 &lt;attribute name="ImportFieldType" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="ImportLength" type="{http://www.w3.org/2001/XMLSchema}int" default="9" />
 *                 &lt;attribute name="ImportOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="11" />
 *                 &lt;attribute name="NDocumentCrearLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *                 &lt;attribute name="NDocumentCrearOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *                 &lt;attribute name="NDocumentModificarLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
 *                 &lt;attribute name="NDocumentModificarOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
 *                 &lt;attribute name="PosicioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
 *                 &lt;attribute name="PosicioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="9" />
 *                 &lt;attribute name="SocietatLength" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *                 &lt;attribute name="SocietatOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
 *                 &lt;attribute name="TextLength" type="{http://www.w3.org/2001/XMLSchema}int" default="50" />
 *                 &lt;attribute name="TextOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="12" />
 *                 &lt;attribute name="TipusOperacioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="TipusOperacioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
 *                 &lt;attribute name="TipusRegistreLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="TipusRegistreOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *                 &lt;attribute name="TransaccioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="20" />
 *                 &lt;attribute name="TransaccioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
 *                 &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 */
public interface DadesDocumentsType {
    /**
     * Gets the value of the order property.
     *
     */
    int getOrder();

    /**
     * Sets the value of the order property.
     *
     */
    void setOrder(int value);

    /**
     * Gets the value of the DadaDocument property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the DadaDocument property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDadaDocument().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link net.gencat.gecat.batch.DocumentsComplementarisHelper.DadesDocumentsType.DadaDocumentType}
     *
     */
    java.util.List getDadaDocument();

    /**
     * Java content class for anonymous complex type.
     *         <p>The following schema fragment specifies the expected         content contained within this java content object.         (defined at file:/D:/EULOGI/workspace/canigo-connectors-gecat/XMLSchema/DocumentsComplementarisHelper.xsd line 36)
     * <p>
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="ClasseDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
     *       &lt;attribute name="ClasseDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="7" />
     *       &lt;attribute name="DataComptLength" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
     *       &lt;attribute name="DataComptOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="6" />
     *       &lt;attribute name="DataDocumentLength" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
     *       &lt;attribute name="DataDocumentOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
     *       &lt;attribute name="ImportFieldType" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
     *       &lt;attribute name="ImportLength" type="{http://www.w3.org/2001/XMLSchema}int" default="9" />
     *       &lt;attribute name="ImportOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="11" />
     *       &lt;attribute name="NDocumentCrearLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
     *       &lt;attribute name="NDocumentCrearOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
     *       &lt;attribute name="NDocumentModificarLength" type="{http://www.w3.org/2001/XMLSchema}int" default="10" />
     *       &lt;attribute name="NDocumentModificarOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="8" />
     *       &lt;attribute name="PosicioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="5" />
     *       &lt;attribute name="PosicioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="9" />
     *       &lt;attribute name="SocietatLength" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
     *       &lt;attribute name="SocietatOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="4" />
     *       &lt;attribute name="TextLength" type="{http://www.w3.org/2001/XMLSchema}int" default="50" />
     *       &lt;attribute name="TextOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="12" />
     *       &lt;attribute name="TipusOperacioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
     *       &lt;attribute name="TipusOperacioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="3" />
     *       &lt;attribute name="TipusRegistreLength" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
     *       &lt;attribute name="TipusRegistreOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="1" />
     *       &lt;attribute name="TransaccioLength" type="{http://www.w3.org/2001/XMLSchema}int" default="20" />
     *       &lt;attribute name="TransaccioOrder" type="{http://www.w3.org/2001/XMLSchema}int" default="2" />
     *       &lt;attribute name="order" type="{http://www.w3.org/2001/XMLSchema}int" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     *
     */
    public interface DadaDocumentType {
        /**
         * Gets the value of the classeDocumentLength property.
         *
         */
        int getClasseDocumentLength();

        /**
         * Sets the value of the classeDocumentLength property.
         *
         */
        void setClasseDocumentLength(int value);

        /**
         * Gets the value of the dataDocumentLength property.
         *
         */
        int getDataDocumentLength();

        /**
         * Sets the value of the dataDocumentLength property.
         *
         */
        void setDataDocumentLength(int value);

        /**
         * Gets the value of the importFieldType property.
         *
         */
        int getImportFieldType();

        /**
         * Sets the value of the importFieldType property.
         *
         */
        void setImportFieldType(int value);

        /**
         * Gets the value of the order property.
         *
         */
        int getOrder();

        /**
         * Sets the value of the order property.
         *
         */
        void setOrder(int value);

        /**
         * Gets the value of the importLength property.
         *
         */
        int getImportLength();

        /**
         * Sets the value of the importLength property.
         *
         */
        void setImportLength(int value);

        /**
         * Gets the value of the textLength property.
         *
         */
        int getTextLength();

        /**
         * Sets the value of the textLength property.
         *
         */
        void setTextLength(int value);

        /**
         * Gets the value of the posicioLength property.
         *
         */
        int getPosicioLength();

        /**
         * Sets the value of the posicioLength property.
         *
         */
        void setPosicioLength(int value);

        /**
         * Gets the value of the importOrder property.
         *
         */
        int getImportOrder();

        /**
         * Sets the value of the importOrder property.
         *
         */
        void setImportOrder(int value);

        /**
         * Gets the value of the textOrder property.
         *
         */
        int getTextOrder();

        /**
         * Sets the value of the textOrder property.
         *
         */
        void setTextOrder(int value);

        /**
         * Gets the value of the posicioOrder property.
         *
         */
        int getPosicioOrder();

        /**
         * Sets the value of the posicioOrder property.
         *
         */
        void setPosicioOrder(int value);

        /**
         * Gets the value of the societatOrder property.
         *
         */
        int getSocietatOrder();

        /**
         * Sets the value of the societatOrder property.
         *
         */
        void setSocietatOrder(int value);

        /**
         * Gets the value of the dataComptOrder property.
         *
         */
        int getDataComptOrder();

        /**
         * Sets the value of the dataComptOrder property.
         *
         */
        void setDataComptOrder(int value);

        /**
         * Gets the value of the nDocumentCrearLength property.
         *
         */
        int getNDocumentCrearLength();

        /**
         * Sets the value of the nDocumentCrearLength property.
         *
         */
        void setNDocumentCrearLength(int value);

        /**
         * Gets the value of the tipusOperacioOrder property.
         *
         */
        int getTipusOperacioOrder();

        /**
         * Sets the value of the tipusOperacioOrder property.
         *
         */
        void setTipusOperacioOrder(int value);

        /**
         * Gets the value of the tipusRegistreOrder property.
         *
         */
        int getTipusRegistreOrder();

        /**
         * Sets the value of the tipusRegistreOrder property.
         *
         */
        void setTipusRegistreOrder(int value);

        /**
         * Gets the value of the dataDocumentOrder property.
         *
         */
        int getDataDocumentOrder();

        /**
         * Sets the value of the dataDocumentOrder property.
         *
         */
        void setDataDocumentOrder(int value);

        /**
         * Gets the value of the nDocumentCrearOrder property.
         *
         */
        int getNDocumentCrearOrder();

        /**
         * Sets the value of the nDocumentCrearOrder property.
         *
         */
        void setNDocumentCrearOrder(int value);

        /**
         * Gets the value of the nDocumentModificarOrder property.
         *
         */
        int getNDocumentModificarOrder();

        /**
         * Sets the value of the nDocumentModificarOrder property.
         *
         */
        void setNDocumentModificarOrder(int value);

        /**
         * Gets the value of the tipusOperacioLength property.
         *
         */
        int getTipusOperacioLength();

        /**
         * Sets the value of the tipusOperacioLength property.
         *
         */
        void setTipusOperacioLength(int value);

        /**
         * Gets the value of the dataComptLength property.
         *
         */
        int getDataComptLength();

        /**
         * Sets the value of the dataComptLength property.
         *
         */
        void setDataComptLength(int value);

        /**
         * Gets the value of the tipusRegistreLength property.
         *
         */
        int getTipusRegistreLength();

        /**
         * Sets the value of the tipusRegistreLength property.
         *
         */
        void setTipusRegistreLength(int value);

        /**
         * Gets the value of the transaccioOrder property.
         *
         */
        int getTransaccioOrder();

        /**
         * Sets the value of the transaccioOrder property.
         *
         */
        void setTransaccioOrder(int value);

        /**
         * Gets the value of the transaccioLength property.
         *
         */
        int getTransaccioLength();

        /**
         * Sets the value of the transaccioLength property.
         *
         */
        void setTransaccioLength(int value);

        /**
         * Gets the value of the nDocumentModificarLength property.
         *
         */
        int getNDocumentModificarLength();

        /**
         * Sets the value of the nDocumentModificarLength property.
         *
         */
        void setNDocumentModificarLength(int value);

        /**
         * Gets the value of the classeDocumentOrder property.
         *
         */
        int getClasseDocumentOrder();

        /**
         * Sets the value of the classeDocumentOrder property.
         *
         */
        void setClasseDocumentOrder(int value);

        /**
         * Gets the value of the societatLength property.
         *
         */
        int getSocietatLength();

        /**
         * Sets the value of the societatLength property.
         *
         */
        void setSocietatLength(int value);
    }
}
