/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.samples.prototip.web.propertyeditors;

import java.beans.PropertyEditorSupport;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.security.model.Role;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class CustomRolesEditor extends PropertyEditorSupport {
   /**
    * Documentaci�.
    */
   private LoggingService logService = null;

   /**
    * @return Returns the logService.
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * @param logService The logService to set.
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getValue() {
      if (this.logService != null) {
         this.logService.getLog(this.getClass())
                        .debug("getValue=" + super.getValue());
      }

      return super.getValue();
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setValue(Object value) {
      if (value != null) {
         if (this.logService != null) {
            this.logService.getLog(this.getClass())
                           .debug("setValue=" + value + " of class " +
               value.getClass().getName());
         }

         if (value instanceof String[]) {
            Set roles = new HashSet();
            String[] ids = (String[]) value;

            for (int i = 0; i < ids.length; i++) {
               if (this.logService != null) {
                  this.logService.getLog(this.getClass())
                                 .debug("adding role=" + ids[i]);
               }

               Role r = new Role();
               r.setId(new Integer(ids[i]));
               roles.add(r);
            }

            super.setValue(roles);
         } else if (value instanceof Set) {
            super.setValue(value);
         }
      } else {
         super.setValue(value);
      }
   }

   /**
    * Documentaci�.
    *
    * @param text Documentaci�
    *
    * @throws IllegalArgumentException Documentaci�
    */
   public void setAsText(String text) throws IllegalArgumentException {
      if (text != null) {
         Set roles = new HashSet();

         if (this.logService != null) {
            this.logService.getLog(this.getClass()).debug("adding role=" +
               text);
         }

         Role r = new Role();
         r.setId(new Integer(text));
         roles.add(r);
         super.setValue(roles);
      } else {
         super.setAsText(text);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getAsText() {
      if (this.logService != null) {
         this.logService.getLog(this.getClass())
                        .debug("getAsText=" + super.getAsText());
      }

      if ((this.getValue() != null) && this.getValue() instanceof Set) {
         Set roles = (Set) this.getValue();
         StringBuffer selecteds = new StringBuffer();
         Iterator it = roles.iterator();

         while (it.hasNext()) {
            Role r = (Role) it.next();
            selecteds.append(r.getId());

            if (it.hasNext()) {
               selecteds.append(",");
            }
         }

         return selecteds.toString();
      }

      return super.getAsText();
   }
}
