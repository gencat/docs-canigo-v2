/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.samples.prototip.exceptions;

import net.gencat.ctti.canigo.services.exceptions.BusinessException;
import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class UnknownDirectory extends BusinessException {
   /**
    * Creates a new UnknownDirectory object.
    */
   public UnknownDirectory() {
      super();

      // TODO Auto-generated constructor stub
   }

   /**
    * Creates a new UnknownDirectory object.
    *
    * @param arg0 DOCUMENT ME.
    * @param arg1 DOCUMENT ME.
    */
   public UnknownDirectory(Throwable arg0, ExceptionDetails arg1) {
      super(arg0, arg1);

      // TODO Auto-generated constructor stub
   }

   /**
    * Creates a new UnknownDirectory object.
    *
    * @param arg0 DOCUMENT ME.
    */
   public UnknownDirectory(ExceptionDetails arg0) {
      super(arg0);

      // TODO Auto-generated constructor stub
   }

   /**
    * Creates a new UnknownDirectory object.
    *
    * @param arg0 DOCUMENT ME.
    */
   public UnknownDirectory(String arg0) {
      super(arg0);

      // TODO Auto-generated constructor stub
   }

   /**
    * Creates a new UnknownDirectory object.
    *
    * @param arg0 DOCUMENT ME.
    * @param arg1 DOCUMENT ME.
    */
   public UnknownDirectory(String arg0, Object[] arg1) {
      super(arg0, arg1);

      // TODO Auto-generated constructor stub
   }

   /**
    * Creates a new UnknownDirectory object.
    *
    * @param arg0 DOCUMENT ME.
    * @param arg1 DOCUMENT ME.
    * @param arg2 DOCUMENT ME.
    */
   public UnknownDirectory(String arg0, Object[] arg1, Layer arg2) {
      super(arg0, arg1, arg2);

      // TODO Auto-generated constructor stub
   }

   /**
    * Creates a new UnknownDirectory object.
    *
    * @param arg0 DOCUMENT ME.
    * @param arg1 DOCUMENT ME.
    * @param arg2 DOCUMENT ME.
    * @param arg3 DOCUMENT ME.
    */
   public UnknownDirectory(String arg0, Object[] arg1, Layer arg2,
      Subsystem arg3) {
      super(arg0, arg1, arg2, arg3);

      // TODO Auto-generated constructor stub
   }

   /**
    * Creates a new UnknownDirectory object.
    *
    * @param arg0 DOCUMENT ME.
    * @param arg1 DOCUMENT ME.
    */
   public UnknownDirectory(Throwable arg0, String arg1) {
      super(arg0, arg1);

      // TODO Auto-generated constructor stub
   }

   /**
    * Creates a new UnknownDirectory object.
    *
    * @param arg0 DOCUMENT ME.
    * @param arg1 DOCUMENT ME.
    * @param arg2 DOCUMENT ME.
    */
   public UnknownDirectory(Throwable arg0, String arg1, Object[] arg2) {
      super(arg0, arg1, arg2);

      // TODO Auto-generated constructor stub
   }

   /**
    * Creates a new UnknownDirectory object.
    *
    * @param arg0 DOCUMENT ME.
    * @param arg1 DOCUMENT ME.
    * @param arg2 DOCUMENT ME.
    * @param arg3 DOCUMENT ME.
    */
   public UnknownDirectory(Throwable arg0, String arg1, Object[] arg2,
      Layer arg3) {
      super(arg0, arg1, arg2, arg3);

      // TODO Auto-generated constructor stub
   }

   /**
    * Creates a new UnknownDirectory object.
    *
    * @param arg0 DOCUMENT ME.
    * @param arg1 DOCUMENT ME.
    * @param arg2 DOCUMENT ME.
    * @param arg3 DOCUMENT ME.
    * @param arg4 DOCUMENT ME.
    */
   public UnknownDirectory(Throwable arg0, String arg1, Object[] arg2,
      Layer arg3, Subsystem arg4) {
      super(arg0, arg1, arg2, arg3, arg4);

      // TODO Auto-generated constructor stub
   }
}
