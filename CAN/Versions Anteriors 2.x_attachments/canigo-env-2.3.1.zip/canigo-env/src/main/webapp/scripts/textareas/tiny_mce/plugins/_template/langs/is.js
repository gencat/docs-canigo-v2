// Iceland lang variables by Johannes Birgir Jensson

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : '&THORN;etta er sni&eth;m&aacute;tsgluggi',
template_desc : '&THORN;etta er  sni&eth;m&aacute;tstakki'
});
