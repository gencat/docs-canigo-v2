// FI lang variables by Tuomo Aura, Ateco.fi

tinyMCE.addToLang('',{
insert_advhr_desc : 'Lis&auml;&auml; / Muokkaa vaakaviivaa',
insert_advhr_width : 'Leveys',
insert_advhr_size : 'Korkeus',
insert_advhr_noshade : 'Ei varjostusta'
});
