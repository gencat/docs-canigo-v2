CREATE OR REPLACE TRIGGER ACL_OBJ_TRIGGER
before insert on ACL_OBJECT_IDENTITY
for each row
begin
select ACL_OBJECT_SEQ.nextval into :new.id from dual;
end;

CREATE OR REPLACE TRIGGER ACL_PERMISSION_TRIGGER
before insert on ACL_PERMISSION
for each row
begin
select ACL_PERMISSION_SEQ.nextval into :new.id from dual;
end;

CREATE OR REPLACE TRIGGER PARTY_OBJECT_SEQ_TRIGGER
before insert on PARTY_GROUP
for each row
WHEN (new.PARTY_ID is null)
begin
select PARTY_OBJECT_SEQ.nextval into :new.PARTY_ID from dual;
end;

CREATE OR REPLACE TRIGGER ROLE_OBJECT_SEQ_TRIGGER
before insert on ROLE 
for each row 
WHEN (new.ROLE_ID is null)
begin
select ROLE_OBJECT_SEQ.nextval into :new.ROLE_ID from dual;
end;