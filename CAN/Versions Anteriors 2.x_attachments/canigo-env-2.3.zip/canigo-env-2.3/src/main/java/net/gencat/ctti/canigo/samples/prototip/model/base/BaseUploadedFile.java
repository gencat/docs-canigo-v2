/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.samples.prototip.model.base;

import java.io.Serializable;

import java.lang.Comparable;


/**
 * This is an object that contains data related to the UPLOADED_FILE table.
 * Do not modify this class because it will be overwritten if the configuration file
 * related to this class is modified.
 *
 * @hibernate.class
 *  table="UPLOADED_FILE"
 */
public abstract class BaseUploadedFile implements Comparable, Serializable {
   /**
    * Documentaci�.
    */
   public static String REF = "UploadedFile";

   /**
    * Documentaci�.
    */
   public static String PROP_BYTES = "bytes";

   /**
    * Documentaci�.
    */
   public static String PROP_PATH = "path";

   /**
    * Documentaci�.
    */
   public static String PROP_ID = "id";

   // primary key
   /**
    * Documentaci�.
    */
   private java.lang.String id;

   /**
    * Documentaci�.
    */
   private java.lang.String path;

   // fields
   /**
    * Documentaci�.
    */
   private byte[] bytes;

   /**
    * Documentaci�.
    */
   private int hashCode = Integer.MIN_VALUE;

   // constructors
   /**
    * Creates a new BaseUploadedFile object.
    */
   public BaseUploadedFile() {
      initialize();
   }

   /**
    * Constructor for primary key
    */
   public BaseUploadedFile(java.lang.String id) {
      this.setId(id);
      initialize();
   }

   /**
    * Constructor for required fields
    */
   public BaseUploadedFile(java.lang.String id, byte[] bytes,
      java.lang.String path) {
      this.setId(id);
      this.setBytes(bytes);
      this.setPath(path);
      initialize();
   }

   /**
    * Documentaci�.
    */
   protected void initialize() {
   }

   /**
    * Return the unique identifier of this class
   * @hibernate.id
   *  generator-class="assigned"
   *  column="NAME"
   */
   public java.lang.String getId() {
      return id;
   }

   /**
    * Set the unique identifier of this class
    * @param id the new ID
    */
   public void setId(java.lang.String id) {
      this.id = id;
      this.hashCode = Integer.MIN_VALUE;
   }

   /**
    * Return the value associated with the column: BYTES
    */
   public byte[] getBytes() {
      return bytes;
   }

   /**
    * Set the value related to the column: BYTES
    * @param bytes the BYTES value
    */
   public void setBytes(byte[] bytes) {
      this.bytes = bytes;
   }

   /**
    * Return the value associated with the column: PATH
    */
   public java.lang.String getPath() {
      return path;
   }

   /**
    * Set the value related to the column: PATH
    * @param path the PATH value
    */
   public void setPath(java.lang.String path) {
      this.path = path;
   }

   /**
    * Documentaci�.
    *
    * @param obj Documentaci�
    *
    * @return Documentaci�
    */
   public boolean equals(Object obj) {
      if (null == obj) {
         return false;
      }

      if (!(obj instanceof net.gencat.ctti.canigo.samples.prototip.model.UploadedFile)) {
         return false;
      } else {
         net.gencat.ctti.canigo.samples.prototip.model.UploadedFile uploadedFile =
            (net.gencat.ctti.canigo.samples.prototip.model.UploadedFile) obj;

         if ((null == this.getId()) || (null == uploadedFile.getId())) {
            return false;
         } else {
            return (this.getId().equals(uploadedFile.getId()));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int hashCode() {
      if (Integer.MIN_VALUE == this.hashCode) {
         if (null == this.getId()) {
            return super.hashCode();
         } else {
            String hashStr = this.getClass().getName() + ":" +
               this.getId().hashCode();
            this.hashCode = hashStr.hashCode();
         }
      }

      return this.hashCode;
   }

   /**
    * Documentaci�.
    *
    * @param obj Documentaci�
    *
    * @return Documentaci�
    */
   public int compareTo(Object obj) {
      if (obj.hashCode() > hashCode()) {
         return 1;
      } else if (obj.hashCode() < hashCode()) {
         return -1;
      } else {
         return 0;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String toString() {
      return super.toString();
   }
}
