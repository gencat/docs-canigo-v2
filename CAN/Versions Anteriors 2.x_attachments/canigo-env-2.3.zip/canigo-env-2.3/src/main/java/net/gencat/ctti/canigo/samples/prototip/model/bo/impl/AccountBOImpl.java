/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.samples.prototip.model.bo.impl;

import java.util.List;

import net.gencat.ctti.canigo.samples.prototip.model.Account;
import net.gencat.ctti.canigo.samples.prototip.model.bo.AccountBO;
import net.gencat.ctti.canigo.services.persistence.HibernateDAO;
import net.gencat.ctti.canigo.services.persistence.UniversalHibernateDAO;

import org.apache.commons.beanutils.BeanUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class AccountBOImpl implements AccountBO {
   /**
    * Documentaci�.
    */
   UniversalHibernateDAO dao;

   /**
    * Creates a new AccountBOImpl object.
    */
   public AccountBOImpl() {
      super();
   }

   /**
    * Documentaci�.
    */
   public void test() {
      System.out.println("------------> test");
   }

   /**
    * Documentaci�.
    *
    * @param id Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public Account getAccountById(String id) throws Exception {
      return (Account) dao.get(Account.class, id);
   }

   /**
    * Documentaci�.
    *
    * @param account Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void save(Account account) throws Exception {
      // First try to see if exists the account
      //Account tmpAccount = new Account();
      //BeanUtils.copyProperties(tmpAccount,account);

      //dao.refresh(account);
      //BeanUtils.copyProperties(account,tmpAccount);		
      this.test();
      dao.save(account);
   }

   /**
    * Documentaci�.
    *
    * @param account Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void update(Account account) throws Exception {
      this.test();

      Account tmpAccount = new Account();
      tmpAccount.setId(account.getId());
      BeanUtils.copyProperties(tmpAccount, account);
      //		
      dao.refresh(tmpAccount);
      BeanUtils.copyProperties(tmpAccount, account);
      //		accountDAO.refresh(tmpAccount);
      //		BeanUtils.c
      System.out.println("Update");
      dao.update(tmpAccount);
   }

   /**
    * Documentaci�.
    *
    * @param account Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void delete(Account account) throws Exception {
      this.test();
      dao.delete(account);
   }

   /**
    * Documentaci�.
    *
    * @param account Documentaci�
    *
    * @return Documentaci�
    */
   public Account load(Account account) {
      this.test();
      dao.refresh(account);

      return account;
   }

   /**
    * Documentaci�.
    *
    * @param account Documentaci�
    *
    * @return Documentaci�
    */
   public Account refresh(Account account) {
      this.test();
      dao.refresh(account);

      return account;
   }

   /**
    * Documentaci�.
    *
    * @param account Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void saveOrUpdate(Account account) throws Exception {
      this.test();
      dao.saveOrUpdate(account);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List findAll() {
      return ((HibernateDAO) (dao)).findAll();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public UniversalHibernateDAO getDao() {
      return dao;
   }

   /**
    * Documentaci�.
    *
    * @param dao Documentaci�
    */
   public void setDao(UniversalHibernateDAO dao) {
      this.dao = dao;
   }
}
