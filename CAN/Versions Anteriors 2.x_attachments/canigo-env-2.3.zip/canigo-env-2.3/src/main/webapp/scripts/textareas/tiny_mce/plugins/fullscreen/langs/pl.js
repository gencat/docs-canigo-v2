// UK lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Tryb pe�noekranowy',
fullscreen_desc : 'W��cz tryb pe�noekranowy'
});
