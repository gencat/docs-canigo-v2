/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2007/05/23 11:11:18 msabates Exp $ 
 */  

tinyMCE.addToLang('',{
autosave_unload_msg : 'Změny, které jste udělal(a) budou ztraceny, jestliže opustíte tuto stránku.'
});

