// PL lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'Dokonane zmiany zostan� utracone je�lo opu�cisz t� stron�.'
});
