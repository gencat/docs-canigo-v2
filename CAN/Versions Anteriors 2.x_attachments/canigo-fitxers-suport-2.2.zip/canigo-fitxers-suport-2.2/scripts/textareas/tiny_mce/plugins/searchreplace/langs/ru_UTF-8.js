// RU UTF-8 lang variables

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Найти',
searchreplace_searchnext_desc : 'Найти опять',
searchreplace_replace_desc : 'Найти/Заменить',
searchreplace_notfound : 'Поиск завершён. Искомое выражение не найдено.',
searchreplace_search_title : 'Найти',
searchreplace_replace_title : 'Найти/Заменить',
searchreplace_allreplaced : 'Замена была выполнена во всех случаях совпадения искомого выражения.',
searchreplace_findwhat : 'Найти что',
searchreplace_replacewith : 'Заменить чем',
searchreplace_direction : 'Направление',
searchreplace_up : 'Вверх',
searchreplace_down : 'Вниз',
searchreplace_case : 'С учётом регистра',
searchreplace_findnext : 'Найти&nbsp;следующее',
searchreplace_replace : 'Заменить',
searchreplace_replaceall : 'Заменить&nbsp;везде',
searchreplace_cancel : 'Отменить'
});
