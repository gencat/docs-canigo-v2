// Iceland lang variables by Johannes Birgir Jensson

tinyMCE.addToLang('',{
save_desc : 'Vista'
});
