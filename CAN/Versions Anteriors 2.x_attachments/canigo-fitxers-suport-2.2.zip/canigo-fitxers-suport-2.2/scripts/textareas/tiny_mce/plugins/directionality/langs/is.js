// Iceland lang variables by Johannes Birgir Jensson

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Fr&aacute; vinstri til h&aelig;gri',
directionality_rtl_desc : 'Fr&aacute; h&aelig;gri til vinstri'
});
