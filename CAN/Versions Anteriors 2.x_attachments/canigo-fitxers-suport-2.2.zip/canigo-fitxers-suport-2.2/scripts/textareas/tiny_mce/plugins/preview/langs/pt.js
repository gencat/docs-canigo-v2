// UK lang variables

tinyMCE.addToLang('',{
preview_desc : 'Pr�-visualiza��o'
});
