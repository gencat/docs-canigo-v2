// Franch lang variables by Laurent Dran

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Trouver',
searchreplace_searchnext_desc : 'Trouver encore',
searchreplace_replace_desc : 'Trouver/Remplacer',
searchreplace_notfound : 'Votre recherche a &eacute;t&eacute; compl&eacute;&eacute;. La recherche de la chaine pourra ne pas aboutir.',
searchreplace_search_title : 'Trouver',
searchreplace_replace_title : 'Trouver/Remplacer',
searchreplace_allreplaced : 'Toutes les occurences de la chaine ont &eacute;t&eacute; remplc&eacute;es.',
searchreplace_findwhat : 'Trouver le mot',
searchreplace_replacewith : 'Remplacer avec',
searchreplace_direction : 'Direction',
searchreplace_up : 'Haut',
searchreplace_down : 'Base',
searchreplace_case : 'Respecter la casse',
searchreplace_findnext : 'Trouver le prochain',
searchreplace_replace : 'Remplacer',
searchreplace_replaceall : 'Remplacer tout',
searchreplace_cancel : 'Annuler'
});
