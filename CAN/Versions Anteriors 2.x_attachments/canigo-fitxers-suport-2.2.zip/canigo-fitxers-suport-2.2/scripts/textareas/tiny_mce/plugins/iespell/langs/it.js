// IT lang variables

tinyMCE.addToLang('',{
iespell_desc : 'Avvia il controllo ortografico',
iespell_download : "ieSpell non trovato. Clicca OK per andare alla pagina di download."
});

