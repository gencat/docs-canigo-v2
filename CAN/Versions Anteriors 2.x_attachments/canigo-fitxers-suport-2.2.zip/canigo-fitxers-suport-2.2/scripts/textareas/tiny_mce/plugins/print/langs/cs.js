/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2007/05/23 11:11:19 msabates Exp $ 
 */  

tinyMCE.addToLang('',{
print_desc : 'Tisk'
});

