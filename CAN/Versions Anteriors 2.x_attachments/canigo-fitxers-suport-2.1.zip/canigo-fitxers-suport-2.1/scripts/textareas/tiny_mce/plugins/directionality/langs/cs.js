/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2007/05/23 11:11:18 msabates Exp $ 
 */  

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Směr z leva doprava',
directionality_rtl_desc : 'Směr z prava doleva'
});

