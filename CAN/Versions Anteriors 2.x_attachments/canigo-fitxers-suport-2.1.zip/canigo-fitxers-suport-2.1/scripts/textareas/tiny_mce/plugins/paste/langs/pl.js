// UK lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Wstaw jako tekst',
paste_text_title : 'U�yj CTRL+V na klawiaturze aby wstawi� tekst do okna.',
paste_text_linebreaks : 'Zachowaj prze�amania linii',
paste_word_desc : 'Wstaw z Word\'a',
paste_word_title : 'U�yj CTRL+V na klawiaturze aby wstawi� tekst do okna.',
selectall_desc : 'Zaznacz wszystko'
});
