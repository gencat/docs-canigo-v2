// IT lang variables

tinyMCE.addToLang('',{
preview_desc : 'Anteprima'
});
