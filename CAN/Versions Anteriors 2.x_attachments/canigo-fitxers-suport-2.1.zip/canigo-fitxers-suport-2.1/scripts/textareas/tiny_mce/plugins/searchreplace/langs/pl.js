// PL lang variables

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Znajd�',
searchreplace_searchnext_desc : 'Znajd� ponownie',
searchreplace_replace_desc : 'Znajd�/Zast�p',
searchreplace_notfound : 'Uko�czono wyszukiwanie. Poszukiwana fraza nie zosta�a odnaleziona.',
searchreplace_search_title : 'Znajd�',
searchreplace_replace_title : 'Znajd�/Zast�p',
searchreplace_allreplaced : 'Wszystkie wyst�pienia poszukiwanej frazy zosta�y zast�pione. ',
searchreplace_findwhat : 'Znajd�',
searchreplace_replacewith : 'Zast�p',
searchreplace_direction : 'Kierunek',
searchreplace_up : 'Do g�ry',
searchreplace_down : 'Do do�u',
searchreplace_case : 'Wielko�� liter',
searchreplace_findnext : 'Znajd�&nbsp;nast�pny',
searchreplace_replace : 'Zast�p',
searchreplace_replaceall : 'Zast�p&nbsp;wszystkie',
searchreplace_cancel : 'Wyjd�'
});
