// PL lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Wstaw/Edytuj pozioma linie',
insert_advhr_width : 'Szerokosc',
insert_advhr_size : 'Wysokosc',
insert_advhr_noshade : 'Brak cienia'
});
