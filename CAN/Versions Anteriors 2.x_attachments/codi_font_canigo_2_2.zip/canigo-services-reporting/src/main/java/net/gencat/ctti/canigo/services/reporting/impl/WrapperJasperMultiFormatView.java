/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.reporting.impl;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletResponse;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.reporting.exception.ReportingServiceException;
import net.sf.jasperreports.engine.JasperPrint;

import org.springframework.beans.BeanUtils;
import org.springframework.util.ClassUtils;
import org.springframework.web.servlet.view.jasperreports.JasperReportsMultiFormatView;


/**
 * Jasper Reports view class that allows for the actual rendering format to be
 * specified at runtime using a parameter contained in the model.
 *
 * <p>This view works on the concept of a format key and a mapping key.
 * The format key is used to pass the mapping key from your
 * <code>Controller</code> to Spring through as part of the model and the
 * mapping key is used to map a logical format to an actual JasperReports
 * view class. For example you might add the following code to your
 * <code>Controller</code>:
 *
 * <pre>
 * Map model = new HashMap();
 * model.put("format", "pdf");</pre>
 *
 * Here <code>format</code> is the format key and <code>pdf</code> is
 * the mapping key. When rendering a report, this class looks for a
 * model parameter under the format key, which by default is
 * <code>format</code>. It then uses the value of this parameter to lookup
 * the actual <code>View</code> class to use. The default mappings for this
 * lookup are:
 *
 * <p><ul>
 * <li><code>csv</code> - <code>WrapperJasperCsvView</code></li>
 * <li><code>html</code> - <code>WrapperJasperHtmlView</code></li>
 * <li><code>pdf</code> - <code>WrapperJasperPdfView</code></li>
 * <li><code>xls</code> - <code>WrapperJasperXlsView</code></li>
 * <li><code>rtf</code> - <code>WrapperJasperRtfView</code></li>
 * </ul>
 *
 * <p>The format key can be changed using the <code>formatKey</code>
 * property and the mapping key to view class mappings can be changed using the
 * <code>formatMappings</code> property.
 *
 * @author Rob Harrop
 * @since 1.1.5
 * @see #setFormatKey(String)
 * @see #setFormatMappings(java.util.Properties)
 */
public class WrapperJasperMultiFormatView extends WrapperAbstractJasperView {
   /**
    * Stores the format mappings, with the format discriminator
    * as key and the corresponding view class as value.
    */
   public Map formatMappings;

   /**
    * The key of the model parameter that holds the format key.
    */
   public String formatKey = WrappedJasperMultiFormatView.DEFAULT_FORMAT_KEY;

   /**
    * Documentaci�.
    */
   WrappedJasperMultiFormatView delegate;

   /**
          * Creates a new <code>WrapperJasperMultiFormatView</code> instance
          * with a default set of mappings.
          */
   public WrapperJasperMultiFormatView() {
      delegate = new WrappedJasperMultiFormatView();
      formatMappings = new HashMap(4);
      formatMappings.put("csv", WrapperJasperCsvView.class);
      formatMappings.put("html", WrapperJasperHtmlView.class);
      formatMappings.put("pdf", WrapperJasperPdfView.class);
      formatMappings.put("xls", WrapperJasperXlsView.class);
      formatMappings.put("rtf", WrapperJasperRtfView.class);
   }

   /**
    * Documentaci�.
    *
    * @param formatKey Documentaci�
    */
   public void setFormatKey(String formatKey) {
      this.formatKey = formatKey;
      delegate.setFormatKey(formatKey);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getFormatKey() {
      return this.formatKey;
   }

   /**
    * Set the mappings of format discriminators to view class names.
    * The default mappings are:
    * <p><ul>
    * <li><code>csv</code> - <code>WrapperJasperCsvView</code></li>
    * <li><code>html</code> - <code>WrapperJasperHtmlView</code></li>
    * <li><code>pdf</code> - <code>WrapperJasperPdfView</code></li>
    * <li><code>xls</code> - <code>WrapperJasperXlsView</code></li>
    * <li><code>rtf</code> - <code>WrapperJasperRtfView</code></li>
    * </ul>
    */
   public void setFormatMappings(Properties mappingsWithClassNames) {
      if ((mappingsWithClassNames == null) || mappingsWithClassNames.isEmpty()) {
         throw new IllegalArgumentException("formatMappings must not be empty");
      }

      this.formatMappings = new HashMap(mappingsWithClassNames.size());

      for (Enumeration discriminators = mappingsWithClassNames.propertyNames();
            discriminators.hasMoreElements();) {
         String discriminator = (String) discriminators.nextElement();
         String className = mappingsWithClassNames.getProperty(discriminator);

         try {
            if (this.logService != null) {
               this.logService.getLog(this.getClass().getName())
                              .debug("Mapped view class [" + className +
                  "] to mapping key [" + discriminator + "]");
            }

            this.formatMappings.put(discriminator, ClassUtils.forName(className));
         } catch (ClassNotFoundException ex) {
            String[] args = { className, discriminator };
            ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.reporting.setFormatMappings",
                  args, Layer.SERVICES, Subsystem.REPORTING_SERVICES);
            exDetails.setProperties(new Properties());
            throw new ReportingServiceException(ex, exDetails);
         }
      }

      delegate.setFormatMappings(mappingsWithClassNames);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getFormatMappings() {
      return this.formatMappings;
   }

   /**
    * Set the mappings of <code>Content-Disposition</code> header values to
    * mapping keys. If specified, Spring will look at these mappings to determine
    * the value of the <code>Content-Disposition</code> header for a given
    * format mapping.
    */
   public void setContentDispositionMappings(Properties mappings) {
      delegate.setContentDispositionMappings(mappings);
   }

   /**
    * Gets the mappings of <code>Content-Disposition</code> header values to
    * mapping keys.
    */
   public Properties getContentDispositionMappings() {
      // NOTE: Added to support configuration through the properties file mechanism.
      return delegate.getContentDispositionMappings();
   }

   /**
    * Locates the format key in the model using the configured discriminator key and uses this
    * key to lookup the appropriate view class from the mappings. The rendering of the
    * report is then delegated to an instance of that view class.
    */
   protected void renderReport(JasperPrint populatedReport, Map model,
      HttpServletResponse response) throws ReportingServiceException {
      String format = (String) model.get(getFormatKey());

      if (format == null) {
         String[] args = {  };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.reporting.withoutFormatInModel",
               args, Layer.SERVICES, Subsystem.REPORTING_SERVICES);
         exDetails.setProperties(new Properties());
         throw new ReportingServiceException(exDetails);
      }

      if (this.logService != null) {
         this.logService.getLog(this.getClass().getName())
                        .debug("Rendering report using format mapping key [" +
            format + "]");
      }

      Class viewClass = (Class) getFormatMappings().get(format);

      if (viewClass == null) {
         String[] args = { format };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.reporting.formatNotConfigured",
               args, Layer.SERVICES, Subsystem.REPORTING_SERVICES);
         exDetails.setProperties(new Properties());
         throw new ReportingServiceException(exDetails);
      }

      if (this.logService != null) {
         this.logService.getLog(this.getClass().getName())
                        .debug("Rendering report using view class [" +
            viewClass.getName() + "]");
      }

      WrapperAbstractJasperView view = (WrapperAbstractJasperView) BeanUtils.instantiateClass(viewClass);

      // Copy appropriate properties across.
      view.setExporterParameters(delegate.getExporterParameters());

      // Can skip most initialization since all relevant
      // URL processing has been done - just need to convert
      // parameters on the sub view..
      view.wrappedConvertExporterParameters();

      response.setContentType(view.getContentType());

      populateContentDispositionIfNecessary(format, response);

      view.renderReport(populatedReport, model, response);
   }

   /**
    * Adds/overwrites the <code>Content-Disposition</code> header value with the format-specific
    * value if the mappings have been specified and a valid one exists for the given format.
    * @param format the format key of the mapping
    * @param response the <code>HttpServletResponse</code> to set the header in
    * @see #setContentDispositionMappings
    */
   private void populateContentDispositionIfNecessary(String format,
      HttpServletResponse response) {
      if (delegate.getContentDispositionMappings() != null) {
         String header = delegate.getContentDispositionMappings()
                                 .getProperty(format);

         if (header != null) {
            if (this.logService != null) {
               this.logService.getLog(this.getClass().getName())
                              .debug("Setting Content-Disposition header to: [" +
                  header + "]");
            }

            response.setHeader(HEADER_CONTENT_DISPOSITION, header);
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.5 $
     */
   private class WrappedJasperMultiFormatView
      extends JasperReportsMultiFormatView {
   }
}
