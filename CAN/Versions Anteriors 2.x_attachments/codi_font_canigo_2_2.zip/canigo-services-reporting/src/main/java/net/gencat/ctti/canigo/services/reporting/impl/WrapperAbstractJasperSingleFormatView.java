/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.reporting.impl;

import java.io.ByteArrayOutputStream;

import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.reporting.exception.ReportingServiceException;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperPrint;

import org.springframework.ui.jasperreports.JasperReportsUtils;


/**
 * Extends <code>AbstractJasperReportsView</code> to provide basic rendering logic for
 * views that are fixed format, i.e. always PDF or always HTML.
 *
 * <p>Subclasses need to implement two template methods: <code>createExporter</code>
 * to create a JasperReports exporter for a specific output format, and
 * <code>useWriter</code> to determine whether to write text or binary content.
 *
 * @author Rob Harrop
 * @author Juergen Hoeller
 * @since 1.1.5
 * @see #createExporter()
 * @see #useWriter()
 */
public abstract class WrapperAbstractJasperSingleFormatView
   extends WrapperAbstractJasperView {
   /**
    * Initial size for the output array.
    */
   private static final int OUTPUT_BYTE_ARRAY_INITIAL_SIZE = 4096;

   /**
    * Perform rendering for a single Jasper Reports exporter,
    * i.e. a pre-defined output format.
    */
   protected void renderReport(JasperPrint populatedReport, Map model,
      HttpServletResponse response) throws ReportingServiceException {
      try {
         // Prepare report for rendering.
         JRExporter exporter = createExporter();

         if (getConvertedExporterParameters() != null) {
            exporter.setParameters(getConvertedExporterParameters());
         }

         if (useWriter()) {
            // Copy the encoding configured for the report into the response-
            String encoding = (String) exporter.getParameter(JRExporterParameter.CHARACTER_ENCODING);

            if (encoding != null) {
               response.setCharacterEncoding(encoding);
            }

            // Render report into HttpServletResponse's Writer.
            JasperReportsUtils.render(exporter, populatedReport,
               response.getWriter());
         } else {
            // Render report into local OutputStream.
            // IE workaround: write into byte array first.
            ByteArrayOutputStream baos = new ByteArrayOutputStream(OUTPUT_BYTE_ARRAY_INITIAL_SIZE);
            JasperReportsUtils.render(exporter, populatedReport, baos);

            // Write content length (determined via byte array).
            response.setContentLength(baos.size());

            // Flush byte array to servlet output stream.
            ServletOutputStream out = response.getOutputStream();
            baos.writeTo(out);
            out.flush();
         }
      } catch (Exception ex) {
         String[] args = { populatedReport.getName() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.services.reporting.renderReport",
               args, Layer.SERVICES, Subsystem.REPORTING_SERVICES);
         exDetails.setProperties(new Properties());
         throw new ReportingServiceException(ex, exDetails);
      }
   }

   /**
    * Create a JasperReports exporter for a specific output format,
    * which will be used to render the report to the HTTP response.
    * <p>The <code>useWriter</code> method determines whether the
    * output will be written as text or as binary content.
    * @see #useWriter
    */
   protected abstract JRExporter createExporter();

   /**
    * Return whether to use a <code>java.io.Writer</code> to write text content
    * to the HTTP response. Else, a <code>java.io.OutputStream</code> will be used,
    * to write binary content to the response.
    * @see javax.servlet.ServletResponse#getWriter
    * @see javax.servlet.ServletResponse#getOutputStream
    */
   public abstract boolean useWriter();
}
