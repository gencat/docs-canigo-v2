/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.reporting;

import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.web.struts.SpringBindingActionForm;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class SpringBindingFormJRDataSource implements JRDataSource {
   /**
    * Documentaci�.
    */
   private LoggingService logService = null;

   /**
    * Documentaci�.
    */
   private SpringBindingActionForm form = null;

   /**
    * Documentaci�.
    */
   private boolean isFirst = true;

   /**
    * Creates a new SpringBindingFormJRDataSource object.
    *
    * @param form DOCUMENT ME.
    */
   public SpringBindingFormJRDataSource(SpringBindingActionForm form) {
      this.form = form;
   }

   /**
    * Documentaci�.
    *
    * @param field Documentaci�
    *
    * @return Documentaci�
    *
    * @throws JRException Documentaci�
    */
   public Object getFieldValue(JRField field) throws JRException {
      if (this.logService != null) {
         this.logService.getLog(this.getClass())
                        .debug("Getting field " + field.getName() + " from " +
            this.form);
      }

      try {
         Object o = this.form.getErrors().getFieldValue(field.getName());

         if (this.logService != null) {
            this.logService.getLog(this.getClass()).debug("Value is " + o);
         }

         return o;
      } catch (Exception e) {
         if (this.logService != null) {
            this.logService.getLog(this.getClass())
                           .error("Cannot get field " + field.getName());
         }

         throw new JRException(e);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws JRException Documentaci�
    */
   public boolean next() throws JRException {
      if (isFirst) {
         this.isFirst = false;

         return true;
      }

      return false;
   }

   /**
    * @return Returns the logService.
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * @param logService
    *            The logService to set.
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }
}
