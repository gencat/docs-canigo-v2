/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.reporting.impl;

import java.io.OutputStream;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.reporting.exception.ReportingServiceException;
import net.gencat.ctti.canigo.services.reporting.impl.WrapperJasperPdfView;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JasperPrint;

import org.springframework.ui.jasperreports.JasperReportsUtils;


/**
 * Implementaci�n especifica del render para Reports PDF. <br>
 * La modificaci�n que se a�ade es que el report generado puede ser volcado <br>
 * en cualquier OutputStream (FileOutputStream, BytearrayOutputStream), en vez de la rigidez de <br>
 * volcarlo siempre sobre el response HTTP. <br>
 *
 * Esta clase puede ser invocada directamente desde un Action, de tal manera que este le pase <br>
 * el modelo de datos para realizar el render y el outputstream sobre el que volcar el documento generado.<br>
 *
 * @author A111422
 *
 */
public class RenderJasperReportPDFView extends WrapperJasperPdfView {
   /**
    * Prepares the view given the specified model, merging it with static
    * attributes.
    * Delegates to renderMergedOutputModel for the actual rendering.
    * @see #renderMergedOutputModel
    */
   public void render(Map pModel, HttpServletRequest pRequest, OutputStream pOut)
      throws Exception {
      if (logger.isDebugEnabled()) {
         logger.debug("Rendering view with name '" + getBeanName() +
            "' with model " + pModel + " and static attributes " +
            getStaticAttributes());
      }

      // consolidate static and dynamic model attributes
      Map mergedModel = new HashMap(getStaticAttributes().size() +
            ((pModel != null) ? pModel.size() : 0));
      mergedModel.putAll(getStaticAttributes());

      if (pModel != null) {
         mergedModel.putAll(pModel);
      }

      renderMergedOutputModel(mergedModel, pRequest, pOut);
   }

   /**
    * Finds the report data to use for rendering the report and then invokes the
    * <code>renderReport</code> method that should be implemented by the subclass.
    * @param model the model map, as passed in for view rendering. Must contain
    * a report data value that can be converted to a <code>JRDataSource</code>,
    * acccording to the <code>getReportData</code> method.
    * @see #getReportData
    */
   protected void renderMergedOutputModel(Map model,
      HttpServletRequest pRequest, OutputStream pOut)
      throws ReportingServiceException {
      try {
         // Expose Spring-managed Locale and MessageSource.
         exposeLocalizationContext(model, pRequest);

         // Fill and render the report.
         JasperPrint filledReport = fillReport(model);
         postProcessReport(filledReport, model);
         renderReport(filledReport, model, pOut);
      } catch (Exception e) {
         String[] args = { e.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.reporting.gral",
               args, Layer.SERVICES, Subsystem.REPORTING_SERVICES);
         exDetails.setProperties(new Properties());
         throw new ReportingServiceException(exDetails);
      }
   }

   /**
    * Realiza el render para un Jasper Report, y vuelca el report obtenido <br>
    * sobre el OutputStream recibido como par�metro.
    *
    */
   protected void renderReport(JasperPrint populatedReport, Map model,
      OutputStream pOut) throws ReportingServiceException {
      try {
         // Prepare report for rendering.
         JRExporter exporter = createExporter();

         if (getConvertedExporterParameters() != null) {
            exporter.setParameters(getConvertedExporterParameters());
         }

         JasperReportsUtils.render(exporter, populatedReport, pOut);
      } catch (Exception ex) {
         String[] args = { populatedReport.getName() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.reporting.renderReport",
               args, Layer.SERVICES, Subsystem.REPORTING_SERVICES);
         exDetails.setProperties(new Properties());
         throw new ReportingServiceException(ex, exDetails);
      }
   }
}
