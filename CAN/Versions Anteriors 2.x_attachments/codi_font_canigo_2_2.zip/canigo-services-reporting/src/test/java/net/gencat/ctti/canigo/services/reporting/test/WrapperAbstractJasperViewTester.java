/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.reporting.test;

import java.sql.SQLException;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import net.gencat.ctti.canigo.services.reporting.exception.ReportingServiceException;
import net.gencat.ctti.canigo.services.reporting.impl.WrapperAbstractJasperSingleFormatView;
import net.gencat.ctti.canigo.services.reporting.impl.WrapperAbstractJasperView;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRAbstractBeanDataSourceProvider;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.easymock.MockControl;
import org.springframework.context.support.StaticApplicationContext;


/**
 * @author Rob Harrop
 * @author Juergen Hoeller
 */
public abstract class WrapperAbstractJasperViewTester
   extends WrapperAbstractJasperTester {
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected abstract WrapperAbstractJasperView getViewImplementation();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected abstract String getDesiredContentType();

   /**
    * Documentaci�.
    *
    * @param url Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   protected WrapperAbstractJasperView getView(String url)
      throws Exception {
      WrapperAbstractJasperView view = getViewImplementation();
      view.setUrl(url);

      StaticApplicationContext ac = new StaticApplicationContext();
      ac.addMessage("page", Locale.GERMAN, "MeineSeite");
      ac.refresh();
      view.setApplicationContext(ac);

      return view;
   }

   /**
    * Simple test to see if compiled report succeeds.
    */
   public void testCompiledReport() throws Exception {
      try {
         if (!canCompileReport) {
            return;
         }

         WrapperAbstractJasperView view = getView(COMPILED_REPORT);
         view.render(getModel(), request, response);
         assertTrue(response.getContentAsByteArray().length > 0);

         if (view instanceof WrapperAbstractJasperSingleFormatView &&
               ((WrapperAbstractJasperSingleFormatView) view).useWriter()) {
            String output = response.getContentAsString();
            assertTrue("Output should contain 'MeineSeite'",
               output.indexOf("MeineSeite") > -1);
         }
      } catch (Exception e) {
         fail("ERROR: " + e.getLocalizedMessage());
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testUncompiledReport() throws Exception {
      if (!canCompileReport) {
         return;
      }

      WrapperAbstractJasperView view = getView(UNCOMPILED_REPORT);
      view.render(getModel(), request, response);
      assertTrue(response.getContentAsByteArray().length > 0);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWithInvalidPath() throws Exception {
      try {
         getView("foo.jasper");
         fail("Invalid path should throw ApplicationContextException");
      } catch (ReportingServiceException rse) {
         // expected
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testInvalidExtension() throws Exception {
      try {
         getView("foo.bar");
         fail("Invalid extension should throw IllegalArgumentException");
      } catch (ReportingServiceException rse) {
         // expected
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testContentType() throws Exception {
      WrapperAbstractJasperView view = getView(COMPILED_REPORT);

      // removed assert because not all views no in advance what the content type will be,
      // plus the important test is the finished response.
      //assertEquals("View content type is incorrect", getDesiredContentType(), view.getContentType());
      view.render(getModel(), request, response);
      assertEquals("Response content type is incorrect",
         getDesiredContentType(), response.getContentType());
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWithoutDatasource() throws Exception {
      Map model = getModel();
      model.remove("dataSource");

      try {
         WrapperAbstractJasperView view = getView(COMPILED_REPORT);
         view.render(model, request, response);
         fail("No data source should result in NoDataSourceException");
      } catch (ReportingServiceException rse) {
         // expected
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWithCollection() throws Exception {
      Map model = getModel();
      model.remove("dataSource");
      model.put("reportData", getData());

      WrapperAbstractJasperView view = getView(COMPILED_REPORT);
      view.render(model, request, response);
      assertTrue(response.getContentAsByteArray().length > 0);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWithMultipleCollections() throws Exception {
      Map model = getModel();
      model.remove("dataSource");
      model.put("reportData", getData());
      model.put("otherData", new LinkedList());

      try {
         WrapperAbstractJasperView view = getView(COMPILED_REPORT);
         view.render(model, request, response);
         fail("No data source should result in NoDataSourceException");
      } catch (ReportingServiceException rse) {
         // expected
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWithJRDataSourceProvider() throws Exception {
      Map model = getModel();
      model.remove("dataSource");
      model.put("dataSource", new MockDataSourceProvider(PersonBean.class));

      WrapperAbstractJasperView view = getView(COMPILED_REPORT);
      view.render(model, request, response);
      assertTrue(response.getContentAsByteArray().length > 0);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWithSpecificCollection() throws Exception {
      Map model = getModel();
      model.remove("dataSource");
      model.put("reportData", getData());
      model.put("otherData", new LinkedList());

      WrapperAbstractJasperView view = getView(COMPILED_REPORT);
      view.setReportDataKey("reportData");
      view.render(model, request, response);
      assertTrue(response.getContentAsByteArray().length > 0);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWithArray() throws Exception {
      Map model = getModel();
      model.remove("dataSource");
      model.put("reportData", getData().toArray());

      WrapperAbstractJasperView view = getView(COMPILED_REPORT);
      view.render(model, request, response);
      assertTrue(response.getContentAsByteArray().length > 0);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWithMultipleArrays() throws Exception {
      Map model = getModel();
      model.remove("dataSource");
      model.put("reportData", getData().toArray());
      model.put("otherData", new String[0]);

      try {
         WrapperAbstractJasperView view = getView(COMPILED_REPORT);
         view.render(model, request, response);
         fail("No data source should result in NoDataSourceException");
      } catch (ReportingServiceException rse) {
         // expected
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWithSpecificArray() throws Exception {
      Map model = getModel();
      model.remove("dataSource");
      model.put("reportData", getData().toArray());
      model.put("otherData", new String[0]);

      WrapperAbstractJasperView view = getView(COMPILED_REPORT);
      view.setReportDataKey("reportData");
      view.render(model, request, response);
      assertTrue(response.getContentAsByteArray().length > 0);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWithSubReport() throws Exception {
      if (!canCompileReport) {
         return;
      }

      Map model = getModel();
      model.put("SubReportData", getProductData());

      Properties subReports = new Properties();
      subReports.put("ProductsSubReport", "jasperreports/subReportChild.jrxml");

      WrapperAbstractJasperView view = getView(SUB_REPORT_PARENT);
      view.setReportDataKey("dataSource");
      view.setSubReportUrls(subReports);
      view.setSubReportDataKeys(new String[] { "SubReportData" });
      view.render(model, request, response);

      assertTrue(response.getContentAsByteArray().length > 0);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWithNonExistentSubReport() throws Exception {
      if (!canCompileReport) {
         return;
      }

      Map model = getModel();
      model.put("SubReportData", getProductData());

      Properties subReports = new Properties();
      subReports.put("ProductsSubReport",
         "jasperreports/subReportChildFalse.jrxml");

      WrapperAbstractJasperView view = getView(SUB_REPORT_PARENT);
      view.setReportDataKey("dataSource");
      view.setSubReportUrls(subReports);
      view.setSubReportDataKeys(new String[] { "SubReportData" });
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testSubReportWithUnspecifiedParentDataSource()
      throws Exception {
      if (!canCompileReport) {
         return;
      }

      Map model = getModel();
      model.put("SubReportData", getProductData());

      Properties subReports = new Properties();
      subReports.put("ProductsSubReport",
         "jasperreports/subReportChildFalse.jrxml");

      WrapperAbstractJasperView view = getView(SUB_REPORT_PARENT);
      view.setSubReportUrls(subReports);
      view.setSubReportDataKeys(new String[] { "SubReportData" });
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testContentDisposition() throws Exception {
      WrapperAbstractJasperView view = getView(COMPILED_REPORT);
      view.render(getModel(), request, response);
      assertEquals("Invalid content type", "inline",
         response.getHeader("Content-Disposition"));
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testOverrideContentDisposition() throws Exception {
      Properties headers = new Properties();
      String cd = "attachment";
      headers.setProperty("Content-Disposition", cd);

      WrapperAbstractJasperView view = getView(COMPILED_REPORT);
      view.setHeaders(headers);
      view.render(getModel(), request, response);
      assertEquals("Invalid content type", cd,
         response.getHeader("Content-Disposition"));
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testSetCustomHeaders() throws Exception {
      Properties headers = new Properties();

      String key = "foo";
      String value = "bar";

      headers.setProperty(key, value);

      WrapperAbstractJasperView view = getView(COMPILED_REPORT);
      view.setHeaders(headers);
      view.render(getModel(), request, response);

      assertNotNull("Header not present", response.getHeader(key));
      assertEquals("Invalid header value", value, response.getHeader(key));
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWithSqlDataSource() throws Exception {
      if (!canCompileReport) {
         return;
      }

      WrapperAbstractJasperView view = getView(UNCOMPILED_REPORT);
      view.setJdbcDataSource(getMockSqlDataSource());

      Map model = getModel();
      model.remove("dataSource");

      try {
         view.render(model, request, response);
         fail("DataSource was not used as report DataSource");
      } catch (ReportingServiceException rse) {
         // expected
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testJRDataSourceOverridesDataSource() throws Exception {
      if (!canCompileReport) {
         return;
      }

      WrapperAbstractJasperView view = getView(UNCOMPILED_REPORT);
      view.setJdbcDataSource(getMockSqlDataSource());

      try {
         view.render(getModel(), request, response);
      } catch (SQLException ex) {
         fail(
            "javax.sql.DataSource was used when JRDataSource should have overriden it");
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testWithCharacterEncoding() throws Exception {
      WrapperAbstractJasperView view = getView(COMPILED_REPORT);

      if (!(view instanceof WrapperAbstractJasperSingleFormatView) ||
            !((WrapperAbstractJasperSingleFormatView) view).useWriter()) {
         return;
      }

      String characterEncoding = "UTF-8";

      Map parameters = new HashMap();
      parameters.put(JRExporterParameter.CHARACTER_ENCODING, characterEncoding);

      view.setExporterParameters(parameters);
      view.wrappedConvertExporterParameters();

      view.render(getModel(), this.request, this.response);

      assertEquals(characterEncoding, this.response.getCharacterEncoding());
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws SQLException Documentaci�
    */
   private DataSource getMockSqlDataSource() throws SQLException {
      MockControl ctl = MockControl.createControl(DataSource.class);
      DataSource ds = (DataSource) ctl.getMock();
      ds.getConnection();
      ctl.setThrowable(new SQLException());
      ctl.replay();

      return ds;
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.5 $
     */
   private class MockDataSourceProvider extends JRAbstractBeanDataSourceProvider {
      /**
       * Creates a new MockDataSourceProvider object.
       *
       * @param clazz DOCUMENT ME.
       */
      public MockDataSourceProvider(Class clazz) {
         super(clazz);
      }

      /**
       * Documentaci�.
       *
       * @param jasperReport Documentaci�
       *
       * @return Documentaci�
       *
       * @throws JRException Documentaci�
       */
      public JRDataSource create(JasperReport jasperReport)
         throws JRException {
         return new JRBeanCollectionDataSource(getData());
      }

      /**
       * Documentaci�.
       *
       * @param jrDataSource Documentaci�
       *
       * @throws JRException Documentaci�
       */
      public void dispose(JRDataSource jrDataSource) throws JRException {
      }
   }
}
