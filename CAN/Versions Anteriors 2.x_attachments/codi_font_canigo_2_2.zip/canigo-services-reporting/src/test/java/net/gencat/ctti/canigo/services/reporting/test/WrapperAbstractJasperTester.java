/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.reporting.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import junit.framework.TestCase;

import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;


/**
 * @author Rob Harrop
 * @since 18.11.2004
 */
public abstract class WrapperAbstractJasperTester extends TestCase {
   /**
    * Documentaci�.
    */
   protected static final String COMPILED_REPORT = "jasperreports/DataSourceReport.jasper";

   /**
    * Documentaci�.
    */
   protected static final String UNCOMPILED_REPORT = "jasperreports/DataSourceReport.jrxml";

   /**
    * Documentaci�.
    */
   protected static final String SUB_REPORT_PARENT = "jasperreports/subReportParent.jrxml";

   /**
    * Documentaci�.
    */
   public static boolean canCompileReport;

   static {
      try {
         Class.forName("org.eclipse.jdt.internal.compiler.Compiler");
         canCompileReport = true;
      } catch (ClassNotFoundException ex) {
         canCompileReport = false;
      }
   }

   /**
    * Documentaci�.
    */
   protected MockHttpServletRequest request;

   /**
    * Documentaci�.
    */
   protected MockHttpServletResponse response;

   /**
    * Documentaci�.
    */
   public void setUp() {
      request = new MockHttpServletRequest();
      response = new MockHttpServletResponse();

      request.setAttribute(DispatcherServlet.LOCALE_RESOLVER_ATTRIBUTE,
         new AcceptHeaderLocaleResolver());
      request.addPreferredLocale(Locale.GERMAN);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected Map getModel() {
      Map model = new HashMap();
      model.put("ReportTitle", "Dear Lord!");
      model.put("dataSource", new JRBeanCollectionDataSource(getData()));
      extendModel(model);

      return model;
   }

   /**
    * Subclasses can extend the model if they need to.
    */
   protected void extendModel(Map model) {
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected List getData() {
      List list = new ArrayList();

      for (int x = 0; x < 10; x++) {
         PersonBean bean = new PersonBean();
         bean.setId(x);
         bean.setName("Rob Harrop");
         bean.setStreet("foo");
         list.add(bean);
      }

      return list;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected List getProductData() {
      List list = new ArrayList();

      for (int x = 0; x < 10; x++) {
         ProductBean bean = new ProductBean();
         bean.setId(x);
         bean.setName("Foo Bar");
         bean.setPrice(1.9f);
         bean.setQuantity(1.0f);

         list.add(bean);
      }

      return list;
   }
}
