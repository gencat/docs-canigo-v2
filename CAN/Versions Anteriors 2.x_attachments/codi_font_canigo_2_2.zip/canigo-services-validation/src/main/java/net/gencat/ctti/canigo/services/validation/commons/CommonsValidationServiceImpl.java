/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.validation.commons;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.logging.Log;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.validation.BindFieldException;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.validation.commons.util.ValidationInfo;
import net.gencat.ctti.canigo.services.validation.commons.util.ValidationInfoSet;
import net.gencat.ctti.canigo.services.validation.exception.ValidationServiceException;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.validator.Arg;
import org.apache.commons.validator.Field;
import org.apache.commons.validator.Form;
import org.apache.commons.validator.Msg;
import org.apache.commons.validator.Validator;
import org.apache.commons.validator.ValidatorAction;
import org.apache.commons.validator.ValidatorException;
import org.apache.commons.validator.ValidatorResources;
import org.apache.commons.validator.ValidatorResult;
import org.apache.commons.validator.ValidatorResults;
import org.apache.commons.validator.Var;
import org.apache.commons.validator.util.ValidatorUtils;
import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springmodules.validation.commons.DefaultValidatorFactory;
import org.springmodules.validation.commons.ValidatorFactory;


/**
 * Definici� de la validaci�
 *
 * @since
 */
public class CommonsValidationServiceImpl implements ValidationService {
   /**
    * El log.
    */
   private static transient Log log;

   /**
    * Servei d'internacionalitzaci�. Per obtenir missatges de validaci�
    */
   private I18nService i18nService;

   /**
    * Servei Logging.
    */
   private LoggingService loggingService;

   /**
    * Spring ValidatorFactory
    */
   private ValidatorFactory validatorFactory;

   /**
    * Get an Errors object that contains errors
    * on validation
    *
    * @param aName Name of validator
    * @param aFieldName Name of field to validate
    * @param aValue Value of field
    *
    * @return Errors object
    */

   //    public Errors getStringValidationResults(String aName, String aFieldName,
   //                                             String aValue) {
   //        return getValidationResults(aName, aFieldName, aValue);
   //    }
   private Log getLog() {
      if (log == null) {
         log = loggingService.getLog(this.getClass());
      }

      return log;
   }

   /**
    * Obt� el resultat de la validaci� d'un bean complet.
    *
    * @param aName String
    * @param aValue Object
    *
    * @return Errors
    */
   public Errors getValidationResults(String aName, Object aValue)
      throws ValidationServiceException {
      if (getLog().isDebugEnabled()) {
         getLog()
            .debug("Begin getValidationResults(name:" + aName + ",value:" +
            aValue + ")");
      }

      try {
         // Obtain validator resources
         ValidatorResources validatorResources = validatorFactory.getValidatorResources();

         // Create validator from aName
         Validator validator = new Validator(validatorResources, aName);
         validator.setParameter(Validator.LOCALE_PARAM,
            i18nService.getCurrentLocale());
         validator.setParameter(Validator.BEAN_PARAM, aValue);
         // �?�?
         validator.setParameter(DefaultValidatorFactory.ERRORS_KEY,
            new BindException(aValue, "bean"));

         // Get results of the validation
         ValidatorResults results = null;

         results = validator.validate();

         if (getLog().isDebugEnabled()) {
            getLog()
               .debug("End getValidationResults(name:" + aName + ",value:" +
               aValue + "):" + results);
         }

         return parseResults(aName, aValue, results, validatorResources);
      } catch (Throwable e) {
         // TODO Creare exception of ValidationServiceException
         getLog()
            .error("Validation Error (name:" + aName + ", value:" + aValue, e);
         e.printStackTrace();

         return null;
      }
   }

   //    /**
   //     * Obtain validation results of field
   //     *
   //     * @param aName DOCUMENT ME!
   //     * @param aFieldName DOCUMENT ME!
   //     * @param aFieldValue DOCUMENT ME!
   //     *
   //     * @return DOCUMENT ME!
   //     */
   //    public Errors getValidationResultsTextFieldCopy(String aValidatorName,String aFieldName,String aFieldValue,String aErrorKey,String dependentFields)
   //        throws ValidationServiceException {
   //
   //    	if (getLog().isDebugEnabled()) {
   //      	   getLog().debug("Begin getValidationResultsTextField(name:"+aValidatorName+",fieldName:"+aFieldName+",fieldValue:"+aFieldValue+",errorKey:"+aErrorKey+",dependentFields:"+dependentFields+")");
   //      	}
   //    	
   //    	
   //    	//    	 Get results of the validation.
   //		ValidatorResults results = null;
   //		Errors errorsTotal=null;
   //		try {
   //    	
   //		// Obtain validator resources
   //		ValidatorResources validatorResources = validatorFactory.getValidatorResources();
   //			
   //		//vemos si hay un metodo de validacion o mas
   //		//String metodoValidacio=aValidatorName;
   //		FwkField tmpF = new FwkField(); 
   //		StringTokenizer tokens = new StringTokenizer(aValidatorName,",");
   //		
   //		while(tokens.hasMoreTokens())
   //		{
   //			String metodoValidacio=(tokens.nextToken());
   //		    
   //			//buscamos el metodo de validacion sin params
   //			int primero = metodoValidacio.lastIndexOf("{");	
   //			String param="";
   //			String valueParam = "";
   //			String aValidar=metodoValidacio;
   //			if (primero>0){
   //			   
   //			   aValidar=metodoValidacio.substring(0,primero);
   //			 
   //			   //buscammos las variables para ese metodo de validacion
   //			   int primer = metodoValidacio.lastIndexOf("{");
   //		       int ultim = metodoValidacio.lastIndexOf("}");	
   //		       String variables = metodoValidacio.substring(primer+1,ultim);
   //		       
   //			   StringTokenizer tokensVars = new StringTokenizer(variables,";");
   //			   int i=1;
   //				while(tokensVars.hasMoreTokens())
   //				{
   //					String variable=(tokensVars.nextToken());
   //					
   //			        int ini = variable.lastIndexOf(":");
   //			        int fin = variable.length();	
   //			   
   //			        param=variable.substring(0,ini);
   //		            valueParam = variable.substring(ini+1,fin);
   //			
   //			        Arg arg = new Arg();
   //					arg.setResource(false);
   //					arg.setName(param);
   //					arg.setKey(valueParam);
   //					arg.setPosition(i);
   //						
   //					tmpF.addArg(arg);
   //					i++;
   //			    }
   //			//	}
   //			//
   //		//	}
   //			Validator validator = new Validator(validatorResources);
   //			validator.setParameter(Validator.LOCALE_PARAM,i18nService.getCurrentLocale());
   //			
   //			//vemos si hay campos dependientes
   //
   //			JSONObject params =  new JSONObject(dependentFields);
   //			Map paramsDependents = new HashMap();
   //			if (params!=null&&!params.equals("")&&params.length()>0){
   //		    	JSONArray paramsCampsDependents = params.getJSONArray("campsDependents");
   //		    
   //		    	for (int i=0;i<paramsCampsDependents.length();i++){
   //		        	JSONObject campsDependents=(JSONObject)paramsCampsDependents.get(i);
   //		           
   //		        	String fieldName = (String)campsDependents.get("nomCamp");
   //		        	String fieldValue = (String)campsDependents.get("valueCamp");
   //		        	paramsDependents.put(fieldName,fieldValue); 
   //		    	}
   //		    	
   //		    	tmpF.setCampsDependents(paramsDependents);		    
   //		    }
   //
   //			//
   //			Map tmpBean = new HashMap();
   //		
   //			tmpBean.put(Validator.BEAN_PARAM,aFieldValue);
   //			tmpBean.put(Validator.FIELD_PARAM,tmpF);
   //			tmpBean.put(Validator.VALIDATOR_PARAM,validator);
   //			tmpBean.put(DefaultValidatorFactory.ERRORS_KEY, new BindFieldException(aFieldValue,"bean"));
   //				
   //			ValidatorAction validatorAction = validatorResources.getValidatorAction(aValidar);
   //			Map tmpActions = validatorResources.getValidatorActions();
   //
   //			tmpF.setKey(aFieldName);
   //			Msg msg = new Msg();
   //			msg.setKey(validatorAction.getMsg());
   //			tmpF.addMsg(msg);
   //				
   //			Arg arg = new Arg();
   //			arg.setResource(true);
   //			arg.setKey(aErrorKey);
   //			arg.setPosition(0);
   //			tmpF.addArg(arg);
   //				
   //			if (!param.equals("")){
   //			    Var v = new Var();
   //			    v.setName(param);
   //				v.setValue(valueParam);
   //				tmpF.addVar(v);
   //				
   //			}
   //		
   //			tmpF.setProperty(aFieldName);
   //			tmpF.setDepends(aValidar);
   //				
   //			results =  tmpF.validate(tmpBean,tmpActions);
   //		//			Errors errors = parseFieldResults(aFieldName, aFieldValue, results, validatorResources);
   //		//			if (errors.getErrorCount()!=0){
   //		//				if (errorsTotal!=null){
   //		//				    errorsTotal.addAllErrors(errors);
   //		//				}else{
   //		//					errorsTotal=errors;
   //		//				}	
   //		//			}
   //		//			
   //			
   //			if (errorsTotal==null)
   //			    errorsTotal = parseFieldResults(aFieldName, aFieldValue, results, validatorResources);
   //			else{
   //				Errors errores = parseFieldResults(aFieldName, aFieldValue, results, validatorResources);
   //				if (errores.getErrorCount()!=0){
   //				    errorsTotal.addAllErrors(errores); 
   //				}
   //			}
   //			
   //			
   //		  }
   //    	if (getLog().isDebugEnabled()) {
   //       	   getLog().debug("End getValidationResultsTextField():"+errorsTotal.getErrorCount());
   //       	}
   //		  
   //		  return errorsTotal;
   //		 
   //		} catch (ValidatorException e) {
   //		   // TODO Creare exception of ValidationServiceException
   //			getLog().error("getValidationResults(name:"+aValidatorName+",fieldName:"+aFieldName+",fieldValue:"+aFieldValue+",errorKey:"+aErrorKey+",dependentFields:"+dependentFields+")",e);
   //		    //e.printStackTrace();		
   //		   return null;
   //		}
   //		
   //	}

   /**
    * Obt� el resultat de la validaci� d'un camp.
    *
    * @param aName String
    * @param aFieldName String
    * @param aFieldValue String
    * @param aErrorKey String
    * @param dependentFields String
    *
    * @return Errors
    */
   public Errors getValidationResultsTextField(String aValidatorName,
      String aFieldName, String aFieldValue, String aErrorKey,
      String dependentFields) throws ValidationServiceException {
      if (getLog().isDebugEnabled()) {
         getLog()
            .debug("Begin getValidationResultsTextField(name:" +
            aValidatorName + ",fieldName:" + aFieldName + ",fieldValue:" +
            aFieldValue + ",errorKey:" + aErrorKey + ",dependentFields:" +
            dependentFields + ")");
      }

      //    	 Get results of the validation.
      ValidatorResults results = null;
      Errors errorsTotal = null;

      try {
         // Obtain validator resources
         ValidatorResources validatorResources = validatorFactory.getValidatorResources();

         //vemos si hay un metodo de validacion o mas
         //String metodoValidacio=aValidatorName;
         FwkField tmpF = new FwkField();

         //@carles Ho he cambiat de lloc ja que els camps dependents son per camp i no validador.
         //vemos si hay campos dependientes
         JSONObject params = new JSONObject(dependentFields);
         Map paramsDependents = new HashMap();

         if ((params != null) && !params.equals("") && (params.length() > 0)) {
            JSONArray paramsCampsDependents = params.getJSONArray(
                  "campsDependents");

            for (int i = 0; i < paramsCampsDependents.length(); i++) {
               JSONObject campsDependents = (JSONObject) paramsCampsDependents.get(i);

               String fieldName = (String) campsDependents.get("nomCamp");

               //ASM: Un camp depenent pot ser un Map en cas de ser un llistat
               Object fieldValue = (Object) campsDependents.get("valueCamp");
               paramsDependents.put(fieldName, fieldValue);
            }

            tmpF.setCampsDependents(paramsDependents);
         }

         Validator validator = new Validator(validatorResources);
         validator.setParameter(Validator.LOCALE_PARAM,
            i18nService.getCurrentLocale());

         Map tmpBean = new HashMap();

         tmpBean.put(Validator.BEAN_PARAM, aFieldValue);
         tmpBean.put(Validator.FIELD_PARAM, tmpF);
         tmpBean.put(Validator.VALIDATOR_PARAM, validator);
         tmpBean.put(DefaultValidatorFactory.ERRORS_KEY,
            new BindFieldException(aFieldValue, "bean"));

         tmpF.setKey(aFieldName);

         Arg arg = new Arg();
         arg.setResource(true);
         arg.setKey(aErrorKey);
         arg.setPosition(0);
         tmpF.addArg(arg);

         ValidationInfoSet tmpInfos = new ValidationInfoSet();
         tmpInfos.load(aFieldName, aValidatorName);

         Iterator tmpItInfos = tmpInfos.getValidationsInfo().iterator();
         int tmpCount = 1;

         while (tmpItInfos.hasNext()) {
            ValidationInfo tmpInfo = (ValidationInfo) tmpItInfos.next();
            String[] tmpParameters = tmpInfo.getParameters();

            for (int j = 0; j < tmpParameters.length; j++) {
               String tmpParam = tmpParameters[j];
               String tmpValueParam = tmpInfo.getValue(j);

               //		        arg = new Arg();
               //				arg.setResource(false);
               //				arg.setName(tmpParam);
               //				arg.setKey(tmpValueParam);
               //				arg.setPosition(tmpCount);						
               //				tmpF.addArg(arg);
               Var v = new Var();
               v.setName(tmpParam);
               v.setValue(tmpValueParam);

               tmpF.addVar(v);
               tmpCount++;
            }

            ValidatorAction validatorAction = validatorResources.getValidatorAction(tmpInfo.getValidatorName());

            Msg msg = new Msg();
            msg.setKey(validatorAction.getMsg());
            tmpF.addMsg(msg);

            //@carles comentat ja que no se per a que serveix. 
            //			En l'algoritme sembla que posi com a variable l'ultim parametre cosa que no t� sentit.
            //          >>Ho tots o cap  << i davant del dubte cap.
            //			
            //			if (!param.equals("")){
            //			    Var v = new Var();
            //			    v.setName(param);
            //				v.setValue(valueParam);
            //				tmpF.addVar(v);
            //				
            //			}
         }

         tmpF.setProperty(aFieldName);

         Map tmpActions = validatorResources.getValidatorActions();

         String[] tmpValidatorNames = tmpInfos.getValidatorNames();

         for (int i = 0; i < tmpValidatorNames.length; i++) {
            String tmpV = tmpValidatorNames[i];
            tmpF.setDepends(tmpV);

            results = tmpF.validate(tmpBean, tmpActions);

            if (errorsTotal == null) {
               errorsTotal = parseFieldResults(aFieldName, aFieldValue,
                     results, validatorResources);
            } else {
               Errors errores = parseFieldResults(aFieldName, aFieldValue,
                     results, validatorResources);

               if (errores.getErrorCount() != 0) {
                  errorsTotal.addAllErrors(errores);
               }
            }
         }

         if (getLog().isDebugEnabled()) {
            getLog()
               .debug("End getValidationResultsTextField():" +
               errorsTotal.getErrorCount());
         }

         return errorsTotal;
      } catch (ValidatorException e) {
         // TODO Creare exception of ValidationServiceException
         getLog()
            .error("getValidationResults(name:" + aValidatorName +
            ",fieldName:" + aFieldName + ",fieldValue:" + aFieldValue +
            ",errorKey:" + aErrorKey + ",dependentFields:" + dependentFields +
            ")", e);

         //e.printStackTrace();		
         return null;
      }
   }

   /**
    * Analitza els results i retorna Errors
    *
    * @param aName String
    * @param aPropertyName String
    * @param aPropertyValue Object
    * @param results ValidatorResults
    * @param resources ValidatorResources
    *
    * @return Errors
    */
   private Errors parseResults(String aName, String aPropertyName,
      Object aPropertyValue, ValidatorResults results,
      ValidatorResources resources) {
      /** require aName!=null; */
      StringBuffer errorMsg = new StringBuffer();

      Errors errors = new BindException(aName, "bean");

      // Get the result of validating the property.
      ValidatorResult result = results.getValidatorResult(aPropertyName);

      // Get the Field associated with that property in the Form
      Field field = result.getField();

      // Look up the formatted name of the field from the Field arg0
      String fieldKey = field.getArg(0).getKey();
      String fieldMessage = i18nService.getMessage(fieldKey);

      // Get all the actions run against the property, and iterate over their
      // names.
      Map actionMap = result.getActionMap();
      Iterator keys = result.getActions();

      while (keys.hasNext()) {
         String actName = (String) keys.next();
         ValidatorAction action = resources.getValidatorAction(actName);

         // If the result is valid, print PASSED, otherwise print FAILED
         errorMsg.append("\n" + aPropertyName + "[" + actName + "] (" +
            (result.isValid(actName) ? "PASSED" : "FAILED") + ")");

         // If the result failed, format the Action's message against the
         // formatted field name
         if (!result.isValid(actName)) {
            Object rejectedValue = aPropertyValue;

            // EVC: fixed messages with only first arg bug.
            // Get the arguments
            Arg[] args = field.getArgs(actName);
            String[] arguments = getArgValues(i18nService, args);

            // By default, get message from action
            String keyMessage = action.getMsg();

            // If msg has been defined for action change by it
            if (field.getMsg(actName) != null) {
               keyMessage = field.getMsg(actName);
            }

            //                Object[] args = {fieldMessage};
            String message = i18nService.getMessage(keyMessage, arguments);
            String[] keyMessages = { keyMessage };

            FieldError error = new FieldError(aName, aPropertyName,
                  rejectedValue, true, keyMessages, args, message);

            if (errors instanceof BindException) {
               ((BindException) errors).addError(error);
            }

            errorMsg.append("\n     Error message will be: '" + message + "'");
         }
      }

      if (loggingService != null) {
         loggingService.getLog(this.getClass()).debug(errorMsg);
      }

      return errors;
   }

   /**
    * Documentaci�.
    *
    * @param aFieldName Documentaci�
    * @param bean Documentaci�
    * @param results Documentaci�
    * @param resources Documentaci�
    *
    * @return Documentaci�
    *
    * @throws ValidationServiceException Documentaci�
    */
   private Errors parseResults(String aFieldName, Object bean,
      ValidatorResults results, ValidatorResources resources)
      throws ValidationServiceException {
      // Bind errors to complete bean
      Errors errors = new BindException(bean, aFieldName);

      // Construct message to trace
      StringBuffer errorMsg = new StringBuffer();
      errorMsg.append("\n\nValidating:");
      errorMsg.append(bean);

      // Iterate over each of the properties of the Bean which had messages.
      Iterator propertyNames = results.getPropertyNames().iterator();

      while (propertyNames.hasNext()) {
         String propertyName = (String) propertyNames.next();

         // Get the Field associated with that property in the Form
         ValidatorResult result = (ValidatorResult) results.getValidatorResult(propertyName);
         Field field = result.getField();

         // Obtain the rejected value
         String rejectedValue = ValidatorUtils.getValueAsString(bean,
               field.getProperty());
         // Add the error to list of errors, parsing the error in Errors
         // object
         //msg-ini
         addAllErrors(errors,
            parseResults(aFieldName, propertyName, rejectedValue, results,
               resources));

         //msg-fi
      }

      if (errors.getErrorCount() == 0) {
         errorMsg.append("\nFORM VALIDATION PASSED");
      } else {
         errorMsg.append("\nFORM VALIDATION FAILED");
      }

      if (loggingService != null) {
         loggingService.getLog(this.getClass()).debug("ERRORS:" + errorMsg);
      }

      return errors;
   }

   //msg-ini
   /**
    * Documentaci�.
    *
    * @param desti Documentaci�
    * @param origen Documentaci�
    */
   private void addAllErrors(Errors desti, Errors origen) {
      if (desti != null) {
         List llistaErrors = origen.getAllErrors();

         for (Iterator it = llistaErrors.iterator(); it.hasNext();) {
            FieldError error = (FieldError) it.next();
            ((BindException) desti).addError(error);
         }
      }
   }

   //msg-fi
   /**
    * Analitza els results i retorna Errors
    *
    * @param aName String
    * @param aFieldValue String
    * @param results ValidatorResults
    * @param resources ValidatorResources
    *
    * @return Errors
    */
   private Errors parseFieldResults(String aFieldName, String aFieldValue,
      ValidatorResults results, ValidatorResources resources)
      throws ValidationServiceException {
      // Bind errors to complete bean
      Errors errors = new BindFieldException(aFieldValue, "bean");

      // Construct message to trace
      StringBuffer errorMsg = new StringBuffer();
      errorMsg.append("\n\nValidating:");
      errorMsg.append(aFieldValue);

      // Iterate over each of the properties of the Bean which had messages.
      Iterator propertyNames = results.getPropertyNames().iterator();

      while (propertyNames.hasNext()) {
         String propertyName = (String) propertyNames.next();

         // Get the Field associated with that property in the Form
         ValidatorResult result = (ValidatorResult) results.getValidatorResult(propertyName);
         Field field = result.getField();

         // Obtain the rejected value
         String rejectedValue = aFieldValue;
         // Add the error to list of errors, parsing the error in Errors
         // object
         errors.addAllErrors(parseResults(aFieldName, propertyName,
               rejectedValue, results, resources));
      }

      if (errors.getErrorCount() == 0) {
         errorMsg.append("\nFORM FIELD VALIDATION PASSED");
      } else {
         errorMsg.append("\nFORM FIELD VALIDATION FAILED");
      }

      if (loggingService != null) {
         loggingService.getLog(this.getClass()).debug("ERRORS:" + errorMsg);
      }

      return errors;
   }

   /**
    * Analitza els results i retorna Errors
    *
    * @param aName String
    * @param aFieldValue String
    *
    * @param results ValidatorResults
    * @param resources ValidatorResources
    * @param aPropertyValue Object
    * @return Errors
    */
   private Errors parseFieldResults(String aName, String aPropertyName,
      Object aPropertyValue, ValidatorResults results,
      ValidatorResources resources) {
      /** require aName!=null; */
      StringBuffer errorMsg = new StringBuffer();

      Errors errors = new BindFieldException(aName, "bean");

      // Get the result of validating the property.
      ValidatorResult result = results.getValidatorResult(aPropertyName);

      // Get the Field associated with that property in the Form
      Field field = result.getField();

      // Look up the formatted name of the field from the Field arg0
      String fieldKey = field.getArg(0).getKey();
      String fieldMessage = i18nService.getMessage(fieldKey);

      // Get all the actions run against the property, and iterate over their
      // names.
      Map actionMap = result.getActionMap();

      //Iterator keys = actionMap.keySet().iterator();
      Iterator keys = result.getActions();

      while (keys.hasNext()) {
         String actName = (String) keys.next();
         ValidatorAction action = resources.getValidatorAction(actName);

         // If the result is valid, print PASSED, otherwise print FAILED
         errorMsg.append("\n" + aPropertyName + "[" + actName + "] (" +
            (result.isValid(actName) ? "PASSED" : "FAILED") + ")");

         // If the result failed, format the Action's message against the
         // formatted field name
         if (!result.isValid(actName)) {
            Object rejectedValue = aPropertyValue;

            // By default, get message from action
            String keyMessage = action.getMsg();

            // If msg has been defined for action change by it
            if (field.getMsg(actName) != null) {
               keyMessage = field.getMsg(actName);
            }

            Object[] args = { fieldMessage };
            String message = i18nService.getMessage(keyMessage, args);
            String[] keyMessages = { keyMessage };

            FieldError error = new FieldError(aName, aPropertyName,
                  rejectedValue, true, keyMessages, args, message);

            if (errors instanceof BindException) {
               ((BindException) errors).addError(error);
            }

            errorMsg.append("\n     Error message will be: '" + message + "'");
         }
      }

      if (loggingService != null) {
         loggingService.getLog(this.getClass()).debug(errorMsg);
      }

      return errors;
   }

   /**
    * @return LoggingService
    */
   public LoggingService getLoggingService() {
      return loggingService;
   }

   /**
    * @param loggingService LoggingService
    */
   public void setLoggingService(LoggingService loggingService) {
      this.loggingService = loggingService;
   }

   /**
    * @param aName String
    * @param aFieldName String
    *
    * @return boolean
    */
   public boolean isRequiredField(String aName, String aFieldName) {
      // Obtain validator resources
      ValidatorResources validatorResources = validatorFactory.getValidatorResources();

      // Get form with current locale
      Form form = validatorResources.getForm(i18nService.getCurrentLocale(),
            aName);

      if (form != null) {
         Field field = form.getField(aFieldName);

         if (field != null) {
            List dependencyList = field.getDependencyList();

            if ((dependencyList != null) &&
                  dependencyList.contains("required")) {
               return true;
            }
         }
      }

      return false;
   }

   /**
    * @param aName String
    * @param aFieldName String
    *
    * @return String
    */
   public String getDatePattern(String aName, String aFieldName) {
      // Obtain validator resources
      ValidatorResources validatorResources = validatorFactory.getValidatorResources();

      // Get form with current locale
      Form form = validatorResources.getForm(i18nService.getCurrentLocale(),
            aName);

      if (form != null) {
         Field field = form.getField(aFieldName);

         if (field != null) {
            List dependencyList = field.getDependencyList();

            if ((dependencyList != null) && dependencyList.contains("date")) {
               Var datePatternVar = field.getVar("datePattern");

               return datePatternVar.getValue();
            }
         }
      }

      return null;
   }

   /**
    * @return I18nService
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * @return ValidatorFactory
    */
   public ValidatorFactory getValidatorFactory() {
      return validatorFactory;
   }

   /**
    * @param validatorFactory ValidatorFactory
    */
   public void setValidatorFactory(ValidatorFactory validatorFactory) {
      this.validatorFactory = validatorFactory;
   }

   // EVC: added modified org.apache.struts.validator.Resources.getArgValues function of Struts.
   /**
    * Documentaci�.
    *
    * @param i18nService I18nService
    * @param args Arg[]
    *
    * @return String[]
    */
   private static String[] getArgValues(I18nService i18nService, Arg[] args) {
      Locale locale = i18nService.getCurrentLocale();

      if ((args == null) || (args.length == 0)) {
         return null;
      }

      String[] values = new String[args.length];

      for (int i = 0; i < args.length; i++) {
         if (args[i] != null) {
            if (args[i].isResource()) {
               values[i] = i18nService.getMessage(args[i].getKey(), locale);
            } else {
               values[i] = args[i].getKey();
            }
         }
      }

      return values;
   }

   /**
    * Documentaci�.
    */
   public static void main() {
   }
}
