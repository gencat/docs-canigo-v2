/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.validation.commons.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.validator.Arg;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class ValidationInfo {
   /**
    * The values.
    */
   private List myValues;

   /**
    * The validator name.
    */
   private String myValidatorName;

   /**
    * The parameters and values.
    */
   private String[] myParameters;

   /**
    * The validation info.
    */
   public ValidationInfo() {
   }

   /**
    * Carrega la informaci� en format validaci� del JSP, per exemple
    * mask{mask:^d{2}%;datePattern:aaa}
    * @param pInfo
    */
   public void load(String pInfo) {
      if (myValidatorName != null) {
         // info ja carregada.
      }

      List tmpParameters = new ArrayList(2);
      myValues = new ArrayList(2);
      myParameters = new String[0];

      int tmpPosClau = pInfo.indexOf("{");

      if (tmpPosClau != -1) {
         myValidatorName = pInfo.substring(0, tmpPosClau);

         int tmpLongitut = pInfo.length() - 1;

         if (pInfo.charAt(tmpLongitut) != '}') {
            // throw falta } al final de cadena.
         }

         String tmpParametres = pInfo.substring(tmpPosClau + 1, tmpLongitut);
         StringTokenizer tmpTokenParametres = new StringTokenizer(tmpParametres,
               ";");

         while (tmpTokenParametres.hasMoreTokens()) {
            String tmpParamValor = (tmpTokenParametres.nextToken());
            int tmpDosPunts = tmpParamValor.indexOf(":");

            if (tmpDosPunts == -1) {
               // throw no hi ha dos punts.
            }

            String tmpNomParametre = tmpParamValor.substring(0, tmpDosPunts);
            String tmpValorParametre = tmpParamValor.substring(tmpDosPunts + 1);
            tmpParameters.add(tmpNomParametre);
            myValues.add(tmpValorParametre);
         }

         myParameters = new String[tmpParameters.size()];
         myParameters = (String[]) tmpParameters.toArray(myParameters);
      } else {
         myValidatorName = pInfo;
      }
   }

   /**
    * Gets the validator name.
    */
   public String getValidatorName() {
      return myValidatorName;
   }

   /**
    * Obt� els par�metres definits.
    */
   public String[] getParameters() {
      return myParameters;
   }

   /**
    * Obt� els valor del parametre d'una determinada posici�
    * @param pPosition, la posici�.
    */
   public String getValue(int pPosition) {
      return (String) myValues.get(pPosition);
   }
}
