/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.validation.commons.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class ValidationInfoSet {
   /**
    * The validations info.
    */
   private List myValidationInfos;

   /**
    * The field.
    */
   private String myFieldName;

   /**
    * The validations info set.
    */
   public ValidationInfoSet() {
   }

   /**
    * Load.
    * @param pValidations, is required,mask{mask:^dd{2}$;length:2}
    * @param pFieldName, the field name.
    */
   public void load(String pFieldName, String pValidations) {
      StringTokenizer tokens = new StringTokenizer(pValidations, ",");

      myValidationInfos = new ArrayList();

      while (tokens.hasMoreTokens()) {
         String metodoValidacio = (tokens.nextToken());
         ValidationInfo tmpInfo = new ValidationInfo();
         tmpInfo.load(metodoValidacio);

         myValidationInfos.add(tmpInfo);
      }
   }

   /**
    * Gets the validations info.
    */
   public List getValidationsInfo() {
      return myValidationInfos;
   }

   /**
    * Gets the field name.
    */
   public String getFieldName() {
      return myFieldName;
   }

   /**
    * Gets validator names.
    * @param args
    */
   public String getValidatorNames(char pSeparator) {
      StringBuffer tmpBuff = new StringBuffer();
      Iterator tmpIt = this.getValidationsInfo().iterator();

      while (tmpIt.hasNext()) {
         String tmpAction = ((ValidationInfo) tmpIt.next()).getValidatorName();
         tmpBuff.append(tmpAction + pSeparator);
      }

      if (this.getValidationsInfo().size() > 0) {
         tmpBuff.deleteCharAt(tmpBuff.length() - 1);
      }

      return tmpBuff.toString();
   }

   /**
    * Gets validator names.
    * @param args
    */
   public String[] getValidatorNames() {
      String[] tmpValidatorNames = new String[this.getValidationsInfo().size()];
      Iterator tmpIt = this.getValidationsInfo().iterator();
      int i = 0;

      while (tmpIt.hasNext()) {
         String tmpAction = ((ValidationInfo) tmpIt.next()).getValidatorName();
         tmpValidatorNames[i] = tmpAction;
         i++;
      }

      return tmpValidatorNames;
   }

   /**
    * Documentaci�.
    *
    * @param args Documentaci�
    */
   public static void main(String[] args) {
      ValidationInfoSet tmpSrt = new ValidationInfoSet();
      tmpSrt.load("fieldName",
         "mask{mask:^d{2}\\_\\d{3}$;datePattern:dd\\mm\\yyy},required");

      List tmpV = tmpSrt.getValidationsInfo();
      System.out.println(tmpSrt.getValidatorNames(','));

      for (int i = 0; tmpV.size() > i; i++) {
         ValidationInfo tmpInfo = (ValidationInfo) tmpV.get(i);
         StringBuffer tmpBuff = new StringBuffer();
         tmpBuff.append("validation:" + tmpInfo.getValidatorName());

         String[] tmpP = tmpInfo.getParameters();

         for (int j = 0; j < tmpP.length; j++) {
            tmpBuff.append(tmpP[j] + " -> " + tmpInfo.getValue(j) + "  ||||");
         }

         System.out.println(tmpBuff.toString());
      }
   }
}
