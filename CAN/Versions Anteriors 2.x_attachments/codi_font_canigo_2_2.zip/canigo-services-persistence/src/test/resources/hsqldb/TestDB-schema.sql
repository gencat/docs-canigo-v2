create table category (
	id int not null,
	name varchar(80) null,
	descn varchar(255) null,
	constraint pk_category primary key (id)
);

create table product (
    id int not null,
    category int not null,
    name varchar(80) null,
    descn varchar(255) null,
    constraint pk_product primary key (id),
        constraint fk_product_1 foreign key (category)
        references category (id)
);

create index product_cat on product (category);
create index product_name on product (name);
