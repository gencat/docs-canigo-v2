/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package com.myapp.model.base;

import java.io.Serializable;

import java.lang.Comparable;


/**
 * This is an object that contains data related to the PRODUCT table.
 * Do not modify this class because it will be overwritten if the configuration file
 * related to this class is modified.
 *
 * @hibernate.class
 *  table="PRODUCT"
 */
public abstract class BaseProduct implements Comparable, Serializable {
   /**
    * Documentaci�.
    */
   public static String REF = "Product";

   /**
    * Documentaci�.
    */
   public static String PROP_CATEGORY = "category";

   /**
    * Documentaci�.
    */
   public static String PROP_DESCN = "descn";

   /**
    * Documentaci�.
    */
   public static String PROP_NAME = "name";

   /**
    * Documentaci�.
    */
   public static String PROP_ID = "id";

   // many to one
   /**
    * Documentaci�.
    */
   private com.myapp.model.Category category;

   // fields
   /**
    * Documentaci�.
    */
   private java.lang.String descn;

   // primary key
   /**
    * Documentaci�.
    */
   private java.lang.Integer id;

   /**
    * Documentaci�.
    */
   private java.lang.String name;

   /**
    * Documentaci�.
    */
   private int hashCode = Integer.MIN_VALUE;

   // constructors
   /**
    * Creates a new BaseProduct object.
    */
   public BaseProduct() {
      initialize();
   }

   /**
    * Constructor for primary key
    */
   public BaseProduct(java.lang.Integer id) {
      this.setId(id);
      initialize();
   }

   /**
    * Constructor for required fields
    */
   public BaseProduct(java.lang.Integer id, com.myapp.model.Category category) {
      this.setId(id);
      this.setCategory(category);
      initialize();
   }

   /**
    * Documentaci�.
    */
   protected void initialize() {
   }

   /**
    * Return the unique identifier of this class
   * @hibernate.id
   *  generator-class="increment"
   *  column="ID"
   */
   public java.lang.Integer getId() {
      return id;
   }

   /**
    * Set the unique identifier of this class
    * @param id the new ID
    */
   public void setId(java.lang.Integer id) {
      this.id = id;
      this.hashCode = Integer.MIN_VALUE;
   }

   /**
    * Return the value associated with the column: DESCN
    */
   public java.lang.String getDescn() {
      return descn;
   }

   /**
    * Set the value related to the column: DESCN
    * @param descn the DESCN value
    */
   public void setDescn(java.lang.String descn) {
      this.descn = descn;
   }

   /**
    * Return the value associated with the column: NAME
    */
   public java.lang.String getName() {
      return name;
   }

   /**
    * Set the value related to the column: NAME
    * @param name the NAME value
    */
   public void setName(java.lang.String name) {
      this.name = name;
   }

   /**
    * Return the value associated with the column: CATEGORY
    */
   public com.myapp.model.Category getCategory() {
      return category;
   }

   /**
    * Set the value related to the column: CATEGORY
    * @param category the CATEGORY value
    */
   public void setCategory(com.myapp.model.Category category) {
      this.category = category;
   }

   /**
    * Documentaci�.
    *
    * @param obj Documentaci�
    *
    * @return Documentaci�
    */
   public boolean equals(Object obj) {
      if (null == obj) {
         return false;
      }

      if (!(obj instanceof com.myapp.model.Product)) {
         return false;
      } else {
         com.myapp.model.Product product = (com.myapp.model.Product) obj;

         if ((null == this.getId()) || (null == product.getId())) {
            return false;
         } else {
            return (this.getId().equals(product.getId()));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int hashCode() {
      if (Integer.MIN_VALUE == this.hashCode) {
         if (null == this.getId()) {
            return super.hashCode();
         } else {
            String hashStr = this.getClass().getName() + ":" +
               this.getId().hashCode();
            this.hashCode = hashStr.hashCode();
         }
      }

      return this.hashCode;
   }

   /**
    * Documentaci�.
    *
    * @param obj Documentaci�
    *
    * @return Documentaci�
    */
   public int compareTo(Object obj) {
      if (obj.hashCode() > hashCode()) {
         return 1;
      } else if (obj.hashCode() < hashCode()) {
         return -1;
      } else {
         return 0;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String toString() {
      return super.toString();
   }
}
