/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package com.myapp.model.dao.hibernate.impl.base;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.criterion.Order;


/**
 * This is an automatically generated DAO class which should not be edited.
 */
public abstract class BaseCategoryDAO extends com.myapp.model.dao.hibernate.impl.HibernateRootDAOImpl
   implements com.myapp.model.dao.CategoryDAO {
   // query name references
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Class getReferenceClass() {
      return com.myapp.model.Category.class;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Order getDefaultOrder() {
      return Order.asc("name");
   }

   /**
    * Cast the object as a com.myapp.model.Category
    */
   public com.myapp.model.Category cast(Object object) {
      return (com.myapp.model.Category) object;
   }

   /**
    * Documentaci�.
    *
    * @param key Documentaci�
    *
    * @return Documentaci�
    *
    */
   public com.myapp.model.Category get(java.lang.Integer key)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      return (com.myapp.model.Category) get(getReferenceClass(), key);
   }

   /**
    * Documentaci�.
    *
    * @param key Documentaci�
    * @param s Documentaci�
    *
    * @return Documentaci�
    *
    */
   public com.myapp.model.Category get(java.lang.Integer key, Session s)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      return (com.myapp.model.Category) get(getReferenceClass(), key, s);
   }

   /**
    * Documentaci�.
    *
    * @param key Documentaci�
    *
    * @return Documentaci�
    *
    */
   public com.myapp.model.Category load(java.lang.Integer key)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      return (com.myapp.model.Category) load(getReferenceClass(), key);
   }

   /**
    * Documentaci�.
    *
    * @param key Documentaci�
    * @param s Documentaci�
    *
    * @return Documentaci�
    *
    */
   public com.myapp.model.Category load(java.lang.Integer key, Session s)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      return (com.myapp.model.Category) load(getReferenceClass(), key, s);
   }

   /**
    * Documentaci�.
    *
    * @param key Documentaci�
    * @param s Documentaci�
    *
    * @return Documentaci�
    *
    */
   public com.myapp.model.Category loadInitialize(java.lang.Integer key,
      Session s)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      com.myapp.model.Category obj = load(key, s);

      if (!Hibernate.isInitialized(obj)) {
         Hibernate.initialize(obj);
      }

      return obj;
   }

   /**
    * Return all objects related to the implementation of this DAO with no filter.
    */
   public java.util.List findAll()
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      return super.findAll();
   }

   /**
    * Return all objects related to the implementation of this DAO with no filter.
    */
   public java.util.List findAll(Order defaultOrder)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      return super.findAll(defaultOrder);
   }

   /**
    * Return all objects related to the implementation of this DAO with no filter.
    * Use the session given.
    * @param s the Session
    */
   public java.util.List findAll(Session s, Order defaultOrder)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      return super.findAll(s, defaultOrder);
   }

   /**
    * Persist the given transient instance, first assigning a generated identifier. (Or using the current value
    * of the identifier property if the assigned generator is used.)
    * @param category a transient instance of a persistent class
    * @return the class identifier
    */
   public java.lang.Integer save(com.myapp.model.Category category)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      return (java.lang.Integer) super.save(category);
   }

   /**
    * Persist the given transient instance, first assigning a generated identifier. (Or using the current value
    * of the identifier property if the assigned generator is used.)
    * Use the Session given.
    * @param category a transient instance of a persistent class
    * @param s the Session
    * @return the class identifier
    */
   public java.lang.Integer save(com.myapp.model.Category category, Session s)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      return (java.lang.Integer) save((Object) category, s);
   }

   /**
    * Either save() or update() the given instance, depending upon the value of its identifier property. By default
    * the instance is always saved. This behaviour may be adjusted by specifying an unsaved-value attribute of the
    * identifier property mapping.
    * @param category a transient instance containing new or updated state
    */
   public void saveOrUpdate(com.myapp.model.Category category)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      saveOrUpdate((Object) category);
   }

   /**
    * Either save() or update() the given instance, depending upon the value of its identifier property. By default the
    * instance is always saved. This behaviour may be adjusted by specifying an unsaved-value attribute of the identifier
    * property mapping.
    * Use the Session given.
    * @param category a transient instance containing new or updated state.
    * @param s the Session.
    */
   public void saveOrUpdate(com.myapp.model.Category category, Session s)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      saveOrUpdate((Object) category, s);
   }

   /**
    * Update the persistent state associated with the given identifier. An exception is thrown if there is a persistent
    * instance with the same identifier in the current session.
    * @param category a transient instance containing updated state
    */
   public void update(com.myapp.model.Category category)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      update((Object) category);
   }

   /**
    * Update the persistent state associated with the given identifier. An exception is thrown if there is a persistent
    * instance with the same identifier in the current session.
    * Use the Session given.
    * @param category a transient instance containing updated state
    * @param the Session
    */
   public void update(com.myapp.model.Category category, Session s)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      update((Object) category, s);
   }

   /**
    * Remove a persistent instance from the datastore. The argument may be an instance associated with the receiving
    * Session or a transient instance with an identifier associated with existing persistent state.
    * @param id the instance ID to be removed
    */
   public void delete(java.lang.Integer id)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      delete((Object) load(id));
   }

   /**
    * Remove a persistent instance from the datastore. The argument may be an instance associated with the receiving
    * Session or a transient instance with an identifier associated with existing persistent state.
    * Use the Session given.
    * @param id the instance ID to be removed
    * @param s the Session
    */
   public void delete(java.lang.Integer id, Session s)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      delete((Object) load(id, s), s);
   }

   /**
    * Remove a persistent instance from the datastore. The argument may be an instance associated with the receiving
    * Session or a transient instance with an identifier associated with existing persistent state.
    * @param category the instance to be removed
    */
   public void delete(com.myapp.model.Category category)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      delete((Object) category);
   }

   /**
    * Remove a persistent instance from the datastore. The argument may be an instance associated with the receiving
    * Session or a transient instance with an identifier associated with existing persistent state.
    * Use the Session given.
    * @param category the instance to be removed
    * @param s the Session
    */
   public void delete(com.myapp.model.Category category, Session s)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      delete((Object) category, s);
   }

   /**
    * Re-read the state of the given instance from the underlying database. It is inadvisable to use this to implement
    * long-running sessions that span many business tasks. This method is, however, useful in certain special circumstances.
    * For example
    * <ul>
    * <li>where a database trigger alters the object state upon insert or update</li>
    * <li>after executing direct SQL (eg. a mass update) in the same session</li>
    * <li>after inserting a Blob or Clob</li>
    * </ul>
    */
   public void refresh(com.myapp.model.Category category, Session s)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      refresh((Object) category, s);
   }

   /**
   * Re-read the state of the given instance from the underlying database. It is inadvisable to use this to implement
   * long-running sessions that span many business tasks. This method is, however, useful in certain special circumstances.
   * For example
   * <ul>
   * <li>where a database trigger alters the object state upon insert or update</li>
   * <li>after executing direct SQL (eg. a mass update) in the same session</li>
   * <li>after inserting a Blob or Clob</li>
   * </ul>
   */
   public void refresh(com.myapp.model.Category category)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException {
      refresh((Object) category);
   }
}
