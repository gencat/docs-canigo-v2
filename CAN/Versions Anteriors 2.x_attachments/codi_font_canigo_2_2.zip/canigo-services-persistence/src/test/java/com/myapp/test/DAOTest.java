/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package com.myapp.test;

import java.util.ArrayList;
import java.util.Iterator;

import com.myapp.model.Category;
import com.myapp.model.dao.CategoryDAO;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.logging.Log;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class DAOTest extends TestCase {
   /**
    * Documentaci�.
    */
   private BeanFactory factory = null;

   /**
    * Documentaci�.
    */
   private Log log = null;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void setUp() throws Exception {
      super.setUp();

      ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(
            "applicationContext.xml");
      this.factory = (BeanFactory) appContext;

      /**
       * Logging service
       */
      LoggingService logService = (LoggingService) factory.getBean(
            "loggingService");
      this.log = logService.getLog(this.getClass());
   }

   /**
    * Documentaci�.
    */
   public void testMultipleSave() {
      log.debug("DAOTest.testMultipleSave()");

      /**
       * Request a the 'multisave object'
       */
      MultiSave multiSave = (MultiSave) factory.getBean("multiSaveProxy");
      ArrayList list = new ArrayList();

      for (int i = 0; i < 3; i++) {
         /**
          * Request a new category instance
          */
         Category newCategory = (Category) factory.getBean("category");
         newCategory.setName("name at " + System.currentTimeMillis());
         newCategory.setDescn("descn at " + System.currentTimeMillis());
         list.add(newCategory);
      }

      try {
         multiSave.saveMultiple(list);
      } catch (PersistenceServiceException ex) {
         log.warn("An error has ocurred: " + ex.getLocalizedMessage());
      }

      Iterator it = list.iterator();

      while (it.hasNext()) {
         Category c = (Category) it.next();

         if (c.getId() != null) {
            log.debug("Loading category with ID=" + c.getId());

            Category cLoaded = multiSave.loadCategory(c.getId());
            log.debug("Loaded from BD a category " + cLoaded + " with Id=" +
               c.getId() + "?" + (cLoaded != null));
            assertTrue("The category has been saved into DB and should not!",
               cLoaded == null);
         }
      }

      log.debug("End.");
   }

   /**
    * Documentaci�.
    */
   public void testSave() {
      log.debug("DAOTest.testSave()");

      /**
       * Request the DAO to manipulate category instances
       */
      CategoryDAO categoryDAO = (CategoryDAO) factory.getBean(
            "categoryDaoProxy");

      /**
       * Request a new category instance
       */
      Category newCategory = (Category) factory.getBean("category");
      newCategory.setName("name at " + System.currentTimeMillis());
      newCategory.setDescn("descn at " + System.currentTimeMillis());

      try {
         categoryDAO.save(newCategory);
      } catch (PersistenceServiceException ex) {
         log.warn("An error has ocurred: " + ex.getLocalizedMessage());
      }

      log.debug("New category with ID: " + newCategory.getId());
      assertTrue("Category not saved!", newCategory.getId() != null);
   }

   /**
    * Documentaci�.
    */
   public void testDelete() {
      log.debug("DAOTest.testDelete()");

      /**
       * Request the DAO to manipulate category instances
       */
      CategoryDAO categoryDAO = (CategoryDAO) factory.getBean(
            "categoryDaoProxy");

      /**
       * Request a new category instance
       */
      Category newCategory = (Category) factory.getBean("category");
      newCategory.setName("name at " + System.currentTimeMillis());
      newCategory.setDescn("descn at " + System.currentTimeMillis());

      try {
         categoryDAO.save(newCategory);
      } catch (PersistenceServiceException ex) {
         log.warn("Se ha producido un error: " + ex.getLocalizedMessage());
      }

      log.debug("New category with ID: " + newCategory.getId());
      assertTrue("An error has ocurred saving Category!",
         newCategory.getId() != null);

      if (newCategory.getId() != null) {
         try {
            log.debug("Deleting category with ID: " + newCategory.getId());
            categoryDAO.delete(newCategory);
         } catch (PersistenceServiceException ex) {
            log.warn("An error has ocurred deleting Category: " +
               ex.getLocalizedMessage());
         }

         Category targetCategory = null;

         try {
            log.debug("Loading category with ID: " + newCategory.getId());
            targetCategory = categoryDAO.get(newCategory.getId());
         } catch (PersistenceServiceException ex) {
            log.warn("An error has ocurred loading Category: " +
               ex.getLocalizedMessage());
         }

         log.debug("Loaded category with ID: " + newCategory.getId() + "?" +
            (targetCategory != null));
         assertTrue("Category " + targetCategory + " not deleted!",
            targetCategory == null);
      }
   }

   /**
    * Documentaci�.
    */
   public void testLoad() {
      log.debug("DAOTest.testLoad()");

      /**
       * Request the DAO to manipulate category instances
       */
      CategoryDAO categoryDAO = (CategoryDAO) factory.getBean(
            "categoryDaoProxy");

      /**
       * Request a new category instance
       */
      Category newCategory = (Category) factory.getBean("category");
      newCategory.setName("name at " + System.currentTimeMillis());
      newCategory.setDescn("descn at " + System.currentTimeMillis());

      try {
         categoryDAO.save(newCategory);
      } catch (PersistenceServiceException ex) {
         log.warn("An error has ocurred: " + ex.getLocalizedMessage());
      }

      log.debug("New category with ID: " + newCategory.getId());
      assertTrue("An error has ocurred saving Category!",
         newCategory.getId() != null);

      if (newCategory.getId() != null) {
         Category targetCategory = null;

         try {
            log.debug("Loading category with ID: " + newCategory.getId());
            targetCategory = categoryDAO.get(newCategory.getId());
         } catch (PersistenceServiceException ex) {
            log.warn("An error has ocurred loading Category: " +
               ex.getLocalizedMessage());
         }

         log.debug("Loaded category with ID: " + newCategory.getId() + "?" +
            (targetCategory != null));
         assertTrue("Category " + targetCategory + " not loaded!",
            targetCategory != null);
      }
   }
}
