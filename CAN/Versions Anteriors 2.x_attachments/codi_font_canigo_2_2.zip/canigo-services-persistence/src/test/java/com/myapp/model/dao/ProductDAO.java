/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package com.myapp.model.dao;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public interface ProductDAO {
   /**
   * Persist the given transient instance, first assigning a generated identifier. (Or using the current value
   * of the identifier property if the assigned generator is used.)
   * @param product a transient instance of a persistent class
   * @return the class identifier
   */
   public java.lang.Integer save(com.myapp.model.Product product)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException;

   /**
    * Either save() or update() the given instance, depending upon the value of its identifier property. By default
    * the instance is always saved. This behaviour may be adjusted by specifying an unsaved-value attribute of the
    * identifier property mapping.
    * @param product a transient instance containing new or updated state
    */
   public void saveOrUpdate(com.myapp.model.Product product)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException;

   /**
    * Update the persistent state associated with the given identifier. An exception is thrown if there is a persistent
    * instance with the same identifier in the current session.
    * @param product a transient instance containing updated state
    */
   public void update(com.myapp.model.Product product)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException;

   /**
    * Remove a persistent instance from the datastore. The argument may be an instance associated with the receiving
    * Session or a transient instance with an identifier associated with existing persistent state.
    * @param id the instance ID to be removed
    */
   public void delete(java.lang.Integer id)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException;

   /**
    * Remove a persistent instance from the datastore. The argument may be an instance associated with the receiving
    * Session or a transient instance with an identifier associated with existing persistent state.
    * @param product the instance to be removed
    */
   public void delete(com.myapp.model.Product product)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException;

   /**
   * Re-read the state of the given instance from the underlying database. It is inadvisable to use this to implement
   * long-running sessions that span many business tasks. This method is, however, useful in certain special circumstances.
   * For example
   * <ul>
   * <li>where a database trigger alters the object state upon insert or update</li>
   * <li>after executing direct SQL (eg. a mass update) in the same session</li>
   * <li>after inserting a Blob or Clob</li>
   * </ul>
   */
   public void refresh(com.myapp.model.Product product)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException;

   /**
    * Loads the state associated with the given key. An exception is thrown if there is an error
    * @param key the primary key to load the object
    */
   public com.myapp.model.Product load(java.lang.Integer key)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException;

   /**
    * Get the state associated with the given key. An exception is thrown if there is an error
    * @param key the primary key to load the object
    */
   public com.myapp.model.Product get(java.lang.Integer key)
      throws net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException;
}
