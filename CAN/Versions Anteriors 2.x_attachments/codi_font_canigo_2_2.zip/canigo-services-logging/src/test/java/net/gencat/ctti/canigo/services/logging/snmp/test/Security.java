/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging.snmp.test;

import java.util.Hashtable;

import ca.wengsoft.snmp.Core.SecurityInterface;

import net.gencat.ctti.canigo.services.logging.LoggingService;


/**
 * Security for snmp
 *
 */
public class Security implements SecurityInterface {
   /**
    * Stats
    */
   private Hashtable stats = new Hashtable();

   /**
    * The logging service
    */
   private LoggingService loggingService = null;

   /**
    * Engine boots
    */
   private long engineBoots = 1;

   /**
    * Start time
    */
   private long startTime = System.currentTimeMillis();

   /**
    * Gets the user profile
    * @param userName the user name
    */
   public int getUserProfile(byte[] userName) {
      // Remove temporary
      // SecurityInterface.ENCRYPT_REQUIRED |
      return SecurityInterface.VALID_USER | SecurityInterface.AUTH_REQUIRED;
   }

   /**
    * Gets the encrypted password
    * @param userName the user name
    * @return byte[] the encrypted password
    */
   public byte[] getEncryptionPassword(byte[] userName) {
      this.loggingService.getLog(this.getClass())
                         .debug("getEncryptionPassword for " +
         new String(userName));

      return "testtest".getBytes();
   }

   /**
    * Gets the password
    * @param userName the user name
    * @return byte[] the password
    */
   public byte[] getAuthenticationPassword(byte[] userName) {
      this.loggingService.getLog(this.getClass())
                         .debug("getAuthenticationPassword for " +
         new String(userName));

      return "testtest".getBytes();
   }

   /**
    * Gets the authentication algorithm
    * @param userName the user name
    * @return int
    */
   public int getAuthenticationAlgorithm(byte[] userName) {
      this.loggingService.getLog(this.getClass())
                         .debug("getAuthenticationAlgorithm for " +
         new String(userName));

      return SecurityInterface.SHA;
   }

   /**
    * Getter
    * @return long
    */
   public long getEngineBoots() {
      return engineBoots;
   }

   /**
    * Getter
    * @return long
    */
   public long getEngineTime() {
      return (System.currentTimeMillis() - startTime) / 1000;
   }

   /**
    * Getter
    * @return byte[]
    */
   public byte[] getEngineID() {
      return "TestEngineID".getBytes();
   }

   /**
    * Getter
    * @return int
    */
   public int getStats(String OID) {
      int count;

      Integer nbr = (Integer) stats.get(OID);

      if (nbr == null) {
         count = 1;
      } else {
         count = nbr.intValue() + 1;
      }

      stats.put(OID, new Integer(count));

      return count;
   }

   /**
    * Getter
    * @return net.gencat.ctti.canigo.services.logging.LoggingService
    */
   public LoggingService getLoggingService() {
      return loggingService;
   }

   /**
    * Setter
    * @param loggingService the logging service
    */
   public void setLoggingService(LoggingService loggingService) {
      this.loggingService = loggingService;
   }
}
