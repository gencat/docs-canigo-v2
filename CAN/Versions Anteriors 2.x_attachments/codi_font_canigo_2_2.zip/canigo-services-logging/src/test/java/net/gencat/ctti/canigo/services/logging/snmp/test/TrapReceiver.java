/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging.snmp.test;

import ca.wengsoft.snmp.Core.SnmpServer;

import net.gencat.ctti.canigo.services.logging.LoggingService;


/**
 * Receives trap messages
 */
public class TrapReceiver {
   /**
    * The logging service
    */
   private LoggingService loggingService = null;

   /**
    * The snmp security
    */
   private Security security = null;

   /**
    * Snmp server
    */
   private SnmpServer server = null;

   /**
    * The test listener
    */
   private TestListener listener = null;

   /**
    * Default port
    */
   private int defaultPort = 8001;

   /**
    * Default constructor
    */
   public TrapReceiver() {
   }

   /**
    * Initializing method
    */
   public void init() {
      try {
         loggingService.getLog(this.getClass())
                       .debug("Iniciant servidor TrapReceiver...");
         server = new SnmpServer("*", defaultPort);
         server.addSnmpServerListener(listener,
            SnmpServer.TRAP_V1 | SnmpServer.TRAP_V2);
         server.addSnmpSecurityInterface(security);
         server.start();
      } catch (Exception ex) {
         loggingService.getLog(this.getClass()).error(ex);
      }
   }

   /**
    * Getter
    * @return int
    */
   public int getDefaultPort() {
      return defaultPort;
   }

   /**
    * Setter
    * @param defaultPort
    */
   public void setDefaultPort(int defaultPort) {
      this.defaultPort = defaultPort;
   }

   /**
    * Getter
    * @return net.gencat.ctti.canigo.services.logging.LoggingService
    */
   public LoggingService getLoggingService() {
      return loggingService;
   }

   /**
    * Setter
    * @param loggingService the logging service
    */
   public void setLoggingService(LoggingService logService) {
      this.loggingService = logService;
   }

   /**
    * Getter
    * @return SnmpServer
    */
   public SnmpServer getServer() {
      return server;
   }

   /**
    * Setter
    * @param server
    */
   public void setServer(SnmpServer server) {
      this.server = server;
   }

   /**
    * Getter
    * @return TestListener
    */
   public TestListener getListener() {
      return listener;
   }

   /**
    * Setter
    * @param listener
    */
   public void setListener(TestListener listener) {
      this.listener = listener;
   }

   /**
    * Getter
    * @return Security
    */
   public Security getSecurity() {
      return security;
   }

   /**
    * Setter
    * @param security
    */
   public void setSecurity(Security security) {
      this.security = security;
   }
}
