/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging.log4j.xml.impl;

import java.io.Serializable;

import java.text.SimpleDateFormat;

import java.util.Date;


/**
 * The log should have the following XML format:
 *
 * &lt;registre&gt;<br>
 *     &lt;data&gt;2006/08/03 13:59:50&lt;/data&gt;<br>
 *     &lt;errorType&gt;0&lt;/errorType&gt; <br>
 *     &lt;aplicacio&gt;/ma&lt;/aplicacio&gt; <br>
 *     &lt;logger&gt;Log4JLog.java&lt;/logger&gt; <br>
 *     &lt;nivell&gt;INFO&lt;/nivell&gt; <br>
 *     &lt;classe&gt;net.opentrends.openframe.services.web.taglib.util.TagUtil&lt;/classe&gt;<br>
 *     &lt;metode&gt;info&lt;/metode&gt; <br>
 *     &lt;pid&gt;http-8080-Processor24&lt;/pid&gt;<br>
 *     &lt;missatge&gt;<br>
 *      &lt;![CDATA[ Skipping options field state_options ]]&gt;<br>
 *     &lt;/missatge&gt;<br>
 *     &lt;userId&gt;a&lt;/userId&gt;<br>
 *     &lt;idTramit&gt;a&lt;/idTramit&gt;<br>
 *     &lt;pagOrigen&gt;http://localhost:8080/ma/admin/aplicacions.do&lt;/pagOrigen&gt;<br>
 *     &lt;textException&gt; &lt;![CDATA[ ... ]]&gt; &lt;/textException&gt; <br>
 * &lt;/registre&gt;<br>
 *
 * @author MMR
 *
 */
public class TrazaCtti implements Serializable {
   /**
    * Documentaci�.
    */
   public static String ROOT_NODE = "registres";

   /**
    * Documentaci�.
    */
   public static String NODE = "registre";

   /**
    * Documentaci�.
    */
   public static String DATA = "data";

   /**
    * Documentaci�.
    */
   public static String ERROR_TYPE = "errorType";

   /**
    * Documentaci�.
    */
   public static String APLICACIO = "aplicacio";

   /**
    * Documentaci�.
    */
   public static String LOGGER = "logger";

   /**
    * Documentaci�.
    */
   public static String NIVELL = "nivell";

   /**
    * Documentaci�.
    */
   public static String CLASSE = "classe";

   /**
    * Documentaci�.
    */
   public static String METODE = "metode";

   /**
    * Documentaci�.
    */
   public static String PID = "pid";

   /**
    * Documentaci�.
    */
   public static String MISSATGE = "missatge";

   /**
    * Documentaci�.
    */
   public static String USER_ID = "userId";

   /**
    * Documentaci�.
    */
   public static String ID_TRAMIT = "idTramit";

   /**
    * Documentaci�.
    */
   public static String PAG_ORIGEN = "pagOrigen";

   /**
    * Documentaci�.
    */
   public static String TEXT_EXCEPTION = "textException";

   /**
    * Documentaci�.
    */
   private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(TrazaCtti.class);

   /**
    * Log encoding
    */
   public static String XML_ENCODING = "ISO-8859-1";

   /**
    * XML header
    */
   public static String XML_HEADER = "<?xml version=\"1.0\" encoding=\"" +
      XML_ENCODING + "\"?><registres>";

   /**
    * Documentaci�.
    */
   public static String XML_FOOTER = "</registres>";

   /**
    * CTTI DTD
    */
   public static StringBuffer CTTI_DTD = new StringBuffer();

   static {
      CTTI_DTD = new StringBuffer();
      CTTI_DTD.append("<!ELEMENT registres (registre*)>\r\n");
      CTTI_DTD.append(
         "<!ELEMENT registre (data, errorType?, aplicacio?, logger?, nivell, classe, metode?, pid, missatge, userId?, idTramit?, pagOrigen, textException?) >\r\n");
      CTTI_DTD.append("<!ELEMENT data      (#PCDATA)>\r\n");
      CTTI_DTD.append("<!ELEMENT errorType     (#PCDATA)>\r\n");
      CTTI_DTD.append("<!ELEMENT aplicacio     (#PCDATA)>\r\n");
      CTTI_DTD.append("<!ELEMENT logger    (#PCDATA)>\r\n");
      CTTI_DTD.append("<!ELEMENT nivell    (#PCDATA)>\r\n");
      CTTI_DTD.append("<!ELEMENT classe    (#PCDATA)>\r\n");
      CTTI_DTD.append("<!ELEMENT metode    (#PCDATA)>\r\n");
      CTTI_DTD.append("<!ELEMENT pid       (#PCDATA)>\r\n");
      CTTI_DTD.append("<!ELEMENT missatge  (#PCDATA)>\r\n");
      CTTI_DTD.append("<!ELEMENT userId    (#PCDATA)>\r\n");
      CTTI_DTD.append("<!ELEMENT idTramit  (#PCDATA)>\r\n");
      CTTI_DTD.append("<!ELEMENT pagOrigen (#PCDATA)>\r\n");
      CTTI_DTD.append("<!ELEMENT textException (#PCDATA)>\r\n");
   }

   /**
    * The day this log item belongs to
    */
   private Date dia = null;

   /**
    * Documentaci�.
    */
   private String aplicacio = null;

   /**
    * Documentaci�.
    */
   private String classe = null;

   /**
    * Documentaci�.
    */
   private String data = null;

   //    XXX CAN-40
   /**
    * Documentaci�.
    */
   private String dataFormat = "dd/MM/yyyy HH:mm:ss";

   /**
    * Documentaci�.
    */
   private String errorType = null;

   /**
    * Documentaci�.
    */
   private String idTramit = null;

   /**
    * Documentaci�.
    */
   private String logger = null;

   /**
    * Documentaci�.
    */
   private String metode = null;

   /**
    * Documentaci�.
    */
   private String missatge = null;

   /**
    * Documentaci�.
    */
   private String nivell = null;

   /**
    * Documentaci�.
    */
   private String pagOrigen = null;

   /**
    * Documentaci�.
    */
   private String pid = null;

   //XXX CAN-40
   /**
    * Documentaci�.
    */
   private String ruta = null;

   /**
    * Documentaci�.
    */
   private String textException = null;

   /**
    * Documentaci�.
    */
   private String userId = null;

   /**
    * Documentaci�.
    */
   private boolean matchFilters = true;

   /**
    * Creates a new TrazaCtti object.
    */
   public TrazaCtti() {
      super();
   }

   /**
    * Creates a new TrazaCtti object.
    *
    * @param dataFormat DOCUMENT ME.
    */
   public TrazaCtti(String dataFormat) {
      this();
      this.dataFormat = dataFormat;
   }

   //    XXX CAN-40
   //    /**
   //     * @return Returns the fitxerDeTraces.
   //     */
   //    public FitxerAplicacio getFitxerTraces() {
   //        return fitxerTraces;
   //    }
   //    /**
   //     * @param fitxerDeTraces The fitxerDeTraces to set.
   //     */
   //    public void setFitxerTraces(FitxerAplicacio fitxerDeTraces) {
   //        this.fitxerTraces = fitxerDeTraces;
   //    }
   /**
    * @return Returns the aplicacio.
    */
   public String getAplicacio() {
      return aplicacio;
   }

   /**
    * @param aplicacio The aplicacio to set.
    */
   public void setAplicacio(String aplicacio) {
      this.aplicacio = aplicacio;
   }

   /**
    * @return Returns the classe.
    */
   public String getClasse() {
      return classe;
   }

   /**
    * @param classe The classe to set.
    */
   public void setClasse(String classe) {
      this.classe = classe;
   }

   /**
    * @return Returns the data.
    */
   public String getData() {
      return data;
   }

   /**
    * @param data The data to set.
    */
   public void setData(String data) {
      this.data = data;
   }

   /**
    * @return Returns the errorType.
    */
   public String getErrorType() {
      return errorType;
   }

   /**
    * @param errorType The errorType to set.
    */
   public void setErrorType(String errorType) {
      this.errorType = errorType;
   }

   /**
    * @return Returns the idTramit.
    */
   public String getIdTramit() {
      return idTramit;
   }

   /**
    * @param idTramit The idTramit to set.
    */
   public void setIdTramit(String idTramit) {
      this.idTramit = idTramit;
   }

   /**
    * @return Returns the logger.
    */
   public String getLogger() {
      return logger;
   }

   /**
    * @param logger The logger to set.
    */
   public void setLogger(String logger) {
      this.logger = logger;
   }

   /**
    * @return Returns the metode.
    */
   public String getMetode() {
      return metode;
   }

   /**
    * @param metode The metode to set.
    */
   public void setMetode(String metode) {
      this.metode = metode;
   }

   /**
    * @return Returns the missatge.
    */
   public String getMissatge() {
      return missatge;
   }

   /**
    * @param missatge The missatge to set.
    */
   public void setMissatge(String missatge) {
      this.missatge = missatge;
   }

   /**
    * @return Returns the nivell.
    */
   public String getNivell() {
      return nivell;
   }

   /**
    * @param nivell The nivell to set.
    */
   public void setNivell(String nivell) {
      this.nivell = nivell;
   }

   /**
    * @return Returns the pagOrigen.
    */
   public String getPagOrigen() {
      return pagOrigen;
   }

   /**
    * @param pagOrigen The pagOrigen to set.
    */
   public void setPagOrigen(String pagOrigen) {
      this.pagOrigen = pagOrigen;
   }

   /**
    * @return Returns the pid.
    */
   public String getPid() {
      return pid;
   }

   /**
    * @param pid The pid to set.
    */
   public void setPid(String pid) {
      this.pid = pid;
   }

   /**
    * @return Returns the textException.
    */
   public String getTextException() {
      return textException;
   }

   /**
    * @param textException The textException to set.
    */
   public void setTextException(String textException) {
      this.textException = textException;
   }

   /**
    * @return Returns the userId.
    */
   public String getUserId() {
      return userId;
   }

   /**
    * @param userId The userId to set.
    */
   public void setUserId(String userId) {
      this.userId = userId;
   }

   /**
    * @return Returns the dia.
    */
   public Date getDia() {
      return dia;
   }

   /**
    * @param dia The dia to set.
    */
   public void setDia(Date dia) {
      this.dia = dia;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getHour() {
      if ((this.data != null) && !"".equals(data)) {
         Date data = null;

         try {
            data = new SimpleDateFormat(this.dataFormat).parse(this.data);

            return new SimpleDateFormat("HH:mm:ss").format(data);
         } catch (Exception e) {
            log.error("Error in date from traza", e);
         }
      }

      return null;
   }

   /**
    * @return Returns the isFiltered.
    */
   public boolean isMatchFilters() {
      return matchFilters;
   }

   /**
    * @param isFiltered The isFiltered to set.
    */
   public void setMatchFilters(boolean isFiltered) {
      this.matchFilters = isFiltered;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getRuta() {
      return ruta;
   }

   /**
    * Documentaci�.
    *
    * @param ruta Documentaci�
    */
   public void setRuta(String ruta) {
      this.ruta = ruta;
   }
}
