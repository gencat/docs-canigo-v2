/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging.log4j.xml.impl;

import java.io.BufferedReader;
import java.io.File;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.gencat.ctti.canigo.core.util.beanutils.BeanUtils;
import net.gencat.ctti.canigo.services.file.FileSystemService;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.logging.log4j.Log4JServiceImpl;

//XXX CAN-40
//import net.gencat.controlpanel.exceptions.ControlPanelException;
import net.gencat.ctti.canigo.services.logging.log4j.xml.impl.TrazaCtti;

//XXX CAN-40
//import net.gencat.ctti.canigo.services.web.lists.exception.WebListsServiceException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;


/**
 * @author MMR
 *
 */
public class DailyRollingFileLogBuilder implements LogBuilder {
   /**
    * Filter config EQUALS ('equalsIgnoreCase')
    */
   public static String EQUALS = "EQUALS";

   /**
    * Filter config LIKE ('indexOf')
    */
   public static String LIKE = "LIKE";

   /**
    * File Service
    */
   private FileSystemService fileSystemService = null;

   /**
    * The log service
    */
   private LoggingService logService = null;

   /**
    * Configuration for filters (EQUALS or LIKE)
    */
   private Map filtersConfig = null;

   /**
    * The file date pattern. Default 'yyyyMMdd'
    */
   private String fileDatePattern = "yyyyMMdd";

   /**
    * The filter date pattern. Default 'dd/MM/yyyy'
    */
   private String filterDatePattern = "dd/MM/yyyy";

   /**
    * 'data' log item format
    */
   private String logItemDatePattern = "dd/MM/yyyy HH:mm:ss";

   /**
    * The maximum number of logs to build
    */
   private long maxLogs = Long.MAX_VALUE;

   /**
    * @return Returns the fileDatePattern.
    */
   public String getFileDatePattern() {
      return fileDatePattern;
   }

   /**
    * @param fileDatePattern The fileDatePattern to set.
    */
   public void setFileDatePattern(String fileDatePattern) {
      this.fileDatePattern = fileDatePattern;
   }

   /**
    * @return Returns the filterDatePattern.
    */
   public String getFilterDatePattern() {
      return filterDatePattern;
   }

   /**
    * @param filterDatePattern The filterDatePattern to set.
    */
   public void setFilterDatePattern(String filterDatePattern) {
      this.filterDatePattern = filterDatePattern;
   }

   /**
    * @return Returns the logService.
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * @param logService The logService to set.
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * Documentaci�.
    *
    * @param logList Documentaci�
    * @param filters Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public List getLogItems(DailyRollingFileLogInfo logList, Map filters)
      throws Exception {
      String path = (String) filters.get(DailyRollingFileLogFinderAdapter.PATH);
      String dia = (String) filters.get(DailyRollingFileLogFinderAdapter.DATE);

      if ((dia != null) && !"".equals(dia)) {
         // Log4J daillyRollingFile behaviour 
         Date date = null;

         try {
            date = new SimpleDateFormat(this.filterDatePattern).parse(dia);
            dia = new SimpleDateFormat(this.fileDatePattern).format(date);
            path = path + "." + dia;
         } catch (ParseException ex) {
            this.logService.getLog(this.getClass())
                           .error("Cannot parse date filter " + dia, ex);
         }
      }

      this.logService.getLog(this.getClass()).info("Preparing file: " + path);

      File log4jOut = new File(path);

      // XMLLayout does not write a valid XML file, so we have to write a wrapper
      // see http://logging.apache.org/log4j/docs/api/org/apache/log4j/xml/XMLLayout.html
      if (log4jOut.exists()) {
         this.logService.getLog(this.getClass()).info("Parsing XML file...");

         return this.parseFile(log4jOut, logList, filters);
      } else {
         this.logService.getLog(this.getClass())
                        .info("File " + path +
            " does not exist. Cannot obtain logs. Returning null");
      }

      return null;
   }

   /**
    * @return Returns the fileSystemService.
    */
   public FileSystemService getFileSystemService() {
      return fileSystemService;
   }

   /**
    * @param fileSystemService The fileSystemService to set.
    */
   public void setFileSystemService(FileSystemService fileSystemService) {
      this.fileSystemService = fileSystemService;
   }

   /**
    * Parses log file (XML)
    * @param file
    * @param filters
    * @return java.util.List
    * @throws Exception
    */
   private List parseFile(File file, DailyRollingFileLogInfo logList,
      Map filters) throws Exception {
      XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
      factory.setNamespaceAware(true);

      XmlPullParser xpp = factory.newPullParser();
      PatternXMLLayoutReader source = new PatternXMLLayoutReader(file);
      source.setLogService(this.logService);
      xpp.setInput(new BufferedReader(source));

      int eventType = xpp.getEventType();
      TrazaCtti logItem = null;
      String lastNode = null;
      StringBuffer lastValue = null;

      try {
         do {
            if (eventType == XmlPullParser.START_DOCUMENT) {
               this.logService.getLog(this.getClass()).debug("Start document");
            } else if (eventType == XmlPullParser.END_DOCUMENT) {
               this.logService.getLog(this.getClass()).debug("End document");
            } else if (eventType == XmlPullParser.START_TAG) {
               lastNode = xpp.getName();
               this.logService.getLog(this.getClass())
                              .debug("Start element: " + lastNode);

               if (TrazaCtti.NODE.equalsIgnoreCase(lastNode)) {
                  logItem = new TrazaCtti(this.logItemDatePattern);
               }

               lastValue = new StringBuffer();
            } else if (eventType == XmlPullParser.END_TAG) {
               processEndElement(xpp.getName(), filters, logList, logItem,
                  lastNode, lastValue.toString(), file);
            } else if (eventType == XmlPullParser.TEXT) {
               lastValue.append(processText(xpp, logItem));
            }

            eventType = xpp.next();
         } while (eventType != XmlPullParser.END_DOCUMENT);
      } finally {
         source.close();
      }

      return logList.getItems();
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param filters Documentaci�
    * @param logList Documentaci�
    * @param logItem Documentaci�
    * @param node Documentaci�
    * @param value Documentaci�
    * @param file Documentaci�
    *
    * @throws Exception Documentaci�
    * @throws RuntimeException Documentaci�
    */
   public void processEndElement(String name, Map filters,
      DailyRollingFileLogInfo logList, TrazaCtti logItem, String node,
      String value, File file) throws Exception {
      this.logService.getLog(this.getClass()).debug("End element: " + name);

      // If logItem is filtered then, discard it
      if (!TrazaCtti.NODE.equalsIgnoreCase(name) &&
            !TrazaCtti.ROOT_NODE.equalsIgnoreCase(name)) {
         if (logItem.isMatchFilters()) {
            // Default filter config is EQUALS
            String filterConfig = ((String) this.filtersConfig.get(node) != null)
               ? (String) this.filtersConfig.get(node) : EQUALS;
            String filterValue = (String) filters.get(node);
            boolean matchFilters = true;

            if ((filterValue != null) && !"".equals(filterValue)) {
               // value is never null 
               if (EQUALS.equals(filterConfig)) {
                  matchFilters = value.equalsIgnoreCase(filterValue);
               } else if (LIKE.equals(filterConfig)) {
                  matchFilters = value.toLowerCase()
                                      .indexOf(filterValue.toLowerCase()) != -1;
               } else {
                  // Default EQUALS
                  matchFilters = value.equalsIgnoreCase(filterValue);
               }
            }

            // If logItem is filtered (default true), then 
            logItem.setMatchFilters(matchFilters);
            BeanUtils.setProperty(logItem, node, value);
         }
      } else if (TrazaCtti.NODE.equalsIgnoreCase(name)) {
         if (logItem.isMatchFilters()) {
            logList.addItem(logItem);

            if (logList.getItems().size() >= this.maxLogs) {
               //XXX CAN-40
               //ExceptionDetails exD = new ExceptionDetails(DailyRollingFileLogBuilder.class.getPackage().getName()+".max_logs_exceeded",new Object[]{file.getAbsolutePath(),""+this.maxLogs});
               //XXX CAN-40
               //throw new SystemException(exD);
               throw new RuntimeException(DailyRollingFileLogBuilder.class.getPackage()
                                                                          .getName() +
                  ".max_logs_exceeded. File: " + file.getAbsolutePath() +
                  ", MaxLogs: " + this.maxLogs);
            }
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param xpp Documentaci�
    * @param logItem Documentaci�
    *
    * @return Documentaci�
    *
    * @throws XmlPullParserException Documentaci�
    */
   public String processText(XmlPullParser xpp, TrazaCtti logItem)
      throws XmlPullParserException {
      int[] holderForStartAndLength = new int[2];
      char[] ch = xpp.getTextCharacters(holderForStartAndLength);
      int start = holderForStartAndLength[0];
      int length = holderForStartAndLength[1];
      StringBuffer value = new StringBuffer();

      for (int i = start; i < (start + length); i++) {
         value.append(ch[i]);
      }

      this.logService.getLog(this.getClass()).debug("Value=" +
         value.toString());

      return value.toString();
   }

   /**
    * @return Returns the maxLogs.
    */
   public long getMaxLogs() {
      return maxLogs;
   }

   /**
    * @param maxLogs The maxLogs to set.
    */
   public void setMaxLogs(long maxLogs) {
      this.maxLogs = maxLogs;
   }

   /**
    * @return Returns the logItemDateFormat.
    */
   public String getLogItemDatePattern() {
      return logItemDatePattern;
   }

   /**
    * @param logItemDateFormat The logItemDateFormat to set.
    */
   public void setLogItemDatePattern(String logItemDateFormat) {
      this.logItemDatePattern = logItemDateFormat;
   }

   /**
    * @return Returns the filtersConfig.
    */
   public Map getFiltersConfig() {
      return filtersConfig;
   }

   /**
    * @param filtersConfig The filtersConfig to set.
    */
   public void setFiltersConfig(Map filtersConfig) {
      this.filtersConfig = filtersConfig;
   }

   //XXX CAN-40
   //    public static void main(String args[]) throws Exception{
   //        DailyRollingFileLogBuilder b = new DailyRollingFileLogBuilder();
   //        b.setLogService(new Log4JServiceImpl());
   //        b.setFiltersConfig(new HashMap());
   //        HashMap filters = new HashMap();
   //        filters.put(DailyRollingFileLogFinderAdapter.PATH,"d:\\pipex2.log");
   //        DailyRollingFileLogInfo info = new DailyRollingFileLogInfo();
   //        info.setFirstItem2Parse(540);
   //        info.setNumberOfItems2Parse(10);
   //        List list = b.getLogItems(info, filters);
   //        b.getLogService().getLog(DailyRollingFileLogBuilder.class).info("Numero de trazas parseadas="+list.size());
   //        b.getLogService().getLog(DailyRollingFileLogBuilder.class).info("Numero de total de trazas="+info.getTotalNumberOfItems());
   //    }
}
