/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.i18n.impl;

import java.util.Locale;

import net.gencat.ctti.canigo.core.threadlocal.ThreadLocalProperties;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.i18n.Constants;
import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.i18n.exception.I18nServiceException;

import org.springframework.context.MessageSource;


/**
 * Resolves messages from a key with or without parameters
 *
 * @author Manel Mateos
 *
 */
public class SpringI18nServiceImpl implements I18nService {
   /**
    * The default locale configured for this service or default locale
    * of virtual machine if not specified
    */
   private Locale defaultLocale;

   /**
    * Message resolver for a key and locale
    */
   private MessageSource messageSource = null;

   /**
    * Default constructor
    *
    */
   public SpringI18nServiceImpl() {
   }

   /**
    * Documentaci�.
    *
    * @param code Documentaci�
    *
    * @return Documentaci�
    *
    * @throws I18nServiceException Documentaci�
    */
   public String getMessage(String code) throws I18nServiceException {
      if (this.messageSource == null) {
         throw new I18nServiceException(this.getClass().getPackage() +
            ".messageSource_not_defined", new Object[] { code },
            Layer.SERVICES, Subsystem.I18N_SERVICES);
      }

      try {
         return this.messageSource.getMessage(code, null, getCurrentLocale());
      } catch (org.springframework.context.NoSuchMessageException ex) {
         throw new I18nServiceException(ex,
            this.getClass().getPackage() + ".cannot_resolve_code",
            new Object[] { code }, Layer.SERVICES, Subsystem.I18N_SERVICES);
      }
   }

   /**
    * Documentaci�.
    *
    * @param code Documentaci�
    * @param locale Documentaci�
    *
    * @return Documentaci�
    *
    * @throws I18nServiceException Documentaci�
    */
   public String getMessage(String code, Locale locale)
      throws I18nServiceException {
      if (this.messageSource == null) {
         throw new I18nServiceException(this.getClass().getPackage() +
            ".messageSource_not_defined", new Object[] { code },
            Layer.SERVICES, Subsystem.I18N_SERVICES);
      }

      try {
         return this.messageSource.getMessage(code, null, locale);
      } catch (org.springframework.context.NoSuchMessageException ex) {
         throw new I18nServiceException(ex,
            this.getClass().getPackage() + ".cannot_resolve_code_with_locale",
            new Object[] { code, locale }, Layer.SERVICES,
            Subsystem.I18N_SERVICES);
      }
   }

   /**
    * Documentaci�.
    *
    * @param code Documentaci�
    * @param args Documentaci�
    *
    * @return Documentaci�
    *
    * @throws I18nServiceException Documentaci�
    */
   public String getMessage(String code, Object[] args)
      throws I18nServiceException {
      if (this.messageSource == null) {
         throw new I18nServiceException(this.getClass().getPackage() +
            ".messageSource_not_defined", new Object[] { code },
            Layer.SERVICES, Subsystem.I18N_SERVICES);
      }

      try {
         return this.messageSource.getMessage(code, args, getCurrentLocale());
      } catch (org.springframework.context.NoSuchMessageException ex) {
         throw new I18nServiceException(ex,
            this.getClass().getPackage() +
            ".cannot_resolve_code_with_arguments",
            new Object[] { code, args2string(args) }, Layer.SERVICES,
            Subsystem.I18N_SERVICES);
      }
   }

   /**
    * Documentaci�.
    *
    * @param code Documentaci�
    * @param args Documentaci�
    * @param locale Documentaci�
    *
    * @return Documentaci�
    *
    * @throws I18nServiceException Documentaci�
    */
   public String getMessage(String code, Object[] args, Locale locale)
      throws I18nServiceException {
      if (this.messageSource == null) {
         throw new I18nServiceException(this.getClass().getPackage() +
            ".messageSource_not_defined", new Object[] { code },
            Layer.SERVICES, Subsystem.I18N_SERVICES);
      }

      try {
         return this.messageSource.getMessage(code, args, locale);
      } catch (org.springframework.context.NoSuchMessageException ex) {
         throw new I18nServiceException(ex,
            I18nServiceException.class.getPackage() +
            ".cannot_resolve_code_with_arguments_locale",
            new Object[] { code }, Layer.SERVICES, Subsystem.I18N_SERVICES);
      }
   }

   /**
    * From array of objects to a string, i.e, obj[] -> [obj[0].toString(),
    * obj[1].toString, ...]
    *
    * @param args
    *            the objects
    * @return java.lang.String
    */
   private static String args2string(Object[] args) {
      StringBuffer sb = new StringBuffer("[");

      if (args != null) {
         for (int i = 0; i < args.length; i++) {
            sb.append("" + args[i]);

            if (i < (args.length - 1)) {
               sb.append(", ");
            }
         }
      }

      return sb.append("]").toString();
   }

   /**
    * @return Returns the messageSource.
    */
   public MessageSource getMessageSource() {
      return messageSource;
   }

   /**
    * @param messageSource The messageSource to set.
    */
   public void setMessageSource(MessageSource messageSource) {
      this.messageSource = messageSource;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Locale getCurrentLocale() {
      Locale locale = (Locale) ThreadLocalProperties.get(Constants.LOCALE);

      if (locale == null) {
         return getDefaultLocale();
      } else {
         return locale;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Locale getDefaultLocale() {
      if (defaultLocale != null) {
         return defaultLocale;
      } else {
         return Locale.getDefault();
      }
   }

   /**
    * Documentaci�.
    *
    * @param defaultLocale Documentaci�
    */
   public void setDefaultLocale(Locale defaultLocale) {
      this.defaultLocale = defaultLocale;
   }
}
