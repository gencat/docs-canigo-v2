/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.mail;

import java.io.File;

import java.util.List;
import java.util.Map;

import net.gencat.ctti.canigo.services.mail.exception.MailServiceException;


/**
 * canigo Service to send e-mails.
 */
public interface MailService {
   /**
    * Sends a message to the given address. All the parameters all required (not null)
    *
    * @param from the origin address
    * @param subject the subject
    * @param aMessage the message (plain texto or html without images)
    * @param isHtml true if the message is html
    * @param to the target address
    */
   public void send(String from, String subject, String aMessage,
      boolean isHtml, String to) throws MailServiceException;

   /**
    * Sends a message to the given address with an attachment. All the parameters all required (not null)
    *
    * @param from the origin address
    * @param subject the subject
    * @param aMessage the message (plain texto or html without images)
    * @param isHtml true if the message is HTML
    * @param to the target address
    * @param attachment the attachment
    */
   public void send(String from, String subject, String aMessage,
      boolean isHtml, String to, File attachment) throws MailServiceException;

   /**
    * Sends a message to the given addresses with a list of attachmens. All the parameters are required (not null)<br>
    * The given addresses (<code>java.util.Map</code>) looks like:<br>
    * <ul>
    *      <li>Key: [MimeMessage.RecipientType.TO,MimeMessage.RecipientType.BCC � MimeMessage.RecipientType.CC]</li>
    *      <li>Value: a string (<code>java.lang.String</code>) or an array of strings(<code>java.lang.String []</code>)
    * </ul>
    * The list of attachments is a file list (<code>java.util.List</code> of <code>java.io.File</code>)
    *
    * @param from the origin address
    * @param subject the subject
    * @param aMessage the message (plain texto or html without images)
    * @param isHtml true if the message is HTML
    * @param recipients the target addresses (TO,BCC or CC)
    * @param attachments the list of attachments
    */
   public void send(String from, String subject, String aMessage,
      boolean isHtml, Map recipients, List attachments)
      throws MailServiceException;

   /**
    * Returns the maximun size of attachments (in bytes)
    * @return long
    */
   public long getMaxAttachmentSize();
}
