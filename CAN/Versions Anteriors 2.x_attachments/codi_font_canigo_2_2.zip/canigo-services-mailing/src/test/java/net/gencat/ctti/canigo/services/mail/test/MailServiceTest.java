/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.mail.test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import java.util.Date;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.mail.MailService;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * MailService test
 *
 */
public class MailServiceTest extends TestCase {
   /**
    * Initializing method
    */
   protected void setUp() throws Exception {
      super.setUp();
   }

   /**
    * MailService test with a file attachment
    *
    */
   public void testMailingWithAttachment() {
      BeanFactory beanFactory = new ClassPathXmlApplicationContext(
            "applicationContext.xml");
      MailService mailService = (MailService) beanFactory.getBean("mailService");
      TestClient clientTest = (TestClient) beanFactory.getBean("clientTest");
      LoggingService logService = (LoggingService) beanFactory.getBean(
            "logService");

      File tempFile = null;
      ByteArrayOutputStream bos = new ByteArrayOutputStream();

      try {
         tempFile = File.createTempFile("testMailing-" +
               System.currentTimeMillis(), null);
      } catch (IOException ex) {
         PrintWriter pw = new PrintWriter(bos);
         ex.printStackTrace(pw);
         pw.flush();
      }

      assertNotNull("Cannot create temp file to send attachments: " +
         bos.toString(), tempFile);

      if (tempFile != null) {
         int tempFileSize = 512;
         byte[] data = new byte[tempFileSize];
         FileOutputStream fos = null;

         try {
            fos = new FileOutputStream(tempFile);

            for (int i = 0; i < tempFileSize; i++) {
               data[i] = (byte) '0';
            }

            fos.write(data);
            fos.flush();
            fos.close();

            /**
             * Test attachment
             */
            if (logService != null) {
               logService.getLog(this.getClass())
                         .debug("From test=" + clientTest.getFromTest() +
                  ",To test=" + clientTest.getToTest());
            }

            mailService.send(clientTest.getFromTest(),
               "MailServiceTest " + new Date(),
               "MailServiceTest with attachment", false,
               clientTest.getToTest(), tempFile);
         } catch (Exception ex) {
            bos = new ByteArrayOutputStream();

            PrintWriter pw = new PrintWriter(bos);
            ex.printStackTrace(pw);
            pw.flush();
            assertFalse("Mail should be sent! \n" + bos.toString(), true);
         }

         tempFile.delete();
      }

      if (logService != null) {
         logService.getLog(this.getClass())
                   .debug("testMailingWithAttachment().End.");
      }
   }

   /**
    * MailService test with a file attachment
    *
    */
   public void testMailingWithoutAttachment() {
      BeanFactory beanFactory = new ClassPathXmlApplicationContext(
            "applicationContext.xml");
      MailService mailService = (MailService) beanFactory.getBean("mailService");
      TestClient clientTest = (TestClient) beanFactory.getBean("clientTest");
      LoggingService logService = (LoggingService) beanFactory.getBean(
            "logService");

      ByteArrayOutputStream bos = new ByteArrayOutputStream();

      /**
      * Test simple mail
      */
      try {
         if (logService != null) {
            logService.getLog(this.getClass())
                      .debug("From test=" + clientTest.getFromTest() +
               ",To test=" + clientTest.getToTest());
         }

         mailService.send(clientTest.getFromTest(),
            "MailServiceTest " + new Date(),
            "MailServiceTest without attachment", false, clientTest.getToTest());
      } catch (Exception e) {
         bos = new ByteArrayOutputStream();

         PrintWriter pw = new PrintWriter(bos);
         e.printStackTrace(pw);
         pw.flush();
         assertFalse("Mail should be sent! \n" + bos.toString(), true);
      }

      if (logService != null) {
         logService.getLog(this.getClass())
                   .debug("testMailingWithoutAttachment().End.");
      }
   }
}
