/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.util;

import java.util.List;
import java.util.Properties;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;

import fr.improve.struts.taglib.layout.field.AbstractLayoutFieldTag;

import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.SpringBindingActionForm;
import net.gencat.ctti.canigo.services.web.taglib.FieldTag;
import net.gencat.ctti.canigo.services.web.taglib.FormTag;


/**
 * <p>Classe que defineix les propietats de un camp b�sic</p>
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class BasicField extends fr.improve.struts.taglib.layout.util.BasicField {
   /**
    * Attribute created internally of associated tag
    */
   boolean isRequired = false;

   /**
    * Comencem a mostrar el camp.
    * Redefinicio del metode super de Struts Layout.
    * - Utilitzem tag 'label' de html.
    * - Es permet mostrar camps requerits com a labels o
    * imatges(representats a Ajax).
    */
   public void doStartField(StringBuffer in_buffer,
      AbstractLayoutFieldTag inTag, String in_label, Object in_value)
      throws JspException {
      FieldTag inputFormTag = null;

      if (inTag instanceof FieldTag) {
         inputFormTag = (FieldTag) inTag;
      } else {
         throw new JspTagException("FieldTag expected");
      }

      String pojoClassName;

      // Obtain form in page context
      Object bean = inTag.getPageContext().findAttribute(inTag.getName());

      String validatorName = null;

      FormTag formTag = (FormTag) inTag.findAncestorWithClass(inTag,
            FormTag.class);

      if (formTag != null) { // parent tag has been found, get validatorName

         Properties validationProperties = formTag.getValidationProperties();

         if (validationProperties != null) {
            validatorName = (String) validationProperties.get(FormTagHelper.VALIDATOR_NAME);
         }
      }

      // Obtain pojo associated to this form and obtain if the current field is a required field
      if (bean instanceof SpringBindingActionForm) {
         SpringBindingActionForm actionForm = (SpringBindingActionForm) bean;
         pojoClassName = actionForm.getPojoClassName();

         ValidationService validationService = inputFormTag.getValidationService();

         if (validationService != null) {
            if (validatorName == null) {
               validatorName = pojoClassName;
            }

            isRequired = validationService.isRequiredField(validatorName,
                  inTag.getProperty());
         }
      } else {
         isRequired = inputFormTag.isRequired();
      }

      if (isRequired) {
         BasicFieldHelper.displayRequired(in_buffer, inTag);
      }

      in_buffer = BasicFieldHelper.displayLabel(in_buffer, inTag, in_label);

      // Prepare to print the value: start the value cell.
      if (inputFormTag.isLayout()) {
         in_buffer.append("<td valign=\"top\"");

         if (inputFormTag.getStyleClass() != null) {
            in_buffer.append(" class=\"");
            in_buffer.append(inputFormTag.getStyleClass());
            in_buffer.append(" ");
         }
      }

      // Set the layoutId of the cell.
      //		if (lc_layoutId!=null) {
      //			in_buffer.append("\" id=\"");
      //			in_buffer.append(lc_layoutId);
      //			in_buffer.append("F");	
      //		}
      //		
      //		// Maybe use extra style information.
      //		String lc_style = LayoutUtils.getSkin(in_tag.getPageContext().getSession()).getFormUtils().getFieldValueStyle(in_tag.getPageContext());
      //		if (lc_style!=null) {
      //			in_buffer.append("\" style=\"");
      //			in_buffer.append(lc_style);
      //		}
      if (inputFormTag.isLayout()) {
         if (!in_buffer.toString().trim().endsWith("\"")) {
            in_buffer.append("\">");
         } else {
            in_buffer.append(">");
         }
      }
   }

   /**
    * Visualitzar camp requerit.
    *
    * @param in_buffer StringBuffer
    * @param in_tag AbstractLayoutFieldTag
    * @param in_value Object
    * @throws JspException Excepcio JSP
    * @deprecated - Now using BasicFieldHelper to show with Ajax behaviour
    */
   private void displayRequiredField(StringBuffer in_buffer,
      AbstractLayoutFieldTag in_tag, Object in_value) throws JspException {
      //  Display an image if is Required is set.
   }

   /**
    * Documentaci�.
    *
    * @param in_buffer Documentaci�
    * @param in_tag Documentaci�
    * @param in_errors Documentaci�
    */
   public void doStartErrors(StringBuffer in_buffer,
      AbstractLayoutFieldTag in_tag, List in_errors) {
      in_errors.clear();
   }

   /**
    * Sobreescriu el del super per no mostrar camps requerits amb imatges.
    */
   public void doEndField(StringBuffer in_buffer,
      AbstractLayoutFieldTag in_tag, Object in_value) throws JspException {
      FieldTag inputFormTag;

      if (in_tag instanceof FieldTag) {
         inputFormTag = (FieldTag) in_tag;
      } else {
         throw new JspTagException("FieldTag expected");
      }

      if (inputFormTag.isLayout()) {
         in_buffer.append("</td>");
      }

      // Append tool tip ajax
      BasicFieldHelper.displayTooltip(in_buffer, in_tag);

      in_tag = null;
   }

   /**
    * Documentaci�.
    *
    * @param arg0 StringBuffer
    * @param arg1 AbstractLayoutFieldTag
    * @param arg2 List
    *
    * @throws JspException - Excepci� Jsp
    */
   public void doEndErrors(StringBuffer arg0, AbstractLayoutFieldTag arg1,
      List arg2) throws JspException {
      super.doEndErrors(arg0, arg1, arg2);
   }
}
