/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts;

import fr.improve.struts.taglib.layout.util.FormUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class DefaultFormDisplayResolver implements FormDisplayResolver {
   /**
    * Documentaci�.
    */
   public static final String EDIT_METHOD_PREFIX = "edit";

   /**
    * Documentaci�.
    */
   public static final String SEARCH_METHOD_PREFIX = "search";

   /**
    * Documentaci�.
    */
   public static final String NEW_METHOD_PREFIX = "create";

   /**
    * Documentaci�.
    */
   public static final String DELETE_METHOD_PREFIX = "delete";

   /**
    * Documentaci�.
    */
   public static final String SAVE_METHOD_PREFIX = "save";

   /**
    * Documentaci�.
    */
   public static final String VIEW_METHOD_PREFIX = "view";

   /**
    * Documentaci�.
    *
    * @param methodName Documentaci�
    *
    * @return Documentaci�
    */
   public int resolveMode(String methodName) {
      if (methodName.startsWith(EDIT_METHOD_PREFIX)) {
         return FormUtils.EDIT_MODE;
      }

      if (methodName.startsWith(NEW_METHOD_PREFIX)) {
         return FormUtils.CREATE_MODE;
      }

      if (methodName.startsWith(SEARCH_METHOD_PREFIX)) {
         return FormUtils.INSPECT_MODE;
      }

      if (methodName.startsWith(SAVE_METHOD_PREFIX)) {
         return FormUtils.EDIT_MODE;
      }

      if (methodName.startsWith(VIEW_METHOD_PREFIX)) {
         return FormUtils.INSPECT_MODE;
      }

      return FormUtils.EDIT_MODE;
   }
}
