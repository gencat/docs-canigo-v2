/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.context;

import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import net.gencat.ctti.canigo.services.exceptions.aop.aspectwerkz.container.WebApplicationContextAspectContainer;

import org.springframework.web.context.support.WebApplicationContextUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class AspectWerkzContextLoaderServlet extends HttpServlet {
   /**
    * Documentaci�.
    */
   private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(AspectWerkzContextLoaderServlet.class);

   /**
    * Documentaci�.
    */
   public static String AOP_WEB_INF_XML_FILE = "/aop.xml";

   /**
    * Documentaci�.
    */
   public static String WEB_WEB_INF_XML_FILE = "/./../web.xml";

   /**
    * Creates a new AspectWerkzContextLoaderServlet object.
    */
   public AspectWerkzContextLoaderServlet() {
      super();
   }

   /**
    * Documentaci�.
    *
    * @throws ServletException Documentaci�
    */
   public void init() throws ServletException {
      super.init();
      log.info("Initializing AspectWerkzContextLoaderServlet...");

      ClassLoader classLoader = this.getClass().getClassLoader();
      log.info("Classloader=" + classLoader);

      // From AspectWerkz 2.0
      String aop = "../aop.xml";

      // From AspectWerkz 2.0
      String aopMetainf = "META-INF/aop.xml";
      URL aopRes = classLoader.getResource(aop);
      log.info("Path of '.'=" + classLoader.getResource("."));
      log.info("Path of '/'=" + classLoader.getResource("/"));
      log.info("AOP resource (../aop.xml)=" + aopRes);
      log.info("META-INF AOP resource (META-INF/aop.xml)=" +
         classLoader.getResource(aopMetainf));
      WebApplicationContextAspectContainer.setFactory(WebApplicationContextUtils.getWebApplicationContext(
            this.getServletContext()));
   }
}
