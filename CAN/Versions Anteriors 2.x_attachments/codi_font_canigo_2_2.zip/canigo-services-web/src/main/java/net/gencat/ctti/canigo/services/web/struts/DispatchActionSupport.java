/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.improve.struts.taglib.layout.util.FormUtils;

import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.web.spring.ServletRequestDynamicDataBinder;
import net.gencat.ctti.canigo.services.web.spring.bind.ServletRequestDataBinderFactory;
import net.gencat.ctti.canigo.services.web.spring.util.WebApplicationContextUtils;
import net.gencat.ctti.canigo.services.web.struts.action.ActionSupport;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.FormTag;
import net.gencat.ctti.canigo.services.web.validation.commons.WebValidationSubmit;

import ognl.Ognl;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.config.ModuleConfig;
import org.springframework.validation.Errors;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.XmlWebApplicationContext;
import org.springframework.web.struts.ContextLoaderPlugIn;
import org.springframework.web.struts.DelegatingActionUtils;


/**
 * Dispath Action Support that enables: - To use tags configurations - To use
 * pojos in an easy way - To use mode of forms automatically depending on
 * reqCode
 *
 * @author XES
 *
 */
public abstract class DispatchActionSupport extends org.springframework.web.struts.DispatchActionSupport
   implements ActionSupport {
   /**
    * Documentaci�.
    */
   public static final String REQUEST_POJO_VALIDATOR = "__RequestPojoVAlidator__";

   /**
    * Documentaci�.
    */
   public static final String REQUEST_VALIDATOR_FACTORY = "__RequestValidatorFactory__";

   /**
    * Documentaci�.
    */
   protected LoggingService logService = null;

   /**
    * Documentaci�.
    */
   private java.util.List fileUploadNames;

   /**
    * The array class of pojo to be used
    */
   private Class pojoClass;

   /**
    * Documentaci�.
    */
   private FormDisplayResolver displayModeResolver = new DefaultFormDisplayResolver();

   /**
        * Lista de metodos para los cuales hay que ejecutar la validacion
        */
   private List metodosList;

   /**
    * Documentaci�.
    */
   private Map additionalFieldNames;

   /**
    * Documentaci�.
    */
   private Map customMappingEditors;

   /**
    * The list of configuration of tags used in page of action
    */
   private Map tagsConfiguration;

   /**
    * Documentaci�.
    */
   private ServletRequestDataBinderFactory requestDataBinderFactory;

   /**
    * Documentaci�.
    */
   private ServletRequestDynamicDataBinder additionalFieldNamesBinder;

   /**
    * Documentaci�.
    */
   private ServletRequestDynamicDataBinder fileUploadBinder;

   /**
    * Mensaje por defecto de acci�n ejecutada satisfactoriamente
    */
   private String defaultSuccessMessage;

   /**
    * WebValidationSubmit
    */
   private WebValidationSubmit webValidationSubmit;

   /**
    * Documentaci�.
    */
   private boolean secureReqCode = false;

   /**
    * Dispatch to the specified method.
    * @since Struts 1.1
    */
   private ActionForward dispatchMethodInternal(ActionMapping mapping,
      ActionForm form, HttpServletRequest request,
      HttpServletResponse response, String name) throws Exception {
      ActionForward tmpForward = null;

      if (this.isSecureReqCode()) {
         tmpForward = this.dispatchMethodToSecureBeans(mapping, form, request,
               response, name);
      } else {
         tmpForward = super.dispatchMethod(mapping, form, request, response,
               name);
      }

      return tmpForward;
   }

   /**
    * Dispatch to the specified method.
    * @since Struts 1.1
    */
   protected ActionForward dispatchMethodToSecureBeans(ActionMapping mapping,
      ActionForm form, HttpServletRequest request,
      HttpServletResponse response, String name) throws Exception {
      // Make sure we have a valid method name to call.
      // This may be null if the user hacks the query string.
      if (name == null) {
         return this.unspecified(mapping, form, request, response);
      }

      // Identify the method object to be dispatched to
      Method method = null;

      try {
         method = getMethod(name);
      } catch (NoSuchMethodException e) {
         String message = messages.getMessage("dispatch.method",
               mapping.getPath(), name);
         log.error(message, e);
         throw e;
      }

      ActionForward forward = null;

      try {
         WebApplicationContext tmpAppContext = null;

         String tmpNameContext = null;
         ModuleConfig tmpModule = (ModuleConfig) request.getAttribute(Globals.MODULE_KEY);

         if (tmpModule != null) {
            tmpNameContext = tmpModule.getPrefix();
            tmpAppContext = (XmlWebApplicationContext) this.getServletContext()
                                                           .getAttribute(ContextLoaderPlugIn.SERVLET_CONTEXT_PREFIX +
                  tmpNameContext);
         }

         if (tmpAppContext == null) {
            //tmpNameContext = "";
            tmpAppContext = WebApplicationContextUtils.getWebApplicationContext(this.getServletContext());
         }

         // cuidadin com canvii de versi� spring.
         String tmpBeanName = DelegatingActionUtils.determineActionBeanName(mapping);
         Object tmpObj = tmpAppContext.getBean(tmpBeanName);

         Object[] args = { mapping, form, request, response };
         forward = (ActionForward) method.invoke(tmpObj, args);
      } catch (ClassCastException e) {
         String message = messages.getMessage("dispatch.return",
               mapping.getPath(), name);
         log.error(message, e);
         throw e;
      } catch (IllegalAccessException e) {
         String message = messages.getMessage("dispatch.error",
               mapping.getPath(), name);
         log.error(message, e);
         throw e;
      } catch (InvocationTargetException e) {
         // Rethrow the target exception if possible so that the
         // exception handling machinery can deal with it
         Throwable t = e.getTargetException();

         if (t instanceof Exception) {
            throw ((Exception) t);
         } else {
            String message = messages.getMessage("dispatch.error",
                  mapping.getPath(), name);
            log.error(message, e);
            throw new ServletException(t);
         }
      }

      // Return the returned ActionForward instance
      return (forward);
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    * @param name Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   protected ActionForward dispatchMethod(ActionMapping mapping,
      ActionForm form, HttpServletRequest request,
      HttpServletResponse response, String name) throws Exception {
      ActionForward actionF = new ActionForward();

      if (webValidationSubmit == null) {
         //			  ExceptionDetails exDetails = new ExceptionDetails("errors.noWebValidationSubmit");
         //	    	  ValidationServiceException vse = new ValidationServiceException(exDetails);
         //	    	  throw  vse;
         if (logService != null) {
            logService.getLog(this.getClass())
                      .warn("The action " + mapping.getName() +
               " don't have submit mandatory validations activaded");
         }

         // in the future, will throw an exception.       		
         actionF = this.dispatchMethodInternal(mapping, form, request,
               response, name);
         putSuccessMessage(request);
      } else { // with submit validation. 

         if ((metodosList != null) && metodosList.contains(name)) {
            if (logService != null) {
               logService.getLog(this.getClass())
                         .info("The action " + mapping.getName() +
                  "  with method " + name +
                  " has submit mandatory validations");
            }

            Errors errores = webValidationSubmit.doMandatorySubmit(mapping,
                  form, request);

            if ((errores == null) || !errores.hasErrors()) {
               actionF = this.dispatchMethodInternal(mapping, form, request,
                     response, name);
               putSuccessMessage(request);
            } else {
               request.setAttribute("errores.validacion.submit.mandatory",
                  errores);
               actionF = mapping.findForward("error");
            }
         } else {
            if (logService != null) {
               logService.getLog(this.getClass())
                         .info("The action " + mapping.getName() +
                  "  with method " + name +
                  " don't have submit mandatory validations");
            }

            // in the future, will throw an exception.           		
            actionF = this.dispatchMethodInternal(mapping, form, request,
                  response, name);
            putSuccessMessage(request);
         }
      }

      removeFormIdsFromSession(request);

      return actionF;
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    */
   private void putSuccessMessage(HttpServletRequest request) {
      if (defaultSuccessMessage != null) {
         String reqCode = request.getParameter("reqCode");

         if (reqCode != null) {
            String actionSuccessMessage = defaultSuccessMessage + "." +
               reqCode;
            request.setAttribute("actionSuccessMessage", actionSuccessMessage);
         }

         request.setAttribute("successMessage", defaultSuccessMessage);
      }
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    */
   private void removeFormIdsFromSession(HttpServletRequest request) {
      Enumeration tmpEn = request.getSession().getAttributeNames();

      while (tmpEn.hasMoreElements()) {
         String tmpKey = (String) tmpEn.nextElement();

         if (tmpKey.startsWith(FormTag.PREFIX_IDENTIFIER)) {
            request.getSession().removeAttribute(tmpKey);

            if (logService != null) {
               logService.getLog(this.getClass())
                         .debug("Removed key from session  " + tmpKey);
            }
         }
      }
   }

   /**
    * Add row edit list.
    * @param mapping
    * @param form
    * @param request
    * @param response
    * @return
    * @throws Exception
    */
   public ActionForward addRowEditList(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      FormUtils.setFormDisplayMode(request, form, FormUtils.CREATE_MODE);

      SpringBindingActionForm actionForm = (SpringBindingActionForm) form;

      String tmpItemsClass = request.getParameter("itemsClass");
      String tmpListName = request.getParameter("listName");
      String tmpForward = request.getParameter("forward");

      if (tmpForward == null) {
         throw new Exception(
            "The forward param is mandatory for reqCode addRowEditList in tag addRow");
      }

      if (tmpItemsClass == null) {
         throw new Exception(
            "The itemsClass is mandatory for reqCode addRowEditList in tag addRow");
      }

      if (tmpListName == null) {
         throw new Exception(
            "The listName param is mandatory for reqCode addRowEditList in tag addRow");
      }

      Object vo = actionForm.getTarget();

      Class tmpItemClass = Class.forName(tmpItemsClass);
      Object tmpItem = tmpItemClass.newInstance();

      List tmpList = new ArrayList();
      tmpList.add(tmpItem);

      Ognl.setValue(tmpListName, vo, tmpList);

      return mapping.findForward(tmpForward);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Class getPojoClass() {
      return pojoClass;
   }

   /**
    * Documentaci�.
    *
    * @param pojoClass Documentaci�
    */
   public void setPojoClass(Class pojoClass) {
      this.pojoClass = pojoClass;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public FormDisplayResolver getDisplayModeResolver() {
      return displayModeResolver;
   }

   /**
    * Documentaci�.
    *
    * @param displayModeResolver Documentaci�
    */
   public void setDisplayModeResolver(FormDisplayResolver displayModeResolver) {
      this.displayModeResolver = displayModeResolver;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getTagsConfiguration() {
      return tagsConfiguration;
   }

   /**
    * Documentaci�.
    *
    * @param tagsConfiguration Documentaci�
    */
   public void setTagsConfiguration(Map tagsConfiguration) {
      this.tagsConfiguration = tagsConfiguration;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List getFileUploadNames() {
      return fileUploadNames;
   }

   /**
    * Documentaci�.
    *
    * @param fileUploadnames Documentaci�
    */
   public void setFileUploadNames(List fileUploadnames) {
      this.fileUploadNames = fileUploadnames;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getAdditionalFieldNames() {
      return additionalFieldNames;
   }

   /**
    * Documentaci�.
    *
    * @param additionalFieldNames Documentaci�
    */
   public void setAdditionalFieldNames(Map additionalFieldNames) {
      this.additionalFieldNames = additionalFieldNames;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * @param logService
    *            The logService to set.
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ServletRequestDynamicDataBinder getAdditionalFieldNamesBinder() {
      return additionalFieldNamesBinder;
   }

   /**
    * Documentaci�.
    *
    * @param additionalFieldNamesBinder Documentaci�
    */
   public void setAdditionalFieldNamesBinder(
      ServletRequestDynamicDataBinder additionalFieldNamesBinder) {
      this.additionalFieldNamesBinder = additionalFieldNamesBinder;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ServletRequestDynamicDataBinder getFileUploadBinder() {
      return fileUploadBinder;
   }

   /**
    * Documentaci�.
    *
    * @param fileUploadBinder Documentaci�
    */
   public void setFileUploadBinder(
      ServletRequestDynamicDataBinder fileUploadBinder) {
      this.fileUploadBinder = fileUploadBinder;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getCustomMappingEditors() {
      return this.customMappingEditors;
   }

   /**
    * @param customMappingEditors The customMappingEditors to set.
    */
   public void setCustomMappingEditors(Map customMappingEditors) {
      this.customMappingEditors = customMappingEditors;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ServletRequestDataBinderFactory getRequestDataBinderFactory() {
      return requestDataBinderFactory;
   }

   /**
    * Documentaci�.
    *
    * @param requestDataBinderFactory Documentaci�
    */
   public void setRequestDataBinderFactory(
      ServletRequestDataBinderFactory requestDataBinderFactory) {
      this.requestDataBinderFactory = requestDataBinderFactory;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List getMetodosList() {
      return metodosList;
   }

   /**
    * Documentaci�.
    *
    * @param metodosList Documentaci�
    */
   public void setMetodosList(List metodosList) {
      this.metodosList = metodosList;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public WebValidationSubmit getWebValidationSubmit() {
      return webValidationSubmit;
   }

   /**
    * Documentaci�.
    *
    * @param webValidationSubmit Documentaci�
    */
   public void setWebValidationSubmit(WebValidationSubmit webValidationSubmit) {
      this.webValidationSubmit = webValidationSubmit;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isSecureReqCode() {
      return secureReqCode;
   }

   /**
    * Documentaci�.
    *
    * @param secureAction Documentaci�
    */
   public void setSecureReqCode(boolean secureAction) {
      this.secureReqCode = secureAction;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getDefaultSuccessMessage() {
      return defaultSuccessMessage;
   }

   /**
    * Documentaci�.
    *
    * @param defaultSuccessMessage Documentaci�
    */
   public void setDefaultSuccessMessage(String defaultSuccessMessage) {
      this.defaultSuccessMessage = defaultSuccessMessage;
   }
}
