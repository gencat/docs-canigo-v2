/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;

import fr.improve.struts.taglib.layout.el.Expression;
import fr.improve.struts.taglib.layout.field.AbstractModeFieldTag;
import fr.improve.struts.taglib.layout.skin.Skin;
import fr.improve.struts.taglib.layout.util.FormUtils;
import fr.improve.struts.taglib.layout.util.LayoutUtils;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.ServicesTagHelper;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;

import org.apache.struts.Globals;


/**
 * <p>Definici� de les propietats del Tag TextFieldTag.</p>
 *
 * @author XES
 *
 */
public class SubmitTag extends fr.improve.struts.taglib.layout.SubmitTag
   implements net.gencat.ctti.canigo.services.web.taglib.SubmitTag {
   /**
   * Serial version UID generated
   */
   private static final long serialVersionUID = -500990363481331305L;

   /**
    * Bundle where resources i18n are defined
    */
   protected String bundle = Globals.MESSAGES_KEY;

   /**
   * I18nService
   */
   private I18nService i18nService;

   /**
    * Skin reference
    */
   private Skin skin;

   /**
    * Key of value of submit
    */
   private String key;

   /**
    * Redefine mode. By an error of Struts Layout no 'getMode' is defined in parent
    */
   private String mode;

   /**
    * ValidationService
    */
   private ValidationService validationService;

   /**
    * Crea un nou objecte del tipus SubmitTag.
    */
   public SubmitTag() {
      super();
   }

   /**
    * Documentaci�.
    *
    * @param in_pageContext PageContext
    */
   public void setPageContext(PageContext in_pageContext) {
      super.setPageContext(in_pageContext);
      skin = LayoutUtils.getSkin(in_pageContext.getSession());
   }

   /**
    * Inicialitza els valors dinamics.
    */
   protected void initDynamicValues() {
      // Evaluate mode as an EL.
      jspMode = mode;
      mode = Expression.evaluate(mode, pageContext);

      // Determinate if the action should be displaued or not.
      jspDisabled = getDisabled();

      if (mode != null) {
         int lc_visible = FormUtils.computeVisibilityMode(pageContext, mode);

         switch (lc_visible) {
         case AbstractModeFieldTag.MODE_EDIT:
            display = true;

            break;

         case AbstractModeFieldTag.MODE_NODISPLAY:
            display = false;

            break;

         case AbstractModeFieldTag.MODE_DISABLED:
            display = true;
            setDisabled(true);

            break;

         case AbstractModeFieldTag.MODE_CELL:
            cell = true;

            break;
         }
      }

      // Evaluate onlick as an EL
      jspOnclick = getOnclick();
      setOnclick(Expression.evaluate(jspOnclick, pageContext));
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doStartLayoutTag() throws JspException {
      TagUtil.copyConfiguration(this);
      this.initDynamicValues();

      // Obtain from resources label associated to key and set as value
      // No used in Struts Layout, defined for canigo
      if (key != null) {
         String label = LayoutUtils.getLabel(getPageContext(), getBundle(),
               key, null, false);

         if (label != null) {
            this.setValue(label);
         }
      }

      return super.doStartLayoutTag();
   }

   /**
    * Documentaci�.
    *
    * @return boolean
    */
   public boolean isDisplay() {
      return display;
   }

   /**
    * Documentaci�.
    *
    * @param display Documentaci�
    */
   public void setDisplay(boolean display) {
      this.display = display;
   }

   /**
    * Degut a una inconsistencia en Struts-Layout
    * el mode no es pot obtenir.
    *
    * @return String
    */
   public String getMode() {
      return mode;
   }

   /**
    * Degut a una inconsistencia en Struts-Layout
    * el mode no es pot obtenir.
    *
    * @param aMode String
    */
   public void setMode(String aMode) {
      this.mode = aMode;
      super.setMode(aMode);
   }

   /**
    * Alineaci� del contingut del component.
    *
    * @return String
    */
   public String getValign() {
      return valign;
   }

   /**
    * Alineaci� del contingut del component.
    *
    * @return String
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @param validationService ValidationService
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getKey() {
      return key;
   }

   /**
    * Documentaci�.
    *
    * @param key String
    */
   public void setKey(String key) {
      this.key = key;
   }

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getBundle() {
      return bundle;
   }

   /**
    * Documentaci�.
    *
    * @param bundle String
    */
   public void setBundle(String bundle) {
      this.bundle = bundle;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Skin getSkin() {
      return skin;
   }

   /**
    * Documentaci�.
    *
    * @param skin Documentaci�
    */
   public void setSkin(Skin skin) {
      this.skin = skin;
   }

   /**
    * Serial version uid.
    *
    * @return long
    */
   public static long getSerialVersionUID() {
      return serialVersionUID;
   }

   /**
    * Permet injectar serveis del contenidor d' spring.
    *
    * @param services String
    *
    * @throws JspException
    */
   public void setServices(String services) throws JspException {
      ServicesTagHelper.setServices(services, pageContext, this);
   }
}
