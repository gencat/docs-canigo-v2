/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.config.impl;

import org.apache.struts.config.ModuleConfig;


/**
 * $Id: SpringModuleConfigFactoryImpl.java,v 1.4 2007/07/16 08:45:52 msabates Exp $
 * Spring Module Configuration Factory.
 * @author XES
 * @version Versi� $Revision: 1.4 $ $Date: 2007/07/16 08:45:52 $
 *
 * @since 1.0
 *
 * $Log: SpringModuleConfigFactoryImpl.java,v $
 * Revision 1.4  2007/07/16 08:45:52  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]
 *
 * Revision 1.3  2007/05/23 10:47:40  msabates
 * Cap�alera
 *
 * Revision 1.1.1.1.2.1  2007/05/18 10:49:46  fernando.vaquero
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2007/05/15 13:53:30  fernando.vaquero
 * Importacio canigo 2.0
 *
 * Revision 1.2  2007/05/15 10:19:03  msabates
 * Jalopy
 *
 * Revision 1.1  2007/03/28 12:13:09  msabates
 * *** empty log message ***
 *
 * Revision 1.2  2007/03/14 14:44:39  msabates
 * *** empty log message ***
 *
 * Revision 1.1  2007/03/12 11:40:56  msabates
 * Refactor a net.gencat.ctti.canigo
 *
 * Revision 1.1  2007/02/22 15:56:11  msabates
 * *** empty log message ***
 *
 * Revision 1.2  2006/11/16 16:47:43  mmateos
 * author: xescuder: XES: Improvements on documentation and using tags properties directly from jsps
 *
 * Revision 1.2  2006/02/23 18:30:45  xescuder
 * XES: Improvements on documentation and using tags properties directly from jsps
 *
 */
public class SpringModuleConfigFactoryImpl extends org.apache.struts.config.impl.DefaultModuleConfigFactory {
   /**
    * Serial version uid
    */
   private static final long serialVersionUID = 1L;

   /**
    * Logger configured for this module
    */
   private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(SpringModuleConfigFactoryImpl.class);

   /**
    * Create and return a newly instansiated {@link ModuleConfig}.
    * This method must be implemented by concrete subclasses.
    *
    * @param aPrefix Module prefix for Configuration
    * @return ModuleConfig Configuration of module with passed prefix
    */
   public ModuleConfig createModuleConfig(String aPrefix) {
      log.debug("Creating module with prefix: " + aPrefix);

      return new SpringModuleConfigImpl(aPrefix);
   }
}
