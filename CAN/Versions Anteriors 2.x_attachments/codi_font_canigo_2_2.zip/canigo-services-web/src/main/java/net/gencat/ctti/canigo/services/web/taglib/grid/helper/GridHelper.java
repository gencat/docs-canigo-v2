/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.taglib.grid.helper;

import java.util.StringTokenizer;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;

import net.gencat.ctti.canigo.services.web.taglib.grid.GridCell;
import net.gencat.ctti.canigo.services.web.taglib.grid.GridRow;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.htmlparser.Parser;
import org.htmlparser.util.NodeIterator;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class GridHelper {
   /**
    * Documentaci�.
    */
   public static final int ROW = 0;

   /**
    * Documentaci�.
    */
   public static final int COL = 1;

   /**
    * Documentaci�.
    */
   public static Log log;

   static {
      log = LogFactory.getLog(GridHelper.class);
   }

   /**
    * Documentaci�.
    *
    * @param bodyContentString Documentaci�
    * @param pageContext Documentaci�
    *
    * @return Documentaci�
    *
    * @throws ParserException Documentaci�
    */
   public static NodeIterator parse(String bodyContentString,
      PageContext pageContext) throws ParserException {
      //		bodyContentString = "<root>" + bodyContentString + "</root>";
      //		System.out.println("Translate.decode(bodyContentString):" + Translate.decode(bodyContentString));
      //		System.out.println("Translate.encode(bodyContentString):" + Translate.encode(bodyContentString));
      Parser parser = Parser.createParser(bodyContentString, "UTF-8");

      NodeList nodelist = parser.parse(new net.gencat.ctti.canigo.services.web.taglib.grid.filter.NodeFilter());

      //		return parser.elements();
      return nodelist.elements();
   }

   /**
    * Documentaci�.
    *
    * @param size Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public static Object[][] getGrid(int[] size) throws Exception {
      int rows = size[ROW];
      int cols = size[COL];

      Object[][] matrix = new Object[rows][cols];

      for (int i = 0; i < rows; i++) {
         for (int j = 0; j < cols; j++) {
            matrix[i][j] = new GridCell(matrix, i, j);
         }
      }

      return matrix;
   }

   /**
    * Documentaci�.
    *
    * @param size Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public static Object[] getRowArray(int[] size) throws Exception {
      int rows = size[ROW];

      Object[] rowArray = new Object[rows];

      for (int i = 0; i < rows; i++) {
         rowArray[i] = new GridRow();
      }

      return rowArray;
   }

   /**
    * Documentaci�.
    *
    * @param xy Documentaci�
    *
    * @return Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public static int[] getSize(String xy) throws JspException {
      int[] rowCol = new int[2];
      StringTokenizer st = new StringTokenizer(xy, ",");

      if (st.hasMoreTokens()) {
         String tmpI = st.nextToken();
         rowCol[ROW] = Integer.parseInt(tmpI);

         if (st.hasMoreTokens()) {
            tmpI = st.nextToken();
            rowCol[COL] = Integer.parseInt(tmpI);

            if (log.isDebugEnabled()) {
               log.debug("GridBagLayout size = " + rowCol[ROW] + "," +
                  rowCol[COL]);
            }

            if ((rowCol[ROW] < 0) || (rowCol[COL] < 0)) {
               throw new JspException("The gridBagLayout size  " + xy +
                  " is incorrect. The size can't be negative.");
            }
         } else {
            throw new JspException("The gridBagLayout size" + xy +
               " is incorrect. It must be in format 'row,cols'");
         }
      } else {
         throw new JspException("The gridBagLayout size" + xy +
            " is incorrect. It must be in format 'row,cols'");
      }

      return rowCol;
   }

   /**
    * Documentaci�.
    *
    * @param xy Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public static int getCols(String xy) throws Exception {
      return getSize(xy)[COL];
   }

   /**
    * Documentaci�.
    *
    * @param xy Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public static int getRows(String xy) throws Exception {
      return getSize(xy)[ROW];
   }
}
