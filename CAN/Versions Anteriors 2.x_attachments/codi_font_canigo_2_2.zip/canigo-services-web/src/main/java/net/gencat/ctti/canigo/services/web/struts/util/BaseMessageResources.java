/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.util;

import java.io.IOException;
import java.io.InputStream;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import org.apache.struts.util.MessageResources;


/**
 * Custom Message Resource implementation for Struts. This class searches through
 * a series of resource files passed to it via the constructor to obtain the localised value for a
 * key passed. If the key cannot be resolved, it prints a warning message to the logger output.
 *
 * The purpose of this class is avoid to use different message resources with Struts standard
 * strategy, where we can define several message resources by key and then from tags being accessed
 * by key. What are the effects in standard way if we change one message from a file to another?
 *
 */
public class BaseMessageResources extends MessageResources {
   /**
    *
    */
   private static final long serialVersionUID = 1L;

   //hashmap holding the resource bundle for which we have already loaded the values
   /**
    * Documentaci�.
    */
   protected HashMap bundlesLoaded = new HashMap();

   //hashmap for holding ther resource bundle key and value
   /**
    * Documentaci�.
    */
   protected HashMap resourceMap = new HashMap();

   //the array containing the names of the resource bundles to look for
   /**
    * Documentaci�.
    */
   List bundles = new ArrayList();

   /**
    * Constructor accepting a list of resource bundle files.
    * @param configFiles A List of resouce bundle files.
    */
   public BaseMessageResources(List configFiles) {
      super(null, null);
      this.bundles = configFiles;

      // TODO Auto-generated constructor stub
   }

   /** (non-Javadoc)
    * @see org.apache.struts.util.MessageResources#getMessage(java.util.Locale, java.lang.String)
    */
   public String getMessage(Locale locale, String key) {
      String message = null;

      //initialise the variables we need
      String localeKey = "";

      if (!super.defaultLocale.equals(locale)) {
         this.localeKey(locale);
      }

      //go through all the resource bundle files and load them
      for (int i = 0; i < bundles.size(); i++) {
         String config = (String) bundles.get(i);
         this.loadBundle(localeKey, config);

         //now look if the message can be found
         message = (String) resourceMap.get(key);

         //message found, so get out of the loop
         if (message != null) {
            break;
         } else {
            System.out.println("COULD NOT FIND RESOURCE FILE VALUE FOR KEY: " +
               key);
         }
      }

      return message;
   }

   /**
    * Loads the resource bundle based on the locale.
    * @param localeKey The locale
    * @param config The resource file.
    */
   protected void loadBundle(String localeKey, String config) {
      String fileName = null;
      InputStream inStream = null;
      Properties props = new Properties();

      //first check if this bundle is alreay loaded previously
      if (bundlesLoaded.get(config) != null) {
         return;
      }

      //otherwise mark this bundle being loaded
      this.bundlesLoaded.put(config, localeKey);

      // Set up to load the property resource for this locale key, if we can
      fileName = config.replace('.', '/');

      if (localeKey.length() > 0) {
         fileName += ("_" + localeKey);
      }

      fileName += ".properties";

      //obtain a class loader
      ClassLoader classLoader = Thread.currentThread().getContextClassLoader();

      //if this classloader is null, use the class loader used to load this class
      if (classLoader == null) {
         classLoader = this.getClass().getClassLoader();
      }

      //load the file as Stream
      inStream = classLoader.getResourceAsStream(fileName);

      //check if the Stream in not null
      if (inStream != null) {
         //populate the properties from this input Stream
         try {
            props.load(inStream);
         } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         } finally {
            try {
               inStream.close();
            } catch (IOException e1) {
               // TODO Auto-generated catch block
               e1.printStackTrace();
            }
         }

         //now retrieve the key value pairs from the resource file and
         //put it in the map
         synchronized (this.resourceMap) {
            Iterator iterator = props.keySet().iterator();

            while (iterator.hasNext()) {
               String key = (String) iterator.next();

               //String messageKey = this.messageKey(localeKey,key);
               String value = props.getProperty(key);

               this.resourceMap.put(key, value);
            }
         }
      } else {
         System.out.println("COULD NOT LOAD RESOURCE FILE: " + fileName);
      }
   }
}
