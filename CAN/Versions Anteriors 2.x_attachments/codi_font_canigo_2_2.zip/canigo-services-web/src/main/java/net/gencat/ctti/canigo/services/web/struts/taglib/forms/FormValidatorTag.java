/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms;

import java.io.IOException;

import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

import net.gencat.ctti.canigo.core.util.beanutils.BeanUtils;
import net.gencat.ctti.canigo.services.exceptions.BusinessException;
import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.SpringBindingActionForm;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.FieldValidatorTagHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.util.BasicFieldHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.util.FormTagHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.util.FormValidatorTagHelper;
import net.gencat.ctti.canigo.services.web.taglib.FieldTag;
import net.gencat.ctti.canigo.services.web.taglib.FormTag;
import net.gencat.ctti.canigo.services.web.taglib.SelectFieldTag;
import net.gencat.ctti.canigo.services.web.taglib.Tag;
import net.gencat.ctti.canigo.services.web.taglib.TextAreaFieldTag;
import net.gencat.ctti.canigo.services.web.taglib.TextFieldTag;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;

import org.apache.struts.taglib.TagUtils;


/**
 * <p>Definici� de les propietats del Tag FormValidatorTag.</p>
 *
 * @author
 * @version 1.4
 *
 */
public class FormValidatorTag extends TagSupport implements Tag {
   /**
    * Documentaci�.
    */
   private static final long serialVersionUID = 1107866494185767999L;

   //  public static final String VALIDATOR_NAME = "validatorName";

   /**
   * Refer�ncia al servei d'internalitzaci�.
   */
   private I18nService i18nService;

   /**
    * Documentaci�.
    */
   private String contextSubpath = null;

   /**
    * Documentaci�.
    */
   private String errorPanelStyleId;

   /**
    * Documentaci�.
    */
   private String indicator;

   /**
    * Documentaci�.
    */
   private String mode;

   /**
    * Documentaci�.
    */
   private String source;

   /**
    * Id of tag
    */
   private String styleId;

   /**
    * Documentaci�.
    */
   private String validationFormMessageMode;

   /**
    * Documentaci�.
    */
   private String validationMessageFunction;

   /**
    * ValidationService
    */
   private ValidationService validationService;

   /**
    * Documentaci�.
    */
   private boolean appendContextPath = true;

   /**
    * Crea un nou objecte del tipus FormValidatorTag.
    */
   public FormValidatorTag() {
      super();
   }

   /**
   * Crida al m�tode "copyConfiguartion" de la Classe "TagUtil".
   * Aquest m�tode obte les propietatas de la configuraci� de Spring.
   * Sino hi ha configuraci� s'agafa la configuraci� definide per
   * defecte en els tags (validationService,...)
   *
   * @author XES
   * @since 1.1.
    */
   public void init() {
      TagUtil.copyConfiguration(this);
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doStartTag() throws JspException {
      if ((this.getValidationFormMessageMode() != null) &&
            !this.getValidationFormMessageMode().equals("")) {
         FormValidatorTagHelper.generateValidation(this);
      }

      FormValidatorTagHelper.generateBehaviour(this);

      return super.doStartTag();
   }

   /**
    * Fi de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doEndTag() throws JspException {
      return super.doStartTag();
   }

   /**
    * Liberar tots els camps configurats per tal de no copiar en els
    * pr�xims tags.
    */
   public void release() {
      super.release();
      appendContextPath = true;
      contextSubpath = null;
   }

   /**
    * Documentaci�.
    *
    * @return PageContext
    */
   public PageContext getPageContext() {
      return pageContext;
   }

   /**
    * Documentaci�.
    *
    * @return PageContext
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @return I18nService
    */
   public String getStyleId() {
      return styleId;
   }

   /**
    * Aquest identificador �s el que correspon a la propietat 'styleId'
    * en el fitxer de configuraci� del tag.
    *
    * @param styleId String
    */
   public void setStyleId(String styleId) {
      this.styleId = styleId;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @param validationService ValidationService
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * Documentaci�.
    *
    * @param appendContextPath boolean
    */
   public void setAppendContextPath(boolean appendContextPath) {
      this.appendContextPath = appendContextPath;
   }

   /**
    * Documentaci�.
    *
    * @return boolean
    */
   public boolean getAppendContextPath() {
      return this.appendContextPath;
   }

   /**
    * Documentaci�.
    *
    * @return Returns the contextSubpath.
    */
   public String getContextSubpath() {
      return contextSubpath;
   }

   /**
    * Documentaci�.
    *
    * @param contextSubpath String
    */
   public void setContextSubpath(String contextSubpath) {
      this.contextSubpath = contextSubpath;
   }

   /**
    * Serial version uid.
    *
    * @return Long
    */
   public static long getSerialVersionUID() {
      return serialVersionUID;
   }

   /**
    * Id del component.
    *
    * @return String
    */
   public String getSource() {
      return source;
   }

   /**
    * Id del component.
    *
    * @param source String
    */
   public void setSource(String source) {
      this.source = source;
   }

   /**
    * Id del panell d'errors.
    *
    * @return String
    */
   public String getErrorPanelStyleId() {
      return errorPanelStyleId;
   }

   /**
    * Id del panell d'errors.
    *
    * @param errorPanelStyleId String
    */
   public void setErrorPanelStyleId(String errorPanelStyleId) {
      this.errorPanelStyleId = errorPanelStyleId;
   }

   /**
    * Indica les maneres de mostrar els errors de formulari.
    * Pot ser PANEL, FIELDS, WINDOW.
    *
    * @return Documentaci�
    */
   public String getValidationFormMessageMode() {
      return validationFormMessageMode;
   }

   /**
    * Indica les maneres de mostrar els errors de formulari.
    * Pot ser PANEL, FIELDS, WINDOW.
    *
    * @param validationFormMessageMode Documentaci�
    */
   public void setValidationFormMessageMode(String validationFormMessageMode) {
      this.validationFormMessageMode = validationFormMessageMode;
   }

   /**
    * Funci� de presentaci�.
    *
    * @return String
    */
   public String getValidationMessageFunction() {
      return validationMessageFunction;
   }

   /**
    * Funci� de presentaci�.
    *
    * @param validationMessageFunction String
    */
   public void setValidationMessageFunction(String validationMessageFunction) {
      this.validationMessageFunction = validationMessageFunction;
   }

   /**
    * El que es mostra quan es fa petici� AJAX.
    *
    * @return String
    */
   public String getIndicator() {
      return indicator;
   }

   /**
    * El que es mostra quan es fa petici� AJAX.
    *
    * @param indicator String
    */
   public void setIndicator(String indicator) {
      this.indicator = indicator;
   }

   /**
    * Necessari per quan no estant configurades les validacions del commons
    * validator i nom�s hi ha validacions dels tags.
    *
    * @return String
    */
   public String getMode() {
      return mode;
   }

   /**
    * Necessari per quan no estant configurades les validacions del commons
    * validator i nom�s hi ha validacions dels tags.
    *
    * @param mode String
    */
   public void setMode(String mode) {
      this.mode = mode;
   }
}
