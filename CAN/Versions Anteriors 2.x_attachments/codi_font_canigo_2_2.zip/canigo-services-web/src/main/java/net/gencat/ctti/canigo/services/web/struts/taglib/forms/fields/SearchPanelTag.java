/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields;

import java.io.IOException;

import java.util.Locale;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.DWRHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.ServicesTagHelper;
import net.gencat.ctti.canigo.services.web.taglib.Constants;
import net.gencat.ctti.canigo.services.web.taglib.Tag;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;

import org.ajaxtags.tags.AjaxAutocompleteTag;
import org.ajaxtags.tags.OptionsBuilder;
import org.apache.struts.taglib.TagUtils;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;


/**
 * <p>Definici� de les propietats del Tag SearchPanelTag.</p>
 *
 * @author $author$
 *
 * @version $Revision: 1.5 $
  */
public class SearchPanelTag extends TagSupport implements Tag {
   /**
    * Serial version.
    */
   private static final long serialVersionUID = 1934076733823993119L;

   /**
        * Imported scripts flag.
        */
   private static final String SEARCH_PANEL_IMPORTED_SCRIPTS = "__search_panel_imported_scripts__";

   /**
    * I18nService
    */
   private I18nService i18nService;

   /**
    * LogginService
    */
   private LoggingService logService;

   /**
    * Documentaci�.
    */
   private String columnLabels;

   //private String defaultElementsPage;
   /**
    * Documentaci�.
    */
   private String indicator;

   /**
    * Documentaci�.
    */
   private String method;

   /**
    * Documentaci�.
    */
   private String optionsListName;

   /**
    * Documentaci�.
    */
   private String parameters;

   /**
    * Documentaci�.
    */
   private String popupId;

   /**
    * Documentaci�.
    */
   private String queryParameter;

   /**
    * Documentaci�.
    */
   private String selectedProperty;

   /**
    * Documentaci�.
    */
   private String source;

   /**
    * Documentaci�.
    */
   private String styleClass;

   /**
    * Documentaci�.
    */
   private String styleId;

   /**
    * Documentaci�.
    */
   private String tableProperties;

   /**
    * Documentaci�.
    */
   private String target;

   /**
   * ValidationService
   */
   private ValidationService validationService;

   /**
    * Crea un nou objecte SearchPanelTag.
    */
   public SearchPanelTag() {
      super();
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doStartTag() throws JspException {
      if (this.getLogService() != null) {
         this.getLogService().getLog(this.getClass())
             .debug("Begin doStartTag of SearchPanelTag...");
      }

      int tmpS = super.doStartTag();

      // EVC: import engine.js if not imported yet
      DWRHelper.generateDWREngineScript(super.pageContext);

      // EVC: import tag scripts if not imported yet.
      HttpServletRequest request = (HttpServletRequest) super.pageContext.getRequest();
      HttpServletResponse response = (HttpServletResponse) super.pageContext.getResponse();

      if ((request.getAttribute(SEARCH_PANEL_IMPORTED_SCRIPTS) == null)) {
         request.setAttribute(SEARCH_PANEL_IMPORTED_SCRIPTS, Constants.IMPORTED);

         TagUtils tagUtils = TagUtils.getInstance();
         tagUtils.write(super.pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() +
            response.encodeURL("/dwr/interface/searchPanelService.js") +
            "\"></script>");
         tagUtils.write(super.pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() +
            response.encodeURL(
               "/scripts/ajax/ajaxtags/canigo-ajaxtags-searchPanel.js") +
            "\"></script>\n");
      }

      if (this.getOptionsListName() != null) {
         this.optionsListName = (String) ExpressionEvaluatorManager.evaluate("source",
               this.getOptionsListName(), String.class, this, super.pageContext);
      } else {
         throw new JspException("The attribute optionsListName is not defined");
      }

      if (this.getIndicator() != null) {
         this.indicator = (String) ExpressionEvaluatorManager.evaluate("indicator",
               this.getIndicator(), String.class, this, super.pageContext);
      }

      return tmpS;
   }

   /**
    * Fi de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doEndTag() throws JspException {
      if (this.getLogService() != null) {
         this.getLogService().getLog(this.getClass())
             .debug("Begin doEndTag of SearchPanelTag...");
      }

      TagUtil.copyConfiguration(this);

      OptionsBuilder options = new OptionsBuilder();

      options.add("popupId", this.getPopupId(), true)
             .add("target", this.getTarget(), true)
             .add("source", this.getSource(), true);

      if (this.getStyleClass() != null) {
         options.add("className", this.getStyleClass(), true);
      }

      int colsC = 0;
      int labelsC = 0;

      if (this.getI18nService() != null) {
         Locale locale = this.getI18nService().getCurrentLocale();
         StringTokenizer labels = new StringTokenizer(this.getColumnLabels(),
               ",");
         labelsC = labels.countTokens();

         String labelsP = "";

         while (labels.hasMoreTokens()) {
            String msg = labels.nextToken();
            String msgKey = i18nService.getMessage(msg, locale);

            if (labelsP.equals("")) {
               labelsP = msgKey;
            } else {
               labelsP = labelsP + "," + msgKey;
            }
         }

         options.add("columnLabels", labelsP, true);
      } else {
         throw new JspException("The I18nService is not defined");
      }

      if (this.getTableProperties() != null) {
         StringTokenizer columns = new StringTokenizer(this.getTableProperties(),
               ",");
         colsC = columns.countTokens();
         options.add("tableProperties", this.getTableProperties(), true);
      }

      if (colsC != labelsC) {
         throw new JspException(
            "The number of columns and labels should be the same");
      }

      options.add("numColumns", Integer.toString(colsC), true);

      if (this.getSelectedProperty() != null) {
         options.add("selectedProperty", this.getSelectedProperty(), true);
      }

      if (this.getOptionsListName() != null) {
         options.add("optionsListName", this.getOptionsListName(), true);
      }

      //	    if (this.getDefaultElementsPage() != null)	
      //			  options.add("defaultElementsPage", this.getDefaultElementsPage(), true);
      if (this.getIndicator() != null) {
         options.add("indicator", this.getIndicator(), true);
      }

      if (this.getMethod() != null) {
         options.add("method", this.getMethod(), true);
      }

      options.add("queryParameter", this.getQueryParameter(), true);

      StringBuffer script = new StringBuffer();
      script.append("<script type=\"text/javascript\">");
      script.append("new CanigoSearchPanelTag.Search(\"http://nop.cat/hola\",{");
      script.append(options.toString());
      script.append("});");
      script.append("</script>");

      JspWriter writer = pageContext.getOut();

      try {
         writer.println(script);
      } catch (IOException e) {
         throw new JspException(e.getMessage());
      }

      if (this.getLogService() != null) {
         this.getLogService().getLog(this.getClass())
             .debug("End doEndTag of SearchPanelTag...");
      }

      return EVAL_PAGE;
   }

   /**
    * Refer�ncia a la definici� de la llista.
     *
     * @param optionsListName String
     */
   public void setOptionsListName(String optionsListName) {
      this.optionsListName = optionsListName;
   }

   /**
    * El que es mostra quan es fa petici� AJAX.
    *
    * @return String
    */
   public String getIndicator() {
      return indicator;
   }

   /**
    * El que es mostra quan es fa petici� AJAX.
    *
    * @param indicator String
    */
   public void setIndicator(String indicator) {
      this.indicator = indicator;
   }

   //	public String getDefaultElementsPage() {
   /**
    * Par�metres per a la cerca.
    *
    * @return String
    */
   public String getParameters() {
      return parameters;
   }

   /**
    * Par�metres per a la cerca.
    *
    * @param parameters String
    */
   public void setParameters(String parameters) {
      this.parameters = parameters;
   }

   /**
    * Camp que es copiar� el valor seleccionat.
    *
    * @return String
    */
   public String getTarget() {
      return target;
   }

   /**
    * Camp que es copiar� el valor seleccionat
    *
    * @param target String
    */
   public void setTarget(String target) {
      this.target = target;
   }

   /**
    * Refer�ncia a la definici� de la llista.
    *
    * @return String
    */
   public String getOptionsListName() {
      return optionsListName;
   }

   /**
    * Identificador del div que cont� el panell de cerca.
    *
    * @return String
    */
   public String getPopupId() {
      return popupId;
   }

   /**
    * Identificador del div que cont� el panell de cerca.
    *
    * @param popupId String
    */
   public void setPopupId(String popupId) {
      this.popupId = popupId;
   }

   /**
    * Id del component gr�fic que escolar� l'event onClick per mostrar el panell.
    *
    * @return String
    */
   public String getSource() {
      return source;
   }

   /**
    * Id del component gr�fic que escolar� l'event onClick per mostrar el panell.
    *
    * @param source String
    */
   public void setSource(String source) {
      this.source = source;
   }

   /**
    * Claus dels noms de les propietats internacionalitzades.
    *
    * @return String
    */
   public String getColumnLabels() {
      return columnLabels;
   }

   /**
    * Claus dels noms de les propietats internacionalitzades.
    *
    * @param columnLabels String
    */
   public void setColumnLabels(String columnLabels) {
      this.columnLabels = columnLabels;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @return I18nService
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Documentaci�.
    *
    * @return LoggingService
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * Documentaci�.
    *
    * @param logService LoggingService
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * Identificador per lligar amb configuraci� XML.
    *
    * @return String
    */
   public String getStyleId() {
      return styleId;
   }

   /**
    * Identificador per lligar amb configuraci� XML.
    *
    * @param styleId String
    */
   public void setStyleId(String styleId) {
      this.styleId = styleId;
   }

   /**
    * Documentaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Documentaci�.
    *
    * @param validationService ValidationService
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * Documentaci�.
    *
    * @return PageContext
    */
   public PageContext getPageContext() {
      return pageContext;
   }

   /**
    * Documentaci�.
    *
    * @return PageContext
    */
   public String getSelectedProperty() {
      return selectedProperty;
   }

   /**
    * Propietat a copiar al target.
    *
    * @param selectedProperty String
    */
   public void setSelectedProperty(String selectedProperty) {
      this.selectedProperty = selectedProperty;
   }

   /**
    * Nom de les propietats del bean que es volen mostrar en la cerca.
    *
    * @return String
    */
   public String getTableProperties() {
      return tableProperties;
   }

   /**
    * Nom de les propietats del bean que es volen mostrar en la cerca.
    *
    * @param tableProperties String
    */
   public void setTableProperties(String tableProperties) {
      this.tableProperties = tableProperties;
   }

   /**
    * Nom del par�metre de la query..
    *
    * @return String
    */
   public String getQueryParameter() {
      return queryParameter;
   }

   /**
    *  Nom del par�metre de la query..
    *
    * @param queryParameter String
    */
   public void setQueryParameter(String queryParameter) {
      this.queryParameter = queryParameter;
   }

   /**
    * Nom del m�tode que s'encarregar� de fer la presentaci�, enlloc de fer la per defecte.
    *
    * @return String
    */
   public String getMethod() {
      return method;
   }

   /**
    * Nom del m�tode que s'encarregar� de fer la presentaci�, enlloc de fer la per defecte.
    *
    * @param method String
    */
   public void setMethod(String method) {
      this.method = method;
   }

   /**
    * Estil CSS per aplicar al panell.
    *
    * @return String
    */
   public String getStyleClass() {
      return styleClass;
   }

   /**
    * Estil CSS per aplicar al panell.
    *
    * @param styleClass String
    */
   public void setStyleClass(String styleClass) {
      this.styleClass = styleClass;
   }

   /**
    * Parelles de nom servei:servei . nom servei �s l'atribut que cont� el
    * servei, i servei �s el nom del servei en spring.
    *
    * @param services Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public void setServices(String services) throws JspException {
      ServicesTagHelper.setServices(services, pageContext, this);
   }
}
