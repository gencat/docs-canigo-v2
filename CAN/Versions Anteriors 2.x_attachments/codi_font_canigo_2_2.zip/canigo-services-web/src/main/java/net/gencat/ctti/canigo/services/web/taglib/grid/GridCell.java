/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.taglib.grid;

import javax.servlet.jsp.JspException;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class GridCell extends GridBase {
   /**
    * Documentaci�.
    */
   private String colspan = null;

   /**
    * Documentaci�.
    */
   private String innerhtml = "";

   /**
    * Documentaci�.
    */
   private String rowspan = null;

   /**
    * Documentaci�.
    */
   private Object[][] grid = null;

   /**
    * Documentaci�.
    */
   private int col;

   /**
    * Documentaci�.
    */
   private int row;

   /**
    * Creates a new GridCell object.
    *
    * @param grid DOCUMENT ME.
    * @param row DOCUMENT ME.
    * @param col DOCUMENT ME.
    */
   public GridCell(Object[][] grid, int row, int col) {
      this.grid = grid;
      this.row = row;
      this.col = col;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getSerializedAttributes() {
      String attributes = super.getSerializedAttributes();

      if (rowspan != null) {
         attributes += (Constants.WHITESPACE + Constants.ROWSPAN + "=\"" +
         rowspan + "\"");
      }

      if (colspan != null) {
         attributes += (Constants.WHITESPACE + Constants.COLSPAN + "=\"" +
         colspan + "\"");
      }

      return attributes;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getColspan() {
      return colspan;
   }

   /**
    * Documentaci�.
    *
    * @param colspan Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public void setColspan(String colspan) throws JspException {
      int colspanInt = new Integer(colspan).intValue();

      if (colspanInt < 1) {
         throw new JspException("Colspan attribute of cell " + this.row +
            Constants.CELLDELIM + this.col + " is " + colspan +
            ", and cannot be < 1.");
      }

      if ((this.rowspan != null) &&
            ((new Integer(this.rowspan).intValue()) > 1)) {
         for (int rowCounter = this.row;
               rowCounter < (this.row + new Integer(this.rowspan).intValue());
               rowCounter++) {
            for (int colCounter = this.col + 1;
                  colCounter < (this.col + new Integer(colspan).intValue());
                  colCounter++) {
               Object cell = null;

               try {
                  cell = grid[rowCounter][colCounter];
               } catch (Exception ex) {
                  throw new JspException("Cell " + this.row +
                     Constants.CELLDELIM + this.col +
                     " has an out of bounds colspan attribute.");
               }

               if (cell.getClass().getName()
                          .equals(OverlappedGridCell.class.getName())) {
                  // Cell overlapped by more than one cell.
                  OverlappedGridCell ovCell = (OverlappedGridCell) cell;
                  throw new JspException("Cell " + rowCounter +
                     Constants.CELLDELIM + colCounter +
                     " is overlapped by cells " + this.row +
                     Constants.CELLDELIM + this.col + " and " +
                     ovCell.getOverlappingCellRow() + Constants.CELLDELIM +
                     ovCell.getOverlappingCellCol());
               } else {
                  grid[rowCounter][colCounter] = new OverlappedGridCell(this.row,
                        this.col);
               }
            }
         }
      } else {
         for (int colCounter = this.col + 1;
               colCounter < (this.col + new Integer(colspan).intValue());
               colCounter++) {
            Object cell = null;

            try {
               cell = grid[this.row][colCounter];
            } catch (Exception ex) {
               throw new JspException("Cell " + this.row + Constants.CELLDELIM +
                  this.col + " has an out of bounds colspan attribute.");
            }

            if (cell.getClass().getName()
                       .equals(OverlappedGridCell.class.getName())) {
               // Cell overlapped by more than one cell.
               OverlappedGridCell ovCell = (OverlappedGridCell) cell;
               throw new JspException("Cell " + this.row + Constants.CELLDELIM +
                  colCounter + " is overlapped by cells " + this.row +
                  Constants.CELLDELIM + this.col + " and " +
                  ovCell.getOverlappingCellRow() + Constants.CELLDELIM +
                  ovCell.getOverlappingCellCol());
            } else {
               grid[this.row][colCounter] = new OverlappedGridCell(this.row,
                     this.col);
            }
         }
      }

      this.colspan = colspan;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getRowspan() {
      return rowspan;
   }

   /**
    * Documentaci�.
    *
    * @param rowspan Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public void setRowspan(String rowspan) throws JspException {
      for (int rowCounter = this.row + 1;
            rowCounter < (this.row + new Integer(rowspan).intValue());
            rowCounter++) {
         Object cell = null;

         try {
            cell = grid[rowCounter][this.col];
         } catch (Exception ex) {
            throw new JspException("Cell " + this.row + Constants.CELLDELIM +
               this.col + " has an out of bounds rowspan attribute.");
         }

         if (cell.getClass().getName().equals(OverlappedGridCell.class.getName())) {
            // Cell overlapped by more than one cell.
            OverlappedGridCell ovCell = (OverlappedGridCell) cell;
            throw new JspException("Cell " + rowCounter + Constants.CELLDELIM +
               this.col + " is overlapped by cells " + this.row +
               Constants.CELLDELIM + this.col + " and " +
               ovCell.getOverlappingCellRow() + Constants.CELLDELIM +
               ovCell.getOverlappingCellCol());
         } else {
            grid[rowCounter][this.col] = new OverlappedGridCell(this.row,
                  this.col);
         }
      }

      this.rowspan = rowspan;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getInnerhtml() {
      return innerhtml;
   }

   /**
    * Documentaci�.
    *
    * @param innerhtml Documentaci�
    */
   public void setInnerhtml(String innerhtml) {
      this.innerhtml = innerhtml;
   }

   /**
    * Documentaci�.
    */
   public void release() {
      this.colspan = null;

      this.rowspan = null;

      this.innerhtml = null;

      super.release();
   }
}
