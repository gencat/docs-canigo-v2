/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers;

import java.util.Iterator;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.servlet.jsp.JspException;

import fr.improve.struts.taglib.layout.field.AbstractModeFieldTag;

import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.TextAreaFieldTag;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.TextFieldTagHelper;

import org.apache.struts.taglib.TagUtils;


/**
 * Helper de TextAreaFieldTag.
 *
 * @author $author$
 * @version $Revision: 1.6 $
  */
public class TextAreaFieldTagHelper {
   /**
    * Crea un nou objecte del tipus TextAreaFieldTagHelper.
    */
   public TextAreaFieldTagHelper() {
      super();
   }

   /**
    * Afegeix decorators (basad en TinyMCE)
    * @param aTextAreaFieldTag TextAreaFieldTag
    * @throws JspException
    */
   public static void appendDecorators(TextAreaFieldTag aTextAreaFieldTag)
      throws JspException {
      if (aTextAreaFieldTag.getFieldDisplayMode() == AbstractModeFieldTag.MODE_EDIT) {
         Properties decoratorProperties = aTextAreaFieldTag.getDecoratorProperties();

         if (decoratorProperties != null) {
            // Now only one text area with decorators allowed
            TagUtils tagUtils = TagUtils.getInstance();
            StringBuffer buffer = new StringBuffer();

            //                ConfigurationTag config = (ConfigurationTag)TagUtil.getConfigurationTag(aTextAreaFieldTag.getPageContext());
            //                boolean tinyMCELibraryGenerated = "true".equals(aTextAreaFieldTag.getPageContext().getAttribute("_tinyMCELibraryGenerated_"));
            //                if (config!=null&&!tinyMCELibraryGenerated) {
            //                    config.addScriptLibrary(aTextAreaFieldTag.getPageContext(),"/textareas/tiny_mce/tiny_mce.js");
            //                }
            buffer.append("<script type=\"text/javascript\">");
            buffer.append("tinyMCE.init({");

            Iterator decoratorIt = decoratorProperties.keySet().iterator();

            while (decoratorIt.hasNext()) {
               String key = (String) decoratorIt.next();
               String value = decoratorProperties.getProperty(key);
               buffer.append(key + ":" + "\"" + value + "\",");
            }

            // Last parameter add id of textarea
            buffer.append("elements : \"" + aTextAreaFieldTag.getStyleId() +
               "\"");
            buffer.append("});");
            buffer.append("</script>");
            tagUtils.write(aTextAreaFieldTag.getPageContext(), buffer.toString());
         }
      }
   }

   /**
    * Afegeix comportaments al TextArea.
    *
    * @param aTextFieldTag Documentaci�
    */
   public static void appendBehaviours(TextAreaFieldTag aTextFieldTag) {
      // For all attributes of type 'behaviour' (ajax) add style class
      if (aTextFieldTag.isAutoTab()) {
         aTextFieldTag.setStyleClass(aTextFieldTag.getStyleClass() + " " +
            TextFieldTagHelper.AUTO_TAB);
      }

      // Get conversions        
      if (aTextFieldTag.getConvertTo() != null) {
         StringTokenizer strToken = new StringTokenizer(aTextFieldTag.getConvertTo(),
               ",");

         while (strToken.hasMoreElements()) {
            String conversion = strToken.nextToken();
            aTextFieldTag.setStyleClass(aTextFieldTag.getStyleClass() + " " +
               conversion);
         }
      }

      if (aTextFieldTag.isSelectOnFocus()) {
         aTextFieldTag.setStyleClass((aTextFieldTag.getStyleClass() != null)
            ? aTextFieldTag.getStyleClass()
            : ("" + " " + TextFieldTagHelper.SELECT_ON_FOCUS));
      }
   }
}
