/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.ServicesTagHelper;
import net.gencat.ctti.canigo.services.web.taglib.Tag;

import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;


/**
 * <p>Definici� de les propietats del Tag TextErrorTag.</p>
 *
 * @author
 *
 * @version Versi� 1.4 $ $Date: 2007/07/25 11:10:34 $
 *
 */
public class TextErrorTag extends TagSupport implements Tag {
   /**
    * Documentaci�.
    */
   private static final long serialVersionUID = 1107866494185767999L;

   /**
   * I18nService
   */
   private I18nService i18nService;

   /**
    * Documentaci�.
    */
   private String contextSubpath = null;

   /**
    * Documentaci�.
    */
   private String styleClass;

   /**
    * Id of tag
    */
   private String styleId;

   /**
    * ValidationService
    */
   private ValidationService validationService;

   /**
    * Documentaci�.
    */
   private boolean appendContextPath = true;

   /**
    * Creacio de un nou objecte TextErrorTag.
    */
   public TextErrorTag() {
      super();
   }

   /**
    * Inici de la configuraci� del Tag..
    *
    * @return int
    *
    * @throws JspException
    * @throws JspTagException
   */
   public int doStartTag() throws JspException {
      if (this.getStyleId() != null) {
         this.styleId = (String) ExpressionEvaluatorManager.evaluate("styleId",
               this.styleId, String.class, this, pageContext);
      }

      if (this.getStyleClass() != null) {
         this.styleClass = (String) ExpressionEvaluatorManager.evaluate("styleClass",
               this.styleClass, String.class, this, pageContext);
      }

      try {
         if (styleId != null) {
            pageContext.getOut()
                       .write("<div id=\"" + styleId + "\" class=\"" +
               styleClass + "\" ></div>");
         }
      } catch (IOException e) {
         throw new JspTagException("An IOException occurred.");
      }

      return SKIP_BODY;
   }

   /**
    * Fi configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException Documentaci�
    */
   public int doEndTag() throws JspException {
      return EVAL_PAGE;
   }

   /**
    * Liberar tots els camps configurats per tal de no copiar en els
    * pr�xims tags.
    *
    * @author
    */
   public void release() {
      super.release();
      appendContextPath = true;
      contextSubpath = null;
      styleClass = null;
      styleId = null;
   }

   /**
    * Documentaci�.
    *
    * @return PageContext
    */
   public PageContext getPageContext() {
      return pageContext;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @return I18nService
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�..
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Id d'enlla� amb la configuraci� XML.
    *
    * @return String
    */
   public String getStyleId() {
      return styleId;
   }

   /**
    * Id d'enlla� amb la configuraci� XML.
    *
    * @param styleId String
    */
   public void setStyleId(String styleId) {
      this.styleId = styleId;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @param validationService ValidationService
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * Documentaci�.
    *
    * @param appendContextPath boolean
    */
   public void setAppendContextPath(boolean appendContextPath) {
      this.appendContextPath = appendContextPath;
   }

   /**
    * Documentaci�.
    *
    * @return boolean
    */
   public boolean getAppendContextPath() {
      return this.appendContextPath;
   }

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getContextSubpath() {
      return contextSubpath;
   }

   /**
    * Documentaci�.
    *
    * @param contextSubpath String
    */
   public void setContextSubpath(String contextSubpath) {
      this.contextSubpath = contextSubpath;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public static long getSerialVersionUID() {
      return serialVersionUID;
   }

   /**
    * Estil CSS a utilitzar.
    *
    * @return String
    */
   public String getStyleClass() {
      return styleClass;
   }

   /**
    * Estil CSS a utilitzar.
    *
    * @param styleClass String
    */
   public void setStyleClass(String styleClass) {
      this.styleClass = styleClass;
   }

   /**
    * Permet injectar serveis del contenidor d' spring.
    *
    * @param services String
    *
    * @throws JspException
    */
   public void setServices(String services) throws JspException {
      ServicesTagHelper.setServices(services, pageContext, this);
   }
}
