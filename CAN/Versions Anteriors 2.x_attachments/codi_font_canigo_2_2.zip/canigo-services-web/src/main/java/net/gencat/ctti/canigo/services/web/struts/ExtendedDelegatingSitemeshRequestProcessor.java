/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts;

import java.io.IOException;

import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.improve.struts.taglib.layout.util.FormUtils;

import net.gencat.ctti.canigo.core.springframework.beans.BindException;
import net.gencat.ctti.canigo.services.exceptions.SystemException;
import net.gencat.ctti.canigo.services.exceptions.WrappedCheckedException;
import net.gencat.ctti.canigo.services.logging.Log;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.web.exception.TagsServiceException;
import net.gencat.ctti.canigo.services.web.spring.bind.ServletRequestDataBinder;
import net.gencat.ctti.canigo.services.web.spring.bind.ServletRequestDataBinderFactory;
import net.gencat.ctti.canigo.services.web.struts.action.ActionSupport;
import net.gencat.ctti.canigo.services.web.struts.helper.BindingHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.configuration.ConfigurationTag;

import org.apache.struts.Globals;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.config.ModuleConfig;
import org.springframework.beans.BeanUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.struts.DelegatingRequestProcessor;


/**
 * <p>Proces de la request quan s'utilitza sitemesh. A diferencia de
 * "ExtendedDelegatingTilesRequestProcessor extend de
 * "DelegatingRequestProcessor".</p>
 *
 * @author FND
 * @version 1
 *
 */
public class ExtendedDelegatingSitemeshRequestProcessor
   extends DelegatingRequestProcessor {
   /**
    * Documentaci�.
    */
   private static final String SERVLET_REQUEST_DATA_BINDER_FACTORY = "servletRequestDataBinderFactory";

   /**
    * Documentaci�.
    */
   public static final String ACTION_TAGS_CONFIGURATION = "__tagsConfiguration__";

   /**
    * Documentaci�.
    */
   public static final String CURRENT_MODE_REQUEST_ATTRIBUTE = "__currentMode__";

   /**
    * Documentaci�.
    */
   public static final String CONFIGURATION_TAG = "configurationTag";

   /**
    * Servei logging predetermitat a l'atribut pageContext.
    */
   public static final String DEFAULT_LOGGING_SERVICE = "defaultLoggingService";

   /**
    * Servei d'internacionalitzaci� predetermitat a l'atribut pageContext.
    */
   public static final String DEFAULT_I18N_SERVICE = "defaultI18NService";

   /**
    * Documentaci�.
    */
   private Log log = null;

   /**
    * Documentaci�.
    *
    * @param target Documentaci�
    * @param servletRequestDataBinderFactory Documentaci�
    * @param actionSupport Documentaci�
    *
    * @return Documentaci�
    */
   protected ServletRequestDataBinder getBinder(Object target,
      ServletRequestDataBinderFactory servletRequestDataBinderFactory,
      ActionSupport actionSupport) {
      ServletRequestDataBinderFactory customBinderFactory = actionSupport.getRequestDataBinderFactory();
      ServletRequestDataBinder binder = null;

      if (binder == null) {
         // Obtain binder and bind parameters into bean
         if (customBinderFactory != null) {
            binder = customBinderFactory.getInstance(target, "myPojoErrors");
         } else {
            binder = servletRequestDataBinderFactory.getInstance(target,
                  "myPojoErrors");
         }

         if (actionSupport.getCustomMappingEditors() != null) {
            if (log != null) {
               log.info("Adding custom mapping editors...");
            }

            binder.registerCustomMappingEditors(actionSupport.getCustomMappingEditors());
         } else {
            if (log != null) {
               log.info("ActionSupport does not have custom mapping editors!");
            }
         }
      }

      return binder;
   }

   /**
    * Documentaci�.
    *
    * @param uri Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @throws IOException Documentaci�
    * @throws ServletException Documentaci�
    * @throws TagsServiceException Documentaci�
    */
   protected void doForward(String uri, HttpServletRequest request,
      HttpServletResponse response) throws IOException, ServletException {
      try {
         super.doForward(uri, request, response);
      } catch (Exception ex) {
         throw new TagsServiceException(ex, ex.getMessage());
      }
   }

   /**
    * Initialization of attributes defined in Spring context
    */
   protected WebApplicationContext initWebApplicationContext(
      ActionServlet actionServlet, ModuleConfig moduleConfig)
      throws IllegalStateException {
      WebApplicationContext webappContext = super.initWebApplicationContext(actionServlet,
            moduleConfig);

      WebApplicationContext requiredAppContext = WebApplicationContextUtils.getRequiredWebApplicationContext(actionServlet.getServletContext());
      Map map = requiredAppContext.getBeansOfType(LoggingService.class);

      if ((map != null) && (map.size() > 0)) {
         LoggingService logService = (LoggingService) map.get(map.keySet()
                                                                 .iterator()
                                                                 .next());
         this.log = logService.getLog(this.getClass());
         this.log.debug(
            "Initialized log in ExtendedDelegatingTilesRequestProcessor");
      }

      return webappContext;
   }

   /**
    * Proc�s request.
    *
    * @param request HttpServletRequest
    * @param response HttpServletResponse
    * @param action Action
    * @param actionForm ActionForm
    * @param actionMapping ActionMapping
    *
    * @return ActionForward
    *
    * @throws IOException
    * @throws ServletException
    */
   protected ActionForward processActionPerform(
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response, Action action,
      ActionForm actionForm, ActionMapping actionMapping)
      throws java.io.IOException, javax.servlet.ServletException {
      if (action instanceof ActionSupport) {
         this.processActionPerformActionSupport(request, response,
            (ActionSupport) action, actionForm, actionMapping);
      }

      return super.processActionPerform(request, response, action, actionForm,
         actionMapping);
   }

   /**
    * M�tode principal que efectua el proces action (vinculaci� request amb
    * pojoClass, mode del formulari, inicialitzaci� dels tags, ....).
    *
    * @param request
    * @param response
    * @param action
    * @param actionForm
    * @param actionMapping
    * @throws java.io.IOException
    * @throws javax.servlet.ServletException
    */
   protected void processActionPerformActionSupport(
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response, ActionSupport action,
      ActionForm actionForm, ActionMapping actionMapping)
      throws java.io.IOException, javax.servlet.ServletException {
      if (actionForm != null) {
         int currentMode = FormUtils.getFormDisplayMode(request, actionForm);
         request.setAttribute(CURRENT_MODE_REQUEST_ATTRIBUTE,
            new Integer(currentMode));
      }

      // Before of calling obtain information of action
      WebApplicationContext webApplicationContext = getWebApplicationContext();

      // In case of have been defined a pojoClass in action bind into the pojo
      ServletRequestDataBinderFactory servletRequestDataBinderFactory = (ServletRequestDataBinderFactory) webApplicationContext.getBean(SERVLET_REQUEST_DATA_BINDER_FACTORY);
      SpringBindingActionForm form = null;
      Object target = null;

      if ((actionForm != null) &&
            actionForm instanceof SpringBindingActionForm) {
         form = (SpringBindingActionForm) actionForm;
         target = form.getTarget();
      }

      ActionSupport actionSupport = (ActionSupport) action;

      // Put tags Configuration of action in request
      if (actionSupport.getTagsConfiguration() != null) {
         request.setAttribute(ACTION_TAGS_CONFIGURATION,
            actionSupport.getTagsConfiguration());
      } else {
         if (log != null) {
            log.warn("Attribute tagsConfiguration from " +
               actionSupport.getClass().getName() + " is null");
         }
      }

      // Obtain from webApplicationContext the configuration tag to inject other services needed
      ConfigurationTag configurationTag = (ConfigurationTag) webApplicationContext.getBean(CONFIGURATION_TAG);

      if (configurationTag != null) {
         request.setAttribute(CONFIGURATION_TAG, configurationTag);
      } else {
         if (log != null) {
            log.warn("Attribute configurationTag from " +
               actionSupport.getClass().getName() + " is null");
         }
      }

      Class pojoClass = actionSupport.getPojoClass();

      if (target == null) {
         // try to instantiate object 
         //          if(request.getSession().getAttribute("org.apache.struts.taglib.html.SESSION_BEAN") != null){
         //             target = request.getSession().getAttribute("org.apache.struts.taglib.html.SESSION_BEAN");
         //          }else 
         if (pojoClass != null) {
            target = BeanUtils.instantiateClass(pojoClass);
         } else {
            if (log != null) {
               log.warn("pojoClass from " + actionSupport.getClass().getName() +
                  " is null. Cannot instantiate bean");
            }
         }
      }

      if (form != null) {
         // Set pojoClassName into form (to be used by tags)
         if (pojoClass != null) {
            form.setPojoClassName(pojoClass.getName());
         } else {
            if (log != null) {
               log.warn("pojoClass from " + actionSupport.getClass().getName() +
                  " is null. Cannot set pojoClass into ActionForm");
            }
         }
      }

      ServletRequestDataBinder binder = null;

      if (target != null) {
         target = BindingHelper.buildCollections(request.getParameterMap(),
               target);
         binder = getBinder(target, servletRequestDataBinderFactory,
               actionSupport);
         binder.bind(request);
         BindingHelper.removeNullElementsInCollections(request.getParameterMap(),
            target);
      }

      // Req code of request
      String reqCode = null;

      if ((actionMapping.getParameter() != null) &&
            (request.getParameter(actionMapping.getParameter()) != null)) {
         reqCode = request.getParameter(actionMapping.getParameter());
      } else if (actionMapping.getParameter() != null) {
         reqCode = (String) request.getAttribute(actionMapping.getParameter());
      } else {
         if (log != null) {
            log.warn("Cannot resolve reqCode beacuse parameter from " +
               actionSupport.getClass().getName() +
               " ActionMapping has not been set (<action-mapping ... parameter=\"****\"/>)");
         }
      }

      if (reqCode != null) {
         if (actionSupport.getDisplayModeResolver() != null) {
            if (form != null) {
               // Finally set form mode depending on reqCode                           
               FormUtils.setFormDisplayMode(request, actionForm,
                  actionSupport.getDisplayModeResolver().resolveMode(reqCode));
            } else {
               if (log != null) {
                  log.warn("Cannot set form display mode because form is null");
               }
            }
         } else {
            if (log != null) {
               log.warn("Cannot resolve mode beacuse displayModeResolver from " +
                  actionSupport.getClass().getName() + " is null");
            }
         }
      } else {
         if (log != null) {
            log.warn(
               "Cannot resolve mode beacuse reqCode is null (neither parameter nor attribute)");
         }
      }

      if ((form != null) && (binder != null)) {
         //msg-ini
         form.setErrors(binder.getErrors());

         //msg-fi
         // Finally expose errors of binding into request
         if (binder.isWrappedInstanceMutable()) {
            if (this.log != null) {
               //this.log.warn("Object has mutated from "+target+" to "+((BindException)binder.getErrors()).getTransientObject());
            }

            // Para las listas editables
            form.expose(((BindException) binder.getErrors()).getTransientObject());
         } else {
            if (this.log != null) {
               this.log.info("Exposing " + binder.getTarget());
            }

            form.expose(binder.getErrors(), request);
         }

         form.expose(binder.getErrors(), request);
      }
   }

   /**
    * Documentaci�.
    *
    * @param request HttpServletRequest
    * @param response HttpServletResponse
    * @param exception Exception
    * @param form ActionForm
    * @param mapping ActionMapping
    *
    * @return ActionForward
    *
    * @throws IOException
    * @throws ServletException
    */
   protected ActionForward processException(HttpServletRequest request,
      HttpServletResponse response, Exception exception, ActionForm form,
      ActionMapping mapping) throws IOException, ServletException {
      if (this.log != null) {
         this.log.debug("--------------------processException: " +
            exception.getClass().getName() + " ----------------------------");
         this.log.error("Error", exception);
      }

      ActionMessages messages = null;
      ActionForward forward = null;
      String reqCode = null;

      // Obtain reqCode in order to know what method to execute
      if (mapping.getParameter() != null) {
         if (request.getParameter(mapping.getParameter()) != null) {
            reqCode = request.getParameter(mapping.getParameter());
         } else {
            reqCode = (String) request.getAttribute(mapping.getParameter());
         }
      }

      String suffix = ((reqCode != null) && (reqCode.length() > 1))
         ? (reqCode.substring(0, 1).toUpperCase() + reqCode.substring(1)) : "";

      if (exception instanceof WrappedCheckedException) {
         messages = ActionMessagesHelper.buildWrappedCheckedExceptionMessages((WrappedCheckedException) exception);
         request.setAttribute(Globals.ERROR_KEY, messages);
         forward = mapping.findForward("error" + suffix);

         if (forward == null) {
            forward = mapping.findForward("error");
         }
      } else if (exception instanceof SystemException) {
         messages = ActionMessagesHelper.buildSystemExceptionMessages((SystemException) exception);
         request.setAttribute(Globals.ERROR_KEY, messages);
         forward = mapping.findForward("error" + suffix);

         if (forward == null) {
            forward = mapping.findForward("error");
         }
      } else {
         if (this.log != null) {
            this.log.error(exception);
         }

         // since 1.0.1 changed to show root cause
         messages = ActionMessagesHelper.buildExceptionMessages(exception);
         request.setAttribute(Globals.ERROR_KEY, messages);
         forward = mapping.findForward("error" + suffix);

         if (forward == null) {
            forward = mapping.findForward("error");
         }
      }

      Integer lastMode = (Integer) request.getAttribute(CURRENT_MODE_REQUEST_ATTRIBUTE);

      if ((lastMode != null) && (form != null)) {
         FormUtils.setFormDisplayMode(request, form, lastMode.intValue());
      }

      if (forward != null) {
         return forward;
      }

      return super.processException(request, response, exception, form, mapping);
   }

   /**
    * Documentaci�.
    *
    * @param request HttpServletRequest
    * @param response HttpServletResponse
    * @param actionForm ActionForm
    * @param mapping ActionMapping
    *
    * @throws ServletException
    */
   protected void processPopulate(HttpServletRequest request,
      HttpServletResponse response, ActionForm actionForm, ActionMapping mapping)
      throws ServletException {
      if (actionForm instanceof SpringBindingActionForm) {
         return;
      }

      super.processPopulate(request, response, actionForm, mapping);
   }
}
