/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.jsp.JspException;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.i18n.spring.beans.propertyeditors.CustomDateEditor;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.spring.bind.WebDataBinderFactory;
import net.gencat.ctti.canigo.services.web.struts.SpringBindingActionForm;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.util.BasicFieldHelper;
import net.gencat.ctti.canigo.services.web.taglib.FieldTag;
import net.gencat.ctti.canigo.services.web.validation.WebValidationService;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.taglib.TagUtils;


/**
 * <p>Definici� de les propietats del Tag TextFieldTagHelper.</p>
 *
 * @author XES
 *
 * @version Versi� $Revision: 1.6 $ $Date: 2007/07/30 09:16:23 $
 *
 * @since 1.0
 *
 * Revision 1.4  2007/07/16 08:45:51  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]</p>
 *
 * <p>Revision 1.3  2007/05/23 10:47:40  msabates
 * Cap�alera</p>
 *
 * <p>Revision 1.1.1.1.2.1  2007/05/18 10:49:41  fernando.vaquero
 * *** empty log message ***</p>
 *
 * <p>Revision 1.1.1.1  2007/05/15 13:54:08  fernando.vaquero
 * Importacio canigo 2.0</p>
 *
 * <p>Revision 1.2  2007/05/15 10:19:03  msabates
 * Jalopy</p>
 *
 * <p>Revision 1.1  2007/03/28 12:13:27  msabates
 * *** empty log message ***</p>
 *
 * <p>Revision 1.2  2007/03/14 14:44:39  msabates
 * *** empty log message ***</p>
 *
 * <p>Revision 1.1  2007/03/12 11:40:55  msabates
 * Refactor a net.gencat.ctti.canigo</p>
 *
 * <p>Revision 1.1  2007/02/22 15:56:10  msabates
 * *** empty log message ***</p>
 *
 * <p>Revision 1.18  2006/11/16 17:01:18  mmateos
 * author: evidal:</p>
 *
 * <p>Revision 1.18  2006/07/27 12:43:15  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.16  2006/07/26 13:38:26  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.15  2006/07/26 11:16:11  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.14  2006/07/20 14:29:02  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.13  2006/07/18 13:01:47  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.12  2006/07/14 13:38:38  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.11  2006/07/13 14:54:16  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.10  2006/07/12 14:02:41  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.9  2006/07/07 13:46:32  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.8  2006/07/06 16:04:59  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.7  2006/06/30 14:50:27  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.6  2006/06/29 14:23:32  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.5  2006/06/28 13:42:07  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.4  2006/02/23 18:30:44  xescuder
 * XES: Improvements on documentation and using tags
 * properties directly from jsps</p>
 *
 */
public class TextFieldTagHelper {
   /**
    * Nom de la propietat del camp de texte per Autotabulaci� del camp.
    */
   public static final String AUTO_TAB = "autoTab";

   /**
    * Nom de la propietat del camp de texte per definirsi amb el focus es
    * selecciona tot el component.
    */
   public static final String SELECT_ON_FOCUS = "selectOnFocus";

   /**
    * Documentaci�.
    */
   private static final String REQUIRED_ATTRIBUTE = " required";

   /**
    * Afegeix totes les peticions de Ajax en funci� de les propietats
    * del camps de texte.
    *
    * @param aTextFieldTag TextFieldTag
    */
   static void appendBehaviours(TextFieldTag aTextFieldTag) {
      // For all attributes of type 'behaviour' (ajax) add style class
      if (aTextFieldTag.isAutoTab()) {
         aTextFieldTag.setStyleClass(aTextFieldTag.getStyleClass() + " " +
            AUTO_TAB);
      }

      // Get conversions        
      if (aTextFieldTag.getConvertTo() != null) {
         StringTokenizer strToken = new StringTokenizer(aTextFieldTag.getConvertTo(),
               ",");

         // For each specified conversion add to class 
         while (strToken.hasMoreElements()) {
            String conversion = strToken.nextToken();
            aTextFieldTag.setStyleClass((aTextFieldTag.getStyleClass() != null)
               ? aTextFieldTag.getStyleClass() : ("" + " " + conversion));
         }
      }

      // Select on focus behaviour
      if (aTextFieldTag.isSelectOnFocus()) {
         aTextFieldTag.setStyleClass((aTextFieldTag.getStyleClass() != null)
            ? aTextFieldTag.getStyleClass() : ("" + " " + SELECT_ON_FOCUS));
      }
   }

   /**
    * Afegir el script del calendari al codi.
    *
    * @param aTextFieldTag TextFieldTag - Tag on afegir el calendari
    * @param i18NService I18NService - pels textes literals
    * @param validationService ValidationService - Servei de validaci�
    * @throws JspException - excepci� de JSP
    */
   static void appendCalendar(TextFieldTag aTextFieldTag,
      I18nService i18NService, ValidationService validationService)
      throws JspException {
      if (aTextFieldTag.isShowCalendar()) {
         TagUtils tagUtils = TagUtils.getInstance();
         StringBuffer buffer = new StringBuffer();
         buffer.append("<script type=\"text/javascript\">");
         buffer.append("new CanigoTextFieldTag.Calendar({");
         buffer.append("source: \"" + aTextFieldTag.getProperty() + "\"");

         // Obtain datePattern defined in validation of associated bean
         Object bean = aTextFieldTag.getPageContext()
                                    .findAttribute(aTextFieldTag.getName());

         if (bean == null) {
            throw new JspException("No name has been defined of text field tag");
         }

         // Try to get if SpringBindingActionForm is being used
         if (bean instanceof SpringBindingActionForm) {
            SpringBindingActionForm actionForm = (SpringBindingActionForm) bean;

            // Obtain pojoClassName associated to actionForm
            String pojoClassName = actionForm.getPojoClassName();

            if (pojoClassName == null) {
               throw new JspException(
                  "Please configure pojoClassName property for actionForm");
            }

            // If validation service has been configured
            if (validationService != null) {
               String datePattern = validationService.getDatePattern(pojoClassName,
                     aTextFieldTag.getProperty());

               if (datePattern != null) {
                  buffer.append(",datePattern:\"" + datePattern + "\"");
               } else {
                  // try to obtain pattern from customEditor
                  WebValidationService webValidationService = (WebValidationService) validationService;
                  WebDataBinderFactory webDataBinderFactory = webValidationService.getWebDataBinderFactory();

                  if (webDataBinderFactory != null) {
                     Map customEditors = webDataBinderFactory.getCustomEditors();

                     if (customEditors != null) {
                        // Obtain key of 'java.util.Date'
                        Object customEditor = customEditors.get(
                              "java.util.Date");

                        if (customEditor instanceof CustomDateEditor) {
                           CustomDateEditor customDateEditor = (CustomDateEditor) customEditor;
                           Map localeDatePatternsMap = customDateEditor.getLocaleDatePatternsMap();

                           if (localeDatePatternsMap != null) {
                              // Obtain datePattern from current locale of user
                              Locale currentLocale = i18NService.getCurrentLocale();
                              String language = currentLocale.getLanguage();
                              datePattern = (String) localeDatePatternsMap.get(language);

                              if (datePattern != null) {
                                 buffer.append(",datePattern:\"" + datePattern +
                                    "\"");
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         buffer.append("});");
         buffer.append("</script>");

         tagUtils.write(aTextFieldTag.getPageContext(), buffer.toString());
      }
   }

   /**
    * Recollim en un Hashtable els par�metres de tots els camps del formulari.
    *
    * @param aTextFieldTag TextFieldTag
    *
    * @throws JspException - excepci� JSP
    *
    */
   static void getItemsForm(TextFieldTag aTextFieldTag)
      throws JspException {
      TagUtils tagUtils = TagUtils.getInstance();
      StringBuffer buffer = new StringBuffer();
      buffer.append("<script type=\"text/javascript\">");
      buffer.append("itemsForm.put(\"" + aTextFieldTag.getProperty() + "\",\"" +
         aTextFieldTag.getValidationFieldMessageMode() + "\")");

      if ((aTextFieldTag.getSourceErrorTooltip() != null) &&
            !aTextFieldTag.getSourceErrorTooltip().equals("")) {
         buffer.append(";itemsForm.put(\"" + aTextFieldTag.getProperty() +
            "Tooltip" + "\",\"" + aTextFieldTag.getSourceErrorTooltip() +
            "\")");
      }

      if ((aTextFieldTag.getIconStyleId() != null) &&
            !aTextFieldTag.getIconStyleId().equals("")) {
         buffer.append(";itemsForm.put(\"" + aTextFieldTag.getProperty() +
            "Icon" + "\",\"" + aTextFieldTag.getIconStyleId() + "\")");
      }

      if ((aTextFieldTag.getTextErrorStyleId() != null) &&
            !aTextFieldTag.getTextErrorStyleId().equals("")) {
         buffer.append(";itemsForm.put(\"" + aTextFieldTag.getProperty() +
            "Text" + "\",\"" + aTextFieldTag.getTextErrorStyleId() + "\")");
      }

      if ((aTextFieldTag.getErrorClass() != null) &&
            !aTextFieldTag.getErrorClass().equals("")) {
         buffer.append(";itemsForm.put(\"" + aTextFieldTag.getProperty() +
            "errorClass" + "\",\"" + aTextFieldTag.getErrorClass() + "\")");
      }

      buffer.append("</script>");

      tagUtils.write(aTextFieldTag.getPageContext(), buffer.toString());
   }

   /**
    * Recollim en un Hashtable els par�metres de tots els camps del formulari
    * per a la validaci� del submit.
    *
    * @param aTextFieldTag TextFieldTag
    *
    * @throws JspException - excepci� JSP
    *
    */
   static void guardarValidacioSubmit(TextFieldTag aTextFieldTag)
      throws JspException {
      TagUtils tagUtils = TagUtils.getInstance();
      StringBuffer buffer = new StringBuffer();
      buffer.append("<script type=\"text/javascript\">");

      String validacions = null;

      if (aTextFieldTag.getValidations().toUpperCase().indexOf("ONCHANGE") != -1) {
         int ini = aTextFieldTag.getValidations().indexOf("ONSUBMIT");
         int fin = aTextFieldTag.getValidations().length();
         String valOnsubmit = aTextFieldTag.getValidations().substring(ini, fin);
         validacions = valOnsubmit.substring(valOnsubmit.lastIndexOf("(") + 1,
               valOnsubmit.lastIndexOf(")"));
      } else {
         int ini = aTextFieldTag.getValidations().lastIndexOf("(");
         int fin = aTextFieldTag.getValidations().lastIndexOf(")");
         validacions = aTextFieldTag.getValidations().substring(ini + 1, fin);
      }

      if (validacions.indexOf("required") != -1) {
         //BasicFieldHelper.displayRequired(buffer, aTextFieldTag);
         if (aTextFieldTag instanceof FieldTag) {
            FieldTag fieldTag = (FieldTag) aTextFieldTag;
            fieldTag.setStyleClass(((fieldTag.getStyleClass() != null)
               ? fieldTag.getStyleClass() : "") + REQUIRED_ATTRIBUTE);
         }
      }

      buffer.append("itemsSubmit.put(\"" + aTextFieldTag.getProperty() +
         "\",\"" + validacions + "\")");
      buffer.append(";");
      buffer.append("itemsSubmit.put(\"" + aTextFieldTag.getProperty() +
         "DependentFields\",\"" + aTextFieldTag.getDependentFields() + "\")");
      buffer.append(";");
      buffer.append("itemsSubmit.put(\"" + aTextFieldTag.getProperty() +
         "ErrorKey\",\"" + aTextFieldTag.getErrorKey() + "\")");
      buffer.append("</script>");

      tagUtils.write(aTextFieldTag.getPageContext(), buffer.toString());

      String identificadorForm = (String) aTextFieldTag.getPageContext()
                                                       .getRequest()
                                                       .getAttribute("identificadorForm");

      JSONObject par = null;

      if (aTextFieldTag.getPageContext().getSession()
                          .getAttribute(identificadorForm) != null) {
         par = (JSONObject) aTextFieldTag.getPageContext().getSession()
                                         .getAttribute(identificadorForm);

         JSONArray paramsCamps = par.getJSONArray("camps");
         JSONObject p = new JSONObject();
         p.put("nomCamp", aTextFieldTag.getProperty());
         p.put("validacio", validacions);
         p.put("errorKey", aTextFieldTag.getErrorKey());

         if (aTextFieldTag.getDependentFields() != null) {
            p.put("dependentFields", aTextFieldTag.getDependentFields());
         } else {
            p.put("dependentFields", "");
         }

         paramsCamps.put(paramsCamps.length(), p);
      } else {
         par = new JSONObject();

         JSONObject p = new JSONObject();
         p.put("nomCamp", aTextFieldTag.getProperty());
         p.put("validacio", validacions);
         p.put("errorKey", aTextFieldTag.getErrorKey());

         if (aTextFieldTag.getDependentFields() != null) {
            p.put("dependentFields", aTextFieldTag.getDependentFields());
         } else {
            p.put("dependentFields", "");
         }

         par.append("camps", p);
      }

      aTextFieldTag.getPageContext().getSession()
                   .setAttribute(identificadorForm, par);
   }
}
