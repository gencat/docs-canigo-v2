/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.taglib.grid;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class GridBase extends BodyTagSupport {
   /**
    * Documentaci�.
    */
   private String colspan = null;

   /**
    * Documentaci�.
    */
   private String onchange = null;

   /**
    * Documentaci�.
    */
   private String onclick = null;

   /**
    * Documentaci�.
    */
   private String ondblclick = null;

   /**
    * Documentaci�.
    */
   private String onfocus = null;

   /**
    * Documentaci�.
    */
   private String onkeydown = null;

   /**
    * Documentaci�.
    */
   private String onkeypress = null;

   /**
    * Documentaci�.
    */
   private String onkeyup = null;

   /**
    * Documentaci�.
    */
   private String onmousedown = null;

   /**
    * Documentaci�.
    */
   private String onmousemove = null;

   /**
    * Documentaci�.
    */
   private String onmouseout = null;

   /**
    * Documentaci�.
    */
   private String onmouseover = null;

   /**
    * Documentaci�.
    */
   private String onmouseup = null;

   /**
    * Documentaci�.
    */
   private String rowspan = null;

   /**
    * Documentaci�.
    */
   private String style = null;

   /**
    * Documentaci�.
    */
   private String styleClass = null;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getSerializedAttributes() {
      String attributes = "";

      if (styleClass != null) {
         attributes += (" class=\"" + styleClass + "\"");
      }

      if (style != null) {
         attributes += (" style=\"" + style + "\"");
      }

      if (onmouseover != null) {
         attributes += (" onmouseover=\"" + onmouseover + "\"");
      }

      if (onmouseout != null) {
         attributes += (" onmouseout=\"" + onmouseout + "\"");
      }

      if (onchange != null) {
         attributes += (" onchange=\"" + onchange + "\"");
      }

      if (onclick != null) {
         attributes += (" onclick=\"" + onclick + "\"");
      }

      if (ondblclick != null) {
         attributes += (" ondblclick=\"" + ondblclick + "\"");
      }

      if (onfocus != null) {
         attributes += (" onfocus=\"" + onfocus + "\"");
      }

      if (onkeydown != null) {
         attributes += (" onkeydown=\"" + onkeydown + "\"");
      }

      if (onkeyup != null) {
         attributes += (" onkeyup=\"" + onkeyup + "\"");
      }

      if (onmousedown != null) {
         attributes += (" onmousedown=\"" + onmousedown + "\"");
      }

      if (onmousemove != null) {
         attributes += (" onmousemove=\"" + onmousemove + "\"");
      }

      if (onmouseup != null) {
         attributes += (" onmousemoup=\"" + onmouseup + "\"");
      }

      if (onkeypress != null) {
         attributes += (" onkeypress=\"" + onkeypress + "\"");
      }

      return attributes;
   }

   /**
    * Documentaci�.
    *
    * @param className Documentaci�
    */
   public void setStyleClass(String className) {
      if (this.styleClass != null) {
         this.styleClass += (" " + className);
      } else {
         this.styleClass = className;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getStyle() {
      return style;
   }

   /**
    * Documentaci�.
    *
    * @param style Documentaci�
    */
   public void setStyle(String style) {
      if (this.style != null) {
         if (this.style.endsWith(";")) {
            this.style += style;
         } else {
            this.style += (";" + style);
         }
      } else {
         this.style = style;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnmouseout() {
      return onmouseout;
   }

   /**
    * Documentaci�.
    *
    * @param onmouseout Documentaci�
    */
   public void setOnmouseout(String onmouseout) {
      if (this.onmouseout != null) {
         if (this.onmouseout.endsWith(";")) {
            this.onmouseout += onmouseout;
         } else {
            this.onmouseout += (";" + onmouseout);
         }
      } else {
         this.onmouseout = onmouseout;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnmouseover() {
      return onmouseover;
   }

   /**
    * Documentaci�.
    *
    * @param onmouseover Documentaci�
    */
   public void setOnmouseover(String onmouseover) {
      if (this.onmouseover != null) {
         if (this.onmouseover.endsWith(";")) {
            this.onmouseover += onmouseover;
         } else {
            this.onmouseover += (";" + onmouseover);
         }
      } else {
         this.onmouseover = onmouseover;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getColspan() {
      return colspan;
   }

   /**
    * Documentaci�.
    *
    * @param colspan Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public void setColspan(String colspan) throws JspException {
      this.colspan = colspan;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getRowspan() {
      return rowspan;
   }

   /**
    * Documentaci�.
    *
    * @param rowspan Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public void setRowspan(String rowspan) throws JspException {
      this.rowspan = rowspan;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnchange() {
      return onchange;
   }

   /**
    * Documentaci�.
    *
    * @param onchange Documentaci�
    */
   public void setOnchange(String onchange) {
      if (this.onchange != null) {
         if (this.onchange.endsWith(";")) {
            this.onchange += onchange;
         } else {
            this.onchange += (";" + onchange);
         }
      } else {
         this.onchange = onchange;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnclick() {
      return onclick;
   }

   /**
    * Documentaci�.
    *
    * @param onclick Documentaci�
    */
   public void setOnclick(String onclick) {
      if (this.onclick != null) {
         if (this.onclick.endsWith(";")) {
            this.onclick += onclick;
         } else {
            this.onclick += (";" + onclick);
         }
      } else {
         this.onclick = onclick;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOndblclick() {
      return ondblclick;
   }

   /**
    * Documentaci�.
    *
    * @param ondblclick Documentaci�
    */
   public void setOndblclick(String ondblclick) {
      if (this.ondblclick != null) {
         if (this.ondblclick.endsWith(";")) {
            this.ondblclick += ondblclick;
         } else {
            this.ondblclick += (";" + ondblclick);
         }
      } else {
         this.ondblclick = ondblclick;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnfocus() {
      return onfocus;
   }

   /**
    * Documentaci�.
    *
    * @param onfocus Documentaci�
    */
   public void setOnfocus(String onfocus) {
      if (this.onfocus != null) {
         if (this.onfocus.endsWith(";")) {
            this.onfocus += onfocus;
         } else {
            this.onfocus += (";" + onfocus);
         }
      } else {
         this.onfocus = onfocus;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnkeydown() {
      return onkeydown;
   }

   /**
    * Documentaci�.
    *
    * @param onkeydown Documentaci�
    */
   public void setOnkeydown(String onkeydown) {
      if (this.onkeydown != null) {
         if (this.onkeydown.endsWith(";")) {
            this.onkeydown += onkeydown;
         } else {
            this.onkeydown += (";" + onkeydown);
         }
      } else {
         this.onkeydown = onkeydown;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnkeypress() {
      return onkeypress;
   }

   /**
    * Documentaci�.
    *
    * @param onkeypress Documentaci�
    */
   public void setOnkeypress(String onkeypress) {
      if (this.onkeypress != null) {
         if (this.onkeypress.endsWith(";")) {
            this.onkeypress += onkeypress;
         } else {
            this.onkeypress += (";" + onkeypress);
         }
      } else {
         this.onkeypress = onkeypress;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnkeyup() {
      return onkeyup;
   }

   /**
    * Documentaci�.
    *
    * @param onkeyup Documentaci�
    */
   public void setOnkeyup(String onkeyup) {
      if (this.onkeyup != null) {
         if (this.onkeyup.endsWith(";")) {
            this.onkeyup += onkeyup;
         } else {
            this.onkeyup += (";" + onkeyup);
         }
      } else {
         this.onkeyup = onkeyup;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnmousedown() {
      return onmousedown;
   }

   /**
    * Documentaci�.
    *
    * @param onmousedown Documentaci�
    */
   public void setOnmousedown(String onmousedown) {
      if (this.onmousedown != null) {
         if (this.onmousedown.endsWith(";")) {
            this.onmousedown += onmousedown;
         } else {
            this.onmousedown += (";" + onmousedown);
         }
      } else {
         this.onmousedown = onmousedown;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnmouseup() {
      return onmouseup;
   }

   /**
    * Documentaci�.
    *
    * @param onmouseup Documentaci�
    */
   public void setOnmouseup(String onmouseup) {
      if (this.onmouseup != null) {
         if (this.onmouseup.endsWith(";")) {
            this.onmouseup += onmouseup;
         } else {
            this.onmouseup += (";" + onmouseup);
         }
      } else {
         this.onmouseup = onmouseup;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnmousemove() {
      return onmousemove;
   }

   /**
    * Documentaci�.
    *
    * @param onmousemove Documentaci�
    */
   public void setOnmousemove(String onmousemove) {
      if (this.onmousemove != null) {
         if (this.onmousemove.endsWith(";")) {
            this.onmousemove += onmousemove;
         } else {
            this.onmousemove += (";" + onmousemove);
         }
      } else {
         this.onmousemove = onmousemove;
      }
   }

   /**
    * Documentaci�.
    */
   public void release() {
      this.style = null;

      this.colspan = null;

      this.rowspan = null;

      this.styleClass = null;

      this.onchange = null;

      this.onclick = null;

      this.ondblclick = null;

      this.onfocus = null;

      this.onkeydown = null;

      this.onkeyup = null;

      this.onmousedown = null;

      this.onmousemove = null;

      this.onmouseup = null;

      this.onmouseover = null;

      this.onmouseout = null;

      this.onkeypress = null;

      super.release();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getStyleClass() {
      return styleClass;
   }
}
