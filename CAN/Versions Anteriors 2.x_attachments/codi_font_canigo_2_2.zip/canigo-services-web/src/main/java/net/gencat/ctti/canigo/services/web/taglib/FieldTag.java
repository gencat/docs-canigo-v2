/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.taglib;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.validation.ValidationService;


/**
 * <p>Interface per definir FieldTag.</p>
 *
 * @author XES
 * @version $Revision: 1.5 $ $Date: 2007/07/27 09:32:08 $
 *
 * @since 1.0
 *
 * <p>Revision 1.4  2007/07/16 08:45:51  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]</p>
 *
 * <p>Revision 1.3  2007/05/23 10:47:40  msabates
 * Cap�alera</p>
 *
 * <p>Revision 1.1.1.1.2.1  2007/05/18 10:49:39  fernando.vaquero
 * *** empty log message ***</p>
 *
 * <p>Revision 1.1.1.1  2007/05/15 13:54:08  fernando.vaquero
 * Importacio canigo 2.0</p>
 *
 * <p>Revision 1.2  2007/05/15 10:19:03  msabates
 * Jalopy</p>
 *
 * <p>Revision 1.1  2007/03/28 12:12:57  msabates
 * *** empty log message ***</p>
 *
 * <p>Revision 1.2  2007/03/14 14:44:39  msabates
 * *** empty log message ***</p>
 *
 * <p>Revision 1.1  2007/03/12 11:40:55  msabates
 * Refactor a net.gencat.ctti.canigo</p>
 *
 * <p>Revision 1.1  2007/02/22 15:56:10  msabates
 * *** empty log message ***</p>
 *
 * <p>Revision 1.8  2006/11/16 17:09:24  mmateos
 * author: xescuder: XES: Added behaviour to set properties
 * from jsp in adition of configuration files</p>
 *
 * <p>Revision 1.8  2006/02/24 13:54:19  xescuder
 * XES: Added behaviour to set properties from jsp in
 * adition of configuration files</p>
 *
 */
public interface FieldTag extends Tag {
   /**
    * Classe per establir quan hi ha un error.
    *
    * @return String
    */
   public String getErrorStyleClass();

   /**
    * Classe per establir quan hi ha un error.
    *
    * @param errorStyleClass String
    */
   public void setErrorStyleClass(String errorStyleClass);

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getAccept();

   /**
    * Documentaci�.
    *
    * @param accept String
    */
   public void setAccept(String accept);

   /**
    * Permet fer �s d'acc�s per teclat al component.
    *
    * @return String
    */
   public String getAccesskey();

   /**
    * Permet fer �s d'acc�s per teclat al component.
    *
    * @param accesskey String
    */
   public void setAccesskey(String accesskey);

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getBundle();

   /**
    * Documentaci�.
    *
    * @param bundle String
    */
   public void setBundle(String bundle);

   /**
    * N�mero de columnes.
    *
    * @return String
    */
   public String getCols();

   /**
    * N�mero de columnes.
    *
    * @param cols String
    */
   public void setCols(String cols);

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getHint();

   /**
    * Documentaci�.
    *
    * @param hint String
    */
   public void setHint(String hint);

   /**
    * Refer�ncia al servei d'internalitzaci�.
    *
    * @return I18nService
    */
   public I18nService getI18nService();

   /**
    * Refer�ncia al servei d'internalitzaci�.
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service);

   /**
    * Refer�ncia al servei de Validaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService();

   /**
    * Refer�ncia al servei de Validaci�.
    *
    * @param service ValidationService
    */
   public void setValidationService(ValidationService service);

   /**
    * Mostra el camp com obligatori.
    *
    * @return boolean
    */
   public boolean isRequired();

   /**
    * Mostra el camp com obligatori.
    *
    * @param isRequired boolean
    */
   public void setRequired(boolean isRequired);

   /**
    * Clau del component.
    *
    * @return String
    */
   public String getKey();

   /**
    * Clau del component.
    *
    * @param key String
    */
   public void setKey(String key);

   /**
    * Clau del estil.
    *
    * @return String
    */
   public String getKeyStyleClass();

   /**
    * Clau del estil.
    *
    * @param keyStyleClass String
    */
   public void setKeyStyleClass(String keyStyleClass);

   /**
    * Permet definir si volem generar o no el layout pel formulari.
    * Per defecte, el tag crea un <table> que agrupar� els components
    * input interns. Aquests components interns generaran '<tr>'<td>'
    * de forma autom�tica.
    *
    * @return boolean
    */
   public boolean isLayout();

   /**
    * Permet definir si volem generar o no el layout pel formulari.
    * Per defecte, el tag crea un <table> que agrupar� els components
    * input interns. Aquests components interns generaran '<tr>'<td>'
    * de forma autom�tica.
    *
    * @param layout boolean - True, si es vol layout
    */
   public void setLayout(boolean layout);

   /**
    * Tamany m�xim del camp.
    *
    * @return String
    */
   public String getMaxlength();

   /**
    * Tamany m�xim del camp.
    *
    * @param maxlength String
    */
   public void setMaxlength(String maxlength);

   /**
    * Mode de visualitzaci� del component.
    *
    * @return String
    */
   public String getMode();

   /**
    * Mode de visualitzaci� del component .
    *
    * @param mode String
    */
   public void setMode(String mode);

   /**
    * Valor que se li dona al name en la JSP.
    *
    * @return String
    */
   public String getName();

   /**
    * Valor que se li dona al name en la JSP.
    *
    * @param name String
    */
   public void setName(String name);

   /**
    * Event onBlur.
    *
    * @return String
    */
   public String getOnblur();

   /**
    * Event onBlur.
    *
    * @param onblur String
    */
   public void setOnblur(String onblur);

   /**
    * Event que produeix l'acci� Change.
    *
    * @return String
    */
   public String getOnchange();

   /**
    * Event que produeix l'acci� Change.
    *
    * @param onchange String
    */
   public void setOnchange(String onchange);

   /**
    * Event que produeix l'acci� Click.
    *
    * @return String
    */
   public String getOnclick();

   /**
    * Event que produeix l'acci� Click.
    *
    * @param onclick String
    */
   public void setOnclick(String onclick);

   /**
    * Event que produeix l'acci� Click.
    *
    * @return String
    */
   public String getOndblclick();

   /**
    * Event que produeix l'acci� Double Click.
    *
    * @param ondblclick String
    */
   public void setOndblclick(String ondblclick);

   /**
    * Event que produeix l'acci� Focus.
    *
    * @return String
    */
   public String getOnfocus();

   /**
    * Event que produeix l'acci� Focus.
    *
    * @param onfocus String
    */
   public void setOnfocus(String onfocus);

   /**
    * Event que produeix l'acci� Key Down.
    *
    * @return String
    */
   public String getOnkeydown();

   /**
    * Event que produeix l'acci� Key Down.
    *
    * @param onkeydown String
    */
   public void setOnkeydown(String onkeydown);

   /**
    * Event que produeix l'acci� Key Press.
    *
    * @return String
    */
   public String getOnkeypress();

   /**
    * Event que produeix l'acci� Key Press.
    *
    * @param onkeypress String
    */
   public void setOnkeypress(String onkeypress);

   /**
    * Event que produeix l'acci� Key Up.
    *
    * @return String
    */
   public String getOnkeyup();

   /**
    * Event que produeix l'acci� Key Up.
    *
    * @param onkeyup String
    */
   public void setOnkeyup(String onkeyup);

   /**
    * Event que produeix l'acci� Mouse Down.
    *
    * @return String
    */
   public String getOnmousedown();

   /**
    * Event que produeix l'acci� Mouse Down.
    *
    * @param onmousedown String
    */
   public void setOnmousedown(String onmousedown);

   /**
    * Event que produeix l'acci� Mouse Move.
    *
    * @return String
    */
   public String getOnmousemove();

   /**
    * Event que produeix l'acci� Mouse Move.
    *
    * @param onmousemove String
    */
   public void setOnmousemove(String onmousemove);

   /**
    * Event que produeix l'acci� Mouse Out.
    *
    * @return String
    */
   public String getOnmouseout();

   /**
    * Event que produeix l'acci� Mouse Out.
    *
    * @param onmouseout String
    */
   public void setOnmouseout(String onmouseout);

   /**
    * Event que produeix l'acci� Mouse Over.
    *
    * @return String
    */
   public String getOnmouseover();

   /**
    * Event que produeix l'acci� Mouse Over.
    *
    * @param onmouseover String
    */
   public void setOnmouseover(String onmouseover);

   /**
    * Event que produeix l'acci� Mouse Up.
    *
    * @return String
    */
   public String getOnmouseup();

   /**
    * Event que produeix l'acci� Mouse Up.
    *
    * @param onmouseup String
    */
   public void setOnmouseup(String onmouseup);

   /**
    * Event que produeix l'acci� Select.
    *
    * @return String
    */
   public String getOnselect();

   /**
    * Event que produeix l'acci� Mouse Select.
    *
    * @param onselect String
    */
   public void setOnselect(String onselect);

   /**
    * Nom del component.
    *
    * @return String
    */
   public String getProperty();

   /**
    * Nom del component.
    *
    * @param property String
    */
   public void setProperty(String property);

   /**
    * Numero de files.
    *
    * @return String
    */
   public String getRows();

   /**
    * Numero de files.
    *
    * @param rows String
    */
   public void setRows(String rows);

   /**
    * Tamany del component.
    *
    * @return String
    */
   public String getSize();

   /**
    * Tamany del component.
    *
    * @param size String
    */
   public void setSize(String size);

   /**
    * Estil del component.
    *
    * @return String
    */
   public String getStyle();

   /**
    * Estil del component.
    *
    * @param style String
    */
   public void setStyle(String style);

   /**
    * Classe Css que utilitzar� el component.
    *
    * @return String
    */
   public String getStyleClass();

   /**
    * Classe Css que utilitzar� el component.
    *
    * @param styleClass String
    */
   public void setStyleClass(String styleClass);

   /**
    * �ndex de tabulaci�.
    *
    * @return String
    */
   public String getTabIndex();

   /**
    * �ndex de tabulaci�.
    *
    * @param tabIndex String
    */
   public void setTabIndex(String tabIndex);

   /**
    * Clau del literal del missatge a mostrar dins el tooltip.
    *
    * @return String
    */
   public String getTooltipKey();

   /**
    * Clau del literal del missatge a mostrar dins el tooltip.
    *
    * @param tooltipMessageKey String
    */
   public void setTooltipKey(String tooltipMessageKey);

   /**
    * Opcions aplicades segons la implementaci� (en el cas actual sota DOM
    * Tooltip).
    *
    * @return String
    */
   public String getTooltipOptions();

   /**
    * Opcions aplicades segons la implementaci� (en el cas actual sota DOM
    * Tooltip).
    *
    * @param tooltipOptions String
    */
   public void setTooltipOptions(String tooltipOptions);

   /**
    * Clau del literal a mostrar si volem mostrar un t�tol com a cap�alera del
    * tooltip.
    *
    * @return String
    */
   public String getTooltipTitleKey();

   /**
    * Clau del literal a mostrar si volem mostrar un t�tol com a cap�alera del
    * tooltip.
    *
    * @param tooltipTitleKey String
    */
   public void setTooltipTitleKey(String tooltipTitleKey);

   /**
    * Valor introduit al component.
    *
    * @return String
    */
   public String getValue();

   /**
    * Valor introduit al component.
    *
    * @param value String
    */
   public void setValue(String value);

   /**
    * Documentaci�.
    *
    * @param display boolean
    */
   public void setFieldErrorDisplayed(boolean display);

   /**
    * Documentaci�.
    *
    * @return boolean
    */
   public boolean isFieldErrorDisplayed();
}
