/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.taglib;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.DWRHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.ServicesTagHelper;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;

import org.apache.struts.taglib.TagUtils;


/**
 * <p>Definici� de les propietats del Tag DirtyFormWarningTag.</p>
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class DirtyFormWarningTag extends TagSupport implements Tag {
   /**
    *
    */
   private static final long serialVersionUID = 1L;

   /**
        * Imported scripts flag.
        */
   private static final String DIRTY_FORM_WARNING_IMPORTED_SCRIPTS = "__dirty_form_warning_imported_scripts__";

   /**
   * I18nService
   */
   private I18nService i18nService;

   /**
    * LogginService
    */
   private LoggingService logService;

   /**
    * Documentaci�.
    */
   private String message;

   /**
    * Documentaci�.
    */
   private String messageKey;

   /**
    * Documentaci�.
    */
   private String source;

   /**
    * Documentaci�.
    */
   private String styleId;

   /**
    * ValidationService
    */
   private ValidationService validationService;

   /**
    * Crea un nou Objecte del tipus DirtyFormWarningTag.
    */
   public DirtyFormWarningTag() {
      super();
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doStartTag() throws JspException {
      // EVC: import tag scripts if not imported yet.
      HttpServletRequest request = (HttpServletRequest) super.pageContext.getRequest();
      HttpServletResponse response = (HttpServletResponse) super.pageContext.getResponse();

      if ((request.getAttribute(DIRTY_FORM_WARNING_IMPORTED_SCRIPTS) == null)) {
         request.setAttribute(DIRTY_FORM_WARNING_IMPORTED_SCRIPTS,
            Constants.IMPORTED);

         TagUtils tagUtils = TagUtils.getInstance();
         tagUtils.write(super.pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() +
            response.encodeURL("/scripts/dojo/canigo-dirtyFormWarning-tag.js") +
            "\"></script>");
         tagUtils.write(super.pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() +
            response.encodeURL("/scripts/dojo/dojo.js") + "\"></script>");
         tagUtils.write(super.pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() +
            response.encodeURL("/scripts/dojo/io.js") + "\"></script>\n");
      }

      TagUtils tagUtils = TagUtils.getInstance();
      TagUtil.copyConfiguration(this);

      StringBuffer buffer = new StringBuffer();

      if (this.getLogService() != null) {
         this.getLogService().getLog(this.getClass())
             .debug("Begin doStartTag(" + this.getSource() +
            " of DirtyFormWarningTag...");
      }

      buffer.append("<script type=\"text/javascript\">");
      buffer.append("new CanigoDirtyFormWarningTag.DirtyForm({");
      buffer.append("source:\"" + this.getSource() + "\"");

      if ((this.getMessageKey() != null) && (this.getMessage() != null)) {
         throw new JspException("Source: " + this.getSource() +
            ".You only can inform one of this atributs : message or messageKey");
      }

      if (this.getMessageKey() != null) {
         I18nService tmpI18nService = this.getI18nService();

         if (tmpI18nService == null) {
            throw new JspException("Source: " + this.getSource() +
               ".The i18nService is null. You must define the i18nService attribut or check the styleId");
         }

         Locale locale = tmpI18nService.getCurrentLocale();
         String msgKey = i18nService.getMessage(this.getMessageKey(), locale);
         buffer.append(",");
         buffer.append("message:\"" + msgKey + "\"");
      } else {
         if (this.getMessage() != null) {
            buffer.append(",");
            buffer.append("message:\"" + this.getMessage() + "\"");
         } else {
            throw new JspException("Source: " + this.getSource() +
               ".You should specify at least one of the attributes message or messageKey");
         }
      }

      buffer.append("});");
      buffer.append("</script>");

      tagUtils.write(this.getPageContext(), buffer.toString());

      if (this.getLogService() != null) {
         this.getLogService().getLog(this.getClass())
             .debug("End doStartTag(" + this.getSource() +
            " of DirtyFormWarningTag...");
      }

      //return SKIP_BODY;
      return EVAL_BODY_INCLUDE;
   }

   /**
    * Fi de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doEndTag() throws JspException {
      super.doEndTag();

      return EVAL_PAGE;
   }

   /**
    * Id del formulari que �s vol escoltar dels canvis..
    *
    * @return String
    */
   public String getSource() {
      return source;
   }

   /**
    * Id del formulari que �s vol escoltar dels canvis..
    *
    * @param source String
    */
   public void setSource(String source) {
      this.source = source;
   }

   /**
    * Documentaci�.
    *
    * @return PageContext
    */
   public PageContext getPageContext() {
      return pageContext;
   }

   /**
    * Text del missatge a mostrar.
    *
    * @return String
    */
   public String getMessage() {
      return message;
   }

   /**
    * Text del missatge a mostrar.
    *
    * @param message String
    */
   public void setMessage(String message) {
      this.message = message;
   }

   /**
    * Clau internacionalitzada del missatge.
    *
    * @return String
    */
   public String getMessageKey() {
      return messageKey;
   }

   /**
    * Clau internacionalitzada del missatge.
    *
    * @param messageKey String
    */
   public void setMessageKey(String messageKey) {
      this.messageKey = messageKey;
   }

   /**
    * Refer�ncia al servei d'intenalitzaci�.
    *
    * @return I18nService
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Refer�ncia al servei d'intenalitzaci�.
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Identificador per lligar amb configuraci� XML.
    *
    * @return String
    */
   public String getStyleId() {
      return styleId;
   }

   /**
    * Identificador per lligar amb configuraci� XML.
    *
    * @param styleId String
    */
   public void setStyleId(String styleId) {
      this.styleId = styleId;
   }

   /**
    * Refer�ncia al servei de log.
    *
    * @return LoggingService
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * Refer�ncia al servei de log.
    *
    * @param logService LoggingService
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * Refer�ncia al servei de validacions.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Refer�ncia al servei de validacions.
    *
    * @param validationService ValidationService
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * Permet injectar serveis del contenidor d' spring.
    *
    * @param services String
    *
    * @throws JspException
    */
   public void setServices(String services) throws JspException {
      ServicesTagHelper.setServices(services, pageContext, this);
   }
}
