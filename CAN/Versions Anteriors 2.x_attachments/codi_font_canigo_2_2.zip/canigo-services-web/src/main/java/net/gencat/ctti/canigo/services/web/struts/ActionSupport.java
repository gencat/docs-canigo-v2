/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.web.spring.ServletRequestDynamicDataBinder;
import net.gencat.ctti.canigo.services.web.spring.bind.ServletRequestDataBinderFactory;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


/**
 * $Id: ActionSupport.java,v 1.4 2007/07/16 08:45:50 msabates Exp $
 * Extension of ActionSupport of Spring Struts.
 * @author XES
 * @version $Revision: 1.4 $ $Date: 2007/07/16 08:45:50 $
 *
 * @since 1.0
 * $Log: ActionSupport.java,v $
 * Revision 1.4  2007/07/16 08:45:50  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]
 *
 * Revision 1.3  2007/05/23 10:47:39  msabates
 * Cap�alera
 *
 * Revision 1.1.1.1.2.1  2007/05/18 10:49:34  fernando.vaquero
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2007/05/15 13:53:40  fernando.vaquero
 * Importacio canigo 2.0
 *
 * Revision 1.2  2007/05/15 10:19:03  msabates
 * Jalopy
 *
 * Revision 1.1  2007/03/28 12:13:27  msabates
 * *** empty log message ***
 *
 * Revision 1.2  2007/03/14 14:44:39  msabates
 * *** empty log message ***
 *
 * Revision 1.1  2007/03/12 11:40:54  msabates
 * Refactor a net.gencat.ctti.canigo
 *
 * Revision 1.1  2007/02/22 15:56:10  msabates
 * *** empty log message ***
 *
 * Revision 1.5  2006/11/16 16:41:53  mmateos
 * author: crico: version 1.1 no estable
 *
 * Revision 1.5  2006/09/19 16:41:56  crico
 * version 1.1 no estable
 *
 * Revision 1.3.2.1  2006/03/21 11:02:24  ecollell
 * ECG: maintenance multi-row
 *
 * Revision 1.3  2006/02/24 13:52:12  xescuder
 * *** empty log message ***
 *
 */
public abstract class ActionSupport extends org.springframework.web.struts.ActionSupport
   implements net.gencat.ctti.canigo.services.web.struts.action.ActionSupport {
   /**
    * Documentaci�.
    */
   protected LoggingService logService = null;

   /**
    * Documentaci�.
    */
   private java.util.List fileUploadNames;

   /**
    * The pojo class to be used
    */
   private Class pojoClass;

   /**
    * Documentaci�.
    */
   private FormDisplayResolver displayModeResolver = new DefaultFormDisplayResolver();

   /**
    * Documentaci�.
    */
   private Map additionalFieldNames;

   /**
    * Documentaci�.
    */
   private Map customMappingEditors;

   /**
    * The list of configuration of tags used in page of action
    */
   private Map tagsConfiguration;

   /**
    * Documentaci�.
    */
   private ServletRequestDataBinderFactory requestDataBinderFactory;

   /**
    * Documentaci�.
    */
   private ServletRequestDynamicDataBinder additionalFieldNamesBinder;

   /**
    * Documentaci�.
    */
   private ServletRequestDynamicDataBinder fileUploadBinder;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Class getPojoClass() {
      return pojoClass;
   }

   /**
    * Documentaci�.
    *
    * @param pojoClass Documentaci�
    */
   public void setPojoClass(Class pojoClass) {
      this.pojoClass = pojoClass;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public FormDisplayResolver getDisplayModeResolver() {
      return displayModeResolver;
   }

   /**
    * Documentaci�.
    *
    * @param displayModeResolver Documentaci�
    */
   public void setDisplayModeResolver(FormDisplayResolver displayModeResolver) {
      this.displayModeResolver = displayModeResolver;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getTagsConfiguration() {
      return tagsConfiguration;
   }

   /**
    * Documentaci�.
    *
    * @param tagsConfiguration Documentaci�
    */
   public void setTagsConfiguration(Map tagsConfiguration) {
      this.tagsConfiguration = tagsConfiguration;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List getFileUploadNames() {
      return fileUploadNames;
   }

   /**
    * Documentaci�.
    *
    * @param fileUploadnames Documentaci�
    */
   public void setFileUploadNames(List fileUploadnames) {
      this.fileUploadNames = fileUploadnames;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getAdditionalFieldNames() {
      return additionalFieldNames;
   }

   /**
    * Documentaci�.
    *
    * @param additionalFieldNames Documentaci�
    */
   public void setAdditionalFieldNames(Map additionalFieldNames) {
      this.additionalFieldNames = additionalFieldNames;
   }

   /**
    * @return Returns the logService.
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * @param logService
    *            The logService to set.
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ServletRequestDynamicDataBinder getAdditionalFieldNamesBinder() {
      return additionalFieldNamesBinder;
   }

   /**
    * Documentaci�.
    *
    * @param additionalFieldNamesBinder Documentaci�
    */
   public void setAdditionalFieldNamesBinder(
      ServletRequestDynamicDataBinder additionalFieldNamesBinder) {
      this.additionalFieldNamesBinder = additionalFieldNamesBinder;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ServletRequestDynamicDataBinder getFileUploadBinder() {
      return fileUploadBinder;
   }

   /**
    * Documentaci�.
    *
    * @param fileUploadBinder Documentaci�
    */
   public void setFileUploadBinder(
      ServletRequestDynamicDataBinder fileUploadBinder) {
      this.fileUploadBinder = fileUploadBinder;
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    * @param arg2 Documentaci�
    * @param arg3 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public abstract ActionForward execute(ActionMapping arg0, ActionForm arg1,
      HttpServletRequest arg2, HttpServletResponse arg3)
      throws Exception;

   /**
    * @return Returns the customMappingEditors.
    */
   public Map getCustomMappingEditors() {
      return customMappingEditors;
   }

   /**
    * @param customMappingEditors The customMappingEditors to set.
    */
   public void setCustomMappingEditors(Map customMappingEditors) {
      this.customMappingEditors = customMappingEditors;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ServletRequestDataBinderFactory getRequestDataBinderFactory() {
      return requestDataBinderFactory;
   }

   /**
    * Documentaci�.
    *
    * @param requestDataBinderFactory Documentaci�
    */
   public void setRequestDataBinderFactory(
      ServletRequestDataBinderFactory requestDataBinderFactory) {
      this.requestDataBinderFactory = requestDataBinderFactory;
   }
}
