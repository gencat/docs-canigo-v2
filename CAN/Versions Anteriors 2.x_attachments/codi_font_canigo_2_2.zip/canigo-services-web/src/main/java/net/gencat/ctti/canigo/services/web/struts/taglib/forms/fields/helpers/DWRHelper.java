/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;

import fr.improve.struts.taglib.layout.util.LayoutUtils;

import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.OptionsFieldTag;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.SelectFieldTag;
import net.gencat.ctti.canigo.services.web.taglib.Constants;

import org.apache.struts.taglib.TagUtils;


/**
 * Helper de Select Field Tag.
 * @author XES
 * @version $Revision: 1.5 $ $Date: 2007/07/30 09:16:23 $
 *
 * @see
 * @since 1.0
 * $Log: DWRHelper.java,v $
 * Revision 1.5  2007/07/30 09:16:23  cbernal
 * Revisi� Javadoc
 *
 * Revision 1.4  2007/07/16 08:45:52  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]
 *
 * Revision 1.3  2007/05/23 10:47:40  msabates
 * Cap�alera
 *
 * Revision 1.1.1.1.2.1  2007/05/18 10:49:47  fernando.vaquero
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2007/05/15 13:54:08  fernando.vaquero
 * Importacio canigo 2.0
 *
 * Revision 1.2  2007/05/15 10:19:03  msabates
 * Jalopy
 *
 * Revision 1.1  2007/03/28 12:13:00  msabates
 * *** empty log message ***
 *
 * Revision 1.2  2007/03/14 14:44:39  msabates
 * *** empty log message ***
 *
 * Revision 1.1  2007/03/12 11:40:55  msabates
 * Refactor a net.gencat.ctti.canigo
 *
 * Revision 1.1  2007/02/22 15:56:11  msabates
 * *** empty log message ***
 *
 * Revision 1.2  2007/02/12 11:46:11  evidal
 * EVC: added version 1.2 changes.
 *
 * Revision 1.1.2.1  2007/02/07 19:34:08  evidal
 * EVC: version 1.2 -> autoimported scripts.
 *
 * Revision 1.8  2006/11/16 17:01:52  mmateos
 * author: crico: version 1.1 no estable
 *
 * Revision 1.8  2006/09/19 16:41:56  crico
 * version 1.1 no estable
 *
 * Revision 1.6.2.4  2006/06/30 08:58:03  evidal
 * *** empty log message ***
 *
 * Revision 1.7  2006/06/19 14:22:02  evidal
 * versio de partida del 20%
 *
 * Revision 1.6.2.3  2006/05/25 11:04:44  evidal
 * EVC: arreglat el bug del select tag en mode inspect.
 *
 * Revision 1.6.2.2  2006/03/06 11:42:20  mmateos
 * MMR: corregido un bug de binding en los CustomNumberEditor
 *
 * Revision 1.6.2.1  2006/03/01 10:01:47  xescuder
 * *** empty log message ***
 *
 * Revision 1.6  2006/02/24 13:54:03  xescuder
 * XES: Checked format of fields on properties
 *
 */
public class DWRHelper {
   /**
    * Documentaci�.
    */
   private static final String DWR_ENGINE_IMPORTED_SCRIPT = "__dwr_engine_imported_scripts__";

   /**
    * Importa DWR engine.js si no ha sigut importat.
    * @param pageContext PageContext
    * @throws JspException
    */
   public static void generateDWREngineScript(PageContext pageContext)
      throws JspException {
      // EVC: import scripts if not imported yet.
      HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
      HttpServletResponse response = (HttpServletResponse) pageContext.getResponse();

      if ((request.getAttribute(DWR_ENGINE_IMPORTED_SCRIPT) == null)) {
         request.setAttribute(DWR_ENGINE_IMPORTED_SCRIPT, Constants.IMPORTED);

         TagUtils tagUtils = TagUtils.getInstance();
         tagUtils.write(pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() + response.encodeURL("/dwr/engine.js") +
            "\"></script>\n");
      }
   }
}
