/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields;

import java.io.IOException;

import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;

import fr.improve.struts.taglib.layout.field.SelectTag;
import fr.improve.struts.taglib.layout.util.LayoutUtils;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.DWRHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.ServicesTagHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.util.BasicFieldHelper;
import net.gencat.ctti.canigo.services.web.taglib.Constants;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;
import net.gencat.ctti.canigo.services.web.taglib.util.options.OptionsListService;

import org.ajaxtags.tags.OptionsBuilder;
import org.apache.struts.taglib.TagUtils;
import org.apache.struts.util.ResponseUtils;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;


/**
 * <p>Definici� de les propietats del Tag PagedSelectFieldTag.</p>
 *
 * @author
 * @version $Revision: 1.5 $
  */
public class PagedSelectFieldTag extends SelectTag implements net.gencat.ctti.canigo.services.web.taglib.SelectFieldTag {
   /**
    * Serial version uid
    */
   private static final long serialVersionUID = -6146008493834447620L;

   /**
        * Imported scripts flag.
        */
   private static final String PAGED_SELECT_IMPORTED_SCRIPTS = "__paged_select_imported_scripts__";

   /**
    * I18nService
    */
   private I18nService i18nService;

   /**
    * For use in select dependencies
    */
   private Object selectFieldSourceProperties = new Object();

   /**
    * OptionsListService. Service to obtain options from database or
    * other source
    */
   private OptionsListService optionsListService;

   /**
    * For use in select dependencies
    */
   private Properties selectFieldSource = new Properties();

   /**
    * Documentaci�.
    */
   private String dependentFields;

   //private String parameters;
   /**
    * Documentaci�.
    */
   private String indicator;

   /**
    * Style class defined for key of field
    */
   private String keyStyleClass = null;

   //private String queryParameter;
   /**
    * Documentaci�.
    */
   private String numberRowsPerPage;

   /**
    * Documentaci�.
    */
   private String optionsListName;

   /**
    * Key of option that will be added as first option in addition
    * of list of values retrieved
    */
   private String otherKey = null;

   /**
    * Value to send as first option
    */
   private String otherValue = null;

   /**
    * Documentaci�.
    */
   private String popupId;

   /**
    * Documentaci�.
    */
   private String queryParameters;

   /**
    * Documentaci�.
    */
   private String selectedKey;

   /**
    * Documentaci�.
    */
   private String selectedValue;

   /**
    * Tab index
    */
   private String tabIndex;

   /**
    * Tooltip key
    */
   private String tooltipKey = null;

   /**
    * Tooltip options
    */
   private String tooltipOptions = null;

   /**
    * Tooltip key for title
    */
   private String tooltipTitleKey = null;

   /**
    * Show an error next to the field
    */
   private boolean fieldErrorDisplayed = true;

   /**
    * Select on focus
    */
   private boolean selectOnFocus = true;

   /**
    * Identificador del div que es mostra al fer la petici� a servidor.
    *
    * @return String
    */
   public String getIndicator() {
      return indicator;
   }

   /**
    * Identificador del div que es mostra al fer la petici� a servidor.
    *
    * @param pIndicator String
    */
   public void setIndicator(String pIndicator) {
      indicator = pIndicator;
   }

   /**
    * Si layout=false s'ha de cridar a la generaci� de la etiqueta.
    *
    * @return boolean
    *
    * @throws JspException
    */
   protected boolean doBeforeValue() throws javax.servlet.jsp.JspException {
      // super.doBeforeValue();

      // If no layout specified, we have to add manually label
      if (!isLayout()) {
         BasicFieldHelper.displayLabel(this);
      }

      if (this.getFieldDisplayMode() == MODE_INSPECT) {
         StringBuffer sb = new StringBuffer();
         sb.append("<span class=\"");
         sb.append(styleClass);
         sb.append("\">");
         //			if (otherValue != null) {						
         //				sb.append(otherValue);
         //			} else {
         sb.append(LayoutUtils.getBeanFromPageContext(pageContext, property));
         //			}
         sb.append("</span>");
         ResponseUtils.write(pageContext, sb.toString());
      } else {
         String tmpIdDiv = this.getProperty() + "Div";
         String tmpHTML = "<div id=\"" + tmpIdDiv +
            "\"> <input type=\"hidden\" name=\"" + this.getProperty() + "\"" +
            " value=\"" +
            LayoutUtils.getBeanFromPageContext(pageContext, property) +
            " \"/> " + "<input type=\"text\" name=\"" + this.getProperty() +
            "/Text\"" + completeAttribs() + " value=\"" +
            LayoutUtils.getBeanFromPageContext(pageContext, property) +
            " \"/> </div>";

         try {
            this.getPageContext().getOut().write(tmpHTML);
         } catch (IOException e) {
            throw new JspException(e);
         }

         OptionsBuilder options = new OptionsBuilder();
         options.add("fieldId", this.getProperty(), true);

         if (this.getIndicator() != null) {
            options.add("indicator", this.getIndicator(), false);
         }

         options.add("optionsListName", this.getOptionsListName(), true);
         options.add("numberRowsPerPage", this.getNumberRowsPerPage(), true);
         options.add("selectedKey", this.getSelectedKey(), true);
         options.add("selectedValue", this.getSelectedValue(), true);

         if (this.getStyleClass() != null) {
            options.add("className", this.getStyleClass(), true);
         }

         if (this.getQueryParameters() != null) {
            options.add("queryParameters", this.getQueryParameters(), true);
         }

         if (this.getDependentFields() != null) {
            String tmpDep = (String) ExpressionEvaluatorManager.evaluate("dependentFields",
                  this.getDependentFields(), String.class, this,
                  super.pageContext);
            options.add("dependentFields", tmpDep, true);
         }

         if (this.otherKey != null) {
            options.add("otherKey", this.otherKey, true);
         }

         if (this.otherValue != null) {
            if (this.i18nService == null) {
               throw new JspException("I18nService not defined!");
            } else {
               options.add("otherValue",
                  this.i18nService.getMessage(this.otherValue), true);
            }
         }

         StringBuffer buffer = new StringBuffer();
         buffer.append("<script type=\"text/javascript\">");
         buffer.append("new CanigoPagedSelectFieldTag.Search({");
         buffer.append(options.toString());
         buffer.append("});");
         buffer.append("</script>");

         try {
            this.getPageContext().getOut().write(buffer.toString());
         } catch (IOException e) {
            throw new JspException(e);
         }
      }

      return true;
   }

   /**
    * Documentaci�.
    *
    * @return String
    *
    * @throws JspException
    */
   private String completeAttribs() throws JspException {
      StringBuffer buffer = new StringBuffer();

      // Mouse events
      prepareAttribute(buffer, "onclick", getOnclick());
      prepareAttribute(buffer, "ondblclick", getOndblclick());
      prepareAttribute(buffer, "onmouseover", getOnmouseover());
      prepareAttribute(buffer, "onmouseout", getOnmouseout());
      prepareAttribute(buffer, "onmousemove", getOnmousemove());
      prepareAttribute(buffer, "onmousedown", getOnmousedown());
      prepareAttribute(buffer, "onmouseup", getOnmouseup());

      // Key events
      prepareAttribute(buffer, "onkeydown", getOnkeydown());
      prepareAttribute(buffer, "onkeyup", getOnkeyup());
      prepareAttribute(buffer, "onkeypress", getOnkeypress());

      // Text events
      prepareAttribute(buffer, "onselect", getOnselect());
      prepareAttribute(buffer, "onchange", getOnchange());

      // Focus events
      prepareAttribute(buffer, "onblur", getOnblur());
      prepareAttribute(buffer, "onfocus", getOnfocus());

      return buffer.toString();
   }

   /**
    * Documentaci�.
    *
    * @param handlers Documentaci�
    * @param name Documentaci�
    * @param value Documentaci�
    */
   protected void prepareAttribute(StringBuffer handlers, String name,
      Object value) {
      if (value != null) {
         handlers.append(" ");
         handlers.append(name);
         handlers.append("=\"");
         handlers.append(value);
         handlers.append("\"");
      }
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doStartLayoutTag() throws JspException {
      // EVC: import engine.js if not imported yet
      DWRHelper.generateDWREngineScript(super.pageContext);

      // EVC: import tag scripts if not imported yet.
      HttpServletRequest request = (HttpServletRequest) super.pageContext.getRequest();
      HttpServletResponse response = (HttpServletResponse) super.pageContext.getResponse();

      if ((request.getAttribute(PAGED_SELECT_IMPORTED_SCRIPTS) == null)) {
         request.setAttribute(PAGED_SELECT_IMPORTED_SCRIPTS, Constants.IMPORTED);

         TagUtils tagUtils = TagUtils.getInstance();
         tagUtils.write(super.pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() +
            response.encodeURL(
               "/scripts/ajax/ajaxtags/canigo-ajaxtags-pagedSelect.js") +
            "\"></script>\n");
      }

      TagUtil.copyConfiguration(this);
      doBeforeValue();

      return Tag.EVAL_BODY_INCLUDE;

      //super.doStartLayoutTag();
   }

   /**
    * Documentaci�.
    */
   protected void initDynamicValues() {
      TagUtil.copyConfiguration(this);
      super.initDynamicValues();
   }

   /**
    * By an error of Struts Layout after value addChoice
    * is called to add other options, but isClosed throws
    * an Exception of nested text values not allowed after
    * value printed.
    */
   protected void doAfterValue() throws JspException {
      //        need_other = false;
      //        isClosed = false;
      //
      //        // Default selected from bean
      //        Object lc_bean = pageContext.findAttribute(name);
      //        String[] oldMatch = null;
      //
      //        if (lc_bean != null) {
      //            String[] defaultSelectedFromBean = null;
      //
      //            try {
      //                defaultSelectedFromBean = LayoutUtils.getArrayProperty(lc_bean,
      //                        property);
      //            } catch (Exception ex) {
      //                throw new JspException(ex);
      //            }
      //
      //            if ((defaultSelectedFromBean != null) &&
      //                    (defaultSelectedFromBean.length > 0)) {
      //                // If default selected is neither null not blank, we set
      //                // the match attribute to be able to append "selected" html attribute 
      //                // to the html tag <option/> through the Choice interface
      //                oldMatch = match;
      //
      //                if ("true".equals(this.multiple) &&
      //                        (defaultSelectedFromBean.length == 1)) {
      //                    // Convert "1,2,3" into an array of [1,2,3] 
      //                    StringTokenizer st = new StringTokenizer(defaultSelectedFromBean[0],
      //                            ",");
      //
      //                    if (st.countTokens() > 0) {
      //                        defaultSelectedFromBean = new String[st.countTokens()];
      //
      //                        int i = 0;
      //
      //                        while (st.hasMoreTokens()) {
      //                            defaultSelectedFromBean[i++] = st.nextToken();
      //                        }
      //                    }
      //                }
      //
      //                match = defaultSelectedFromBean;
      //            }
      //        }
      //
      //        if (this.otherKey != null) {
      //            // Another option is needed
      //            StringBuffer buffer = new StringBuffer();
      //            addChoice(buffer, (this.otherValue != null) ? this.otherValue : "",
      //                this.i18nService.getMessage(this.otherKey));
      //            TagUtils.getInstance().write(getPageContext(), buffer.toString());
      //        }
      //
      //        SelectFieldTagHelper.generateOptions(this);
      //
      //        if (oldMatch != null) {
      //            match = oldMatch;
      //        }
      //
      //        if (getFieldDisplayMode() == MODE_EDIT) {
      //            selectTag.doEndTag();
      //        }
      //
      //        isClosed = true;
   }

   /**
    * Fi de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doEndLayoutTag() throws JspException {
      // TODO Auto-generated method stub
      //   return super.doEndLayoutTag();
      return Tag.EVAL_PAGE;
   }

   /**
    * Documentaci�.
    *
    * @return boolean
    */
   public boolean isFieldErrorDisplayed() {
      return fieldErrorDisplayed;
   }

   /**
    * Documentaci�.
    *
    * @param fieldErrorDisplayed boolean
    */
   public void setFieldErrorDisplayed(boolean fieldErrorDisplayed) {
      this.fieldErrorDisplayed = fieldErrorDisplayed;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @return I18nService
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Estil definit pel text o camp.
    *
    * @return String
    */
   public String getKeyStyleClass() {
      return keyStyleClass;
   }

   /**
    * Estil definit pel text o camp.
    *
    * @param keyStyleClass String
    */
   public void setKeyStyleClass(String keyStyleClass) {
      this.keyStyleClass = keyStyleClass;
   }

   /**
    * Defineix si amb el focus es selecciona tot el component.
    *
    * @return boolean
    */
   public boolean isSelectOnFocus() {
      return selectOnFocus;
   }

   /**
    * Defineix si amb el focus es selecciona tot el component.
    *
    * @param selectOnFocus boolean
    */
   public void setSelectOnFocus(boolean selectOnFocus) {
      this.selectOnFocus = selectOnFocus;
   }

   /**
    * Clau del literal del missatge a mostrar dins el tooltip.
    *
    * @return String
    */
   public String getTooltipKey() {
      return tooltipKey;
   }

   /**
    * Clau del literal del missatge a mostrar dins el tooltip.
    *
    * @param tooltipKey String
    */
   public void setTooltipKey(String tooltipKey) {
      this.tooltipKey = tooltipKey;
   }

   /**
    * Opcions aplicades segons la implementaci� (en el cas actual sota DOM
    * Tooltip).
    *
    * @return String
    */
   public String getTooltipOptions() {
      return tooltipOptions;
   }

   /**
    * Opcions aplicades segons la implementaci� (en el cas actual sota DOM
    * Tooltip).
    *
    * @param tooltipOptions String
    */
   public void setTooltipOptions(String tooltipOptions) {
      this.tooltipOptions = tooltipOptions;
   }

   /**
    * Clau del literal a mostrar si volem mostrar un t�tol com a cap�alera del
    * tooltip.
    *
    * @return String
    */
   public String getTooltipTitleKey() {
      return tooltipTitleKey;
   }

   /**
    * Clau del literal a mostrar si volem mostrar un t�tol com a cap�alera del
    * tooltip.
    *
    * @param tooltipTitleKey String
    */
   public void setTooltipTitleKey(String tooltipTitleKey) {
      this.tooltipTitleKey = tooltipTitleKey;
   }

   /**
    * Mostra el camp com obligatori.
    *
    * @param isRequired boolean
    */
   public void setRequired(boolean isRequired) {
      this.setIsRequired(Boolean.toString(isRequired));
   }

   /**
    * �ndex de tabulaci�.
    *
    * @return String
    */
   public String getTabIndex() {
      return tabIndex;
   }

   /**
    * �ndex de tabulaci�.
    *
    * @param tabIndex String
    */
   public void setTabIndex(String tabIndex) {
      this.tabIndex = tabIndex;
   }

   /**
    * PageSelects dependents de un camp.
    *
    * @return Properties
    */
   public Properties getSelectFieldSource() {
      return this.selectFieldSource;
   }

   /**
    * PageSelects dependents.
    *
    * @return Documentaci�
    */
   public Object getSelectFieldSourceProperties() {
      return this.selectFieldSourceProperties;
   }

   /**
    * PageSelects dependents.
    *
    * @param obj Object
    *
    * @throws JspException
    */
   public void setSelectFieldSourceProperties(Object obj)
      throws JspException {
      //    	if(obj.getClass().getName().equals(Properties.class.getName())){
      //    		this.selectFieldSource = (Properties)obj;
      //    	}else if(obj.getClass().getName().equals(String.class.getName())){
      //        	HashMap hashMap = (HashMap)super.pageContext.getSession().getAttribute("fr.improve.struts.taglib.layout.util.FormUtils.FORM_MODE_KEY");
      //        	Set set = hashMap.keySet();
      //        	Iterator iterator = set.iterator();
      //        	if(((Integer)hashMap.get(iterator.next())).intValue() == fr.improve.struts.taglib.layout.util.FormUtils.INSPECT_MODE ){
      //        		// inspect mode -> reset selectFieldSource
      //        		this.selectFieldSource = new Properties();
      //        	}
      //        	else{
      //        		// create or edit mode -> create java.util.Properties from a String
      //        		TagUtil.putProperties(selectFieldSource, (String)obj);
      //        	}
      //    	}else{
      //    		// Object must be java.util.Properties or java.lang.String
      //    	}
   }

   /**
    * PageSelects dependents de un camp.
    *
    * @param selectFieldSource Properties
    */
   public void setSelectFieldSource(Properties selectFieldSource) {
      this.selectFieldSource = selectFieldSource;
   }

   /**
    * Refer�ncia a la definici� de la llista.
    *
    * @return String
    */
   public String getOptionsListName() {
      return optionsListName;
   }

   /**
    * Refer�ncia a la definici� de la llista.
    *
    * @param optionsListName String
    */
   public void setOptionsListName(String optionsListName) {
      this.optionsListName = optionsListName;
   }

   /**
    * Refer�ncia al servei d'opcions.
    *
    * @return OptionsListService
    */
   public OptionsListService getOptionsListService() {
      return optionsListService;
   }

   /**
    * Refer�ncia al servei d'opcions.
    *
    * @param optionsListService OptionsListService
    */
   public void setOptionsListService(OptionsListService optionsListService) {
      this.optionsListService = optionsListService;
   }

   /**
    * Documentaci�.
    *
    * @return Returns String.
    */
   public String getOtherKey() {
      return otherKey;
   }

   /**
    * Documentaci�.
    *
    * @param otherKey String.
    */
   public void setOtherKey(String otherKey) {
      this.otherKey = otherKey;
   }

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getOtherValue() {
      return otherValue;
   }

   /**
    * Documentaci�.
    *
    * @param otherValue String
    */
   public void setOtherValue(String otherValue) {
      this.otherValue = otherValue;
   }

   /**
    * Permet injectar serveis del contenidor d' spring.
    *
    * @param services String
    *
    * @throws JspException
    */
   public void setServices(String services) throws JspException {
      ServicesTagHelper.setServices(services, pageContext, this);
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      // TODO Auto-generated method stub
      return null;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @param service ValidationService
    */
   public void setValidationService(ValidationService service) {
      // TODO Auto-generated method stub
   }

   /**
    * N�mero de files del pageSelected.
    *
    * @return String
    */
   public String getNumberRowsPerPage() {
      return numberRowsPerPage;
   }

   /**
    * N�mero de files del pageSelected.
    *
    * @param numberRowsPerPage String
    */
   public void setNumberRowsPerPage(String numberRowsPerPage) {
      this.numberRowsPerPage = numberRowsPerPage;
   }

   /**
    * Identificador del div que cont� les opcions del pageSelected.
    *
    * @return String
    */
   public String getPopupId() {
      return popupId;
   }

   /**
    * Identificador del div que cont� les opcions del pageSelected..
    *
    * @param popupId String
    */
   public void setPopupId(String popupId) {
      this.popupId = popupId;
   }

   /**
    * PageSelects dependents de m�s de un camp.
    *
    * @return String
    */
   public String getDependentFields() {
      return dependentFields;
   }

   /**
    * PageSelects dependents de m�s de un camp.
    *
    * @param dependentFields String
    */
   public void setDependentFields(String dependentFields) {
      this.dependentFields = dependentFields;
   }

   /**
    * Par�metres de la query.
    *
    * @return String
    */
   public String getQueryParameters() {
      return queryParameters;
   }

   /**
    * Par�metres de la query.
    *
    * @param queryParameters String
    */
   public void setQueryParameters(String queryParameters) {
      this.queryParameters = queryParameters;
   }

   /**
    * Camp de la query que ser� la clau de la option.
    *
    * @return String
    */
   public String getSelectedKey() {
      return selectedKey;
   }

   /**
    * Camp de la query que ser� la clau de la option.
    *
    * @param selectedKey String
    */
   public void setSelectedKey(String selectedKey) {
      this.selectedKey = selectedKey;
   }

   /**
    * Camp de la query que ser� el valor de la option.
    *
    * @return String
    */
   public String getSelectedValue() {
      return selectedValue;
   }

   /**
    * Camp de la query que ser� el valor de la option.
    *
    * @param selectedValue String
    */
   public void setSelectedValue(String selectedValue) {
      this.selectedValue = selectedValue;
   }
}
