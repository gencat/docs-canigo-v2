/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.logging;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import net.gencat.ctti.canigo.core.threadlocal.ThreadLocalProperties;
import net.gencat.ctti.canigo.services.security.SecurityService;
import net.gencat.ctti.canigo.services.web.spring.util.WebApplicationContextUtils;


/**
 * Adds extra params to the logging context
 *
 * @author MMR
 *
 */
public class RequestLoggingFilter implements Filter {
   /**
    * The security service
    */
   private SecurityService securityService = null;

   /**
    * Documentaci�.
    *
    * @param config Documentaci�
    *
    * @throws ServletException Documentaci�
    */
   public void init(FilterConfig config) throws ServletException {
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    * @param chain Documentaci�
    *
    * @throws IOException Documentaci�
    * @throws ServletException Documentaci�
    */
   public void doFilter(ServletRequest arg0, ServletResponse arg1,
      FilterChain chain) throws IOException, ServletException {
      HttpServletRequest request = (HttpServletRequest) arg0;

      if (this.securityService == null) {
         this.securityService = (SecurityService) WebApplicationContextUtils.getBeanOfType(request.getSession()
                                                                                                  .getServletContext(),
               SecurityService.class);
      }

      String contextPath = request.getContextPath();
      String remoteHost = request.getRemoteHost();
      String requestURL = (request.getRequestURL() != null)
         ? request.getRequestURL().toString() : null;
      String requestURI = request.getRequestURI();
      String queryString = request.getQueryString();
      String remoteAddr = request.getRemoteAddr();
      String userLogin = "not authenticated";
      String appName = request.getContextPath();

      if (this.securityService != null) {
         userLogin = (this.securityService.getUserLogin() != null)
            ? this.securityService.getUserLogin().getUserName()
            : "not authenticated";
         //@carles adaptat per treballar amb versi� d'acegi 0.8.3. 
         // el codi comentat es per la versi� 1.0 d'acegi. El servei de seguretat
         //  versi� 1.2 donar� aquest servei.

         //           appName = this.securityService.getApplicationName() != null ? this.securityService
         //                   .getApplicationName()
         //                   : "";
         appName = "";

         //@carles fi de l'adaptaci�.
      }

      ThreadLocalProperties.put("username", userLogin);
      ThreadLocalProperties.put("contextPath", contextPath);
      ThreadLocalProperties.put("remoteHost", remoteHost);
      ThreadLocalProperties.put("remoteAddress", remoteAddr);
      ThreadLocalProperties.put("applicationName", appName);

      if (requestURL != null) {
         ThreadLocalProperties.put("requestURL", requestURL);
      }

      if (requestURI != null) {
         ThreadLocalProperties.put("requestURI", requestURI);
      }

      if (queryString != null) {
         ThreadLocalProperties.put("queryString", queryString);
      }

      chain.doFilter(arg0, arg1);
   }

   /**
    * Documentaci�.
    */
   public void destroy() {
      // Nothing
   }

   /**
    * @return Returns the securityService.
    */
   public SecurityService getSecurityService() {
      return securityService;
   }

   /**
    * @param securityService
    *            The securityService to set.
    */
   public void setSecurityService(SecurityService securityService) {
      this.securityService = securityService;
   }
}
