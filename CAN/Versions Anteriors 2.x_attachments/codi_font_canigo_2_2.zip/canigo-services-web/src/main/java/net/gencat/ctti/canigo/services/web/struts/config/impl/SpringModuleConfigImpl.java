/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.config.impl;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.config.FormBeanConfig;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class SpringModuleConfigImpl extends org.apache.struts.config.impl.ModuleConfigImpl {
   /**
    * Documentaci�.
    */
   private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(SpringModuleConfigImpl.class);

   /**
    * Creates a new SpringModuleConfigImpl object.
    *
    * @param prefix DOCUMENT ME.
    */
   public SpringModuleConfigImpl(String prefix) {
      super(prefix);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    *
    * @return Documentaci�
    */
   public FormBeanConfig findFormBeanConfig(String name) {
      log.debug("Finding FormBeanConfig for name " + name + " and module " +
         this.prefix);

      return super.findFormBeanConfig(name);
   }

   /**
    * Documentaci�.
    *
    * @param config Documentaci�
    */
   public void addFormBeanConfig(FormBeanConfig config) {
      log.debug("Adding FormBeanConfig for " + config.getName() + " of type " +
         config.getType() + " in module " + this.prefix);

      net.gencat.ctti.canigo.services.web.struts.config.SpringFormBeanConfig formBeanConfig =
         new net.gencat.ctti.canigo.services.web.struts.config.SpringFormBeanConfig();

      try {
         BeanUtils.copyProperties(formBeanConfig, config);
         formBeanConfig.setPrefix(this.prefix);
      } catch (Exception ex) {
         log.error("Cannot copy FormBeanConfig for " + config.getName() +
            " in module " + this.prefix + ". Using struts one");
         super.addFormBeanConfig(config);
      }

      super.addFormBeanConfig(formBeanConfig);
   }
}
