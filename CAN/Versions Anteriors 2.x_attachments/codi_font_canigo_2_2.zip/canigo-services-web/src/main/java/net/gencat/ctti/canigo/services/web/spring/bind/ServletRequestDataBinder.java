/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.spring.bind;

import java.beans.PropertyEditor;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import net.gencat.ctti.canigo.core.springframework.beans.BeanWrapperImpl;
import net.gencat.ctti.canigo.services.logging.LoggingService;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.ConfigurablePropertyAccessor;
import org.springframework.validation.AbstractPropertyBindingResult;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;


/**
 * Servlet Request Data Binder
 * BeanWrapper
 * @author XES
 *
 */
public class ServletRequestDataBinder extends org.springframework.web.bind.ServletRequestDataBinder {
   /**
    * The log service
    */
   protected LoggingService logService = null;

   /**
    * Documentaci�.
    */
   protected Map bindProperties;

   /**
    * True if this binder changes wrapped instance
    */
   protected boolean wrappedInstanceMutable = false;

   /**
    * Documentaci�.
    */
   private BeanWrapper wrapper = null;

   // msg-ini
   /**
    * Documentaci�.
    */
   private BindException errors = null;

   // msg-fi

   /**
    * Creates a new ServletRequestDataBinder object.
    *
    * @param target DOCUMENT ME.
    * @param objectName DOCUMENT ME.
    * @param bindProperties DOCUMENT ME.
    */
   public ServletRequestDataBinder(Object target, String objectName,
      Map bindProperties) {
      super(target, objectName);

      //      Object obj = getErrors();
      this.bindProperties = bindProperties;

      //msg-ini
      //Generem un nou BindException
      setErrors(createErrors(target, objectName));

      //Generam un nou BeanWrapperImpl
      if (wrapper == null) {
         wrapper = new BeanWrapperImpl(super.getTarget(), bindProperties);
      }

      //Associem el bindProperties al BindException
      ((net.gencat.ctti.canigo.core.springframework.beans.BindException) this.getErrors()).setBindProperties(bindProperties);

      //    Associem el BeanWrapper al BindException
      ((net.gencat.ctti.canigo.core.springframework.beans.BindException) this.getErrors()).setBeanWrapper(wrapper);

      //Associem el BeanWrapper al BindingResults
      ((net.gencat.ctti.canigo.core.springframework.beans.BeanPropertyBindingResult) ((net.gencat.ctti.canigo.core.springframework.beans.BindException) this.getErrors()).getBindingResult()).setBeanWrapper(wrapper);

      //msg-fi

      //      if (obj instanceof net.gencat.ctti.canigo.core.springframework.beans.BindException) {
      //         ((net.gencat.ctti.canigo.core.springframework.beans.BindException) obj).setBindProperties(bindProperties);
      //      }
   }

   /**
    * Documentaci�.
    *
    * @param target Documentaci�
    * @param objectName Documentaci�
    *
    * @return Documentaci�
    */
   protected BindException createErrors(Object target, String objectName) {
      return new net.gencat.ctti.canigo.core.springframework.beans.BindException(target,
         objectName);
   }

   /**
    * Documentaci�.
    *
    * @param customMappingEditors Documentaci�
    */
   public void registerCustomMappingEditors(Map customMappingEditors) {
      Set keysSet = customMappingEditors.keySet();
      Iterator keysIterator = keysSet.iterator();

      while (keysIterator.hasNext()) {
         // register custom editors for specific properties
         String propertyName = (String) keysIterator.next();
         PropertyEditor pes = (PropertyEditor) customMappingEditors.get(propertyName);

         if (this.logService != null) {
            this.logService.getLog(this.getClass())
                           .info("Adding custom mapping editor " +
               pes.getClass().getName() + " for property " + propertyName);
         }

         this.registerCustomEditor(null, propertyName, pes);
      }
   }

   /**
    * @return Returns the wrappedInstanceMutable.
    */
   public boolean isWrappedInstanceMutable() {
      return wrappedInstanceMutable;
   }

   /**
    * @param wrappedInstanceMutable The wrappedInstanceMutable to set.
    */
   public void setWrappedInstanceMutable(boolean wrappedInstanceMutable) {
      this.wrappedInstanceMutable = wrappedInstanceMutable;
   }

   /**
    * @return Returns the logService.
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * @param logService The logService to set.
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */

   // msg-ini
   protected BeanWrapper getBeanWrapper() {
      // this.logService.getLog(ServletRequestDataBinder.class).debug("Creating a BeanWrapper with bindProperties="+this.bindProperties);
      if (wrapper == null) {
         wrapper = new BeanWrapperImpl(super.getTarget(), bindProperties);
      }

      return wrapper;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public BindException getErrors() {
      return errors;
   }

   /**
    * Documentaci�.
    *
    * @param errors Documentaci�
    */
   public void setErrors(BindException errors) {
      this.errors = errors;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected ConfigurablePropertyAccessor getPropertyAccessor() {
      return getBeanWrapper();
   }

   //msg-fi
}
