/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts;

import java.io.PrintWriter;
import java.io.StringWriter;

import net.gencat.ctti.canigo.services.exceptions.BusinessException;
import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Level;
import net.gencat.ctti.canigo.services.exceptions.SystemException;
import net.gencat.ctti.canigo.services.exceptions.WrappedCheckedException;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;


/**
 * $Id: ActionMessagesHelper.java,v 1.4 2007/07/16 08:45:50 msabates Exp $
 * Helper to build ActionMessages based on exceptions and other situations.
 * @author MMA
 * @author XES
 * @version $Revision: 1.4 $ $Date: 2007/07/16 08:45:50 $
 *
 * @since 1.1 Refactored from ExtendedDelegatingTilesRequestProcessor
 * $Log: ActionMessagesHelper.java,v $
 * Revision 1.4  2007/07/16 08:45:50  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]
 *
 * Revision 1.3  2007/05/23 10:47:39  msabates
 * Cap�alera
 *
 * Revision 1.1.1.1.2.1  2007/05/18 10:49:34  fernando.vaquero
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2007/05/15 13:53:56  fernando.vaquero
 * Importacio canigo 2.0
 *
 * Revision 1.2  2007/05/15 10:19:03  msabates
 * Jalopy
 *
 * Revision 1.1  2007/03/28 12:13:27  msabates
 * *** empty log message ***
 *
 * Revision 1.2  2007/03/14 14:44:39  msabates
 * *** empty log message ***
 *
 * Revision 1.1  2007/03/12 11:40:54  msabates
 * Refactor a net.gencat.ctti.canigo
 *
 * Revision 1.1  2007/02/22 15:56:10  msabates
 * *** empty log message ***
 *
 * Revision 1.3  2006/11/16 16:41:37  mmateos
 * author: crico: version 1.1 no estable
 *
 * Revision 1.3  2006/09/19 16:41:56  crico
 * version 1.1 no estable
 *
 * Revision 1.1.2.2  2006/08/07 11:51:34  mmateos
 * MMR: single message constructor
 *
 * Revision 1.1.2.1  2006/04/26 22:20:27  xescuder
 * XES: Added control of exceptions different of canigo
 *
 * Revision 1.1  2006/02/24 13:51:55  xescuder
 * XES: New class refactored from ExtendedDelegatingTilesRequestProcessor
 *
 */
public class ActionMessagesHelper {
   /**
    * Attribute where message errors will be set
    */
   public static final String ERROR_MESSAGE_PROPERTY_NAME = Globals.ERROR_KEY;

   /**
    * Documentaci�.
    */
   public static String ERROR_DETAILS_NOT_SET_BUNDLE_KEY = "error";

   /**
    * Unexpected error key (because has not been wrapped by canigo exception.
    * @since 1.0.1
    */
   public static String ERROR_UNEXPECTED = "error.unexpected";

   /**
    * Build ActionMessages from WrappedCheckedException type
    * @param wException
    * @return
    */
   public static ActionMessages buildWrappedCheckedExceptionMessages(
      WrappedCheckedException wException) {
      StringBuffer sb = new StringBuffer();

      ExceptionDetails exDetails = wException.getExceptionDetails();

      if (exDetails == null) {
         if (wException.getCause() instanceof BusinessException) {
            exDetails = ((BusinessException) wException.getCause()).getExceptionDetails();
         }
      }

      StringWriter stackTrace = new StringWriter();
      wException.printStackTrace(new PrintWriter(stackTrace));
      stackTrace.flush();

      ActionMessage message = null;
      ActionMessage messageDetails = null;
      ActionMessage messageStackTrace = null;
      ActionMessages messages = new ActionMessages();

      if (exDetails != null) {
         sb.append("\nError type=" + wException.getClass().getName());
         sb.append("\nLocalized message=" + wException.getLocalizedMessage());
         sb.append("\nProperties=" + exDetails.getProperties());
         sb.append("\nLayer=" + exDetails.getLayer());
         sb.append("\nSubsystem=" + exDetails.getSubsystem());
         sb.append("\nError code=" + exDetails.getErrorCode());
         sb.append("\nArguments=" + exDetails.arguments2string());
         sb.append("\nId=" + exDetails.getId());
         message = new ActionMessage(exDetails.getErrorCode(),
               exDetails.getArguments());
         messageDetails = new ActionMessage(WrappedCheckedException.class.getName(),
               new Object[] {
                  wException.getClass().getName(),
                  wException.getLocalizedMessage(), exDetails.getProperties(),
                  exDetails.getLayer(), exDetails.getSubsystem(),
                  exDetails.getErrorCode(), exDetails.arguments2string(),
                  exDetails.getId() + "", stackTrace.toString()
               });
         messageStackTrace = new ActionMessage(SystemException.class.getPackage()
                                                                    .getName() +
               ".stackTrace", new Object[] { stackTrace.toString() });
         messages.add(SystemException.class.getPackage().getName() +
            ".STACKTRACE", messageStackTrace);

         messages.add(Level.class.getName() + "." +
            Level.WARNING.getValue().toUpperCase(), messageDetails);
         messages.add(ERROR_MESSAGE_PROPERTY_NAME, message);
      } else {
         sb.append("\nWARN: ExceptionDetails is null!");
         message = new ActionMessage(ERROR_DETAILS_NOT_SET_BUNDLE_KEY);
         messages.add(ERROR_MESSAGE_PROPERTY_NAME, message);
      }

      return messages;
   }

   /**
    * Build ActionMessages from SystemException
    * @param wException
    * @return
    */
   public static ActionMessages buildSystemExceptionMessages(
      SystemException wException) {
      StringBuffer sb = new StringBuffer();

      ExceptionDetails exDetails = wException.getExceptionDetails();

      if (exDetails == null) {
         if (wException.getCause() instanceof BusinessException) {
            exDetails = ((BusinessException) wException.getCause()).getExceptionDetails();
         }
      }

      StringWriter stackTrace = new StringWriter();
      wException.printStackTrace(new PrintWriter(stackTrace));
      stackTrace.flush();

      ActionMessage message = null;
      ActionMessage messageDetails = null;
      ActionMessage messageStackTrace = null;
      ActionMessages messages = new ActionMessages();

      if (exDetails != null) {
         sb.append("\nError type=" + wException.getClass().getName());
         sb.append("\nLocalized message=" + wException.getLocalizedMessage());
         sb.append("\nProperties=" + exDetails.getProperties());
         sb.append("\nLayer=" + exDetails.getLayer());
         sb.append("\nSubsystem=" + exDetails.getSubsystem());
         sb.append("\nError code=" + exDetails.getErrorCode());
         sb.append("\nArguments=" + exDetails.arguments2string());
         sb.append("\nId=" + exDetails.getId());
         message = new ActionMessage(exDetails.getErrorCode(),
               exDetails.getArguments());
         messageDetails = new ActionMessage(SystemException.class.getName(),
               new Object[] {
                  wException.getClass().getName(),
                  wException.getLocalizedMessage(), exDetails.getProperties(),
                  exDetails.getLayer(), exDetails.getSubsystem(),
                  exDetails.getErrorCode(), exDetails.arguments2string(),
                  exDetails.getId() + "", stackTrace.toString()
               });
         messageStackTrace = new ActionMessage(SystemException.class.getPackage()
                                                                    .getName() +
               ".stackTrace", new Object[] { stackTrace.toString() });
         messages.add(SystemException.class.getPackage().getName() +
            ".STACKTRACE", messageStackTrace);
         messages.add(Level.class.getName() + "." +
            Level.ERROR.getValue().toUpperCase(), messageDetails);
         messages.add(ERROR_MESSAGE_PROPERTY_NAME, message);
      } else {
         sb.append("\nWARN: ExceptionDetails is null!");
         message = new ActionMessage(ERROR_DETAILS_NOT_SET_BUNDLE_KEY);
         messages.add(ERROR_MESSAGE_PROPERTY_NAME, message);
      }

      return messages;
   }

   /**
    * Build ActionMessages from other exceptions
    * @param wException
    * @return
    * @since 1.0.1
    * @author XES
    */
   public static ActionMessages buildExceptionMessages(Exception anException) {
      StringBuffer sb = new StringBuffer();

      StringWriter stackTrace = new StringWriter();
      anException.printStackTrace(new PrintWriter(stackTrace));
      stackTrace.flush();

      ActionMessage message = null;
      ActionMessages messages = new ActionMessages();

      if (anException.getMessage() != null) {
         message = new ActionMessage(ERROR_UNEXPECTED, anException.getMessage());
         messages.add(ERROR_MESSAGE_PROPERTY_NAME, message);
      } else {
         sb.append("\nWARN: ExceptionDetails is null!");
         message = new ActionMessage(ERROR_UNEXPECTED,
               "No information of exception '" + anException +
               "' has been indicated");
         messages.add(ERROR_MESSAGE_PROPERTY_NAME, message);
      }

      ActionMessage messageStackTrace = new ActionMessage(SystemException.class.getPackage()
                                                                               .getName() +
            ".stackTrace", new Object[] { stackTrace.toString() });
      messages.add(SystemException.class.getPackage().getName() +
         ".STACKTRACE", messageStackTrace);

      return messages;
   }

   /**
    * Builds a single message
    * @param code
    * @param arguments
    * @return
    */
   public static ActionMessages buildMessage(String code, Object[] arguments) {
      ActionMessage message = null;
      ActionMessage messageDetails = null;
      ActionMessages messages = new ActionMessages();

      message = new ActionMessage(code, arguments);
      messageDetails = new ActionMessage(WrappedCheckedException.class.getName());
      messages.add(Level.class.getName() + "." +
         Level.ERROR.getValue().toUpperCase(), messageDetails);
      messages.add(ERROR_MESSAGE_PROPERTY_NAME, message);

      return messages;
   }
}
