/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;

import fr.improve.struts.taglib.layout.util.LayoutUtils;

import org.apache.struts.taglib.TagUtils;
import org.apache.struts.taglib.html.BaseTag;


/**
 * $Id: HtmlTag.java,v 1.4 2007/07/16 08:45:52 msabates Exp $
 * Tag for html pages.
 * @author XES
 * @version $Revision: 1.4 $ $Date: 2007/07/16 08:45:52 $
 *
 * $Log: HtmlTag.java,v $
 * Revision 1.4  2007/07/16 08:45:52  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]
 *
 * Revision 1.3  2007/05/23 10:47:40  msabates
 * Cap�alera
 *
 * Revision 1.1.1.1.2.1  2007/05/18 10:49:48  fernando.vaquero
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2007/05/15 13:53:58  fernando.vaquero
 * Importacio canigo 2.0
 *
 * Revision 1.2  2007/05/15 10:19:04  msabates
 * Jalopy
 *
 * Revision 1.1  2007/03/28 12:13:40  msabates
 * *** empty log message ***
 *
 * Revision 1.2  2007/03/14 14:44:39  msabates
 * *** empty log message ***
 *
 * Revision 1.1  2007/03/12 11:40:55  msabates
 * Refactor a net.gencat.ctti.canigo
 *
 * Revision 1.1  2007/02/22 15:56:11  msabates
 * *** empty log message ***
 *
 * Revision 1.6  2007/01/15 09:03:33  mmateos
 * *** empty log message ***
 *
 * Revision 1.5  2007/01/12 16:26:57  evidal
 * *** empty log message ***
 *
 * Revision 1.4  2006/11/16 16:48:52  mmateos
 * author: xescuder: XES: Formatted and javadoc
 *
 * Revision 1.4  2006/02/23 15:19:24  xescuder
 * XES: Formatted and javadoc
 *
 */
public class HtmlTag extends fr.improve.struts.taglib.layout.HtmlTag {
   /**
    * Serial version uid
    */
   private static final long serialVersionUID = 1L;

   /**
    * Documentaci�.
    */
   public static final String HMTL_COUNTER_KEY = "net.gencat.ctti.canigo.services.web.struts.taglib.forms.HtmlTag.counter";

   /**
    * Constructor
    */
   public HtmlTag() {
      super();

      if (baseTag != null) {
         baseTag.release();
      }

      baseTag = new BaseTag() {
               protected String renderBaseElement(String scheme,
                  String serverName, int port, String uri) {
                  return super.renderBaseElement(scheme, serverName, port,
                     getRealUri((HttpServletRequest) pageContext.getRequest()));
               }
            };
   }

   /**
    * Obtain uri from request
    * @param aRequest HttpServletRequest
    * @return Uri
    */
   public static String getRealUri(HttpServletRequest aRequest) {
      String contextPath = aRequest.getContextPath();

      if (!contextPath.endsWith("/")) {
         return contextPath.concat("/");
      }

      return contextPath;
   }

   /**
    * Documentaci�.
    *
    * @param sb Documentaci�
    */
   public void doBeforeBody(StringBuffer sb) {
      sb.append("<table cellspacing=\"0\" cellpadding=\"10\" width=\"100%\"");
      sb.append(" border=\"0\">");
   }

   /**
    * End of tag
    * @return EVAL_PAGE if no html has been found previously, instead
    * return super
    * @throws JspException Exception of JSP
    */
   public int doEndLayoutTag() throws JspException {
      if (!checkForHTMLLevel(false)) {
         return EVAL_PAGE;
      }

      return super.doEndLayoutTag();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public int doStartLayoutTag() throws JspException {
      if (!checkForHTMLLevel(true)) {
         return EVAL_BODY_INCLUDE;
      }

      // append the html tag
      LayoutUtils.copyProperties(htmlTag, this);
      htmlTag.doStartTag();

      // append the head tag	
      TagUtils.getInstance().write(pageContext, "\n<head>\n\t");

      LayoutUtils.copyProperties(baseTag, this);
      baseTag.doStartTag();
      baseTag.doEndTag();
      TagUtils.getInstance().write(pageContext, "\n");

      StringBuffer sb = new StringBuffer();
      doPrintHead(sb);
      TagUtils.getInstance().write(pageContext, sb.toString());

      sb.setLength(0);
      sb.append("\n</head>\n");

      sb.append("<body");

      if (onload != null) {
         sb.append(" onload=\"");
         sb.append(onload);
         sb.append("\"");
      }

      sb.append(">\n");

      // append the title table
      if (styleClass != null) {
         doStartPanel(sb);

         if (key != null) {
            doPrintTitle(sb);
         }

         doEndPanel(sb);
      }

      // prepare the body layout
      if (layout) {
         doBeforeBody(sb);
         sb.append("<tr>");
         sb.append("<td>");
      }

      TagUtils.getInstance().write(pageContext, sb.toString());

      return (EVAL_BODY_INCLUDE);
   }

   /**
    * Check current level of html code. This is used
    * to know if html has been opened previously and only
    * generate code if not found before.
    * @param isOpening Param that sets if a tag html has been opened
    * @return true if count==1 if isOpening or count==0 when isOpening is false
    */
   private boolean checkForHTMLLevel(boolean isOpening) {
      if (pageContext != null) {
         Integer counter = (Integer) pageContext.getRequest()
                                                .getAttribute(HMTL_COUNTER_KEY);
         int count;

         if (counter == null) {
            count = 0;
         } else {
            count = counter.intValue();
         }

         boolean result;

         if (isOpening) {
            count++;

            //logger.debug("Opening.count=" + count);
            result = count == 1;
         } else {
            count--;

            //logger.debug("Closing.count=" + count); 
            result = count == 0;
         }

         pageContext.getRequest()
                    .setAttribute(HMTL_COUNTER_KEY, new Integer(count));

         return result;
      }

      return false;
   }
}
