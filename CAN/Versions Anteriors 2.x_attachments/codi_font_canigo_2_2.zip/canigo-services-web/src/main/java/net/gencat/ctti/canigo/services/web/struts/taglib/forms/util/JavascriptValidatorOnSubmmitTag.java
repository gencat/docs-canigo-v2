/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.util;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.validator.Arg;
import org.apache.commons.validator.Field;
import org.apache.commons.validator.Form;
import org.apache.commons.validator.Msg;
import org.apache.commons.validator.ValidatorAction;
import org.apache.commons.validator.ValidatorResources;
import org.apache.commons.validator.Var;
import org.apache.commons.validator.util.ValidatorUtils;
import org.springframework.beans.factory.BeanFactoryUtils;
import org.springframework.context.MessageSource;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.support.RequestContext;
import org.springmodules.validation.commons.MessageUtils;
import org.springmodules.validation.commons.ValidatorFactory;
import org.springmodules.validation.commons.taglib.JavascriptValidatorTag;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class JavascriptValidatorOnSubmmitTag extends JavascriptValidatorTag {
   /**
    * I18nService
   */
   private I18nService i18nService;

   /**
    * Documentaci�.
    */
   private String htmlBeginComment = "\n<!-- Begin \n";

   /**
    * Documentaci�.
    */
   private String htmlEndComment = "//End --> \n";

   /**
    * Creates a new JavascriptValidatorOnSubmmitTag object.
    */
   public JavascriptValidatorOnSubmmitTag() {
      super();
   }

   /**
    * Render the JavaScript for to perform validations based on the form name.
    *
    * @throws javax.servlet.jsp.JspException if a JSP exception has occurred
   */
   public int doStartTag(JSONObject paramsOnSubmit) throws JspException {
      StringBuffer results = new StringBuffer();

      //Locale locale = pageContext.getRequest().getLocale();
      Locale locale = getI18nService().getCurrentLocale();
      ValidatorResources resources = getValidatorResources();
      JSONArray paramsCamps = paramsOnSubmit.getJSONArray("camps");

      Form form = resources.getForm(locale, formName);

      if (form != null) {
         if ("true".equalsIgnoreCase(dynamicJavascript)) {
            MessageSource messages = getMessageSource();

            List lActions = new ArrayList();
            List lActionMethods = new ArrayList();

            // Get List of actions for this Form
            for (Iterator i = form.getFields().iterator(); i.hasNext();) {
               Field field = (Field) i.next();

               for (Iterator x = field.getDependencyList().iterator();
                     x.hasNext();) {
                  Object o = x.next();

                  if ((o != null) && !lActionMethods.contains(o)) {
                     lActionMethods.add(o);
                  }
               }
            }

            //codigo para OnSubmit
            lActionMethods = getMethodsOnSubmit(lActionMethods, paramsCamps);

            //

            // Create list of ValidatorActions based on lActionMethods
            for (Iterator i = lActionMethods.iterator(); i.hasNext();) {
               String depends = (String) i.next();
               ValidatorAction va = resources.getValidatorAction(depends);

               // throw nicer NPE for easier debugging
               if (va == null) {
                  throw new NullPointerException("Depends string \"" + depends +
                     "\" was not found in validator-rules.xml.");
               }

               String javascript = va.getJavascript();

               if ((javascript != null) && (javascript.length() > 0)) {
                  lActions.add(va);
               } else {
                  i.remove();
               }
            }

            Collections.sort(lActions,
               new Comparator() {
                  public int compare(Object o1, Object o2) {
                     ValidatorAction va1 = (ValidatorAction) o1;
                     ValidatorAction va2 = (ValidatorAction) o2;

                     if (((va1.getDepends() == null) ||
                           (va1.getDepends().length() == 0)) &&
                           ((va2.getDepends() == null) ||
                           (va2.getDepends().length() == 0))) {
                        return 0;
                     } else if (((va1.getDepends() != null) &&
                           (va1.getDepends().length() > 0)) &&
                           ((va2.getDepends() == null) ||
                           (va2.getDepends().length() == 0))) {
                        return 1;
                     } else if (((va1.getDepends() == null) ||
                           (va1.getDepends().length() == 0)) &&
                           ((va2.getDepends() != null) &&
                           (va2.getDepends().length() > 0))) {
                        return -1;
                     } else {
                        return va1.getDependencyList().size() -
                        va2.getDependencyList().size();
                     }
                  }
               });

            String methods = null;

            for (Iterator i = lActions.iterator(); i.hasNext();) {
               ValidatorAction va = (ValidatorAction) i.next();

               if (methods == null) {
                  methods = va.getMethod() + "(form)";
               } else {
                  methods += (" && " + va.getMethod() + "(form)");
               }
            }

            results.append(getJavascriptBegin(methods));

            for (Iterator i = lActions.iterator(); i.hasNext();) {
               ValidatorAction va = (ValidatorAction) i.next();
               String jscriptVar = null;
               String functionName = null;

               if ((va.getJsFunctionName() != null) &&
                     (va.getJsFunctionName().length() > 0)) {
                  functionName = va.getJsFunctionName();
               } else {
                  functionName = va.getName();
               }

               results.append("    function " + functionName + " () { \n");

               for (Iterator x = form.getFields().iterator(); x.hasNext();) {
                  Field field = (Field) x.next();

                  // Skip indexed fields for now until there is a good way to handle
                  // error messages (and the length of the list (could retrieve from scope?))
                  if (field.isIndexed() || (field.getPage() != page) ||
                        !field.isDependency(va.getName())) {
                     continue;
                  }

                  String message = MessageUtils.getMessage(messages, locale,
                        va, field);

                  message = (message != null) ? message : "";

                  jscriptVar = this.getNextVar(jscriptVar);

                  results.append("     this." + jscriptVar + " = new Array(\"" +
                     field.getKey() + "\", \"" + message + "\", ");

                  results.append("new Function (\"varName\", \"");

                  Map vars = field.getVars();

                  // Loop through the field's variables.
                  Iterator varsIterator = vars.keySet().iterator();

                  while (varsIterator.hasNext()) {
                     String varName = (String) varsIterator.next();
                     Var var = (Var) vars.get(varName);
                     String varValue = var.getValue();
                     String jsType = var.getJsType();

                     // skip requiredif variables field, fieldIndexed, fieldTest, fieldValue
                     if (varName.startsWith("field")) {
                        continue;
                     }

                     if (Var.JSTYPE_INT.equalsIgnoreCase(jsType)) {
                        results.append("this." + varName + "=" +
                           ValidatorUtils.replace(varValue, "\\", "\\\\") +
                           "; ");
                     } else if (Var.JSTYPE_REGEXP.equalsIgnoreCase(jsType)) {
                        results.append("this." + varName + "=/" +
                           ValidatorUtils.replace(varValue, "\\", "\\\\") +
                           "/; ");
                     } else if (Var.JSTYPE_STRING.equalsIgnoreCase(jsType)) {
                        results.append("this." + varName + "='" +
                           ValidatorUtils.replace(varValue, "\\", "\\\\") +
                           "'; ");

                        // So everyone using the latest format doesn't need to change their xml files immediately.
                     } else if ("mask".equalsIgnoreCase(varName)) {
                        results.append("this." + varName + "=/" +
                           ValidatorUtils.replace(varValue, "\\", "\\\\") +
                           "/; ");
                     } else {
                        results.append("this." + varName + "='" +
                           ValidatorUtils.replace(varValue, "\\", "\\\\") +
                           "'; ");
                     }
                  }

                  results.append(" return this[varName];\"));\n");
               }

               //codigo para a�adir a cada funcion los campos a validar del OnSubmit
               results = getVarsOnSubmit(results, paramsCamps, va, jscriptVar);

               //
               results.append("    } \n\n");
            }
         } else if ("true".equalsIgnoreCase(staticJavascript)) {
            results.append(this.getStartElement());

            if ("true".equalsIgnoreCase(htmlComment)) {
               results.append(htmlBeginComment);
            }
         }
      }

      if ("true".equalsIgnoreCase(staticJavascript)) {
         results.append(getJavascriptStaticMethods(resources));
      }

      if ((form != null) &&
            ("true".equalsIgnoreCase(dynamicJavascript) ||
            "true".equalsIgnoreCase(staticJavascript))) {
         results.append(getJavascriptEnd());
      }

      JspWriter writer = pageContext.getOut();

      try {
         writer.print(results.toString());
      } catch (IOException e) {
         throw new JspException(e.getMessage());
      }

      return (SKIP_BODY);
   }

   /**
    * Metodo que crea las funciones javascript validationName
    * para los campos que tienen onSubmit
    */
   private List getMethodsOnSubmit(List lActionMethods, JSONArray paramsCamps) {
      for (int j = 0; j < paramsCamps.length(); j++) {
         JSONObject camps = (JSONObject) paramsCamps.get(j);
         String aValidar = (String) camps.get("validacio");

         String fieldName = (String) camps.get("nomCamp");

         //Get List of actions for this Form
         //vemos si hay un metodo de validacion o mas
         //String metodoValidacio=aValidatorName;
         StringTokenizer tokens = new StringTokenizer(aValidar, ",");

         while (tokens.hasMoreTokens()) {
            String metodoValidacio = (tokens.nextToken());

            //buscamos el metodo de validacion sin params
            //int inici = metodoValidacio.lastIndexOf("{"); carles.
            int inici = metodoValidacio.indexOf("{");
            String param = "";
            String valueParam = "";
            String metVal = metodoValidacio;

            if (inici >= 0) {
               metVal = metodoValidacio.substring(0, inici);

               //
            }

            if ((metVal != null) && !lActionMethods.contains(metVal)) {
               lActionMethods.add(metVal);
            }
         }
      }

      return lActionMethods;
   }

   /**
    * Metodo que crea las funciones especificas de validacion
    * para los campos que tienen onSubmit
    */
   private StringBuffer getVarsOnSubmit(StringBuffer results,
      JSONArray paramsCamps, ValidatorAction va, String jscriptVar) {
      MessageSource messages = getMessageSource();

      for (int j = 0; j < paramsCamps.length(); j++) {
         JSONObject camps = (JSONObject) paramsCamps.get(j);
         String nomCamp = (String) camps.get("nomCamp");
         String valName = (String) camps.get("validacio");
         String errorKey = "";

         if (camps.get("errorKey") != null) {
            errorKey = (String) camps.get("errorKey");
         }

         StringTokenizer tokens = new StringTokenizer(valName, ",");
         String dependents = "";

         while (tokens.hasMoreTokens()) {
            String metodoValidacio = tokens.nextToken();

            //    		buscamos el metodo de validacion sin params
            //			int inici = metodoValidacio.lastIndexOf("{");	
            int inici = metodoValidacio.indexOf("{");
            String metVal = metodoValidacio;

            if (inici >= 0) {
               metVal = metodoValidacio.substring(0, inici);
            }

            if (dependents.equals("")) {
               dependents = metVal;
            } else {
               dependents = dependents + "," + metVal;
            }
         }

         Field field = new Field();
         field.setKey(nomCamp);
         field.setProperty(nomCamp);
         field.setDepends(dependents);

         Msg msg = new Msg();
         msg.setKey(va.getMsg());

         field.addMsg(msg);

         Arg arg = new Arg();
         arg.setResource(true);
         arg.setKey(errorKey);
         //arg.setBundle(errorKey);
         arg.setPosition(0);
         field.addArg(arg);

         // Skip indexed fields for now until there is a good way to handle
         // error messages (and the length of the list (could retrieve from scope?))
         if (field.isIndexed() || (field.getPage() != page) ||
               !field.isDependency(va.getName())) {
            continue;
         }

         System.out.println("i18nService.getCurrentLocale()----" +
            getI18nService().getCurrentLocale());

         String message = MessageUtils.getMessage(getMessageSource(),
               getI18nService().getCurrentLocale(), va, field);

         message = (message != null) ? message : "";

         jscriptVar = getNextVar(jscriptVar);

         results.append("     this." + jscriptVar + " = new Array(\"" +
            nomCamp + "\", \"" + message + "\", ");

         results.append("new Function (\"varName\", \"");

         //String valName = (String)camps.get("validacio");
         //int ultimo= valName.lastIndexOf(")");	
         //int primero =valName.lastIndexOf("(");	
         //String aVal=valName.substring(primero+1,ultimo);
         //String fieldName = (String)camps.get("nomCamp");
         StringTokenizer tokensVal = new StringTokenizer(valName, ",");

         while (tokensVal.hasMoreTokens()) {
            String metodoVal = (tokensVal.nextToken());

            //buscamos el metodo de validacion sin params
            //			buscamos el metodo de validacion sin params
            //	    		int inici = metodoVal.lastIndexOf("{");	
            int inici = metodoVal.indexOf("{");
            String varName = "";
            String varValue = "";
            String metValida = metodoVal;

            if (inici >= 0) {
               metValida = metodoVal.substring(0, inici);

               //buscammos las variables para ese metodo de validacion
               int primer = metodoVal.indexOf("{");
               int ultim = metodoVal.lastIndexOf("}");
               String variables = metodoVal.substring(primer + 1, ultim);

               StringTokenizer tokensVars = new StringTokenizer(variables, ";");
               int k = 1;

               while (tokensVars.hasMoreTokens()) {
                  String variable = (tokensVars.nextToken());

                  int ini = variable.lastIndexOf(":");
                  int fin = variable.length();

                  varName = variable.substring(0, ini);
                  varValue = variable.substring(ini + 1, fin);

                  Arg argVar = new Arg();
                  argVar.setResource(false);
                  argVar.setName(varName);
                  argVar.setKey(varValue);
                  argVar.setPosition(k);

                  field.addArg(argVar);
                  k++;
               }

               //

               //            String varName = (String) varsIterator.next();
               //            Var var = (Var) vars.get(varName);
               //            String varValue = var.getValue();
               //           String jsType = var.getJsType();

               // skip requiredif variables field, fieldIndexed, fieldTest, fieldValue
               if (varName.startsWith("field")) {
                  continue;
               }

               //            if (Var.JSTYPE_INT.equalsIgnoreCase(jsType)) {
               //                results.append("this."
               //                        + varName
               //                        + "="
               //                        + ValidatorUtils.replace(varValue,
               //                                "\\",
               //                                "\\\\")
               //                        + "; ");
               //            }
               //            else if (Var.JSTYPE_REGEXP.equalsIgnoreCase(jsType)) {
               //                results.append("this."
               //                        + varName
               //                        + "=/"
               //                        + ValidatorUtils.replace(varValue,
               //                                "\\",
               //                                "\\\\")
               //                        + "/; ");
               //            }
               //            else if (Var.JSTYPE_STRING.equalsIgnoreCase(jsType)) {
               //                results.append("this."
               //                        + varName
               //                        + "='"
               //                        + ValidatorUtils.replace(varValue,
               //                                "\\",
               //                                "\\\\")
               //                        + "'; ");
               //                // So everyone using the latest format doesn't need to change their xml files immediately.
               //            }
               //            else 
               if ("mask".equalsIgnoreCase(varName)) {
                  results.append("this." + varName + "=/" +
                     ValidatorUtils.replace(varValue, "\\", "\\\\") + "/; ");
               } else {
                  results.append("this." + varName + "='" +
                     ValidatorUtils.replace(varValue, "\\", "\\\\") + "'; ");
               }
            }
         }

         results.append(" return this[varName];\"));\n");
      }

      return results;
   }

   /**
    * Render the JavaScript for to perform validations based on the form name.
    *
    * @throws javax.servlet.jsp.JspException if a JSP exception has occurred
    */
   public int doStartTagDecotator(JSONObject paramsOnSubmit)
      throws JspException {
      StringBuffer results = new StringBuffer();
      Locale locale = getI18nService().getCurrentLocale();
      ValidatorResources resources = getValidatorResources();

      // Form form = resources.getForm(locale, formName);
      // if (form != null) {
      if ("true".equalsIgnoreCase(dynamicJavascript)) {
         MessageSource messages = getMessageSource();

         List lActions = new ArrayList();
         List lActionMethods = new ArrayList();

         JSONArray paramsCamps = paramsOnSubmit.getJSONArray("camps");

         for (int j = 0; j < paramsCamps.length(); j++) {
            JSONObject camps = (JSONObject) paramsCamps.get(j);
            String aValidar = (String) camps.get("validacio");
            String fieldName = (String) camps.get("nomCamp");

            //Get List of actions for this Form
            //vemos si hay un metodo de validacion o mas
            //String metodoValidacio=aValidatorName;
            StringTokenizer tokens = new StringTokenizer(aValidar, ",");

            while (tokens.hasMoreTokens()) {
               String metodoValidacio = (tokens.nextToken());

               //buscamos el metodo de validacion sin params
               int inici = metodoValidacio.indexOf("{");
               String param = "";
               String valueParam = "";
               String metVal = metodoValidacio;

               if (inici >= 0) {
                  metVal = metodoValidacio.substring(0, inici);

                  //buscammos los parametros necesarios para ese metodo de validacion

                  //carles: repassar.
                  int ini = metodoValidacio.lastIndexOf(":");
                  int fin = metodoValidacio.lastIndexOf("}");

                  param = metodoValidacio.substring(inici + 1, ini);
                  valueParam = metodoValidacio.substring(ini + 1, fin);

                  //
               }

               if ((metVal != null) && !lActionMethods.contains(metVal)) {
                  lActionMethods.add(metVal);
               }
            }
         }

         // Create list of ValidatorActions based on lActionMethods
         for (Iterator i = lActionMethods.iterator(); i.hasNext();) {
            String depends = (String) i.next();
            ValidatorAction va = resources.getValidatorAction(depends);

            // throw nicer NPE for easier debugging
            if (va == null) {
               throw new NullPointerException("Depends string \"" + depends +
                  "\" was not found in validator-rules.xml.");
            }

            String javascript = va.getJavascript();

            if ((javascript != null) && (javascript.length() > 0)) {
               lActions.add(va);
            } else {
               i.remove();
            }
         }

         Collections.sort(lActions,
            new Comparator() {
               public int compare(Object o1, Object o2) {
                  ValidatorAction va1 = (ValidatorAction) o1;
                  ValidatorAction va2 = (ValidatorAction) o2;

                  if (((va1.getDepends() == null) ||
                        (va1.getDepends().length() == 0)) &&
                        ((va2.getDepends() == null) ||
                        (va2.getDepends().length() == 0))) {
                     return 0;
                  } else if (((va1.getDepends() != null) &&
                        (va1.getDepends().length() > 0)) &&
                        ((va2.getDepends() == null) ||
                        (va2.getDepends().length() == 0))) {
                     return 1;
                  } else if (((va1.getDepends() == null) ||
                        (va1.getDepends().length() == 0)) &&
                        ((va2.getDepends() != null) &&
                        (va2.getDepends().length() > 0))) {
                     return -1;
                  } else {
                     return va1.getDependencyList().size() -
                     va2.getDependencyList().size();
                  }
               }
            });

         String methods = null;

         for (Iterator i = lActions.iterator(); i.hasNext();) {
            ValidatorAction va = (ValidatorAction) i.next();

            if (methods == null) {
               methods = va.getMethod() + "(form)";
            } else {
               methods += (" && " + va.getMethod() + "(form)");
            }
         }

         results.append(getJavascriptBegin(methods));

         for (Iterator i = lActions.iterator(); i.hasNext();) {
            ValidatorAction va = (ValidatorAction) i.next();
            String jscriptVar = null;
            String functionName = null;

            if ((va.getJsFunctionName() != null) &&
                  (va.getJsFunctionName().length() > 0)) {
               functionName = va.getJsFunctionName();
            } else {
               functionName = va.getName();
            }

            results.append("    function " + functionName + " () { \n");

            for (int j = 0; j < paramsCamps.length(); j++) {
               JSONObject camps = (JSONObject) paramsCamps.get(j);
               String nomCamp = (String) camps.get("nomCamp");
               String valName = (String) camps.get("validacio");
               String errorKey = "";

               if (camps.get("errorKey") != null) {
                  errorKey = (String) camps.get("errorKey");
               }

               StringTokenizer tokens = new StringTokenizer(valName, ",");
               String dependents = "";

               while (tokens.hasMoreTokens()) {
                  String metodoValidacio = tokens.nextToken();

                  //                  		buscamos el metodo de validacion sin params
                  int inici = metodoValidacio.indexOf("{");
                  String metVal = metodoValidacio;

                  if (inici >= 0) {
                     metVal = metodoValidacio.substring(0, inici);
                  }

                  if (dependents.equals("")) {
                     dependents = metVal;
                  } else {
                     dependents = dependents + "," + metVal;
                  }
               }

               Field field = new Field();
               field.setKey(nomCamp);
               field.setProperty(nomCamp);
               field.setDepends(dependents);

               Msg msg = new Msg();
               msg.setKey(va.getMsg());

               field.addMsg(msg);

               Arg arg = new Arg();
               arg.setResource(true);
               arg.setKey(errorKey);
               arg.setPosition(0);
               field.addArg(arg);

               // Skip indexed fields for now until there is a good way to handle
               // error messages (and the length of the list (could retrieve from scope?))
               if (field.isIndexed() || (field.getPage() != page) ||
                     !field.isDependency(va.getName())) {
                  continue;
               }

               String message = MessageUtils.getMessage(getMessageSource(),
                     locale, va, field);

               message = (message != null) ? message : "";

               jscriptVar = getNextVar(jscriptVar);

               results.append("     this." + jscriptVar + " = new Array(\"" +
                  nomCamp + "\", \"" + message + "\", ");

               results.append("new Function (\"varName\", \"");

               StringTokenizer tokensVal = new StringTokenizer(valName, ",");

               while (tokensVal.hasMoreTokens()) {
                  String metodoVal = (tokensVal.nextToken());

                  //buscamos el metodo de validacion sin params
                  //              			buscamos el metodo de validacion sin params
                  int inici = metodoVal.lastIndexOf("{");
                  String varName = "";
                  String varValue = "";
                  String metValida = metodoVal;

                  if (inici >= 0) {
                     metValida = metodoVal.substring(0, inici);

                     //buscammos las variables para ese metodo de validacion
                     int primer = metodoVal.lastIndexOf("{");
                     int ultim = metodoVal.lastIndexOf("}");
                     String variables = metodoVal.substring(primer + 1, ultim);

                     StringTokenizer tokensVars = new StringTokenizer(variables,
                           ";");
                     int k = 1;

                     while (tokensVars.hasMoreTokens()) {
                        String variable = (tokensVars.nextToken());

                        int ini = variable.lastIndexOf(":");
                        int fin = variable.length();

                        varName = variable.substring(0, ini);
                        varValue = variable.substring(ini + 1, fin);

                        Arg argVar = new Arg();
                        argVar.setResource(false);
                        argVar.setName(varName);
                        argVar.setKey(varValue);
                        argVar.setPosition(k);

                        field.addArg(argVar);
                        k++;
                     }

                     //

                     // skip requiredif variables field, fieldIndexed, fieldTest, fieldValue
                     if (varName.startsWith("field")) {
                        continue;
                     }

                     //                          if (Var.JSTYPE_INT.equalsIgnoreCase(jsType)) {
                     //                              results.append("this."
                     //                                      + varName
                     //                                      + "="
                     //                                      + ValidatorUtils.replace(varValue,
                     //                                              "\\",
                     //                                              "\\\\")
                     //                                      + "; ");
                     //                          }
                     //                          else if (Var.JSTYPE_REGEXP.equalsIgnoreCase(jsType)) {
                     //                              results.append("this."
                     //                                      + varName
                     //                                      + "=/"
                     //                                      + ValidatorUtils.replace(varValue,
                     //                                              "\\",
                     //                                              "\\\\")
                     //                                      + "/; ");
                     //                          }
                     //                          else if (Var.JSTYPE_STRING.equalsIgnoreCase(jsType)) {
                     //                              results.append("this."
                     //                                      + varName
                     //                                      + "='"
                     //                                      + ValidatorUtils.replace(varValue,
                     //                                              "\\",
                     //                                              "\\\\")
                     //                                      + "'; ");
                     //                              // So everyone using the latest format doesn't need to change their xml files immediately.
                     //                          }
                     //                          else 
                     if ("mask".equalsIgnoreCase(varName)) {
                        results.append("this." + varName + "=/" +
                           ValidatorUtils.replace(varValue, "\\", "\\\\") +
                           "/; ");
                     } else {
                        results.append("this." + varName + "='" +
                           ValidatorUtils.replace(varValue, "\\", "\\\\") +
                           "'; ");
                     }
                  }
               }

               results.append(" return this[varName];\"));\n");
            }

            results.append("    } \n\n");
         }
      } else if ("true".equalsIgnoreCase(staticJavascript)) {
         results.append(getStartElement());

         if ("true".equalsIgnoreCase(htmlComment)) {
            results.append(htmlBeginComment);
         }
      }

      //}
      if ("true".equalsIgnoreCase(staticJavascript)) {
         results.append(getJavascriptStaticMethods(resources));
      }

      if (("true".equalsIgnoreCase(dynamicJavascript) ||
            "true".equalsIgnoreCase(staticJavascript))) {
         results.append(getJavascriptEnd());
      }

      JspWriter writer = pageContext.getOut();

      try {
         writer.print(results.toString());
      } catch (IOException e) {
         throw new JspException(e.getMessage());
      }

      return (SKIP_BODY);
   }

   /**
    * Use the application context itself for default message resolution.
    */
   private MessageSource getMessageSource() {
      try {
         this.requestContext = new RequestContext((HttpServletRequest) this.pageContext.getRequest());
      } catch (RuntimeException ex) {
         throw ex;
      } catch (Exception ex) {
         pageContext.getServletContext().log("Exception in custom tag", ex);
      }

      return requestContext.getWebApplicationContext();
   }

   /**
    * Get the validator resources from a ValidatorFactory defined in the
    * web application context or one of its parent contexts.
    * The bean is resolved by type (org.springmodules.commons.validator.ValidatorFactory).
    *
    * @return ValidatorResources from a ValidatorFactory
    */
   private ValidatorResources getValidatorResources() {
      WebApplicationContext ctx = (WebApplicationContext) pageContext.getRequest()
                                                                     .getAttribute(DispatcherServlet.WEB_APPLICATION_CONTEXT_ATTRIBUTE);

      if (ctx == null) {
         // look in main application context (i.e. applicationContext.xml)
         ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(pageContext.getServletContext());
      }

      ValidatorFactory factory = (ValidatorFactory) BeanFactoryUtils.beanOfTypeIncludingAncestors(ctx,
            ValidatorFactory.class, true, true);

      return factory.getValidatorResources();
   }

   /**
    * The value <code>null</code> will be returned at the end of the sequence.
    * &nbsp;&nbsp;&nbsp; ex: "zz" will return <code>null</code>
    */
   private String getNextVar(String input) {
      if (input == null) {
         return "aa";
      }

      input = input.toLowerCase();

      for (int i = input.length(); i > 0; i--) {
         int pos = i - 1;

         char c = input.charAt(pos);
         c++;

         if (c <= 'z') {
            if (i == 0) {
               return c + input.substring(pos, input.length());
            } else if (i == input.length()) {
               return input.substring(0, pos) + c;
            } else {
               return input.substring(0, pos) + c +
               input.substring(pos, input.length() - 1);
            }
         } else {
            input = replaceChar(input, pos, 'a');
         }
      }

      return null;
   }

   /**
    * Replaces a single character in a <code>String</code>
    */
   private String replaceChar(String input, int pos, char c) {
      if (pos == 0) {
         return c + input.substring(pos, input.length());
      } else if (pos == input.length()) {
         return input.substring(0, pos) + c;
      } else {
         return input.substring(0, pos) + c +
         input.substring(pos, input.length() - 1);
      }
   }

   /**
    * Constructs the beginning &lt;script&gt; element depending on xhtml status.
    */
   private String getStartElement() {
      StringBuffer start = new StringBuffer("<script type=\"text/javascript\"");

      // there is no language attribute in xhtml
      if (!this.isXhtml()) {
         start.append(" language=\"Javascript1.1\"");
      }

      if (this.src != null) {
         start.append(" src=\"" + src + "\"");
      }

      start.append("> \n");

      return start.toString();
   }

   /**
    * Returns true if this is an xhtml page.
    */
   private boolean isXhtml() {
      return "true".equalsIgnoreCase(xhtml);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Documentaci�.
    *
    * @param service Documentaci�
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }
}
