/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.util;

import java.util.StringTokenizer;

import javax.servlet.jsp.JspException;

import fr.improve.struts.taglib.layout.field.AbstractFieldTag;
import fr.improve.struts.taglib.layout.field.AbstractLayoutFieldTag;
import fr.improve.struts.taglib.layout.field.AbstractModeFieldTag;
import fr.improve.struts.taglib.layout.util.LayoutUtils;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.web.taglib.FieldTag;
import net.gencat.ctti.canigo.services.web.taglib.TextFieldTag;

import org.apache.struts.taglib.TagUtils;


/**
 * Helper de BasicField
 * Genera:
 *    - Etiquetes
 *    - Tooltips
 *    - Codi per camps requerits
 *    - Conversi� dels valors dels camps
 *    - Acces al id del component
 *
 * @author XES
 *
 */
public class BasicFieldHelper {
   /**
    * Documentaci�.
    */
   private static final String REQUIRED_ATTRIBUTE = " required";

   /**
    * Genera les etiquetes.
    *
    * @param inputFormTag FieldTag
    *
    * @throws JspException
    */
   public static void displayLabel(FieldTag inputFormTag)
      throws JspException {
      I18nService i18nService = inputFormTag.getI18nService();

      if (i18nService != null) {
         String labelKey = inputFormTag.getKey();

         if (labelKey != null) {
            String in_label = i18nService.getMessage(labelKey);

            if (in_label != null) {
               TagUtils tagUtils = TagUtils.getInstance();
               StringBuffer buffer = new StringBuffer();
               buffer = displayLabel(buffer,
                     (AbstractLayoutFieldTag) inputFormTag, in_label);
               tagUtils.write(inputFormTag.getPageContext(), buffer.toString());
            }
         }
      }
   }

   /**
    * Genera les etiquetes.
    *
    * @param aBuffer StringBuffer
    * @param inputFormTag AbstractLayoutFieldTag
    * @param in_label String
    *
    * @return StringBuffer
    *
    * @throws Jsp
    */
   static StringBuffer displayLabel(StringBuffer aBuffer,
      AbstractLayoutFieldTag inputFormTag, String in_label)
      throws JspException {
      boolean showLabel = true;

      // Only display label if show mode
      if (inputFormTag instanceof AbstractModeFieldTag) {
         AbstractModeFieldTag modeFieldTag = (AbstractModeFieldTag) inputFormTag;
         int fieldDisplayMode = modeFieldTag.getFieldDisplayMode();

         switch (fieldDisplayMode) {
         case AbstractModeFieldTag.MODE_NODISPLAY:
         case AbstractModeFieldTag.MODE_HIDDEN:
            showLabel = false;

            break;
         }
      }

      if (!showLabel) {
         return aBuffer;
      }

      // -------------------------------------------------------------------/
      // ------------------------- LABEL GENERATION ------------------------/
      // -------------------------------------------------------------------/
      String keyLabel = inputFormTag.getKey();

      if (keyLabel != null) {
         // Now with canigo we can decide to generate or not the layout
         if (inputFormTag.isLayout()) {
            // Start the label cell.
            aBuffer.append("<th valign=\"top\"");
            BasicFieldHelper.displayKeyStyleClass(aBuffer, inputFormTag);

            // Set the layout id of the cell.
            String lc_layoutId = inputFormTag.getStyleId();

            if (lc_layoutId != null) {
               aBuffer.append(" id=\"");
               aBuffer.append(lc_layoutId);
               aBuffer.append("L");
            }

            // Render a span in_tag as some browser don't support to set the style in the <td> in_tag.
            aBuffer.append("\">");
         }

         // Instead of previous behaviour of Struts Layout (using span class)
         // use a label tag using 'for' of associated property		
         aBuffer.append("<label for=\"" + inputFormTag.getStyleId() + "\"");
         BasicFieldHelper.displayKeyStyleClass(aBuffer, inputFormTag);

         // Render a tooltip.
         if (inputFormTag.getHint() != null) {
            aBuffer.append(" title=\"");
            aBuffer.append(LayoutUtils.getLabel(inputFormTag.getPageContext(),
                  inputFormTag.getBundle(), inputFormTag.getHint(), null, false));
            aBuffer.append("\"");
         }

         // --------------     ACCESS KEY GENERATION ---------------------------/
         // canigo extension: Append access key -----------------------------
         aBuffer = BasicFieldHelper.displayAccessKey(aBuffer, inputFormTag);

         //---------------------------------------------------------------------
         aBuffer.append(">");

         // Render the label and end of the label cell.
         if ((in_label == null) || in_label.trim().equals("")) {
            // (canigo) Obtain associated label from key
            if (keyLabel != null) {
               in_label = LayoutUtils.getLabel(inputFormTag.getPageContext(),
                     inputFormTag.getBundle(), keyLabel, null, false);
            }
         }

         if (in_label != null) {
            // Obtain label from key property
            StringBuffer lc_label = new StringBuffer(in_label);

            for (int i = 0; i < lc_label.length(); i++) {
               if (lc_label.charAt(i) == ' ') {
                  lc_label.replace(i, i + 1, "&nbsp;");
               }
            }

            aBuffer.append(lc_label.toString());
         } else {
            aBuffer.append("&nbsp;");
         }

         aBuffer.append("</label>");

         if (inputFormTag.isLayout()) {
            aBuffer.append("</th>");
         }
      } // end of 'if (keyLabel!=null)' 

      //	---------------------  END OF LABEL GENERATION -------------------/
      return aBuffer;
   }

   /**
    * Mostra la informaci� requerida.
    * @param aBuffer StringBuffer
    * @param inTag AbstractLayoutFieldTag
    * @return StringBuffer
    */
   static StringBuffer displayRequired(StringBuffer aBuffer,
      AbstractLayoutFieldTag inTag) {
      if (inTag instanceof FieldTag) {
         FieldTag fieldTag = (FieldTag) inTag;
         fieldTag.setStyleClass(((fieldTag.getStyleClass() != null)
            ? fieldTag.getStyleClass() : "") + REQUIRED_ATTRIBUTE);
      }

      return aBuffer;
   }

   /**
    * Afegeix informaci� per convertir l'�atribut.
    * @param aBuffer StringBuffer
    * @param inTag AbstractLayoutFieldTag
    * @return StringBuffer
    */
   static StringBuffer displayConvertTo(StringBuffer aBuffer,
      AbstractLayoutFieldTag inTag) {
      if (inTag instanceof TextFieldTag) {
         TextFieldTag textFieldTag = (TextFieldTag) inTag;

         // Expected list separated by ','
         String convertTo = textFieldTag.getConvertTo();

         if ((convertTo != null) && !convertTo.trim().equals("")) {
            StringTokenizer strTokenizer = new StringTokenizer(convertTo, ",");

            while (strTokenizer.hasMoreTokens()) {
               String conversion = strTokenizer.nextToken();
               textFieldTag.setStyleClass(textFieldTag.getStyleClass() + " " +
                  conversion);
            }
         }
      }

      return aBuffer;
   }

   /**
        * Afegeix la classe de estil al camp.
        * @param aBuffer StringBuffer
        * @return StringBuffer
        */
   static StringBuffer displayKeyStyleClass(StringBuffer aBuffer,
      AbstractLayoutFieldTag inTag) {
      if (inTag instanceof FieldTag) {
         FieldTag inputFormTag = (FieldTag) inTag;
         String newKeyStyleClass = inputFormTag.getKeyStyleClass();

         boolean isNull = (newKeyStyleClass == null) ||
            newKeyStyleClass.trim().equals("null") ||
            newKeyStyleClass.equals("");

         // By default if no keyStyleClass has been configured used keyStyleClass
         if (isNull) {
            newKeyStyleClass = inputFormTag.getStyleClass();
         }

         isNull = (newKeyStyleClass == null) ||
            newKeyStyleClass.trim().equals("null") ||
            newKeyStyleClass.equals("");

         if (!isNull) {
            aBuffer.append(" class=\"");
            aBuffer.append(newKeyStyleClass);
            aBuffer.append("\"");
         }
      }

      return aBuffer;
   }

   /**
    * Afegeix una entrada per accedir al camp.
    * @author XES
    */
   static StringBuffer displayAccessKey(StringBuffer aBuffer,
      AbstractLayoutFieldTag inTag) {
      if (inTag instanceof FieldTag) {
         FieldTag inputFormTag = (FieldTag) inTag;
         String newAccessKey = inputFormTag.getAccesskey();

         if (newAccessKey != null) {
            // Obtain from resources the access key value
            I18nService i18nService = inputFormTag.getI18nService();

            if (i18nService != null) {
               String accessKeyValue = i18nService.getMessage(newAccessKey);

               if (accessKeyValue != null) {
                  aBuffer.append(" accesskey=\"");
                  aBuffer.append(accessKeyValue);
                  aBuffer.append("\"");
               }

               if (inTag instanceof AbstractFieldTag) {
                  AbstractFieldTag abstractFieldTag = (AbstractFieldTag) inTag;
                  abstractFieldTag.setAccesskey(accessKeyValue);
               }
            }
         }
      }

      return aBuffer;
   }

   /**
    * Afegeix el tooltip.
    * @author XES
    */
   static void displayTooltip(StringBuffer buffer, AbstractLayoutFieldTag inTag)
      throws JspException {
      //	Si tip definido mostrar a href con overlib
      if (inTag instanceof FieldTag) {
         FieldTag inputFormTag = (FieldTag) inTag;

         String tooltipKey = inputFormTag.getTooltipKey();
         String tooltipOptions = inputFormTag.getTooltipOptions();
         String tooltipTitleKey = inputFormTag.getTooltipTitleKey();

         if (tooltipKey != null) {
            String tooltipMessage = LayoutUtils.getLabel(inTag.getPageContext(),
                  inTag.getBundle(), tooltipKey, null, false);

            buffer.append("<script type=\"text/javascript\">");
            buffer.append("new CanigoFieldTag.Tooltip({");
            buffer.append(" source: \"" + inputFormTag.getStyleId() + "\",");
            buffer.append(" tooltipMessage: \"" + tooltipMessage + "\"");

            if (tooltipTitleKey != null) {
               String tooltipTitleMessage = LayoutUtils.getLabel(inTag.getPageContext(),
                     inTag.getBundle(), tooltipTitleKey, null, false);

               buffer.append(",");
               buffer.append("tooltipTitleMessage:\"" + tooltipTitleMessage +
                  "\"");
            }

            if (tooltipOptions != null) {
            }

            buffer.append("});");
            buffer.append("</script>");
         }
      }
   }
}
