/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.ServicesTagHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.util.BasicFieldHelper;
import net.gencat.ctti.canigo.services.web.taglib.Constants;
import net.gencat.ctti.canigo.services.web.taglib.FieldTag;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;

import org.apache.struts.taglib.TagUtils;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;


/**
 * <p>Definici� de les propietats del Tag TextFieldTag.</p>
 *
 * @author XES
 *
 * @see fr.improve.struts.taglib.layout.field.TextFieldTag
 *
 * @since 1.0
 *
 * <p>Revision 1.7  2007/07/16 08:45:51  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]</p>
 *
 * <p>Revision 1.6  2007/07/11 12:34:47  msabates
 * Canvis efectuats per la incid�ncia CAN-138</p>
 *
 * <p>Revision 1.5  2007/05/23 10:47:40  msabates
 * Cap�alera</p>
 *
 * <p>Revision 1.1.1.1.2.1  2007/05/18 10:49:41  fernando.vaquero
 * *** empty log message ***</p>
 *
 * <p>Revision 1.1.1.1  2007/05/15 13:53:20  fernando.vaquero
 * Importacio canigo 2.0</p>
 *
 * <p>Revision 1.4  2007/05/15 10:19:03  msabates
 * Jalopy</p>
 *
 * <p>Revision 1.3  2007/04/23 11:13:41  msabates
 * Canvis que estaven a la v1.4</p>
 *
 * <p>Revision 1.2  2007/04/20 09:49:21  msabates
 * Canvis que estaven a la v1.4</p>
 *
 * <p>Revision 1.28  2007/02/12 11:46:11  evidal
 * EVC: added version 1.2 changes.</p>
 *
 * <p>Revision 1.27.4.1  2007/02/07 19:34:08  evidal
 * EVC: version 1.2 -> autoimported scripts.</p>
 *
 * <p>Revision 1.27  2006/11/16 17:00:31  mmateos
 * author: evidal:</p>
 *
 * <p>Revision 1.27  2006/09/15 08:22:20  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.26  2006/09/06 17:07:57  crico
 * correcci� errors</p>
 *
 * <p>Revision 1.25  2006/08/14 09:17:44  crico
 * *** empty log message ***</p>
 *
 * <p>Revision 1.24  2006/08/11 16:30:24  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.23  2006/08/11 15:15:21  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.22  2006/08/11 14:15:39  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.21  2006/07/27 12:43:15  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.19  2006/07/26 13:38:26  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.18  2006/07/20 14:29:02  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.17  2006/07/14 13:38:38  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.16  2006/07/12 14:02:41  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.15  2006/07/10 13:44:37  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.14  2006/07/07 13:46:32  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.13  2006/07/06 16:04:59  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.12  2006/07/03 14:44:11  evidal
 * *** empty log message ***<p>
 *
 * <p>Revision 1.11  2006/06/30 14:50:27  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.10  2006/06/29 14:23:32  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.9  2006/06/28 13:42:07  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.8  2006/06/20 10:45:42  evidal
 * EVC: tagConfiguration not required.</p>
 *
 * <p>Revision 1.7  2006/02/23 18:30:44  xescuder
 * XES: Improvements on documentation and using tags properties
 * directly from jsps</p>
 *
 */
public class TextFieldTag extends fr.improve.struts.taglib.layout.field.TextFieldTag
   implements net.gencat.ctti.canigo.services.web.taglib.TextFieldTag {
   /**
    * Serial version uid.
    */
   private static final long serialVersionUID = -3712700108530449188L;

   /**
   * Posici� horitzontal del cursor en el camp.
   */
   public static final String LEFT_KEY_POSITION = "left";

   /**
    * Posici� vertical del cursor en el camp.
    */
   public static final String TOP_KEY_POSITION = "top";

   /**
    * Mostra el camp com obligatori.
    */
   private static final String REQUIRED_ATTRIBUTE = " required";

   /**
   * Imported scripts flag.
   */
   private static final String MASK_IMPORTED_SCRIPTS = "__mask_imported_scripts__";

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    */
   private I18nService i18nService;

   /**
    * Llista conversions: uppercase, lowercase, trim ...
    * Tots han de estar separats per comes
    */
   private String convertTo = null;

   /**
    * Camps dependents.
    */
   private String dependentFields;

   /**
    * Estil textField en si es produeix un error.
    */
   private String errorClass;

   /**
    * Nom del camp internacionalitzat.
    */
   private String errorKey;

   /**
    * Identificador de l' icona.
    */
   private String iconStyleId;

   /**
    * Div a mostrar quan es fa petici� AJAX.
    */
   private String indicator;

   /**
    * Key position.
    */
   private String keyPosition = LEFT_KEY_POSITION;

   /**
    * Style class defined for key of field (canigo).
    */
   private String keyStyleClass = null;

   /**
    * M�scara que es vol aplicar al camp.
    */
   private String mask;

   /**
    * Tipus de m�scara que es vol aplicar: text, date, number.
    */
   private String maskType;

   /**
    * Pot ser ICON, TEXT.
    */
   private String sourceErrorTooltip;

   /**
    * Div amb el text d'error.
    */
   private String textErrorStyleId;

   /**
    * Clau del literal del missatge a mostrar dins el tooltip.
    */
   private String tooltipKey = null;

   /**
    * Opcions aplicades segons la implementaci� (en el cas actual sota DOM
    * Tooltip).
    */
   private String tooltipOptions = null;

   /**
    * Clau del literal a mostrar si volem mostrar un t�tol com a cap�alera del
    * tooltip.
    */
   private String tooltipTitleKey = null;

   /**
    * Tipus de validaci� que volem mostrar quan salta la validaci�.
    * valors possibles: ICON,TOOLTIP,CHANGESTYLE,TEXTERROR
    */
   private String validationFieldMessageMode;

   /**
    * Funci� de presentaci�.
    */
   private String validationMessageFunction;

   /**
    * validacions pel camp.
    */
   private String validations;

   /**
    * Refer�ncia al servei de validaci�.
    */
   private ValidationService validationService;

   /**
    * Show an error next to the field.
    */
   private boolean fieldErrorDisplayed = true;

   /**
    * Use autotab when number of characters entered by user.
    *
    */
   private boolean isAutoTab = false;

   /**
    * Select on focus.
    */
   private boolean selectOnFocus = true;

   /**
    * Mostrar calendari d'edici� de data.
    */
   private boolean showCalendar = false;

   /**
    * Si layout=false s'ha de cridar a la generaci� de la etiqueta.
    */
   protected boolean doBeforeValue() throws javax.servlet.jsp.JspException {
      super.doBeforeValue();

      // If no layout specified, we have to add manually label
      if (!isLayout()) {
         BasicFieldHelper.displayLabel(this);
      }

      return true;
   }

   /**
    * Documentaci�.
    */
   protected void initDynamicValues() {
      TagUtil.copyConfiguration(this);
      super.initDynamicValues();
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doStartLayoutTag() throws JspException {
      // Set to refresh mode and other calculated attributes 
      // (computeDisplayMode)
      // (doStartTag in Struts Layout has been defined final!!!!)
      //initDynamicValues();

      // EVC: import tag scripts if not imported yet.
      HttpServletRequest request = (HttpServletRequest) super.pageContext.getRequest();
      HttpServletResponse response = (HttpServletResponse) super.pageContext.getResponse();

      if ((request.getAttribute(MASK_IMPORTED_SCRIPTS) == null)) {
         request.setAttribute(MASK_IMPORTED_SCRIPTS, Constants.IMPORTED);

         TagUtils tagUtils = TagUtils.getInstance();
         tagUtils.write(super.pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() +
            response.encodeURL("/scripts/masks/masks.js") + "\"></script>\n");
      }

      if (this.getIconStyleId() != null) {
         this.iconStyleId = (String) ExpressionEvaluatorManager.evaluate("iconStyleId",
               this.iconStyleId, String.class, this, pageContext);
      }

      if (this.getTextErrorStyleId() != null) {
         this.textErrorStyleId = (String) ExpressionEvaluatorManager.evaluate("textErrorStyleId",
               this.textErrorStyleId, String.class, this, pageContext);
      }

      if (this.getDependentFields() != null) {
         this.dependentFields = (String) ExpressionEvaluatorManager.evaluate("dependentFields",
               this.dependentFields, String.class, this, pageContext);
      }

      if (this.getValidations() != null) {
         this.validations = (String) ExpressionEvaluatorManager.evaluate("validations",
               this.validations, String.class, this, pageContext);

         if (this.getErrorKey() == null) {
            throw new JspException("The field Tag " + this.getProperty() +
               " must to define the errorKey");
         }

         if ((this.getValidationMessageFunction() == null) &&
               (this.getValidationFieldMessageMode() == null) &&
               (this.getValidations().indexOf("ONCHANGE") != -1)) {
            throw new JspException("The field Tag " + this.getProperty() +
               " must to define the validationFieldMessageMode or the validateMessageFunction");
         }
      }

      if (this.getIndicator() != null) {
         this.indicator = (String) ExpressionEvaluatorManager.evaluate("indicator",
               this.indicator, String.class, this, pageContext);
      }

      if ((this.key == null) && isLayout()) {
         throw new JspException("No key defined for tag \"" +
            this.getStyleId() + "\" with layout true.");
      }

      TextFieldTagHelper.appendBehaviours(this);

      if ((this.getValidationFieldMessageMode() != null) &&
            !this.getValidationFieldMessageMode().equals("")) {
         TextFieldTagHelper.getItemsForm(this);
      }

      if ((this.validations != null) && !this.validations.equals("")) {
         if (this.validations.toUpperCase().indexOf("ONCHANGE") != -1) {
            String validacions = null;

            if (this.getValidations().toUpperCase().indexOf("ONSUBMIT") != -1) {
               int fin = this.getValidations().toUpperCase().indexOf("ONSUBMIT");
               String valOnchange = this.getValidations().substring(0, fin);
               validacions = valOnchange.substring(valOnchange.lastIndexOf("(") +
                     1, valOnchange.lastIndexOf(")"));
            } else {
               int ini = this.getValidations().lastIndexOf("(");
               int fin = this.getValidations().length() - 1;
               validacions = this.getValidations().substring(ini + 1, fin);
            }

            this.setOnchange("javascript:validateField(\'" + validacions +
               "\',\'" + this.getProperty() + "\',\'" + this.getValue() +
               "\',\'" + this.getValidationFieldMessageMode() + "\',\'" +
               this.getSourceErrorTooltip() + "\',\'" + this.getIconStyleId() +
               "\',\'" + this.getTextErrorStyleId() + "\',\'" +
               this.getErrorClass() + "\',\'" +
               this.getValidationMessageFunction() + "\',\'" +
               this.getDependentFields() + "\',\'" + this.getErrorKey() +
               "\',\'" + this.getIndicator() + "\');");

            if (validacions.indexOf("required") != -1) {
               //BasicFieldHelper.displayRequired(buffer, aTextFieldTag);
               if (this instanceof FieldTag) {
                  FieldTag fieldTag = (FieldTag) this;
                  fieldTag.setStyleClass(((fieldTag.getStyleClass() != null)
                     ? fieldTag.getStyleClass() : "") + REQUIRED_ATTRIBUTE);
               }
            }
         }

         //validaciones para el submit
         if (this.validations.toUpperCase().indexOf("ONSUBMIT") != -1) {
            TextFieldTagHelper.guardarValidacioSubmit(this);
         }
      }

      //        this.setLayout(false);

      // print input before apply the mask
      int ret = super.doStartLayoutTag();

      if (this.mask != null) {
         StringBuffer script = new StringBuffer();
         script.append("<script type=\"text/javascript\">\n");

         if ((this.maskType != null) &&
               (this.maskType.toLowerCase().equals("number"))) {
            script.append("new Mask(\"" + this.mask +
               "\",\"number\").attach($('" + this.styleId + "'));");
         } else if ((this.maskType != null) &&
               (this.maskType.toLowerCase().equals("date"))) {
            script.append("new Mask(\"" + this.mask +
               "\",\"date\").attach($('" + this.styleId + "'));");
         } else {
            script.append("new Mask(\"" + this.mask + "\").attach($('" +
               this.styleId + "'));");
         }

         script.append("\n</script>");

         JspWriter writer = pageContext.getOut();

         try {
            writer.println(script);
         } catch (IOException e) {
            throw new JspException(e.getMessage());
         }
      }

      return ret;
   }

   /**
    * At end of tag add behaviours based in Ajax
    * In this case only used if edit mode
    */
   protected int doEndEditMode() throws JspException {
      int ret = super.doEndEditMode();
      TextFieldTagHelper.appendCalendar(this, i18nService, validationService);

      return ret;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @return I18nService
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Posici� del text.
    *
    * @return String
    */
   public String getKeyPosition() {
      return keyPosition;
   }

   /**
    * Poscici� del text.
    *
    * @param keyPosition String
    */
   public void setKeyPosition(String keyPosition) {
      this.keyPosition = keyPosition;
   }

   /**
    * Estil definit pel text o camp.
    *
    * @return String
    */
   public String getKeyStyleClass() {
      return keyStyleClass;
   }

   /**
    * Estil definit pel text o camp.
    *
    * @param keyStyleClass String
    */
   public void setKeyStyleClass(String keyStyleClass) {
      this.keyStyleClass = keyStyleClass;
   }

   /**
    * Llista conversions: uppercase, lowercase, trim ...
    * Tots han de estar separats per comes
    *
    * @return String
    */
   public String getConvertTo() {
      return convertTo;
   }

   /**
    * Llista conversions: uppercase, lowercase, trim ...
    * Tots han de estar separats per comes
    *
    * @param convertTo String
    */
   public void setConvertTo(String convertTo) {
      this.convertTo = convertTo;
   }

   /**
    * Autotabulaci� del camp.
    *
    * @return boolean
    */
   public boolean isAutoTab() {
      return isAutoTab;
   }

   /**
    * Autotabulaci� del camp.
    *
    * @param isAutotab boolean
    */
   public void setAutoTab(boolean isAutotab) {
      this.isAutoTab = isAutotab;
   }

   /**
    * �ndex de tabulaci�.
    *
    * @return String
    */
   public String getTabIndex() {
      return getTabindex();
   }

   /**
    * �ndex de tabulaci�.
    *
    * @param tabIndex String
    */
   public void setTabIndex(String tabIndex) {
      setTabindex(tabIndex);
   }

   /**
    * Clau del literal del missatge a mostrar dins el tooltip.
    *
    * @return String
    */
   public String getTooltipKey() {
      return tooltipKey;
   }

   /**
    * Clau del literal del missatge a mostrar dins el tooltip.
    *
    * @param tooltipKey String
    */
   public void setTooltipKey(String tooltipKey) {
      this.tooltipKey = tooltipKey;
   }

   /**
    * Opcions aplicades segons la implementaci� (en el cas actual sota DOM
    * Tooltip).
    *
    * @return String
    */
   public String getTooltipOptions() {
      return tooltipOptions;
   }

   /**
    * Opcions aplicades segons la implementaci� (en el cas actual sota DOM
    * Tooltip).
    *
    * @param tooltipOptions String
    */
   public void setTooltipOptions(String tooltipOptions) {
      this.tooltipOptions = tooltipOptions;
   }

   /**
    * Clau del literal a mostrar si volem mostrar un t�tol com a cap�alera del
    * tooltip.
    *
    * @return String
    */
   public String getTooltipTitleKey() {
      return tooltipTitleKey;
   }

   /**
    * Clau del literal a mostrar si volem mostrar un t�tol com a cap�alera del
    * tooltip.
    *
    * @param tooltipTitleKey String
    */
   public void setTooltipTitleKey(String tooltipTitleKey) {
      this.tooltipTitleKey = tooltipTitleKey;
   }

   /**
    * Mostra un error a continuaci� del camp.
    *
    * @return boolean
    */
   public boolean isFieldErrorDisplayed() {
      return fieldErrorDisplayed;
   }

   /**
    * Mostra un error a continuaci� del camp.
    *
    * @param fieldErrorDisplayed boolean
    */
   public void setFieldErrorDisplayed(boolean fieldErrorDisplayed) {
      this.fieldErrorDisplayed = fieldErrorDisplayed;
   }

   /**
    * Liberar tots els camps configurats per tal de no copiar en els
    * pr�xims tags.
    *
    * @author XES
    */
   public void release() {
      super.release();
      reset();
   }

   /**
    * Release all configured fields
    * in order to not copy to next tag
    *
    * Some properties are not released correctly by Struts Layout
    * Release now
    * @author XES
    */
   protected void reset() {
      super.reset();
      value = null;
      accesskey = null;
      keyPosition = LEFT_KEY_POSITION;
      key = null;
      keyStyleClass = null;
      i18nService = null;
      convertTo = null;
      isAutoTab = false;
      tooltipKey = null;
      tooltipOptions = null;
      tooltipTitleKey = null;
      selectOnFocus = true;
      showCalendar = false;
      fieldErrorDisplayed = true;
      styleId = null;
      validations = null;
      validationFieldMessageMode = null;
      validationMessageFunction = null;
      sourceErrorTooltip = null;
      iconStyleId = null;
      textErrorStyleId = null;
      errorKey = null;
      indicator = null;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @param validationService ValidationService
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * Mostra el camp com obligatori.
    *
    * @param isRequired boolean
    */
   public void setRequired(boolean isRequired) {
      setIsRequired(Boolean.toString(isRequired));
   }

   /**
    * Defineix si amb el focus es selecciona tot el component.
    *
    * @return boolean
    */
   public boolean isSelectOnFocus() {
      return selectOnFocus;
   }

   /**
    * Defineix si el amb el focus es selecciona tot el component.
    *
    * @param selectedOnFocus boolean
    */
   public void setSelectOnFocus(boolean selectedOnFocus) {
      this.selectOnFocus = selectedOnFocus;
   }

   /**
    * Mostrar calendari d'edici� de data.
    *
    * @return boolean
    */
   public boolean isShowCalendar() {
      return showCalendar;
   }

   /**
    * Mostrar calendari d'edici� de data.
    *
    * @param showCalendar boolean
    */
   public void setShowCalendar(boolean showCalendar) {
      this.showCalendar = showCalendar;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Tipus de validaci� que volem mostrar quan salta la validaci�.
    * valors possibles: ICON,TOOLTIP,CHANGESTYLE,TEXTERROR
    *
    * @return String
    */
   public String getValidationFieldMessageMode() {
      return validationFieldMessageMode;
   }

   /**
    * Tipus de validaci� que volem mostrar quan salta la validaci�.
    * valors possibles: ICON,TOOLTIP,CHANGESTYLE,TEXTERROR
    *
    * @param validationFieldMessageMode String
    */
   public void setValidationFieldMessageMode(String validationFieldMessageMode) {
      this.validationFieldMessageMode = validationFieldMessageMode;
   }

   /**
    * Camps dependents.
    *
    * @return String
    */
   public String getDependentFields() {
      return dependentFields;
   }

   /**
    * Funci� de presentaci�.
    *
    * @param dependentFields String
    */
   public void setDependentFields(String dependentFields) {
      this.dependentFields = dependentFields;
   }

   /**
    * Funci� de presentaci�.
    *
    * @return String
    */
   public String getValidationMessageFunction() {
      return validationMessageFunction;
   }

   /**
    * Documentaci�.
    *
    * @param validateMessageFunction String
    */
   public void setValidationMessageFunction(String validateMessageFunction) {
      this.validationMessageFunction = validateMessageFunction;
   }

   /**
    * Validacions pel camp.
    *
    * @return String
    */
   public String getValidations() {
      return validations;
   }

   /**
    * Validacions pel camp.
    *
    * @param validations String
    */
   public void setValidations(String validations) {
      this.validations = validations;
   }

   /**
    * Tipus tooltip en error.
    *
    * @return String
    */
   public String getSourceErrorTooltip() {
      return sourceErrorTooltip;
   }

   /**
    * Tipus tooltip en error.
    *
    * @param sourceErrorTooltip String
    */
   public void setSourceErrorTooltip(String sourceErrorTooltip) {
      this.sourceErrorTooltip = sourceErrorTooltip;
   }

   /**
    * Estil de la classe quan est� en error.
    *
    * @return String
    */
   public String getErrorClass() {
      return errorClass;
   }

   /**
    * Estil de la classe quan est� en error.
    *
    * @param errorClass String
    */
   public void setErrorClass(String errorClass) {
      this.errorClass = errorClass;
   }

   /**
    * Identificador de l' icona.
    *
    * @return String
    */
   public String getIconStyleId() {
      return iconStyleId;
   }

   /**
    * Identificador de l' icona.
    *
    * @param iconStyleId String
    */
   public void setIconStyleId(String iconStyleId) {
      this.iconStyleId = iconStyleId;
   }

   /**
    * Text d'error
    *
    * @return String
    */
   public String getTextErrorStyleId() {
      return textErrorStyleId;
   }

   /**
    * Text d'error
    *
    * @param textErrorStyleId String
    */
   public void setTextErrorStyleId(String textErrorStyleId) {
      this.textErrorStyleId = textErrorStyleId;
   }

   /**
    * Nom del camp internacionalitzat.
    *
    * @return String
    */
   public String getErrorKey() {
      return errorKey;
   }

   /**
    * Nom del camp internacionalitzat.
    *
    * @param errorKey String
    */
   public void setErrorKey(String errorKey) {
      this.errorKey = errorKey;
   }

   /**
    * El que es mostra quan es fa petici� AJAX.
    *
    * @return String
    */
   public String getIndicator() {
      return indicator;
   }

   /**
    * El que es mostra quan es fa petici� AJAX.
    *
    * @param indicator String
    */
   public void setIndicator(String indicator) {
      this.indicator = indicator;
   }

   /**
    * Permet injectar serveis del contenidor d' spring.
    *
    * @param services String
    *
    * @throws JspException
    */
   public void setServices(String services) throws JspException {
      ServicesTagHelper.setServices(services, pageContext, this);
   }

   /**
    * M�scara que es vol aplicar al camp.
    *
    * @return String
    */
   public String getMask() {
      return mask;
   }

   /**
    * M�scara que es vol aplicar al camp.
    *
    * @param mask String
    */
   public void setMask(String mask) {
      this.mask = mask;
   }

   /**
    * Tipus de m�scara que es vol aplicar: text, date, number.
    *
    * @return String
    */
   public String getMaskType() {
      return maskType;
   }

   /**
    * Tipus de m�scara que es vol aplicar: text, date, number.
    *
    * @param maskType String
    */
   public void setMaskType(String maskType) {
      this.maskType = maskType;
   }
}
