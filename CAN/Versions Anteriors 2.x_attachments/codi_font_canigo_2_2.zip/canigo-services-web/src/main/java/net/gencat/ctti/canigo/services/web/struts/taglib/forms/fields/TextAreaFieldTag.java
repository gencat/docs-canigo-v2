/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields;

import java.util.Properties;

import javax.servlet.jsp.JspException;

import fr.improve.struts.taglib.layout.field.TextareaFieldTag;
import fr.improve.struts.taglib.layout.util.LayoutUtils;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.ServicesTagHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.TextAreaFieldTagHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.util.BasicFieldHelper;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;


/**
 * <p>Definici� de les propietats del Tag TextAreaFieldTag.</p>
 *
 * @author XES
 *
 * @version Versi� $Revision: 1.7 $ $Date: 2007/07/25 11:10:34 $
 *
 * @see
 *
 * @since 1.0
 *
 * <p>$Log: TextAreaFieldTag.java,v $
 * <p>Revision 1.7  2007/07/25 11:10:34  cbernal
 * <p>Revisi� Javadoc
 * <p>
 * Revision 1.6  2007/07/16 08:45:51  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]</p>
 *
 * <p>Revision 1.5  2007/05/23 10:47:40  msabates
 * Cap�alera</p>
 *
 * <p>Revision 1.1.1.1.2.1  2007/05/18 10:49:41  fernando.vaquero
 * *** empty log message ***</p>
 *
 * <p>Revision 1.1.1.1  2007/05/15 13:52:40  fernando.vaquero
 * Importacio canigo 2.0</p>
 *
 * <p>Revision 1.4  2007/05/15 10:19:03  msabates
 * Jalopy</p>
 *
 * <p>Revision 1.3  2007/04/23 11:13:41  msabates
 * Canvis que estaven a la v1.4</p>
 *
 * <p>Revision 1.2  2007/04/20 09:49:21  msabates
 * Canvis que estaven a la v1.4</p>
 *
 * <p>Revision 1.10  2007/03/21 11:42:45  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.9.2.1  2007/02/28 17:12:23  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.9  2007/02/20 14:41:58  evidal
 * EVC: merging 1.0 & 1.1.</p>
 *
 * <p>Revision 1.8  2006/11/16 16:58:21  mmateos
 * author: evidal:</p>
 *
 * <p>Revision 1.8  2006/08/11 16:30:24  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.7  2006/06/19 14:22:02  evidal
 * versio de partida del 20%</p>
 *
 * <p>Revision 1.6.2.1  2006/03/01 09:37:56  mmateos
 * MMR: corregido bug de error JS con tinyMCE y IE</p>
 *
 * <p>Revision 1.6  2006/02/24 13:53:05  xescuder
 * XES: Added behaviour to set properties from jsp in adition
 * of configuration files</p>
 *
 */
public class TextAreaFieldTag extends TextareaFieldTag implements net.gencat.ctti.canigo.services.web.taglib.TextAreaFieldTag {
   /**
    *
    */
   private static final long serialVersionUID = 6966137640929873852L;

   /**
    * I18nService
    */
   private I18nService i18nService;

   /**
    * Decorator properties. Now based on 'TinyMCE'
    */
   private Properties decoratorProperties = new Properties();

   /**
    * List of conversions: uppercase, lowercase, trim ...
    * All they have to be separated by commas
    */
   private String convertTo = null;

   /**
   * Style class defined for key of field (ctti)
   */
   private String keyStyleClass = null;

   /**
    * Tooltip attributes
    */
   private String tooltipKey = null;

   /**
    * Documentaci�.
    */
   private String tooltipOptions = null;

   /**
    * Documentaci�.
    */
   private String tooltipTitleKey = null;

   /**
    * ValidationService
    */
   private ValidationService validationService;

   /**
    * Show an error next to the field
    */
   private boolean fieldErrorDisplayed = true;

   /**
    * Documentaci�.
    */
   private boolean isAutoTab = false;

   /**
    * Documentaci�.
    */
   private boolean selectOnFocus = true;

   /**
    * Creates a new TextAreaFieldTag object.
    */
   public TextAreaFieldTag() {
      super();
   }

   /**
        * In case of layout=false we have to call to generation of label
        */
   protected boolean doBeforeValue() throws javax.servlet.jsp.JspException {
      super.doBeforeValue();

      // If no layout specified, we have to add manually label
      if (!isLayout()) {
         BasicFieldHelper.displayLabel(this);
      }

      return true;
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doStartLayoutTag() throws JspException {
      TagUtil.copyConfiguration(this);

      // Set to refresh mode and other calculated attributes 
      // (computeDisplayMode)
      // (doStartTag in Struts Layout has been defined final!!!!)
      initDynamicValues();

      // Initialize decorators
      TextAreaFieldTagHelper.appendBehaviours(this);

      //        TextAreaFieldTagHelper.appendDecorators(this);
      return super.doStartLayoutTag();
   }

   // EVC: fixed Inspect Mode showing tags bug.
   /**
    * Aconseguir el valor del camp.
    *
    * @return Object
    *
    * @throws JspException
    */
   protected Object getFieldValue() throws JspException {
      if (value != null) {
         return value;
      }

      return LayoutUtils.getBeanFromPageContext(pageContext, name, property);
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @param validationService ValidationService
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * Llista conversions: uppercase, lowercase, trim ...
    * Tots han de estar separats per comes
    *
    * @return String
    */
   public String getConvertTo() {
      return convertTo;
   }

   /**
    * Llista conversions: uppercase, lowercase, trim ...
    * Tots han de estar separats per comes
    *
    * @param convertTo String
    */
   public void setConvertTo(String convertTo) {
      this.convertTo = convertTo;
   }

   /**
    * Documentaci�.
    *
    * @return boolean
    */
   public boolean isFieldErrorDisplayed() {
      return fieldErrorDisplayed;
   }

   /**
    * Documentaci�.
    *
    * @param fieldErrorDisplayed boolean
    */
   public void setFieldErrorDisplayed(boolean fieldErrorDisplayed) {
      this.fieldErrorDisplayed = fieldErrorDisplayed;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @return I18nService
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Autotabulaci� del camp.
    *
    * @return boolean
    */
   public boolean isAutoTab() {
      return isAutoTab;
   }

   /**
    * Autotabulaci� del camp.
    *
    * @param isAutotab boolean
    */
   public void setAutoTab(boolean isAutoTab) {
      this.isAutoTab = isAutoTab;
   }

   /**
    * Estil definit pel text o camp.
    *
    * @return String
    */
   public String getKeyStyleClass() {
      return keyStyleClass;
   }

   /**
    * Estil definit pel text o camp.
    *
    * @param keyStyleClass String
    */
   public void setKeyStyleClass(String keyStyleClass) {
      this.keyStyleClass = keyStyleClass;
   }

   /**
    * Clau del literal del missatge a mostrar dins el tooltip.
    *
    * @return String
    */
   public String getTooltipKey() {
      return tooltipKey;
   }

   /**
    * Clau del literal del missatge a mostrar dins el tooltip.
    *
    * @param tooltipKey String
    */
   public void setTooltipKey(String tooltipKey) {
      this.tooltipKey = tooltipKey;
   }

   /**
    * Opcions aplicades segons la implementaci� (en el cas actual sota DOM
    * Tooltip).
    *
    * @return String
    */
   public String getTooltipOptions() {
      return tooltipOptions;
   }

   /**
    * Opcions aplicades segons la implementaci� (en el cas actual sota DOM
    * Tooltip).
    *
    * @param tooltipOptions String
    */
   public void setTooltipOptions(String tooltipOptions) {
      this.tooltipOptions = tooltipOptions;
   }

   /**
    * Clau del literal a mostrar si volem mostrar un t�tol com a cap�alera del
    * tooltip.
    *
    * @return String
    */
   public String getTooltipTitleKey() {
      return tooltipTitleKey;
   }

   /**
    * Clau del literal a mostrar si volem mostrar un t�tol com a cap�alera del
    * tooltip.
    *
    * @param tooltipTitleKey String
    */
   public void setTooltipTitleKey(String tooltipTitleKey) {
      this.tooltipTitleKey = tooltipTitleKey;
   }

   /**
    * Mostra el camp com obligatori.
    *
    * @param isRequired boolean
    */
   public void setRequired(boolean isRequired) {
      setIsRequired(Boolean.toString(isRequired));
   }

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getLocaleKey() {
      // TODO Auto-generated method stub
      return null;
   }

   /**
    * Documentaci�.
    *
    * @param localeKey String
    */
   public void setLocaleKey(String localeKey) {
      // TODO Auto-generated method stub
   }

   /**
    * �ndex de tabulaci�
    * Per discordancia amb Struts Layout el metode definid es getTabindex
    * i setTabindex per� l'atribut es tabIndex.
    *
    * @return String
    */
   public String getTabIndex() {
      return getTabindex();
   }

   /**
    * �ndex de tabulaci�.
    *
    * @param tabIndex String
    */
   public void setTabIndex(String tabIndex) {
      setTabindex(tabIndex);
   }

   /**
    * Defineix si el amb el focus es selecciona tot el component.
    *
    * @return boolean
    */
   public boolean isSelectOnFocus() {
      return selectOnFocus;
   }

   /**
    * Defineix si el amb el focus es selecciona tot el component.
    *
    * @param selectedOnFocus boolean
    */
   public void setSelectOnFocus(boolean selectedOnFocus) {
      this.selectOnFocus = selectedOnFocus;
   }

   /**
    * Aconsegueix les propietas del decorator.
    *
    * @return Properties
    */
   public Properties getDecoratorProperties() {
      return decoratorProperties;
   }

   /**
    * Metode per establir les propietas del decorator al JSP.
    *
    * @param decoratorProperties Properties
    */
   public void setDecoratorProperties(Properties decoratorProperties) {
      this.decoratorProperties = decoratorProperties;
   }

   /**
    * Metode per establir les propietas del decorator al JSP.
    *
    * @param aDecoratorProperties List of properties in String format
    *
    * @since 1.1
    */
   public void setDecoratorProperties(final String aDecoratorProperties)
      throws JspException {
      TagUtil.putProperties(decoratorProperties, aDecoratorProperties);
   }

   /**
    * Permet injectar serveis del contenidor d' spring.
    *
    * @param services String
    *
    * @throws JspException
    */
   public void setServices(String services) throws JspException {
      ServicesTagHelper.setServices(services, pageContext, this);
   }
}
