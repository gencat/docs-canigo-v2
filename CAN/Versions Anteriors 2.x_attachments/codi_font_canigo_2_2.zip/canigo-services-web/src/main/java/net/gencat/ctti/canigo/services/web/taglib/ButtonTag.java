/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.taglib;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTag;
import javax.servlet.jsp.tagext.BodyTagSupport;

import fr.improve.struts.taglib.layout.field.AbstractModeFieldTag;
import fr.improve.struts.taglib.layout.util.FormUtils;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.ServicesTagHelper;

import org.apache.struts.taglib.TagUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class ButtonTag extends BodyTagSupport implements BodyTag {
   /**
   * I18nService
   */
   private I18nService i18nService;

   /**
    * LogginService
    */
   private LoggingService logService;

   /**
    * Documentaci�.
    */
   private String accesskey;

   /**
    * Documentaci�.
    */
   private String dir;

   /**
    * Documentaci�.
    */
   private String lang;

   /**
    * Documentaci�.
    */
   private String mode;

   /**
    * Documentaci�.
    */
   private String onblur;

   /**
    * Documentaci�.
    */
   private String onchange;

   /**
    * Documentaci�.
    */
   private String onclick;

   /**
    * Documentaci�.
    */
   private String ondblclick;

   /**
    * Documentaci�.
    */
   private String onfocus;

   /**
    * Documentaci�.
    */
   private String onkeydown;

   /**
    * Documentaci�.
    */
   private String onkeypress;

   /**
    * Documentaci�.
    */
   private String onkeyup;

   /**
    * Documentaci�.
    */
   private String onmousedown;

   /**
    * Documentaci�.
    */
   private String onmousemove;

   /**
    * Documentaci�.
    */
   private String onmouseout;

   /**
    * Documentaci�.
    */
   private String onmouseover;

   /**
    * Documentaci�.
    */
   private String onmouseup;

   /**
    * Documentaci�.
    */
   private String property;

   /**
    * Documentaci�.
    */
   private String reqCode;

   /**
    * Documentaci�.
    */
   private String style;

   /**
    * Documentaci�.
    */
   private String styleClass;

   /**
    * Documentaci�.
    */
   private String styleId;

   /**
    * Documentaci�.
    */
   private String tabindex;

   /**
    * Documentaci�.
    */
   private String title;

   /**
    * Documentaci�.
    */
   private String type;

   /**
    * Documentaci�.
    */
   private String value;

   /**
    * Documentaci�.
    */
   private boolean cell = false;

   /**
    * Documentaci�.
    */
   private boolean disabled = false;

   //	private String reqCode;
   /**
    * Documentaci�.
    */
   private boolean display = true;

   /**
    * Creates a new ButtonTag object.
    */
   public ButtonTag() {
      super();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public int doStartTag() throws JspException {
      if (this.getLogService() != null) {
         this.getLogService().getLog(this.getClass())
             .debug("Begin doStartTag of ButtonTag...");
      }

      int lc_visible = FormUtils.computeVisibilityMode(pageContext, mode);

      switch (lc_visible) {
      case AbstractModeFieldTag.MODE_EDIT:
         display = true;

         break;

      case AbstractModeFieldTag.MODE_NODISPLAY:
         display = false;

         break;

      case AbstractModeFieldTag.MODE_DISABLED:
         display = true;
         disabled = true;

         break;

      case AbstractModeFieldTag.MODE_CELL:
         cell = true;

         break;
      }

      TagUtils tagUtils = TagUtils.getInstance();
      StringBuffer buffer = new StringBuffer();

      if (this.type == null) {
         this.type = "submit";
      }

      if (this.cell) {
         buffer.append("&nbsp;");
      } else {
         if (display) {
            buffer.append("<button name=\"" + this.styleId + "\"");

            if (this.getValue() != null) {
               buffer.append(" value=\"" + this.getValue() + "\"");
            }

            if (this.getStyle() != null) {
               buffer.append(" style=\"" + this.getStyle() + "\"");
            }

            if (this.getStyleClass() != null) {
               buffer.append(" styleClass=\"" + this.getStyleClass() + "\"");
            }

            if (this.getTabindex() != null) {
               buffer.append(" tabindex=\"" + this.getTabindex() + "\"");
            }

            if (this.getTitle() != null) {
               buffer.append(" title=\"" + this.getTitle() + "\"");
            }

            if (this.getLang() != null) {
               buffer.append(" lang=\"" + this.getLang() + "\"");
            }

            if (this.getDir() != null) {
               buffer.append(" dir=\"" + this.getLang() + "\"");
            }

            if (this.getOnblur() != null) {
               buffer.append(" onblur=\"" + this.getOnblur() + "\"");
            }

            if (this.getOnchange() != null) {
               buffer.append(" onchange=\"" + this.getOnchange() + "\"");
            }

            String tmpOnClick = "";

            if (this.getReqCode() != null) {
               tmpOnClick = "this.form.elements['reqCode'].value='" +
                  this.getReqCode() + "';";
            }

            if (this.getType() != null) {
               String tmpType = this.getType();

               if (getType().equalsIgnoreCase("CANCEL")) {
                  tmpType = "BUTTON";
                  tmpOnClick = "window.__diryFormWarning='false';" +
                     tmpOnClick;
               }

               buffer.append(" type=\"" + tmpType + "\"");
            }

            if ((this.getOnclick() != null) || (tmpOnClick.length() > 0)) {
               if (this.getOnclick() != null) {
                  tmpOnClick = tmpOnClick + this.getOnclick();
               }

               buffer.append(" onclick=\"" + tmpOnClick + "\"");
            }

            if (this.getOndblclick() != null) {
               buffer.append(" ondblclick=\"" + this.getOndblclick() + "\"");
            }

            if (this.getOnfocus() != null) {
               buffer.append(" onfocus=\"" + this.getOnfocus() + "\"");
            }

            if (this.getOnkeydown() != null) {
               buffer.append(" onkeydown=\"" + this.getOnkeydown() + "\"");
            }

            if (this.getOnkeypress() != null) {
               buffer.append(" onkeypress=\"" + this.getOnkeypress() + "\"");
            }

            if (this.getOnkeyup() != null) {
               buffer.append(" onkeyup=\"" + this.getOnkeyup() + "\"");
            }

            if (this.getOnmousedown() != null) {
               buffer.append(" onmousedown=\"" + this.getOnmousedown() + "\"");
            }

            if (this.disabled) {
               buffer.append(" disabled=\"true\"");
            }

            buffer.append(" >");
         }
      }

      tagUtils.write(this.pageContext, buffer.toString());

      if (this.getLogService() != null) {
         this.getLogService().getLog(this.getClass())
             .debug("End doStartTag of ButtonTag...");
      }

      if (display && !cell) {
         return EVAL_BODY_INCLUDE;
      } else {
         return SKIP_BODY;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public int doEndTag() throws JspException {
      if (this.getLogService() != null) {
         this.getLogService().getLog(this.getClass())
             .debug("Begin doEndTag of ButtonTag...");
      }

      if (display && !cell) {
         TagUtils tagUtils = TagUtils.getInstance();
         StringBuffer buffer = new StringBuffer();

         buffer.append("</button>");
         tagUtils.write(this.pageContext, buffer.toString());
      }

      if (this.getLogService() != null) {
         this.getLogService().getLog(this.getClass())
             .debug("End doEndTag of ButtonTag...");
      }

      return EVAL_PAGE;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public BodyContent getBodyContent() {
      return bodyContent;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getStyleId() {
      return styleId;
   }

   /**
    * Documentaci�.
    *
    * @param styleId Documentaci�
    */
   public void setStyleId(String styleId) {
      this.styleId = styleId;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getType() {
      return type;
   }

   /**
    * Documentaci�.
    *
    * @param type Documentaci�
    */
   public void setType(String type) {
      this.type = type;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getAccesskey() {
      return accesskey;
   }

   /**
    * Documentaci�.
    *
    * @param accesskey Documentaci�
    */
   public void setAccesskey(String accesskey) {
      this.accesskey = accesskey;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getDir() {
      return dir;
   }

   /**
    * Documentaci�.
    *
    * @param dir Documentaci�
    */
   public void setDir(String dir) {
      this.dir = dir;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getLang() {
      return lang;
   }

   /**
    * Documentaci�.
    *
    * @param lang Documentaci�
    */
   public void setLang(String lang) {
      this.lang = lang;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnblur() {
      return onblur;
   }

   /**
    * Documentaci�.
    *
    * @param onblur Documentaci�
    */
   public void setOnblur(String onblur) {
      this.onblur = onblur;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnchange() {
      return onchange;
   }

   /**
    * Documentaci�.
    *
    * @param onchange Documentaci�
    */
   public void setOnchange(String onchange) {
      this.onchange = onchange;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnclick() {
      return onclick;
   }

   /**
    * Documentaci�.
    *
    * @param onclick Documentaci�
    */
   public void setOnclick(String onclick) {
      this.onclick = onclick;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOndblclick() {
      return ondblclick;
   }

   /**
    * Documentaci�.
    *
    * @param ondblclick Documentaci�
    */
   public void setOndblclick(String ondblclick) {
      this.ondblclick = ondblclick;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnfocus() {
      return onfocus;
   }

   /**
    * Documentaci�.
    *
    * @param onfocus Documentaci�
    */
   public void setOnfocus(String onfocus) {
      this.onfocus = onfocus;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnkeydown() {
      return onkeydown;
   }

   /**
    * Documentaci�.
    *
    * @param onkeydown Documentaci�
    */
   public void setOnkeydown(String onkeydown) {
      this.onkeydown = onkeydown;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnkeypress() {
      return onkeypress;
   }

   /**
    * Documentaci�.
    *
    * @param onkeypress Documentaci�
    */
   public void setOnkeypress(String onkeypress) {
      this.onkeypress = onkeypress;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnkeyup() {
      return onkeyup;
   }

   /**
    * Documentaci�.
    *
    * @param onkeyup Documentaci�
    */
   public void setOnkeyup(String onkeyup) {
      this.onkeyup = onkeyup;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnmousedown() {
      return onmousedown;
   }

   /**
    * Documentaci�.
    *
    * @param onmousedown Documentaci�
    */
   public void setOnmousedown(String onmousedown) {
      this.onmousedown = onmousedown;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnmousemove() {
      return onmousemove;
   }

   /**
    * Documentaci�.
    *
    * @param onmousemove Documentaci�
    */
   public void setOnmousemove(String onmousemove) {
      this.onmousemove = onmousemove;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnmouseout() {
      return onmouseout;
   }

   /**
    * Documentaci�.
    *
    * @param onmouseout Documentaci�
    */
   public void setOnmouseout(String onmouseout) {
      this.onmouseout = onmouseout;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnmouseover() {
      return onmouseover;
   }

   /**
    * Documentaci�.
    *
    * @param onmouseover Documentaci�
    */
   public void setOnmouseover(String onmouseover) {
      this.onmouseover = onmouseover;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getOnmouseup() {
      return onmouseup;
   }

   /**
    * Documentaci�.
    *
    * @param onmouseup Documentaci�
    */
   public void setOnmouseup(String onmouseup) {
      this.onmouseup = onmouseup;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getProperty() {
      return property;
   }

   /**
    * Documentaci�.
    *
    * @param property Documentaci�
    */
   public void setProperty(String property) {
      this.property = property;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getStyle() {
      return style;
   }

   /**
    * Documentaci�.
    *
    * @param style Documentaci�
    */
   public void setStyle(String style) {
      this.style = style;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getStyleClass() {
      return styleClass;
   }

   /**
    * Documentaci�.
    *
    * @param styleClass Documentaci�
    */
   public void setStyleClass(String styleClass) {
      this.styleClass = styleClass;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getTabindex() {
      return tabindex;
   }

   /**
    * Documentaci�.
    *
    * @param tabindex Documentaci�
    */
   public void setTabindex(String tabindex) {
      this.tabindex = tabindex;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getTitle() {
      return title;
   }

   /**
    * Documentaci�.
    *
    * @param title Documentaci�
    */
   public void setTitle(String title) {
      this.title = title;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getValue() {
      return value;
   }

   /**
    * Documentaci�.
    *
    * @param value Documentaci�
    */
   public void setValue(String value) {
      this.value = value;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Documentaci�.
    *
    * @param service Documentaci�
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * Documentaci�.
    *
    * @param logService Documentaci�
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * Documentaci�.
    *
    * @param services Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public void setServices(String services) throws JspException {
      ServicesTagHelper.setServices(services, pageContext, this);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getMode() {
      return mode;
   }

   /**
    * Documentaci�.
    *
    * @param mode Documentaci�
    */
   public void setMode(String mode) {
      this.mode = mode;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isDisabled() {
      return disabled;
   }

   /**
    * Documentaci�.
    *
    * @param disabled Documentaci�
    */
   public void setDisabled(boolean disabled) {
      this.disabled = disabled;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getReqCode() {
      return reqCode;
   }

   /**
    * Documentaci�.
    *
    * @param reqCode Documentaci�
    */
   public void setReqCode(String reqCode) {
      this.reqCode = reqCode;
   }
}
