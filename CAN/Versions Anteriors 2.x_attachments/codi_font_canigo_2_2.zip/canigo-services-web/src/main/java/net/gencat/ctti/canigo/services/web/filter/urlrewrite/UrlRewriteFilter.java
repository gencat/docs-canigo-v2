/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.filter.urlrewrite;


/**
 * Copyright (c) 2005, Paul Tuckey
 * All rights reserved.
 *
 * Each copy or derived work must preserve the copyright notice and this
 * notice unmodified.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import java.net.InetAddress;
import java.net.UnknownHostException;

import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.tuckey.web.filters.urlrewrite.Conf;
import org.tuckey.web.filters.urlrewrite.RewrittenUrl;
import org.tuckey.web.filters.urlrewrite.ServerNameMatcher;
import org.tuckey.web.filters.urlrewrite.UrlRewriteWrappedResponse;
import org.tuckey.web.filters.urlrewrite.UrlRewriter;
import org.tuckey.web.filters.urlrewrite.utils.Log;
import org.tuckey.web.filters.urlrewrite.utils.NumberUtils;
import org.tuckey.web.filters.urlrewrite.utils.StringUtils;


/**
 * Based on the URLRewrite filter of tuckey project.
 * <p> See http://tuckey.org/urlrewrite/ for more information about URLRewrite filter. </p>
 * <p> The only difference between net.gencat.ctti.canigo.services.web.filter.urlrewrite.UrlRewriteFilter and <br>
 *     org.tuckey.web.filters.urlrewrite.UrlRewriteFilter is that net.gencat.ctti.canigo.services.web.filter.urlrewrite.UrlRewriteFilter <br>
 *     applies only when response hasn't been commited by a previous filter. <br>
 *     How org.tuckey.web.filters.urlrewrite.UrlRewriteFilter is a final class, it has completely been copied, and <br>
 *     control to watch if response has been commited is in the doFilter method. <br>
 *  </p>
 * @author Paul Tuckey
 * @version $Revision: 1.6 $ $Date: 2007/07/16 08:45:50 $
 * Revision 1.0  2006/08/31 09:40:30  mmasquefa
 * MMO: Added control to watch if response has been commited.
 */
public class UrlRewriteFilter implements Filter {
   /**
    * Documentaci�.
    */
   private static Log log = Log.getLog(UrlRewriteFilter.class);

   // next line is replaced by ant on compile
   /**
    * Documentaci�.
    */
   public static final String VERSION = "3.0 build 5769";

   /**
    * Documentaci�.
    */
   public static final String DEFAULT_WEB_CONF_PATH = "/WEB-INF/urlrewrite.xml";

   /**
    * Documentaci�.
    */
   private static final String DEFAULT_STATUS_ENABLED_ON_HOSTS = "localhost, local, 127.0.0.1";

   /**
    * Documentaci�.
    */
   private Conf confLastLoaded = null;

   /**
    * Documentaci�.
    */
   private ServerNameMatcher statusServerNameMatcher;

   /**
    *
    */
   private ServletContext context = null;

   /**
    * path to conf file.
    */
   private String confPath;

   /**
    * Documentaci�.
    */
   private String confPathStr = "";

   /**
    * Documentaci�.
    */
   private String confReloadCheckIntervalStr = "";

   /**
    * Documentaci�.
    */
   private String statusEnabledConf = "";

   /**
    * Documentaci�.
    */
   private String statusEnabledOnHosts = "";

   /**
    * Documentaci�.
    */
   private String statusPath = "/rewrite-status";

   /**
    * Documentaci�.
    */
   private String statusPathConf = "";

   /**
    * The conf for this filter.
    */
   private UrlRewriter urlRewriter = null;

   /**
    * A user defined setting that can enable conf reloading.
    */
   private boolean confReloadCheckEnabled = false;

   /**
    * Flag to make sure we don't bog the filter down during heavy load.
    */
   private boolean confReloadInProgress = false;

   /**
    * Documentaci�.
    */
   private boolean statusEnabled = true;

   /**
    * A user defined setting that says how often to check the conf has changed.
    */
   private int confReloadCheckInterval = 0;

   /**
    * The last time that the conf file was loaded.
    */
   private long confLastLoad = 0;

   /**
    * Documentaci�.
    */
   private long confReloadLastCheck = 30;

   /**
    * Init is called automatically by the application server when it creates this filter.
    *
    * @param filterConfig The config of the filter
    */
   public void init(final FilterConfig filterConfig) {
      log.debug("filter init called");

      if (filterConfig == null) {
         log.error("unable to init filter as filter config is null");

         return;
      }

      log.debug(
         "init: calling destroy just in case we are being re-inited uncleanly");
      destroyActual();

      context = filterConfig.getServletContext();

      if (context == null) {
         log.error("unable to init as servlet context is null");

         return;
      }

      // set the conf of the logger to make sure we get the messages in context log
      Log.setConfiguration(filterConfig);

      // get init paramerers from context web.xml file
      this.confReloadCheckIntervalStr = filterConfig.getInitParameter(
            "confReloadCheckInterval");
      this.confPathStr = filterConfig.getInitParameter("confPath");
      this.statusPathConf = filterConfig.getInitParameter("statusPath");
      this.statusEnabledConf = filterConfig.getInitParameter("statusEnabled");
      this.statusEnabledOnHosts = filterConfig.getInitParameter(
            "statusEnabledOnHosts");

      initParametersFilter();

      loadConf();
   }

   /**
    * Documentaci�.
    */
   private void initParametersFilter() {
      //  confReloadCheckInterval (default to null)
      if (!StringUtils.isBlank(confReloadCheckIntervalStr)) {
         // convert to millis
         confReloadCheckInterval = 1000 * NumberUtils.stringToInt(confReloadCheckIntervalStr);

         if (confReloadCheckInterval < 0) {
            confReloadCheckEnabled = false;
            log.info("conf reload check disabled");
         } else if (confReloadCheckInterval == 0) {
            confReloadCheckEnabled = true;
            log.info("conf reload check performed each request");
         } else {
            confReloadCheckEnabled = true;
            log.info("conf reload check set to " +
               (confReloadCheckInterval / 1000) + "s");
         }
      } else {
         confReloadCheckEnabled = false;
      }

      if (!StringUtils.isBlank(confPathStr)) {
         confPath = StringUtils.trim(confPathStr);
      } else {
         confPath = DEFAULT_WEB_CONF_PATH;
      }

      log.debug("confPath set to " + confPath);

      // status enabled (default true)
      if ((statusEnabledConf != null) && !"".equals(statusEnabledConf)) {
         log.debug("statusEnabledConf set to " + statusEnabledConf);
         statusEnabled = "true".equals(statusEnabledConf.toLowerCase());
      }

      if (statusEnabled) {
         // status path (default /rewrite-status)
         if ((statusPathConf != null) && !"".equals(statusPathConf)) {
            statusPath = statusPathConf.trim();
            log.info("status display enabled, path set to " + statusPath);
         }
      } else {
         log.info("status display disabled");
      }

      if (StringUtils.isBlank(statusEnabledOnHosts)) {
         statusEnabledOnHosts = DEFAULT_STATUS_ENABLED_ON_HOSTS;
      } else {
         log.debug("statusEnabledOnHosts set to " + statusEnabledOnHosts);
      }

      statusServerNameMatcher = new ServerNameMatcher(statusEnabledOnHosts);
   }

   /**
    * Documentaci�.
    */
   private void loadConf() {
      String hostName = "";
      InetAddress localHost = null;
      String confPathHost = confPath;

      try {
         localHost = InetAddress.getLocalHost();
         hostName = new String(localHost.getHostName());
         confPathHost = confPath + "." + hostName;
      } catch (UnknownHostException e) {
         log.error("Error", e);
      }

      log.info("Loading conf file " + confPathHost);

      InputStream inputStream = context.getResourceAsStream(confPathHost);

      if (inputStream == null) {
         log.info("Conf file " + confPathHost + " does not exists. Trying " +
            confPath);
         inputStream = context.getResourceAsStream(confPath);
      }

      if (inputStream == null) {
         log.error("unable to find urlrewrite conf file at " + confPath);

         // set the writer back to null
         if (urlRewriter != null) {
            log.error("unloading existing conf");
            urlRewriter = null;
         }
      } else {
         Conf conf = new Conf(context, inputStream, confPath);

         if (log.isDebugEnabled()) {
            if (conf.getRules() != null) {
               log.debug("inited with " + conf.getRules().size() + " rules");
            }

            log.debug("conf is " + (conf.isOk() ? "ok" : "NOT ok"));
         }

         confLastLoaded = conf;

         if (conf.isOk()) {
            urlRewriter = new UrlRewriter(conf);
            log.info("loaded (conf ok)");
         } else {
            log.error("Conf failed to load");
            log.error("unloading existing conf");
            urlRewriter = null;
         }
      }
   }

   /**
    * Destroy is called by the application server when it unloads this filter.
    */
   public void destroy() {
      log.info("destroy called");
      destroyActual();
   }

   /**
    * Documentaci�.
    */
   public void destroyActual() {
      if (urlRewriter != null) {
         urlRewriter.destroy();
         urlRewriter = null;
      }

      context = null;
      confLastLoad = 0;
      confPath = DEFAULT_WEB_CONF_PATH;
      confReloadCheckEnabled = false;
      confReloadCheckInterval = 0;
      confReloadInProgress = false;
   }

   /**
    * The main method called for each request that this filter is mapped for.<br>
    * This method has been updated to control if response has been commited. <br>
    * In this case, filter doesn't modified the request and passes it to the next filter<br>
    * into the chain.
    *
    * @param request
    * @param response
    * @param chain
    * @throws IOException
    * @throws ServletException
    */
   public void doFilter(final ServletRequest request,
      final ServletResponse response, final FilterChain chain)
      throws IOException, ServletException {
      // check to see if the conf needs reloading
      long now = System.currentTimeMillis();

      if (confReloadCheckEnabled && !confReloadInProgress &&
            ((now - confReloadCheckInterval) > confReloadLastCheck)) {
         confReloadInProgress = true;
         confReloadLastCheck = now;

         log.debug("starting conf reload check");

         long confFileCurrentTime = getConfFileLastModified();

         if (confLastLoad < confFileCurrentTime) {
            // reload conf
            confLastLoad = System.currentTimeMillis();
            log.info("conf file modified since last load, reloading");
            loadConf();
         } else {
            log.debug("conf is not modified");
         }

         confReloadInProgress = false;
      }

      final HttpServletRequest hsRequest = (HttpServletRequest) request;
      final HttpServletResponse hsResponse = (HttpServletResponse) response;
      UrlRewriteWrappedResponse urlRewriteWrappedResponse = new UrlRewriteWrappedResponse(hsResponse,
            hsRequest, urlRewriter);

      // check for status request
      if (statusEnabled &&
            statusServerNameMatcher.isMatch(request.getServerName())) {
         String uri = hsRequest.getRequestURI();

         if (log.isDebugEnabled()) {
            log.debug("checking for status path on " + uri);
         }

         String contextPath = hsRequest.getContextPath();

         if ((uri != null) && uri.startsWith(contextPath + statusPath)) {
            showStatus(hsRequest, urlRewriteWrappedResponse);

            return;
         }
      }

      boolean requestRewritten = false;

      // Si hsResponse.isCommitted significa que aleshores la petici� inicial que ha arribat al servidor 
      // ja ha sigut resposta per un filtre anterior (per exemple per un filtre d'Acegi,molt probablement 
      // pel filtre d'autentificaci�).
      if ((urlRewriter != null) && !hsResponse.isCommitted()) {
         // process the request
         RewrittenUrl rewrittenUrl = urlRewriter.processRequest(hsRequest,
               urlRewriteWrappedResponse);

         //rewrittenUrl == null --> la URL no se ha de reescribir....                                                            
         if (rewrittenUrl != null) {
            requestRewritten = rewrittenUrl.doRewrite(hsRequest,
                  urlRewriteWrappedResponse, chain);
         }
      } else {
         if (log.isDebugEnabled()) {
            log.debug(
               "urlRewriter engine not loaded ignoring request (could be a conf file problem or response has already been commited by a previous filter)");
         }
      }

      // if no rewrite has taken place continue as normal
      if (!requestRewritten) {
         chain.doFilter(hsRequest, urlRewriteWrappedResponse);
      }
   }

   /**
    * Gets the last modified date of the conf file.
    *
    * @return time as a long
    */
   private long getConfFileLastModified() {
      File confFile = new File(context.getRealPath(DEFAULT_WEB_CONF_PATH));

      return confFile.lastModified();
   }

   /**
    * Show the status of the conf and the filter to the user.
    *
    * @param request
    * @param response
    * @throws java.io.IOException
    */
   private void showStatus(final HttpServletRequest request,
      final ServletResponse response) throws IOException {
      log.debug("showing status");

      Status status = new Status(confLastLoaded, this);
      status.displayStatusInContainer(request);

      response.setContentLength(status.getBuffer().length());

      final PrintWriter out = response.getWriter();
      out.write(status.getBuffer().toString());
      out.close();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isConfReloadCheckEnabled() {
      return confReloadCheckEnabled;
   }

   /**
    * The amount of seconds between reload checks.
    */
   public int getConfReloadCheckInterval() {
      return confReloadCheckInterval / 1000;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Date getConfReloadLastCheck() {
      return new Date(confReloadLastCheck);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isStatusEnabled() {
      return statusEnabled;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getStatusPath() {
      return statusPath;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isLoaded() {
      return urlRewriter != null;
   }
}
