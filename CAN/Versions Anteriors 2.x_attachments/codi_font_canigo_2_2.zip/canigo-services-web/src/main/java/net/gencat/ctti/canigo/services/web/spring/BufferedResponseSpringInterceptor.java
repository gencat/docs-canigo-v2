/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
/**

 */
package net.gencat.ctti.canigo.services.web.spring;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.gencat.ctti.canigo.services.web.displaytag.filter.BufferedResponseWrapper;
import net.gencat.ctti.canigo.services.web.displaytag.filter.BufferedResponseWrapper13Impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;
import org.springframework.web.servlet.HandlerAdapter;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleControllerHandlerAdapter;
import org.springframework.web.util.UrlPathHelper;


/**
 * <p>
 * </p>
 * <p>
 *
 * @version $Revision: 1.5 $ ($Author: msabates $)
 */
public class BufferedResponseSpringInterceptor implements HandlerInterceptor {
   /**
    * Documentaci�.
    */
   public static final String PARAMETER_EXPORTING = "__InterceptorParameterExporting__";

   /**
    * Documentaci�.
    */
   public static final String INTERCEPTOR_FORCED_REDIRECT = "__DisplayTagForcedRedirect__";

   /**
    * Logger.
    */
   static Log log = LogFactory.getLog(BufferedResponseSpringInterceptor.class);

   /**
    * Documentaci�.
    */
   private Map redirections = new HashMap();

   /**
    * Documentaci�.
    */
   private PathMatcher pathMatcher = new AntPathMatcher();

   /**
    * Documentaci�.
    */
   private UrlPathHelper urlPathHelper = new UrlPathHelper();

   {
      redirections.put("/**/*searchExportPDF*", "/pdfView.pdf");
   }

   /**
    * Documentaci�.
    *
    * @param urlPath Documentaci�
    *
    * @return Documentaci�
    */
   protected String lookupRedirection(String urlPath) {
      // direct match?
      String redirection = (String) this.redirections.get(urlPath);
      log.info("redirections map (" + urlPath + ")=" + redirection);

      if (redirection == null) {
         // pattern match?
         for (Iterator it = this.redirections.keySet().iterator();
               it.hasNext();) {
            String registeredPath = (String) it.next();
            log.info("registered path=" + registeredPath +
               " matchs vs. urlPath=" + urlPath + "?" +
               this.pathMatcher.match(registeredPath, urlPath));

            if (this.pathMatcher.match(registeredPath, urlPath)) {
               return (String) this.redirections.get(registeredPath);
            }
         }
      }

      log.info("Returning " + redirection);

      return redirection;
   }

   /**
    * @see HandlerInterceptor#preHandle(HttpServletRequest,HttpServletResponse,
    *      Object)
    */
   public boolean preHandle(HttpServletRequest request,
      HttpServletResponse response, Object handler) throws Exception {
      log.info("Looking redirection for " +
         this.urlPathHelper.getRequestUri(request) + "?" +
         request.getQueryString());

      String lookupPath = lookupRedirection(this.urlPathHelper.getRequestUri(
               request) + "?" + request.getQueryString());

      if (lookupPath == null) {
         return true;
      } else {
         if (getRedirect(request) != null) {
            // redirecting, do not evaluate
            return true;
         }
      }

      BufferedResponseWrapper wrapper = new BufferedResponseWrapper13Impl(response);

      log.info("handler is " + handler);

      HandlerAdapter handlerAdaptor = new SimpleControllerHandlerAdapter();

      // Here the original servlet is executed with a buffered response
      handlerAdaptor.handle(request, wrapper, handler);

      // now we want to check whether we were instructed to redirect by the
      // original servlet
      RequestDispatcher rd = request.getRequestDispatcher(lookupPath);

      if (rd != null) {
         //We want to prevent re-entry
         setRedirect(request, lookupPath);

         // we discard the buffered response, back to the real one for the
         // redirect to use
         rd.forward(request, response);
      }

      return false;
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param redirect Documentaci�
    */
   public static void setRedirect(ServletRequest request, String redirect) {
      request.setAttribute(INTERCEPTOR_FORCED_REDIRECT, redirect);
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    *
    * @return Documentaci�
    */
   public static String getRedirect(HttpServletRequest request) {
      return (String) request.getAttribute(INTERCEPTOR_FORCED_REDIRECT);
   }

   /**
    * @see HandlerInterceptor#postHandle(HttpServletRequest,HttpServletResponse,
    *      Object, ModelAndView)
    */
   public void postHandle(HttpServletRequest request,
      HttpServletResponse response, Object obj, ModelAndView modelAndView)
      throws Exception {
   }

   /**
    * @see HandlerInterceptor#afterCompletion(HttpServletRequest,HttpServletResponse,
    *      Object, Exception)
    */
   public void afterCompletion(HttpServletRequest request,
      HttpServletResponse response, Object obj, Exception exception)
      throws Exception {
      //		if (response instanceof BufferedResponseWrapper13Impl) {
      //			BufferedResponseWrapper13Impl bufresp = (BufferedResponseWrapper13Impl) response;
      //
      //			ByteArrayOutputStream outs = ((SimpleServletOutputStream) bufresp
      //					.getOutputStream()).getOutputStream();
      //			byte[] content = outs.toByteArray();
      //			bufresp.getResponse().setContentType(bufresp.getContentType());
      //			bufresp.getResponse().setContentLength(content.length);
      //			OutputStream out = bufresp.getResponse().getOutputStream();
      //			out.write(content);
      //			out.flush();
      //		}
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public PathMatcher getPathMatcher() {
      return pathMatcher;
   }

   /**
    * Documentaci�.
    *
    * @param pathMatcher Documentaci�
    */
   public void setPathMatcher(PathMatcher pathMatcher) {
      this.pathMatcher = pathMatcher;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public UrlPathHelper getUrlPathHelper() {
      return urlPathHelper;
   }

   /**
    * Documentaci�.
    *
    * @param urlPathHelper Documentaci�
    */
   public void setUrlPathHelper(UrlPathHelper urlPathHelper) {
      this.urlPathHelper = urlPathHelper;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getRedirections() {
      return redirections;
   }

   /**
    * Documentaci�.
    *
    * @param redirections Documentaci�
    */
   public void setRedirections(Map redirections) {
      this.redirections = redirections;
   }
}
