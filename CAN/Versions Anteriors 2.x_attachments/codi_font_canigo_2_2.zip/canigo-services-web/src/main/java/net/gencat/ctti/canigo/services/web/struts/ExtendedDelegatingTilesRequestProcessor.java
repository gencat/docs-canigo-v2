/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts;

import java.io.IOException;

import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.improve.struts.taglib.layout.util.FormUtils;

import net.gencat.ctti.canigo.core.springframework.beans.BindException;
import net.gencat.ctti.canigo.services.exceptions.SystemException;
import net.gencat.ctti.canigo.services.exceptions.WrappedCheckedException;
import net.gencat.ctti.canigo.services.logging.Log;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.web.exception.TagsServiceException;
import net.gencat.ctti.canigo.services.web.spring.bind.ServletRequestDataBinder;
import net.gencat.ctti.canigo.services.web.spring.bind.ServletRequestDataBinderFactory;
import net.gencat.ctti.canigo.services.web.struts.action.ActionSupport;
import net.gencat.ctti.canigo.services.web.struts.helper.BindingHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.configuration.ConfigurationTag;

import org.apache.struts.Globals;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.config.ModuleConfig;
import org.springframework.beans.BeanUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.struts.DelegatingTilesRequestProcessor;


/**
 * <p>Proces de la request quan s'utilitza tiles</p>
 *
 * @author RFA
 * @author XES
 * @author MMA
 *
 * @version $Revision: 1.10 $ $Date: 2007/09/17 10:32:45 $
 *
 * @since 1.0
 * <p>$Log: ExtendedDelegatingTilesRequestProcessor.java,v $
 * <p>Revision 1.10  2007/09/17 10:32:45  msabates
 * <p>Merge amb la branca BT2_1_325_1 i Jalopy
 * <p>
 * <p>Revision 1.9  2007/08/13 05:54:53  cbernal
 * <p>Revisi� Javadoc
 * <p>
 * <p>Revision 1.8  2007/07/26 09:30:55  cbernal
 * <p>Revisio Javadoc
 * <p>
 * Revision 1.7  2007/07/16 08:45:50  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]</p>
 *
 * <p>Revision 1.6  2007/05/23 10:47:39  msabates
 * Cap�alera</p>
 *
 * <p>Revision 1.1.1.1.2.1  2007/05/18 10:49:34  fernando.vaquero
 * *** empty log message ***</p>
 *
 * <p>Revision 1.1.1.1  2007/05/15 13:53:14  fernando.vaquero
 * Importacio canigo 2.0</p>
 *
 * <p>Revision 1.5  2007/05/15 10:19:03  msabates
 * Jalopy</p>
 *
 * <p>Revision 1.4  2007/05/15 08:00:15  msabates
 * Merge amb la branca BT2001 (Spring 2.0)</p>
 *
 * <p>Revision 1.3  2007/04/23 11:13:41  msabates
 * Canvis que estaven a la v1.4</p>
 *
 * <p>Revision 1.2  2007/04/20 09:49:21  msabates
 * Canvis que estaven a la v1.4</p>
 *
 * <p>Revision 1.33  2007/02/20 14:41:58  evidal
 * EVC: merging 1.0 & 1.1.</p>
 *
 * <p>Revision 1.32  2007/02/12 11:46:11  evidal
 * EVC: added version 1.2 changes.</p>
 *
 * <p>Revision 1.31.4.1  2007/01/22 12:09:13  evidal
 * EVC: merging with Justicia Branch.</p>
 *
 * <p>Revision 1.31.2.2  2006/12/13 12:30:58  rferre
 * RFA: fix pel bug dels forwars (evitar binding de struts a
 * processPopulate)</p>
 *
 * <p>Revision 1.31.2.1  2006/11/28 08:56:38  rferre
 * Incidencia Justicia 000007(RFA): control d'exceptions en el doForward,
 * aixi les exceptions de tags arriben a presentacio correctament</p>
 *
 * <p>Revision 1.31  2006/11/16 16:45:10  mmateos
 * author: crico: version 1.1 no estable</p>
 *
 * <p>Revision 1.31  2006/09/19 16:41:56  crico
 * version 1.1 no estable</p>
 *
 * <p>Revision 1.30  2006/09/06 17:08:38  crico
 * correcci� errors</p>
 *
 * <p>Revision 1.29  2006/08/01 15:16:58  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.28  2006/07/18 13:04:53  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.27  2006/07/14 11:35:55  evidal
 * *** empty log message ***</p>
 *
 * <p>Revision 1.26  2006/06/19 14:22:02  evidal
 * versio de partida del 20%</p>
 *
 * <p>Revision 1.25.2.2  2006/04/26 22:20:27  xescuder
 * XES: Added control of exceptions different of canigo</p>
 *
 * <p>Revision 1.25.2.1  2006/03/21 11:02:24  ecollell
 * ECG: maintenance multi-row</p>
 *
 * <p>Revision 1.25  2006/02/24 13:52:27  xescuder
 * *** empty log message ***</p>
 *
 */
public class ExtendedDelegatingTilesRequestProcessor
   extends DelegatingTilesRequestProcessor {
   /**
    * Documentaci�.
    */
   private static final String SERVLET_REQUEST_DATA_BINDER_FACTORY = "servletRequestDataBinderFactory";

   /**
    * Documentaci�.
    */
   public static final String ACTION_TAGS_CONFIGURATION = "__tagsConfiguration__";

   /**
    * Documentaci�.
    */
   public static final String CURRENT_MODE_REQUEST_ATTRIBUTE = "__currentMode__";

   /**
    * Documentaci�.
    */
   public static final String CONFIGURATION_TAG = "configurationTag";

   /**
    * Servei logging predetermitat a l'atribut pageContext.
    */
   public static final String DEFAULT_LOGGING_SERVICE = "defaultLoggingService";

   /**
    * Servei d'internacionalitzaci� predetermitat a l'atribut pageContext.
    */
   public static final String DEFAULT_I18N_SERVICE = "defaultI18NService";

   /**
    * Documentaci�.
    */
   private Log log = null;

   /**
    * Inicialitzaci� dels atributs definits en el context de Spring.
    */
   protected WebApplicationContext initWebApplicationContext(
      ActionServlet actionServlet, ModuleConfig moduleConfig)
      throws IllegalStateException {
      WebApplicationContext webappContext = super.initWebApplicationContext(actionServlet,
            moduleConfig);

      WebApplicationContext requiredAppContext = WebApplicationContextUtils.getRequiredWebApplicationContext(actionServlet.getServletContext());
      Map map = requiredAppContext.getBeansOfType(LoggingService.class);

      if ((map != null) && (map.size() > 0)) {
         LoggingService logService = (LoggingService) map.get(map.keySet()
                                                                 .iterator()
                                                                 .next());
         this.log = logService.getLog(this.getClass());
         this.log.debug(
            "Initialized log in ExtendedDelegatingTilesRequestProcessor");
      }

      return webappContext;
   }

   /**
    * Documentaci�.
    *
    * @param request HttpServletRequest
    * @param response HttpServletResponse
    * @param exception Exception
    * @param form ActionForm
    * @param mapping ActionMapping
    *
    * @return ActionForward
    *
    * @throws IOException
    * @throws ServletException
    */
   protected ActionForward processException(HttpServletRequest request,
      HttpServletResponse response, Exception exception, ActionForm form,
      ActionMapping mapping) throws IOException, ServletException {
      if (this.log != null) {
         this.log.debug("--------------------processException: " +
            exception.getClass().getName() + " ----------------------------");
         this.log.error("Error", exception);
      }

      ActionMessages messages = null;
      ActionForward forward = null;
      String reqCode = null;

      // Obtain reqCode in order to know what method to execute
      if (mapping.getParameter() != null) {
         if (request.getParameter(mapping.getParameter()) != null) {
            reqCode = request.getParameter(mapping.getParameter());
         } else {
            reqCode = (String) request.getAttribute(mapping.getParameter());
         }
      }

      String suffix = ((reqCode != null) && (reqCode.length() > 1))
         ? (reqCode.substring(0, 1).toUpperCase() + reqCode.substring(1)) : "";

      if (exception instanceof WrappedCheckedException) {
         messages = ActionMessagesHelper.buildWrappedCheckedExceptionMessages((WrappedCheckedException) exception);
         request.setAttribute(Globals.ERROR_KEY, messages);
         forward = mapping.findForward("error" + suffix);

         if (forward == null) {
            forward = mapping.findForward("error");
         }
      } else if (exception instanceof SystemException) {
         messages = ActionMessagesHelper.buildSystemExceptionMessages((SystemException) exception);
         request.setAttribute(Globals.ERROR_KEY, messages);
         forward = mapping.findForward("error" + suffix);

         if (forward == null) {
            forward = mapping.findForward("error");
         }
      } else {
         if (this.log != null) {
            this.log.error(exception);
         }

         // since 1.0.1 changed to show root cause
         messages = ActionMessagesHelper.buildExceptionMessages(exception);
         request.setAttribute(Globals.ERROR_KEY, messages);
         forward = mapping.findForward("error" + suffix);

         if (forward == null) {
            forward = mapping.findForward("error");
         }
      }

      Integer lastMode = (Integer) request.getAttribute(CURRENT_MODE_REQUEST_ATTRIBUTE);

      if ((lastMode != null) && (form != null)) {
         FormUtils.setFormDisplayMode(request, form, lastMode.intValue());
      }

      if (forward != null) {
         return forward;
      }

      return super.processException(request, response, exception, form, mapping);
   }

   /**
    * M�tode principal que efectua el proces action (vinculaci� request amb
    * pojoClass, mode del formulari, inicialitzaci� dels tags, ....).
    *
    * @param request
    * @param response
    * @param action
    * @param actionForm
    * @param actionMapping
    * @throws java.io.IOException
    * @throws javax.servlet.ServletException
    */
   protected void processActionPerformActionSupport(
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response, ActionSupport action,
      ActionForm actionForm, ActionMapping actionMapping)
      throws java.io.IOException, javax.servlet.ServletException {
      if (actionForm != null) {
         int currentMode = FormUtils.getFormDisplayMode(request, actionForm);
         request.setAttribute(CURRENT_MODE_REQUEST_ATTRIBUTE,
            new Integer(currentMode));
      }

      // Before of calling obtain information of action
      WebApplicationContext webApplicationContext = getWebApplicationContext();

      // In case of have been defined a pojoClass in action bind into the pojo
      ServletRequestDataBinderFactory servletRequestDataBinderFactory = (ServletRequestDataBinderFactory) webApplicationContext.getBean(SERVLET_REQUEST_DATA_BINDER_FACTORY);
      SpringBindingActionForm form = null;
      Object target = null;

      if ((actionForm != null) &&
            actionForm instanceof SpringBindingActionForm) {
         form = (SpringBindingActionForm) actionForm;
         target = form.getTarget();
      }

      ActionSupport actionSupport = (ActionSupport) action;

      // Put tags Configuration of action in request
      if (actionSupport.getTagsConfiguration() != null) {
         request.setAttribute(ACTION_TAGS_CONFIGURATION,
            actionSupport.getTagsConfiguration());
      } else {
         if (log != null) {
            log.warn("Attribute tagsConfiguration from " +
               actionSupport.getClass().getName() + " is null");
         }
      }

      // Obtain from webApplicationContext the configuration tag to inject other services needed
      ConfigurationTag configurationTag = (ConfigurationTag) webApplicationContext.getBean(CONFIGURATION_TAG);

      if (configurationTag != null) {
         request.setAttribute(CONFIGURATION_TAG, configurationTag);
      } else {
         if (log != null) {
            log.warn("Attribute configurationTag from " +
               actionSupport.getClass().getName() + " is null");
         }
      }

      Class pojoClass = actionSupport.getPojoClass();

      if (target == null) {
         // try to instantiate object 
         //        	if(request.getSession().getAttribute("org.apache.struts.taglib.html.SESSION_BEAN") != null){
         //        		target = request.getSession().getAttribute("org.apache.struts.taglib.html.SESSION_BEAN");
         //        	}else 
         if (pojoClass != null) {
            target = BeanUtils.instantiateClass(pojoClass);
         } else {
            if (log != null) {
               log.warn("pojoClass from " + actionSupport.getClass().getName() +
                  " is null. Cannot instantiate bean");
            }
         }
      }

      if (form != null) {
         // Set pojoClassName into form (to be used by tags)
         if (pojoClass != null) {
            form.setPojoClassName(pojoClass.getName());
         } else {
            if (log != null) {
               log.warn("pojoClass from " + actionSupport.getClass().getName() +
                  " is null. Cannot set pojoClass into ActionForm");
            }
         }
      }

      ServletRequestDataBinder binder = null;

      if (target != null) {
         target = BindingHelper.buildCollections(request.getParameterMap(),
               target);
         binder = getBinder(target, servletRequestDataBinderFactory,
               actionSupport);
         binder.bind(request);
         BindingHelper.removeNullElementsInCollections(request.getParameterMap(),
            target);
      }

      // Req code of request
      String reqCode = null;

      if ((actionMapping.getParameter() != null) &&
            (request.getParameter(actionMapping.getParameter()) != null)) {
         reqCode = request.getParameter(actionMapping.getParameter());
      } else if (actionMapping.getParameter() != null) {
         reqCode = (String) request.getAttribute(actionMapping.getParameter());
      } else {
         if (log != null) {
            log.warn("Cannot resolve reqCode beacuse parameter from " +
               actionSupport.getClass().getName() +
               " ActionMapping has not been set (<action-mapping ... parameter=\"****\"/>)");
         }
      }

      if (reqCode != null) {
         if (actionSupport.getDisplayModeResolver() != null) {
            if (form != null) {
               // Finally set form mode depending on reqCode                           
               FormUtils.setFormDisplayMode(request, actionForm,
                  actionSupport.getDisplayModeResolver().resolveMode(reqCode));
            } else {
               if (log != null) {
                  log.warn("Cannot set form display mode because form is null");
               }
            }
         } else {
            if (log != null) {
               log.warn("Cannot resolve mode beacuse displayModeResolver from " +
                  actionSupport.getClass().getName() + " is null");
            }
         }
      } else {
         if (log != null) {
            log.warn(
               "Cannot resolve mode beacuse reqCode is null (neither parameter nor attribute)");
         }
      }

      if ((form != null) && (binder != null)) {
         //msg-ini
         form.setErrors(binder.getErrors());

         //msg-fi
         // Finally expose errors of binding into request
         if (binder.isWrappedInstanceMutable()) {
            if (this.log != null) {
               //this.log.warn("Object has mutated from "+target+" to "+((BindException)binder.getErrors()).getTransientObject());
            }

            // Para las listas editables
            form.expose(((BindException) binder.getErrors()).getTransientObject());
         } else {
            if (this.log != null) {
               this.log.info("Exposing " + binder.getTarget());
            }

            form.expose(binder.getErrors(), request);
         }

         form.expose(binder.getErrors(), request);
      }
   }

   /**
    * Proc�s request.
    *
    * @param request HttpServletRequest
    * @param response HttpServletResponse
    * @param action Action
    * @param actionForm ActionForm
    * @param actionMapping ActionMapping
    *
    * @return ActionForward
    *
    * @throws IOException
    * @throws ServletException
    */
   protected ActionForward processActionPerform(
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response, Action action,
      ActionForm actionForm, ActionMapping actionMapping)
      throws java.io.IOException, javax.servlet.ServletException {
      if (action instanceof ActionSupport) {
         this.processActionPerformActionSupport(request, response,
            (ActionSupport) action, actionForm, actionMapping);
      }

      return super.processActionPerform(request, response, action, actionForm,
         actionMapping);
   }

   /**
    * Documentaci�.
    *
    * @param uri String
    * @param request HttpServletRequest
    * @param response HttpServletResponse
    *
    * @throws IOException
    * @throws ServletException
    * @throws TagsServiceException
    */
   protected void doForward(String uri, HttpServletRequest request,
      HttpServletResponse response) throws IOException, ServletException {
      try {
         super.doForward(uri, request, response);
      } catch (Exception ex) {
         throw new TagsServiceException(ex, ex.getMessage());
      }
   }

   /**
    * Documentaci�.
    *
    * @param target Object
    * @param servletRequestDataBinderFactory ServletRequestDataBinderFactory
    * @param actionSupport ActionSupport
    *
    * @return ServletRequestDataBinder
    */
   protected ServletRequestDataBinder getBinder(Object target,
      ServletRequestDataBinderFactory servletRequestDataBinderFactory,
      ActionSupport actionSupport) {
      ServletRequestDataBinderFactory customBinderFactory = actionSupport.getRequestDataBinderFactory();
      ServletRequestDataBinder binder = null;

      if (binder == null) {
         // Obtain binder and bind parameters into bean
         if (customBinderFactory != null) {
            binder = customBinderFactory.getInstance(target, "myPojoErrors");
         } else {
            binder = servletRequestDataBinderFactory.getInstance(target,
                  "myPojoErrors");
         }

         if (actionSupport.getCustomMappingEditors() != null) {
            if (log != null) {
               log.info("Adding custom mapping editors...");
            }

            binder.registerCustomMappingEditors(actionSupport.getCustomMappingEditors());
         } else {
            if (log != null) {
               log.info("ActionSupport does not have custom mapping editors!");
            }
         }
      }

      return binder;
   }

   /**
    * Documentaci�.
    *
    * @param request HttpServletRequest
    * @param response HttpServletResponse
    * @param actionForm ActionForm
    * @param mapping ActionMapping
    *
    * @throws ServletException
    */
   protected void processPopulate(HttpServletRequest request,
      HttpServletResponse response, ActionForm actionForm, ActionMapping mapping)
      throws ServletException {
      if (actionForm instanceof SpringBindingActionForm) {
         return;
      }

      super.processPopulate(request, response, actionForm, mapping);
   }
}
