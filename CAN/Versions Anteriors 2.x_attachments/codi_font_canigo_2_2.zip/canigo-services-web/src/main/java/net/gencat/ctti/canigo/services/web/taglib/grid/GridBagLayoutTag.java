/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.taglib.grid;

import java.io.IOException;

import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;

import net.gencat.ctti.canigo.services.web.taglib.grid.helper.GridHelper;

import ognl.Ognl;
import ognl.OgnlException;

import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.htmlparser.Node;
import org.htmlparser.nodes.RemarkNode;
import org.htmlparser.tags.DoctypeTag;
import org.htmlparser.tags.InputTag;
import org.htmlparser.tags.MetaTag;
import org.htmlparser.tags.ScriptTag;
import org.htmlparser.tags.StyleTag;
import org.htmlparser.util.NodeIterator;
import org.htmlparser.util.ParserException;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class GridBagLayoutTag extends GridBase {
   /**
    * Documentaci�.
    */
   private static final int ROW = GridHelper.ROW;

   /**
    * Documentaci�.
    */
   private static final int COL = GridHelper.COL;

   /**
    * Documentaci�.
    */
   private String gridBorder = null;

   /**
    * Documentaci�.
    */
   private String gridClass = null;

   /**
    * Documentaci�.
    */
   private String gridStyle = null;

   /**
    * Documentaci�.
    */
   private String gridStyleId = null;

   /**
    * Documentaci�.
    */
   private String size = null;

   /**
    * Documentaci�.
    */
   private Object[][] grid = null;

   /**
    * Documentaci�.
    */
   private Object[] rowArray = null;

   /**
    * Documentaci�.
    */
   private int cols;

   /**
    * Documentaci�.
    */
   private int rows;

   /**
    * Creates a new GridBagLayoutTag object.
    */
   public GridBagLayoutTag() {
      super();

      // TODO Auto-generated constructor stub
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public int doStartTag() throws JspException {
      try {
         int[] tmpSize = GridHelper.getSize(size);
         this.rows = tmpSize[GridHelper.ROW];
         this.cols = tmpSize[GridHelper.COL];
         grid = GridHelper.getGrid(tmpSize);
         rowArray = GridHelper.getRowArray(tmpSize);
      } catch (Exception ex) {
         throw new JspException(ex);
      }

      return super.doStartTag();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public int doEndTag() throws JspException {
      BodyContent body = super.getBodyContent();
      String bodyContent = body.getString();

      try {
         NodeIterator iterator = GridHelper.parse(bodyContent, pageContext);
         setCellsAttributes();
         setCellsHTML(iterator);
         printGrid();
      } catch (ParserException pe) {
         // TODO Auto-generated catch block
         pe.printStackTrace();
         throw new JspException(pe);
      }

      this.release();

      return EVAL_PAGE;
   }

   /**
    * Documentaci�.
    *
    * @throws JspException Documentaci�
    */
   public void setCellsAttributes() throws JspException {
      if (getRowspan() != null) {
         setCellAttribute(Constants.ROWSPAN, getRowspan());
      }

      if (getColspan() != null) {
         setCellAttribute(Constants.COLSPAN, getColspan());
      }

      if (getStyleClass() != null) {
         setCellAttribute("styleClass", getStyleClass());
      }

      if (getStyle() != null) {
         setCellAttribute("style", getStyle());
      }

      if (getOnchange() != null) {
         setCellAttribute("onchange", getOnchange());
      }

      if (getOnclick() != null) {
         setCellAttribute("onclick", getOnclick());
      }

      if (getOndblclick() != null) {
         setCellAttribute("ondblclick", getOndblclick());
      }

      if (getOnfocus() != null) {
         setCellAttribute("onfocus", getOnfocus());
      }

      if (getOnkeydown() != null) {
         setCellAttribute("onkeydown", getOnkeydown());
      }

      if (getOnkeyup() != null) {
         setCellAttribute("onkeyup", getOnkeyup());
      }

      if (getOnmousedown() != null) {
         setCellAttribute("onmousedown", getOnmousedown());
      }

      if (getOnmouseover() != null) {
         setCellAttribute("onmouseover", getOnmouseover());
      }

      if (getOnmouseout() != null) {
         setCellAttribute("onmouseout", getOnmouseout());
      }

      if (getOnmousemove() != null) {
         setCellAttribute("onmousemove", getOnmousemove());
      }

      if (getOnmouseup() != null) {
         setCellAttribute("onmouseup", getOnmouseup());
      }

      if (getOnkeypress() != null) {
         setCellAttribute("onkeypress", getOnkeypress());
      }
   }

   /**
    * Documentaci�.
    *
    * @param attribute Documentaci�
    * @param attributeValue Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public void setCellAttribute(String attribute, String attributeValue)
      throws JspException {
      StringTokenizer st = new StringTokenizer(attributeValue, ",");

      while (st.hasMoreElements()) {
         String attributeStr = st.nextToken();
         StringTokenizer st2 = new StringTokenizer(attributeStr, "=");

         String xyCell = null;
         String cellAttributeValue = "";

         try {
            xyCell = st2.nextToken();

            // Attribute value can contain "=" character, but only first is the real token!
            while (st2.hasMoreTokens()) {
               cellAttributeValue += ("=" + st2.nextToken());
            }

            cellAttributeValue = cellAttributeValue.substring(1);
         } catch (Exception ex) {
            throw new JspException("Exception in attribute \"" + attribute +
               "\" format: " + attributeStr);
         }

         StringTokenizer st3 = new StringTokenizer(xyCell, ":");

         String rowCellStr = st3.nextToken();
         String colCellStr = st3.nextToken();

         int rowCell;
         int colCell;

         if (rowCellStr.equals("*") && colCellStr.equals("**")) {
            for (int i = 0; i < this.rows; i++) {
               ((GridRow) rowArray[i]).setHasAttributes(true);

               try {
                  Ognl.setValue(attribute, (GridRow) rowArray[i],
                     cellAttributeValue);
               } catch (OgnlException e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
               }
            }
         } else if (colCellStr.equals("**")) {
            try {
               rowCell = new Integer(rowCellStr).intValue();
            } catch (Exception ex) {
               throw new JspException("Exception in attribute \"" + attribute +
                  "\" format: " + xyCell + ". Row must be a number.");
            }

            if (rowCell < 0) {
               throw new JspException("Exception in attribute \"" + attribute +
                  "\" format: " + xyCell + ". Row must be a positive number.");
            }

            ((GridRow) rowArray[rowCell]).setHasAttributes(true);

            try {
               Ognl.setValue(attribute, (GridRow) rowArray[rowCell],
                  cellAttributeValue);
            } catch (OgnlException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
            }
         } else if (rowCellStr.equals("*") && colCellStr.equals("*")) {
            for (int i = 0; i < this.rows; i++) {
               for (int j = 0; j < this.cols; j++) {
                  Object cell = grid[i][j];

                  if (cell instanceof GridCell) {
                     try {
                        Ognl.setValue(attribute, (GridCell) cell,
                           cellAttributeValue);
                     } catch (OgnlException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                     }
                  }
               }
            }
         } else if (rowCellStr.equals("*")) {
            try {
               colCell = new Integer(colCellStr).intValue();
            } catch (Exception ex) {
               throw new JspException("Exception in attribute \"" + attribute +
                  "\" format: " + xyCell);
            }

            for (int i = 0; i < this.rows; i++) {
               Object cell = grid[i][colCell];

               if (cell instanceof GridCell) {
                  try {
                     Ognl.setValue(attribute, (GridCell) cell,
                        cellAttributeValue);
                  } catch (OgnlException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
                  }
               }
            }
         } else if (colCellStr.equals("*")) {
            try {
               rowCell = new Integer(rowCellStr).intValue();
            } catch (Exception ex) {
               throw new JspException("Exception in attribute \"" + attribute +
                  "\" format: " + xyCell);
            }

            for (int i = 0; i < this.rows; i++) {
               Object cell = grid[rowCell][i];

               if (cell instanceof GridCell) {
                  try {
                     Ognl.setValue(attribute, (GridCell) cell,
                        cellAttributeValue);
                  } catch (OgnlException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
                  }
               }
            }
         } else {
            try {
               rowCell = new Integer(rowCellStr).intValue();
               colCell = new Integer(colCellStr).intValue();
            } catch (Exception ex) {
               throw new JspException("Exception in attribute \"" + attribute +
                  "\" format: " + xyCell);
            }

            if (grid[rowCell][colCell] instanceof GridCell) {
               GridCell gridCell = (GridCell) grid[rowCell][colCell];

               try {
                  Ognl.setValue(attribute, gridCell, cellAttributeValue);
               } catch (OgnlException e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
               }
            } else {
               // Setting attributes to an overlapped cell.
               OverlappedGridCell ovCell = (OverlappedGridCell) grid[rowCell][colCell];
               throw new JspException("Cannot set " + attribute +
                  " attribute to overlapped cell " + rowCell +
                  Constants.CELLDELIM + colCell + "." +
                  " This cell is overlapped by cell " +
                  ovCell.getOverlappingCell() + ".");
            }
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param pNumCell Documentaci�
    *
    * @return Documentaci�
    *
    * @throws JspException Documentaci�
    */
   private int[] getPositionCell(int pNumCell) throws JspException {
      int[] tmpPos = new int[2];
      tmpPos[ROW] = pNumCell / cols;
      tmpPos[COL] = pNumCell % cols;

      if (tmpPos[ROW] >= rows) {
         throw new JspException(
            "There are html elements that can't be filled in the gridBagLayout " +
            this.getId() +
            ". You need to add more cells the gridbaglayout with size " +
            this.getSize());
      }

      return tmpPos;
   }

   /**
    * Documentaci�.
    *
    * @param iterator Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public void setCellsHTML(NodeIterator iterator) throws JspException {
      try {
         int tmpNumCells = -1;

         while (iterator.hasMoreNodes()) {
            Node node = iterator.nextNode();

            if (isPositionableTag(node)) {
               tmpNumCells++;

               int[] tmpPos = getPositionCell(tmpNumCells);
               int tmpRow = tmpPos[ROW];
               int tmpCol = tmpPos[COL];
               Object tmpCell = grid[tmpRow][tmpCol];

               if (tmpCell instanceof OverlappedGridCell) {
                  while (tmpCell instanceof OverlappedGridCell) {
                     tmpNumCells++;
                     tmpPos = getPositionCell(tmpNumCells);
                     tmpRow = tmpPos[ROW];
                     tmpCol = tmpPos[COL];
                     tmpCell = grid[tmpRow][tmpCol];
                  }
               }

               ((GridCell) grid[tmpRow][tmpCol]).setInnerhtml(node.toHtml());
            } else {
               int tmpWriteCell = tmpNumCells;

               if (tmpNumCells < 0) {
                  // mai sera una overlappedgridcell.
                  tmpWriteCell = 0;
               }

               int[] tmpPos = getPositionCell(tmpWriteCell);
               int tmpRow = tmpPos[ROW];
               int tmpCol = tmpPos[COL];
               ((GridCell) grid[tmpRow][tmpCol]).setInnerhtml(((GridCell) grid[tmpRow][tmpCol]).getInnerhtml() +
                  node.toHtml());
            }
         }
      } catch (ParserException pe) {
         throw new JspException(pe);
      }
   }

   /**
    * Documentaci�.
    *
    * @param aTag Documentaci�
    *
    * @return Documentaci�
    */
   public boolean isPositionableTag(Node aTag) {
      boolean tmpResult = true;

      if (aTag instanceof ScriptTag) {
         return false;
      }

      if (aTag instanceof StyleTag) {
         return false;
      }

      if (aTag instanceof DoctypeTag) {
         return false;
      }

      if (aTag instanceof MetaTag) {
         return false;
      }

      if (aTag instanceof RemarkNode) {
         return false;
      }

      if (aTag instanceof InputTag) {
         InputTag tmpTag = (InputTag) aTag;
         String tmpType = tmpTag.getAttribute("type");

         if (tmpType != null) {
            if (tmpType.equalsIgnoreCase("hidden")) {
               return false;
            }
         }
      }

      return tmpResult;
   }

   /**
    * Documentaci�.
    *
    * @throws JspException Documentaci�
    */
   public void printGrid() throws JspException {
      JspWriter writer = pageContext.getOut();

      try {
         writer.write(Constants.INITOPENTABLE);
         writer.write(getSerializedTableAttributes());
         writer.write(Constants.CLOSETAG);

         for (int i = 0; i < this.rows; i++) {
            writer.write(Constants.NEWLINE + Constants.TAB);
            writer.write(Constants.INITOPENTR);

            if (((GridRow) rowArray[i]).isHasAttributes()) {
               writer.write(((GridRow) rowArray[i]).getSerializedAttributes());
            }

            writer.write(Constants.CLOSETAG);

            for (int j = 0; j < this.cols; j++) {
               if (grid[i][j] instanceof GridCell) {
                  writer.write(Constants.NEWLINE + Constants.TAB +
                     Constants.TAB);
                  writer.write(Constants.INITOPENTD);
                  writer.write(((GridCell) grid[i][j]).getSerializedAttributes());
                  writer.write(Constants.CLOSETAG);

                  writer.write(Constants.NEWLINE + Constants.TAB +
                     Constants.TAB + Constants.TAB);

                  String cellValue = ((GridCell) grid[i][j]).getInnerhtml();
                  writer.write(cellValue);

                  writer.write(Constants.NEWLINE + Constants.TAB +
                     Constants.TAB);
                  writer.write(Constants.CLOSETD);
               }
            }

            writer.write(Constants.NEWLINE + Constants.TAB);
            writer.write(Constants.CLOSETR);
         }

         writer.write(Constants.NEWLINE);
         writer.write(Constants.CLOSETABLE);
      } catch (IOException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public String getSerializedTableAttributes() throws JspException {
      String attributes = "";

      if (this.gridStyleId != null) {
         attributes += (" id=\"" + this.gridStyleId + "\"");
      }

      if (this.gridClass != null) {
         attributes += (" class=\"" + this.gridClass + "\"");
      }

      if (this.gridStyle != null) {
         attributes += (" style=\"" + this.gridStyle + "\"");
      }

      if (this.gridBorder != null) {
         attributes += (" border=\"" + this.gridBorder + "\"");
      }

      return attributes;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getSize() {
      return size;
   }

   /**
    * Documentaci�.
    *
    * @param size Documentaci�
    */
   public void setSize(String size) {
      this.size = size;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getGridClass() {
      return gridClass;
   }

   /**
    * Documentaci�.
    *
    * @param gridClass Documentaci�
    */
   public void setGridClass(String gridClass) {
      this.gridClass = gridClass;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getGridStyle() {
      return gridStyle;
   }

   /**
    * Documentaci�.
    *
    * @param gridStyle Documentaci�
    */
   public void setGridStyle(String gridStyle) {
      this.gridStyle = gridStyle;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getGridBorder() {
      return gridBorder;
   }

   /**
    * Documentaci�.
    *
    * @param gridBorder Documentaci�
    */
   public void setGridBorder(String gridBorder) {
      this.gridBorder = gridBorder;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getGridStyleId() {
      return gridStyleId;
   }

   /**
    * Documentaci�.
    *
    * @param gridStyleId Documentaci�
    */
   public void setGridStyleId(String gridStyleId) {
      this.gridStyleId = gridStyleId;
   }

   /**
    * Documentaci�.
    */
   public void release() {
      this.gridStyle = null;
      this.gridClass = null;
      this.gridStyleId = null;
      this.gridBorder = null;

      // call release method of every cell.
      for (int i = 0; i < this.rows; i++) {
         for (int j = 0; j < this.cols; j++) {
            Object cell = grid[i][j];

            if (grid[i][j] instanceof GridCell) {
               ((GridCell) cell).release();
            }
         }
      }

      super.release();
   }
}
