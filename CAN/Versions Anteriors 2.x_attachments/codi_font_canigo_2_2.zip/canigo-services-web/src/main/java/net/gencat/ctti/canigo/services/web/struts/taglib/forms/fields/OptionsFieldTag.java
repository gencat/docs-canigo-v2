/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;

import fr.improve.struts.taglib.layout.field.ChoiceTag;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.ServicesTagHelper;
import net.gencat.ctti.canigo.services.web.taglib.Constants;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;
import net.gencat.ctti.canigo.services.web.taglib.util.options.OptionsListService;

import org.apache.struts.taglib.TagUtils;
import org.apache.struts.util.LabelValueBean;


/**
 * <p>Definici� de les propietats del Tag OptionsFieldTag.</p>
 *
 * @author XES
 */
public class OptionsFieldTag extends fr.improve.struts.taglib.layout.field.OptionsTag
   implements net.gencat.ctti.canigo.services.web.taglib.OptionsFieldTag {
   /**
    *
    */
   private static final long serialVersionUID = 3903713008602056468L;

   /**
   * I18nService
   */
   private I18nService i18nService;

   /**
    * Documentaci�.
    */
   private OptionsListService optionsListService;

   /**
    * Documentaci�.
    */
   private String optionsListName;

   /**
    * Documentaci�.
    */
   private String styleId;

   /**
    * ValidationService
    */
   private ValidationService validationService;

   /**
    * Fi de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doEndTag() throws JspException {
      TagUtil.copyConfiguration(this);

      ChoiceTag choiceTag;

      // Acquire the select or radios tag we are associated with
      try {
         choiceTag = (ChoiceTag) getParent();
      } catch (ClassCastException e) {
         throw new JspException(messages.getMessage("optionsTag.select"));
      }

      StringBuffer sb = new StringBuffer();

      // Generate options
      if ((optionsListService != null) && (optionsListName != null)) {
         List optionsList = optionsListService.getOptions(optionsListName,
               (HttpServletRequest) pageContext.getRequest());

         if (optionsList != null) {
            Iterator it = optionsList.iterator();

            while (it.hasNext()) {
               Object bean = it.next();
               Object value = null;
               Object label = null;
               ;

               if (bean instanceof LabelValueBean) {
                  LabelValueBean labelValueBean = (LabelValueBean) bean;
                  value = labelValueBean.getValue();
                  label = labelValueBean.getLabel();
               } else if (bean instanceof Map) { // used from OptionsListSource
                                                 // For each map keys 'label' and 'value' specified 

                  Map map = (Map) bean;
                  // Only one key and value expected
                  label = map.get(Constants.LABEL);
                  value = map.get(Constants.VALUE);
               } else {
                  value = getValueFromBean(bean, property);

                  if (value == null) {
                     value = "";
                  }

                  if (labelProperty != null) {
                     label = getLabelFromBean(bean, labelProperty);
                  } else {
                     label = value;
                  }

                  if (label == null) {
                     label = "";
                  }
               }

               choiceLabel = label.toString();
               choiceValue = value.toString();
               choiceTag.addChoice(sb, this);
            }
         }

         TagUtils.getInstance().write(getPageContext(), sb.toString());
         //  Reset
         reset();

         return EVAL_PAGE;
      } else {
         return super.doEndTag();
      }
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doStartTag() throws JspException {
      if ((optionsListService != null) && (optionsListName != null)) {
         // Set as labelName and labelProperty the internal defined in
         // optionListSource
         setLabelName(optionsListService.getOptionsLabelName(optionsListName));
         setLabelProperty(optionsListService.getOptionsLabelProperty(
               optionsListName));
      }

      return super.doStartTag();
   }

   /**
    * Id d'enlla� amb la configuraci� XML.
    *
    * @return String
    */
   public String getStyleId() {
      return styleId;
   }

   /**
    * Id d'enlla� amb la configuraci� XML.
    *
    * @param styleId String
    */
   public void setStyleId(String styleId) {
      this.styleId = styleId;
   }

   /**
    * Documentaci�.
    *
    * @return PageContext
    */
   public PageContext getPageContext() {
      return pageContext;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @return I18nService
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @param validationService ValidationService
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * Documentaci�.
    *
    * @return OptionsListService
    */
   public OptionsListService getOptionsListService() {
      return optionsListService;
   }

   /**
    * Documentaci�.
    *
    * @param optionsListService OptionsListService
    */
   public void setOptionsListService(OptionsListService optionsListService) {
      this.optionsListService = optionsListService;
   }

   /**
    * Refer�ncia a la definici� de la llista.
    *
    * @return String
    */
   public String getOptionsListName() {
      return optionsListName;
   }

   /**
    * Refer�ncia a la definici� de la llista.
    *
    * @param optionsListName String
    */
   public void setOptionsListName(String optionsListName) {
      this.optionsListName = optionsListName;
   }

   /**
    * Permet injectar serveis del contenidor d' spring.
    *
    * @param services String
    *
    * @throws JspException
    */
   public void setServices(String services) throws JspException {
      ServicesTagHelper.setServices(services, pageContext, this);
   }
}
