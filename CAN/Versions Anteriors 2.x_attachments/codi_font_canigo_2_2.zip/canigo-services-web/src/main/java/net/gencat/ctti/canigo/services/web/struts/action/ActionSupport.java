/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.action;

import java.util.Map;

import net.gencat.ctti.canigo.services.web.spring.bind.ServletRequestDataBinder;
import net.gencat.ctti.canigo.services.web.spring.bind.ServletRequestDataBinderFactory;
import net.gencat.ctti.canigo.services.web.struts.FormDisplayResolver;


/**
 * $Id: ActionSupport.java,v 1.4 2007/07/16 08:45:52 msabates Exp $
 * Descripci�.
 * @author RFA
 * @author XES
 * @version $Revision: 1.4 $ $Date: 2007/07/16 08:45:52 $
 *
 * @see
 * @since 1.0
 *
 * $Log: ActionSupport.java,v $
 * Revision 1.4  2007/07/16 08:45:52  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]
 *
 * Revision 1.3  2007/05/23 10:47:40  msabates
 * Cap�alera
 *
 * Revision 1.1.1.1.2.1  2007/05/18 10:49:47  fernando.vaquero
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2007/05/15 13:54:16  fernando.vaquero
 * Importacio canigo 2.0
 *
 * Revision 1.2  2007/05/15 10:19:04  msabates
 * Jalopy
 *
 * Revision 1.1  2007/03/28 12:14:01  msabates
 * *** empty log message ***
 *
 * Revision 1.2  2007/03/14 14:44:39  msabates
 * *** empty log message ***
 *
 * Revision 1.1  2007/03/12 11:40:55  msabates
 * Refactor a net.gencat.ctti.canigo
 *
 * Revision 1.1  2007/02/22 15:56:10  msabates
 * *** empty log message ***
 *
 * Revision 1.3  2006/11/16 16:47:01  mmateos
 * author: evidal: versio de partida del 20
 *
 * Revision 1.3  2006/06/19 14:22:02  evidal
 * versio de partida del 20%
 *
 * Revision 1.2.2.2  2006/03/21 11:02:24  ecollell
 * ECG: maintenance multi-row
 *
 * Revision 1.2.2.1  2006/03/03 14:58:19  xescuder
 * XES: Added documentation
 *
 */
public interface ActionSupport {
   /**
    * Pojo class to use with action.
    * @return Class The class of pojo
    */
   public Class getPojoClass();

   /**
    * The form display mode resolver.
    * @return
    */
   public FormDisplayResolver getDisplayModeResolver();

   /**
    * Tags configuration for each 'reqCode' received as parameter.
    * @return Map
    */
   public Map getTagsConfiguration();

   /**
    * Custom mapping editors to set values in pojo from request parameters.
    * @return Map
    */
   public Map getCustomMappingEditors();

   /**
    * Custom request-data binder.
    * @return Map
    */
   public ServletRequestDataBinderFactory getRequestDataBinderFactory();
}
