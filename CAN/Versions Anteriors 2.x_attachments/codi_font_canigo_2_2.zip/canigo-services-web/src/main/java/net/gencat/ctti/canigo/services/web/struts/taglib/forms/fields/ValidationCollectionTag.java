/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

import net.gencat.ctti.canigo.services.web.taglib.Tag;
import net.gencat.ctti.canigo.services.web.validation.commons.WebValidationSubmit;


/**
 * <p>Definici� de les propietats del Tag ValidationCollectionTag.</p>
 * Aquest tag es necessari per validar collections en el submit.
 * Es usat en les listes editables.
 *
 * @author A122912
 *
 */
public class ValidationCollectionTag extends TagSupport {
   /**
    * Documentaci�.
    */
   private String property;

   /**
    * Documentaci�.
    */
   private int indexReference = 0;

   /**
    * Crea un nou objecte ValidationCollectionTag.
    */
   public ValidationCollectionTag() {
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doStartTag() throws JspException {
      if (indexReference < 0) {
         throw new JspException(
            "The referenceIndex can't be negative in the validateCollectionTag");
      }

      return SKIP_BODY;
   }

   /**
    * Fi de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doEndTag() throws JspException {
      String identificadorForm = (String) this.pageContext.getRequest()
                                                          .getAttribute("identificadorForm");

      if (identificadorForm == null) {
         throw new JspException(
            "The tag don't found a form identifier to add collection " +
            this.getProperty() + " validation");
      }

      String tmpProperty = property + "[" + indexReference + "]";

      String tmpCollections = (String) pageContext.getSession()
                                                  .getAttribute(identificadorForm +
            WebValidationSubmit.COLLECTIONS);

      if (tmpCollections != null) {
         tmpCollections = "," + tmpProperty;
      } else {
         tmpCollections = tmpProperty;
      }

      pageContext.getSession()
                 .setAttribute(identificadorForm +
         WebValidationSubmit.COLLECTIONS, tmpCollections);

      return EVAL_PAGE;
   }

   /**
    * Liberar tots els camps configurats per tal de no copiar en els
    * pr�xims tags.
    */
   public void release() {
      super.release();
   }

   /**
    * Nom de la propietat que �s col- lecci�.
    *
    * @return String
    */
   public String getProperty() {
      return property;
   }

   /**
    * Nom de la propietat que �s col- lecci�.
    *
    * @param property String
    */
   public void setProperty(String property) {
      this.property = property;
   }

   /**
    * Documentaci�.
    *
    * @return int
    */
   public int getReferenceIndex() {
      return indexReference;
   }

   /**
    * Documentaci�.
    *
    * @param referenceIndex int
    */
   public void setReferenceIndex(int referenceIndex) {
      this.indexReference = referenceIndex;
   }

   /**
    * Numero de fila refer�ncia per a propagar les validacions de submit.
    * Si no s'informa s'assumeix 0.
    *
    * @return int
    */
   public int getIndexReference() {
      return indexReference;
   }

   /**
    * Numero de fila refer�ncia per a propagar les validacions de submit.
    * Si no s'informa s'assumeix 0.
    *
    * @param indexReference int
    */
   public void setIndexReference(int indexReference) {
      this.indexReference = indexReference;
   }
}
