/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields;

import javax.servlet.jsp.JspException;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.ServicesTagHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.util.BasicFieldHelper;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;


/**
 * <p>Definici� de les propietats del Tag PasswordFieldTag.</p>
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class PasswordFieldTag extends fr.improve.struts.taglib.layout.field.PasswordFieldTag
   implements net.gencat.ctti.canigo.services.web.taglib.PasswordFieldTag {
   /**
    *
    */
   private static final long serialVersionUID = 1301025968987719336L;

   /**
    * I18nService
    */
   private I18nService i18nService;

   /**
    * List of conversions: uppercase, lowercase, trim ...
    * All they have to be separated by commas
    */
   private String convertTo = null;

   /**
   * Style class defined for key of field (canigo)
   */
   private String keyStyleClass = null;

   /**
    * Tooltip attributes
    */
   private String tooltipKey = null;

   /**
    * Documentaci�.
    */
   private String tooltipOptions = null;

   /**
    * Documentaci�.
    */
   private String tooltipTitleKey = null;

   /**
    * ValidationService
    */
   private ValidationService validationService;

   /**
    * Show an error next to the field
    */
   private boolean fieldErrorDisplayed = true;

   /**
    * Documentaci�.
    */
   private boolean isAutoTab = false;

   /**
    * Select on focus
    */
   private boolean selectOnFocus = true;

   /**
    * Show calendar
    */
   private boolean showCalendar = false;

   /**
    * Crea un nou objecte PasswordFieldTag.
    */
   public PasswordFieldTag() {
      super();
   }

   /**
    * In case of layout=false we have to call to generation of label
    */
   protected boolean doBeforeValue() throws javax.servlet.jsp.JspException {
      super.doBeforeValue();

      // If no layout specified, we have to add manually label
      if (!isLayout()) {
         BasicFieldHelper.displayLabel(this);
      }

      return true;
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doStartLayoutTag() throws JspException {
      TagUtil.copyConfiguration(this);
      // Set to refresh mode and other calculated attributes 
      // (computeDisplayMode)
      // (doStartTag in Struts Layout has been defined final!!!!)
      initDynamicValues();

      return super.doStartLayoutTag();
   }

   /**
    * Llista conversions: uppercase, lowercase, trim ...
    * Tots han de estar separats per comes
    *
    * @return String
    */
   public String getConvertTo() {
      return convertTo;
   }

   /**
    * Llista conversions: uppercase, lowercase, trim ...
    * Tots han de estar separats per comes
    *
    * @param convertTo String
    */
   public void setConvertTo(String convertTo) {
      this.convertTo = convertTo;
   }

   /**
    * Documentaci�.
    *
    * @return boolean
    */
   public boolean isFieldErrorDisplayed() {
      return fieldErrorDisplayed;
   }

   /**
    * Documentaci�.
    *
    * @param fieldErrorDisplayed boolean
    */
   public void setFieldErrorDisplayed(boolean fieldErrorDisplayed) {
      this.fieldErrorDisplayed = fieldErrorDisplayed;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @return I18nService
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Autotabulaci� del camp.
    *
    * @return boolean
    */
   public boolean isAutoTab() {
      return isAutoTab;
   }

   /**
    * Autotabulaci� del camp.
    *
    * @param isAutoTab boolean
    */
   public void setAutoTab(boolean isAutoTab) {
      this.isAutoTab = isAutoTab;
   }

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getKeyStyleClass() {
      return keyStyleClass;
   }

   /**
    * Documentaci�.
    *
    * @param keyStyleClass String
    */
   public void setKeyStyleClass(String keyStyleClass) {
      this.keyStyleClass = keyStyleClass;
   }

   /**
    * Defineix si amb el focus es selecciona tot el component.
    *
    * @return boolean
    */
   public boolean isSelectOnFocus() {
      return selectOnFocus;
   }

   /**
    * Defineix si amb el focus es selecciona tot el component.
    *
    * @param selectOnFocus boolean
    */
   public void setSelectOnFocus(boolean selectOnFocus) {
      this.selectOnFocus = selectOnFocus;
   }

   /**
    * Mostrar calendari d'edici� de data.
    *
    * @return boolean
    */
   public boolean isShowCalendar() {
      return showCalendar;
   }

   /**
    * Mostrar calendari d'edici� de data.
    *
    * @param showCalendar boolean
    */
   public void setShowCalendar(boolean showCalendar) {
      this.showCalendar = showCalendar;
   }

   /**
    * Clau del literal del missatge a mostrar dins el tooltip.
    *
    * @return String
    */
   public String getTooltipKey() {
      return tooltipKey;
   }

   /**
    * Clau del literal del missatge a mostrar dins el tooltip.
    *
    * @param tooltipKey String
    */
   public void setTooltipKey(String tooltipKey) {
      this.tooltipKey = tooltipKey;
   }

   /**
    * Opcions aplicades segons la implementaci� (en el cas actual sota DOM
    * Tooltip).
    *
    * @return String
    */
   public String getTooltipOptions() {
      return tooltipOptions;
   }

   /**
    * Opcions aplicades segons la implementaci� (en el cas actual sota DOM
    * Tooltip).
    *
    * @param tooltipOptions String
    */
   public void setTooltipOptions(String tooltipOptions) {
      this.tooltipOptions = tooltipOptions;
   }

   /**
    * Clau del literal a mostrar si volem mostrar un t�tol com a cap�alera del
    * tooltip.
    *
    * @return String
    */
   public String getTooltipTitleKey() {
      return tooltipTitleKey;
   }

   /**
    * Clau del literal a mostrar si volem mostrar un t�tol com a cap�alera del
    * tooltip.
    *
    * @param tooltipTitleKey String
    */
   public void setTooltipTitleKey(String tooltipTitleKey) {
      this.tooltipTitleKey = tooltipTitleKey;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @param validationService ValidationService
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * Mostra el camp com obligatori.
    * Canviat el valor de struts layout. String / boolean.
    *
    * @param isRequired boolean
    */
   public void setRequired(boolean isRequired) {
      setIsRequired(Boolean.toString(isRequired));
   }

   /**
    * �ndex de tabulaci�
    * Per discordancia amb Struts Layout el metode definid es getTabindex
    * i setTabindex per� l'atribut es tabIndex.
    *
    * @return String
    */
   public String getTabIndex() {
      return getTabindex();
   }

   /**
    * �ndex de tabulaci�.
    *
    * @param tabIndex String
    */
   public void setTabIndex(String tabIndex) {
      setTabindex(tabIndex);
   }

   /**
    * Permet injectar serveis del contenidor d' spring.
    *
    * @param services String
    *
    * @throws JspException
    */
   public void setServices(String services) throws JspException {
      ServicesTagHelper.setServices(services, pageContext, this);
   }
}
