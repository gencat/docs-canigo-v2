/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields;

import java.io.IOException;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;

import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.DWRHelper;
import net.gencat.ctti.canigo.services.web.taglib.Constants;

import org.ajaxtags.tags.AjaxAutocompleteTag;
import org.ajaxtags.tags.OptionsBuilder;
import org.apache.struts.taglib.TagUtils;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;


/**
 * <p>Definici� de les propietats del Tag Autocomplete.</p>
 *
 * @author
 * @version 1.0
  */
public class AutocompleteTag extends AjaxAutocompleteTag {
   /**
    * Serial version.
    */
   private static final long serialVersionUID = 1934076733823993119L;

   /**
        * Imported scripts flag.
        */
   private static final String AUTOCOMPLETE_IMPORTED_SCRIPTS = "__autocomplete_imported_scripts__";

   /**
    * Indicator.
    */
   private String indicator;

   /**
   * Options list name
   */
   private String optionsListName;

   /**
    * The query parameter.
    */
   private String queryParameter;

   /**
    * The selected property.
    */
   private String selectedProperty;

   /**
    * Documentaci�.
    */
   private String styleClass;

   /**
    * Nom de la opci� a mostrar.
    *
    * @return String
    */
   public String getOptionsListName() {
      return optionsListName;
   }

   /**
    * Nom de la opci� a mostrar.
    *
    * @param optionsListName
    */
   public void setOptionsListName(String optionsListName) {
      this.optionsListName = optionsListName;
   }

   /**
    * Inici de la configuraci� del Tag
    *
    * @return int
    */
   public int doStartTag() throws JspException {
      setBaseUrl(this.getBaseUrlDummy());
      setClassName("");

      int tmpS = super.doStartTag();

      // EVC: import engine.js if not imported yet
      DWRHelper.generateDWREngineScript(super.pageContext);

      // EVC: import tag scripts if not imported yet.
      HttpServletRequest request = (HttpServletRequest) super.pageContext.getRequest();
      HttpServletResponse response = (HttpServletResponse) super.pageContext.getResponse();

      if ((request.getAttribute(AUTOCOMPLETE_IMPORTED_SCRIPTS) == null)) {
         request.setAttribute(AUTOCOMPLETE_IMPORTED_SCRIPTS, Constants.IMPORTED);

         TagUtils tagUtils = TagUtils.getInstance();
         tagUtils.write(super.pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() +
            response.encodeURL("/dwr/interface/autocompleteService.js") +
            "\"></script>");
         tagUtils.write(super.pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() +
            response.encodeURL(
               "/scripts/ajax/ajaxtags/canigo-ajaxtags-autocomplete.js") +
            "\"></script>\n");
      }

      this.optionsListName = (String) ExpressionEvaluatorManager.evaluate("source",
            this.optionsListName, String.class, this, super.pageContext);

      if (this.getIndicator() != null) {
         this.indicator = (String) ExpressionEvaluatorManager.evaluate("indicator",
               this.indicator, String.class, this, super.pageContext);
      }

      return tmpS;
   }

   /**
    * Final de la configuraci� del Tag
    *
    * @return int
    */
   public int doEndTag() throws JspException {
      OptionsBuilder options = new OptionsBuilder();
      options.add("source", this.getSource(), true)
             .add("target", this.getTarget(), true)
             .add("parameters", this.getParameters(), true);

      if (this.getProgressStyle() != null) {
         options.add("progressStyle", this.getProgressStyle(), true);
      }

      if (this.getMinimumCharacters() != null) {
         options.add("minimumCharacters", this.getMinimumCharacters(), true);
      }

      if (this.getForceSelection() != null) {
         options.add("forceSelection", this.getForceSelection(), true);
      }

      if (this.getAppendValue() != null) {
         options.add("appendValue", this.getAppendValue(), true);
      }

      if (this.getAppendSeparator() != null) {
         options.add("appendSeparator", this.getAppendSeparator(), true);
      }

      if (this.getPostFunction() != null) {
         options.add("postFunction", this.getPostFunction(), false);
      }

      if (this.getEmptyFunction() != null) {
         options.add("emptyFunction", this.getEmptyFunction(), false);
      }

      if (this.getErrorFunction() != null) {
         options.add("errorFunction", this.getErrorFunction(), false);
      }

      if (this.getStyleClass() != null) {
         options.add("className", this.getStyleClass(), true);
      }

      options.add("queryParameter", this.getQueryParameter(), true);
      options.add("selectedProperty", this.getSelectedProperty(), true);

      if (this.getOptionsListName() != null) {
         options.add("optionsListName", this.getOptionsListName(), true);
      }

      if (this.getIndicator() != null) {
         options.add("indicator", this.getIndicator(), true);
      }

      StringBuffer script = new StringBuffer();
      script.append("<script type=\"text/javascript\">\n");
      script.append("new CanigoAutocompleteTag.Autocomplete(\n");
      script.append("\"");
      script.append("http://nop.cat/hola");
      script.append("\", {\n");
      script.append(options.toString());
      script.append("});\n");
      script.append("</script>\n\n");

      JspWriter writer = pageContext.getOut();

      try {
         writer.println(script);
      } catch (IOException e) {
         throw new JspException(e.getMessage());
      }

      return EVAL_PAGE;
   }

   /**
    * Div a mostrar quan es fa petici� AJAX.
    *
    * @return String
    */
   public String getIndicator() {
      return indicator;
   }

   /**
    * Div a mostrar quan es fa petici� AJAX.
    *
    * @param indicator String
    */
   public void setIndicator(String indicator) {
      this.indicator = indicator;
   }

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getBaseUrlDummy() {
      return "http://hola.papallona.cat";
   }

   /**
    * Nom parametre de la query.
    *
    * @return String
    */
   public String getQueryParameter() {
      return queryParameter;
   }

   /**
    * Nom de la propietat del bean que retorna la query que es vol copiar
    * al camp de text target.
    *
    * @param queryParameter String
    */
   public void setQueryParameter(String queryParameter) {
      this.queryParameter = queryParameter;
   }

   /**
    * Nom de la propietat del bean que retorna la query que es vol copiar
    * al camp de text target.
    *
    * @return String
    */
   public String getSelectedProperty() {
      return selectedProperty;
   }

   /**
    * Propietat a copiar al target.
    *
    * @param selectedProperty String
    */
   public void setSelectedProperty(String selectedProperty) {
      this.selectedProperty = selectedProperty;
   }

   /**
    * Propietat a copiar al target.
    *
    * @return String
    */
   public String getStyleClass() {
      return styleClass;
   }

   /**
    * Estil per aplicar.
    *
    * @param styleClass String
    */
   public void setStyleClass(String styleClass) {
      this.styleClass = styleClass;
      super.setClassName(styleClass);
   }
}
