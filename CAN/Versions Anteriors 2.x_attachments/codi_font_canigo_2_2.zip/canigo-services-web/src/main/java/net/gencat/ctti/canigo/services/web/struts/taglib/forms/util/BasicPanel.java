/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.util;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

import net.gencat.ctti.canigo.services.web.taglib.FormTag;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class BasicPanel extends fr.improve.struts.taglib.layout.util.BasicPanel {
   /**
    * Documentaci�.
    */
   private boolean layout = false;

   /**
    * Documentaci�.
    *
    * @param buffer Documentaci�
    */
   public void doEndPanel(StringBuffer buffer) {
      if (layout) {
         super.doEndPanel(buffer);
      }
   }

   /**
    * Documentaci�.
    *
    * @param buffer Documentaci�
    * @param align Documentaci�
    * @param width Documentaci�
    */
   public void doStartPanel(StringBuffer buffer, String align, String width) {
      if (layout) {
         super.doStartPanel(buffer, align, width);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    */
   public void doPrintTitle(StringBuffer arg0, String arg1) {
      if (layout) {
         super.doPrintTitle(arg0, arg1);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void doAfterBody(StringBuffer arg0) {
      if (layout) {
         super.doAfterBody(arg0);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    */
   public void doBeforeBody(StringBuffer arg0, String arg1) {
      if (layout) {
         super.doBeforeBody(arg0, arg1);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    */
   public void doPrintBlankLine(StringBuffer arg0, int arg1) {
      if (layout) {
         super.doPrintBlankLine(arg0, arg1);
      }
   }

   /**
    * Documentaci�.
    *
    * @param pg Documentaci�
    * @param in_styleClass Documentaci�
    * @param in_panel Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public void init(final PageContext pg, String in_styleClass,
      TagSupport in_panel) throws JspException {
      if (in_panel instanceof FormTag) {
         FormTag formTag = (FormTag) in_panel;
         layout = formTag.isLayout();
      }

      super.init(pg, in_styleClass, in_panel);
   }
}
