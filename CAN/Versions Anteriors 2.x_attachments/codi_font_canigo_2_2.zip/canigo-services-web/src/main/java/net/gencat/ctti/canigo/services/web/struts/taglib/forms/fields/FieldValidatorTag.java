/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields;

import java.io.IOException;

import java.lang.reflect.InvocationTargetException;

import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

import net.gencat.ctti.canigo.core.util.beanutils.BeanUtils;
import net.gencat.ctti.canigo.services.exceptions.BusinessException;
import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.util.BasicFieldHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.util.FormTagHelper;
import net.gencat.ctti.canigo.services.web.taglib.FieldTag;
import net.gencat.ctti.canigo.services.web.taglib.FormTag;
import net.gencat.ctti.canigo.services.web.taglib.SelectFieldTag;
import net.gencat.ctti.canigo.services.web.taglib.Tag;
import net.gencat.ctti.canigo.services.web.taglib.TextAreaFieldTag;
import net.gencat.ctti.canigo.services.web.taglib.TextFieldTag;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.taglib.TagUtils;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;


/**
 * <p>Definici� de les propietats del Tag FieldValidatorTag.</p>
 *
 * @author
 * @version Versi� $Revision: 1.5 $ $Date: 2007/07/25 11:10:34 $
 *
 */
public class FieldValidatorTag extends TagSupport implements Tag {
   /**
    * Documentaci�.
    */
   private static final long serialVersionUID = 1107866494185767999L;

   /**
   * I18nService
   */
   private I18nService i18nService;

   /**
    * Documentaci�.
    */
   private String contextSubpath = null;

   /**
    * Documentaci�.
    */
   private String dependentFields;

   /**
    * Documentaci�.
    */
   private String errorClass;

   /**
    * Documentaci�.
    */
   private String errorKey;

   /**
    * Documentaci�.
    */
   private String iconStyleId;

   /**
    * Documentaci�.
    */
   private String indicator;

   /**
    * Documentaci�.
    */
   private String source;

   /**
    * Documentaci�.
    */
   private String sourceErrorTooltip;

   /**
    * Id of tag.
    */
   private String styleId;

   /**
    * Documentaci�.
    */
   private String textErrorStyleId;

   /**
    * Documentaci�.
    */
   private String validationFieldMessageMode;

   /**
    * Documentaci�.
    */
   private String validationMessageFunction;

   /**
    * Documentaci�.
    */
   private String validations;

   /**
    * ValidationService.
    */
   private ValidationService validationService;

   /**
    * Documentaci�.
    */
   private boolean appendContextPath = true;

   /**
    * Crea un nou objecte FieldValidatorTag.
    */
   public FieldValidatorTag() {
      super();
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doStartTag() throws JspException {
      if (this.getSource() != null) {
         this.source = (String) ExpressionEvaluatorManager.evaluate("source",
               this.source, String.class, this, pageContext);
      }

      if (this.getIconStyleId() != null) {
         this.iconStyleId = (String) ExpressionEvaluatorManager.evaluate("iconStyleId",
               this.iconStyleId, String.class, this, pageContext);
      }

      if (this.getTextErrorStyleId() != null) {
         this.textErrorStyleId = (String) ExpressionEvaluatorManager.evaluate("textErrorStyleId",
               this.textErrorStyleId, String.class, this, pageContext);
      }

      if (this.getDependentFields() != null) {
         this.dependentFields = (String) ExpressionEvaluatorManager.evaluate("dependentFields",
               this.dependentFields, String.class, this, pageContext);
      }

      if (this.getValidations() != null) {
         this.validations = (String) ExpressionEvaluatorManager.evaluate("validations",
               this.validations, String.class, this, pageContext);

         if (this.getErrorKey() == null) {
            throw new JspException("The field validator tag " +
               this.getSource() + " must to define the errorKey");
         }

         if ((this.getValidationMessageFunction() == null) &&
               (this.getValidationFieldMessageMode() == null) &&
               (this.getValidations().indexOf("ONCHANGE") != -1)) {
            throw new JspException("The field validator tag " +
               this.getSource() +
               " must to define the validationFieldMessageMode or the validationMessageFunction");
         }
      }

      if (this.getIndicator() != null) {
         this.indicator = (String) ExpressionEvaluatorManager.evaluate("indicator",
               this.indicator, String.class, this, pageContext);
      }

      //TagUtils tagUtils = TagUtils.getInstance();
      FieldValidatorTagHelper.generateValidation(this);

      //		if (this.source!=null&&this.validations!=null&&this.validationFieldMessageMode!=null){
      //			if (this.validations.toUpperCase().indexOf("ONCHANGE")!=-1){
      //				StringBuffer buffer = new StringBuffer();
      //	            buffer.append("<script type=\"text/javascript\">");
      //	            buffer.append("buildValidacioField(\'"+this.getSource()+"\',\'"+this.getValidations()+"\',\'"+this.getValidationFieldMessageMode()+"\',\'" +this.getSourceErrorTooltip()+"\',\'"+this.getIconStyleId()+"\',\'"+this.getTextErrorStyleId()+"\',\'"+this.getErrorClass()+"\',\'"+this.getValidationMessageFunction()+"\',\'"+this.getDependentFields()+"\',\'"+this.getErrorKey()+"\',\'"+this.getIndicator()+"\");");
      //	            buffer.append("</script>");
      //	            tagUtils.write(this.getPageContext(), buffer.toString());
      //			}
      //		}
      //		
      //		if (this.source!=null&&this.getValidationFieldMessageMode()!=null){
      //		     StringBuffer bufferItems = new StringBuffer();
      //		     bufferItems.append("<script type=\"text/javascript\">");
      //		     bufferItems.append("itemsForm.put(\""+this.source+"\",\""+this.getValidationFieldMessageMode()+ "\")");
      //		    
      //		     if (this.getSourceErrorTooltip()!=null&&!this.getSourceErrorTooltip().equals("")){
      //		          	bufferItems.append(";itemsForm.put(\""+this.source+"Tooltip"+"\",\""+this.getSourceErrorTooltip()+ "\")");
      //		     }
      //		     if (this.getIconStyleId()!=null&&!this.getIconStyleId().equals("")){
      //		       	bufferItems.append(";itemsForm.put(\""+this.source+"Icon"+"\",\""+this.getIconStyleId()+ "\")");
      //		            	
      //		     }
      //		     if (this.getTextErrorStyleId()!=null&&!this.getTextErrorStyleId().equals("")){
      //		       	bufferItems.append(";itemsForm.put(\""+this.source+"Text"+"\",\""+this.getTextErrorStyleId()+ "\")");
      //		     }
      //		     if (this.getErrorClass()!=null&&!this.getErrorClass().equals("")){
      //		       	bufferItems.append(";itemsForm.put(\""+this.source+"errorClass"+"\",\""+this.getErrorClass()+ "\")");
      //		     }
      //		     
      //		     bufferItems.append("</script>");
      //	         tagUtils.write(this.getPageContext(), bufferItems.toString());
      //		  
      //		    }
      //		
      //		   // Recogemos en un Hashtable los parametros de todos los campos del formulario 
      //		  //para la validacion en el submit
      //		    		   
      //		   if (this.source!=null&&this.validations!=null){
      //			   if (this.validations.toUpperCase().indexOf("ONSUBMIT")!=-1){
      //			       StringBuffer bufferSubmit = new StringBuffer();
      //			       bufferSubmit.append("<script type=\"text/javascript\">");
      //			       String validaciones = this.getValidations();
      //			       int ini=validaciones.lastIndexOf(",");
      //			       int fin=validaciones.length();
      //			       String valSubmit = validaciones.substring(ini+1,fin);
      //			      
      //			       bufferSubmit.append("itemsSubmit.put(\""+this.getSource()+"\",\""+valSubmit+ "\")");
      //			       bufferSubmit.append(";");
      //			       bufferSubmit.append("itemsSubmit.put(\""+this.getSource()+"DependentFields\",\""+this.getDependentFields()+ "\")");
      //			       bufferSubmit.append(";");
      //			       bufferSubmit.append("itemsSubmit.put(\""+this.getSource()+"ErrorKey\",\""+this.getErrorKey()+ "\")");
      //			       bufferSubmit.append("</script>");
      //			       tagUtils.write(this.getPageContext(), bufferSubmit.toString());
      //			   }    
      //		  
      //		    
      //		   
      //		   // Guardamos en sesion los campos del formulario que tienen validacion en el submit
      //		  
      //		      String validaciones = this.getValidations();
      //		      int ini=validaciones.lastIndexOf(",");
      //		      int fin=validaciones.length();
      //		      String valSubmit = validaciones.substring(ini+1,fin);
      //		             
      //		             String identificadorForm = (String)this.getPageContext().getRequest().getAttribute("identificadorForm");
      //		             
      //		             JSONObject par =  null;
      //		             
      //		             if (this.getPageContext().getSession().getAttribute(identificadorForm)!= null){
      //		            	 par = (JSONObject)this.getPageContext().getSession().getAttribute(identificadorForm);
      //		            	 JSONArray paramsCamps = par.getJSONArray("camps");
      //		            	 JSONObject p =  new JSONObject();
      //		                 p.put("nomCamp",this.getSource());
      //		                 p.put("validacio",valSubmit);
      //		                 p.put("errorKey",this.getErrorKey());
      //		                 if (this.getDependentFields()!=null)
      //		                     p.put("dependentFields",this.getDependentFields());
      //		                 else
      //		                	 p.put("dependentFields","");
      //		            	 paramsCamps.put(paramsCamps.length(),p);
      //		            	
      //		             }else{
      //		            	 par =  new JSONObject();
      //		            	 JSONObject p =  new JSONObject();
      //		                 p.put("nomCamp",this.getSource());
      //		                 p.put("validacio",valSubmit);
      //		                 p.put("errorKey",this.getErrorKey());
      //		                 if (this.getDependentFields()!=null)
      //		                     p.put("dependentFields",this.getDependentFields());
      //		                 else
      //		                	 p.put("dependentFields","");
      //		            	 par.append("camps",p);
      //		             }
      //		                
      //		             this.getPageContext().getSession().setAttribute(identificadorForm,par);
      //		             
      //		             System.out.println("json*************"+par.toString());
      //		   }
      return super.doStartTag();
   }

   /**
    * Fi de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doEndTag() throws JspException {
      return super.doStartTag();
   }

   /**
    * Liberar tots els camps configurats per tal de no copiar en els
    * pr�xims tags.
    */
   public void release() {
      super.release();
      appendContextPath = true;
      contextSubpath = null;
      validations = null;
      validationFieldMessageMode = null;
      validationMessageFunction = null;
      sourceErrorTooltip = null;
      iconStyleId = null;
      textErrorStyleId = null;
      errorKey = null;
      indicator = null;
   }

   /**
    * Documentaci�.
    *
    * @return PageContext
    */
   public PageContext getPageContext() {
      return pageContext;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @return I18nService
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Id d'enlla� amb la configuraci� XML.
    *
    * @return String
    */
   public String getStyleId() {
      return styleId;
   }

   /**
    * Id d'enlla� amb la configuraci� XML.
    *
    * @param styleId String
    */
   public void setStyleId(String styleId) {
      this.styleId = styleId;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @param validationService ValidationService
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * Documentaci�.
    *
    * @param appendContextPath boolean
    */
   public void setAppendContextPath(boolean appendContextPath) {
      this.appendContextPath = appendContextPath;
   }

   /**
    * Documentaci�.
    *
    * @return boolean
    */
   public boolean getAppendContextPath() {
      return this.appendContextPath;
   }

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getContextSubpath() {
      return contextSubpath;
   }

   /**
    * Documentaci�.
    *
    * @param contextSubpath String
    */
   public void setContextSubpath(String contextSubpath) {
      this.contextSubpath = contextSubpath;
   }

   /**
    * Documentaci�.
    *
    * @return long
    */
   public static long getSerialVersionUID() {
      return serialVersionUID;
   }

   /**
    * Estil quan es produeix un error.
    *
    * @return String
    */
   public String getErrorClass() {
      return errorClass;
   }

   /**
    * Estil quan es produeix un error.
    *
    * @param errorClass String
    */
   public void setErrorClass(String errorClass) {
      this.errorClass = errorClass;
   }

   /**
    * Identificador de l' icona.
    *
    * @return String
    */
   public String getIconStyleId() {
      return iconStyleId;
   }

   /**
    * Identificador de l' icona.
    *
    * @param iconStyleId String
    */
   public void setIconStyleId(String iconStyleId) {
      this.iconStyleId = iconStyleId;
   }

   /**
    * Identificador origen.
    *
    * @return String
    */
   public String getSource() {
      return source;
   }

   /**
    * Identificador origen.
    *
    * @param source String
    */
   public void setSource(String source) {
      this.source = source;
   }

   /**
    * validacions pel camp.
    *
    * @return String
    */
   public String getValidations() {
      return validations;
   }

   /**
    * validacions pel camp.
    *
    * @param validations String
    */
   public void setValidations(String validations) {
      this.validations = validations;
   }

   /**
    * Tipus de validaci� que volem mostrar quan salta la validaci�.
    * valors possibles: ICON,TOOLTIP,CHANGESTYLE,TEXTERROR
    *
    * @return String
    */
   public String getValidationFieldMessageMode() {
      return validationFieldMessageMode;
   }

   /**
    * Tipus de validaci� que volem mostrar quan salta la validaci�.
    * valors possibles: ICON,TOOLTIP,CHANGESTYLE,TEXTERROR
    *
    * @param validationFieldMessageMode String
    */
   public void setValidationFieldMessageMode(String validationFieldMessageMode) {
      this.validationFieldMessageMode = validationFieldMessageMode;
   }

   /**
    * Div amb el text d'error..
    *
    * @return String
    */
   public String getTextErrorStyleId() {
      return textErrorStyleId;
   }

   /**
    * Div amb el text d'error.
    *
    * @param textErrorStyleId String
    */
   public void setTextErrorStyleId(String textErrorStyleId) {
      this.textErrorStyleId = textErrorStyleId;
   }

   /**
    * Tipus tooltip en error.
    *
    * @return String
    */
   public String getSourceErrorTooltip() {
      return sourceErrorTooltip;
   }

   /**
    * Tipus tooltip en error.
    *
    * @param sourceErrorTooltip String
    */
   public void setSourceErrorTooltip(String sourceErrorTooltip) {
      this.sourceErrorTooltip = sourceErrorTooltip;
   }

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getValidationMessageFunction() {
      return validationMessageFunction;
   }

   /**
    * Documentaci�.
    *
    * @param validationMessageFunction String
    */
   public void setValidationMessageFunction(String validationMessageFunction) {
      this.validationMessageFunction = validationMessageFunction;
   }

   /**
    * Camps Dependents.
    *
    * @return String
    */
   public String getDependentFields() {
      return dependentFields;
   }

   /**
    * Camps Dependents.
    *
    * @param dependentFields String
    */
   public void setDependentFields(String dependentFields) {
      this.dependentFields = dependentFields;
   }

   /**
    * Nom del camp internacionalitzat.
    *
    * @return String
    */
   public String getErrorKey() {
      return errorKey;
   }

   /**
    * Nom del camp internacionalitzat.
    *
    * @param errorKey String
    */
   public void setErrorKey(String errorKey) {
      this.errorKey = errorKey;
   }

   /**
    * El que es mostra quan es fa petici� AJAX.
    *
    * @return String
    */
   public String getIndicator() {
      return indicator;
   }

   /**
    * El que es mostra quan es fa petici� AJAX.
    *
    * @param indicator String
    */
   public void setIndicator(String indicator) {
      this.indicator = indicator;
   }
}
