/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers;

import java.util.StringTokenizer;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;

import net.gencat.ctti.canigo.services.web.spring.util.WebApplicationContextUtils;

import ognl.Ognl;
import ognl.OgnlException;

import org.springframework.web.context.WebApplicationContext;


/**
 * Helper de Select Field Tag.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class ServicesTagHelper {
   /**
    * Injecta el servei del contenidor d' spring.
    *
    * @param services String
    * @param pageContext PageContext
    * @param tag Tag
    *
    * @throws JspException
    */
   public static void setServices(String services, PageContext pageContext,
      Tag tag) throws JspException {
      WebApplicationContext appContext = WebApplicationContextUtils.getWebApplicationContext(pageContext.getServletContext());
      StringTokenizer st = new StringTokenizer(services, ",");

      while (st.hasMoreTokens()) {
         String serviceDef = st.nextToken();

         StringTokenizer st2 = new StringTokenizer(serviceDef, ":");

         String serviceName = null;
         String serviceId = null;

         try {
            serviceName = st2.nextToken();
            serviceId = st2.nextToken();
         } catch (Exception ex) {
            throw new JspException("Attribute services of tag " +
               tag.getClass().getName() + " has an invalid value: \"" +
               serviceDef + "\".");
         }

         Object service = appContext.getBean(serviceId);

         if (service == null) {
            throw new JspException(" service with id \"" + serviceId +
               "\" not found in Spring Context.");
         } else {
            try {
               Ognl.setValue(serviceName, tag, service);
            } catch (OgnlException e) {
               throw new JspException(serviceName + " is not a valid service.");
            }
         }
      }
   }
}
