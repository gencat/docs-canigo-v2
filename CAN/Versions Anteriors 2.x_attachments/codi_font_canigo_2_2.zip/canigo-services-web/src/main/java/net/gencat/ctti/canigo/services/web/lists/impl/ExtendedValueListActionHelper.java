/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
/**
 * aaa
 */
package net.gencat.ctti.canigo.services.web.lists.impl;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import net.gencat.ctti.canigo.core.util.beanutils.BeanUtils;
import net.gencat.ctti.canigo.services.web.lists.impl.SimpleValueListActionHelper;
import net.gencat.ctti.canigo.services.web.struts.SpringBindingActionForm;
import net.mlw.vlh.ValueListInfo;

import org.apache.struts.action.ActionForm;


/**
 * Search for logs exposing the properties inside the SpringBindingActionForm
 * @author MMR
 *
 */
public class ExtendedValueListActionHelper extends SimpleValueListActionHelper {
   /**
    * Documentaci�.
    */
   private List exposedProperties = null;

   /**
    * @return Returns the exposedProperties.
    */
   public List getExposedProperties() {
      return exposedProperties;
   }

   /**
    * @param exposedProperties The exposedProperties to set.
    */
   public void setExposedProperties(List exposedProperties) {
      this.exposedProperties = exposedProperties;
   }

   /**
    * Documentaci�.
    *
    * @param info Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    */
   public void addCustomFilters(ValueListInfo info, ActionForm form,
      HttpServletRequest request) {
      super.addCustomFilters(info, form, request);

      if ((this.exposedProperties != null) && (form != null) &&
            form instanceof SpringBindingActionForm) {
         Iterator it = this.exposedProperties.iterator();

         while (it.hasNext()) {
            String property = (String) it.next();
            this.getLogService().getLog(this.getClass())
                .debug("Exposing property " + property);

            Object value = null;

            try {
               value = BeanUtils.getProperty(((SpringBindingActionForm) form).getTarget(),
                     property);

               if (value != null) {
                  this.getLogService().getLog(this.getClass())
                      .debug("Property " + property + " has value=" + value);
                  info.getFilters().put(property, value.toString());
               }
            } catch (Exception ex) {
               this.getLogService().getLog(this.getClass())
                   .warn("Error getting " + property, ex);
            }
         }
      }
   }
}
