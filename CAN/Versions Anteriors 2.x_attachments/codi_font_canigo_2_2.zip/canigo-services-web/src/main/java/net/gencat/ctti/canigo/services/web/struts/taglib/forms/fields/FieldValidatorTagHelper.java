/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields;

import javax.servlet.jsp.JspException;

import net.gencat.ctti.canigo.services.web.taglib.FieldTag;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.taglib.TagUtils;


/**
 * <p>Definici� de les propietats del Tag FieldValidatorTagHelper.</p>
 *
 * @author
 *
 * @version v 1.6 2007/07/16 08:45:51 msabates
 */
public class FieldValidatorTagHelper {
   /**
    * Nom del validador.
    */
   public static final String VALIDATOR_NAME = "validatorName";

   /**
    * Tipus de validacio.
    */
   public static final String VALIDATION_TYPE = "validationType";

   /**
    * Documentaci�.
    */
   private static final String REQUIRED_ATTRIBUTE = " required";

   /**
    * Crea un objecte FieldValidatorTagHelper nou.
    */
   public FieldValidatorTagHelper() {
      super();
   }

   /**
    * Genera la validaci� mitjan�ant FieldValidatorTag.
    *
    * @param fieldValidatorTag FieldValidatorTag
    *
    * @throws JspException
    */
   public static void generateValidation(FieldValidatorTag fieldValidatorTag)
      throws JspException {
      TagUtils tagUtils = TagUtils.getInstance();

      if ((fieldValidatorTag.getSource() != null) &&
            (fieldValidatorTag.getValidations() != null) &&
            (fieldValidatorTag.getValidationFieldMessageMode() != null)) {
         if (fieldValidatorTag.getValidations().toUpperCase().indexOf("ONCHANGE") != -1) {
            String validacions = null;

            if (fieldValidatorTag.getValidations().toUpperCase()
                                    .indexOf("ONSUBMIT") != -1) {
               int fin = fieldValidatorTag.getValidations().toUpperCase()
                                          .indexOf("ONSUBMIT");
               String valOnchange = fieldValidatorTag.getValidations()
                                                     .substring(0, fin);
               validacions = valOnchange.substring(valOnchange.lastIndexOf("(") +
                     1, valOnchange.lastIndexOf(")"));
            } else {
               int ini = fieldValidatorTag.getValidations().lastIndexOf("(");
               int fin = fieldValidatorTag.getValidations().length();
               validacions = fieldValidatorTag.getValidations()
                                              .substring(ini + 1, fin);
            }

            if (validacions.indexOf("required") != -1) {
               Object field = TagUtil.getTag(fieldValidatorTag.getPageContext(),
                     fieldValidatorTag.getSource());

               if (field instanceof FieldTag) {
                  FieldTag fieldTag = (FieldTag) field;
                  fieldTag.setStyleClass(((fieldTag.getStyleClass() != null)
                     ? fieldTag.getStyleClass() : "") + REQUIRED_ATTRIBUTE);
               }
            }

            StringBuffer buffer = new StringBuffer();
            buffer.append("<script type=\"text/javascript\">");
            buffer.append("buildValidacioField(\'" +
               fieldValidatorTag.getSource() + "\',\'" + validacions + "\',\'" +
               fieldValidatorTag.getValidationFieldMessageMode() + "\',\'" +
               fieldValidatorTag.getSourceErrorTooltip() + "\',\'" +
               fieldValidatorTag.getIconStyleId() + "\',\'" +
               fieldValidatorTag.getTextErrorStyleId() + "\',\'" +
               fieldValidatorTag.getErrorClass() + "\',\'" +
               fieldValidatorTag.getValidationMessageFunction() + "\',\'" +
               fieldValidatorTag.getDependentFields() + "\',\'" +
               fieldValidatorTag.getErrorKey() + "\',\'" +
               fieldValidatorTag.getIndicator() + "\');");
            buffer.append("</script>");
            tagUtils.write(fieldValidatorTag.getPageContext(), buffer.toString());
         }
      }

      if ((fieldValidatorTag.getSource() != null) &&
            (fieldValidatorTag.getValidationFieldMessageMode() != null)) {
         StringBuffer bufferItems = new StringBuffer();
         bufferItems.append("<script type=\"text/javascript\">");
         bufferItems.append("itemsForm.put(\"" + fieldValidatorTag.getSource() +
            "\",\"" + fieldValidatorTag.getValidationFieldMessageMode() +
            "\")");

         if ((fieldValidatorTag.getSourceErrorTooltip() != null) &&
               !fieldValidatorTag.getSourceErrorTooltip().equals("")) {
            bufferItems.append(";itemsForm.put(\"" +
               fieldValidatorTag.getSource() + "Tooltip" + "\",\"" +
               fieldValidatorTag.getSourceErrorTooltip() + "\")");
         }

         if ((fieldValidatorTag.getIconStyleId() != null) &&
               !fieldValidatorTag.getIconStyleId().equals("")) {
            bufferItems.append(";itemsForm.put(\"" +
               fieldValidatorTag.getSource() + "Icon" + "\",\"" +
               fieldValidatorTag.getIconStyleId() + "\")");
         }

         if ((fieldValidatorTag.getTextErrorStyleId() != null) &&
               !fieldValidatorTag.getTextErrorStyleId().equals("")) {
            bufferItems.append(";itemsForm.put(\"" +
               fieldValidatorTag.getSource() + "Text" + "\",\"" +
               fieldValidatorTag.getTextErrorStyleId() + "\")");
         }

         if ((fieldValidatorTag.getErrorClass() != null) &&
               !fieldValidatorTag.getErrorClass().equals("")) {
            bufferItems.append(";itemsForm.put(\"" +
               fieldValidatorTag.getSource() + "errorClass" + "\",\"" +
               fieldValidatorTag.getErrorClass() + "\")");
         }

         bufferItems.append("</script>");
         tagUtils.write(fieldValidatorTag.getPageContext(),
            bufferItems.toString());
      }

      // Recogemos en un Hashtable los parametros de todos los campos del formulario 
      //para la validacion en el submit
      if ((fieldValidatorTag.getSource() != null) &&
            (fieldValidatorTag.getValidations() != null)) {
         String validacions = null;

         if (fieldValidatorTag.getValidations().toUpperCase().indexOf("ONSUBMIT") != -1) {
            if (fieldValidatorTag.getValidations().toUpperCase()
                                    .indexOf("ONCHANGE") != -1) {
               int ini = fieldValidatorTag.getValidations().indexOf("ONSUBMIT");
               int fin = fieldValidatorTag.getValidations().length();
               String valOnsubmit = fieldValidatorTag.getValidations()
                                                     .substring(ini, fin);
               validacions = valOnsubmit.substring(valOnsubmit.lastIndexOf("(") +
                     1, valOnsubmit.lastIndexOf(")"));
            } else {
               int ini = fieldValidatorTag.getValidations().lastIndexOf("(");
               int fin = fieldValidatorTag.getValidations().lastIndexOf(")");
               validacions = fieldValidatorTag.getValidations()
                                              .substring(ini + 1, fin);
            }

            if (validacions.indexOf("required") != -1) {
               Object field = TagUtil.getTag(fieldValidatorTag.getPageContext(),
                     fieldValidatorTag.getSource());

               if (field instanceof FieldTag) {
                  FieldTag fieldTag = (FieldTag) field;
                  fieldTag.setStyleClass(((fieldTag.getStyleClass() != null)
                     ? fieldTag.getStyleClass() : "") + REQUIRED_ATTRIBUTE);
               }
            }

            StringBuffer bufferSubmit = new StringBuffer();
            bufferSubmit.append("<script type=\"text/javascript\">");

            bufferSubmit.append("itemsSubmit.put(\"" +
               fieldValidatorTag.getSource() + "\",\"" + validacions + "\")");
            bufferSubmit.append(";");
            bufferSubmit.append("itemsSubmit.put(\"" +
               fieldValidatorTag.getSource() + "DependentFields\",\"" +
               fieldValidatorTag.getDependentFields() + "\")");
            bufferSubmit.append(";");
            bufferSubmit.append("itemsSubmit.put(\"" +
               fieldValidatorTag.getSource() + "ErrorKey\",\"" +
               fieldValidatorTag.getErrorKey() + "\")");
            bufferSubmit.append("</script>");
            tagUtils.write(fieldValidatorTag.getPageContext(),
               bufferSubmit.toString());

            // Guardamos en sesion los campos del formulario que tienen validacion en el submit
            String identificadorForm = (String) fieldValidatorTag.getPageContext()
                                                                 .getRequest()
                                                                 .getAttribute("identificadorForm");
            JSONObject par = null;

            if (fieldValidatorTag.getPageContext().getSession()
                                    .getAttribute(identificadorForm) != null) {
               par = (JSONObject) fieldValidatorTag.getPageContext().getSession()
                                                   .getAttribute(identificadorForm);

               JSONArray paramsCamps = par.getJSONArray("camps");
               JSONObject p = new JSONObject();
               p.put("nomCamp", fieldValidatorTag.getSource());
               p.put("validacio", validacions);
               p.put("errorKey", fieldValidatorTag.getErrorKey());

               if (fieldValidatorTag.getDependentFields() != null) {
                  p.put("dependentFields",
                     fieldValidatorTag.getDependentFields());
               } else {
                  p.put("dependentFields", "");
               }

               paramsCamps.put(paramsCamps.length(), p);
            } else {
               par = new JSONObject();

               JSONObject p = new JSONObject();
               p.put("nomCamp", fieldValidatorTag.getSource());
               p.put("validacio", validacions);
               p.put("errorKey", fieldValidatorTag.getErrorKey());

               if (fieldValidatorTag.getDependentFields() != null) {
                  p.put("dependentFields",
                     fieldValidatorTag.getDependentFields());
               } else {
                  p.put("dependentFields", "");
               }

               par.append("camps", p);
            }

            fieldValidatorTag.getPageContext().getSession()
                             .setAttribute(identificadorForm, par);
         }
      }
   }
}
