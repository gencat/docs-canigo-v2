/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.util;

import java.util.Properties;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;

import net.gencat.ctti.canigo.services.web.struts.SpringBindingActionForm;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.FormTag;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.DWRHelper;
import net.gencat.ctti.canigo.services.web.taglib.Constants;
import net.gencat.ctti.canigo.services.web.validation.taglib.JavascriptValidatorTag;
import net.sf.json.JSONObject;

import org.apache.log4j.Logger;
import org.apache.struts.taglib.TagUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class FormTagHelper {
   /**
    * Documentaci�.
    */
   public static final String CLIENT_VALIDATION = "CLIENT";

   /**
    * Documentaci�.
    */
   public static final String SERVER_VALIDATION = "SERVER";

   /**
    * Documentaci�.
    */
   public static final String VALIDATOR_NAME = "validatorName";

   /**
    * Documentaci�.
    */
   public static final String VALIDATION_TYPE = "validationType";

   /**
    * Documentaci�.
    */
   private static final String VALIDATORNAME = "%%VALIDATORNAME";

   /**
        * Imported scripts flag.
        */
   private static final String FORM_TAG_IMPORTED_SCRIPTS = "__form_tag_imported_scripts__";

   /**
    * Documentaci�.
    */
   private static Logger log = Logger.getLogger(FormTagHelper.class);

   /**
    * Creates a new FormTagHelper object.
    */
   public FormTagHelper() {
      super();
   }

   /**
    * Documentaci�.
    *
    * @param pageContext Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public static void generateScripts(PageContext pageContext)
      throws JspException {
      // EVC: import engine.js if not imported yet
      DWRHelper.generateDWREngineScript(pageContext);

      // EVC: import tag scripts if not imported yet.
      HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
      HttpServletResponse response = (HttpServletResponse) pageContext.getResponse();

      if ((request.getAttribute(FORM_TAG_IMPORTED_SCRIPTS) == null)) {
         request.setAttribute(FORM_TAG_IMPORTED_SCRIPTS, Constants.IMPORTED);

         TagUtils tagUtils = TagUtils.getInstance();
         tagUtils.write(pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() +
            response.encodeURL("/dwr/interface/webValidationService.js") +
            "\"></script>");
         tagUtils.write(pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() +
            response.encodeURL("/scripts/Tokenizer/Tokenizer.js") +
            "\"></script>");
         tagUtils.write(pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() + response.encodeURL("/scripts/json.js") +
            "\"></script>");
         tagUtils.write(pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() +
            response.encodeURL("/scripts/ajax/json/json.js") + "\"></script>");
         tagUtils.write(pageContext,
            "\n<script type=\"text/javascript\" src=\"" +
            request.getContextPath() +
            response.encodeURL(
               "/scripts/ajax/ajaxtags/canigo-ajaxtags-validation.js") +
            "\"></script>\n");
      }
   }

   /**
    * Documentaci�.
    *
    * @param formTag Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public static void generateValidation(FormTag formTag)
      throws JspException {
      if (log.isDebugEnabled()) {
         log.debug("-> generateValidation(" + formTag.getId() + ")");
      }

      Properties validationProperties = formTag.getValidationProperties();
      String validatorName = "";

      if (validationProperties != null) {
         if (log.isDebugEnabled()) {
            log.debug("Conf XML FormTag: Validation Type:" +
               validationProperties.get(VALIDATION_TYPE) + " Validation Name:" +
               validationProperties.getProperty(VALIDATOR_NAME));
         }

         if (validationProperties.get(VALIDATION_TYPE) != null) {
            validatorName = (String) validationProperties.get(VALIDATOR_NAME);

            String validationType = (String) validationProperties.get(VALIDATION_TYPE);

            if (validatorName == null) {
               if (validationType.toUpperCase().equals(SERVER_VALIDATION)) {
                  // per compatibilitat amb versi� 1.0 si el validatorName es null s'assumeix que es
                  // el nom de la pojoClass en el cas de servidor.
                  Object bean = formTag.getPageContext()
                                       .findAttribute(formTag.getStyleId());

                  if (bean instanceof SpringBindingActionForm) {
                     SpringBindingActionForm actionForm = (SpringBindingActionForm) bean;
                     validatorName = actionForm.getPojoClassName();
                  } else {
                     log.error("The actionForm " + formTag.getStyleId() +
                        " in the action " + formTag.getAction() +
                        " is not a SpringBindingActionForm. Canigo can't obtain the validatorName. You must write it");
                  }

                  if (log.isDebugEnabled()) {
                     log.debug("The validator name in the formTag " +
                        formTag.getStyleId() +
                        " is not configurated. The value assumed is:" +
                        validatorName);
                  }
               } else {
                  throw new JspException(
                     "The validatorName is null in formTag " +
                     formTag.getStyleId() + " with action " +
                     formTag.getAction());
               }
            }

            //  add validator name to the session.
            addValidatorNameInSession(formTag, validatorName);

            if (validationType.toUpperCase().equals(SERVER_VALIDATION)) {
               if (formTag.getMode() != null) {
                  if (formTag.getMode().toUpperCase().equals(CLIENT_VALIDATION)) {
                     //    	   			    	    ExceptionDetails exDetails = new ExceptionDetails("errors.configValidacioNoCorrecta",new Object[]{""},Layer.SERVICES,Subsystem.WEB_LISTS_SERVICES);
                     //    	   			    		SystemException vse = new SystemException(exDetails);
                     //    	   			    	    throw  vse; 
                     throw new JspException(
                        "La configuraci� de la validaci�n no �s correcta para el form" +
                        formTag.getStyleId() +
                        ".El atributo mode del decorador:" + formTag.getMode() +
                        "es incongruente con la configuraci�n en xml:" +
                        validationType);
                  } else {
                     if (log.isDebugEnabled()) {
                        log.debug("Apply server validation in form " +
                           formTag.getStyleId() +
                           " without formtag mode configurated");
                     }

                     validateOnServer(formTag, validatorName);
                  }
               } else {
                  if (log.isDebugEnabled()) {
                     log.debug("Apply server validation in form " +
                        formTag.getStyleId() +
                        " with formtag mode configurated");
                  }

                  validateOnServer(formTag, validatorName);
               }
            } else {
               //validaci� client
               if (validationType.toUpperCase().equals(CLIENT_VALIDATION)) {
                  if (formTag.getMode() != null) {
                     if (formTag.getMode().toUpperCase()
                                   .equals(SERVER_VALIDATION)) {
                        //    	      			     	   ExceptionDetails exDetails = new ExceptionDetails("errors.configValidacioNoCorrecta",new Object[]{""},Layer.SERVICES,Subsystem.WEB_LISTS_SERVICES);
                        //     	   			    		   SystemException vse = new SystemException(exDetails);
                        //     	   			    	       throw  vse; 
                        throw new JspException(
                           "La configuraci� de la validaci�n no �s correcta para el form" +
                           formTag.getStyleId() +
                           ".El atributo mode del decorador:" +
                           formTag.getMode() +
                           "es incongruente con la configuraci�n en xml:" +
                           validationType);
                     } else {
                        if (log.isDebugEnabled()) {
                           log.debug("Apply client validation in form " +
                              formTag.getStyleId() +
                              " with formtag mode configurated");
                        }

                        validateOnClient(formTag, validatorName);
                     }
                  } else {
                     if (log.isDebugEnabled()) {
                        log.debug("Apply client validation in form " +
                           formTag.getStyleId() +
                           " without formtag mode configurated");
                     }

                     validateOnClient(formTag, validatorName);
                  }
               } else {
                  log.error("The validationType " + validationType +
                     " in form tag " + formTag.getStyleId() + " is incorrect");
                  throw new JspException("The validationType " +
                     validationType + " in form tag " + formTag.getStyleId() +
                     " is incorrect");
               }
            }
         } else {
            throw new JspException("The validatorType is null in formTag " +
               formTag.getStyleId() + " with action " + formTag.getAction());
         }
      } else {
         if (log.isDebugEnabled()) {
            log.debug("The formTag " + formTag.getId() +
               " doesn't have configuration in the Spring XML");
         }

         //sense configuraci� en el xml per validacions. No hi ni tag validationProperties.
         // configuraci� correcte.
         if ((formTag.getValidationFormMessageMode() != null) &&
               !formTag.getValidationFormMessageMode().equals("")) {
            if (log.isDebugEnabled()) {
               log.debug("The formTag " + formTag.getId() +
                  " has the new JSP validations system configurated.");
            }

            if (formTag.getMode() != null) {
               if (formTag.getMode().toUpperCase().equals(SERVER_VALIDATION)) {
                  validateOnServer(formTag, validatorName);
               } else if (formTag.getMode().toUpperCase()
                                    .equals(CLIENT_VALIDATION)) {
                  validateOnClient(formTag, validatorName);
               }
            } else {
               throw new JspException(
                  "You need to write the mode attribute in the form tag " +
                  formTag.getStyleId());
            }
         } else {
            if (log.isDebugEnabled()) {
               log.debug("If the formTag " + formTag.getId() +
                  " would have validations, you need to write the atribute validationFormMessageMode in the fwk:form");
            }

            if (log.isInfoEnabled()) {
               log.info("The formTag " + formTag.getId() +
                  " doesn't have validations");
            }
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param formTag Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public static void generateBehaviour(FormTag formTag)
      throws JspException {
      TagUtils tagUtils = TagUtils.getInstance();
      tagUtils.write(formTag.getPageContext(),
         "<script type=\"text/javascript\"> if(typeof(Behaviour)!='undefined')Behaviour.apply(); </script>");
   }

   /**
    * Documentaci�.
    *
    * @param formTag Documentaci�
    * @param validatorName Documentaci�
    *
    * @throws JspException Documentaci�
    */
   private static void addValidatorNameInSession(FormTag formTag,
      String validatorName) throws JspException {
      String tmpIdForm = (String) formTag.getPageContext().getRequest()
                                         .getAttribute("identificadorForm");

      if (tmpIdForm != null) {
         formTag.getPageContext().getSession()
                .setAttribute(tmpIdForm + VALIDATORNAME, validatorName);
      } else {
         throw new JspException(
            "The formId is not in the pageContext. the formTag is " +
            formTag.getStyleId() +
            " You must use fwk:form tag for validations");
      }
   }

   /**
    * Create code for alert in Javascript
    * @param formTag
    */
   private static void validateOnClient(FormTag formTag, String validatorName)
      throws JspException {
      //Generate code from tag JavaScript Validator Tag	
      if (log.isDebugEnabled()) {
         if (formTag != null) {
            log.debug("-> validateOnClient(" + formTag.getId() + "," +
               validatorName + ")");
         } else {
            log.debug("-> validateOnClient(null," + validatorName + ")");
         }
      }

      String identificador = (String) formTag.getPageContext().getRequest()
                                             .getAttribute("identificadorForm");

      if (log.isDebugEnabled()) {
         log.debug("Form Identifier:" + identificador);
      }

      if ((validatorName == null) || validatorName.equals("")) {
         if (formTag != null) {
            validatorName = formTag.getStyleId();
         } else {
            throw new JspException(
               "ValidatorName no informat i no hi ha tag de formulari en construir les validacions");
         }
      }

      if ((identificador != null) && !identificador.equals("")) {
         JSONObject paramsOnSubmit = (JSONObject) formTag.getPageContext()
                                                         .getSession()
                                                         .getAttribute(identificador);

         if ((paramsOnSubmit != null) && !paramsOnSubmit.equals("")) { // validacions noves.

            if (log.isDebugEnabled()) {
               log.debug("Generar js amb validacions noves");
            }

            JavascriptValidatorOnSubmmitTag javascriptValidatorOnSubmitTag = new JavascriptValidatorOnSubmmitTag();
            javascriptValidatorOnSubmitTag.setPageContext(formTag.getPageContext());
            javascriptValidatorOnSubmitTag.setFormName(validatorName);
            javascriptValidatorOnSubmitTag.setStaticJavascript("false");
            javascriptValidatorOnSubmitTag.setI18nService(formTag.getI18nService());
            javascriptValidatorOnSubmitTag.doStartTag(paramsOnSubmit);
            javascriptValidatorOnSubmitTag.doEndTag();
         } else { // no hi ha validacions noves.

            if (log.isDebugEnabled()) {
               log.debug("Generar js amb per validacions del commons");
            }

            JavascriptValidatorTag javascriptValidatorTag = new JavascriptValidatorTag();
            javascriptValidatorTag.setPageContext(formTag.getPageContext());
            javascriptValidatorTag.setFormName(validatorName);
            javascriptValidatorTag.setStaticJavascript("false");
            javascriptValidatorTag.doStartTag();
            javascriptValidatorTag.doEndTag();
         }
      } else {
         // no hi ha identificador de formulari. Cas estrany. 
         // Formulari generat sense el tag del fwk.	        	
         if (log.isDebugEnabled()) {
            log.debug("Generar js amb per validacions del commons");
         }

         JavascriptValidatorTag javascriptValidatorTag = new JavascriptValidatorTag();
         javascriptValidatorTag.setPageContext(formTag.getPageContext());
         javascriptValidatorTag.setFormName(validatorName);
         javascriptValidatorTag.setStaticJavascript("false");
         javascriptValidatorTag.doStartTag();
         javascriptValidatorTag.doEndTag();
      }

      // Now generate common javascript code for validation
      TagUtils tagUtils = TagUtils.getInstance();
      tagUtils.write(formTag.getPageContext(),
         "<script type=\"text/javascript\">");

      JavascriptValidatorTag commonValidatorTag = new JavascriptValidatorTag();
      commonValidatorTag.setPageContext(formTag.getPageContext());
      commonValidatorTag.setDynamicJavascript("false");
      commonValidatorTag.setStaticJavascript("true");
      commonValidatorTag.doStartTag();
      commonValidatorTag.doEndTag();
      tagUtils.write(formTag.getPageContext(), "</script>");

      // Finally attach behaviour onSubmit to call validation functions
      StringBuffer buffer = new StringBuffer();
      buffer.append("<script type=\"text/javascript\">");
      buffer.append("new CanigoFormTag.ClientValidation({");
      buffer.append("source:\"" + formTag.getStyleId() + "\"");
      buffer.append(",");
      buffer.append("validatorName:\"" + validatorName + "\"");
      buffer.append("});");
      buffer.append("</script>");
      tagUtils.write(formTag.getPageContext(), buffer.toString());

      if (log.isDebugEnabled()) {
         log.debug("<- validateOnClient()");
      }
   }

   /**
   * Create AJAX code validation to call to server with DWR
   * @param formTag
   */
   private static void validateOnServer(FormTag formTag, String validatorName)
      throws JspException {
      if (log.isDebugEnabled()) {
         if (formTag != null) {
            log.debug("-> validateOnServer(" + formTag.getId() + "," +
               validatorName + ")");
         } else {
            log.debug("-> validateOnServer(null," + validatorName + ")");
         }
      }

      Properties validationProperties = formTag.getValidationProperties();

      //String validatorName=null;
      String className = null;

      //Obtain associated bean of form and obtain pojoClass
      Object bean = formTag.getPageContext().findAttribute(formTag.getStyleId());

      if (bean instanceof SpringBindingActionForm) {
         SpringBindingActionForm actionForm = (SpringBindingActionForm) bean;
         className = actionForm.getPojoClassName();
      }

      if (validatorName != null) {
         TagUtils tagUtils = TagUtils.getInstance();
         StringBuffer buffer = new StringBuffer();
         buffer.append("<script type=\"text/javascript\">");
         buffer.append("new CanigoFormTag.ServerValidation({");
         buffer.append("source:\"" + formTag.getStyleId() + "\"");
         buffer.append(",");
         buffer.append("validatorName:\"" + validatorName + "\"");
         //nuevos atributos de validacion
         buffer.append(",");
         buffer.append("className:\"" + className + "\"");
         buffer.append(",");
         buffer.append("validationFormMessageMode:\"" +
            formTag.getValidationFormMessageMode() + "\"");
         buffer.append(",");
         buffer.append("validationMessageFunction:\"" +
            formTag.getValidationMessageFunction() + "\"");
         buffer.append(",");
         buffer.append("errorPanelStyleId:\"" + formTag.getErrorPanelStyleId() +
            "\"");
         buffer.append(",");
         buffer.append("indicator:\"" + formTag.getIndicator() + "\"");
         buffer.append("});");
         buffer.append("</script>");
         tagUtils.write(formTag.getPageContext(), buffer.toString());

         if (log.isDebugEnabled()) {
            log.debug("<- validateOnServer():" + buffer.toString());
         }
      } else {
         if (log.isDebugEnabled()) {
            log.debug(
               "<- validateOnServer(): No write the scripts beacuse the validatorName is null. May be a error?");
         }
      }
   }

   /**
   * Campo oculto como identificador unico de formulario
   * @param formTag
   */
   public static String generateFormIdentification(FormTag formTag)
      throws JspException {
      TagUtils tagUtils = TagUtils.getInstance();
      StringBuffer buffer = new StringBuffer();
      String identificador = null;

      if (formTag.getGenerateId() == null) {
         identificador = "paramsSubmit" + System.currentTimeMillis() +
            new Random(System.currentTimeMillis()).nextInt();
      } else {
         identificador = formTag.getGenerateId();
      }

      buffer.append("<input type=\"hidden\" name=\"" + FormTag.HIDDEN_NAME +
         "\" value=\"" + identificador + "\" />");

      tagUtils.write(formTag.getPageContext(), buffer.toString());

      return identificador;
   }
}
