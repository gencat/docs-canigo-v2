/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.configuration;

import java.io.IOException;

import java.lang.reflect.InvocationTargetException;

import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

import net.gencat.ctti.canigo.core.util.beanutils.BeanUtils;
import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.util.FormTagHelper;
import net.gencat.ctti.canigo.services.web.taglib.FieldTag;
import net.gencat.ctti.canigo.services.web.taglib.FormTag;
import net.gencat.ctti.canigo.services.web.taglib.SelectFieldTag;
import net.gencat.ctti.canigo.services.web.taglib.Tag;
import net.gencat.ctti.canigo.services.web.taglib.TextAreaFieldTag;
import net.gencat.ctti.canigo.services.web.taglib.TextFieldTag;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;

import org.apache.struts.taglib.TagUtils;


/**
 * Tag that configures all tags with needed:
 *  - Javascript includes
 * @author XES
 */
public class ConfigurationTag extends TagSupport implements Tag {
   /**
        *
        */
   private static final long serialVersionUID = 1107866494185767999L;

   /**
    * Documentaci�.
    */
   boolean dwrLibrariesAdded = false;

   /**
   * I18nService
   */
   private I18nService i18nService;

   /**
    * Documentaci�.
    */
   private String contextSubpath = null;

   /**
    * Path to scripts
    */
   private String scriptsSrc = "scripts";

   /**
    * Id of tag
    */
   private String styleId;

   /**
    * ValidationService
    */
   private ValidationService validationService;

   /**
    * Documentaci�.
    */
   private boolean appendContextPath = true;

   /**
    * Documentaci�.
    */
   private boolean useUrlRewrite = false;

   /**
    * Creates a new ConfigurationTag object.
    */
   public ConfigurationTag() {
      super();
   }

   /**
    * Add library
    * @param aPageContext
    * @param aLibrary
    * @throws JspException
    */
   public void addLibrary(PageContext aPageContext, String aLibrary)
      throws JspException {
      TagUtils tagUtils = TagUtils.getInstance();
      StringBuffer buffer = new StringBuffer();

      buffer.append("<script src=\"");

      String contextPath = ((HttpServletRequest) aPageContext.getRequest()).getContextPath();

      if (this.appendContextPath) {
         buffer.append(contextPath);
      }

      if (!useUrlRewrite) {
         if (this.contextSubpath != null) {
            if (contextSubpath.startsWith("/")) {
               buffer.append(contextSubpath);
            } else {
               buffer.append("/" + contextSubpath);
            }
         }

         buffer.append("/" + aLibrary);
      } else {
         String url = "/" + aLibrary;
         String encodedURL = ((HttpServletResponse) aPageContext.getResponse()).encodeURL(url);
         buffer.append(encodedURL);
      }

      buffer.append("\"");
      buffer.append(" type=\"text/javascript\">");
      buffer.append("</script>\n");
      tagUtils.write(aPageContext, buffer.toString());
   }

   /**
    * Add reference to a library in js
    * @param aPageContext
    * @param aLibrary
    * @throws JspException
    */
   public void addScriptLibrary(PageContext aPageContext, String aLibrary)
      throws JspException {
      TagUtils tagUtils = TagUtils.getInstance();
      StringBuffer buffer = new StringBuffer();

      buffer.append("<script src=\"");

      String contextPath = ((HttpServletRequest) aPageContext.getRequest()).getContextPath();

      if (this.appendContextPath) {
         buffer.append(contextPath + "/");
      }

      buffer.append(scriptsSrc);
      buffer.append(aLibrary);
      buffer.append("\"");
      buffer.append(" type=\"text/javascript\">");
      buffer.append("</script>\n");
      tagUtils.write(aPageContext, buffer.toString());
   }

   /**
    * Documentaci�.
    *
    * @param pageContext Documentaci�
    *
    * @throws JspException Documentaci�
    */
   private void addDWRLibraries(PageContext pageContext)
      throws JspException {
      addScriptLibrary(pageContext, "/ajax/dwr/engine.js");
      addScriptLibrary(pageContext, "/ajax/dwr/util.js");
      addScriptLibrary(pageContext, "/ajax/dwr/deprecated.js");
   }

   /**
    * Documentaci�.
    *
    * @param pageContext Documentaci�
    * @param formTags Documentaci�
    *
    * @throws JspException Documentaci�
    */
   private void addFormTagLibraries(PageContext pageContext, List formTags)
      throws JspException {
      // Validation
      boolean libraryGenerated = false;

      Iterator it = formTags.iterator();

      while (it.hasNext()) {
         FormTag formTag = (FormTag) it.next();

         Properties validationProperties = formTag.getValidationProperties();

         if (validationProperties != null) {
            String validationType = (String) validationProperties.get(FormTagHelper.VALIDATION_TYPE);

            if (validationType.equals(FormTagHelper.SERVER_VALIDATION) &&
                  !libraryGenerated) {
               addLibrary(pageContext, "dwr/interface/webValidationService.js");
               addScriptLibrary(pageContext,
                  "/ajax/ajaxtags/canigo-ajaxtags-validation.js");
               libraryGenerated = true;
            } else if (validationType.equals(FormTagHelper.CLIENT_VALIDATION) &&
                  !libraryGenerated) {
               addScriptLibrary(pageContext,
                  "/ajax/ajaxtags/canigo-ajaxtags-validation.js");
               libraryGenerated = true;
            }
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param aPageContext Documentaci�
    * @param fieldTags Documentaci�
    *
    * @throws JspException Documentaci�
    */
   private void addFieldTagLibraries(PageContext aPageContext, List fieldTags)
      throws JspException {
      boolean accessKeyLibraryGenerated = false;
      boolean tooltipLibraryGenerated = false;

      Iterator it = fieldTags.iterator();

      while (it.hasNext()) {
         FieldTag fieldTag = (FieldTag) it.next();
         String accessKey = fieldTag.getAccesskey();

         if ((accessKey != null) && !accessKey.equals("") &&
               !accessKeyLibraryGenerated) {
            addScriptLibrary(pageContext, "/utils/canigo-accesskey.js");
            accessKeyLibraryGenerated = true;
         }

         String tooltipKey = fieldTag.getTooltipKey();

         if ((tooltipKey != null) && !tooltipKey.equals("") &&
               !tooltipLibraryGenerated) {
            // DOM TOOLTIPS
            addScriptLibrary(pageContext, "/tooltips/dom_tooltip/domLib.js");
            addScriptLibrary(pageContext, "/tooltips/dom_tooltip/domTT.js");
            tooltipLibraryGenerated = true;
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param aPageContext Documentaci�
    * @param fieldTags Documentaci�
    *
    * @throws JspException Documentaci�
    */
   private void addTextFieldTagLibraries(PageContext aPageContext,
      List fieldTags) throws JspException {
      boolean calendarLibraryGenerated = false;

      Iterator it = fieldTags.iterator();

      while (it.hasNext()) {
         TextFieldTag textFieldTag = (TextFieldTag) it.next();
         boolean showCalendar = textFieldTag.isShowCalendar();

         if (showCalendar && !calendarLibraryGenerated) {
            // We have to obtain locale to generate javascript literals
            String language = "es";

            if (i18nService != null) {
               Locale currentLocale = i18nService.getCurrentLocale();

               if (currentLocale != null) {
                  language = currentLocale.getLanguage();
               }
            }

            addScriptLibrary(pageContext, "/calendars/dynarch/calendar.js");
            addScriptLibrary(pageContext,
               "/calendars/dynarch/lang/calendar-" + language + ".js");
            addScriptLibrary(pageContext, "/calendars/dynarch/calendar-setup.js");
            calendarLibraryGenerated = true;
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param pageContext Documentaci�
    * @param textAreaFieldTags Documentaci�
    *
    * @throws JspException Documentaci�
    */
   private void addTextAreaFieldTagLibraries(PageContext pageContext,
      List textAreaFieldTags) throws JspException {
      boolean tinyMCELibraryGenerated = false;
      Iterator it = textAreaFieldTags.iterator();

      while (it.hasNext()) {
         TextAreaFieldTag textAreaFieldTag = (TextAreaFieldTag) it.next();
         Properties decoratorProperties = textAreaFieldTag.getDecoratorProperties();

         if ((decoratorProperties != null) && !tinyMCELibraryGenerated) {
            addScriptLibrary(pageContext, "/textareas/tiny_mce/tiny_mce.js");
            tinyMCELibraryGenerated = true;
         }

         StringBuffer func = new StringBuffer();
         func.append("<script type=\"text/javascript\">");
         func.append("tinyMCE.init({");

         Iterator decoratorIt = decoratorProperties.keySet().iterator();

         while (decoratorIt.hasNext()) {
            String key = (String) decoratorIt.next();
            String value = decoratorProperties.getProperty(key);
            func.append(key + ":" + "\"" + value + "\",");
         }

         // Last parameter add id of textarea
         func.append("elements : \"" + textAreaFieldTag.getStyleId() + "\"");
         func.append("});</script>\n\r");

         try {
            pageContext.getOut().write(func.toString());
         } catch (IOException ex) {
         }

         ;
      }
   }

   /**
    * Documentaci�.
    *
    * @param pageContext Documentaci�
    * @param selectFieldTags Documentaci�
    *
    * @throws JspException Documentaci�
    */
   private void addSelectFieldTagLibraries(PageContext pageContext,
      List selectFieldTags) throws JspException {
      boolean libraryGenerated = false;

      Iterator it = selectFieldTags.iterator();

      while (it.hasNext()) {
         SelectFieldTag selectFieldTag = (SelectFieldTag) it.next();

         if ((selectFieldTag.getSelectFieldSource() != null) &&
               !libraryGenerated) {
            addLibrary(pageContext, "dwr/interface/webOptionsListService.js");
            addScriptLibrary(pageContext,
               "/ajax/ajaxtags/canigo-ajaxtags-select.js");
            libraryGenerated = true;
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public int doStartTag() throws JspException {
      try {
         Tag configurationTag = TagUtil.getConfigurationTag(pageContext);

         if (configurationTag != null) {
            BeanUtils.copyProperties(this, configurationTag);
         }
      } catch (IllegalAccessException e) {
      } catch (InvocationTargetException e) {
      }

      // Add common libraries
      addScriptLibrary(pageContext, "/ajax/prototype/prototype-1.3.1.js");
      addScriptLibrary(pageContext, "/ajax/ajaxtags/ajaxtags-1.1.js");
      addScriptLibrary(pageContext, "/ajax/ajaxtags/canigo-ajaxtags-fields.js");
      addDWRLibraries(pageContext);

      List formTags = TagUtil.findTagsOfClass(pageContext, FormTag.class);

      if (formTags != null) {
         addFormTagLibraries(pageContext, formTags);
      }

      List fieldTags = TagUtil.findTagsOfClass(pageContext, FieldTag.class);

      if (fieldTags != null) {
         addFieldTagLibraries(pageContext, fieldTags);
      }

      List textFieldTags = TagUtil.findTagsOfClass(pageContext,
            TextFieldTag.class);

      if (textFieldTags != null) {
         addTextFieldTagLibraries(pageContext, textFieldTags);
      }

      // This has been moved to textarea field tag, since scripts
      // libraries needs to be include AFTER tye <body> html element
      List textAreaFieldTags = TagUtil.findTagsOfClass(pageContext,
            TextAreaFieldTag.class);

      if (textAreaFieldTags != null) {
         addTextAreaFieldTagLibraries(pageContext, textAreaFieldTags);
      }

      List selectFieldTags = TagUtil.findTagsOfClass(pageContext,
            SelectFieldTag.class);

      if (selectFieldTags != null) {
         addSelectFieldTagLibraries(pageContext, selectFieldTags);
      }

      addScriptLibrary(pageContext, "/ajax/behaviour/Behaviour.js");
      addScriptLibrary(pageContext, "/ajax/behaviour/canigo-behaviour.js");

      return super.doStartTag();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public int doEndTag() throws JspException {
      return super.doStartTag();
   }

   /**
    * Documentaci�.
    */
   public void release() {
      super.release();
      dwrLibrariesAdded = false;
      appendContextPath = true;
      contextSubpath = null;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getScriptsSrc() {
      return scriptsSrc;
   }

   /**
    * Documentaci�.
    *
    * @param scriptsSrc Documentaci�
    */
   public void setScriptsSrc(String scriptsSrc) {
      this.scriptsSrc = scriptsSrc;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public PageContext getPageContext() {
      return pageContext;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Documentaci�.
    *
    * @param service Documentaci�
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getStyleId() {
      return styleId;
   }

   /**
    * Documentaci�.
    *
    * @param styleId Documentaci�
    */
   public void setStyleId(String styleId) {
      this.styleId = styleId;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Documentaci�.
    *
    * @param validationService Documentaci�
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * @param appendContextPath The appendContextPath to set.
    */
   public void setAppendContextPath(boolean appendContextPath) {
      this.appendContextPath = appendContextPath;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean getAppendContextPath() {
      return this.appendContextPath;
   }

   /**
    * @return Returns the contextSubpath.
    */
   public String getContextSubpath() {
      return contextSubpath;
   }

   /**
    * @param contextSubpath The contextSubpath to set.
    */
   public void setContextSubpath(String contextSubpath) {
      this.contextSubpath = contextSubpath;
   }

   /**
    * @return Returns the useUrlRewrite.
    */
   public boolean isUseUrlRewrite() {
      return useUrlRewrite;
   }

   /**
    * @param useUrlRewrite The useUrlRewrite to set.
    */
   public void setUseUrlRewrite(boolean useUrlRewrite) {
      this.useUrlRewrite = useUrlRewrite;
   }
}
