/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.util;

import java.util.Properties;

import javax.servlet.jsp.JspException;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.exceptions.SystemException;
import net.gencat.ctti.canigo.services.web.struts.SpringBindingActionForm;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.FormTag;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.FormValidatorTag;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;
import net.gencat.ctti.canigo.services.web.validation.commons.WebValidationSubmit;
import net.gencat.ctti.canigo.services.web.validation.taglib.JavascriptValidatorTag;
import net.sf.json.JSONObject;

import org.apache.struts.taglib.TagUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class FormValidatorTagHelper {
   /**
    * Documentaci�.
    */
   public static final String CLIENT_VALIDATION = "CLIENT";

   /**
    * Documentaci�.
    */
   public static final String SERVER_VALIDATION = "SERVER";

   /**
    * Documentaci�.
    */
   public static final String VALIDATOR_NAME = "validatorName";

   /**
    * Documentaci�.
    */
   public static final String VALIDATION_TYPE = "validationType";

   /**
    * Creates a new FormValidatorTagHelper object.
    */
   public FormValidatorTagHelper() {
      super();
   }

   /**
    * Documentaci�.
    *
    * @param formTag Documentaci�
    * @param validatorName Documentaci�
    *
    * @throws JspException Documentaci�
    */
   private static void addValidatorNameInSession(FormValidatorTag formTag,
      String validatorName) throws JspException {
      String tmpIdForm = (String) formTag.getPageContext().getRequest()
                                         .getAttribute("identificadorForm");

      if (tmpIdForm != null) {
         formTag.getPageContext().getSession()
                .setAttribute(tmpIdForm + WebValidationSubmit.VALIDATORNAME,
            validatorName);
      } else {
         throw new JspException(
            "The formId is not in the pageContext. the formTag is " +
            formTag.getId() + " You must use fwk:form tag with validations");
      }
   }

   /**
    * Documentaci�.
    *
    * @param formValidatorTag Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public static void generateValidation(FormValidatorTag formValidatorTag)
      throws JspException {
      FormTag formTag = (FormTag) TagUtil.getTag(formValidatorTag.getPageContext(),
            formValidatorTag.getSource());
      Properties validationProperties = formTag.getValidationProperties();
      String validatorName = "";

      if (validationProperties != null) {
         if (validationProperties.get(VALIDATOR_NAME) != null) {
            validatorName = (String) validationProperties.get(VALIDATOR_NAME);

            String validationType = (String) validationProperties.get(VALIDATION_TYPE);

            if (validationType != null) {
               //amb configuraci� en el xml per validacions
               //validaci� servidor
               addValidatorNameInSession(formValidatorTag, validatorName);

               if (validationType.toUpperCase().equals(SERVER_VALIDATION)) {
                  if (formValidatorTag.getMode() != null) {
                     if (formValidatorTag.getMode().toUpperCase()
                                            .equals(CLIENT_VALIDATION)) {
                        //   			    	    ExceptionDetails exDetails = new ExceptionDetails("errors.configValidacioNoCorrecta",new Object[]{""},Layer.SERVICES,Subsystem.WEB_LISTS_SERVICES);
                        //			    		SystemException vse = new SystemException(exDetails);
                        //			    	    throw  vse; 
                        throw new JspException(
                           "The configuration of validation is not correct for the form " +
                           formTag.getStyleId() +
                           ".The attribute 'mode' of decorator:" +
                           formValidatorTag.getMode() +
                           "it is incongruous with the configuration in the xml:" +
                           validationType);
                     } else {
                        validateOnServer(formValidatorTag, validatorName);
                     }
                  } else {
                     validateOnServer(formValidatorTag, validatorName);
                  }
               } else {
                  //validaci� client
                  if (validationType.toUpperCase().equals(CLIENT_VALIDATION)) {
                     if (formValidatorTag.getMode() != null) {
                        if (formValidatorTag.getMode().toUpperCase()
                                               .equals(SERVER_VALIDATION)) {
                           //      			     	ExceptionDetails exDetails = new ExceptionDetails("errors.configValidacioNoCorrecta",new Object[]{""},Layer.SERVICES,Subsystem.WEB_LISTS_SERVICES);
                           //	   			    		SystemException vse = new SystemException(exDetails);
                           //	   			    	    throw  vse; 
                           throw new JspException(
                              "The configuration of validation is not correct for the form decorator" +
                              formTag.getStyleId() +
                              ".The attribute 'mode' of decorator:" +
                              formValidatorTag.getMode() +
                              "it is incongruous with the configuration in the xml:" +
                              validationType);
                        } else {
                           validateOnClient(formValidatorTag, validatorName);
                        }
                     } else {
                        validateOnClient(formValidatorTag, validatorName);
                     }
                  }
               }
            } else { // validationType==null & validatorName!=null
                     // aix� seria un error de configuraci�.
               throw new JspException(
                  "The validatorName is not null, but validationType is null in form decorator " +
                  formValidatorTag.getStyleId());

               //sense configuraci� en el xml per validacions
               //	   		if (formValidatorTag.getMode()!=null) {
               //	    		if (formValidatorTag.getMode().toUpperCase().equals(SERVER_VALIDATION)) {
               //	    			validateOnServer(formValidatorTag,validatorName);
               //	    		} else if (formValidatorTag.getMode().toUpperCase().equals(CLIENT_VALIDATION)) {
               //	    			validateOnClient(formValidatorTag,validatorName);
               //	    		}
               //	    	} 	
            }
         } else { // validationName==null
                  //   		    if ((String)validationProperties.get(VALIDATION_TYPE)!=null){
                  //	    		throw new JspException("validatorName has not been defined");
                  //	    	}else{ 
                  //	    	  // validationName==null i validationType==null.
                  //	    	  
                  //	    	  // podriem suposar validationName igual que pojoclass.
                  //	    		
                  //   		      //sense configuraci� en el xml per validacions
                  //	   		   if (formValidatorTag.getMode()!=null) {
                  //	    		 if (formValidatorTag.getMode().equals(SERVER_VALIDATION)) {
                  //	    			validateOnServer(formValidatorTag,validatorName);
                  //	    		 } else if (formValidatorTag.getMode().equals(CLIENT_VALIDATION)) {
                  //	    			validateOnClient(formValidatorTag,validatorName);
                  //	    		 }
                  //	   		   }else{
                  //	    	     throw new JspException("You should inform the attibutte 'mode' of the decorator to indicate the type oof validation.");
                  //	   		   }
                  //	   	    }
            throw new JspException(
               "The validatorName is null in form decorator " +
               formValidatorTag.getId());
         }
      } else {
         //		sense configuraci� en el xml per validacions
         if (formValidatorTag.getMode() != null) {
            if (formValidatorTag.getMode().toUpperCase()
                                   .equals(SERVER_VALIDATION)) {
               validateOnServer(formValidatorTag, validatorName);
            } else if (formValidatorTag.getMode().toUpperCase()
                                          .equals(CLIENT_VALIDATION)) {
               validateOnClient(formValidatorTag, validatorName);
            }
         } else {
            throw new JspException(
               "You should inform the attibutte 'mode' of the decorator to indicate the type oof validation.");
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param formTag Documentaci�
    *
    * @throws JspException Documentaci�
    */
   public static void generateBehaviour(FormValidatorTag formTag)
      throws JspException {
      TagUtils tagUtils = TagUtils.getInstance();
      tagUtils.write(formTag.getPageContext(),
         "<script type=\"text/javascript\"> if(typeof(Behaviour)!='undefined')Behaviour.apply(); </script>");
   }

   /**
    * Create code for alert in Javascript
    * @param formTag
    */
   private static void validateOnClient(FormValidatorTag formValidatorTag,
      String validatorName) throws JspException {
      FormTag formTag = (FormTag) TagUtil.getTag(formValidatorTag.getPageContext(),
            formValidatorTag.getSource());

      //Generate code from tag JavaScript Validator Tag	
      String identificador = (String) formValidatorTag.getPageContext()
                                                      .getRequest()
                                                      .getAttribute("identificadorForm");

      if ((validatorName != null) && !validatorName.equals("")) {
         if ((identificador != null) && !identificador.equals("")) {
            JSONObject paramsOnSubmit = (JSONObject) formValidatorTag.getPageContext()
                                                                     .getSession()
                                                                     .getAttribute(identificador);

            if ((paramsOnSubmit != null) && !paramsOnSubmit.equals("")) {
               JavascriptValidatorOnSubmmitTag javascriptValidatorOnSubmitTag = new JavascriptValidatorOnSubmmitTag();
               javascriptValidatorOnSubmitTag.setPageContext(formValidatorTag.getPageContext());
               javascriptValidatorOnSubmitTag.setFormName(validatorName);
               javascriptValidatorOnSubmitTag.setStaticJavascript("false");
               javascriptValidatorOnSubmitTag.setI18nService(formTag.getI18nService());
               javascriptValidatorOnSubmitTag.doStartTag(paramsOnSubmit);
               javascriptValidatorOnSubmitTag.doEndTag();
            }
         } else {
            JavascriptValidatorTag javascriptValidatorTag = new JavascriptValidatorTag();
            javascriptValidatorTag.setPageContext(formValidatorTag.getPageContext());
            javascriptValidatorTag.setFormName(validatorName);
            javascriptValidatorTag.setStaticJavascript("false");
            javascriptValidatorTag.doStartTag();
            javascriptValidatorTag.doEndTag();
         }
      } else {
         validatorName = formTag.getStyleId();

         if ((identificador != null) && !identificador.equals("")) {
            JSONObject paramsOnSubmit = (JSONObject) formValidatorTag.getPageContext()
                                                                     .getSession()
                                                                     .getAttribute(identificador);

            if ((paramsOnSubmit != null) && !paramsOnSubmit.equals("")) {
               JavascriptValidatorOnSubmmitTag javascriptValidatorOnSubmitTag = new JavascriptValidatorOnSubmmitTag();
               javascriptValidatorOnSubmitTag.setPageContext(formValidatorTag.getPageContext());
               javascriptValidatorOnSubmitTag.setFormName(validatorName);
               javascriptValidatorOnSubmitTag.setStaticJavascript("false");
               javascriptValidatorOnSubmitTag.setI18nService(formTag.getI18nService());
               javascriptValidatorOnSubmitTag.doStartTagDecotator(paramsOnSubmit);
               javascriptValidatorOnSubmitTag.doEndTag();
            }
         }
      }

      // Now generate common javascript code for validation
      TagUtils tagUtils = TagUtils.getInstance();
      tagUtils.write(formValidatorTag.getPageContext(),
         "<script type=\"text/javascript\">");

      JavascriptValidatorTag commonValidatorTag = new JavascriptValidatorTag();
      commonValidatorTag.setPageContext(formValidatorTag.getPageContext());
      commonValidatorTag.setDynamicJavascript("false");
      commonValidatorTag.setStaticJavascript("true");
      commonValidatorTag.doStartTag();
      commonValidatorTag.doEndTag();
      tagUtils.write(formValidatorTag.getPageContext(), "</script>");

      // Finally attach behaviour onSubmit to call validation functions
      StringBuffer buffer = new StringBuffer();
      buffer.append("<script type=\"text/javascript\">");
      buffer.append("new CanigoFormTag.ClientValidation({");
      buffer.append("source:\"" + formValidatorTag.getSource() + "\"");
      buffer.append(",");
      buffer.append("validatorName:\"" + validatorName + "\"");
      buffer.append("});");
      buffer.append("</script>");
      tagUtils.write(formValidatorTag.getPageContext(), buffer.toString());
   }

   /**
   * Create AJAX code validation to call to server with DWR
   * @param formTag
   */
   private static void validateOnServer(FormValidatorTag formValidatorTag,
      String validatorName) throws JspException {
      //Obtain associated bean of form and obtain pojoClass
      Object bean = formValidatorTag.getPageContext()
                                    .findAttribute(formValidatorTag.getSource());
      String className = null;

      //Obtain associated bean of form and obtain pojoClass

      //@carles. Si el validatorName es null, vol dir que no hi ha validacions velles.
      if (bean instanceof SpringBindingActionForm) {
         SpringBindingActionForm actionForm = (SpringBindingActionForm) bean;
         className = actionForm.getPojoClassName();

         //			    if (validatorName==null||validatorName.equals("")) { // obtain by default pojoClass as validator
         //					validatorName =	className;	
         //				}
      }

      if ((validatorName != null) && (validatorName != "")) {
         TagUtils tagUtils = TagUtils.getInstance();
         StringBuffer buffer = new StringBuffer();
         buffer.append("<script type=\"text/javascript\">");
         buffer.append("new CanigoFormTag.ServerValidation({");
         buffer.append("source:\"" + formValidatorTag.getSource() + "\"");
         buffer.append(",");
         buffer.append("validatorName:\"" + validatorName + "\"");
         //nuevos atributos de validacion
         buffer.append(",");
         buffer.append("className:\"" + className + "\"");
         buffer.append(",");
         buffer.append("validationFormMessageMode:\"" +
            formValidatorTag.getValidationFormMessageMode() + "\"");
         buffer.append(",");
         buffer.append("validationMessageFunction:\"" +
            formValidatorTag.getValidationMessageFunction() + "\"");
         buffer.append(",");
         buffer.append("errorPanelStyleId:\"" +
            formValidatorTag.getErrorPanelStyleId() + "\"");
         buffer.append(",");
         buffer.append("indicator:\"" + formValidatorTag.getIndicator() + "\"");
         buffer.append("});");
         buffer.append("</script>");
         tagUtils.write(formValidatorTag.getPageContext(), buffer.toString());
      }
   }
}
