/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.util.List;
import java.util.Properties;

import javax.servlet.jsp.JspException;

import fr.improve.struts.taglib.layout.event.EndLayoutEvent;
import fr.improve.struts.taglib.layout.event.StartLayoutEvent;

import net.gencat.ctti.canigo.core.util.beanutils.BeanUtils;
import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.logging.Log;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.logging.log4j.Log4JServiceImpl;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.SpringBindingActionForm;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.ServicesTagHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.util.FormTagHelper;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;

import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.springframework.beans.BeanWrapperImpl;


/**
 * <p>Definici� de les propietats del Tag FormTag.</p>
 *
 * @author XES
 *
 */
public class FormTag extends fr.improve.struts.taglib.layout.FormTag
   implements net.gencat.ctti.canigo.services.web.taglib.FormTag {
   /**
         *
         */
   private static final long serialVersionUID = -8112478994807183612L;

   /**
    * Documentaci�.
    */
   public static final String HIDDEN_NAME = "__Metadata-formIdent__";

   /**
    * Documentaci�.
    */
   public static final String PREFIX_IDENTIFIER = "paramsSubmit";

   /**
   * I18nService
   */
   private I18nService i18nService;

   /**
    * Documentaci�.
    */
   private Log log;

   /**
    * The log service.
    */
   private LoggingService logService;

   /**
    * Validation properties
    */
   private Properties validationProperties;

   /**
    * Documentaci�.
    */
   private String errorPanelStyleId;

   /**
    * Documentaci�.
    */
   private String generateId;

   /**
    * Documentaci�.
    */
   private String indicator;

   /**
    * Documentaci�.
    */
   private String mode;

   /**
    * Documentaci�.
    */
   private String styleId;

   //nuevos atributos del formTag para validacion 
   /**
    * Documentaci�.
    */
   private String validationFormMessageMode;

   /**
    * Documentaci�.
    */
   private String validationMessageFunction;

   /**
    * ValidationService
    */
   private ValidationService validationService;

   /**
    * Documentaci�.
    */
   private boolean layout = true;

   /**
    * Crea un nou objecte FormTag.
    */
   public FormTag() {
      super();
   }

   /**
    * Documentaci�.
    */
   public void init() {
      super.init();

      TagUtil.copyConfiguration(this);
   }

   /**
    * Documentaci�.
    */
   public void initLog() {
      if (log == null) {
         log = logService.getLog(this.getClass());
      }
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doStartLayoutTag() throws JspException {
      //inizializar el objeto que hay en sesion que se utiliza para las validaciones obligatorias de submit
      //this.getPageContext().getSession().setAttribute("paramsSubmit",null);
      //initLog();

      // EVC: import scripts
      FormTagHelper.generateScripts(this.pageContext);

      int inici = super.doStartLayoutTag();

      if (this.getGenerateId() != null) {
         this.generateId = (String) ExpressionEvaluatorManager.evaluate("generateId",
               this.generateId, String.class, this, super.pageContext);
      }

      String identificador = FormTagHelper.generateFormIdentification(this);
      this.pageContext.getRequest()
                      .setAttribute("identificadorForm", identificador);

      if (this.getGenerateId() == null) {
         System.out.println("Generate new identifier: " + identificador +
            " to form " + this.getStyleId());
      } else {
         System.out.println("Generate existing form identifier: " +
            identificador + " to form " + this.getStyleId());
      }

      //	System.out.println("Add ident to pageContext:"+identificador);
      return inici;
   }

   /**
    * Documentaci�.
    *
    * @param styleId Documentaci�
    */
   public void setStyleId(String styleId) {
      this.styleId = styleId;
      formTag.setStyleId(styleId);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getStyleId() {
      return styleId;
   }

   /**
    * Documentaci�.
    *
    * @param in_event EndLayoutEvent
    *
    * @return Object
    *
    * @throws JspException
    */
   public Object processEndLayoutEvent(EndLayoutEvent in_event)
      throws JspException {
      if (isLayout()) {
         return super.processEndLayoutEvent(in_event);
      }

      return null;
   }

   /**
    * Fi de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doEndLayoutTag() throws JspException {
      int ret = super.doEndLayoutTag();
      // Finally create Ajax Validation of form
      FormTagHelper.generateValidation(this);
      FormTagHelper.generateBehaviour(this);

      return ret;
   }

   /**
    * Documentaci�.
    *
    * @param in_event StartLayoutEvent
    *
    * @return Object
    *
    * @throws JspException
    */
   public Object processStartLayoutEvent(StartLayoutEvent in_event)
      throws JspException {
      if (isLayout()) {
         return super.processStartLayoutEvent(in_event);
      }

      return null;
   }

   /**
    * Generar/No generar els tags '<tr>','<td>' per als components.
    * Per defecte �s 'true' si no indiquem aquesta propietat.
    * Indicar 'false' si no es volen
    *
    * @param isLayout boolean
    */
   public void setLayout(boolean isLayout) {
      layout = isLayout;
   }

   /**
    * Generar/No generar els tags '<tr>','<td>' per als components.
    * Per defecte �s 'true' si no indiquem aquesta propietat.
    * Indicar 'false' si no es volen
    *
    * @return boolean
    */
   public boolean isLayout() {
      return layout;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @return I18nService
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @param validationService ValidationService
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * Per especificar com es far� la validaci� de les dades entrades al
    * formulari.
    *
    * @return Properties
    */
   public Properties getValidationProperties() {
      return validationProperties;
   }

   /**
    * Per especificar com es far� la validaci� de les dades entrades al
    * formulari.
    *
    * @param validationProperties Documentaci�
    */
   public void setValidationProperties(Properties validationProperties) {
      this.validationProperties = validationProperties;
   }

   /**
    * Indica les maneres de mostrar els errors de formulari.
    * Pot ser PANEL, FIELDS, WINDOW.
    *
    * @return String
    */
   public String getValidationFormMessageMode() {
      return validationFormMessageMode;
   }

   /**
    * Indica les maneres de mostrar els errors de formulari.
    * Pot ser PANEL, FIELDS, WINDOW.
    *
    * @param validationFormMessageMode String
    */
   public void setValidationFormMessageMode(String validationFormMessageMode) {
      this.validationFormMessageMode = validationFormMessageMode;
   }

   /**
    * Funci� de presentaci� del missatge d'error a mida.
    *
    * @return String
    */
   public String getValidationMessageFunction() {
      return validationMessageFunction;
   }

   /**
    * Funci� de presentaci� del missatge d'error a mida.
    *
    * @param validationMessageFunction String
    */
   public void setValidationMessageFunction(String validationMessageFunction) {
      this.validationMessageFunction = validationMessageFunction;
   }

   /**
    * Identificador del panell incrustat.
    *
    * @return String
    */
   public String getErrorPanelStyleId() {
      return errorPanelStyleId;
   }

   /**
    * Identificador del panell incrustat.
    *
    * @param errorPanelStyleId String
    */
   public void setErrorPanelStyleId(String errorPanelStyleId) {
      this.errorPanelStyleId = errorPanelStyleId;
   }

   /**
    * El que es mostra quan es fa petici� AJAX.
    *
    * @return String
    */
   public String getIndicator() {
      return indicator;
   }

   /**
    * El que es mostra quan es fa petici� AJAX.
    *
    * @param indicator String
    */
   public void setIndicator(String indicator) {
      this.indicator = indicator;
   }

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getMode() {
      return mode;
   }

   /**
    * Documentaci�.
    *
    * @param mode String
    */
   public void setMode(String mode) {
      this.mode = mode;
   }

   /**
    * Permet injectar serveis del contenidor d' spring.
    *
    * @param services String
    *
    * @throws JspException
    */
   public void setServices(String services) throws JspException {
      ServicesTagHelper.setServices(services, pageContext, this);
   }

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getGenerateId() {
      return generateId;
   }

   /**
    * Documentaci�.
    *
    * @param generateId String
    */
   public void setGenerateId(String generateId) {
      this.generateId = generateId;
   }

   /**
    * Documentaci�.
    *
    * @return LoggingService
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * Documentaci�.
    *
    * @param logService LoggingService
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   //	public String getState() {
   //		return state;
   //	}

   //	public void setState(String state) {
   //		this.state = state;
   //	}
}
