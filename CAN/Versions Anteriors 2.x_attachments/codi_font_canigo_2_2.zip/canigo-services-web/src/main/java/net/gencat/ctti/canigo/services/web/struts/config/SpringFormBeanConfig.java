/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.config;

import net.gencat.ctti.canigo.services.web.spring.util.WebApplicationContextUtils;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionServlet;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.web.context.WebApplicationContext;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class SpringFormBeanConfig extends org.apache.struts.config.FormBeanConfig {
   /**
    * Documentaci�.
    */
   private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(SpringFormBeanConfig.class);

   /**
    * Documentaci�.
    */
   private String prefix = null;

   /**
    * Documentaci�.
    *
    * @param servlet Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IllegalAccessException Documentaci�
    * @throws InstantiationException Documentaci�
    */
   public ActionForm createActionForm(ActionServlet servlet)
      throws IllegalAccessException, InstantiationException {
      log.debug("Creating ActionForm with type " + this.type);

      WebApplicationContext webAppContext = WebApplicationContextUtils.getWebApplicationContext(servlet.getServletContext());

      if (this.getFullBeanName() != null) {
         ActionForm actionForm = null;

         try {
            actionForm = (ActionForm) webAppContext.getBean(this.getFullBeanName());
            log.debug("Form " + actionForm.getClass().getName() + " created!");
            this.type = actionForm.getClass().getName();
         } catch (NoSuchBeanDefinitionException ex) {
            log.error("No bean named " + this.getFullBeanName(), ex);
            throw ex;
         }

         return actionForm;
      } else {
         throw new InstantiationException(
            "Cannot create a form-bean because the name of the ActionForm you are requesting is null");
      }
   }

   /**
    * @return Returns the prefix.
    */
   public String getPrefix() {
      return prefix;
   }

   /**
    * @param prefix The prefix to set.
    */
   public void setPrefix(String prefix) {
      this.prefix = prefix;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getFullBeanName() {
      if ((this.prefix != null) && !"".equals(this.prefix)) {
         if (this.name != null) {
            return this.prefix + "/" + this.name;
         }
      } else {
         if (this.name != null) {
            return this.name;
         }
      }

      return null;
   }
}
