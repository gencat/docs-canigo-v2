/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import javax.servlet.jsp.JspException;

import fr.improve.struts.taglib.layout.field.SelectTag;
import fr.improve.struts.taglib.layout.util.LayoutUtils;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.SelectFieldTagHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.ServicesTagHelper;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.util.BasicFieldHelper;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;
import net.gencat.ctti.canigo.services.web.taglib.util.options.OptionsListService;

import org.apache.struts.taglib.TagUtils;


/**
 * <p>Definici� de les propietats del Tag SelectFieldTag.</p>
 *
 * @author XES
 *
 * @version Versi� $Revision: 1.7 $ $Date: 2007/07/27 06:33:25 $
 *
 * @since
 *
 * <p>Revision 1.4  2007/05/23 10:47:40  msabates
 * Cap�alera</p>
 *
 * <p>Revision 1.1.1.1.2.1  2007/05/18 10:49:41  fernando.vaquero
 * *** empty log message ***</p>
 *
 * <p>Revision 1.1.1.1  2007/05/15 13:53:56  fernando.vaquero
 * Importacio canigo 2.0</p>
 *
 * <p>Revision 1.3  2007/05/15 10:19:03  msabates
 * Jalopy</p>
 *
 * <p>Revision 1.2  2007/04/20 09:49:21  msabates
 * Canvis que estaven a la v1.4</p>
 *
 * <p>Revision 1.15  2007/02/20 14:41:58  evidal
 * EVC: merging 1.0 & 1.1.</p>
 *
 * <p>Revision 1.14  2006/11/16 16:58:00  mmateos
 * author: crico: version 1.1 no estable</p>
 *
 * <p>Revision 1.14  2006/09/19 16:41:56  crico
 * version 1.1 no estable</p>
 *
 * <p>Revision 1.11.2.3  2006/08/31 09:03:37  mmasquefa
 * *** empty log message ***</p>
 *
 * <p>Revision 1.12  2006/08/31 09:05:30  mmasquefa
 * MMO: Added release and reset methods, for release of all configured
 * fields.</p>
 *
 * <p>Revision 1.11.2.2  2006/06/16 10:02:44  evidal
 * EVC: fixed SelectFieldTag - OptionsFieldTag bug: match value is needed in
 * doEndTag method of OptionsFieldTag class.</p>
 *
 * <p>Revision 1.11.2.1  2006/05/25 11:09:03  evidal
 * EVC: arreglat el bug del select tag en mode inspect.</p>
 *
 * <p>Revision 1.11  2006/02/27 13:32:31  xescuder
 * XES: Added checking of Properties not empty</p>
 *
 * <p>Revision 1.10  2006/02/24 13:53:05  xescuder
 * XES: Added behaviour to set properties from jsp in adition of
 * configuration files</p>
 *
 * <p>Revision 1.9  2006/02/23 18:30:44  xescuder
 * XES: Improvements on documentation and using tags properties directly
 * from jsps</p>
 *
 *
 */
public class SelectFieldTag extends SelectTag implements net.gencat.ctti.canigo.services.web.taglib.SelectFieldTag {
   /**
    * Serial version uid.
    */
   private static final long serialVersionUID = -6146008493834447620L;

   /**
    * I18nService.
    */
   private I18nService i18nService;

   /**
    * Per selects amb depend�ncies.
    */
   private Object selectFieldSourceProperties = new Object();

   /**
    * Per obtenir les opciones de la base de dades o un altre origen.
    */
   private OptionsListService optionsListService;

   /**
    * Per selects amb depend�ncies.
    */
   private Properties selectFieldSource = new Properties();

   /**
    * Style class defined for key of field.
    */
   private String keyStyleClass = null;

   /**
    * Options list name.
    */
   private String optionsListName;

   /**
    * Key of option that will be added as first option in addition
    * of list of values retrieved.
    */
   private String otherKey = null;

   /**
    * Valor com a primera opci�.
    */
   private String otherValue = null;

   /**
    * Tab index.
    */
   private String tabIndex;

   /**
    * Tooltip key.
    */
   private String tooltipKey = null;

   /**
    * Tooltip options.
    */
   private String tooltipOptions = null;

   /**
    * Tooltip key pel t�tol.
    */
   private String tooltipTitleKey = null;

   /**
    * ValidationService.
    */
   private ValidationService validationService;

   /**
    * Show an error next to the field.
    */
   private boolean fieldErrorDisplayed = true;

   /**
    * Select on focus.
    */
   private boolean selectOnFocus = true;

   /**
    * In case of layout=false we have to call to generation of label.
    */
   protected boolean doBeforeValue() throws javax.servlet.jsp.JspException {
      super.doBeforeValue();

      // If no layout specified, we have to add manually label
      if (!isLayout()) {
         BasicFieldHelper.displayLabel(this);
      }

      // match value is needed in doEndTag method of OptionsFieldTag class.
      Object lc_bean = pageContext.findAttribute(name);
      String[] oldMatch = null;

      if (lc_bean != null) {
         String[] defaultSelectedFromBean = null;

         try {
            defaultSelectedFromBean = LayoutUtils.getArrayProperty(lc_bean,
                  property);
         } catch (Exception ex) {
            throw new JspException(ex);
         }

         if ((defaultSelectedFromBean != null) &&
               (defaultSelectedFromBean.length > 0)) {
            // If default selected is neither null not blank, we set
            // the match attribute to be able to append "selected" html attribute 
            // to the html tag <option/> through the Choice interface
            oldMatch = match;

            if ("true".equals(this.multiple) &&
                  (defaultSelectedFromBean.length == 1)) {
               // Convert "1,2,3" into an array of [1,2,3] 
               StringTokenizer st = new StringTokenizer(defaultSelectedFromBean[0],
                     ",");

               if (st.countTokens() > 0) {
                  defaultSelectedFromBean = new String[st.countTokens()];

                  int i = 0;

                  while (st.hasMoreTokens()) {
                     defaultSelectedFromBean[i++] = st.nextToken();
                  }
               }
            }

            match = defaultSelectedFromBean;
         }
      }

      return true;
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doStartLayoutTag() throws JspException {
      // EVC: fixed Disabled Mode bug.
      //        TagUtil.copyConfiguration(this);

      // Set to refresh mode and other calculated attributes 
      // (computeDisplayMode)
      // (doStartTag in Struts Layout has been defined final!!!!)
      //initDynamicValues();
      // EVC: fixed input type hidden value of Inspect Mode.
      doBeforeValue();

      return super.doStartLayoutTag();
   }

   /**
    * Documentaci�.
    */
   protected void initDynamicValues() {
      TagUtil.copyConfiguration(this);
      super.initDynamicValues();
   }

   /**
    * By an error of Struts Layout after value addChoice
    * is called to add other options, but isClosed throws
    * an Exception of nested text values not allowed after
    * value printed.
    */
   protected void doAfterValue() throws JspException {
      need_other = false;
      isClosed = false;

      // Default selected from bean
      Object lc_bean = pageContext.findAttribute(name);
      String[] oldMatch = null;

      if (lc_bean != null) {
         String[] defaultSelectedFromBean = null;

         try {
            defaultSelectedFromBean = LayoutUtils.getArrayProperty(lc_bean,
                  property);
         } catch (Exception ex) {
            throw new JspException(ex);
         }

         if ((defaultSelectedFromBean != null) &&
               (defaultSelectedFromBean.length > 0)) {
            // If default selected is neither null not blank, we set
            // the match attribute to be able to append "selected" html attribute 
            // to the html tag <option/> through the Choice interface
            oldMatch = match;

            if ("true".equals(this.multiple) &&
                  (defaultSelectedFromBean.length == 1)) {
               // Convert "1,2,3" into an array of [1,2,3] 
               StringTokenizer st = new StringTokenizer(defaultSelectedFromBean[0],
                     ",");

               if (st.countTokens() > 0) {
                  defaultSelectedFromBean = new String[st.countTokens()];

                  int i = 0;

                  while (st.hasMoreTokens()) {
                     defaultSelectedFromBean[i++] = st.nextToken();
                  }
               }
            }

            match = defaultSelectedFromBean;
         }
      }

      if (this.otherKey != null) {
         // Another option is needed
         StringBuffer buffer = new StringBuffer();
         addChoice(buffer, (this.otherValue != null) ? this.otherValue : "",
            this.i18nService.getMessage(this.otherKey));
         TagUtils.getInstance().write(getPageContext(), buffer.toString());
      }

      SelectFieldTagHelper.generateOptions(this);

      if (oldMatch != null) {
         match = oldMatch;
      }

      if (getFieldDisplayMode() == MODE_EDIT) {
         selectTag.doEndTag();
      }

      isClosed = true;
   }

   /**
    * Fi de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException
    */
   public int doEndLayoutTag() throws JspException {
      // TODO Auto-generated method stub
      return super.doEndLayoutTag();
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @param validationService ValidationService
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * Documentaci�.
    *
    * @return boolean
    */
   public boolean isFieldErrorDisplayed() {
      return fieldErrorDisplayed;
   }

   /**
    * Documentaci�.
    *
    * @param fieldErrorDisplayed boolean
    */
   public void setFieldErrorDisplayed(boolean fieldErrorDisplayed) {
      this.fieldErrorDisplayed = fieldErrorDisplayed;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @return I18nService
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @param service Documentaci�
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Estil definit pel text o camp.
    *
    * @return String
    */
   public String getKeyStyleClass() {
      return keyStyleClass;
   }

   /**
    * Estil definit pel text o camp.
    *
    * @param keyStyleClass String
    */
   public void setKeyStyleClass(String keyStyleClass) {
      this.keyStyleClass = keyStyleClass;
   }

   /**
    * Defineix si el amb el focus es selecciona tot el component.
    *
    * @return boolean
    */
   public boolean isSelectOnFocus() {
      return selectOnFocus;
   }

   /**
    * Defineix si el amb el focus es selecciona tot el component.
    *
    * @param selectOnFocus boolean
    */
   public void setSelectOnFocus(boolean selectOnFocus) {
      this.selectOnFocus = selectOnFocus;
   }

   /**
    * Clau del literal del missatge a mostrar dins el tooltip.
    *
    * @return String
    */
   public String getTooltipKey() {
      return tooltipKey;
   }

   /**
    * Clau del literal del missatge a mostrar dins el tooltip.
    *
    * @param tooltipKey String
    */
   public void setTooltipKey(String tooltipKey) {
      this.tooltipKey = tooltipKey;
   }

   /**
    * Opcions aplicades segons la implementaci� (en el cas actual sota DOM
    * Tooltip).
    *
    * @return String
    */
   public String getTooltipOptions() {
      return tooltipOptions;
   }

   /**
    * Opcions aplicades segons la implementaci� (en el cas actual sota DOM
    * Tooltip).
    *
    * @param tooltipOptions String
    */
   public void setTooltipOptions(String tooltipOptions) {
      this.tooltipOptions = tooltipOptions;
   }

   /**
    * Clau del literal a mostrar si volem mostrar un t�tol com a cap�alera del
    * tooltip.
    *
    * @return String
    */
   public String getTooltipTitleKey() {
      return tooltipTitleKey;
   }

   /**
    * Clau del literal a mostrar si volem mostrar un t�tol com a cap�alera del
    * tooltip.
    *
    * @param tooltipTitleKey String
    */
   public void setTooltipTitleKey(String tooltipTitleKey) {
      this.tooltipTitleKey = tooltipTitleKey;
   }

   /**
    * Mostra el camp com obligatori.
    *
    * @param isRequired boolean
    */
   public void setRequired(boolean isRequired) {
      this.setIsRequired(Boolean.toString(isRequired));
   }

   /**
    * �ndex de tabulaci�.
    *
    * @return String
    */
   public String getTabIndex() {
      return tabIndex;
   }

   /**
    * �ndex de tabulaci�.
    *
    * @param tabIndex String
    */
   public void setTabIndex(String tabIndex) {
      this.tabIndex = tabIndex;
   }

   /**
    * Selects dependents.
    *
    * @return Properties
    */
   public Properties getSelectFieldSource() {
      return this.selectFieldSource;
   }

   /**
    * Selects dependents.
    *
    * @return Object
    */
   public Object getSelectFieldSourceProperties() {
      return this.selectFieldSourceProperties;
   }

   /**
    * Documentaci�.
    *
    * @param obj Object
    *
    * @throws JspException
    */
   public void setSelectFieldSourceProperties(Object obj)
      throws JspException {
      if (obj.getClass().getName().equals(Properties.class.getName())) {
         this.selectFieldSource = (Properties) obj;
      } else if (obj.getClass().getName().equals(String.class.getName())) {
         HashMap hashMap = (HashMap) super.pageContext.getSession()
                                                      .getAttribute("fr.improve.struts.taglib.layout.util.FormUtils.FORM_MODE_KEY");
         Set set = hashMap.keySet();
         Iterator iterator = set.iterator();

         if (((Integer) hashMap.get(iterator.next())).intValue() == fr.improve.struts.taglib.layout.util.FormUtils.INSPECT_MODE) {
            // inspect mode -> reset selectFieldSource
            this.selectFieldSource = new Properties();
         } else {
            // create or edit mode -> create java.util.Properties from a String
            TagUtil.putProperties(selectFieldSource, (String) obj);
         }
      } else {
         // Object must be java.util.Properties or java.lang.String
      }
   }

   /**
    * Selects dependents.
    *
    * @param selectFieldSource Properties
    */
   public void setSelectFieldSource(Properties selectFieldSource) {
      this.selectFieldSource = selectFieldSource;
   }

   /**
    * Nom de la query a executar. Ha d'estar definida en
    * canigo-services-weblist.xml.
    *
    * @return String
    */
   public String getOptionsListName() {
      return optionsListName;
   }

   /**
    * Nom de la query a executar. Ha d'estar definida en
    * canigo-services-weblist.xml.
    *
    * @param optionsListName String
    */
   public void setOptionsListName(String optionsListName) {
      this.optionsListName = optionsListName;
   }

   /**
    * Refer�ncia al servei d'opcions.
    *
    * @return OptionsListService
    */
   public OptionsListService getOptionsListService() {
      return optionsListService;
   }

   /**
    * Refer�ncia al servei d'opcions.
    *
    * @param optionsListService OptionsListService
    */
   public void setOptionsListService(OptionsListService optionsListService) {
      this.optionsListService = optionsListService;
   }

   /**
    * Documentaci�.
    *
    * @return String
    */
   public String getOtherKey() {
      return otherKey;
   }

   /**
    * Documentaci�.
    *
    * @param otherKey String
    */
   public void setOtherKey(String otherKey) {
      this.otherKey = otherKey;
   }

   /**
    * Documentaci�.
    *
    * @return Returns String.
    */
   public String getOtherValue() {
      return otherValue;
   }

   /**
    * Documentaci�.
    *
    * @param otherValue String.
    */
   public void setOtherValue(String otherValue) {
      this.otherValue = otherValue;
   }

   /**
    * Liberar tots els camps configurats per tal de no copiar en els
    * pr�xims tags.
    *
    * @author MMO
    */
   public void release() {
      super.release();
      reset();
   }

   /**
    * Liberar tots els camps configurats per tal de no copiar en els
    * pr�xims tags.
    * Algunes propietats no es liberen correctament per Struts Layout.
    *
    * @author MMO
    */
   protected void reset() {
      super.reset();
      value = null;
      accesskey = null;
      key = null;
      keyStyleClass = null;
      i18nService = null;
      tooltipKey = null;
      tooltipOptions = null;
      tooltipTitleKey = null;
      selectOnFocus = true;
      fieldErrorDisplayed = true;
      styleId = null;
      otherKey = null;
      otherProperty = null;
      otherValue = null;
      optionsListName = null;
      optionsListService = null;
      selectFieldSource = null;
      selectFieldSourceProperties = null;
      tabIndex = null;
      tooltipKey = null;
      tooltipOptions = null;
      tooltipTitleKey = null;
      validationService = null;
   }

   /**
    * Permet injectar serveis del contenidor d' spring.
    *
    * @param services String
    *
    * @throws JspException
    */
   public void setServices(String services) throws JspException {
      ServicesTagHelper.setServices(services, pageContext, this);
   }

   ///**
   // * Method to set properties from jsp directly
   // * @since 1.1
   // */

   //    public void setSelectFieldSource(String aProperties)
   //        throws JspException {
   //    	super.pageContext.getSession().getAttribute("fr.improve.struts.taglib.layout.util.FormUtils.FORM_MODE_KEY");
   //        TagUtil.putProperties(selectFieldSource, aProperties);
   //    }

   //    public void setSelectFieldSourceStr(String aProperties)
   //    throws JspException {
   //    	
   //    	
   //    	if(aProperties.getClass().getName().equals(Properties.class.getName()))System.out.println("Properties");
   //    	if(aProperties.getClass().getName().equals(String.class.getName()))System.out.println("String");
   //    	HashMap hashMap = (HashMap)super.pageContext.getSession().getAttribute("fr.improve.struts.taglib.layout.util.FormUtils.FORM_MODE_KEY");
   //    	Set set = hashMap.keySet();
   //    	Iterator iterator = set.iterator();
   //    	if(((Integer)hashMap.get(iterator.next())).intValue() == fr.improve.struts.taglib.layout.util.FormUtils.INSPECT_MODE )System.out.println("INSPECT_MODE");
   //    	else System.out.println("CREATE OR EDIT MODE");
   //    	TagUtil.putProperties(selectFieldSource, aProperties);
   //}
}
