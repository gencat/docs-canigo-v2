package net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers;

import java.util.Properties;

import javax.servlet.jsp.JspException;

import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.OptionsFieldTag;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.SelectFieldTag;

import org.apache.struts.taglib.TagUtils;

import fr.improve.struts.taglib.layout.field.AbstractModeFieldTag;
import fr.improve.struts.taglib.layout.util.LayoutUtils;


/**
 * Helper de Select Field Tag.
 * @author XES
 * @version $Revision: 1.5 $ $Date: 2007/07/30 09:16:22 $
 *
 * @see
 * @since 1.0
 * Revision 1.4  2007/05/23 10:47:40  msabates
 * Cap�alera
 *
 * Revision 1.1.1.1.2.1  2007/05/18 10:49:47  fernando.vaquero
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2007/04/23 11:13:42  fernando.vaquero
 * Importacio canigo 2.0
 *
 * Revision 1.3  2007/04/23 11:13:41  msabates
 * Canvis que estaven a la v1.4
 *
 * Revision 1.2  2007/04/20 09:49:21  msabates
 * Canvis que estaven a la v1.4
 *
 * Revision 1.9  2007/02/20 14:41:58  evidal
 * EVC: merging 1.0 & 1.1.
 *
 * Revision 1.8  2006/11/16 17:01:52  mmateos
 * author: crico: version 1.1 no estable
 *
 * Revision 1.8  2006/09/19 16:41:56  crico
 * version 1.1 no estable
 *
 * Revision 1.6.2.4  2006/06/30 08:58:03  evidal
 * *** empty log message ***
 *
 * Revision 1.7  2006/06/19 14:22:02  evidal
 * versio de partida del 20%
 *
 * Revision 1.6.2.3  2006/05/25 11:04:44  evidal
 * EVC: arreglat el bug del select tag en mode inspect.
 *
 * Revision 1.6.2.2  2006/03/06 11:42:20  mmateos
 * MMR: corregido un bug de binding en los CustomNumberEditor
 *
 * Revision 1.6.2.1  2006/03/01 10:01:47  xescuder
 * *** empty log message ***
 *
 * Revision 1.6  2006/02/24 13:54:03  xescuder
 * XES: Checked format of fields on properties
 *
 */
public class SelectFieldTagHelper {
    private static final String SOURCE_ID = "source";
    private static final String PARAM_NAME = "paramName";

    /**
     * Genera el codi Ajax per tal d'obtenir informaci� sobre el select.
     * 
     * @param aSelectFieldTag SelectFieldTag
     * @throws JspException
     */
    private static void generateClientSelectFieldTag(
        SelectFieldTag aSelectFieldTag) throws JspException {
        Properties selectSourceProperties = aSelectFieldTag.getSelectFieldSource();
    	
        if (selectSourceProperties != null && !selectSourceProperties.isEmpty()) { // this select depends on other select
                                              // We delegate to AJAX the calling to optionsListService in order
                                              // to get values after the select source changes its value

            // Source of selected value
            String source = (String) selectSourceProperties.get(SOURCE_ID);

            if (source==null) {
                throw new JspException("Please define attribute '" + SOURCE_ID);
            }
            
            // Parameter to construct request to obtain dependency
            String paramName = (String) selectSourceProperties.get(PARAM_NAME);
            if (paramName==null) {
                throw new JspException("Please define attribute '" + PARAM_NAME);
            }
            
            
            
            String target = aSelectFieldTag.getStyleId();
            String defaultSelected = "";

            if ((aSelectFieldTag.getName() != null) &&
                    (aSelectFieldTag.getProperty() != null)) {
                Object defaultSelectedObject = LayoutUtils.getBeanFromPageContext(aSelectFieldTag.getPageContext(),
                        aSelectFieldTag.getName(), aSelectFieldTag.getProperty());

                if (defaultSelectedObject != null) {
                    defaultSelected = defaultSelectedObject.toString();
                }
            }

            String optionsTargetListName = aSelectFieldTag.getOptionsListName();
            
            String otherKey = aSelectFieldTag.getOtherKey() != null ? LayoutUtils.getLabel(aSelectFieldTag.getPageContext(), aSelectFieldTag.getOtherKey(),null) : "";
            String otherValue = aSelectFieldTag.getOtherValue() != null ? aSelectFieldTag.getOtherValue() : "";

            if ((target != null) && (optionsTargetListName != null)) {
                TagUtils tagUtils = TagUtils.getInstance();
                StringBuffer buffer = new StringBuffer();
                buffer.append("<script type=\"text/javascript\">");
                buffer.append("new CanigoSelectFieldTag.SelectTarget({");
                buffer.append("defaultSelected: \"" + defaultSelected + "\"");
                buffer.append(",source: \"" + source + "\"");
                buffer.append(",target: \"" + target + "\"");
                buffer.append(",paramName: \"" + paramName + "\"");
                // Append list name
                buffer.append(",optionsTargetListName: \"" +
                    optionsTargetListName + "\"");
                // If otherKey otherValue is defined
                buffer.append(",otherKey: \"" + otherKey + "\"");
                buffer.append(",otherValue: \"" + otherValue + "\"");
                
                buffer.append("});");
                buffer.append("</script>");
                tagUtils.write(aSelectFieldTag.getPageContext(),
                    buffer.toString());
            }
        }
    }

    /**
     * Genera els valors de la lista desde el hql definit.
     * @param aSelectFieldTag SelectFieldTag
     * @throws JspException
     */
    public static void generateOptions(SelectFieldTag aSelectFieldTag)
        throws JspException {
        String optionsListName = aSelectFieldTag.getOptionsListName();

        if (optionsListName != null) { // source list name to obtain from database or other source

            Properties selectSourceProperties = aSelectFieldTag.getSelectFieldSource();

            // If field is in any INSPECT MODE, options must not be generated. Then, selectSourceProperties must be null.
            int fieldMode = aSelectFieldTag.getFieldDisplayMode();
            if((fieldMode == AbstractModeFieldTag.MODE_INSPECT) || 
               (fieldMode == AbstractModeFieldTag.MODE_INSPECT_ONLY) || 
               (fieldMode == AbstractModeFieldTag.MODE_INSPECT_PRESENT) || 
               (fieldMode == AbstractModeFieldTag.MODE_NODISPLAY)){
        			selectSourceProperties = null;
        	}
            if (selectSourceProperties != null && !selectSourceProperties.isEmpty()) {
                generateClientSelectFieldTag(aSelectFieldTag);
            } else {
                OptionsFieldTag optionsFieldTag = new OptionsFieldTag();
                optionsFieldTag.setOptionsListName(aSelectFieldTag.getOptionsListName());
                optionsFieldTag.setOptionsListService(aSelectFieldTag.getOptionsListService());
                optionsFieldTag.setPageContext(aSelectFieldTag.getPageContext());
                optionsFieldTag.setParent(aSelectFieldTag);
                optionsFieldTag.setI18nService(aSelectFieldTag.getI18nService());
                optionsFieldTag.setValidationService(aSelectFieldTag.getValidationService());
                optionsFieldTag.setStyleId(aSelectFieldTag.getStyleId()+"_options");
                optionsFieldTag.doStartTag();
                optionsFieldTag.doEndTag();
            }
        }
    }
}
