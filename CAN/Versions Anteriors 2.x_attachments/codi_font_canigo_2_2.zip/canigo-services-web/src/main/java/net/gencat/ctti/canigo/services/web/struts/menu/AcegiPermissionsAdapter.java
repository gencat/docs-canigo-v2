/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.menu;

import java.io.Serializable;

import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.security.SecurityService;
import net.sf.navigator.menu.MenuComponent;
import net.sf.navigator.menu.PermissionsAdapter;

import org.apache.commons.lang.StringUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class AcegiPermissionsAdapter implements PermissionsAdapter,
   Serializable {
   /**
    * Documentaci�.
    */
   private LoggingService logService = null;

   /**
    * Documentaci�.
    */
   private SecurityService securityService = null;

   /**
    * Creates a new AcegiPermissionsAdapter object.
    *
    * @param securityService DOCUMENT ME.
    * @param logService DOCUMENT ME.
    */
   public AcegiPermissionsAdapter(SecurityService securityService,
      LoggingService logService) {
      this.securityService = securityService;
      this.logService = logService;
   }

   /**
    * If the menu is allowed, this should return true.
    *
    * @return whether or not the menu is allowed.
    */
   public boolean isAllowed(MenuComponent menu) {
      if (menu.getRoles() == null) {
         return true; // no roles define, allow everyone
      } else {
         // Get the list of roles this menu allows
         String[] allowedRolesArray = StringUtils.split(menu.getRoles(), ",");

         if (this.securityService != null) {
            for (int i = 0; i < allowedRolesArray.length; i++) {
               if (this.securityService.isUserInRole(allowedRolesArray[i])) {
                  if (this.logService != null) {
                     this.logService.getLog(this.getClass())
                                    .info("User has the rol " +
                        allowedRolesArray[i] + " to access the menu " +
                        menu.getName());
                  }

                  return true;
               }
            }
         }

         if (this.logService != null) {
            this.logService.getLog(this.getClass())
                           .info("User has not roles to access the menu " +
               menu.getName());
         }
      }

      return false;
   }
}
