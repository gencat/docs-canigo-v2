/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.helper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import ognl.Ognl;
import ognl.OgnlException;

import org.springframework.beans.BeanUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class BindingHelper {
   /**
    * Documentaci�.
    */
   private static final String METADATA = "__Metadata";

   /**
    * Documentaci�.
    */
   private static final String ITEMS_CLASS = "itemsClass__";

   /**
    * Remove null elements in collections.
    */
   public static Object removeNullElementsInCollections(Map parameterMap,
      Object target) {
      Map paramMap = parameterMap;
      List tmpCollections = new ArrayList();

      Set keyset = paramMap.keySet();
      Iterator paramIterator = keyset.iterator();

      while (paramIterator.hasNext()) {
         String paramName = (String) paramIterator.next();

         if ((paramName.indexOf("[") != -1) &&
               (paramName.indexOf("[") != paramName.lastIndexOf("["))) {
            // multiple collections
            //				throw new BindException("Multiple collections not supported.");
         }

         if ((paramName.startsWith(METADATA)) &&
               (paramName.endsWith(ITEMS_CLASS))) {
            String collectionName = paramName.substring(paramName.indexOf("-") +
                  1, paramName.lastIndexOf("-"));
            tmpCollections.add(collectionName);
         }
      }

      Iterator tmpIt = tmpCollections.iterator();

      while (tmpIt.hasNext()) {
         String tmpCollection = (String) tmpIt.next();

         try {
            Object tmpList = Ognl.getValue(tmpCollection, target);

            if (tmpList instanceof Collection) {
               Collection tmpLL = (Collection) tmpList;

               while (tmpLL.contains(null)) {
                  tmpLL.remove(null);
               }
            }
         } catch (OgnlException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
      }

      return target;
   }

   /**
   * Build Collections.Method where collection properties are initilized.
   * Spring don't support this.
   * Es per validacions.
   * @param request
   * @param target
   */
   public static Object buildCollections(Map pValues, Object target) {
      Map collectionIndexMap = new HashMap();
      Map collectionSizeMap = new HashMap();
      Map itemsClassMap = new HashMap();

      Map paramMap = pValues;

      Set keyset = paramMap.keySet();
      Iterator paramIterator = keyset.iterator();

      while (paramIterator.hasNext()) {
         String paramName = (String) paramIterator.next();

         if ((paramName.indexOf("[") != -1) &&
               (paramName.indexOf("[") != paramName.lastIndexOf("["))) {
            // multiple collections
            //				throw new BindException("Multiple collections not supported.");
         }

         if ((paramName.startsWith(METADATA)) &&
               (paramName.endsWith(ITEMS_CLASS))) {
            String collectionName = paramName.substring(paramName.indexOf("-") +
                  1, paramName.lastIndexOf("-"));
            Object tmpValue = paramMap.get(paramName);
            String stringArray = null;

            if (tmpValue instanceof String) {
               String itemsClass = (String) paramMap.get(paramName);
               itemsClassMap.put(collectionName, itemsClass);
            } else if (tmpValue instanceof String[]) {
               String[] tmpArray = (String[]) paramMap.get(paramName);

               if (tmpArray.length == 1) {
                  String itemsClass = tmpArray[0];
                  itemsClassMap.put(collectionName, itemsClass);
               } else if (tmpArray.length > 1) {
                  System.out.println("The parameter " + paramName +
                     " has more than one value");
               } else {
               }
            } else {
               System.out.println("The map has elements of the class " +
                  tmpValue.getClass().getName());
            }
         }

         if (paramName.indexOf("[") != -1) {
            String collectionName = paramName.substring(0,
                  paramName.indexOf("["));
            String collectionIndex = paramName.substring(paramName.indexOf("[") +
                  1, paramName.indexOf("]"));

            if (collectionSizeMap.get(collectionName) == null) {
               collectionSizeMap.put(collectionName, collectionIndex);

               ArrayList indexArray = new ArrayList();
               indexArray.add(collectionIndex);
               collectionIndexMap.put(collectionName, indexArray);
            } else {
               ArrayList indexArray = (ArrayList) collectionIndexMap.get(collectionName);

               if (!indexArray.contains(collectionIndex)) {
                  indexArray.add(collectionIndex);
               }

               collectionIndexMap.put(collectionName, indexArray);

               if ((new Integer(collectionIndex)).intValue() > (new Integer(
                        (String) collectionSizeMap.get(collectionName))).intValue()) {
                  collectionSizeMap.put(collectionName, collectionIndex);
               }
            }
         }
      }

      Set collectionSet = itemsClassMap.keySet();
      Iterator collectionIterator = collectionSet.iterator();

      while (collectionIterator.hasNext()) {
         String collectionName = (String) collectionIterator.next();
         String collectionClass = (String) itemsClassMap.get(collectionName);

         if (collectionSizeMap.containsKey(collectionName)) {
            int collectionSize = new Integer((String) collectionSizeMap.get(
                     collectionName)).intValue();
            List arrayList = new ArrayList(collectionSize + 1);
            ArrayList indexArray = (ArrayList) collectionIndexMap.get(collectionName);

            for (int i = 0; i <= collectionSize; i++) {
               Class clazz;

               try {
                  if (indexArray.contains(new Integer(i).toString())) {
                     clazz = Class.forName(collectionClass);

                     Object item = BeanUtils.instantiateClass(clazz);
                     arrayList.add(i, item);
                  } else {
                     arrayList.add(i, null);
                  }
               } catch (ClassNotFoundException e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
               }
            }

            try {
               Ognl.setValue(collectionName, target, arrayList);
            } catch (OgnlException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
            }
         }
      }

      return target;
   }
}
