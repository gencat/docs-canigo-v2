/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.web.struts.taglib.forms;

import javax.servlet.jsp.JspException;

import fr.improve.struts.taglib.layout.ImageTag;

import net.gencat.ctti.canigo.services.i18n.I18nService;
import net.gencat.ctti.canigo.services.validation.ValidationService;
import net.gencat.ctti.canigo.services.web.struts.taglib.forms.fields.helpers.ServicesTagHelper;
import net.gencat.ctti.canigo.services.web.taglib.util.TagUtil;


/**
 * <p>Definici� de les propietats del Tag ActionImageTag.</p>
 *
 * @author XES
 */
public class ActionImageTag extends ImageTag implements net.gencat.ctti.canigo.services.web.taglib.ActionImageTag {
   /**
   * Serial version UID generated
   */
   private static final long serialVersionUID = -500990363481331305L;

   /**
   * I18nService
   */
   private I18nService i18nService;

   /**
    * ValidationService
    */
   private ValidationService validationService;

   /**
    * Creates a new ActionImageTag object.
    */
   public ActionImageTag() {
      super();
   }

   /**
    * Inici de la configuraci� del tag.
    *
    * @return int
    *
    * @throws JspException - JSP Exception
    */
   public int doStartLayoutTag() throws JspException {
      TagUtil.copyConfiguration(this);

      return super.doStartLayoutTag();
   }

   /**
    * Documentaci�.
    *
    * @return boolean
    */
   public boolean isDisplay() {
      return display;
   }

   /**
    * Documentaci�.
    *
    * @param display boolean
    */
   public void setDisplay(boolean display) {
      this.display = display;
   }

   /**
    * Degut a una inconsistencia del Struts-layout, mode no pot ser obtingut.
    *
    * @return null;
    */
   public String getMode() {
      return null;
   }

   /**
    * Alineaci� imatge.
    *
    * @return String
    */
   public String getValign() {
      return valign;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @return I18nService
    */
   public I18nService getI18nService() {
      return i18nService;
   }

   /**
    * Refer�ncia al servei d'internacionalitzaci�.
    *
    * @param service I18nService
    */
   public void setI18nService(I18nService service) {
      i18nService = service;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @return ValidationService
    */
   public ValidationService getValidationService() {
      return validationService;
   }

   /**
    * Refer�ncia al servei de validaci�.
    *
    * @param validationService ValidationService
    */
   public void setValidationService(ValidationService validationService) {
      this.validationService = validationService;
   }

   /**
    * Permet injectar serveis del contenidor d' spring.
    *
    * @param services String
    *
    * @throws JspException
    */
   public void setServices(String services) throws JspException {
      ServicesTagHelper.setServices(services, pageContext, this);
   }
}
