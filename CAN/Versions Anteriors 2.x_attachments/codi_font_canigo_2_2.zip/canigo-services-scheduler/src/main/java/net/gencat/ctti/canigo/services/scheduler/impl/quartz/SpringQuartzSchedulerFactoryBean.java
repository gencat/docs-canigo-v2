/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.scheduler.impl.quartz;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.scheduler.JobDetailIF;
import net.gencat.ctti.canigo.services.scheduler.SchedulerFactoryBeanIF;
import net.gencat.ctti.canigo.services.scheduler.TriggerIF;
import net.gencat.ctti.canigo.services.scheduler.exception.SchedulerServiceException;

import org.quartz.JobDetail;
import org.quartz.Trigger;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;


/**
 * FactoryBean that sets up a Quartz Scheduler and exposes it for bean
 * references.
 *
 * <p>
 * Allows registration of JobDetails, Calendars and Triggers, automatically
 * starting the scheduler on initialization and shutting it down on destruction.
 * In scenarios that just require static registration of jobs at startup, there
 * is no need to access the Scheduler instance itself in application code.
 *
 * <p>
 * For dynamic registration of jobs at runtime, use a bean reference to this
 * SchedulerFactoryBean to get direct access to the Quartz Scheduler (<code>org.quartz.Scheduler</code>).
 * This allows you to create new jobs and triggers, and also to control and
 * monitor the entire Scheduler.
 *
 * <p>
 * Note that Quartz instantiates a new Job for each execution, in contrast to
 * Timer which uses a TimerTask instance that is shared between repeated
 * executions. Just JobDetail descriptors are shared.
 *
 * <p>
 * When using persistent jobs, it is strongly recommended to perform all
 * operations on the Scheduler within Spring-managed (or plain JTA)
 * transactions. Else, database locking will not properly work and might even
 * break. (See {@link #setDataSource setDataSource} javadoc for details.)
 *
 * <p>
 * The preferred way to achieve transactional execution is to demarcate
 * declarative transactions at the business facade level, which will
 * automatically apply to Scheduler operations performed within those scopes.
 * Alternatively, define a TransactionProxyFactoryBean for the Scheduler itself.
 *
 * <p>
 * SchedulerFactoryBean is fully compatible with both Quartz 1.3 and 1.4
 * (through special checks where necessary).
 *
 * @author Juergen Hoeller
 * @since 18.02.2004
 * @see #setDataSource
 * @see org.quartz.Scheduler
 * @see org.quartz.SchedulerFactory
 * @see org.quartz.impl.StdSchedulerFactory
 * @see org.springframework.transaction.interceptor.TransactionProxyFactoryBean
 */
public class SpringQuartzSchedulerFactoryBean extends SchedulerFactoryBean
   implements SchedulerFactoryBeanIF {
   /**
    * Documentaci�.
    */
   public boolean jobDetailsInitiated = false;

   /**
    * Documentaci�.
    *
    * @param setJobDetails Documentaci�
    */
   public void setJobDetails(JobDetailIF[] setJobDetails) {
      if ((setJobDetails != null) && (setJobDetails.length > 0) &&
            !jobDetailsInitiated) {
         ArrayList alJobDetails = new ArrayList(Arrays.asList(setJobDetails));
         JobDetail[] arJobDtail = new JobDetail[alJobDetails.size()];

         for (int i = 0; i < alJobDetails.size(); i++) {
            arJobDtail[i] = (SpringQuartzJobDetailBean) alJobDetails.get(i);
         }

         super.setJobDetails(arJobDtail);
      }

      jobDetailsInitiated = true;
   }

   /**
    * Documentaci�.
    *
    * @param triggers Documentaci�
    */
   public void setTriggers(TriggerIF[] triggers) {
      if (triggers != null) {
         ArrayList alTriggers = new ArrayList(Arrays.asList(triggers));
         Trigger[] arTriggers = new Trigger[alTriggers.size()];
         JobDetailIF[] arJobDetails = new JobDetailIF[alTriggers.size()];

         for (int i = 0; i < alTriggers.size(); i++) {
            arTriggers[i] = (SpringQuartzTrigger) alTriggers.get(i);

            if (((SpringQuartzTrigger) alTriggers.get(i)).getJobDetail() != null) {
               arJobDetails[i] = (JobDetailIF) ((SpringQuartzTrigger) alTriggers.get(i)).getJobDetail();
            }
         }

         setJobDetails(arJobDetails);
         super.setTriggers(arTriggers);
      } else {
         super.setTriggers(null);
      }
   }

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void afterPropertiesSet() throws SchedulerServiceException {
      try {
         super.afterPropertiesSet();
      } catch (Exception ex) {
         String[] args = { this.getClass().getName() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.scheduler.afterPropertiesSet",
               args, Layer.SERVICES, Subsystem.SCHEDULER_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SchedulerServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void destroy() throws SchedulerServiceException {
      try {
         super.destroy();
      } catch (Exception ex) {
         String[] args = { this.getClass().getName() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.scheduler.destroyFactoryBeanPropertiesSet",
               args, Layer.SERVICES, Subsystem.SCHEDULER_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SchedulerServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getDelegate() {
      return this;
   }
}
