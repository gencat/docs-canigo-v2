/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.scheduler;

import java.beans.PropertyEditor;

import java.lang.reflect.Method;

import net.gencat.ctti.canigo.services.scheduler.exception.SchedulerServiceException;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public interface MethodInvokingJobDetailFactoryBeanIF {
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getDelegate();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getObject();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Class getObjectType();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isSingleton();

   /**
    * Documentaci�.
    *
    * @param beanName Documentaci�
    */
   public void setBeanName(String beanName);

   /**
    * Documentaci�.
    *
    * @param concurrent Documentaci�
    */
   public void setConcurrent(boolean concurrent);

   /**
    * Documentaci�.
    *
    * @param group Documentaci�
    */
   public void setGroup(String group);

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    */
   public void setName(String name);

   /**
    * Documentaci�.
    *
    * @param requiredType Documentaci�
    * @param propertyEditor Documentaci�
    */
   public void registerCustomEditor(Class requiredType,
      PropertyEditor propertyEditor);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object[] getArguments();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Method getPreparedMethod();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Class getTargetClass();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getTargetMethod();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getTargetObject();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public Object invoke() throws SchedulerServiceException;

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void prepare() throws SchedulerServiceException;

   /**
    * Documentaci�.
    *
    * @param arguments Documentaci�
    */
   public void setArguments(Object[] arguments);

   /**
    * Documentaci�.
    *
    * @param staticMethod Documentaci�
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void setStaticMethod(String staticMethod)
      throws SchedulerServiceException;

   /**
    * Documentaci�.
    *
    * @param targetClass Documentaci�
    */
   public void setTargetClass(Class targetClass);

   /**
    * Documentaci�.
    *
    * @param targetMethod Documentaci�
    */
   public void setTargetMethod(String targetMethod);

   /**
    * Documentaci�.
    *
    * @param targetObject Documentaci�
    */
   public void setTargetObject(Object targetObject);

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void afterPropertiesSet() throws SchedulerServiceException;
}
