/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.scheduler.impl.quartz;

import java.util.Date;

import net.gencat.ctti.canigo.services.scheduler.TriggerIF;
import net.gencat.ctti.canigo.services.scheduler.exception.SchedulerServiceException;

import org.quartz.Calendar;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Trigger;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public abstract class SpringQuartzTrigger extends Trigger implements TriggerIF {
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract Object getJobDetail();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public abstract void addTriggerListener(String arg0);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract Object clone();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public abstract int compareTo(Object arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public abstract Date computeFirstFireTime(Calendar arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public abstract boolean equals(Object arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    *
    * @return Documentaci�
    */
   public abstract int executionComplete(JobExecutionContext arg0,
      JobExecutionException arg1);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract String getCalendarName();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract String getDescription();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract Date getEndTime();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract Date getFinalFireTime();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract String getFireInstanceId();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public abstract Date getFireTimeAfter(Date arg0);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract String getFullJobName();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract String getFullName();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract String getGroup();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract String getJobGroup();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract String getJobName();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract int getMisfireInstruction();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract String getName();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract Date getNextFireTime();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract Date getPreviousFireTime();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract Date getStartTime();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract String[] getTriggerListenerNames();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract boolean isVolatile();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract boolean mayFireAgain();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public abstract boolean removeTriggerListener(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public abstract void setCalendarName(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public abstract void setDescription(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public abstract void setFireInstanceId(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public abstract void setGroup(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public abstract void setJobGroup(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public abstract void setJobName(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public abstract void setMisfireInstruction(int arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public abstract void setName(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public abstract void setStartTime(Date arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public abstract void setVolatility(boolean arg0);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public abstract String toString();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public abstract void triggered(Calendar arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public abstract void updateAfterMisfire(Calendar arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    */
   public abstract void updateWithNewCalendar(Calendar arg0, long arg1);

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public abstract void validate() throws SchedulerServiceException;

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   protected abstract boolean validateMisfireInstruction(int arg0);
}
