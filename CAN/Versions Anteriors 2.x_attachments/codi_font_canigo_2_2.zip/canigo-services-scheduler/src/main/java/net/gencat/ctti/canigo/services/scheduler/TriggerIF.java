/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.scheduler;

import java.util.Date;

import net.gencat.ctti.canigo.services.scheduler.exception.SchedulerServiceException;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public interface TriggerIF {
   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void addTriggerListener(String arg0);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getCalendarName();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getDescription();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Date getEndTime();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Date getFinalFireTime();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getFireInstanceId();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public Date getFireTimeAfter(Date arg0);

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getFullJobName();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getFullName();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getGroup();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getJobGroup();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getJobName();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getMisfireInstruction();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getName();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Date getNextFireTime();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Date getPreviousFireTime();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Date getStartTime();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String[] getTriggerListenerNames();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isVolatile();

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean mayFireAgain();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean removeTriggerListener(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setCalendarName(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setDescription(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setFireInstanceId(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setGroup(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setJobGroup(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setJobName(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setMisfireInstruction(int arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setName(String arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setStartTime(Date arg0);

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setVolatility(boolean arg0);

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void validate() throws SchedulerServiceException;
}
