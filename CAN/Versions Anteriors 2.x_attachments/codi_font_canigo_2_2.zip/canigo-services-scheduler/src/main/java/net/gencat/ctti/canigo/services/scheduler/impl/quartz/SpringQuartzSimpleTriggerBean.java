/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.scheduler.impl.quartz;

import java.util.Date;
import java.util.Properties;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.scheduler.SimpleTriggerIF;
import net.gencat.ctti.canigo.services.scheduler.exception.SchedulerServiceException;

import org.apache.commons.beanutils.BeanUtils;
import org.quartz.Calendar;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.scheduling.quartz.SimpleTriggerBean;


/**
 * Convenience subclass of Quartz' SimpleTrigger class that eases
 * bean-style usage.
 *
 * <p>SimpleTrigger itself is already a JavaBean but lacks sensible
 * defaults. This class uses the Spring bean name as job name, the
 * Quartz default group ("DEFAULT") as job group, the current time
 * as start time, and indefinite repetition, if not specified.
 *
 * <p>This class will also register the trigger with the job name
 * and group of a given JobDetail. This allows SchedulerFactoryBean
 * to automatically register a trigger for the respective JobDetail,
 * instead of registering the JobDetail separately.
 *
 * @author Juergen Hoeller
 * @since 18.02.2004
 * @see #setName
 * @see #setGroup
 * @see #setStartTime
 * @see #setJobName
 * @see #setJobGroup
 * @see #setJobDetail
 * @see SchedulerFactoryBean#setTriggers
 * @see SchedulerFactoryBean#setJobDetails
 */
public class SpringQuartzSimpleTriggerBean extends SpringQuartzTrigger
   implements SimpleTriggerIF, SpringQuartzJobDetailAwareTrigger, BeanNameAware,
      InitializingBean {
   /**
    * Documentaci�.
    */
   private static final long serialVersionUID = 1L;

   /**
    * Documentaci�.
    */
   protected SimpleTriggerBean delegate;

   /**
    * Creates a new SpringQuartzSimpleTriggerBean object.
    */
   public SpringQuartzSimpleTriggerBean() {
      delegate = new SimpleTriggerBean();
   }

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void afterPropertiesSet() throws SchedulerServiceException {
      try {
         delegate.afterPropertiesSet();
      } catch (Exception ex) {
         String[] args = { this.getClass().getName() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.scheduler.afterPropertiesSet",
               args, Layer.SERVICES, Subsystem.SCHEDULER_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SchedulerServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getJobDetail() {
      try {
         SpringQuartzJobDetailBean jobDetailBean = new SpringQuartzJobDetailBean();

         if (delegate.getJobDetail() != null) {
            BeanUtils.copyProperties(jobDetailBean, delegate.getJobDetail());
         }

         return (SpringQuartzJobDetailBean) jobDetailBean;
      } catch (Exception ex) {
         String[] args = { this.getClass().getName() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.scheduler.copyProperties",
               args, Layer.SERVICES, Subsystem.SCHEDULER_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SchedulerServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param beanName Documentaci�
    */
   public void setBeanName(String beanName) {
      delegate.setBeanName(beanName);
   }

   /**
    * Documentaci�.
    *
    * @param jobDetailIF Documentaci�
    */
   public void setJobDetail(Object jobDetailIF) {
      try {
         JobDetail jobDetail = new JobDetail();

         if (jobDetailIF != null) {
            BeanUtils.copyProperties(jobDetail, jobDetailIF);
         }

         delegate.setJobDetail(jobDetail);
      } catch (Exception ex) {
         String[] args = { this.getClass().getName() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.scheduler.copyProperties",
               args, Layer.SERVICES, Subsystem.SCHEDULER_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SchedulerServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param constantName Documentaci�
    */
   public void setMisfireInstructionName(String constantName) {
      delegate.setMisfireInstructionName(constantName);
   }

   /**
    * Documentaci�.
    *
    * @param startDelay Documentaci�
    */
   public void setStartDelay(long startDelay) {
      delegate.setStartDelay(startDelay);
   }

   /**
    * Documentaci�.
    *
    * @param names Documentaci�
    */
   public void setTriggerListenerNames(String[] names) {
      delegate.setTriggerListenerNames(names);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public Date computeFirstFireTime(Calendar arg0) {
      return delegate.computeFirstFireTime(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    *
    * @return Documentaci�
    */
   public int computeNumTimesFiredBetween(Date arg0, Date arg1) {
      return delegate.computeNumTimesFiredBetween(arg0, arg1);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    *
    * @return Documentaci�
    */
   public int executionComplete(JobExecutionContext arg0,
      JobExecutionException arg1) {
      return delegate.executionComplete(arg0, arg1);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Date getEndTime() {
      return delegate.getEndTime();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Date getFinalFireTime() {
      return delegate.getFinalFireTime();
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public Date getFireTimeAfter(Date arg0) {
      return delegate.getFireTimeAfter(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public Date getFireTimeBefore(Date arg0) {
      return delegate.getFireTimeBefore(arg0);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Date getNextFireTime() {
      return delegate.getNextFireTime();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Date getPreviousFireTime() {
      return delegate.getPreviousFireTime();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getRepeatCount() {
      return delegate.getRepeatCount();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public long getRepeatInterval() {
      return delegate.getRepeatInterval();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Date getStartTime() {
      return delegate.getStartTime();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getTimesTriggered() {
      return delegate.getTimesTriggered();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean mayFireAgain() {
      return delegate.mayFireAgain();
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setEndTime(Date arg0) {
      delegate.setEndTime(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setNextFireTime(Date arg0) {
      delegate.setNextFireTime(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setPreviousFireTime(Date arg0) {
      delegate.setPreviousFireTime(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setRepeatCount(int arg0) {
      delegate.setRepeatCount(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setRepeatInterval(long arg0) {
      delegate.setRepeatInterval(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setStartTime(Date arg0) {
      delegate.setStartTime(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setTimesTriggered(int arg0) {
      delegate.setTimesTriggered(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void triggered(Calendar arg0) {
      delegate.triggered(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void updateAfterMisfire(Calendar arg0) {
      delegate.updateAfterMisfire(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    */
   public void updateWithNewCalendar(Calendar arg0, long arg1) {
      delegate.updateWithNewCalendar(arg0, arg1);
   }

   /**
    * Documentaci�.
    *
    * @throws SchedulerServiceException Documentaci�
    */
   public void validate() throws SchedulerServiceException {
      try {
         delegate.validate();
      } catch (Exception ex) {
         String[] args = { this.getClass().getName() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.scheduler.validate",
               args, Layer.SERVICES, Subsystem.SCHEDULER_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SchedulerServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void addTriggerListener(String arg0) {
      delegate.addTriggerListener(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public int compareTo(Object arg0) {
      return delegate.compareTo(arg0);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getCalendarName() {
      return delegate.getCalendarName();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getDescription() {
      return delegate.getDescription();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getFireInstanceId() {
      return delegate.getFireInstanceId();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getFullJobName() {
      return delegate.getFullJobName();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getFullName() {
      return delegate.getFullName();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getGroup() {
      return delegate.getGroup();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getJobGroup() {
      return delegate.getJobGroup();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getJobName() {
      return delegate.getJobName();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getMisfireInstruction() {
      return delegate.getMisfireInstruction();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getName() {
      return delegate.getName();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String[] getTriggerListenerNames() {
      return delegate.getTriggerListenerNames();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isVolatile() {
      return delegate.isVolatile();
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean removeTriggerListener(String arg0) {
      return delegate.removeTriggerListener(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setCalendarName(String arg0) {
      delegate.setCalendarName(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setDescription(String arg0) {
      delegate.setDescription(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setFireInstanceId(String arg0) {
      delegate.setFireInstanceId(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setGroup(String arg0) {
      delegate.setGroup(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setJobGroup(String arg0) {
      delegate.setJobGroup(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setJobName(String arg0) {
      delegate.setJobName(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setMisfireInstruction(int arg0) {
      delegate.setMisfireInstruction(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setName(String arg0) {
      delegate.setName(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setVolatility(boolean arg0) {
      delegate.setVolatility(arg0);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object getDelegate() {
      return delegate;
   }

   /**
    * Documentaci�.
    *
    * @param delegate Documentaci�
    */
   public void setDelegate(SimpleTriggerBean delegate) {
      this.delegate = delegate;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object clone() {
      return delegate.clone();
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   public boolean equals(Object arg0) {
      return delegate.equals(arg0);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String toString() {
      return delegate.toString();
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    */
   protected boolean validateMisfireInstruction(int arg0) {
      return false;
   }
}
