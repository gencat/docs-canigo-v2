/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package org.springframework.beans;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;


/**
 * @author Juergen Hoeller
 * @since 11.11.2003
 */
public class IndexedTestBean {
   /**
    * Documentaci�.
    */
   private Collection collection;

   /**
    * Documentaci�.
    */
   private List list;

   /**
    * Documentaci�.
    */
   private Map map;

   /**
    * Documentaci�.
    */
   private Set set;

   /**
    * Documentaci�.
    */
   private SortedSet sortedSet;

   /**
    * Documentaci�.
    */
   private TestBean[] array;

   /**
    * Creates a new IndexedTestBean object.
    */
   public IndexedTestBean() {
      this(true);
   }

   /**
    * Creates a new IndexedTestBean object.
    *
    * @param populate DOCUMENT ME.
    */
   public IndexedTestBean(boolean populate) {
      if (populate) {
         populate();
      }
   }

   /**
    * Documentaci�.
    */
   public void populate() {
      TestBean tb0 = new TestBean("name0", 0);
      TestBean tb1 = new TestBean("name1", 0);
      TestBean tb2 = new TestBean("name2", 0);
      TestBean tb3 = new TestBean("name3", 0);
      TestBean tb4 = new TestBean("name4", 0);
      TestBean tb5 = new TestBean("name5", 0);
      TestBean tb6 = new TestBean("name6", 0);
      TestBean tb7 = new TestBean("name7", 0);
      TestBean tbX = new TestBean("nameX", 0);
      TestBean tbY = new TestBean("nameY", 0);
      this.array = new TestBean[] { tb0, tb1 };
      this.list = new ArrayList();
      this.list.add(tb2);
      this.list.add(tb3);
      this.set = new TreeSet();
      this.set.add(tb6);
      this.set.add(tb7);
      this.map = new HashMap();
      this.map.put("key1", tb4);
      this.map.put("key2", tb5);
      this.map.put("key.3", tb5);

      List list = new ArrayList();
      list.add(tbX);
      list.add(tbY);
      this.map.put("key4", list);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public TestBean[] getArray() {
      return array;
   }

   /**
    * Documentaci�.
    *
    * @param array Documentaci�
    */
   public void setArray(TestBean[] array) {
      this.array = array;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List getList() {
      return list;
   }

   /**
    * Documentaci�.
    *
    * @param list Documentaci�
    */
   public void setList(List list) {
      this.list = list;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public SortedSet getSortedSet() {
      return sortedSet;
   }

   /**
    * Documentaci�.
    *
    * @param sortedSet Documentaci�
    */
   public void setSortedSet(SortedSet sortedSet) {
      this.sortedSet = sortedSet;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Set getSet() {
      return set;
   }

   /**
    * Documentaci�.
    *
    * @param set Documentaci�
    */
   public void setSet(Set set) {
      this.set = set;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Collection getCollection() {
      return collection;
   }

   /**
    * Documentaci�.
    *
    * @param collection Documentaci�
    */
   public void setCollection(Collection collection) {
      this.collection = collection;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getMap() {
      return map;
   }

   /**
    * Documentaci�.
    *
    * @param map Documentaci�
    */
   public void setMap(Map map) {
      this.map = map;
   }
}
