/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.model.dao;

import net.gencat.ctti.canigo.services.security.acegi.testcases.WithinSpringContainerDAOTestCase;
import net.gencat.ctti.canigo.services.security.fixtures.OracleDatabaseFixture;
import net.gencat.ctti.canigo.services.security.fixtures.SecurityServiceTestScenariosFixtures;
import net.gencat.ctti.canigo.services.security.fixtures.SecurityTestScenario;
import net.gencat.ctti.canigo.services.security.model.PartyGroup;
import net.gencat.ctti.canigo.services.security.model.Role;
import net.gencat.ctti.canigo.services.security.model.UserLogin;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class UserLoginDAOTest extends WithinSpringContainerDAOTestCase {
   /**
    * Documentaci�.
    */
   protected UserLoginDAO userLoginDAO;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void onSetUp() throws Exception {
      super.onSetUp();

      super.testScenario = SecurityServiceTestScenariosFixtures.getAdminUserScenario();

      super.expectedLoadedObject = this.testScenario.getUserLogin();
   }

   /**
    * Documentaci�.
    */
   public void testLoad() {
      UserLogin user = (UserLogin) this.userLoginDAO.load(UserLogin.class,
            this.testScenario.getUserLogin().getUserName());
      assertNotNull(user);
   }

   /**
    * Documentaci�.
    */
   public void testUpdate() {
      UserLogin user = this.testScenario.getUserLogin();
      user.setPassword("new password");
      this.userLoginDAO.saveOrUpdate(user);
      assertEquals(expectedLoadedObject, user);
   }

   /**
    * Documentaci�.
    */
   public void testSave() {
      UserLogin newObject = new UserLogin();
      newObject.setUserName("new");
      newObject.setPassword("a password");
      newObject.addRole(this.testScenario.getUserLogin().getFirstRole());

      this.userLoginDAO.saveOrUpdate(newObject);

      // TODO In order to test this part, we need to commit the transaction !!! Use code from
      // Spring class AbstractTransactionalSpringContextTests

      //        assertNotNull(newObject.getUserName());
      //        UserLogin objectLoadedFromDb = (UserLogin) this.userLoginDAO.load(UserLogin.class, newObject.getUserName());
      //        assertEquals(newObject, objectLoadedFromDb);
      //        assertNotNull(objectLoadedFromDb.getGroup());
      //        assertNotNull(objectLoadedFromDb.getRoles());
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testFindByUserName() throws Exception {
      UserLogin user = this.testScenario.getUserLogin();
      assertEquals(user.getUserName(),
         this.userLoginDAO.findByUserName(user.getUserName()).getUserName());
   }
}
