/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers.dao;

import java.util.Set;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.security.acegi.testcases.WithinSpringContainerDAOTestCase;
import net.gencat.ctti.canigo.services.security.fixtures.SecurityServiceTestScenariosFixtures;
import net.gencat.ctti.canigo.services.security.fixtures.SecurityTestScenario;
import net.gencat.ctti.canigo.services.security.model.Role;
import net.gencat.ctti.canigo.services.security.model.dao.UserLoginDAO;
import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.providers.dao.UsernameNotFoundException;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class AuthoritiesDAOTest extends WithinSpringContainerDAOTestCase {
   /**
    * Documentaci�.
    */
   protected AuthoritiesDAO dao;

   /**
    * Documentaci�.
    */
   protected UserLoginDAO userLoginDAO;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void onSetUp() throws Exception {
      super.onSetUp();

      this.dao = new AuthoritiesHibernateImplDAO(this.userLoginDAO);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testScenarioUserAdmin_RoleAdmin() throws Exception {
      assertDAOreturnsExpectedRoles(SecurityServiceTestScenariosFixtures.getAdminUserScenario());
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testCheckDaoOnlyReturnsGrantedAuthoritiesGrantedToUser()
      throws Exception {
      assertDAOreturnsExpectedRoles(SecurityServiceTestScenariosFixtures.getHierarchyOfRolesScenario());
   }

   /**
    * Documentaci�.
    *
    * @param testScenario Documentaci�
    */
   private void assertDAOreturnsExpectedRoles(SecurityTestScenario testScenario) {
      GrantedAuthority[] authorities = dao.getAuthorities(testScenario.getUserLogin()
                                                                      .getUserName());
      Set expectedRoles = testScenario.getUserLogin().getAllRoles();

      assertEquals(expectedRoles.size(), authorities.length);

      //        
      //        for (int i = 0; i < expectedRoles.length; i++) {
      //            assertEquals(expectedRoles[i].getName(), authorities[i].getAuthority());
      //        }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testLookupFailsWithWrongUsername() throws Exception {
      try {
         dao.getAuthorities("UNKNOWN_USER");
         fail("Should have thrown UsernameNotFoundException");
      } catch (UsernameNotFoundException expected) {
         assertTrue(true);
      }
   }
}
