/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.fixtures;

import javax.sql.DataSource;

import net.gencat.ctti.canigo.services.security.model.PartyGroup;
import net.gencat.ctti.canigo.services.security.model.Role;
import net.gencat.ctti.canigo.services.security.model.UserLogin;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class SecurityServiceTestScenariosFixtures {
   /**
    * Documentaci�.
    */
   private static SecurityTestScenario user1WithRole1AndRole2Scenario;

   /**
    * Documentaci�.
    */
   private static SecurityTestScenario saceScenario;

   /**
    * Documentaci�.
    */
   private static SecurityTestScenario ldapScenario;

   /**
    * Documentaci�.
    */
   private static SecurityTestScenario adminUserScenario;

   /**
    * Documentaci�.
    */
   private static SecurityTestScenario hierarchyOfRolesScenario;

   /**
    * Documentaci�.
    */
   private static SecurityTestScenario userWithGroupWithRolesScenario;

   /**
    * Documentaci�.
    */
   private static SecurityTestScenario microsoftLDAPScenario;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public static DataSource getDataSource() {
      return OracleDatabaseFixture.getDataSource();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public static SecurityTestScenario getUser1_with_Role1_and_Role2_Scenario() {
      if (user1WithRole1AndRole2Scenario == null) {
         user1WithRole1AndRole2Scenario = SecurityTestScenario.createTestScenario("user1",
               "ROLE1", "ROLE2");
      }

      return user1WithRole1AndRole2Scenario;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public static SecurityTestScenario getLDAPScenario() {
      if (ldapScenario == null) {
         ldapScenario = new SecurityTestScenario();

         UserLogin user = new UserLogin();
         user.setUserName("gestoruser");
         user.setPassword("gestorpassword");
         user.addRole(new Role("ROLE_ADMIN"));

         ldapScenario.setUserLogin(user);
      }

      return ldapScenario;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public static SecurityTestScenario getSaceScenario() {
      if (saceScenario == null) {
         saceScenario = SecurityTestScenario.createTestScenario("USER_PROVES1",
               "ROLE1", "ROLE2");
      }

      return saceScenario;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public static SecurityTestScenario getAdminUserScenario() {
      if (adminUserScenario == null) {
         adminUserScenario = SecurityTestScenario.createTestScenario("usuario_admin1",
               "ROLE_ADMIN");
         adminUserScenario.getUserLogin().setPassword("password1");

         Role parentRole = new Role();
         parentRole.setId(new Integer(3));
         parentRole.setName("ROLE_BASE");

         Role role = adminUserScenario.getUserLogin().getFirstRole();
         role.setId(new Integer(1));
         role.setParent(parentRole);

         PartyGroup adminGroup = new PartyGroup(1, "GROUP ADMIN");
         adminUserScenario.getUserLogin().setGroup(adminGroup);
      }

      return adminUserScenario;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public static SecurityTestScenario getHierarchyOfRolesScenario() {
      if (hierarchyOfRolesScenario == null) {
         Role roleGrandParent = new Role(4, "ROLE_GRAND_PARENT");
         Role roleParent = new Role(5, "ROLE_PARENT", roleGrandParent);
         Role roleSon = new Role(6, "ROLE_SON", roleParent);

         UserLogin user = new UserLogin("USER_ROLE_HIERARCHY");
         user.addRole(roleSon);

         hierarchyOfRolesScenario = new SecurityTestScenario();
         hierarchyOfRolesScenario.setUserLogin(user);
      }

      return hierarchyOfRolesScenario;
   }

   //    INSERT INTO PARTY_GROUP (PARTY_ID, GROUP_NAME) VALUES (3, 'TEST GROUP WITH ROLE');
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public static SecurityTestScenario getUserWithGroupWithRolesScenario() {
      if (userWithGroupWithRolesScenario == null) {
         UserLogin user = new UserLogin("USER WITH GROUP WITH ROLE");
         user.setPassword("password");

         PartyGroup parentGroup = new PartyGroup(3, "PARENT GROUP");

         PartyGroup group = new PartyGroup(4, "TEST GROUP WITH ROLE");
         group.setParent(parentGroup);

         Role role = new Role(7, "ROLE_TEST_GROUP_WITH_ROLE");
         group.addRole(role);
         user.setGroup(group);

         userWithGroupWithRolesScenario = new SecurityTestScenario();
         userWithGroupWithRolesScenario.setUserLogin(user);
      }

      return userWithGroupWithRolesScenario;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public static SecurityTestScenario getMicrosoftLDAPScenario() {
      if (microsoftLDAPScenario == null) {
         microsoftLDAPScenario = new SecurityTestScenario();

         UserLogin user = new UserLogin();
         user.setUserName("acegi_user");
         user.setPassword("acegi_user");
         user.addRole(new Role("ROLE_ADMIN"));

         microsoftLDAPScenario.setUserLogin(user);
      }

      return microsoftLDAPScenario;
   }
}
