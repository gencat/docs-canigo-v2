/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.afterinvocation;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.security.business.DomainObject;
import net.gencat.ctti.canigo.services.tests.mock.aop.MockAclManager;
import net.gencat.ctti.canigo.services.tests.mock.aop.MockAclObjectIdentity;
import net.gencat.ctti.canigo.services.tests.mock.aop.MockMethodInvocation;
import net.mlw.vlh.DefaultListBackedValueList;
import net.mlw.vlh.ValueList;
import net.sf.acegisecurity.AuthorizationServiceException;
import net.sf.acegisecurity.ConfigAttributeDefinition;
import net.sf.acegisecurity.SecurityConfig;
import net.sf.acegisecurity.acl.AclEntry;
import net.sf.acegisecurity.acl.AclManager;
import net.sf.acegisecurity.acl.basic.SimpleAclEntry;
import net.sf.acegisecurity.providers.UsernamePasswordAuthenticationToken;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class ValueListFilteringProviderTest extends TestCase {
   /**
    * Documentaci�.
    */
   protected ValueListFilteringProvider provider;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void setUp() throws Exception {
      this.provider = new ValueListFilteringProvider();
      this.provider.addFilterForBusinessClass(String.class);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testCorrectOperationWhenPrincipalIsAuthorised()
      throws Exception {
      // Create an AclManager
      AclManager aclManager = new MockAclManager("belmont", "marissa",
            new AclEntry[] {
               new MockAclEntry(),
               new SimpleAclEntry("marissa", new MockAclObjectIdentity(), null,
                  SimpleAclEntry.ADMINISTRATION),
               new SimpleAclEntry("marissa", new MockAclObjectIdentity(), null,
                  SimpleAclEntry.READ),
               new SimpleAclEntry("marissa", new MockAclObjectIdentity(), null,
                  SimpleAclEntry.DELETE)
            });

      provider.setAclManager(aclManager);
      assertEquals(aclManager, provider.getAclManager());
      provider.afterPropertiesSet();

      // Create a Collection containing many items, which only "belmont"
      // should remain in after filtering by provider
      List list = new Vector();
      list.add("sydney");
      list.add("melbourne");
      list.add("belmont");
      list.add("brisbane");

      ValueList valueList = new DefaultListBackedValueList(list);

      // Create the Authentication and Config Attribs we'll be presenting
      UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken("marissa",
            "NOT_USED");
      ConfigAttributeDefinition attr = new ConfigAttributeDefinition();
      attr.addConfigAttribute(new SecurityConfig("AFTER_ACL_COLLECTION_READ"));

      // Filter
      List filteredList = ((ValueList) provider.decide(auth,
            new MockMethodInvocation(), attr, valueList)).getList();

      assertEquals(1, filteredList.size());
      assertEquals("belmont", filteredList.get(0));
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testDetectsIfReturnedObjectIsNotACollection()
      throws Exception {
      // Create an AclManager
      AclManager aclManager = new MockAclManager("belmont", "marissa",
            new AclEntry[] {
               new SimpleAclEntry("marissa", new MockAclObjectIdentity(), null,
                  SimpleAclEntry.ADMINISTRATION),
               new SimpleAclEntry("marissa", new MockAclObjectIdentity(), null,
                  SimpleAclEntry.READ),
               new SimpleAclEntry("marissa", new MockAclObjectIdentity(), null,
                  SimpleAclEntry.DELETE), new MockAclEntry()
            });

      provider.setAclManager(aclManager);
      provider.afterPropertiesSet();

      // Create the Authentication and Config Attribs we'll be presenting
      UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken("marissa",
            "NOT_USED");
      ConfigAttributeDefinition attr = new ConfigAttributeDefinition();
      attr.addConfigAttribute(new SecurityConfig("AFTER_ACL_COLLECTION_READ"));

      // Filter
      try {
         provider.decide(auth, new MockMethodInvocation(), attr,
            new String("RETURN_OBJECT_NOT_COLLECTION"));
         fail("Should have thrown AuthorizationServiceException");
      } catch (AuthorizationServiceException expected) {
         assertTrue(true);
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testGrantsAccessIfReturnedObjectIsNull()
      throws Exception {
      // Create an AclManager
      AclManager aclManager = new MockAclManager("belmont", "marissa",
            new AclEntry[] {
               new SimpleAclEntry("marissa", new MockAclObjectIdentity(), null,
                  SimpleAclEntry.ADMINISTRATION),
               new SimpleAclEntry("marissa", new MockAclObjectIdentity(), null,
                  SimpleAclEntry.READ),
               new SimpleAclEntry("marissa", new MockAclObjectIdentity(), null,
                  SimpleAclEntry.DELETE), new MockAclEntry()
            });

      provider.setAclManager(aclManager);
      provider.afterPropertiesSet();

      // Create the Authentication and Config Attribs we'll be presenting
      UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken("marissa",
            "NOT_USED");
      ConfigAttributeDefinition attr = new ConfigAttributeDefinition();
      attr.addConfigAttribute(new SecurityConfig("AFTER_ACL_COLLECTION_READ"));

      // Filter
      List filteredList = (List) provider.decide(auth,
            new MockMethodInvocation(), attr, null);

      assertNull(filteredList);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testRespectsModificationsToProcessConfigAttribute()
      throws Exception {
      // Create an AclManager
      AclManager aclManager = new MockAclManager("sydney", "marissa",
            new AclEntry[] {
               new SimpleAclEntry("marissa", new MockAclObjectIdentity(), null,
                  SimpleAclEntry.READ), new MockAclEntry()
            });

      provider.setAclManager(aclManager);
      assertEquals("AFTER_ACL_COLLECTION_READ",
         provider.getProcessConfigAttribute());
      provider.setProcessConfigAttribute("AFTER_ACL_COLLECTION_ADMIN");
      assertEquals("AFTER_ACL_COLLECTION_ADMIN",
         provider.getProcessConfigAttribute());
      provider.afterPropertiesSet();

      // Create a Collection containing many items, which only "sydney"
      // should remain in after filtering by provider
      List list = new Vector();
      list.add("sydney");
      list.add("melbourne");
      list.add("belmont");
      list.add("brisbane");

      // Create the Authentication and Config Attribs we'll be presenting
      UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken("marissa",
            "NOT_USED");
      ConfigAttributeDefinition attr = new ConfigAttributeDefinition();
      attr.addConfigAttribute(new SecurityConfig("AFTER_ACL_COLLECTION_READ"));

      // As no matching config attrib, ensure provider doesn't change list
      assertEquals(4,
         ((ValueList) provider
          .decide(auth, new MockMethodInvocation(), attr,
            new DefaultListBackedValueList(list))).getList().size());

      // Filter, this time with the conf attrib provider setup to answer
      attr.addConfigAttribute(new SecurityConfig("AFTER_ACL_COLLECTION_ADMIN"));

      List filteredList = ((ValueList) provider.decide(auth,
            new MockMethodInvocation(), attr,
            new DefaultListBackedValueList(list))).getList();

      assertEquals(1, filteredList.size());
      assertEquals("sydney", filteredList.get(0));
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testRespectsModificationsToRequirePermissions()
      throws Exception {
      // Create an AclManager
      AclManager aclManager = new MockAclManager("sydney", "marissa",
            new AclEntry[] {
               new SimpleAclEntry("marissa", new MockAclObjectIdentity(), null,
                  SimpleAclEntry.ADMINISTRATION), new MockAclEntry()
            });

      provider.setAclManager(aclManager);
      assertEquals(SimpleAclEntry.READ, provider.getRequirePermission()[0]);
      provider.setRequirePermission(new int[] { SimpleAclEntry.ADMINISTRATION });
      assertEquals(SimpleAclEntry.ADMINISTRATION,
         provider.getRequirePermission()[0]);
      provider.afterPropertiesSet();

      // Create a Collection containing many items, which only "sydney"
      // should remain in after filtering by provider
      List list = new Vector();
      list.add("sydney");
      list.add("melbourne");
      list.add("belmont");
      list.add("brisbane");

      // Create the Authentication and Config Attribs we'll be presenting
      UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken("marissa",
            "NOT_USED");
      ConfigAttributeDefinition attr = new ConfigAttributeDefinition();
      attr.addConfigAttribute(new SecurityConfig("AFTER_ACL_COLLECTION_READ"));

      // Filter
      List filteredList = ((ValueList) provider.decide(auth,
            new MockMethodInvocation(), attr,
            new DefaultListBackedValueList(list))).getList();

      assertEquals(1, filteredList.size());
      assertEquals("sydney", filteredList.get(0));
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testStartupDetectsMissingAclManager() throws Exception {
      try {
         provider.afterPropertiesSet();
         fail("Should have thrown IllegalArgumentException");
      } catch (IllegalArgumentException expected) {
         assertEquals("An aclManager is mandatory", expected.getMessage());
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testStartupDetectsMissingProcessConfigAttribute()
      throws Exception {
      AclManager aclManager = new MockAclManager("sydney", "marissa",
            new AclEntry[] {
               new SimpleAclEntry("marissa", new MockAclObjectIdentity(), null,
                  SimpleAclEntry.ADMINISTRATION), new MockAclEntry()
            });
      provider.setAclManager(aclManager);

      provider.setProcessConfigAttribute(null);

      try {
         provider.afterPropertiesSet();
         fail("Should have thrown IllegalArgumentException");
      } catch (IllegalArgumentException expected) {
         assertEquals("A processConfigAttribute is mandatory",
            expected.getMessage());
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testStartupDetectsMissingRequirePermission()
      throws Exception {
      AclManager aclManager = new MockAclManager("sydney", "marissa",
            new AclEntry[] {
               new SimpleAclEntry("marissa", new MockAclObjectIdentity(), null,
                  SimpleAclEntry.ADMINISTRATION), new MockAclEntry()
            });
      provider.setAclManager(aclManager);

      provider.setRequirePermission(null);

      try {
         provider.afterPropertiesSet();
         fail("Should have thrown IllegalArgumentException");
      } catch (IllegalArgumentException expected) {
         assertEquals("One or more requirePermission entries is mandatory",
            expected.getMessage());
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testSetAclsClassList() throws Exception {
      List classesList = new ArrayList();
      classesList.add(
         "net.gencat.ctti.canigo.services.security.business.DomainObject");

      provider.setAclsClassesList(classesList);

      assertEquals(DomainObject.class, provider.getAclsClassesList().get(0));
   }

   // ~ Inner Classes
   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.4 $
     */
   private class MockAclEntry implements AclEntry {
      // just so AclTag iterates some different types of AclEntrys
   }
}
