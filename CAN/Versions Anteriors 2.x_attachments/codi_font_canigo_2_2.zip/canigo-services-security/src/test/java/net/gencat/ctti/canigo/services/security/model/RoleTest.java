/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.model;

import java.util.Iterator;
import java.util.Set;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.security.fixtures.SecurityServiceTestScenariosFixtures;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class RoleTest extends TestCase {
   /**
    * Documentaci�.
    */
   protected Role father;

   // TODO Refactor to a test fixture
   /**
    * Documentaci�.
    */
   protected Role grandFather;

   /**
    * Documentaci�.
    */
   protected Role son;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void setUp() throws Exception {
      grandFather = new Role(1, "grandFather");

      father = new Role(2, "father");
      father.setParent(grandFather);

      son = new Role(3, "son");
      son.setParent(father);
   }

   /**
    * Documentaci�.
    */
   public void testSetParentWithSelf() {
      Role role = new Role(1, "ROLE_SELF");

      try {
         role.setParent(role);
         fail("Should have thrown an " +
            IllegalArgumentException.class.getName());
      } catch (IllegalArgumentException expected) {
         assertTrue(true);
      }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testGetRecursiveParentRoles() throws Exception {
      Set parentRoles = son.getRecursiveParentRoles();
      assertEquals(2, parentRoles.size());

      Iterator iter = parentRoles.iterator();
      assertEquals(son.getParent().getParent(), iter.next());
      assertEquals(son.getParent(), iter.next());
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testCompareTo() throws Exception {
      assertEquals(0, father.compareTo(father));
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testIsAParentOf() throws Exception {
      assertTrue(father.isAParentOf(son));
      assertTrue(grandFather.isAParentOf(son));

      assertFalse(son.isAParentOf(father));
      assertFalse(son.isAParentOf(grandFather));
      assertFalse(father.isAParentOf(grandFather));
   }

   /**
    * Documentaci�.
    */
   public void testSetParentOneOfHisSonOrGrandSon() {
      //        try {
      //            father.setParent(son);
      //            fail("Should have thrown an " + IllegalArgumentException.class.getName());
      //        } catch (IllegalArgumentException expected) {
      //            assertTrue(true);
      //        }
      //
      //        try {
      //            grandFather.setParent(son);
      //            fail("Should have thrown an " + IllegalArgumentException.class.getName());
      //        } catch (IllegalArgumentException expected) {
      //            assertTrue(true);
      //        }
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testGet() throws Exception {
   }
}
