/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.model.dao;

import net.gencat.ctti.canigo.services.security.acegi.testcases.WithinSpringContainerDAOTestCase;
import net.gencat.ctti.canigo.services.security.fixtures.SecurityServiceTestScenariosFixtures;
import net.gencat.ctti.canigo.services.security.model.PartyGroup;
import net.gencat.ctti.canigo.services.security.model.Role;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class PartyGroupDAOTest extends WithinSpringContainerDAOTestCase {
   /**
    * Documentaci�.
    */
   protected PartyGroupDAO partyGroupDAO;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void onSetUp() throws Exception {
      super.onSetUp();
      super.testScenario = SecurityServiceTestScenariosFixtures.getUserWithGroupWithRolesScenario();
   }

   /**
    * Documentaci�.
    */
   public void testLoad() {
      PartyGroup group = this.testScenario.getUserLogin().getGroup();
      PartyGroup loadedOject = (PartyGroup) this.partyGroupDAO.load(group.getId());
      assertEquals(group, loadedOject);
      assertNotNull(loadedOject.getRoles());
      assertNotNull(loadedOject.getParent());
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testUpdate() throws Exception {
      PartyGroup vo = this.testScenario.getUserLogin().getGroup();
      vo.setName("a new name");
      vo.setRoles(null);
      this.partyGroupDAO.saveOrUpdate(vo);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testInsert() throws Exception {
      PartyGroup vo = new PartyGroup();
      vo.setName("a new name");
      // TODO a bit dodgy, should test isolated from other data
      vo.addRole(SecurityServiceTestScenariosFixtures.getAdminUserScenario()
                                                     .getUserLogin()
                                                     .getFirstRole());
      this.partyGroupDAO.saveOrUpdate(vo);
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testFindByName() throws Exception {
      PartyGroup vo = new PartyGroup();
      vo.setName("a new name");
      // TODO a bit dodgy, should test isolated from other data
      vo.addRole(SecurityServiceTestScenariosFixtures.getAdminUserScenario()
                                                     .getUserLogin()
                                                     .getFirstRole());
      this.partyGroupDAO.saveOrUpdate(vo);
   }
}
