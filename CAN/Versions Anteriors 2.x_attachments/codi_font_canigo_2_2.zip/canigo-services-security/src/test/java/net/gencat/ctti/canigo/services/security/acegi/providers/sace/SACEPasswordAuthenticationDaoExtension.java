/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers.sace;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import net.gencat.ctti.canigo.services.security.acegi.providers.dao.AuthoritiesDAO;
import net.gencat.ctti.canigo.services.security.acegi.providers.sace.enums.SACEReturnedCode;
import net.gencat.ctti.canigo.services.security.acegi.providers.sace.enums.SACEUserNameFormatEnum;
import net.sf.acegisecurity.AuthenticationServiceException;
import net.sf.acegisecurity.BadCredentialsException;
import net.sf.acegisecurity.GrantedAuthority;
import net.sf.acegisecurity.UserDetails;
import net.sf.acegisecurity.providers.dao.User;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.dao.DataAccessException;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class SACEPasswordAuthenticationDaoExtension
   extends SACEPasswordAuthenticationDao {
   /**
    * Documentaci�.
    */
   private static final String UTF_8 = "UTF-8";

   /**
    * Documentaci�.
    */
   private AuthoritiesDAO authoritiesDAO;

   /**
    * Documentaci�.
    */
   private FileOutputStream outLog = null;

   /**
    * Documentaci�.
    */
   private SACEUserNameFormatEnum format;

   /**
    * Documentaci�.
    */
   private SACEXMLConverter xmlConverter;

   /**
    * Documentaci�.
    */
   private URL urlSACEServer;

   /**
    * Creates a new SACEPasswordAuthenticationDaoExtension object.
    */
   public SACEPasswordAuthenticationDaoExtension() {
      this.xmlConverter = new SACEXMLConverter();

      // Sin lo siguiente daba: SSLHandshakeException: No trusted certificate found
      // Create a trust manager that does not validate certificate chains (this will be done only once)
      TrustManager[] trustAllCerts = new TrustManager[] {
            new X509TrustManager() {
                  public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                     return null;
                  }

                  public void checkClientTrusted(
                     java.security.cert.X509Certificate[] certs, String authType) {
                  }

                  public void checkServerTrusted(
                     java.security.cert.X509Certificate[] certs, String authType) {
                  }
               }
         };

      // Install the all-trusting trust manager
      try {
         System.setProperty("java.protocol.handler.pkgs",
            "com.ibm.net.ssl.internal.www.protocol");

         outLog = new FileOutputStream("D:\\logSace_" +
               System.currentTimeMillis() + ".txt");

         SSLContext sc = SSLContext.getInstance("SSL");
         sc.init(null, trustAllCerts, new java.security.SecureRandom());
         HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
      } catch (NoSuchAlgorithmException e) {
         throw new AuthenticationServiceException("SSL Certificate problem", e);
      } catch (KeyManagementException e) {
         throw new AuthenticationServiceException("SSL Certificate problem", e);
      } catch (Exception e) {
         writeLog(
            "******* SACEPasswordAuthenticationDao --> Pete en el constructor: " +
            e.getMessage());
         writeException(e);
      }
   }

   /**
    * Creates a new SACEPasswordAuthenticationDaoExtension object.
    *
    * @param param DOCUMENT ME.
    */
   public SACEPasswordAuthenticationDaoExtension(String param) {
      this.xmlConverter = new SACEXMLConverter();

      // Sin lo siguiente daba: SSLHandshakeException: No trusted certificate found
      // Create a trust manager that does not validate certificate chains (this will be done only once)
      TrustManager[] trustAllCerts = new TrustManager[] {
            new X509TrustManager() {
                  public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                     return null;
                  }

                  public void checkClientTrusted(
                     java.security.cert.X509Certificate[] certs, String authType) {
                  }

                  public void checkServerTrusted(
                     java.security.cert.X509Certificate[] certs, String authType) {
                  }
               }
         };

      KeyManager[] km = null;

      // Install the all-trusting trust manager
      try {
         //Nou per a fer proves
         //System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
         //Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
         System.setProperty("java.protocol.handler.pkgs",
            "com.ibm.net.ssl.internal.www.protocol");

         outLog = new FileOutputStream("D:\\logSace_" +
               System.currentTimeMillis() + ".txt");

         //SSLContext sc = SSLContext.getInstance("SSL");
         SSLContext sc = SSLContext.getInstance("SSL", "SunJSSE");
         //sc.init(null, trustAllCerts, new java.security.SecureRandom());                        
         sc.init(km, trustAllCerts, new java.security.SecureRandom());
         HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
      } catch (NoSuchAlgorithmException e) {
         writeException(e);
         throw new AuthenticationServiceException("SSL Certificate problem", e);
      } catch (KeyManagementException e) {
         writeException(e);
         throw new AuthenticationServiceException("SSL Certificate problem", e);
      } catch (Exception e) {
         writeLog(
            "******* SACEPasswordAuthenticationDao --> Pete en el constructor: " +
            e.getMessage());
         writeException(e);
      }
   }

   /**
    * Documentaci�.
    *
    * @param pMessage Documentaci�
    */
   public void writeLog(String pMessage) {
      try {
         pMessage = "\n" + pMessage;

         if (outLog != null) {
            outLog.write(pMessage.getBytes());
         }
      } catch (Exception e) {
      }

      ;
   }

   /**
    * Documentaci�.
    *
    * @param e Documentaci�
    */
   public void writeException(Exception e) {
      try {
         PrintWriter writer = new PrintWriter(outLog);
         writer.write(
            "\n ******* SACEPasswordAuthenticationDao --> stacktrace de la excepci�n " +
            e.getClass().getName() + "\n");
         e.printStackTrace(writer);
      } catch (Exception e1) {
      }

      ;
   }

   /**
    *
    * @param SACEHostName
    */
   public void setSACEHostName(String SACEHostName) {
      try {
         this.urlSACEServer = new URL(SACEHostName);
      } catch (MalformedURLException e) {
         throw new AuthenticationServiceException("Configuration problem, check the SACEHostName",
            e);
      }
   }

   /**
    * Documentaci�.
    *
    * @param authoritiesDAO Documentaci�
    */
   public void setAuthoritiesDAO(AuthoritiesDAO authoritiesDAO) {
      this.authoritiesDAO = authoritiesDAO;
   }

   /**
    * Documentaci�.
    *
    * @param format Documentaci�
    */
   public void setUserNameFormatEnum(SACEUserNameFormatEnum format) {
      this.format = format;
   }

   /**
    *
    */
   public UserDetails loadUserByUsernameAndPassword(String username,
      String password) throws DataAccessException, BadCredentialsException {
      if (GenericValidator.isBlankOrNull(username) ||
            GenericValidator.isBlankOrNull(password)) {
         throw new AuthenticationServiceException(
            "It should be the front-end application responsability to ensure that both user name and passwords are not empty!");
      }

      try {
         writeLog(
            "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword(" +
            username + "," + password + ")");

         String sProtocolHandler = System.getProperty(
               "java.protocol.handler.pkgs");
         writeLog(
            "******* SACEPasswordAuthenticationDao --> sProtocolHandler: " +
            sProtocolHandler);

         //HttpsURLConnection securedHttpURLConnection = (HttpsURLConnection) urlSACEServer.openConnection();
         java.net.URLConnection securedHttpURLConnection = (java.net.URLConnection) urlSACEServer.openConnection();
         writeLog(
            "******* SACEPasswordAuthenticationDao --> securedHttpURLConnection: " +
            securedHttpURLConnection.getClass().getName());

         writeLog(
            "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: connection open");

         // It is set to false by default, which prevent any output action (ProtocolException)
         securedHttpURLConnection.setDoOutput(true);

         OutputStreamWriter wout = new OutputStreamWriter(securedHttpURLConnection.getOutputStream(),
               UTF_8);

         writeLog(
            "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: after securedHttpURLConnection.getOutputStream()");

         wout.write(getEncodedQuerryString(username, password));
         wout.flush();
         wout.close();

         writeLog(
            "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: after write to out");

         // Process SACE output
         String xmlOutput = IOUtils.toString(securedHttpURLConnection.getInputStream());
         String returnedCode = StringUtils.substringBetween(xmlOutput,
               "<Resultat>", "</Resultat>");
         SACEReturnedCode.convertReturnedCode2AuthenticationServiceException(returnedCode);
         writeLog(
            "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: end !!");
      } catch (IOException e) {
         writeLog(
            "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: IOException --> " +
            e.getMessage());
         writeException(e);
         throw new AuthenticationServiceException("", e);
      } catch (DataAccessException d) {
         writeLog(
            "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: DataAccessException " +
            d.getMessage());
         writeException(d);
         throw d;
      } catch (BadCredentialsException b) {
         writeLog(
            "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: BadCredentialsException " +
            b.getMessage());
         writeException(b);
         throw b;
      } catch (Exception e) {
         writeLog(
            "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: PETE2 --> " +
            e.getMessage());
         writeException(e);
      }

      writeLog(
         "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: before authoritiesDAO.getAuthorities(" +
         username + ")");

      GrantedAuthority[] autorities = authoritiesDAO.getAuthorities(username);
      writeLog(
         "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: after authoritiesDAO.getAuthorities(" +
         username + ")");
      writeLog(
         "******* SACEPasswordAuthenticationDao --> loadUserByUsernameAndPassword: autorities --> ");

      for (int i = 0; i < autorities.length; i++) {
         writeLog("******* SACEPasswordAuthenticationDao --> " +
            autorities[i].getAuthority());
      }

      return new User(username, password, true, true, true, true, autorities);
   }

   /**
    *
    * @param user
    * @param password
    * @return
    */
   protected String getEncodedQuerryString(String user, String password) {
      try {
         SACEInputQueryVO inputVO = new SACEInputQueryVO(this.format, user,
               password);

         // SACE does not accept space or any ctrl character (!)
         String xml = StringUtils.deleteSpaces(this.xmlConverter.toXML(inputVO));

         return "XMLIn=" + URLEncoder.encode(xml, UTF_8);
      } catch (UnsupportedEncodingException e) {
         throw new AuthenticationServiceException("", e);
      }
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.5 $
     */
   class CustomX509TrustManager implements X509TrustManager {
      /**
       * Documentaci�.
       *
       * @param chain Documentaci�
       *
       * @return Documentaci�
       */
      public boolean isClientTrusted(X509Certificate[] chain) {
         return true;
      }

      /**
       * Documentaci�.
       *
       * @param chain Documentaci�
       *
       * @return Documentaci�
       */
      public boolean isServerTrusted(X509Certificate[] chain) {
         return true;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public java.security.cert.X509Certificate[] getAcceptedIssuers() {
         return null;
      }

      /**
       * Documentaci�.
       *
       * @param certs Documentaci�
       * @param authType Documentaci�
       */
      public void checkClientTrusted(
         java.security.cert.X509Certificate[] certs, String authType) {
      }

      /**
       * Documentaci�.
       *
       * @param certs Documentaci�
       * @param authType Documentaci�
       */
      public void checkServerTrusted(
         java.security.cert.X509Certificate[] certs, String authType) {
      }
   }
}
