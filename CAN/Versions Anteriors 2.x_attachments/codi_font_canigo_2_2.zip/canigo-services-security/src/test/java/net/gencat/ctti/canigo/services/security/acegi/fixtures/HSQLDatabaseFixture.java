/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.fixtures;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;


/**
 * Singleton which provides a populated database connection for all JDBC-related
 * unit tests.
 *
 */
public class HSQLDatabaseFixture extends DatabaseFixture {
   // ~ Static fields/initializers
   /**
    * Creates a new HSQLDatabaseFixture object.
    */
   private HSQLDatabaseFixture() {
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public static DataSource getDataSource() {
      if (dataSource == null) {
         setupDataSource();
      }

      return dataSource;
   }

   // ~ Methods
   /**
    * Documentaci�.
    */
   protected static void setupDataSource() {
      dataSource = new DriverManagerDataSource();
      dataSource.setDriverClassName("org.hsqldb.jdbcDriver");
      dataSource.setUrl("jdbc:hsqldb:mem:acegisecuritytest");
      dataSource.setUsername("sa");
      dataSource.setPassword("");

      JdbcTemplate template = new JdbcTemplate(dataSource);

      template.execute(
         "CREATE TABLE USERS(USERNAME VARCHAR_IGNORECASE(50) NOT NULL PRIMARY KEY,PASSWORD VARCHAR_IGNORECASE(50) NOT NULL,ENABLED BOOLEAN NOT NULL)");
      template.execute(
         "CREATE TABLE AUTHORITIES(USERNAME VARCHAR_IGNORECASE(50) NOT NULL,AUTHORITY VARCHAR_IGNORECASE(50) NOT NULL,CONSTRAINT FK_AUTHORITIES_USERS FOREIGN KEY(USERNAME) REFERENCES USERS(USERNAME))");
      template.execute(
         "CREATE UNIQUE INDEX IX_AUTH_USERNAME ON AUTHORITIES(USERNAME,AUTHORITY)");
      template.execute("SET IGNORECASE TRUE");
      template.execute("INSERT INTO USERS VALUES('dianne','emu',TRUE)");
      template.execute("INSERT INTO USERS VALUES('marissa','koala',TRUE)");
      template.execute("INSERT INTO USERS VALUES('peter','opal',FALSE)");
      template.execute("INSERT INTO USERS VALUES('scott','wombat',TRUE)");
      template.execute("INSERT INTO USERS VALUES('cooper','kookaburra',TRUE)");
      template.execute(
         "INSERT INTO AUTHORITIES VALUES('marissa','ROLE_TELLER')");
      template.execute(
         "INSERT INTO AUTHORITIES VALUES('marissa','ROLE_SUPERVISOR')");
      template.execute("INSERT INTO AUTHORITIES VALUES('dianne','ROLE_TELLER')");
      template.execute("INSERT INTO AUTHORITIES VALUES('scott','ROLE_TELLER')");
      template.execute("INSERT INTO AUTHORITIES VALUES('peter','ROLE_TELLER')");
   }
}
