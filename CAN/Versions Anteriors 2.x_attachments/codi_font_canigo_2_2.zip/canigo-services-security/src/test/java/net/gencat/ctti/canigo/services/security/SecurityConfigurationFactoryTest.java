/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.security.AuthorizationSecurityConfiguration;
import net.gencat.ctti.canigo.services.security.SecurityConfigurationFactory;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class SecurityConfigurationFactoryTest extends TestCase {
   /**
    * Documentaci�.
    */
   protected SecurityConfigurationFactory securityConfigurationFactory;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void setUp() throws Exception {
      AuthorizationSecurityConfiguration authorizationConfiguration = new AuthorizationSecurityConfiguration();
      authorizationConfiguration.addRole("ROLE_ADMIN");
      authorizationConfiguration.addRole("ROLE_USER");

      authorizationConfiguration.secureBusinessObjectsAfterPropertiesSet();

      this.securityConfigurationFactory = new SecurityConfigurationFactory();
      this.securityConfigurationFactory.setAuthorizationConfiguration(authorizationConfiguration);
   }

   /**
    * Documentaci�.
    */
   public void testGetSecureBusinessObjects() {
      assertEquals("net.mlw.vlh.web.mvc.ValueListHandlerHelper.getValueList=ROLE_ADMIN,ROLE_USER,AFTER_ACL_COLLECTION_READ",
         this.securityConfigurationFactory.getSecureBusinessObjects());
   }

   /**
    * Documentaci�.
    */
   public void testGetBeanNamesPatternForMethodInvocationAOP() {
      assertEquals("valueListHelper",
         this.securityConfigurationFactory.getBeanNamesPatternForMethodInvocationAOP()
                                          .get(0));
   }
}
