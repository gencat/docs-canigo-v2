/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.security.fixtures.SecurityServiceTestScenariosFixtures;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class UserLoginTest extends TestCase {
   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testGetAllRolesFromHierarchyOfRoles() throws Exception {
      Role roleGrandParent = new Role(4, "ROLE_GRAND_PARENT");
      Role roleParent = new Role(5, "ROLE_PARENT", roleGrandParent);
      Role roleSon = new Role(6, "ROLE_SON", roleParent);

      Role roleParentII = new Role(7, "ROLE_PARENT2");
      Role roleSonII = new Role(8, "ROLE_SON2", roleParentII);

      UserLogin user = new UserLogin("USER_ROLE_HIERARCHY");
      user.addRole(roleSon);
      user.addRole(roleSonII);

      List rolesList = new ArrayList(user.getAllRoles());
      assertEquals(5, rolesList.size());
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testHasRole() throws Exception {
      UserLogin user = SecurityServiceTestScenariosFixtures.getHierarchyOfRolesScenario()
                                                           .getUserLogin();
      assertFalse(user.hasRole(new Role()));
      assertFalse(user.hasRole(new Role(1, "pepe toto fritz bob")));

      assertTrue(user.hasRole(user.getFirstRole()));
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void testGetAllRolesWithGroups() throws Exception {
      Role roleGrandParent = new Role(4, "ROLE_GRAND_PARENT");
      Role roleParent = new Role(5, "ROLE_PARENT", roleGrandParent);
      Role roleSon = new Role(6, "ROLE_SON", roleParent);

      Role roleParentII = new Role(7, "ROLE_PARENT2");
      Role roleSonII = new Role(8, "ROLE_SON2", roleParentII);

      PartyGroup parentGroup = new PartyGroup(1, "PARENT GROUP");
      parentGroup.addRole(new Role(9, "ROLE OF PARENT GROUP"));

      PartyGroup group = new PartyGroup(2, "GROUP USER WITH GROUP");
      group.addRole(roleSon);
      group.addRole(roleSonII);
      group.setParent(parentGroup);

      UserLogin user = new UserLogin("USER_WITH_GROUP");
      user.setGroup(group);

      List rolesList = new ArrayList(user.getAllRoles());
      assertEquals(6, rolesList.size());
   }
}
