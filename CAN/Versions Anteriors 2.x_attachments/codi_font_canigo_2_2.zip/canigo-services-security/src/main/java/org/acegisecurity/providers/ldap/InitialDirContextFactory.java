/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package org.acegisecurity.providers.ldap;

import javax.naming.directory.DirContext;


/**
 * Access point for obtaining LDAP contexts.
 *
 * @see DefaultInitialDirContextFactory
 *
 * @author Luke Taylor
 * @version $Id: InitialDirContextFactory.java,v 1.5 2007/07/16 08:43:59 msabates Exp $
 */
public interface InitialDirContextFactory {
   /**
    * Provides an initial context without specific user information.
    */
   DirContext newInitialDirContext();

   /**
    * Provides an initial context by binding as a specific user.
    */
   DirContext newInitialDirContext(String userDn, String password);

   /**
    * @return The DN of the contexts returned by this factory.
    */
   String getRootDn();
}
