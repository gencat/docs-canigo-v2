/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package org.acegisecurity.providers.ldap.authenticator;

import java.util.Iterator;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;

import net.sf.acegisecurity.BadCredentialsException;

import org.acegisecurity.providers.ldap.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * An authenticator which binds as a user.
 *
 * @see AbstractLdapAuthenticator
 *
 * @author Luke Taylor
 * @version $Id: BindAuthenticator.java,v 1.5 2007/07/16 08:43:59 msabates Exp $
 */
public class BindAuthenticator extends AbstractLdapAuthenticator {
   /**
    * Documentaci�.
    */
   private static final Log logger = LogFactory.getLog(BindAuthenticator.class);

   /**
    * Creates a new BindAuthenticator object.
    *
    * @param initialDirContextFactory DOCUMENT ME.
    */
   public BindAuthenticator(InitialDirContextFactory initialDirContextFactory) {
      super(initialDirContextFactory);
   }

   /**
    * Documentaci�.
    *
    * @param username Documentaci�
    * @param password Documentaci�
    *
    * @return Documentaci�
    */
   public LdapUserInfo authenticate(String username, String password) {
      LdapUserInfo user = null;

      // If DN patterns are configured, try authenticating with them directly
      Iterator dns = getUserDns(username).iterator();

      while (dns.hasNext() && (user == null)) {
         user = bindWithDn((String) dns.next(), password);
      }

      // Otherwise use the configured locator to find the user
      // and authenticate with the returned DN.
      if ((user == null) && (getUserSearch() != null)) {
         LdapUserInfo userFromSearch = getUserSearch().searchForUser(username);
         user = bindWithDn(userFromSearch.getDn(), password);
      }

      if (user == null) {
         throw new BadCredentialsException(messages.getMessage(
               "BindAuthenticator.badCredentials", "Bad credentials"));
      }

      return user;
   }

   /**
    * Documentaci�.
    *
    * @param userDn Documentaci�
    * @param password Documentaci�
    *
    * @return Documentaci�
    */
   LdapUserInfo bindWithDn(String userDn, String password) {
      DirContext ctx = null;
      LdapUserInfo user = null;

      if (logger.isDebugEnabled()) {
         logger.debug("Attempting to bind with DN = " + userDn);
      }

      try {
         ctx = getInitialDirContextFactory()
                  .newInitialDirContext(userDn, password);

         Attributes attributes = loadAttributes(ctx, userDn);
         user = new LdapUserInfo(userDn, attributes);
      } catch (BadCredentialsException e) {
         // This will be thrown if an invalid user name is used and the method may
         // be called multiple times to try different names, so we trap the exception.
         if (logger.isDebugEnabled()) {
            logger.debug("Failed to bind as " + userDn + ": " + e.getCause());
         }
      } finally {
         LdapUtils.closeContext(ctx);
      }

      return user;
   }

   /**
    * Documentaci�.
    *
    * @param ctx Documentaci�
    * @param userDn Documentaci�
    *
    * @return Documentaci�
    */
   Attributes loadAttributes(DirContext ctx, String userDn) {
      try {
         return ctx.getAttributes(LdapUtils.getRelativeName(userDn, ctx),
            getUserAttributes());
      } catch (NamingException ne) {
         throw new LdapDataAccessException(messages.getMessage(
               "BindAuthenticator.failedToLoadAttributes",
               new String[] { userDn }, "Failed to load attributes for user {0}"),
            ne);
      }
   }
}
