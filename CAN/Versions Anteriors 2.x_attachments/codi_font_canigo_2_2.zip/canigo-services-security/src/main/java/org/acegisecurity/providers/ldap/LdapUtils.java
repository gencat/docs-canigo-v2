/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package org.acegisecurity.providers.ldap;

import java.io.UnsupportedEncodingException;

import java.net.URI;
import java.net.URISyntaxException;

import javax.naming.Context;
import javax.naming.NamingException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;


/**
 * LDAP Utility methods.
 *
 * @author Luke Taylor
 * @version $Id: LdapUtils.java,v 1.5 2007/07/16 08:43:59 msabates Exp $
 */
public class LdapUtils {
   /**
    * Documentaci�.
    */
   private static final Log logger = LogFactory.getLog(LdapUtils.class);

   /**
    * Documentaci�.
    *
    * @param ctx Documentaci�
    */
   public static void closeContext(Context ctx) {
      try {
         if (ctx != null) {
            ctx.close();
         }
      } catch (NamingException e) {
         logger.error("Failed to close context.", e);
      }
   }

   /**
    * Parses the supplied LDAP URL.
    * @param url the URL (e.g. <tt>ldap://monkeymachine:11389/dc=acegisecurity,dc=org</tt>).
    * @return the URI object created from the URL
    * @throws IllegalArgumentException if the URL is null, empty or the URI syntax is invalid.
    */
   public static URI parseLdapUrl(String url) {
      Assert.hasLength(url);

      try {
         return new URI(url);
      } catch (URISyntaxException e) {
         IllegalArgumentException iae = new IllegalArgumentException(
               "Unable to parse url: " + url);
         iae.initCause(e);
         throw iae;
      }
   }

   /**
    * Documentaci�.
    *
    * @param s Documentaci�
    *
    * @return Documentaci�
    */
   public static byte[] getUtf8Bytes(String s) {
      try {
         return s.getBytes("UTF-8");
      } catch (UnsupportedEncodingException e) {
         // Should be impossible since UTF-8 is required by all implementations
         throw new IllegalStateException(
            "Failed to convert string to UTF-8 bytes. Shouldn't be possible");
      }
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    *
    * @return Documentaci�
    */
   public static String escapeNameForFilter(String name) {
      // TODO: Implement escaping as defined in RFC 2254
      // Think this is probably not needed as filter args should be escaped automatically
      // by the search methods.
      return name;
   }

   /**
    * Obtains the part of a DN relative to a supplied base context.
    * <p>
    * If the DN is "cn=bob,ou=people,dc=acegisecurity,dc=org" and the base context
    * name is "ou=people,dc=acegisecurity,dc=org" it would return "cn=bob".
    * </p>
    *
    * @param fullDn the DN
    * @param baseCtx the context to work out the name relative to.
    * @return the
    * @throws NamingException any exceptions thrown by the context are propagated.
    */
   public static String getRelativeName(String fullDn, Context baseCtx)
      throws NamingException {
      String baseDn = baseCtx.getNameInNamespace();

      if (baseDn.length() == 0) {
         return fullDn;
      }

      if (baseDn.equals(fullDn)) {
         return "";
      }

      int index = fullDn.lastIndexOf(baseDn);

      Assert.isTrue(index > 0, "Context base DN is not contained in the full DN");

      // remove the base name and preceding comma.
      return fullDn.substring(0, index - 1);
   }
}
