/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package org.acegisecurity.userdetails;

import net.sf.acegisecurity.UserDetails;
import net.sf.acegisecurity.providers.dao.DaoAuthenticationProvider;
import net.sf.acegisecurity.providers.dao.UsernameNotFoundException;

import org.springframework.dao.DataAccessException;


/**
 * Defines an interface for implementations that wish to provide data access
 * services to the {@link DaoAuthenticationProvider}.
 *
 * <p>
 * The interface requires only one read-only method, which simplifies support
 * of new data access strategies.
 * </p>
 *
 * @author Ben Alex
 * @version $Id: UserDetailsService.java,v 1.2 2007/09/13 03:17:19 asancho Exp $
 */
public interface UserDetailsService {
   /**
    * Locates the user based on the username. In the actual implementation, the search may possibly be case
    * insensitive, or case insensitive depending on how the implementaion instance is configured. In this case, the
    * <code>UserDetails</code> object that comes back may have a username that is of a different case than what was
    * actually requested..
    *
    * @param username the username presented to the {@link DaoAuthenticationProvider}
    *
    * @return a fully populated user record (never <code>null</code>)
    *
    * @throws UsernameNotFoundException if the user could not be found or the user has no GrantedAuthority
    * @throws DataAccessException if user could not be found for a repository-specific reason
    */
   UserDetails loadUserByUsername(String username)
      throws UsernameNotFoundException, DataAccessException;
}
