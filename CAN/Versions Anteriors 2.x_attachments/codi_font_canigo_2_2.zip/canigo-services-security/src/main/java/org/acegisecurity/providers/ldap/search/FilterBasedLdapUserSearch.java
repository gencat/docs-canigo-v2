/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package org.acegisecurity.providers.ldap.search;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import net.sf.acegisecurity.BadCredentialsException;
import net.sf.acegisecurity.providers.dao.UsernameNotFoundException;

import org.acegisecurity.providers.ldap.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;


/**
 * LdapUserSearch implementation which uses an Ldap filter to locate the user.
 *
 * @author Robert Sanders
 * @author Luke Taylor
 * @version $Id: FilterBasedLdapUserSearch.java,v 1.5 2007/07/16 08:44:00 msabates Exp $
 */
public class FilterBasedLdapUserSearch implements LdapUserSearch {
   /**
    * Documentaci�.
    */
   private static final Log logger = LogFactory.getLog(FilterBasedLdapUserSearch.class);

   /**
    * Documentaci�.
    */
   private InitialDirContextFactory initialDirContextFactory;

   /**
    * Context name to search in, relative to the root DN of the configured
    * InitialDirContextFactory.
    */
   private String searchBase = "";

   /**
    * The filter expression used in the user search. This is an LDAP
    * search filter (as defined in 'RFC 2254') with optional arguments. See the documentation
    * for the <tt>search</tt> methods in {@link javax.naming.directory.DirContext DirContext}
    * for more information.
    * <p>
    * In this case, the username is the only parameter.
    * </p>
    * Possible examples are:
    * <ul>
    * <li>(uid={0}) - this would search for a username match on the uid attribute.</li>
    * </ul>
    * TODO: more examples.
    *
    */
   private String searchFilter;

   /**
    * Documentaci�.
    */
   private int searchScope = SearchControls.ONELEVEL_SCOPE;

   /**
    * The time (in milliseconds) which to wait before the search fails;
    * the default is zero, meaning forever.
    */
   private int searchTimeLimit = 0;

   /**
    * Creates a new FilterBasedLdapUserSearch object.
    *
    * @param searchBase DOCUMENT ME.
    * @param searchFilter DOCUMENT ME.
    * @param initialDirContextFactory DOCUMENT ME.
    */
   public FilterBasedLdapUserSearch(String searchBase, String searchFilter,
      InitialDirContextFactory initialDirContextFactory) {
      Assert.notNull(initialDirContextFactory,
         "initialDirContextFactory must not be null");
      Assert.notNull(searchFilter, "searchFilter must not be null.");
      Assert.notNull(searchBase,
         "searchBase must not be null (an empty string is acceptable).");

      this.searchFilter = searchFilter;
      this.initialDirContextFactory = initialDirContextFactory;
      this.searchBase = searchBase;

      if (searchBase.length() == 0) {
         logger.info(
            "SearchBase not set. Searches will be performed from the root: " +
            initialDirContextFactory.getRootDn());
      }
   }

   /**
    * Return the LdapUserInfo containing the user's information, or null if
    * no SearchResult is found.
    *
    * @param username the username to search for.
    */
   public LdapUserInfo searchForUser(String username) {
      DirContext ctx = initialDirContextFactory.newInitialDirContext();
      SearchControls ctls = new SearchControls();
      ctls.setTimeLimit(searchTimeLimit);
      ctls.setSearchScope(searchScope);

      if (logger.isDebugEnabled()) {
         logger.debug("Searching for user '" + username + "', in context " +
            ctx + ", with user search " + this.toString());
      }

      try {
         String[] args = new String[] { LdapUtils.escapeNameForFilter(username) };

         NamingEnumeration results = ctx.search(searchBase, searchFilter, args,
               ctls);

         if (!results.hasMore()) {
            throw new UsernameNotFoundException("User " + username +
               " not found in directory.");
         }

         SearchResult searchResult = (SearchResult) results.next();

         if (results.hasMore()) {
            throw new BadCredentialsException(
               "Expected a single user but search returned multiple results");
         }

         StringBuffer userDn = new StringBuffer(searchResult.getName());

         if (searchBase.length() > 0) {
            userDn.append(",");
            userDn.append(searchBase);
         }

         userDn.append(",");
         userDn.append(ctx.getNameInNamespace());

         return new LdapUserInfo(userDn.toString(), searchResult.getAttributes());
      } catch (NamingException ne) {
         throw new LdapDataAccessException("User Couldn't be found due to exception",
            ne);
      } finally {
         LdapUtils.closeContext(ctx);
      }
   }

   /**
    * Documentaci�.
    *
    * @param searchSubtree Documentaci�
    */
   public void setSearchSubtree(boolean searchSubtree) {
      //        this.searchSubtree = searchSubtree;
      this.searchScope = searchSubtree ? SearchControls.SUBTREE_SCOPE
                                       : SearchControls.ONELEVEL_SCOPE;
   }

   /**
    * Documentaci�.
    *
    * @param searchTimeLimit Documentaci�
    */
   public void setSearchTimeLimit(int searchTimeLimit) {
      this.searchTimeLimit = searchTimeLimit;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String toString() {
      StringBuffer sb = new StringBuffer();

      sb.append("[ searchFilter: '").append(searchFilter).append("', ");
      sb.append("searchBase: '").append(searchBase).append("'");
      sb.append(", scope: ")
        .append((searchScope == SearchControls.SUBTREE_SCOPE) ? "subtree"
                                                              : "single-level, ");
      sb.append("searchTimeLimit: ").append(searchTimeLimit).append(" ]");

      return sb.toString();
   }
}
