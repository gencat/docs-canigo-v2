/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package org.acegisecurity.providers.siteminder;

import net.sf.acegisecurity.AccountExpiredException;
import net.sf.acegisecurity.AuthenticationException;
import net.sf.acegisecurity.AuthenticationServiceException;
import net.sf.acegisecurity.CredentialsExpiredException;
import net.sf.acegisecurity.DisabledException;
import net.sf.acegisecurity.LockedException;
import net.sf.acegisecurity.UserDetails;
import net.sf.acegisecurity.providers.AuthenticationProvider;
import net.sf.acegisecurity.providers.UsernamePasswordAuthenticationToken;

import org.acegisecurity.providers.dao.AbstractUserDetailsAuthenticationProvider;
import org.acegisecurity.userdetails.UserDetailsService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.Ordered;
import org.springframework.dao.DataAccessException;
import org.springframework.util.Assert;


/**
 * An {@link AuthenticationProvider} implementation that retrieves user details from an {@link UserDetailsService}.
 *
 * @author Scott McCrory
 * @version $Id: SiteminderAuthenticationProvider.java,v 1.2 2007/09/13 03:17:19 asancho Exp $
 */
public class SiteminderAuthenticationProvider
   extends AbstractUserDetailsAuthenticationProvider implements Ordered {
   /**
    * Our logging object
    */
   private static final Log logger = LogFactory.getLog(SiteminderAuthenticationProvider.class);

   /**
    * Our user details service (which does the real work of checking the user against a back-end user store).
    */
   private UserDetailsService userDetailsService;

   /**
    * Documentaci�.
    */
   private int order = -1; // default: same as non-Ordered

   /**
    * @see org.acegisecurity.providers.dao.AbstractUserDetailsAuthenticationProvider#additionalAuthenticationChecks(org.acegisecurity.userdetails.UserDetails, org.acegisecurity.providers.UsernamePasswordAuthenticationToken)
    */
   protected void additionalAuthenticationChecks(final UserDetails user,
      final UsernamePasswordAuthenticationToken authentication)
      throws AuthenticationException {
      // No need for password authentication checks - we only expect one identifying string
      // from the HTTP Request header (as populated by Siteminder), but we do need to see if
      // the user's account is OK to let them in.
      if (!user.isEnabled()) {
         throw new DisabledException(messages.getMessage(
               "AbstractUserDetailsAuthenticationProvider.disabled",
               "Account disabled"));
      }

      if (!user.isAccountNonExpired()) {
         throw new AccountExpiredException(messages.getMessage(
               "AbstractUserDetailsAuthenticationProvider.expired",
               "Account expired"));
      }

      if (!user.isAccountNonLocked()) {
         throw new LockedException(messages.getMessage(
               "AbstractUserDetailsAuthenticationProvider.locked",
               "Account locked"));
      }

      if (!user.isCredentialsNonExpired()) {
         throw new CredentialsExpiredException(messages.getMessage(
               "AbstractUserDetailsAuthenticationProvider.credentialsExpired",
               "Credentials expired"));
      }
   }

   /**
    * @see org.acegisecurity.providers.dao.AbstractUserDetailsAuthenticationProvider#doAfterPropertiesSet()
    */
   protected void doAfterPropertiesSet() throws Exception {
      Assert.notNull(this.userDetailsService, "A UserDetailsService must be set");
   }

   /**
    * Return the user details service.
    * @return The user details service.
    */
   public UserDetailsService getUserDetailsService() {
      return userDetailsService;
   }

   /**
    * @see org.acegisecurity.providers.dao.AbstractUserDetailsAuthenticationProvider#retrieveUser(java.lang.String, org.acegisecurity.providers.UsernamePasswordAuthenticationToken)
    */
   protected final UserDetails retrieveUser(final String username,
      final UsernamePasswordAuthenticationToken authentication)
      throws AuthenticationException {
      UserDetails loadedUser;

      try {
         loadedUser = this.getUserDetailsService().loadUserByUsername(username);
      } catch (DataAccessException repositoryProblem) {
         throw new AuthenticationServiceException(repositoryProblem.getMessage(),
            repositoryProblem);
      }

      if (loadedUser == null) {
         throw new AuthenticationServiceException(
            "UserDetailsService returned null, which is an interface contract violation");
      }

      return loadedUser;
   }

   /**
    * Sets the user details service.
    * @param userDetailsService The user details service.
    */
   public void setUserDetailsService(
      final UserDetailsService userDetailsService) {
      this.userDetailsService = userDetailsService;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getOrder() {
      return order;
   }

   /**
    * Documentaci�.
    *
    * @param order Documentaci�
    */
   public void setOrder(int order) {
      this.order = order;
   }
}
