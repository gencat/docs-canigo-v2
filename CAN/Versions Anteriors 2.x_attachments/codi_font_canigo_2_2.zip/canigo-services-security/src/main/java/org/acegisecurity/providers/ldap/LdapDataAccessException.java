/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package org.acegisecurity.providers.ldap;

import net.sf.acegisecurity.AuthenticationServiceException;


/**
 * Used to wrap unexpected NamingExceptions while accessing the LDAP server
 * or for other LDAP-related data problems such as data we can't handle.
 *
 * @author Luke Taylor
 * @version $Id: LdapDataAccessException.java,v 1.5 2007/07/16 08:43:59 msabates Exp $
 */
public class LdapDataAccessException extends AuthenticationServiceException {
   /**
    * Creates a new LdapDataAccessException object.
    *
    * @param msg DOCUMENT ME.
    */
   public LdapDataAccessException(String msg) {
      super(msg);
   }

   /**
    * Creates a new LdapDataAccessException object.
    *
    * @param msg DOCUMENT ME.
    * @param ex DOCUMENT ME.
    */
   public LdapDataAccessException(String msg, Throwable ex) {
      super(msg, ex);
   }
}
