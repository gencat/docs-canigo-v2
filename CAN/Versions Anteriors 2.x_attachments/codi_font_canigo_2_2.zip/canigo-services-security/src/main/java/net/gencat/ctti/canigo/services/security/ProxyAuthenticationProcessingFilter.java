/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import net.gencat.ctti.canigo.services.security.acegi.providers.SequentialProviderManager;
import net.sf.acegisecurity.Authentication;
import net.sf.acegisecurity.AuthenticationException;
import net.sf.acegisecurity.providers.AuthenticationProvider;
import net.sf.acegisecurity.ui.webapp.AuthenticationProcessingFilter;
import net.sf.acegisecurity.ui.webapp.SiteminderAuthenticationProcessingFilter;

import org.acegisecurity.providers.siteminder.SiteminderAuthenticationProvider;


/**
 * Classe proxy mitjan�ant la qual es decideix si l'autenticaci� �s GICAR (Siteminder)
 * depenent de la configuraci� realitzada en el servei de seguretat
 *
 * @author       ALBERT SANCHO
 * @version 1.0
 */
public class ProxyAuthenticationProcessingFilter
   extends AuthenticationProcessingFilter {
   /**
    * Filtre per a l'autenticaci� GICAR
    */
   private SiteminderAuthenticationProcessingFilter siteminderAuthenticationProcessingFilter;

   /**
    * M�tode que realitza l'autenticaci� pel filtre de Siteminder o per el filtre gen�ric
    */
   public Authentication attemptAuthentication(HttpServletRequest request)
      throws AuthenticationException {
      List authenticationProvidersList = ((SequentialProviderManager) this.getAuthenticationManager()).getProviders();

      boolean siteminderAuthentication = false;

      //search for siteminder provider
      for (int i = 0;
            (i < authenticationProvidersList.size()) &&
            !siteminderAuthentication; i++) {
         AuthenticationProvider authenticationProvider = (AuthenticationProvider) authenticationProvidersList.get(i);

         if (authenticationProvider instanceof SiteminderAuthenticationProvider) {
            siteminderAuthentication = true;
         }
      }

      if (siteminderAuthentication) {
         return siteminderAuthenticationProcessingFilter.attemptAuthentication(request);
      } else {
         return super.attemptAuthentication(request);
      }
   }

   /**
    * Documentaci�.
    *
    * @param siteminderAuthenticationProcessingFilter Documentaci�
    */
   public void setSiteminderAuthenticationProcessingFilter(
      SiteminderAuthenticationProcessingFilter siteminderAuthenticationProcessingFilter) {
      this.siteminderAuthenticationProcessingFilter = siteminderAuthenticationProcessingFilter;
   }
}
