/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.model.dao.hibernate;

import net.gencat.ctti.canigo.services.persistence.exception.PersistenceServiceException;
import net.gencat.ctti.canigo.services.persistence.spring.dao.impl.SpringHibernateDAOImpl;
import net.gencat.ctti.canigo.services.security.model.UserLogin;
import net.gencat.ctti.canigo.services.security.model.dao.UserLoginDAO;

import org.hibernate.Session;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.SimpleExpression;
import org.springframework.orm.hibernate3.SessionFactoryUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.6 $
  */
public class UserLoginHibernateImplDAO extends SpringHibernateDAOImpl
   implements UserLoginDAO {
   /**
   * Documentaci�.
   *
   * @return Documentaci�
   */
   public Class getReferenceClass() {
      return UserLogin.class;
   }

   /**
    * Documentaci�.
    *
    * @param userName Documentaci�
    *
    * @return Documentaci�
    */
   public UserLogin findByUserName(String userName) {
      Session s = null;

      try {
         s = super.getSession();

         return (UserLogin) s.createCriteria(UserLogin.class)
                             .add(Expression.eq("userName", userName))
                             .uniqueResult();
      } catch (Exception ex) {
         return null;
      } finally {
         logger.debug(
            "Closing single Hibernate Session in UserLoginHibernateImplDAO.findByUserName");

         if (s != null) {
            SessionFactoryUtils.releaseSession(s, getSessionFactory());
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param userName Documentaci�
    *
    * @return Documentaci�
    */
   public UserLogin findByUserNameIgnoreCase(String userName) {
      Session s = null;

      try {
         s = super.getSession();

         IgnoreCaseEqExpression ignoreCaseExp = new IgnoreCaseEqExpression("userName",
               userName);

         return (UserLogin) s.createCriteria(UserLogin.class).add(ignoreCaseExp)
                             .uniqueResult();
      } catch (Exception ex) {
         return null;
      } finally {
         logger.debug(
            "Closing single Hibernate Session in UserLoginHibernateImplDAO.findByUserName");

         if (s != null) {
            SessionFactoryUtils.releaseSession(s, getSessionFactory());
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param key Documentaci�
    *
    * @return Documentaci�
    *
    * @throws PersistenceServiceException Documentaci�
    */
   public Object load(Integer key) throws PersistenceServiceException {
      // TODO Auto-generated method stub
      return null;
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.6 $
     */
   class IgnoreCaseEqExpression extends SimpleExpression {
      /**
       * Creates a new IgnoreCaseEqExpression object.
       *
       * @param property DOCUMENT ME.
       * @param value DOCUMENT ME.
       */
      public IgnoreCaseEqExpression(String property, Object value) {
         super(property, value, "=", true);
      }
   }
}
