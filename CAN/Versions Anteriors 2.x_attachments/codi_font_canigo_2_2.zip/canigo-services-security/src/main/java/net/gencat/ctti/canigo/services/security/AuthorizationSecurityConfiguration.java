/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;

import java.util.ArrayList;
import java.util.List;

import net.gencat.ctti.canigo.services.security.model.Role;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.util.StringUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class AuthorizationSecurityConfiguration
   implements ApplicationContextAware, InitializingBean {
   /**
    * Documentaci�.
    */
   protected static final String CONVERT_URL_TO_LOWERCASE_BEFORE_COMPARISON = "CONVERT_URL_TO_LOWERCASE_BEFORE_COMPARISON";

   /**
    * Documentaci�.
    */
   protected static final String PATTERN_TYPE_APACHE_ANT = "PATTERN_TYPE_APACHE_ANT";

   /**
    * Documentaci�.
    */
   private ApplicationContext applicationContext;

   /**
    * Documentaci�.
    */
   private AuthenticationSecurityConfiguration authenticationSecurityConfiguration;

   /**
    * Documentaci�.
    */
   private List aclsClassesList = new ArrayList();

   /**
    * Documentaci�.
    */
   private List beanNamesPatternList = new ArrayList();

   /**
    * Documentaci�.
    */
   private List rolesList = new ArrayList();

   /**
    * Documentaci�.
    */
   private String domainObjectsIdGetters = new String();

   /**
    * Documentaci�.
    */
   private String secureBusinessObjects = new String();

   /**
    * Documentaci�.
    */
   private String secureUrls;

   /**
    * Creates a new AuthorizationSecurityConfiguration object.
    */
   public AuthorizationSecurityConfiguration() {
      this.addBeanNameToSpringAOP("valueListHelper");
   }

   /**
    * Documentaci�.
    *
    * @param beanName Documentaci�
    */
   public void addBeanNameToSpringAOP(String beanName) {
      this.beanNamesPatternList.add(beanName);
   }

   // protected AuthorizationSecurityConfiguration addUrlSecurityPattern(String
   /**
    * Documentaci�.
    *
    * @param secureUrls Documentaci�
    */
   public void setSecureUrls(String secureUrls) {
      this.secureUrls = secureUrls;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected String getSecureUrls() {
      return this.secureUrls;
   }

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    *
    * @return Documentaci�
    */
   public List getSecuredUrls(Role role) {
      return getConfigurationList(role, this.secureUrls);
   }

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    * @param configurationFormatedString Documentaci�
    *
    * @return Documentaci�
    */
   private List getConfigurationList(Role role,
      String configurationFormatedString) {
      BufferedReader br = new BufferedReader(new StringReader(
               configurationFormatedString));
      String line;
      List list = new ArrayList();

      while (true) {
         try {
            line = br.readLine();
         } catch (IOException ioe) {
            throw new IllegalArgumentException(ioe.getMessage());
         }

         if (line == null) {
            break;
         }

         line = line.trim();

         if (line.startsWith("//")) {
            continue;
         }

         // Continue = go back to the beginning of the while loop if there is no "=" in the String
         if (line.lastIndexOf('=') == -1) {
            continue;
         }

         // Tokenize the line into its name/value tokens
         String[] nameValue = StringUtils.delimitedListToStringArray(line, "=");
         String url = nameValue[0];
         String commaSeparatedRolesList = nameValue[1];

         // If the list of commaSeparatedRoles contains the role we're looking for 
         if (commaSeparatedRolesList.lastIndexOf(role.getName()) != -1) {
            list.add(url);
         }
      }

      return list;
   }

   /**
    * Documentaci�.
    *
    * @param secureBusinessObjects Documentaci�
    */
   public void setSecureBusinessObjects(String secureBusinessObjects) {
      this.secureBusinessObjects = secureBusinessObjects;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected String getSecureBusinessObjects() {
      return this.secureBusinessObjects;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected List getBeanNamesPatternList() {
      return this.beanNamesPatternList;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected String getDomainObjectsIdGetters() {
      return domainObjectsIdGetters;
   }

   /**
    * Documentaci�.
    *
    * @param domainObjectsIdGetters Documentaci�
    */
   public void setDomainObjectsIdGetters(String domainObjectsIdGetters) {
      this.domainObjectsIdGetters = domainObjectsIdGetters;
   }

   /**
    * Documentaci�.
    *
    * @param beanNamesPatternList Documentaci�
    */
   public void setBeanNamesPatternList(List beanNamesPatternList) {
      this.beanNamesPatternList = beanNamesPatternList;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected List getRolesList() {
      return rolesList;
   }

   /**
    * Documentaci�.
    *
    * @param rolesList Documentaci�
    */
   public void setRolesList(List rolesList) {
      this.rolesList = rolesList;
   }

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    */
   public void addRole(String role) {
      this.rolesList.add(role);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected String getCommaSeparatedRoleList() {
      return StringUtils.collectionToCommaDelimitedString(this.getRolesList());
   }

   /**
    * Documentaci�.
    *
    * @param aclsClassesList Documentaci�
    */
   public void setAclsClassesList(List aclsClassesList) {
      this.aclsClassesList = aclsClassesList;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected List getAclsClassesList() {
      return aclsClassesList;
   }

   /**
    * Documentaci�.
    *
    * @param applicationContext Documentaci�
    *
    * @throws BeansException Documentaci�
    */
   public void setApplicationContext(ApplicationContext applicationContext)
      throws BeansException {
      this.applicationContext = applicationContext;
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void afterPropertiesSet() throws Exception {
      this.secureUrlsAfterPropertiesSet();

      this.secureBusinessObjectsAfterPropertiesSet();
   }

   /**
    * Documentaci�.
    */
   protected void secureUrlsAfterPropertiesSet() {
      if (this.authenticationSecurityConfiguration == null) {
         this.authenticationSecurityConfiguration = (AuthenticationSecurityConfiguration) this.applicationContext.getBean(
               "authenticationConfiguration");
      }

      // TODO Add Parameter CONVERT_URL_TO_LOWERCASE_BEFORE_COMPARISON + "\n"
      StringBuffer sb = new StringBuffer(PATTERN_TYPE_APACHE_ANT + "\n");

      String anonymousSecureUrl = this.authenticationSecurityConfiguration.getLoginFormUrlValue() +
         "* = ROLE_ANONYMOUS," + this.getCommaSeparatedRoleList() + "\n";

      sb.append(anonymousSecureUrl);

      this.secureUrls = sb.toString() + this.secureUrls;
   }

   /**
    * Documentaci�.
    */
   protected void secureBusinessObjectsAfterPropertiesSet() {
      // Add Collection filtering method which uses the ValueList component
      this.secureBusinessObjects += ("net.mlw.vlh.web.mvc.ValueListHandlerHelper.getValueList=" +
      this.getCommaSeparatedRoleList() + ",AFTER_ACL_COLLECTION_READ");
   }

   /**
    * Documentaci�.
    *
    * @param authenticationConfiguration Documentaci�
    */
   protected void setAuthenticationConfiguration(
      AuthenticationSecurityConfiguration authenticationConfiguration) {
      this.authenticationSecurityConfiguration = authenticationConfiguration;
   }

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    *
    * @return Documentaci�
    */
   public List getSecuredMethods(Role role) {
      return getConfigurationList(role, this.secureBusinessObjects);
   }
}
