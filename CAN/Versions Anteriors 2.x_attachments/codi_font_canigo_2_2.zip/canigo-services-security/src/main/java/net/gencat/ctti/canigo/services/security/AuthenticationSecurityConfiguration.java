/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.sf.acegisecurity.providers.anonymous.AnonymousAuthenticationProvider;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.util.Assert;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class AuthenticationSecurityConfiguration implements InitializingBean,
   ApplicationContextAware {
   /**
    * Documentaci�.
    */
   private ApplicationContext applicationContext;

   /**
    * Documentaci�.
    */
   private List authenticationConfigurationProvidersList = new ArrayList();

   /**
    * Documentaci�.
    */
   private List authenticationProvidersList;

   /**
    * Documentaci�.
    */
   private String authenticationFailureUrlValue;

   /**
    * Documentaci�.
    */
   private String filterProcessesUrl = "/j_acegi_security_check";

   /**
    * Documentaci�.
    */
   private String loginFormUrlValue;

   /**
    * Creates a new AuthenticationSecurityConfiguration object.
    */
   public AuthenticationSecurityConfiguration() {
      this.authenticationProvidersList = new ArrayList();
   }

   /**
    * Documentaci�.
    *
    * @param loginFormUrlValue Documentaci�
    */
   public void setLoginFormUrlValue(String loginFormUrlValue) {
      this.loginFormUrlValue = loginFormUrlValue;
   }

   /**
    * Documentaci�.
    *
    * @param authenticationFailureUrlValue Documentaci�
    */
   public void setAuthenticationFailureUrlValue(
      String authenticationFailureUrlValue) {
      this.authenticationFailureUrlValue = authenticationFailureUrlValue +
         "?login_error=1";
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getAuthenticationFailureUrlValue() {
      return authenticationFailureUrlValue;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getLoginFormUrlValue() {
      return loginFormUrlValue;
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void afterPropertiesSet() throws Exception {
      Assert.notNull(this.loginFormUrlValue, "loginFormUrlValue must be set");
      Assert.notNull(this.authenticationFailureUrlValue,
         "authenticationFailureUrlValue must be set");
   }

   /**
    * Documentaci�.
    *
    * @param authenticationProvidersList Documentaci�
    */
   public void setAuthenticationProvidersConfigurationList(
      List authenticationProvidersList) {
      this.authenticationConfigurationProvidersList = authenticationProvidersList;
   }

   // Get the list configured by the user and an
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public List getAuthenticationProvidersList() throws Exception {
      // Iterate on Configuration list
      for (Iterator iter = this.authenticationConfigurationProvidersList.iterator();
            iter.hasNext();) {
         AbstractAuthenticationConfiguration conf = (AbstractAuthenticationConfiguration) iter.next();
         this.authenticationProvidersList.add(conf.getAuthenticationProvider(
               this.applicationContext));
      }

      // Add an Anonymous at the end 
      AnonymousAuthenticationProvider anonymousAuthenticationProvider = new AnonymousAuthenticationProvider();
      // A bit stupid, but you have to set this value ...
      anonymousAuthenticationProvider.setKey("foobar");
      this.authenticationProvidersList.add(anonymousAuthenticationProvider);

      return this.authenticationProvidersList;
   }

   /**
    * Documentaci�.
    *
    * @param applicationContext Documentaci�
    *
    * @throws BeansException Documentaci�
    */
   public void setApplicationContext(ApplicationContext applicationContext)
      throws BeansException {
      this.applicationContext = applicationContext;
   }

   /**
    * Documentaci�.
    *
    * @param filterProcessesUrl Documentaci�
    */
   public void setFilterProcessesUrl(String filterProcessesUrl) {
      this.filterProcessesUrl = filterProcessesUrl;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getFilterProcessesUrl() {
      return this.filterProcessesUrl;
   }
}
