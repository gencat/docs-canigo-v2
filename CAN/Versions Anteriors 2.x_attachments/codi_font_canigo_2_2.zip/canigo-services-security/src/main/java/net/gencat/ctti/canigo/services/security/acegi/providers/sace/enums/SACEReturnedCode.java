/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers.sace.enums;

import net.sf.acegisecurity.AuthenticationServiceException;
import net.sf.acegisecurity.BadCredentialsException;
import net.sf.acegisecurity.DisabledException;
import net.sf.acegisecurity.LockedException;
import net.sf.acegisecurity.providers.dao.UsernameNotFoundException;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class SACEReturnedCode {
   /**
    * USERID = NIF / NIE
    */
   public static final int RESULT_CODE_USERID_NOT_FOUND = 10;

   /**
    * Documentaci�.
    */
   public static final int RESULT_CODE_OK = 0;

   /**
    * Documentaci�.
    */
   public static final int RESULT_CODE_USERNAME_NOT_FOUND = 13;

   /**
    * Documentaci�.
    */
   public static final int RESULT_CODE_INVALID_PASSWORD = 14;

   /**
    * Documentaci�.
    */
   public static final int RESULT_CODE_DISABLED_USER = 17;

   /**
    * Documentaci�.
    */
   public static final int RESULT_CODE_LOCKED_USER = 18;

   /**
    * Documentaci�.
    *
    * @param returnedCode Documentaci�
    */
   public static void convertReturnedCode2AuthenticationServiceException(
      String returnedCode) {
      int code = new Integer(returnedCode).intValue();

      String message = "Error code from SACE:" + returnedCode;

      switch (code) {
      case RESULT_CODE_OK:
         break; // Do nothing, do not throw exception because user has been sucessfully authenticated

      case RESULT_CODE_INVALID_PASSWORD:
         throw new BadCredentialsException(message);

      case RESULT_CODE_USERNAME_NOT_FOUND:
         throw new UsernameNotFoundException(message);

      case RESULT_CODE_DISABLED_USER:
         throw new DisabledException(message);

      case RESULT_CODE_LOCKED_USER:
         throw new LockedException(message);

      case RESULT_CODE_USERID_NOT_FOUND:
         throw new BadCredentialsException(message);

      default:
         throw new AuthenticationServiceException("SACE, unknown return code: " +
            returnedCode);
      }
   }
}
