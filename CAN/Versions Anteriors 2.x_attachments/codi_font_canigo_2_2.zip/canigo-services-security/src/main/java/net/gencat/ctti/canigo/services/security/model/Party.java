/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.model;

import net.gencat.ctti.canigo.services.security.model.AbstractSecurityModelPOJO;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class Party {
   /**
    * Documentaci�.
    */
   private Integer id;

   /**
    * Documentaci�.
    */
   private int hashCode = Integer.MIN_VALUE;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Integer getId() {
      return id;
   }

   /**
    * Documentaci�.
    *
    * @param id Documentaci�
    */
   public void setId(Integer id) {
      this.id = id;
   }

   /**
    * Documentaci�.
    *
    * @param obj Documentaci�
    *
    * @return Documentaci�
    */
   public boolean equals(Object obj) {
      if (null == obj) {
         return false;
      }

      if (!(obj instanceof AbstractSecurityModelPOJO)) {
         return false;
      } else {
         AbstractSecurityModelPOJO x = (AbstractSecurityModelPOJO) obj;

         if ((null == this.getId()) || (null == x.getId())) {
            return false;
         } else {
            return (this.getId().equals(x.getId()));
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int hashCode() {
      if (Integer.MIN_VALUE == this.hashCode) {
         if (null == this.getId()) {
            return super.hashCode();
         } else {
            String hashStr = this.getClass().getName() + ":" +
               this.getId().hashCode();
            this.hashCode = hashStr.hashCode();
         }
      }

      return this.hashCode;
   }

   /**
    * Documentaci�.
    *
    * @param obj Documentaci�
    *
    * @return Documentaci�
    */
   public int compareTo(Object obj) {
      if (obj.hashCode() > hashCode()) {
         return 1;
      } else if (obj.hashCode() < hashCode()) {
         return -1;
      } else {
         return 0;
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String toString() {
      return super.toString();
   }
}
