/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers.sace.ext;

import javax.net.ssl.SSLContext;


/**
 * Aquesta classe permet encapsular la crida setDefaultSSLSocketFactory sobre una classe <br>
 * propit�ria de IBM. Es fa servir des de la classe SACEPasswordAuthenticationDao en el cas <br>
 * de que ens trobem en un servidor Websphere.
 *
 * @author A119444
 */
public class WrapperHttpsURLConnection {
   /**
    * Documentaci�.
    *
    * @param sc Documentaci�
    */
   public static void setDefaultSSLSocketFactory(SSLContext sc) {
      System.setProperty("java.protocol.handler.pkgs",
         "com.ibm.net.ssl.internal.www.protocol.https");
      com.ibm.net.ssl.internal.www.protocol.https.HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
   }
}
