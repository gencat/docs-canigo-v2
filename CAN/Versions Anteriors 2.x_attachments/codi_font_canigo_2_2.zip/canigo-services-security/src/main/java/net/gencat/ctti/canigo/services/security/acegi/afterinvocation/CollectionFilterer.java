/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.afterinvocation;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * A filter used to filter Collections.
 */
public class CollectionFilterer implements Filterer {
   /**
    * Documentaci�.
    */
   protected static final Log logger = LogFactory.getLog(ValueListFilteringProvider.class);

   /**
    * Documentaci�.
    */
   private Collection collection;

   // collectionIter offers significant performance optimisations (as
   /**
    * Documentaci�.
    */
   private Iterator collectionIter;

   /**
    * Documentaci�.
    */
   private Set removeList;

   /**
    * Creates a new CollectionFilterer object.
    *
    * @param collection DOCUMENT ME.
    */
   CollectionFilterer(Collection collection) {
      this.collection = collection;

      // We create a Set of objects to be removed from the Collection,
      // as ConcurrentModificationException prevents removal during
      // iteration, and making a new Collection to be returned is
      // problematic as the original Collection implementation passed
      // to the method may not necessarily be re-constructable (as
      // the Collection(collection) constructor is not guaranteed and
      // manually adding may lose sort order or other capabilities)
      removeList = new HashSet();
   }

   /**
    * @see net.sf.acegisecurity.afterinvocation.Filterer#getFilteredObject()
    */
   public Object getFilteredObject() {
      // Now the Iterator has ended, remove Objects from Collection
      Iterator removeIter = removeList.iterator();

      int originalSize = collection.size();

      while (removeIter.hasNext()) {
         collection.remove(removeIter.next());
      }

      if (logger.isDebugEnabled()) {
         logger.debug("Original collection contained " + originalSize +
            " elements; now contains " + collection.size() + " elements");
      }

      return collection;
   }

   /**
    * @see net.sf.acegisecurity.afterinvocation.Filterer#iterator()
    */
   public Iterator iterator() {
      collectionIter = collection.iterator();

      return collectionIter;
   }

   /**
    * @see net.sf.acegisecurity.afterinvocation.Filterer#remove(java.lang.Object)
    */
   public void remove(Object object) {
      collectionIter.remove();
   }
}
