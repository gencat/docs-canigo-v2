/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi;

import java.util.Arrays;
import java.util.List;

import net.gencat.ctti.canigo.services.security.SecurityService;
import net.gencat.ctti.canigo.services.security.model.UserLogin;
import net.sf.acegisecurity.Authentication;
import net.sf.acegisecurity.GrantedAuthorityImpl;
import net.sf.acegisecurity.UserDetails;
import net.sf.acegisecurity.context.SecurityContext;
import net.sf.acegisecurity.context.SecurityContextHolder;

import org.apache.commons.validator.GenericValidator;


/**
 * $Id: SecurityServiceAcegiImpl.java,v 1.6 2007/09/13 03:17:19 asancho Exp $
 * Implementation of Security Service based on Acegi.
 * @author JMG
 * @author XES
 * @version $Revision: 1.6 $ $Date: 2007/09/13 03:17:19 $
 *
 * @since 1.0
 *
 * $Log: SecurityServiceAcegiImpl.java,v $
 * Revision 1.6  2007/09/13 03:17:19  asancho
 * [CAN-157]: Integraci� amb Gicar. Canvi llibreria d'acegi 0.8.3 -> 0.9.0
 *
 * Revision 1.5.8.1  2007/09/13 03:08:43  asancho
 * [CAN-157]: Implementaci� amb Gicar. Canvi de llibreria d'acegi 0.8.3 -> 0.9.0
 *
 * Revision 1.5  2007/07/16 08:43:59  msabates
 * Canvis efectuats pel Jalopy [Canigo 2.1]
 *
 * Revision 1.4  2007/05/23 10:44:53  msabates
 * Cap�alera
 *
 * Revision 1.1.1.1.2.1  2007/05/18 10:50:23  fernando.vaquero
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2007/05/15 13:53:46  fernando.vaquero
 * Importacio canigo 2.0
 *
 * Revision 1.3  2007/05/15 10:19:57  msabates
 * Jalopy
 *
 * Revision 1.2  2007/04/24 07:51:18  msabates
 * Canvis que estaven a la v1.4
 *
 * Revision 1.7  2006/11/20 15:18:38  mmateos
 * author: crico: version 1.1
 *
 * Revision 1.7  2006/09/28 07:41:12  crico
 * version 1.1
 *
 * Revision 1.5.2.1  2006/03/10 09:25:05  xescuder
 * XES: Classcast Exception fixed if try to get information of UserLogin before Acegi plug
 *
 */
public class SecurityServiceAcegiImpl implements SecurityService {
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isUserAuthenticated() {
      SecurityContext secureContext = (SecurityContext) SecurityContextHolder.getContext();

      return (secureContext != null) &&
      (secureContext.getAuthentication() != null);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String[] getRoles() {
      // TODO Auto-generated method stub
      return null;
   }

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    *
    * @return Documentaci�
    */
   public boolean isUserInRole(String role) {
      if (GenericValidator.isBlankOrNull(role)) {
         throw new IllegalArgumentException("role should not be blank or null");
      }

      List grantedAuthoritiesList = Arrays.asList(getAuthentication()
                                                     .getAuthorities());

      GrantedAuthorityImpl grantedAuthorityLookedUp = new GrantedAuthorityImpl(role);

      // return value will be >= 0 if and only if the key is found.
      return grantedAuthoritiesList.contains(grantedAuthorityLookedUp);
   }

   /**
    * Documentaci�.
    *
    * @param businessObject Documentaci�
    *
    * @return Documentaci�
    */
   public boolean hasUserReadPermission(Object businessObject) {
      // TODO Auto-generated method stub
      return false;
   }

   /**
    * Documentaci�.
    *
    * @param businessObject Documentaci�
    *
    * @return Documentaci�
    */
   public boolean hasUserWritePermission(Object businessObject) {
      // TODO Auto-generated method stub
      return false;
   }

   /**
    * Documentaci�.
    *
    * @param businessObject Documentaci�
    *
    * @return Documentaci�
    */
   public boolean hasUserDeletePermission(Object businessObject) {
      // TODO Auto-generated method stub
      return false;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public UserLogin getUserLogin() {
      UserLogin user = new UserLogin();

      // since 1.0.1 checked authentication can be null before obtaining getPrincipal().
      // Also not cast for UserDetails of Acegi in authentication
      Authentication authentication = getAuthentication();

      if (authentication != null) {
         Object principal = authentication.getPrincipal();

         if (principal instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();

            if (userDetails != null) {
               user.setUserName(userDetails.getUsername());

               return user;
            }
         }
      }

      return null;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   private Authentication getAuthentication() {
      SecurityContext secureContext = (SecurityContext) SecurityContextHolder.getContext();

      return secureContext.getAuthentication();
   }
}
