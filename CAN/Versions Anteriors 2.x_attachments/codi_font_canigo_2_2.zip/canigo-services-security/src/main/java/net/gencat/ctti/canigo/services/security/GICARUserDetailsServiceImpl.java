/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security;

import net.gencat.ctti.canigo.services.security.acegi.providers.dao.AuthoritiesDAO;
import net.sf.acegisecurity.UserDetails;
import net.sf.acegisecurity.providers.dao.User;
import net.sf.acegisecurity.providers.dao.UsernameNotFoundException;

import org.acegisecurity.userdetails.UserDetailsService;
import org.springframework.dao.DataAccessException;


/**
 * Classe encarregada d'obtenir les dades del usuari a partir del seu nom
 *
 * @author       ALBERT SANCHO
 * @version      1.0
 */
public class GICARUserDetailsServiceImpl implements UserDetailsService {
   /**
    * Separador dels camps de la cap�alera
    */
   private static final String HEADER_SEPARATOR = ";";

   /**
    * DAO per obtenir els permissos de l'usuari
    */
   private AuthoritiesDAO authoritiesDAO;

   /**
    * Nom del camp de la cap�alera que cont� el nom del usuari
    */
   private String httpGicarHeaderUsernameKey;

   /**
    * M�tode que carrega la informaci� del usuari
    */
   public UserDetails loadUserByUsername(String username)
      throws UsernameNotFoundException, DataAccessException {
      if (username.indexOf(httpGicarHeaderUsernameKey) != -1) {
         //HTTP GICAR header example -> CODIINTERN=NRDRJN0001;NIF=11112222W;EMAIL=mail.admin@gencat.net;UNITAT_MAJOR=CTTI;UNITAT_MENOR=CTTI Qualitat
         int ini = username.trim().indexOf(httpGicarHeaderUsernameKey) +
            httpGicarHeaderUsernameKey.length() + 1;
         int end = username.trim().indexOf(HEADER_SEPARATOR, ini);

         if (end == -1) {
            end = username.trim().length();
         }

         String gicarUser = username.substring(ini, end);

         UserDetails user = new User(gicarUser, "dummy", true, true, true,
               true, this.authoritiesDAO.getAuthoritiesIgnoreCase(gicarUser));

         return user;
      }

      return null;
   }

   /**
    * Documentaci�.
    *
    * @param authoritiesDAO Documentaci�
    */
   public void setAuthoritiesDAO(AuthoritiesDAO authoritiesDAO) {
      this.authoritiesDAO = authoritiesDAO;
   }

   /**
    * Documentaci�.
    *
    * @param httpGicarHeaderUsernameKey Documentaci�
    */
   public void setHttpGicarHeaderUsernameKey(String httpGicarHeaderUsernameKey) {
      this.httpGicarHeaderUsernameKey = httpGicarHeaderUsernameKey;
   }
}
