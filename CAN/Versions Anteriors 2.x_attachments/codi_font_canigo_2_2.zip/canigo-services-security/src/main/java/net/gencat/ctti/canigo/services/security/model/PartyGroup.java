/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.model;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class PartyGroup extends AbstractSecurityModelPOJO {
   /**
    * Documentaci�.
    */
   private PartyGroup parent;

   /**
    * This is not a collection. <=> List "Application Roles" in User Details Edit page.
    * Initialized to null because we NEVER want to pre-select a role but the framework tag
    * requires a "property value"
    */
   private Role applicationRoles = null;

   /**
    * available Roles for that user = {ALL ROLES}
    *                               - {Roles assigned to user}
    *                               - {Roles assigned to group and hierarchy of groups}
    *                               - {Hierarchy of Roles }
    *                               - {The grand-mother of my uncle cousins}
    */
   private Set availableRoles;

   /**
    * Documentaci�.
    */
   private Set roles;

   /**
    * Creates a new PartyGroup object.
    */
   public PartyGroup() {
      super();
   }

   /**
    * Creates a new PartyGroup object.
    *
    * @param id DOCUMENT ME.
    * @param name DOCUMENT ME.
    */
   public PartyGroup(int id, String name) {
      super.setId(new Integer(id));
      super.setName(name);
   }

   /**
    * Documentaci�.
    *
    * @param role Documentaci�
    */
   public void addRole(Role role) {
      if (this.roles == null) {
         this.roles = new HashSet();
      }

      this.roles.add(role);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Set getRoles() {
      return this.roles;
   }

   /**
    * Documentaci�.
    *
    * @param roles Documentaci�
    */
   public void setRoles(Set roles) {
      this.roles = roles;
   }

   // TODO Refactoring, this method is exactly the same as UserLogin
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Set getRecursiveRoles() {
      Set allRoles = new HashSet();

      if (this.roles != null) {
         for (Iterator iter = this.roles.iterator(); iter.hasNext();) {
            Role role = (Role) iter.next();
            allRoles.add(role);
            allRoles.addAll(role.getRecursiveParentRoles());
         }
      }

      if (this.parent != null) {
         allRoles.add(this.parent.getRecursiveRoles());
      }

      return allRoles;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public PartyGroup getParent() {
      return this.parent;
   }

   /**
    * Documentaci�.
    *
    * @param newParentRole Documentaci�
    */
   public void setParent(PartyGroup newParentRole) {
      if (newParentRole == null) {
         this.parent = null;
      }

      if (this.equals(newParentRole)) {
         throw new IllegalArgumentException(
            "A role can't be its own father !!! (try to fuck yourself to see what happens...)");
      }

      // TODO I don't understand why Hibernate keeps shouting about it !!!
      // with a NullPointerException
      // if (this.isAParentOf(newParentRole)) {
      // throw new IllegalArgumentException(this + " is a parent of " +
      // newParentRole);
      // }
      this.parent = newParentRole;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Role getApplicationRoles() {
      return applicationRoles;
   }

   /**
    * Documentaci�.
    *
    * @param applicationRoles Documentaci�
    */
   public void setApplicationRoles(Role applicationRoles) {
      this.applicationRoles = applicationRoles;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Set getAvailableRoles() {
      return availableRoles;
   }
}
