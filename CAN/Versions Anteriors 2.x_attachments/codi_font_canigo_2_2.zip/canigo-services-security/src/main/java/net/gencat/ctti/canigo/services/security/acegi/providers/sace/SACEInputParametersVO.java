/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi.providers.sace;

import net.gencat.ctti.canigo.services.security.acegi.providers.sace.enums.SACEUserNameFormatEnum;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class SACEInputParametersVO {
   /**
    * Documentaci�.
    */
   private String commandCode = "";

   /**
    * Documentaci�.
    */
   private String newPassword = "";

   /**
    * Documentaci�.
    */
   private String password = "";

   /**
    * Documentaci�.
    */
   private String returnedUrl = "";

   /**
    * Documentaci�.
    */
   private String userId = "";

   /**
    * Documentaci�.
    */
   private String userName = "";

   /**
    * Creates a new SACEInputParametersVO object.
    *
    * @param format DOCUMENT ME.
    * @param user DOCUMENT ME.
    * @param password DOCUMENT ME.
    */
   public SACEInputParametersVO(SACEUserNameFormatEnum format, String user,
      String password) {
      this.commandCode = format.getName();

      if (format.equals(SACEUserNameFormatEnum.INTERNAL_CODE)) {
         this.userName = user;
      } else {
         this.userId = user;
      }

      this.password = password;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getCommandCode() {
      return commandCode;
   }

   /**
    * Documentaci�.
    *
    * @param commandCode Documentaci�
    */
   public void setCommandCode(String commandCode) {
      this.commandCode = commandCode;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getNewPassword() {
      return newPassword;
   }

   /**
    * Documentaci�.
    *
    * @param newPassword Documentaci�
    */
   public void setNewPassword(String newPassword) {
      this.newPassword = newPassword;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getPassword() {
      return password;
   }

   /**
    * Documentaci�.
    *
    * @param password Documentaci�
    */
   public void setPassword(String password) {
      this.password = password;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getReturnedUrl() {
      return returnedUrl;
   }

   /**
    * Documentaci�.
    *
    * @param returnedUrl Documentaci�
    */
   public void setReturnedUrl(String returnedUrl) {
      this.returnedUrl = returnedUrl;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getUserId() {
      return userId;
   }

   /**
    * Documentaci�.
    *
    * @param userId Documentaci�
    */
   public void setUserId(String userId) {
      this.userId = userId;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getUserName() {
      return userName;
   }

   /**
    * Documentaci�.
    *
    * @param userName Documentaci�
    */
   public void setUserName(String userName) {
      this.userName = userName;
   }
}
