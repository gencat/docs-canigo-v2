/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.acegi;

import java.lang.reflect.Method;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import net.sf.acegisecurity.acl.basic.AclObjectIdentity;
import net.sf.acegisecurity.acl.basic.BasicAclProvider;
import net.sf.acegisecurity.acl.basic.NamedEntityObjectIdentity;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.propertyeditors.PropertiesEditor;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class AclProviderWithIdRegistration extends BasicAclProvider {
   /**
    * Documentaci�.
    */
   private Map registredClassesMap = new Hashtable();

   /**
    * Documentaci�.
    *
    * @param config Documentaci�
    *
    * @throws ClassNotFoundException Documentaci�
    */
   public void setConfigurationDomainObjectsIdGetters(String config)
      throws ClassNotFoundException {
      if ((config == null) || "".equals(config)) {
         // Leave value in property editor null
      } else {
         // Use properties editor to tokenize the string
         PropertiesEditor propertiesEditor = new PropertiesEditor();
         propertiesEditor.setAsText(config);

         Properties props = (Properties) propertiesEditor.getValue();

         for (Iterator iter = props.keySet().iterator(); iter.hasNext();) {
            String name = (String) iter.next();
            String value = props.getProperty(name);

            // Register name and attribute
            this.registerId(Class.forName(name), value);
         }
      }
   }

   /**
    * Documentaci�.
    *
    * @param domainClass Documentaci�
    * @param getterMethodName Documentaci�
    */
   public void registerId(Class domainClass, String getterMethodName) {
      Method getterMethod = BeanUtils.findMethodWithMinimalParameters(domainClass,
            getterMethodName);

      if (getterMethod == null) {
         throw new IllegalArgumentException("The property " + getterMethodName +
            " does not exist");
      }

      this.registredClassesMap.put(domainClass, getterMethod);
   }

   /**
    * Documentaci�.
    *
    * @param domainInstance Documentaci�
    *
    * @return Documentaci�
    */
   public AclObjectIdentity obtainIdentity(Object domainInstance) {
      AclObjectIdentity identity = super.obtainIdentity(domainInstance);

      if (identity != null) {
         return identity;
      }

      Class domainClass = domainInstance.getClass();

      if (!hasRegistredDomainClass(domainClass)) {
         throw new IllegalArgumentException("Class " + domainClass +
            " has not been registred in the AclProvider. " +
            "\nBecause this class does not provide a getId() method, you need to register it in your Spring securiry Configuration." +
            " Add the following line to your configuration: ");
      }

      // We have the name of the getter method for the id, we can use reflexion to get it 
      Method getterMethod = (Method) this.registredClassesMap.get(domainInstance.getClass());
      String stringId = null;

      try {
         Object id = getterMethod.invoke(domainInstance, new Object[] {  });

         if (id != null) {
            stringId = id.toString();
         }
      } catch (Exception ex) {
         throw new RuntimeException(ex);
      }

      return new NamedEntityObjectIdentity(domainClass.getName(), stringId);
   }

   /**
    * Documentaci�.
    *
    * @param domainInstance Documentaci�
    *
    * @return Documentaci�
    */
   public String serializeObjectIdentity(Object domainInstance) {
      StringBuffer identityStringBuf = new StringBuffer(domainInstance.getClass()
                                                                      .getName());
      identityStringBuf.append(':');

      NamedEntityObjectIdentity namedIdentity = (NamedEntityObjectIdentity) obtainIdentity(domainInstance);
      identityStringBuf.append(namedIdentity.getId());

      return identityStringBuf.toString();
   }

   /**
    * Documentaci�.
    *
    * @param domainClass Documentaci�
    *
    * @return Documentaci�
    */
   protected boolean hasRegistredDomainClass(Class domainClass) {
      return registredClassesMap.containsKey(domainClass);
   }
}
