/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.security.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class Role extends AbstractSecurityModelPOJO {
   /**
    * Documentaci�.
    */
   private Role parent;

   /**
    * Creates a new Role object.
    */
   public Role() {
      super();
   }

   /**
    * Creates a new Role object.
    *
    * @param name DOCUMENT ME.
    */
   public Role(String name) {
      super.setName(name);
   }

   /**
    * Creates a new Role object.
    *
    * @param id DOCUMENT ME.
    * @param name DOCUMENT ME.
    */
   public Role(int id, String name) {
      super(new Integer(id), name);
   }

   /**
    * Creates a new Role object.
    *
    * @param id DOCUMENT ME.
    * @param name DOCUMENT ME.
    * @param parent DOCUMENT ME.
    */
   public Role(int id, String name, Role parent) {
      super(new Integer(id), name);
      this.parent = parent;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Set getRecursiveParentRoles() {
      HashSet parentRolesSet = new HashSet();

      if (this.getParent() != null) {
         parentRolesSet.add(this.getParent());

         Role parentRole = (Role) this.getParent();
         parentRolesSet.addAll(parentRole.getRecursiveParentRoles());
      }

      return parentRolesSet;
   }

   /**
    * Documentaci�.
    *
    * @param possibleExistingSon Documentaci�
    *
    * @return Documentaci�
    */
   public boolean isAParentOf(Role possibleExistingSon) {
      List parentsOfmyPossibleExistingSon = new ArrayList(possibleExistingSon.getRecursiveParentRoles());

      return parentsOfmyPossibleExistingSon.contains(this);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String toString() {
      String s = new String();

      if (this.getId() != null) {
         s = this.getId().toString();
      }

      if (this.getName() != null) {
         s = s + ", " + this.getName();
      }

      if (s.length() == 0) {
         return super.toString();
      }

      return s;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Role getParent() {
      return this.parent;
   }

   /**
    * Documentaci�.
    *
    * @param newParentRole Documentaci�
    */
   public void setParent(Role newParentRole) {
      if (newParentRole == null) {
         this.parent = null;
      }

      if (this.equals(newParentRole)) {
         throw new IllegalArgumentException(
            "A role can't be its own father !!! (try to fuck yourself to see what happens...)");
      }

      // TODO I don't understand why Hibernate keeps shouting about it !!!
      // with a NullPointerException
      // if (this.isAParentOf(newParentRole)) {
      // throw new IllegalArgumentException(this + " is a parent of " +
      // newParentRole);
      // }
      this.parent = newParentRole;
   }
}
