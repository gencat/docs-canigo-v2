/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.portlets.struts;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.gencat.ctti.canigo.services.exceptions.SystemException;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.web.exception.TagsServiceException;
import net.gencat.ctti.canigo.services.web.struts.ExtendedDelegatingTilesRequestProcessor;

import org.apache.portals.bridges.struts.PortletServlet;
import org.apache.portals.bridges.struts.PortletServletResponseWrapper;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.MultipartRequestWrapper;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class ExtendedDelegatingPortletTilesRequestProcessor
   extends ExtendedDelegatingTilesRequestProcessor {
   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param response Documentaci�
    * @param mapping Documentaci�
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    * @throws ServletException Documentaci�
    */
   protected boolean processRoles(HttpServletRequest request,
      HttpServletResponse response, ActionMapping mapping)
      throws IOException, ServletException {
      boolean proceed = super.processRoles(request, response, mapping);

      if (proceed && PortletServlet.isPortletRequest(request) &&
            ((PortletServlet) super.servlet).performActionRenderRequest(
               request, response, mapping)) {
         return false;
      } else {
         return proceed;
      }
   }

   //protected void doForward(
   //        String uri,
   //        HttpServletRequest request,
   //        HttpServletResponse response)
   //        throws IOException, ServletException {
   //            
   //        // Unwrap the multipart request, if there is one.
   //        if (request instanceof MultipartRequestWrapper) {
   //            request = ((MultipartRequestWrapper) request).getRequest();
   //        }
   //
   //        RequestDispatcher rd = getServletContext().getRequestDispatcher(uri);
   //        if (rd == null) {
   //            response.sendError(
   //                HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
   //                getInternal().getMessage("requestDispatcher", uri));
   //            return;
   //        }
   //		if (!PortletServlet.isPortletRequest(request)) {
   //            rd.forward(request, response );
   //		}
   //        else{
   //            HttpServletResponse respWrapper = WrappedHttpServletResponse.ensureWrappedResponse(request, response);
   //            try{
   //            	rd.forward(request, respWrapper);
   //            }
   //            catch(Exception ex){
   //            	throw new TagsServiceException(ex, ex.getMessage());
   //             }
   //            finally{
   //            	//WrappedHttpServletResponse.getWrappedResponse(request, response).flushBuffer();
   //            	respWrapper.flushBuffer();
   //            }
   //       }
   //    }
}
