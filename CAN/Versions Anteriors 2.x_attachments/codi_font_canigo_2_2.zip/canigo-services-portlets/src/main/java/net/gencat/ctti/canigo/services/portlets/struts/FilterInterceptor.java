/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.portlets.struts;

import java.io.IOException;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import javax.servlet.http.HttpSessionContext;

import org.apache.portals.bridges.struts.PortletServletRequestWrapper;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.util.UrlPathHelper;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class FilterInterceptor extends HandlerInterceptorAdapter
   implements InitializingBean {
   /**
    * Documentaci�.
    */
   private Class filterClass;

   /**
    * Documentaci�.
    */
   private Filter filter;

   /**
    * Documentaci�.
    */
   private final FilterInterceptorConfig config = new FilterInterceptorConfig();

   /**
    * Documentaci�.
    */
   private HandlerInterceptor nextInterceptor;

   /**
    * Documentaci�.
    */
   private HashMap configMap;

   /**
    * Documentaci�.
    */
   private List urlPatternList;

   /**
    * Documentaci�.
    */
   private PathMatcher pathMatcher = new AntPathMatcher();

   /**
    * Documentaci�.
    */
   private String filterMapping;

   /**
    * Documentaci�.
    */
   private UrlPathHelper urlPathHelper = new UrlPathHelper();

   /**
    * Documentaci�.
    */
   private boolean isInitialized = false;

   /**
    * Documentaci�.
    */
   private int order;

   /**
    * Documentaci�.
    *
    * @param uri Documentaci�
    *
    * @return Documentaci�
    */
   private boolean matches(String uri) {
      for (Iterator iter = urlPatternList.iterator(); iter.hasNext();) {
         String pattern = (String) iter.next();
         pattern = (pattern.startsWith("/") ? "" : "/") + pattern;

         if (this.pathMatcher.match(pattern, uri)) {
            return true;
         }
      }

      return false;
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param response Documentaci�
    * @param arg2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    * @throws ServletException Documentaci�
    */
   public boolean preHandle(HttpServletRequest request,
      HttpServletResponse response, final Object arg2)
      throws Exception {
      boolean wasRedirected;

      if (request instanceof PortletServletRequestWrapper) {
         if (!isInitialized && (config != null)) {
            config.setServletContext(request.getSession().getServletContext());
            filter.init(config);
            isInitialized = true;
         }

         String lookupPath = request.getRequestURI()
                                    .replaceFirst(request.getContextPath(), "");

         if (matches(lookupPath)) {
            filter.doFilter(request, response,
               new FilterChain() {
                  public void doFilter(ServletRequest request,
                     ServletResponse response)
                     throws IOException, ServletException {
                     if (nextInterceptor != null) {
                        try {
                           nextInterceptor.preHandle((HttpServletRequest) request,
                              (HttpServletResponse) response, arg2);
                        } catch (Exception e) {
                           throw new ServletException(e);
                        }
                     }
                  }
               });
         } else {
            if (nextInterceptor != null) {
               try {
                  nextInterceptor.preHandle((HttpServletRequest) request,
                     (HttpServletResponse) response, arg2);
               } catch (Exception e) {
                  throw new ServletException(e);
               }
            }
         }

         return true;
      }

      return super.preHandle(request, response, arg2);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Filter getFilter() {
      return filter;
   }

   /**
    * Documentaci�.
    *
    * @param filter Documentaci�
    */
   public void setFilter(Filter filter) {
      this.filter = filter;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getFilterMapping() {
      return filterMapping;
   }

   /**
    * Documentaci�.
    *
    * @param filterMapping Documentaci�
    */
   public void setFilterMapping(String filterMapping) {
      this.filterMapping = filterMapping;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Class getFilterClass() {
      return filterClass;
   }

   /**
    * Documentaci�.
    *
    * @param filterClass Documentaci�
    */
   public void setFilterClass(Class filterClass) {
      this.filterClass = filterClass;
   }

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   public void afterPropertiesSet() throws Exception {
      if ((filter == null) && (filterClass != null)) {
         filter = (Filter) filterClass.newInstance();
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public FilterInterceptorConfig getConfig() {
      return config;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public HashMap getConfigMap() {
      return configMap;
   }

   /**
    * Documentaci�.
    *
    * @param configMap Documentaci�
    */
   public void setConfigMap(HashMap configMap) {
      this.configMap = configMap;
      config.setParameterMap(configMap);
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param response Documentaci�
    * @param handler Documentaci�
    * @param modelAndView Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void postHandle(HttpServletRequest request,
      HttpServletResponse response, Object handler, ModelAndView modelAndView)
      throws Exception {
      // TODO Auto-generated method stub
      super.postHandle(request, response, handler, modelAndView);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public HandlerInterceptor getNextInterceptor() {
      return nextInterceptor;
   }

   /**
    * Documentaci�.
    *
    * @param nextInterceptor Documentaci�
    */
   public void setNextInterceptor(HandlerInterceptor nextInterceptor) {
      this.nextInterceptor = nextInterceptor;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getOrder() {
      return order;
   }

   /**
    * Documentaci�.
    *
    * @param order Documentaci�
    */
   public void setOrder(int order) {
      this.order = order;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List getUrlPatternList() {
      return urlPatternList;
   }

   /**
    * Documentaci�.
    *
    * @param urlPatternList Documentaci�
    */
   public void setUrlPatternList(List urlPatternList) {
      this.urlPatternList = urlPatternList;
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.2 $
     */
   private static class FilterInterceptorConfig implements FilterConfig {
      /**
       * Documentaci�.
       */
      private HashMap parameterMap = new HashMap();

      /**
       * Documentaci�.
       */
      private ServletContext servletContext;

      /**
       * Documentaci�.
       */
      private String filterName;

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public String getFilterName() {
         return filterName;
      }

      /**
       * Documentaci�.
       *
       * @param name Documentaci�
       *
       * @return Documentaci�
       */
      public String getInitParameter(String name) {
         return (String) parameterMap.get(name);
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public Enumeration getInitParameterNames() {
         Enumeration enu = new Enumeration() {
               Iterator iterator = parameterMap.keySet().iterator();

               public boolean hasMoreElements() {
                  return iterator.hasNext();
               }

               public Object nextElement() {
                  // TODO Auto-generated method stub
                  return iterator.next();
               }
            };

         return enu;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public ServletContext getServletContext() {
         return servletContext;
      }

      /**
       * Documentaci�.
       *
       * @return Documentaci�
       */
      public HashMap getParameterMap() {
         return parameterMap;
      }

      /**
       * Documentaci�.
       *
       * @param parameterMap Documentaci�
       */
      public void setParameterMap(HashMap parameterMap) {
         this.parameterMap = parameterMap;
      }

      /**
       * Documentaci�.
       *
       * @param filterName Documentaci�
       */
      public void setFilterName(String filterName) {
         this.filterName = filterName;
      }

      /**
       * Documentaci�.
       *
       * @param servletContext Documentaci�
       */
      public void setServletContext(ServletContext servletContext) {
         this.servletContext = servletContext;
      }
   }
}
