/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.portlets.struts;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import java.net.InetAddress;

import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.PageContext;

import net.gencat.ctti.canigo.services.portlets.utils.UrlMatcher;

import org.apache.portals.bridges.struts.PortletServletResponseWrapper;
import org.apache.portals.bridges.struts.StrutsPortlet;
import org.apache.portals.bridges.struts.StrutsPortletURL;
import org.apache.portals.bridges.struts.config.PortletURLTypes;
import org.apache.portals.bridges.struts.config.PortletURLTypes.URLType;
import org.apache.portals.bridges.struts.config.StrutsPortletConfig;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class WrappedHttpServletResponse implements HttpServletResponse {
   /**
    * Documentaci�.
    */
   public static final Pattern interceptImgPattern = Pattern.compile(
         "(<img[^>]*src=['\"])([^\"]*)(['\"][^>]*/>)");

   /**
    * Documentaci�.
    */
   public static final Pattern interceptHrefPattern = Pattern.compile(
         "(<a[^>]*href=['\"])([^\"]*)(['\"][^>]*>)");

   /**
    * Documentaci�.
    */
   public static final Pattern interceptActionPattern = Pattern.compile(
         "(<form[^>]*action=['\"])([^\"]*)(['\"][^>]*>)");

   /**
    * Documentaci�.
    */
   public static final Pattern urlPattern = Pattern.compile(
         "(<form[^>]*action=['\"])([^\"]*)(['\"][^>]*>)");

   /**
    * Documentaci�.
    */
   private ByteArrayOutputStream bout = new ByteArrayOutputStream();

   /**
    * Documentaci�.
    */
   private HttpServletRequest request;

   /**
    * Documentaci�.
    */
   private HttpServletResponse wrappedResponse;

   /**
    * Documentaci�.
    */
   private PortletUrlTypeResolver defaultRenderTypeResolver = new PortletUrlTypeResolver() {
         public URLType getType(HttpServletRequest request, String url) {
            return PortletURLTypes.URLType.RENDER;
         }
      };

   /**
    * Documentaci�.
    */
   private PortletUrlTypeResolver defaultResourceTypeResolver = new PortletUrlTypeResolver() {
         public URLType getType(HttpServletRequest request, String url) {
            return PortletURLTypes.URLType.RESOURCE;
         }
      };

   /**
    * Documentaci�.
    */
   private PortletUrlTypeResolver urlTypeResolver;

   /**
    * Documentaci�.
    */
   private ServletOutputStream sout = new ServletOutputStream() {
         public void write(int b) throws IOException {
            if (!wasRedirected) {
               bout.write(b);
            }
         }

         public void close() throws IOException {
            if (wasRedirected) {
               if (wrappedResponse.getWriter() != null) {
                  //wrappedResponse.getWriter().write("<html><body><script>function doRedirect(){document.location.href=\""+redirectLocation+"\";}</script><a href='javascript:doRedirect()'>doredirect</a></body></html>");
                  wrappedResponse.getWriter()
                                 .write("<html><body onload=\"doRedirect()\"><script>function doRedirect(){document.location.href=\"" +
                     redirectLocation + "\";}</script></body></html>");
               }

               super.close();

               return;
            }

            String s = bout.toString();

            // Iterator it = new RETokenizer(s, interceptImgPattern, 1, false);
            // while (it.hasNext())
            // {
            // String theUrl = (String) it.next();
            // //s.replace(theUlr, TagsSuppo
            // s.replace(theUrl, getContextRelativeURL(request, theUrl, true));
            // }
            //			
            // it = new RETokenizer(s, interceptHrefPattern, 1, false);
            // while (it.hasNext())
            // {
            // String theUrl = (String) it.next();
            // //s.replace(theUlr, TagsSuppo
            // if(!theUrl.startsWith("javascript:")){
            // s = s.replace(theUrl, getContextRelativeURL(request, theUrl,
            // true));
            // }
            // }
            //		
            //			Matcher m = interceptImgPattern.matcher(s);
            //			StringBuffer sb = new StringBuffer();
            //			doReplacement(m, sb,urlTypeResolver==null?defaultResourceTypeResolver:urlTypeResolver);
            Matcher m = interceptHrefPattern.matcher(s);

            StringBuffer sb2 = new StringBuffer();
            doReplacement(m, sb2,
               (urlTypeResolver == null) ? defaultRenderTypeResolver
                                         : urlTypeResolver);
            //sb.setLength(0);
            m = interceptActionPattern.matcher(sb2);

            StringBuffer sb3 = new StringBuffer();
            doReplacement(m, sb3,
               (urlTypeResolver == null) ? defaultRenderTypeResolver
                                         : urlTypeResolver);

            if (wrappedResponse.getWriter() != null) {
               wrappedResponse.getWriter().write(sb3.toString());
            }

            super.close();
            bout = new ByteArrayOutputStream();
         }
      };

   /**
    * Documentaci�.
    */
   private PrintWriter writer = new PrintWriter(sout);

   /**
    * Documentaci�.
    */
   private String redirectLocation;

   /**
    * Documentaci�.
    */
   private boolean wasRedirected;

   //<form action="/portlets-web-test/j_acegi_security_check" method="post">
   /**
    * Creates a new WrappedHttpServletResponse object.
    *
    * @param request DOCUMENT ME.
    * @param response DOCUMENT ME.
    */
   public WrappedHttpServletResponse(HttpServletRequest request,
      HttpServletResponse response) {
      this.wrappedResponse = response;
      this.request = request;
      initUrlTypeResolver(request);

      // TODO Auto-generated constructor stub
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    */
   public static HttpServletResponse ensureWrappedResponse(
      HttpServletRequest request, HttpServletResponse response) {
      if ((request.getAttribute("__already_wrapped_response__") != null) ||
            response instanceof WrappedHttpServletResponse) {
         return response;
      }

      WrappedHttpServletResponse wrapper = new WrappedHttpServletResponse(request,
            response);
      request.setAttribute("__already_wrapped_response__", wrapper);

      return wrapper;
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    */
   public static HttpServletResponse getWrappedResponse(
      HttpServletRequest request, HttpServletResponse response) {
      return (HttpServletResponse) request.getAttribute(
         "__already_wrapped_response__");
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    */
   private void initUrlTypeResolver(HttpServletRequest request) {
      WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(request.getSession()
                                                                                                 .getServletContext());
      Map resolvers = context.getBeansOfType(PortletUrlTypeResolver.class);

      if (resolvers.size() > 0) {
         urlTypeResolver = (PortletUrlTypeResolver) resolvers.values().iterator()
                                                             .next();
      }
   }

   /**
    * Documentaci�.
    *
    * @param m Documentaci�
    * @param sb Documentaci�
    * @param resolver Documentaci�
    */
   private void doReplacement(Matcher m, StringBuffer sb,
      PortletUrlTypeResolver resolver) {
      while (m.find()) {
         String theMatch = m.group(2);

         if (!theMatch.startsWith("javascript:")) {
            String theReplacement;
            URLType theType = resolver.getType(request, theMatch);

            if (theType == null) {
               //no type ergo no replacement
               theReplacement = theMatch;
            } else {
               theReplacement = WrappedHttpServletResponse.getURL(request,
                     theMatch, theType);
            }

            m.appendReplacement(sb, "$1" + theReplacement + "$3");
         }
      }

      m.appendTail(sb);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public PrintWriter getWriter() throws IOException {
      // TODO Auto-generated method stub
      return writer;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public ServletOutputStream getOutputStream() throws IOException {
      return sout;
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param url Documentaci�
    * @param addContextPath Documentaci�
    *
    * @return Documentaci�
    */
   public static String getContextRelativeURL(HttpServletRequest request,
      String url, boolean addContextPath) {
      if (!url.startsWith("/") && !url.startsWith(request.getContextPath())) {
         String newUrl = url;
         String currentPath = (String) request.getAttribute(StrutsPortlet.PAGE_URL);

         if (addContextPath) {
            currentPath = request.getContextPath() + currentPath;
         }

         if (addContextPath || (currentPath.length() > 1)) {
            currentPath = currentPath.substring(0, currentPath.lastIndexOf('/'));
         }

         if (currentPath.length() == 0) {
            currentPath = "/";
         }

         while (currentPath.length() > 0) {
            if (newUrl.startsWith("../")) {
               currentPath = currentPath.substring(0,
                     currentPath.lastIndexOf('/'));
               newUrl = newUrl.substring(3);
            } else {
               break;
            }
         }

         if (currentPath.length() > 1) {
            url = currentPath + "/" + newUrl;
         } else {
            url = "/" + newUrl;
         }
      }

      return url;
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param url Documentaci�
    * @param type Documentaci�
    *
    * @return Documentaci�
    */
   public static String getURL(HttpServletRequest request, String url,
      PortletURLTypes.URLType type) {
      url = getContextRelativeURL(request, url, false);

      String contextPath = request.getContextPath();

      if (url.startsWith(contextPath + "/")) {
         url = url.substring(contextPath.length());
      }

      if (type == null) {
         StrutsPortletConfig strutsPortletConfig = (StrutsPortletConfig) request.getSession()
                                                                                .getServletContext()
                                                                                .getAttribute(StrutsPortlet.STRUTS_PORTLET_CONFIG);
         type = strutsPortletConfig.getPortletURLTypes().getType(url);
      }

      if (type.equals(PortletURLTypes.URLType.ACTION)) {
         return StrutsPortletURL.createActionURL(request, url).toString();
      } else if (type.equals(PortletURLTypes.URLType.RENDER)) {
         return StrutsPortletURL.createRenderURL(request, url).toString();
      } else // type.equals(PortletURLTypes.URLType.RESOURCE)
       {
         if (url.startsWith("/")) {
            return contextPath + url;
         }

         return contextPath + "/" + url;
      }
   }

   /**
    * Documentaci�.
    *
    * @param cookie Documentaci�
    */
   public void addCookie(Cookie cookie) {
      wrappedResponse.addCookie(cookie);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param date Documentaci�
    */
   public void addDateHeader(String name, long date) {
      wrappedResponse.addDateHeader(name, date);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param value Documentaci�
    */
   public void addHeader(String name, String value) {
      wrappedResponse.addHeader(name, value);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param value Documentaci�
    */
   public void addIntHeader(String name, int value) {
      wrappedResponse.addIntHeader(name, value);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    *
    * @return Documentaci�
    */
   public boolean containsHeader(String name) {
      return wrappedResponse.containsHeader(name);
   }

   /**
    * Documentaci�.
    *
    * @param url Documentaci�
    *
    * @return Documentaci�
    */
   public String encodeRedirectUrl(String url) {
      return wrappedResponse.encodeRedirectUrl(url);
   }

   /**
    * Documentaci�.
    *
    * @param url Documentaci�
    *
    * @return Documentaci�
    */
   public String encodeRedirectURL(String url) {
      return wrappedResponse.encodeRedirectURL(url);
   }

   /**
    * Documentaci�.
    *
    * @param url Documentaci�
    *
    * @return Documentaci�
    */
   public String encodeUrl(String url) {
      return wrappedResponse.encodeUrl(url);
   }

   /**
    * Documentaci�.
    *
    * @param url Documentaci�
    *
    * @return Documentaci�
    */
   public String encodeURL(String url) {
      return wrappedResponse.encodeURL(url);
   }

   /**
    * Documentaci�.
    *
    * @throws IOException Documentaci�
    */
   public void flushBuffer() throws IOException {
      writer.close();
      wrappedResponse.flushBuffer();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getBufferSize() {
      return wrappedResponse.getBufferSize();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getContentType() {
      return wrappedResponse.getContentType();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getCharacterEncoding() {
      return wrappedResponse.getCharacterEncoding();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Locale getLocale() {
      return wrappedResponse.getLocale();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isCommitted() {
      return wrappedResponse.isCommitted();
   }

   /**
    * Documentaci�.
    */
   public void reset() {
      wrappedResponse.reset();
   }

   /**
    * Documentaci�.
    */
   public void resetBuffer() {
      wrappedResponse.resetBuffer();
   }

   /**
    * Documentaci�.
    *
    * @param sc Documentaci�
    * @param msg Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void sendError(int sc, String msg) throws IOException {
      wrappedResponse.sendError(sc, msg);
   }

   /**
    * Documentaci�.
    *
    * @param sc Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void sendError(int sc) throws IOException {
      wrappedResponse.sendError(sc);
   }

   /**
    * Documentaci�.
    *
    * @param location Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void sendRedirect(String location) throws IOException {
      wasRedirected = true;
      redirectLocation = location;

      UrlMatcher matcher = new UrlMatcher(location);

      if (matcher.isLocalUrl()) {
         redirectLocation = getURL(request, matcher.getRelativePath(),
               getUrlTypeResolver().getType(request, matcher.getRelativePath()));
      }
   }

   /**
    * Documentaci�.
    *
    * @param size Documentaci�
    */
   public void setBufferSize(int size) {
      wrappedResponse.setBufferSize(size);
   }

   /**
    * Documentaci�.
    *
    * @param len Documentaci�
    */
   public void setContentLength(int len) {
      wrappedResponse.setContentLength(len);
   }

   /**
    * Documentaci�.
    *
    * @param type Documentaci�
    */
   public void setContentType(String type) {
      wrappedResponse.setContentType(type);
   }

   /**
    * Documentaci�.
    *
    * @param charset Documentaci�
    */
   public void setCharacterEncoding(String charset) {
      wrappedResponse.setCharacterEncoding(charset);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param date Documentaci�
    */
   public void setDateHeader(String name, long date) {
      wrappedResponse.setDateHeader(name, date);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param value Documentaci�
    */
   public void setHeader(String name, String value) {
      wrappedResponse.setHeader(name, value);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param value Documentaci�
    */
   public void setIntHeader(String name, int value) {
      wrappedResponse.setIntHeader(name, value);
   }

   /**
    * Documentaci�.
    *
    * @param loc Documentaci�
    */
   public void setLocale(Locale loc) {
      wrappedResponse.setLocale(loc);
   }

   /**
    * Documentaci�.
    *
    * @param sc Documentaci�
    * @param sm Documentaci�
    */
   public void setStatus(int sc, String sm) {
      wrappedResponse.setStatus(sc, sm);
   }

   /**
    * Documentaci�.
    *
    * @param sc Documentaci�
    */
   public void setStatus(int sc) {
      wrappedResponse.setStatus(sc);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public PortletUrlTypeResolver getUrlTypeResolver() {
      return urlTypeResolver;
   }

   /**
    * Documentaci�.
    *
    * @param urlTypeResolver Documentaci�
    */
   public void setUrlTypeResolver(PortletUrlTypeResolver urlTypeResolver) {
      this.urlTypeResolver = urlTypeResolver;
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.2 $
     */
   public interface PortletUrlTypeResolver {
      /**
       * Documentaci�.
       *
       * @param request Documentaci�
       * @param url Documentaci�
       *
       * @return Documentaci�
       */
      public PortletURLTypes.URLType getType(HttpServletRequest request,
         String url);
   }
}


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
class RETokenizer implements Iterator {
   // Holds the original input to search for tokens
   /**
    * Documentaci�.
    */
   private CharSequence input;

   // Used to find tokens
   /**
    * Documentaci�.
    */
   private Matcher matcher;

   // The current delimiter value. If non-null, should be returned
   /**
    * Documentaci�.
    */
   private String delim;

   // The current matched value. If non-null and delim=null,
   /**
    * Documentaci�.
    */
   private String match;

   // If true, the String between tokens are returned
   /**
    * Documentaci�.
    */
   private boolean returnDelims;

   // The value of matcher.end() from the last successful match.
   /**
    * Documentaci�.
    */
   private int lastEnd = 0;

   /**
    * Documentaci�.
    */
   private int selectedGroup = 0;

   /**
    * Creates a new RETokenizer object.
    *
    * @param input DOCUMENT ME.
    * @param patternStr DOCUMENT ME.
    * @param returnDelims DOCUMENT ME.
    */
   public RETokenizer(CharSequence input, String patternStr,
      boolean returnDelims) {
      this(input, patternStr, 0, returnDelims);
   }

   /**
    * Creates a new RETokenizer object.
    *
    * @param input DOCUMENT ME.
    * @param pattern DOCUMENT ME.
    * @param selectedGroup DOCUMENT ME.
    * @param returnDelims DOCUMENT ME.
    */
   public RETokenizer(CharSequence input, Pattern pattern, int selectedGroup,
      boolean returnDelims) {
      // Save values
      this.input = input;
      this.returnDelims = returnDelims;
      this.selectedGroup = selectedGroup;
      // Compile pattern and prepare input
      matcher = pattern.matcher(input);
   }

   // patternStr is a regular expression pattern that identifies tokens.
   /**
    * Creates a new RETokenizer object.
    *
    * @param input DOCUMENT ME.
    * @param patternStr DOCUMENT ME.
    * @param selectedGroup DOCUMENT ME.
    * @param returnDelims DOCUMENT ME.
    */
   public RETokenizer(CharSequence input, String patternStr, int selectedGroup,
      boolean returnDelims) {
      // Save values
      // Compile pattern and prepare input
      this(input, Pattern.compile(patternStr), selectedGroup, returnDelims);
   }

   // Returns true if there are more tokens or delimiters.
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean hasNext() {
      if (matcher == null) {
         return false;
      }

      if ((delim != null) || (match != null)) {
         return true;
      }

      if (matcher.find()) {
         if (returnDelims) {
            delim = input.subSequence(lastEnd, matcher.start()).toString();
         }

         match = matcher.group(selectedGroup);
         lastEnd = matcher.end();
      } else if (returnDelims && (lastEnd < input.length())) {
         delim = input.subSequence(lastEnd, input.length()).toString();
         lastEnd = input.length();

         // Need to remove the matcher since it appears to automatically
         // reset itself once it reaches the end.
         matcher = null;
      }

      return (delim != null) || (match != null);
   }

   // Returns the next token (or delimiter if returnDelims is true).
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Object next() {
      String result = null;

      if (delim != null) {
         result = delim;
         delim = null;
      } else if (match != null) {
         result = match;
         match = null;
      }

      return result;
   }

   // Returns true if the call to next() will return a token rather
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isNextToken() {
      return (delim == null) && (match != null);
   }

   // Not supported.
   /**
    * Documentaci�.
    */
   public void remove() {
      throw new UnsupportedOperationException();
   }
}
