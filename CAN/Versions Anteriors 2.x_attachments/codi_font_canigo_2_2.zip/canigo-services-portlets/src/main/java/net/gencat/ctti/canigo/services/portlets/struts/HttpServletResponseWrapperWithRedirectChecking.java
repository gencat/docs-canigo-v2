/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.portlets.struts;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.portals.bridges.struts.PortletServletResponseWrapper;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class HttpServletResponseWrapperWithRedirectChecking
   extends PortletServletResponseWrapper {
   /**
    * Documentaci�.
    */
   private HttpServletRequest request;

   /**
    * Documentaci�.
    */
   private HttpServletResponse response;

   /**
    * Documentaci�.
    */
   private String currentRedirect;

   /**
    * Documentaci�.
    */
   private boolean wasRedirected;

   /**
    * Creates a new HttpServletResponseWrapperWithRedirectChecking object.
    *
    * @param request DOCUMENT ME.
    * @param response DOCUMENT ME.
    */
   public HttpServletResponseWrapperWithRedirectChecking(
      HttpServletRequest request, HttpServletResponse response) {
      super(request, response);
      this.request = request;
      this.response = response;
   }

   /**
    * Documentaci�.
    *
    * @param location Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void sendRedirect(String location) throws IOException {
      wasRedirected = true;
      currentRedirect = location;
      super.sendRedirect(location);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isWasRedirected() {
      return wasRedirected;
   }

   /**
    * Documentaci�.
    *
    * @param wasRedirected Documentaci�
    */
   public void setWasRedirected(boolean wasRedirected) {
      this.wasRedirected = wasRedirected;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getCurrentRedirect() {
      return currentRedirect;
   }

   /**
    * Documentaci�.
    *
    * @param currentRedirect Documentaci�
    */
   public void setCurrentRedirect(String currentRedirect) {
      this.currentRedirect = currentRedirect;
   }

   /**
    * Documentaci�.
    *
    * @throws ServletException Documentaci�
    * @throws IOException Documentaci�
    */
   public void doRedirect() throws ServletException, IOException {
      String redirect = getCurrentRedirect();
      redirect = redirect.substring(redirect.lastIndexOf("/"));
      request.setAttribute("__acegi_session_integration_filter_applied", null);
      //request.setAttribute("javax.portlet.request",null);
      request.getRequestDispatcher(redirect).forward(request, getResponse());
   }
}
