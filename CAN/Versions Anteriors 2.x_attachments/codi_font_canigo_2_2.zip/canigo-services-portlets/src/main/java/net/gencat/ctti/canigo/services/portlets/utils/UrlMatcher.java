/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.portlets.utils;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class UrlMatcher {
   /**
    * Documentaci�.
    */
   public static Pattern urlPattern = Pattern.compile(
         "([^:]+)://([^:/]+)(:([0-9]+))?(/[^/]*)?(.*)");

   /**
    * Documentaci�.
    */
   private Matcher m;

   /**
    * Documentaci�.
    */
   private String url;

   /**
    * Creates a new UrlMatcher object.
    *
    * @param url DOCUMENT ME.
    */
   public UrlMatcher(String url) {
      super();
      this.url = url;
      m = urlPattern.matcher(url);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isValid() {
      return m.matches();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getProtocol() {
      if (isValid()) {
         return evalMatch(1);
      }

      return "";
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getHost() {
      if (isValid()) {
         return evalMatch(2);
      }

      return "";
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getContextPath() {
      if (isValid()) {
         return evalMatch(5);
      }

      return "";
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getPort() {
      if (isValid()) {
         return evalMatch(4);
      }

      return "";
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getRelativePath() {
      if (isValid()) {
         return evalMatch(6);
      }

      return "";
   }

   /**
    * Documentaci�.
    *
    * @param position Documentaci�
    *
    * @return Documentaci�
    */
   private String evalMatch(int position) {
      return (m.group(position) == null) ? "" : m.group(position);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws MalformedURLException Documentaci�
    */
   private URL toUrl() throws MalformedURLException {
      if (getPort() != "") {
         return new URL(getProtocol(), getHost(), Integer.parseInt(getPort()),
            getContextPath() + getRelativePath());
      } else {
         return new URL(getProtocol(), getHost(),
            getContextPath() + getRelativePath());
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isLocalUrl() {
      if (isValid()) {
         try {
            return InetAddress.getByName(getHost()).isLoopbackAddress() ||
            InetAddress.getByName(getHost()).isSiteLocalAddress();
         } catch (UnknownHostException e) {
         }
      }

      return false;
   }
}
