/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.portlets.struts;

import java.io.IOException;
import java.io.PrintWriter;

import java.util.Locale;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class HttpServletResponseWrapper implements javax.servlet.http.HttpServletResponse {
   /**
    * Documentaci�.
    */
   private HttpServletResponse response;

   /**
    * Creates a new HttpServletResponseWrapper object.
    *
    * @param response DOCUMENT ME.
    */
   public HttpServletResponseWrapper(HttpServletResponse response) {
      this.response = response;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public HttpServletResponse getResponse() {
      return response;
   }

   /**
    * Documentaci�.
    *
    * @param cookie Documentaci�
    */
   public void addCookie(Cookie cookie) {
      response.addCookie(cookie);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param date Documentaci�
    */
   public void addDateHeader(String name, long date) {
      response.addDateHeader(name, date);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param value Documentaci�
    */
   public void addHeader(String name, String value) {
      response.addHeader(name, value);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param value Documentaci�
    */
   public void addIntHeader(String name, int value) {
      response.addIntHeader(name, value);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    *
    * @return Documentaci�
    */
   public boolean containsHeader(String name) {
      return response.containsHeader(name);
   }

   /**
    * Documentaci�.
    *
    * @param url Documentaci�
    *
    * @return Documentaci�
    */
   public String encodeRedirectUrl(String url) {
      return response.encodeRedirectUrl(url);
   }

   /**
    * Documentaci�.
    *
    * @param url Documentaci�
    *
    * @return Documentaci�
    */
   public String encodeRedirectURL(String url) {
      return response.encodeRedirectURL(url);
   }

   /**
    * Documentaci�.
    *
    * @param url Documentaci�
    *
    * @return Documentaci�
    */
   public String encodeUrl(String url) {
      return response.encodeUrl(url);
   }

   /**
    * Documentaci�.
    *
    * @param url Documentaci�
    *
    * @return Documentaci�
    */
   public String encodeURL(String url) {
      return response.encodeURL(url);
   }

   /**
    * Documentaci�.
    *
    * @throws IOException Documentaci�
    */
   public void flushBuffer() throws IOException {
      response.flushBuffer();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getBufferSize() {
      return response.getBufferSize();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getContentType() {
      return response.getContentType();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getCharacterEncoding() {
      return response.getCharacterEncoding();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Locale getLocale() {
      return response.getLocale();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public ServletOutputStream getOutputStream() throws IOException {
      return response.getOutputStream();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public PrintWriter getWriter() throws IOException {
      return response.getWriter();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isCommitted() {
      return response.isCommitted();
   }

   /**
    * Documentaci�.
    */
   public void reset() {
      response.reset();
   }

   /**
    * Documentaci�.
    */
   public void resetBuffer() {
      response.resetBuffer();
   }

   /**
    * Documentaci�.
    *
    * @param sc Documentaci�
    * @param msg Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void sendError(int sc, String msg) throws IOException {
      response.sendError(sc, msg);
   }

   /**
    * Documentaci�.
    *
    * @param sc Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void sendError(int sc) throws IOException {
      response.sendError(sc);
   }

   /**
    * Documentaci�.
    *
    * @param location Documentaci�
    *
    * @throws IOException Documentaci�
    */
   public void sendRedirect(String location) throws IOException {
      response.sendRedirect(location);
   }

   /**
    * Documentaci�.
    *
    * @param size Documentaci�
    */
   public void setBufferSize(int size) {
      response.setBufferSize(size);
   }

   /**
    * Documentaci�.
    *
    * @param len Documentaci�
    */
   public void setContentLength(int len) {
      response.setContentLength(len);
   }

   /**
    * Documentaci�.
    *
    * @param type Documentaci�
    */
   public void setContentType(String type) {
      response.setContentType(type);
   }

   /**
    * Documentaci�.
    *
    * @param charset Documentaci�
    */
   public void setCharacterEncoding(String charset) {
      response.setCharacterEncoding(charset);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param date Documentaci�
    */
   public void setDateHeader(String name, long date) {
      response.setDateHeader(name, date);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param value Documentaci�
    */
   public void setHeader(String name, String value) {
      response.setHeader(name, value);
   }

   /**
    * Documentaci�.
    *
    * @param name Documentaci�
    * @param value Documentaci�
    */
   public void setIntHeader(String name, int value) {
      response.setIntHeader(name, value);
   }

   /**
    * Documentaci�.
    *
    * @param loc Documentaci�
    */
   public void setLocale(Locale loc) {
      response.setLocale(loc);
   }

   /**
    * Documentaci�.
    *
    * @param sc Documentaci�
    * @param sm Documentaci�
    */
   public void setStatus(int sc, String sm) {
      response.setStatus(sc, sm);
   }

   /**
    * Documentaci�.
    *
    * @param sc Documentaci�
    */
   public void setStatus(int sc) {
      response.setStatus(sc);
   }
}
