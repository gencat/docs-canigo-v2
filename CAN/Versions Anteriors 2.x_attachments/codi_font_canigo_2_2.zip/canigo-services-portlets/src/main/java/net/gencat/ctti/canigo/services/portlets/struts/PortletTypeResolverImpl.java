/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.portlets.struts;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import net.gencat.ctti.canigo.services.portlets.struts.WrappedHttpServletResponse.PortletUrlTypeResolver;

import org.apache.portals.bridges.struts.config.PortletURLTypes.URLType;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;
import org.springframework.web.util.UrlPathHelper;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.2 $
  */
public class PortletTypeResolverImpl implements PortletUrlTypeResolver {
   /**
    * Documentaci�.
    */
   private List actionMappingsList;

   /**
    * Documentaci�.
    */
   private List nonPortletUrls = Collections.EMPTY_LIST;

   /**
    * Documentaci�.
    */
   private PathMatcher pathMatcher = new AntPathMatcher();

   /**
    * Documentaci�.
    */
   private UrlPathHelper urlPathHelper = new UrlPathHelper();

   /**
    * Documentaci�.
    *
    * @param uri Documentaci�
    *
    * @return Documentaci�
    */
   private boolean matches(String uri) {
      for (Iterator iter = actionMappingsList.iterator(); iter.hasNext();) {
         String pattern = (String) iter.next();
         pattern = (pattern.startsWith("/") ? "" : "/") + pattern;

         if (this.pathMatcher.match(pattern, uri)) {
            return true;
         }
      }

      return false;
   }

   /**
    * Documentaci�.
    *
    * @param uri Documentaci�
    *
    * @return Documentaci�
    */
   private boolean excluded(String uri) {
      for (Iterator iter = nonPortletUrls.iterator(); iter.hasNext();) {
         String pattern = (String) iter.next();
         pattern = (pattern.startsWith("/") ? "" : "/") + pattern;

         if (this.pathMatcher.match(pattern, uri)) {
            return true;
         }
      }

      return false;
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param url Documentaci�
    *
    * @return Documentaci�
    */
   private String getPath(HttpServletRequest request, String url) {
      if (url == null) {
         return urlPathHelper.getLookupPathForRequest(request);
      } else {
         return url.replaceFirst(request.getContextPath(), "");
      }
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param url Documentaci�
    *
    * @return Documentaci�
    */
   public URLType getType(HttpServletRequest request, String url) {
      String currentPath = getPath(request, url);

      if (excluded(currentPath)) {
         return null;
      }

      if (this.actionMappingsList != null) {
         if (matches(currentPath)) {
            return URLType.ACTION;
         }
      }

      return URLType.RENDER;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List getActionMappings() {
      return actionMappingsList;
   }

   /**
    * Documentaci�.
    *
    * @param actionMappings Documentaci�
    */
   public void setActionMappings(List actionMappings) {
      this.actionMappingsList = actionMappings;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List getNonPortletUrls() {
      return nonPortletUrls;
   }

   /**
    * Documentaci�.
    *
    * @param nonPortletUrls Documentaci�
    */
   public void setNonPortletUrls(List nonPortletUrls) {
      this.nonPortletUrls = nonPortletUrls;
   }
}
