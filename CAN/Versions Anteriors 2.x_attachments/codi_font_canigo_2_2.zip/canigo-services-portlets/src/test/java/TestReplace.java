/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.StringReader;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import junit.framework.TestCase;

import net.gencat.ctti.canigo.services.portlets.struts.WrappedHttpServletResponse;
import net.gencat.ctti.canigo.services.portlets.utils.UrlMatcher;

import org.apache.portals.bridges.struts.StrutsPortlet;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.util.ResourceUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.5 $
  */
public class TestReplace extends TestCase {
   /**
    * Documentaci�.
    */
   MockHttpServletRequest request;

   /**
    * Documentaci�.
    */
   MockHttpServletResponse response;

   /**
    * Documentaci�.
    */
   StringBuffer sampleHTML;

   /**
    * Documentaci�.
    *
    * @throws Exception Documentaci�
    */
   protected void setUp() throws Exception {
      // TODO Auto-generated method stub
      super.setUp();
      request = new MockHttpServletRequest();
      request.setContextPath("/testContextPath");
      request.setAttribute(StrutsPortlet.PAGE_URL, "/test.do");
      response = new MockHttpServletResponse();
      sampleHTML = new StringBuffer();

      File f = ResourceUtils.getFile("classpath:exemple.html");
      BufferedReader reader = new BufferedReader(new FileReader(f));
      String line;

      while ((line = reader.readLine()) != null) {
         sampleHTML.append(line);
      }
   }

   /**
    * Documentaci�.
    */
   public void _testReplace1() {
      Matcher m = WrappedHttpServletResponse.interceptHrefPattern.matcher(sampleHTML);
      StringBuffer sb = new StringBuffer();
      doReplacement(m, sb);
      System.out.println(sb);
   }

   /**
    * Documentaci�.
    */
   public void testUrlMatcher() {
      UrlMatcher matcher = new UrlMatcher(
            "http://localhost:8080/context/relative");
      assertEquals(true, matcher.isValid());
      assertEquals("localhost", matcher.getHost());
      assertEquals("8080", matcher.getPort());
      assertEquals("/context", matcher.getContextPath());
      assertEquals("/relative", matcher.getRelativePath());
   }

   /**
    * Documentaci�.
    */
   public void testUrlMatcher2() {
      UrlMatcher matcher = new UrlMatcher("http://localhost/context/");
      assertEquals(true, matcher.isValid());
      assertEquals("localhost", matcher.getHost());
      assertEquals("", matcher.getPort());
      assertEquals("/context", matcher.getContextPath());
      assertEquals("/", matcher.getRelativePath());
   }

   /**
    * Documentaci�.
    *
    * @param m Documentaci�
    * @param sb Documentaci�
    */
   private void doReplacement(Matcher m, StringBuffer sb) {
      while (m.find()) {
         String theMatch = m.group(2);

         if (!theMatch.startsWith("javascript:")) {
            String theReplacement = WrappedHttpServletResponse.getContextRelativeURL(request,
                  theMatch, true);
            m.appendReplacement(sb, "$1" + theReplacement + "$3");
         }
      }

      m.appendTail(sb);
   }
}
