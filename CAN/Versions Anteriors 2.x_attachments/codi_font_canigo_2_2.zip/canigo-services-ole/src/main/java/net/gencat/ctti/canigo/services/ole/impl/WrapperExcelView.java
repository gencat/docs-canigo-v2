/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.ole.impl;

import java.io.IOException;

import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.ole.exception.OleServiceException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.LocalizedResourceHelper;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.support.RequestContextUtils;
import org.springframework.web.servlet.view.document.AbstractExcelView;


/**
 * Convenient superclass for Excel document views.
 *
 * <p>Properties:
 * <ul>
 * <li>url (optional): The url of an existing Excel document to pick as a starting point.
 * It is done without localization part nor the ".xls" extension.
 * </ul>
 *
 * <p>The file will be searched with locations in the following order:
 * <ul>
 * <li>[url]_[language]_[country].xls
 * <li>[url]_[language].xls
 * <li>[url].xls
 * </ul>
 *
 * <p>For working with the workbook in the subclass, see
 * <a href="http://jakarta.apache.org/poi/index.html">Jakarta's POI site</a>
 *
 * <p>As an example, you can try this snippet:
 *
 * <pre>
 * protected void buildExcelDocument(
 *     Map model, HSSFWorkbook workbook,
 *     HttpServletRequest request, HttpServletResponse response) {
 *
 *   // Go to the first sheet.
 *   // getSheetAt: only if workbook is created from an existing document
 *          // HSSFSheet sheet = workbook.getSheetAt(0);
 *          HSSFSheet sheet = workbook.createSheet("Spring");
 *          sheet.setDefaultColumnWidth(12);
 *
 *   // Write a text at A1.
 *   HSSFCell cell = getCell(sheet, 0, 0);
 *   setText(cell, "Spring POI test");
 *
 *   // Write the current date at A2.
 *   HSSFCellStyle dateStyle = workbook.createCellStyle();
 *   dateStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy"));
 *   cell = getCell(sheet, 1, 0);
 *   cell.setCellValue(new Date());
 *   cell.setCellStyle(dateStyle);
 *
 *   // Write a number at A3
 *   getCell(sheet, 2, 0).setCellValue(458);
 *
 *   // Write a range of numbers.
 *   HSSFRow sheetRow = sheet.createRow(3);
 *   for (short i = 0; i < 10; i++) {
 *     sheetRow.createCell(i).setCellValue(i * 10);
 *   }
 * }</pre>
 *
 * @author Jean-Pierre Pawlak
 * @author Juergen Hoeller
 */

/**
 * Wrapper for AbstractExcelView
 */
public abstract class WrapperExcelView implements View {
   /**
    * Documentaci�.
    */
   protected String beanList;

   /**
    * Documentaci�.
    */
   WrappedExcelView delegate;

   /**
    * Default Constructor.
    * Sets the content type of the view to "application/vnd.ms-excel".
    */
   public WrapperExcelView() {
      delegate = new WrappedExcelView();
      delegate.setContentType(WrappedExcelView.CONTENT_TYPE);
   }

   /**
    * Set the URL of the Excel workbook source, without localization part nor extension.
    */
   public void setUrl(String url) {
      delegate.url = url;
      delegate.setUrl(url);
   }

   /**
    * Renders the Excel view, given the specified model.
    */
   protected void renderMergedOutputModel(Map model,
      HttpServletRequest request, HttpServletResponse response)
      throws OleServiceException {
      try {
         delegate.wrappedRenderMergedOutputModel(model, request, response);
      } catch (Exception ex) {
         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ole.renderMergedOutputModel.excel",
               args, Layer.SERVICES, Subsystem.OLE_SERVICES);
         exDetails.setProperties(new Properties());
         throw new OleServiceException(ex, exDetails);
      }
   }

   /**
    * Creates the workbook from an existing XLS document.
    * @param url the URL of the Excel template without localization part nor extension
    * @param request current HTTP request
    * @return the HSSFWorkbook
    * @throws Exception in case of failure
    */
   protected HSSFWorkbook getTemplateSource(String url,
      HttpServletRequest request) throws OleServiceException {
      try {
         return delegate.getTemplateSource(url, request);
      } catch (Exception ex) {
         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ole.getTemplateSource",
               args, Layer.SERVICES, Subsystem.OLE_SERVICES);
         exDetails.setProperties(new Properties());
         throw new OleServiceException(ex, exDetails);
      }
   }

   /**
    * Subclasses must implement this method to create an Excel HSSFWorkbook document,
    * given the model.
    * @param model the model Map
    * @param workbook the Excel workbook to complete
    * @param request in case we need locale etc. Shouldn't look at attributes.
    * @param response in case we need to set cookies. Shouldn't write to it.
    */
   protected abstract void wrappedBuildExcelDocument(Map model,
      HSSFWorkbook workbook, HttpServletRequest request,
      HttpServletResponse response) throws OleServiceException;

   /**
    * Convenient method to obtain the cell in the given sheet, row and column.
    * <p>Creates the row and the cell if they still doesn't already exist.
    * Thus, the column can be passed as an int, the method making the needed downcasts.
    * @param sheet a sheet object. The first sheet is usually obtained by workbook.getSheetAt(0)
    * @param row thr row number
    * @param col the column number
    * @return the HSSFCell
    */
   protected HSSFCell getCell(HSSFSheet sheet, int row, int col) {
      return delegate.getCell(sheet, row, col);
   }

   /**
    * Convenient method to set a String as text content in a cell.
    * @param cell the cell in which the text must be put
    * @param text the text to put in the cell
    */
   protected void setText(HSSFCell cell, String text) {
      delegate.setText(cell, text);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getAttributesMap() {
      return delegate.getAttributesMap();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getBeanName() {
      return delegate.getBeanName();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getContentType() {
      return delegate.getContentType();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getRequestContextAttribute() {
      return delegate.getRequestContextAttribute();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Map getStaticAttributes() {
      return delegate.getStaticAttributes();
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setAttributes(Properties arg0) {
      delegate.setAttributes(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @throws OleServiceException Documentaci�
    */
   public void setAttributesCSV(String arg0) throws OleServiceException {
      try {
         delegate.setAttributesCSV(arg0);
      } catch (Exception ex) {
         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ole.setAttributesCSV",
               args, Layer.SERVICES, Subsystem.OLE_SERVICES);
         exDetails.setProperties(new Properties());
         throw new OleServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setAttributesMap(Map arg0) {
      delegate.setAttributesMap(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setBeanName(String arg0) {
      delegate.setBeanName(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setContentType(String arg0) {
      delegate.setContentType(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    */
   public void setRequestContextAttribute(String arg0) {
      delegate.setRequestContextAttribute(arg0);
   }

   /**
    * Documentaci�.
    *
    * @param model Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @throws OleServiceException Documentaci�
    */
   public void render(Map model, HttpServletRequest request,
      HttpServletResponse response) throws OleServiceException {
      try {
         delegate.render(model, request, response);
      } catch (Exception ex) {
         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ole.render",
               args, Layer.SERVICES, Subsystem.OLE_SERVICES);
         exDetails.setProperties(new Properties());
         throw new OleServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param ac Documentaci�
    */
   public void setApplicationContext(ApplicationContext ac) {
      delegate.setApplicationContext(ac);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getBeanList() {
      return beanList;
   }

   /**
    * Documentaci�.
    *
    * @param beanList Documentaci�
    */
   public void setBeanList(String beanList) {
      this.beanList = beanList;
   }

   /**
    * Documentaci�.
    *
    * @author $author$
    * @version $Revision: 1.5 $
     */
   private class WrappedExcelView extends AbstractExcelView {
      /** The content type for an Excel response */
      private static final String CONTENT_TYPE = "application/vnd.ms-excel";

      /** The extension to look for existing templates */
      private static final String EXTENSION = ".xls";

      /**
       * Documentaci�.
       */
      private String url;

      /**
       * Convenient method to set a String as text content in a cell.
       * @param cell the cell in which the text must be put
       * @param text the text to put in the cell
       */
      protected void setText(HSSFCell cell, String text) {
         cell.setCellType(HSSFCell.CELL_TYPE_STRING);
         cell.setCellValue(text);
      }

      /**
       * Convenient method to obtain the cell in the given sheet, row and column.
       * <p>Creates the row and the cell if they still doesn't already exist.
       * Thus, the column can be passed as an int, the method making the needed downcasts.
       * @param sheet a sheet object. The first sheet is usually obtained by workbook.getSheetAt(0)
       * @param row thr row number
       * @param col the column number
       * @return the HSSFCell
       */
      protected HSSFCell getCell(HSSFSheet sheet, int row, int col) {
         HSSFRow sheetRow = sheet.getRow(row);

         if (sheetRow == null) {
            sheetRow = sheet.createRow(row);
         }

         HSSFCell cell = sheetRow.getCell((short) col);

         if (cell == null) {
            cell = sheetRow.createCell((short) col);
         }

         return cell;
      }

      /**
       * Renders the Excel view, given the specified model.
       */
      protected void wrappedRenderMergedOutputModel(Map model,
         HttpServletRequest request, HttpServletResponse response)
         throws Exception {
         HSSFWorkbook workbook;

         if (delegate.url != null) {
            workbook = getTemplateSource(delegate.url, request);
         } else {
            workbook = new HSSFWorkbook();
         }

         buildExcelDocument(model, workbook, request, response);

         // response.setContentLength(workbook.getBytes().length);
         response.setContentType(getContentType());

         ServletOutputStream out = response.getOutputStream();
         workbook.write(out);
         out.flush();
      }

      /**
       * Creates the workbook from an existing XLS document.
       * @param url the URL of the Excel template without localization part nor extension
       * @param request current HTTP request
       * @return the HSSFWorkbook
       * @throws IOException
       */
      protected HSSFWorkbook getTemplateSource(String url,
         HttpServletRequest request) throws IOException {
         LocalizedResourceHelper helper = new LocalizedResourceHelper(getApplicationContext());
         Locale userLocale = RequestContextUtils.getLocale(request);

         // Delete extension if exists and it's equals than variable "EXTENSION"
         if ((url.indexOf(".") != -1) &&
               EXTENSION.equals(url.substring(url.lastIndexOf("."), url.length()))) {
            url = url.substring(0, url.lastIndexOf("."));
         }

         Resource inputFile = helper.findLocalizedResource(url, EXTENSION,
               userLocale);

         // Create the Excel document from the source.
         POIFSFileSystem fs = new POIFSFileSystem(inputFile.getInputStream());
         HSSFWorkbook workBook = new HSSFWorkbook(fs);

         return workBook;
      }

      /**
       * Documentaci�.
       *
       * @param model Documentaci�
       * @param workbook Documentaci�
       * @param request Documentaci�
       * @param response Documentaci�
       */
      protected void buildExcelDocument(Map model, HSSFWorkbook workbook,
         HttpServletRequest request, HttpServletResponse response) {
         wrappedBuildExcelDocument(model, workbook, request, response);
      }
   }
}
