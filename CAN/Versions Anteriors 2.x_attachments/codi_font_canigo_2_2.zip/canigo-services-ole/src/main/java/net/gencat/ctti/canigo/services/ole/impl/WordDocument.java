/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.ole.impl;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;

import java.util.Iterator;
import java.util.Properties;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.ole.exception.OleServiceException;

import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.model.CHPBinTable;
import org.apache.poi.hwpf.model.ComplexFileTable;
import org.apache.poi.hwpf.model.DocumentProperties;
import org.apache.poi.hwpf.model.FileInformationBlock;
import org.apache.poi.hwpf.model.FontTable;
import org.apache.poi.hwpf.model.GenericPropertyNode;
import org.apache.poi.hwpf.model.ListTables;
import org.apache.poi.hwpf.model.PAPBinTable;
import org.apache.poi.hwpf.model.PlexOfCps;
import org.apache.poi.hwpf.model.PropertyNode;
import org.apache.poi.hwpf.model.SectionTable;
import org.apache.poi.hwpf.model.StyleSheet;
import org.apache.poi.hwpf.model.TextPiece;
import org.apache.poi.hwpf.model.TextPieceTable;
import org.apache.poi.hwpf.model.io.HWPFFileSystem;
import org.apache.poi.hwpf.model.io.HWPFOutputStream;
import org.apache.poi.hwpf.usermodel.HWPFList;
import org.apache.poi.hwpf.usermodel.Range;
import org.apache.poi.poifs.common.POIFSConstants;
import org.apache.poi.poifs.filesystem.DocumentEntry;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;


/**
 *
 * This class acts as the bucket that we throw all of the Word data structures
 * into.
 *
 * @author Ryan Ackley
 */
public class WordDocument extends HWPFDocument {
   /** Contains formatting properties for text*/
   protected CHPBinTable _cbt;

   /** Contains text of the document wrapped in a obfuscated Word data
    * structure*/
   protected ComplexFileTable _cft;

   /** Document wide Properties*/
   protected DocumentProperties _dop;

   /** The FIB*/
   protected FileInformationBlock _fib;

   /** Holds fonts for this document.*/
   protected FontTable _ft;

   /** Hold list tables */
   protected ListTables _lt;

   /** Contains formatting properties for paragraphs*/
   protected PAPBinTable _pbt;

   /** Contains formatting properties for sections.*/
   protected SectionTable _st;

   /** Holds styles for this document.*/
   protected StyleSheet _ss;

   /**
    * Documentaci�.
    */
   protected TextPieceTable _tpt;

   /** data stream buffer*/
   protected byte[] _dataStream;

   /** main document stream buffer*/
   private byte[] _mainStream;

   /** table stream buffer*/
   private byte[] _tableStream;

   /**
    * Creates a new WordDocument object.
    */
   protected WordDocument() {
   }

   /**
    * This constructor loads a Word document from an InputStream.
    *
    * @param istream The InputStream that contains the Word document.
    * @throws OleServiceException If there is an unexpected IOException from the passed
    *         in InputStream.
    */
   public WordDocument(InputStream istream) throws OleServiceException {
      try {
         // do Ole stuff
         POIFSFileSystem filesystem = new POIFSFileSystem(istream);

         // read in the main stream.
         DocumentEntry documentProps = (DocumentEntry) filesystem.getRoot()
                                                                 .getEntry("WordDocument");
         _mainStream = new byte[documentProps.getSize()];
         filesystem.createDocumentInputStream("WordDocument").read(_mainStream);

         // use the fib to determine the name of the table stream.
         _fib = new FileInformationBlock(_mainStream);

         String name = "0Table";

         if (_fib.isFWhichTblStm()) {
            name = "1Table";
         }

         // read in the table stream.
         DocumentEntry tableProps = (DocumentEntry) filesystem.getRoot()
                                                              .getEntry(name);
         _tableStream = new byte[tableProps.getSize()];
         filesystem.createDocumentInputStream(name).read(_tableStream);

         _fib.fillVariableFields(_mainStream, _tableStream);

         // read in the data stream.
         try {
            DocumentEntry dataProps = (DocumentEntry) filesystem.getRoot()
                                                                .getEntry("Data");
            _dataStream = new byte[dataProps.getSize()];
            filesystem.createDocumentInputStream("Data").read(_dataStream);
         } catch (java.io.FileNotFoundException e) {
            _dataStream = new byte[0];
         }

         // get the start of text in the main stream
         int fcMin = _fib.getFcMin();

         // load up our standard structures.
         _dop = new DocumentProperties(_tableStream, _fib.getFcDop());
         _cft = new ComplexFileTable(_mainStream, _tableStream,
               _fib.getFcClx(), fcMin);
         _tpt = _cft.getTextPieceTable();
         _cbt = new CHPBinTable(_mainStream, _tableStream,
               _fib.getFcPlcfbteChpx(), _fib.getLcbPlcfbteChpx(), fcMin);
         _pbt = new PAPBinTable(_mainStream, _tableStream, _dataStream,
               _fib.getFcPlcfbtePapx(), _fib.getLcbPlcfbtePapx(), fcMin);

         // Word XP puts in a zero filled buffer in front of the text and it
         // screws
         // up my system for offsets. This is an adjustment.
         int cpMin = _tpt.getCpMin();

         if (cpMin > 0) {
            _cbt.adjustForDelete(0, 0, cpMin);
            _pbt.adjustForDelete(0, 0, cpMin);
         }

         _st = new SectionTable(_mainStream, _tableStream, _fib.getFcPlcfsed(),
               _fib.getLcbPlcfsed(), fcMin, getTextTable().getTextPieces());
         _ss = new StyleSheet(_tableStream, _fib.getFcStshf());
         _ft = new FontTable(_tableStream, _fib.getFcSttbfffn(),
               _fib.getLcbSttbfffn());

         int listOffset = _fib.getFcPlcfLst();
         int lfoOffset = _fib.getFcPlfLfo();

         if ((listOffset != 0) && (_fib.getLcbPlcfLst() != 0)) {
            _lt = new ListTables(_tableStream, _fib.getFcPlcfLst(),
                  _fib.getFcPlfLfo());
         }

         PlexOfCps plc = new PlexOfCps(_tableStream, _fib.getFcPlcffldMom(),
               _fib.getLcbPlcffldMom(), 2);

         for (int x = 0; x < plc.length(); x++) {
            GenericPropertyNode node = plc.getProperty(x);
            byte[] fld = node.getBytes();
            int breakpoint = 0;
         }
      } catch (Exception ex) {
         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ole.WordDocument",
               args, Layer.SERVICES, Subsystem.OLE_SERVICES);
         exDetails.setProperties(new Properties());
         throw new OleServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public StyleSheet getStyleSheet() {
      return _ss;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public FileInformationBlock getFileInformationBlock() {
      return _fib;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public DocumentProperties getDocProperties() {
      return _dop;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Range getRange() {
      // hack to get the ending cp of the document, Have to revisit this.
      java.util.List text = _tpt.getTextPieces();
      PropertyNode p = (PropertyNode) text.get(text.size() - 1);

      return new Range(0, p.getEnd(), this);
   }

   /**
    * Returns the character length of a document.
    * @return the character length of a document
    */
   public int characterLength() {
      java.util.List textPieces = _tpt.getTextPieces();
      Iterator textIt = textPieces.iterator();

      int length = 0;

      while (textIt.hasNext()) {
         TextPiece tp = (TextPiece) textIt.next();
         length += tp.characterLength();
      }

      return length;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ListTables getListTables() {
      return _lt;
   }

   /**
    * Writes out the word file that is represented by an instance of this class.
    *
    * @param out The OutputStream to write to.
    * @throws OleServiceException If there is an unexpected IOException from the passed
    *         in OutputStream.
    */
   public void write(OutputStream out) throws OleServiceException {
      try {
         // initialize our streams for writing.
         HWPFFileSystem docSys = new HWPFFileSystem();
         HWPFOutputStream mainStream = docSys.getStream("WordDocument");
         HWPFOutputStream tableStream = docSys.getStream("1Table");
         HWPFOutputStream dataStream = docSys.getStream("Data");
         int tableOffset = 0;

         // FileInformationBlock fib = (FileInformationBlock)_fib.clone();
         // clear the offsets and sizes in our FileInformationBlock.
         _fib.clearOffsetsSizes();

         // determine the FileInformationBLock size
         int fibSize = _fib.getSize();
         fibSize += (POIFSConstants.BIG_BLOCK_SIZE -
         (fibSize % POIFSConstants.BIG_BLOCK_SIZE));

         // preserve space for the FileInformationBlock because we will be writing
         // it after we write everything else.
         byte[] placeHolder = new byte[fibSize];
         mainStream.write(placeHolder);

         int mainOffset = mainStream.getOffset();

         // write out the StyleSheet.
         _fib.setFcStshf(tableOffset);
         _ss.writeTo(tableStream);
         _fib.setLcbStshf(tableStream.getOffset() - tableOffset);
         tableOffset = tableStream.getOffset();

         // get fcMin and fcMac because we will be writing the actual text with the
         // complex table.
         int fcMin = mainOffset;

         // write out the Complex table, includes text.
         _fib.setFcClx(tableOffset);
         _cft.writeTo(docSys);
         _fib.setLcbClx(tableStream.getOffset() - tableOffset);
         tableOffset = tableStream.getOffset();

         int fcMac = mainStream.getOffset();

         // write out the CHPBinTable.
         _fib.setFcPlcfbteChpx(tableOffset);
         _cbt.writeTo(docSys, fcMin);
         _fib.setLcbPlcfbteChpx(tableStream.getOffset() - tableOffset);
         tableOffset = tableStream.getOffset();

         // write out the PAPBinTable.
         _fib.setFcPlcfbtePapx(tableOffset);
         _pbt.writeTo(docSys, fcMin);
         _fib.setLcbPlcfbtePapx(tableStream.getOffset() - tableOffset);
         tableOffset = tableStream.getOffset();

         // write out the SectionTable.
         _fib.setFcPlcfsed(tableOffset);
         _st.writeTo(docSys, fcMin);
         _fib.setLcbPlcfsed(tableStream.getOffset() - tableOffset);
         tableOffset = tableStream.getOffset();

         // write out the list tables
         if (_lt != null) {
            _fib.setFcPlcfLst(tableOffset);
            //      _lt.writeListDataTo(tableStream);
            _fib.setLcbPlcfLst(tableStream.getOffset() - tableOffset);

            _fib.setFcPlfLfo(tableStream.getOffset());
            _lt.writeListOverridesTo(tableStream);
            _fib.setLcbPlfLfo(tableStream.getOffset() - tableOffset);
            tableOffset = tableStream.getOffset();
         }

         // write out the FontTable.
         _fib.setFcSttbfffn(tableOffset);
         _ft.writeTo(docSys);
         _fib.setLcbSttbfffn(tableStream.getOffset() - tableOffset);
         tableOffset = tableStream.getOffset();

         // write out the DocumentProperties.
         _fib.setFcDop(tableOffset);

         byte[] buf = new byte[_dop.getSize()];
         _fib.setLcbDop(_dop.getSize());
         _dop.serialize(buf, 0);
         tableStream.write(buf);

         // set some variables in the FileInformationBlock.
         _fib.setFcMin(fcMin);
         _fib.setFcMac(fcMac);
         _fib.setCbMac(mainStream.getOffset());

         // make sure that the table, doc and data streams use big blocks.
         byte[] mainBuf = mainStream.toByteArray();

         if (mainBuf.length < 4096) {
            byte[] tempBuf = new byte[4096];
            System.arraycopy(mainBuf, 0, tempBuf, 0, mainBuf.length);
            mainBuf = tempBuf;
         }

         // write out the FileInformationBlock.
         //_fib.serialize(mainBuf, 0);
         _fib.writeTo(mainBuf, tableStream);

         byte[] tableBuf = tableStream.toByteArray();

         if (tableBuf.length < 4096) {
            byte[] tempBuf = new byte[4096];
            System.arraycopy(tableBuf, 0, tempBuf, 0, tableBuf.length);
            tableBuf = tempBuf;
         }

         byte[] dataBuf = _dataStream;

         if (dataBuf == null) {
            dataBuf = new byte[4096];
         }

         if (dataBuf.length < 4096) {
            byte[] tempBuf = new byte[4096];
            System.arraycopy(dataBuf, 0, tempBuf, 0, dataBuf.length);
            dataBuf = tempBuf;
         }

         // spit out the Word document.
         POIFSFileSystem pfs = new POIFSFileSystem();

         pfs.createDocument(new ByteArrayInputStream(mainBuf), "WordDocument");
         pfs.createDocument(new ByteArrayInputStream(tableBuf), "1Table");
         pfs.createDocument(new ByteArrayInputStream(dataBuf), "Data");

         pfs.writeFilesystem(out);
      } catch (Exception ex) {
         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ole.write",
               args, Layer.SERVICES, Subsystem.OLE_SERVICES);
         exDetails.setProperties(new Properties());
         throw new OleServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public CHPBinTable getCharacterTable() {
      return _cbt;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public PAPBinTable getParagraphTable() {
      return _pbt;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public SectionTable getSectionTable() {
      return _st;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public TextPieceTable getTextTable() {
      return _cft.getTextPieceTable();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public byte[] getDataStream() {
      return _dataStream;
   }

   /**
    * Documentaci�.
    *
    * @param list Documentaci�
    *
    * @return Documentaci�
    */
   public int registerList(HWPFList list) {
      if (_lt == null) {
         _lt = new ListTables();
      }

      return _lt.addList(list.getListData(), list.getOverride());
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public FontTable getFontTable() {
      return _ft;
   }

   /**
    * Documentaci�.
    *
    * @param start Documentaci�
    * @param length Documentaci�
    */
   public void delete(int start, int length) {
      Range r = new Range(start, start + length, this);
      r.delete();
   }
}
