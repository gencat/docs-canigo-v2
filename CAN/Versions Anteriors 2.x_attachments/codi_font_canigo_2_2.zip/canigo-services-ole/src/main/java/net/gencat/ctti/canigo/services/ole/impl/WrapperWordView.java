/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.ole.impl;

import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.ole.exception.OleServiceException;

import org.apache.poi.hwpf.usermodel.CharacterProperties;
import org.apache.poi.hwpf.usermodel.ParagraphProperties;
import org.apache.poi.hwpf.usermodel.Range;
import org.apache.poi.hwpf.usermodel.TableProperties;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.LocalizedResourceHelper;
import org.springframework.web.servlet.support.RequestContextUtils;
import org.springframework.web.servlet.view.AbstractView;


/**
 * Convenient superclass for Word document views.
 *
 * <p>Properties:
 * <ul>
 * <li>url (optional): The url of an existing Word document to pick as a starting point.
 * It is done without localization part nor the ".doc" extension.
 * </ul>
 *
 * <p>The file will be searched with locations in the following order:
 * <ul>
 * <li>[url]_[language]_[country].doc
 * <li>[url]_[language].doc
 * <li>[url].doc
 * </ul>
 *
 * <p>For working with the workbook in the subclass, see
 * <a href="http://jakarta.apache.org/poi/index.html">Jakarta's POI site</a>
 *
 * <p>As an example, you can try this snippet:
 *
 * <pre>
 *                         protected void wrappedBuildWordDocument(Map model,
 *                                                                                                        WordDocument wordDocument,
 *                                                                                                        HttpServletRequest request,
 *                                                                                                        HttpServletResponse response)
 *                                        throws OleServiceException {
 *                                CharacterProperties props = new CharacterProperties();
 *
 *                                for (int currentRow=0; currentRow<3; currentRow++) {
 *                                        props = new CharacterProperties();
 *
 *                                        if (currentRow%2 == 0) {
 *                                                props.setBold(true);
 *                                        } else {
 *                                                props.setItalic(true);
 *                                        }
 *
 *                                        String text = "canigo - id: "+currentRow+" size: "+(currentRow*10)+"\r\n";
 *                                        insertAfter(wordDocument, text, props);
 *                                }
 *                        }
 *
 * </pre>
 *
 * This class is similar to the WrapperExcelView class in usage style.
 *
 * @author Eusebi Collell
 * @see WrapperExcelView
 */
public abstract class WrapperWordView extends AbstractView {
   /** The content type for an Word response */
   private static final String CONTENT_TYPE = "application/vnd.ms-word";

   /** The extension to look for existing templates */
   private static final String EXTENSION = ".doc";

   /**
    * Documentaci�.
    */
   private static String WORD_TEMPLATE = "/WEB-INF/classes/ole/template";

   /**
    * Documentaci�.
    */
   protected String beanList;

   /**
    * Documentaci�.
    */
   private String url;

   /**
    * Default Constructor.
    * Sets the content type of the view to "application/vnd.ms-word".
    */
   public WrapperWordView() {
      setContentType(CONTENT_TYPE);
   }

   /**
    * Set the URL of the Word source, without localization part nor extension.
    */
   public void setUrl(String url) {
      this.url = url;
   }

   /**
    * Renders the Word view, given the specified model.
    */
   protected final void renderMergedOutputModel(Map model,
      HttpServletRequest request, HttpServletResponse response)
      throws OleServiceException {
      try {
         WordDocument wordDocument;
         String urlDoc = "";

         if (this.url != null) {
            urlDoc = this.url;
         } else {
            // Empty file
            urlDoc = WORD_TEMPLATE;
         }

         wordDocument = getTemplateSource(urlDoc, request);

         wrappedBuildWordDocument(model, wordDocument, request, response);

         response.setContentType(getContentType());

         ServletOutputStream out = response.getOutputStream();
         wordDocument.write(out);

         out.flush();
      } catch (Exception ex) {
         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ole.renderMergedOutputModel.word",
               args, Layer.SERVICES, Subsystem.OLE_SERVICES);
         exDetails.setProperties(new Properties());
         throw new OleServiceException(ex, exDetails);
      }
   }

   /**
    * Creates the WordDocument from an existing DOC document.
    *
    * @param url the URL of the Word without localization part nor extension
    * @param request current HTTP request
    * @return the WordDocument
    * @throws Exception in case of failure
    */
   protected WordDocument getTemplateSource(String url,
      HttpServletRequest request) throws OleServiceException {
      try {
         LocalizedResourceHelper helper = new LocalizedResourceHelper(getApplicationContext());
         Locale userLocale = RequestContextUtils.getLocale(request);

         // Delete extension if exists and it's equals than variable "EXTENSION"
         if ((url.indexOf(".") != -1) &&
               EXTENSION.equals(url.substring(url.lastIndexOf("."), url.length()))) {
            url = url.substring(0, url.lastIndexOf("."));
         }

         Resource inputFile = helper.findLocalizedResource(url, EXTENSION,
               userLocale);

         WordDocument wordDocument = new WordDocument(inputFile.getInputStream());

         return wordDocument;
      } catch (Exception ex) {
         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ole.getTemplateSource",
               args, Layer.SERVICES, Subsystem.OLE_SERVICES);
         exDetails.setProperties(new Properties());
         throw new OleServiceException(ex, exDetails);
      }
   }

   /**
    * Subclasses must implement this method to create an Word WordDocument document,
    * given the model.
    * @param model the model Map
    * @param WordDocument Word document
    * @param request in case we need locale etc. Shouldn't look at attributes.
    * @param response in case we need to set co    java.util.List listText = _tpt.getTextPieces();
    */
   protected abstract void wrappedBuildWordDocument(Map model,
      WordDocument wordDocument, HttpServletRequest request,
      HttpServletResponse response) throws OleServiceException;

   /**
    * Convenient method to set a String as text content
    * @param WordDocument Word document
    * @param text the text to put in the document
    */
   protected void insertAfter(WordDocument wordDocument, String text) {
      Range range = getRange(wordDocument);
      range.insertAfter(text);
   }

   /**
    * Convenient method to set a String as text content
    * @param WordDocument Word document
    * @param text the text to put in the document
    * @param props the CharacterProperties to give de text
    */
   protected void insertAfter(WordDocument wordDocument, String text,
      CharacterProperties props) {
      Range range = getRange(wordDocument);
      range.insertAfter(text, props);
   }

   /**
    * Convenient method to set a String as text content
    * @param WordDocument Word document
    * @param text the text to put in the document
    */
   protected void insertBefore(WordDocument wordDocument, String text) {
      Range range = getRange(wordDocument);
      range.insertBefore(text);
   }

   /**
    * Convenient method to set a String as text content
    * @param WordDocument Word document
    * @param text the text to put in the document
    * @param props the CharacterProperties to give de text
    */
   protected void insertBefore(WordDocument wordDocument, String text,
      CharacterProperties props) {
      Range range = getRange(wordDocument);
      range.insertBefore(text, props);
   }

   /**
    * Inserts and empty paragraph into the front of this range.
    * @param WordDocument Word document
    * @param props The properties that the new paragraph will have.
    * @param styleIndex The index into the stylesheet for the new paragraph.
    */
   protected void insertBefore(WordDocument wordDocument,
      ParagraphProperties props, int styleIndex) {
      Range range = getRange(wordDocument);
      range.insertBefore(props, styleIndex);
   }

   /**
    * Inserts and empty paragraph into the end of this range.
    * @param WordDocument Word document
    * @param props The properties that the new paragraph will have.
    * @param styleIndex The index into the stylesheet for the new paragraph.
    */
   public void insertAfter(WordDocument wordDocument,
      ParagraphProperties props, int styleIndex) {
      Range range = getRange(wordDocument);
      range.insertAfter(props, styleIndex);
   }

   /**
    * Inserts a simple table into the beginning of this range. The number of
    * columns is determined by the TableProperties passed into this function.
    * @param WordDocument Word document
    * @param props The table properties for the table.
    * @param rows The number of rows.
    */
   public void insertBefore(WordDocument wordDocument, TableProperties props,
      int rows) {
      Range range = getRange(wordDocument);
      range.insertBefore(props, rows);
   }

   /**
    * Inserts a list into the beginning of this range.
    * @param WordDocument Word document
    * @param props The properties of the list entry. All list entries are paragraphs.
    * @param listID The id of the list that contains the properties.
    * @param level The indentation level of the list.
    * @param styleIndex The base style's index in the stylesheet.
    */
   public void insertBefore(WordDocument wordDocument,
      ParagraphProperties props, int listID, int level, int styleIndex) {
      Range range = getRange(wordDocument);
      range.insertBefore(props, listID, level, styleIndex);
   }

   /**
    * Inserts a list into the beginning of this range.
    * @param WordDocument Word document
    * @param props The properties of the list entry. All list entries are paragraphs.
    * @param listID The id of the list that contains the properties.
    * @param level The indentation level of the list.
    * @param styleIndex The base style's index in the stylesheet.
    */
   public void insertAfter(WordDocument wordDocument,
      ParagraphProperties props, int listID, int level, int styleIndex) {
      Range range = getRange(wordDocument);
      range.insertAfter(props, listID, level, styleIndex);
   }

   /**
    * Convenient method to get document content as String
    *
    * @param WordDocument Word document
    * @return String with document content
    */
   public String getText(WordDocument wordDocument) throws OleServiceException {
      try {
         Range range = new Range(0, wordDocument.characterLength(), wordDocument);

         return range.text();
      } catch (Exception ex) {
         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ole.getText",
               args, Layer.SERVICES, Subsystem.OLE_SERVICES);
         exDetails.setProperties(new Properties());
         throw new OleServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getBeanList() {
      return beanList;
   }

   /**
    * Documentaci�.
    *
    * @param beanList Documentaci�
    */
   public void setBeanList(String beanList) {
      this.beanList = beanList;
   }

   /**
    * Documentaci�.
    *
    * @param wordDocument Documentaci�
    *
    * @return Documentaci�
    */
   protected Range getRange(WordDocument wordDocument) {
      return new Range(0, wordDocument.characterLength(), wordDocument);
   }
}
