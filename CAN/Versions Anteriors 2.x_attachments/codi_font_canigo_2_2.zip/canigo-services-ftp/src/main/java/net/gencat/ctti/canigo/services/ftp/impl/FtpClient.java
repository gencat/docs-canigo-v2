/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.ftp.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.util.Properties;

import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.ftp.FtpClientIF;
import net.gencat.ctti.canigo.services.ftp.exception.FtpServiceException;
import net.gencat.ctti.canigo.services.logging.LoggingService;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;


/**
 * @author Eusebi Collell
 */
public class FtpClient implements FtpClientIF {
   /**
    * Documentaci�.
    */
   public int ASCII_FILE_TYPE = FTP.ASCII_FILE_TYPE;

   /**
    * Documentaci�.
    */
   public int BINARY_FILE_TYPE = FTP.BINARY_FILE_TYPE;

   /**
    * Documentaci�.
    */
   public int IMAGE_FILE_TYPE = FTP.IMAGE_FILE_TYPE;

   /**
    * Documentaci�.
    */
   protected FTPClient delegate;

   /**
    * Documentaci�.
    */
   protected LoggingService logService;

   /**
    * Creates a new FtpClient object.
    */
   public FtpClient() {
      delegate = new FTPClient();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isConnected() {
      return delegate.isConnected();
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean setFileType(int arg0) throws FtpServiceException {
      try {
         return delegate.setFileType(arg0);
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.changeWorkingDirectory",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean changeWorkingDirectory(String arg0)
      throws FtpServiceException {
      try {
         return delegate.changeWorkingDirectory(arg0);
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { arg0 };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.changeWorkingDirectory",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean deleteFile(String arg0) throws FtpServiceException {
      try {
         return delegate.deleteFile(arg0);
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { arg0 };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.deleteFile",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @throws FtpServiceException Documentaci�
    */
   public void disconnect() throws FtpServiceException {
      try {
         delegate.disconnect();
      } catch (IOException ex) {
         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.disconnect",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public FTPFile[] listFiles() throws FtpServiceException {
      try {
         return delegate.listFiles();
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.listFiles",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public String[] listNames() throws FtpServiceException {
      try {
         return delegate.listNames();
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.listNames",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public String[] listNames(String arg0) throws FtpServiceException {
      try {
         return delegate.listNames(arg0);
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.listNames",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param username Documentaci�
    * @param password Documentaci�
    * @param host Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean login(String username, String password, String host)
      throws FtpServiceException {
      try {
         boolean isLoged = false;

         delegate.connect(host);

         if (delegate.isConnected()) {
            isLoged = delegate.login(username, password);
         }

         return isLoged;
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.login",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean logout() throws FtpServiceException {
      try {
         return delegate.logout();
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.logout",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean makeDirectory(String arg0) throws FtpServiceException {
      try {
         return delegate.makeDirectory(arg0);
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { arg0 };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.makeDirectory",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean retrieveFile(String arg0, OutputStream arg1)
      throws FtpServiceException {
      try {
         return delegate.retrieveFile(arg0, arg1);
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { arg0 };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.retrieveFile",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public InputStream retrieveFileStream(String arg0)
      throws FtpServiceException {
      try {
         return delegate.retrieveFileStream(arg0);
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { arg0 };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.retrieveFileStream",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean storeFile(String arg0, InputStream arg1)
      throws FtpServiceException {
      try {
         return delegate.storeFile(arg0, arg1);
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { arg0 };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.storeFile",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public int pasv() throws FtpServiceException {
      try {
         return delegate.pasv();
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.pasv",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public int sendCommand(String arg0) throws FtpServiceException {
      try {
         return delegate.sendCommand(arg0);
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { arg0 };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.sendCommand",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public int sendCommand(String arg0, String arg1) throws FtpServiceException {
      try {
         return delegate.sendCommand(arg0, arg1);
      } catch (IOException ex) {
         if (delegate.isConnected()) {
            disconnect();
         }

         String[] args = { arg0 };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.ftp.FtpClient.sendCommand",
               args, Layer.SERVICES, Subsystem.FTP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new FtpServiceException(ex, exDetails);
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * Documentaci�.
    *
    * @param logService Documentaci�
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }
}
