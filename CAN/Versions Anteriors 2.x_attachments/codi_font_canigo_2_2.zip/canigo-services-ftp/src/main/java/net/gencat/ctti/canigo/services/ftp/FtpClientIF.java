/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.ftp;

import java.io.InputStream;
import java.io.OutputStream;

import net.gencat.ctti.canigo.services.ftp.exception.FtpServiceException;
import net.gencat.ctti.canigo.services.logging.LoggingService;

import org.apache.commons.net.ftp.FTPFile;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public interface FtpClientIF {
   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isConnected();

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean setFileType(int arg0) throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean changeWorkingDirectory(String arg0)
      throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean deleteFile(String arg0) throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @throws FtpServiceException Documentaci�
    */
   public void disconnect() throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public FTPFile[] listFiles() throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public String[] listNames() throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public String[] listNames(String arg0) throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    * @param arg2 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean login(String arg0, String arg1, String arg2)
      throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean logout() throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean makeDirectory(String arg0) throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean retrieveFile(String arg0, OutputStream arg1)
      throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public InputStream retrieveFileStream(String arg0)
      throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public boolean storeFile(String arg0, InputStream arg1)
      throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public int pasv() throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public int sendCommand(String arg0) throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @param arg0 Documentaci�
    * @param arg1 Documentaci�
    *
    * @return Documentaci�
    *
    * @throws FtpServiceException Documentaci�
    */
   public int sendCommand(String arg0, String arg1) throws FtpServiceException;

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public LoggingService getLogService();

   /**
    * Documentaci�.
    *
    * @param logService Documentaci�
    */
   public void setLogService(LoggingService logService);
}
