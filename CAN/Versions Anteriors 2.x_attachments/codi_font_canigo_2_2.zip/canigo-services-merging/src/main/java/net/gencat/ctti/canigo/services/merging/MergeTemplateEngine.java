/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.merging;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import java.util.List;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public interface MergeTemplateEngine {
   /**
    * Para cada elemento de la lista <code>pDades</code>, este m�todo realiza <br>
    * la fusi�n de la plantilla <code>pTemplate</code> con los datos indicados <br>
    * por el elemento.
    * @param pTemplate Stream con el contenido del documento a fusionar (debe tener formato WordML).
    * @param pDades Lista de datos con los que realizar la fusi�n. Cada elemento de la <br>
    *               lista corresponde a una Map, en la cual tenemos para cada bookmark <br>
    *               el valor por el cual ha de ser reemplazada.
    * @return ByteArrayOutputStream[] Array de Outputs, con el resultado de cada una de las fusiones.
    */
   public ByteArrayOutputStream[] mergeTemplate(InputStream pTemplate,
      List pDades) throws Exception;
}
