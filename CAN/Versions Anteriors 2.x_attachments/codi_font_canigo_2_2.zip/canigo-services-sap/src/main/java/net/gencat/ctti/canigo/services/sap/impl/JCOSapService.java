/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.sap.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import com.sap.mw.jco.IFunctionTemplate;
import com.sap.mw.jco.JCO;

import net.gencat.ctti.canigo.core.util.beanutils.BeanUtils;
import net.gencat.ctti.canigo.services.exceptions.ExceptionDetails;
import net.gencat.ctti.canigo.services.exceptions.Layer;
import net.gencat.ctti.canigo.services.exceptions.Subsystem;
import net.gencat.ctti.canigo.services.logging.Log;
import net.gencat.ctti.canigo.services.logging.LoggingService;
import net.gencat.ctti.canigo.services.sap.SapService;
import net.gencat.ctti.canigo.services.sap.exception.SapServiceException;


/**
 * @author Eusebi Collell
 */
public class JCOSapService implements SapService {
   /**
    * Documentaci�.
    */
   private JCO.Client client = null;

   /**
    * Documentaci�.
    */
   private JCO.Function function = null;

   /**
    * Documentaci�.
    */
   private JCO.Pool pool = null;

   /**
    * Documentaci�.
    */
   private JCO.Repository repository = null;

   /**
    * Documentaci�.
    */
   private JCO.Table table = null;

   /**
    * Documentaci�.
    */
   private JCOSapConfigurator sapConfigurator;

   /**
    * Logging service
    */
   private LoggingService logService = null;

   /**
    * JCOSapService's constructor.
    *
    * @throws SapServiceException
    */
   public JCOSapService() throws SapServiceException {
      try {
         // Connection initialization
         client = null;
         repository = null;

         // pool =
         // JCO.getClientPoolManager().getPool(sapConfigurator.getConnectionPoolName());
      } catch (Exception ex) {
         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.sap.JCOSapService.constructor",
               args, Layer.SERVICES, Subsystem.SAP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SapServiceException(ex, exDetails);
      }
   }

   /**
    * It makes the connection with SAP Java Connector.
    *
    * @return
    */
   public boolean connect() {
      try {
         if (sapConfigurator != null) {
            if (client == null) {
               String missatge = "";

               if (sapConfigurator.isConnectionPool() &&
                     (sapConfigurator.getConnectionPoolName() != null) &&
                     !"".equals(sapConfigurator.getConnectionPoolName())) {
                  pool = JCO.getClientPoolManager()
                            .getPool(sapConfigurator.getConnectionPoolName());

                  // Creates a connection pool
                  if (pool == null) {
                     JCO.addClientPool(sapConfigurator.getConnectionPoolName(),
                        sapConfigurator.getMaxNumConnections(),
                        sapConfigurator.getClient(), sapConfigurator.getUser(),
                        sapConfigurator.getPasswd(), sapConfigurator.getLang(),
                        sapConfigurator.getAshost(), sapConfigurator.getSysnr());
                     pool = JCO.getClientPoolManager()
                               .getPool(sapConfigurator.getConnectionPoolName());
                  }

                  client = JCO.getClient(sapConfigurator.getConnectionPoolName());

                  if ((repository == null) &&
                        (sapConfigurator.getRepository() != null)) {
                     repository = new JCO.Repository(sapConfigurator.getRepository(),
                           sapConfigurator.getConnectionPoolName());
                  }

                  missatge = "Client connect to connection pool " +
                     sapConfigurator.getConnectionPoolName();
               } else {
                  // Creates a direct connection
                  client = JCO.createClient(sapConfigurator.getClient(),
                        sapConfigurator.getUser(), sapConfigurator.getPasswd(),
                        sapConfigurator.getLang(), sapConfigurator.getAshost(),
                        sapConfigurator.getSysnr());
                  client.connect();

                  if ((repository == null) &&
                        (sapConfigurator.getRepository() != null)) {
                     repository = new JCO.Repository(sapConfigurator.getRepository(),
                           client);
                  }

                  missatge = "Client connect ";
               }

               if (getLogService() != null) {
                  Log log = getLogService().getLog(this.getClass().getName());

                  if (log.isDebugEnabled()) {
                     log.debug(missatge);
                  }
               }
            }

            return true;
         } else {
            return false;
         }
      } catch (Exception ex) {
         if (getLogService() != null) {
            String missatge = "Error making connection with SAP Java Connector JCO";
            Log log = getLogService().getLog(this.getClass().getName());

            if (log.isErrorEnabled()) {
               log.error(missatge);
            }
         }

         return false;
      }
   }

   /**
    * It makes the disconnection with SAP Java Connector.
    *
    * @return
    */
   public boolean disconnect() {
      try {
         String missatge = "";

         if (client != null) {
            if (pool != null) {
               pool.detachFromPool(client);
               missatge = "Client disconnect from pool " +
                  sapConfigurator.getConnectionPoolName();
            } else {
               client.disconnect();
               missatge = "Client disconnect ";
            }
         }

         if (getLogService() != null) {
            Log log = getLogService().getLog(this.getClass().getName());

            if (log.isDebugEnabled()) {
               log.debug(missatge);
            }
         }

         return true;
      } catch (Exception ex) {
         if (getLogService() != null) {
            String missatge = "Error making disconnection with SAP Java Connector (JCO)";
            Log log = getLogService().getLog(this.getClass().getName());

            if (log.isErrorEnabled()) {
               log.error(missatge);
            }
         }

         return false;
      }
   }

   /**
    * It makes the template's function BAPI
    *
    * @param Function
    *            BAPI name
    * @return JCO.Function Function BAPI's Instance
    * @throws SapServiceException
    */
   protected JCO.Function createFunction(String functionName)
      throws SapServiceException {
      try {
         IFunctionTemplate ft = repository.getFunctionTemplate(functionName.toUpperCase());

         if (ft != null) {
            return ft.getFunction();
         } else {
            return null;
         }
      } catch (Exception ex) {
         String[] args = { ex.getLocalizedMessage() };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.sap.JCOSapService.createFunction",
               args, Layer.SERVICES, Subsystem.SAP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SapServiceException(ex, exDetails);
      }
   }

   /**
    * Executes a BAPI function
    */
   public Collection executeFunction(String functionName, String sapTable,
      Map importParameters, Class returnClass) {
      boolean isConnectInside = false;
      ArrayList returnArrayList = new ArrayList();

      try {
         if (client == null) {
            isConnectInside = connect();
         }

         if (client != null) {
            function = createFunction(functionName);

            if (function != null) {
               // Fill in input parameters
               JCO.ParameterList input = function.getImportParameterList();

               if ((importParameters != null) && !importParameters.isEmpty()) {
                  Iterator ite = importParameters.keySet().iterator();

                  while (ite.hasNext()) {
                     Object obj = ite.next();

                     if (obj != null) {
                        input.setValue(importParameters.get(obj), obj.toString());
                     }
                  }
               }

               // Execute function
               client.execute(function);

               // Evaluate tableParameters and convert to
               // Collection<returnClass>
               table = null;
               table = function.getTableParameterList().getTable(sapTable);

               for (int i = 0; i < table.getNumRows(); i++) {
                  table.setRow(i);

                  // Bean instance
                  Object bean;
                  bean = Class.forName(returnClass.getName()).newInstance();

                  // Loop over all columns in the current row
                  for (JCO.FieldIterator e = table.fields();
                        e.hasMoreElements();) {
                     JCO.Field field = e.nextField();

                     BeanUtils.copyProperty(bean, field.getName(),
                        getValue(field));

                     if (getLogService() != null) {
                        String missatge = field.getName() + ":\t" +
                           field.getString();
                        Log log = getLogService()
                                     .getLog(this.getClass().getName());

                        if (log.isDebugEnabled()) {
                           log.debug(missatge);
                        }
                     }
                  }

                  returnArrayList.add(bean);
               }

               if (isConnectInside) {
                  disconnect();
               }
            } else {
               if (isConnectInside) {
                  disconnect();
               }
            }
         }
      } catch (Exception ex) {
         String[] args = { functionName };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.sap.JCOSapService.createFunction",
               args, Layer.SERVICES, Subsystem.SAP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SapServiceException(ex, exDetails);
      }

      return returnArrayList;
   }

   /**
    * Executes a BAPI function
    */
   public Collection executeFunction(String functionName, String sapTable,
      String sapTableIN, Map importParameters, Class returnClass) {
      boolean isConnectInside = false;
      ArrayList returnArrayList = new ArrayList();

      try {
         if (client == null) {
            isConnectInside = connect();
         }

         if (client != null) {
            function = createFunction(functionName);

            if (function != null) {
               // Fill in input parameters
               // JCO.ParameterList input =
               // function.getImportParameterList();
               JCO.Table input = function.getTableParameterList()
                                         .getTable(sapTableIN);
               input.appendRow();

               if ((importParameters != null) && !importParameters.isEmpty()) {
                  Iterator ite = importParameters.keySet().iterator();

                  while (ite.hasNext()) {
                     Object obj = ite.next();

                     if (obj != null) {
                        input.setValue(importParameters.get(obj), obj.toString());
                     }
                  }
               }

               // Execute function
               client.execute(function);

               // Evaluate tableParameters and convert to
               // Collection<returnClass>
               table = null;
               table = function.getTableParameterList().getTable(sapTable);

               for (int i = 0; i < table.getNumRows(); i++) {
                  table.setRow(i);

                  // Bean instance
                  Object bean;
                  bean = Class.forName(returnClass.getName()).newInstance();

                  // Loop over all columns in the current row
                  for (JCO.FieldIterator e = table.fields();
                        e.hasMoreElements();) {
                     JCO.Field field = e.nextField();

                     BeanUtils.copyProperty(bean, field.getName(),
                        getValue(field));

                     if (getLogService() != null) {
                        String missatge = field.getName() + ":\t" +
                           field.getString();
                        Log log = getLogService()
                                     .getLog(this.getClass().getName());

                        if (log.isDebugEnabled()) {
                           log.debug(missatge);
                        }
                     }
                  }

                  returnArrayList.add(bean);
               }

               if (isConnectInside) {
                  disconnect();
               }
            } else {
               if (isConnectInside) {
                  disconnect();
               }
            }
         }
      } catch (Exception ex) {
         String[] args = { functionName };
         ExceptionDetails exDetails = new ExceptionDetails("net.gencat.ctti.canigo.services.sap.JCOSapService.createFunction",
               args, Layer.SERVICES, Subsystem.SAP_SERVICES);
         exDetails.setProperties(new Properties());
         throw new SapServiceException(ex, exDetails);
      }

      return returnArrayList;
   }

   /**
    * Documentaci�.
    *
    * @param field Documentaci�
    *
    * @return Documentaci�
    */
   protected Object getValue(JCO.Field field) {
      switch (field.getType()) {
      case JCO.TYPE_INT:
      case JCO.TYPE_INT1:
      case JCO.TYPE_INT2:
         return new Integer(field.getInt());

      case JCO.TYPE_CHAR:
      case JCO.TYPE_NUM:
      case JCO.TYPE_STRING:
         return field.getString();

      case JCO.TYPE_BCD:
         return field.getBigDecimal();

      case JCO.TYPE_DATE:
         return field.getDate();

      case JCO.TYPE_TIME:
         return field.getTime();

      case JCO.TYPE_FLOAT:
         return new Double(field.getDouble());

      case JCO.TYPE_BYTE:
      case JCO.TYPE_XSTRING:
         return field.getByteArray();

      default:
         return field.getString();
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public LoggingService getLogService() {
      return logService;
   }

   /**
    * Documentaci�.
    *
    * @param logService Documentaci�
    */
   public void setLogService(LoggingService logService) {
      this.logService = logService;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public JCOSapConfigurator getSapConfigurator() {
      return sapConfigurator;
   }

   /**
    * Documentaci�.
    *
    * @param sapConfigurator Documentaci�
    */
   public void setSapConfigurator(JCOSapConfigurator sapConfigurator) {
      this.sapConfigurator = sapConfigurator;
   }
}
