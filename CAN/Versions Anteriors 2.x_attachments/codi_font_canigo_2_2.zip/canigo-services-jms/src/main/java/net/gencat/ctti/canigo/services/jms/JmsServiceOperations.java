/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.jms;

import javax.jms.Destination;
import javax.jms.Message;

import net.gencat.ctti.canigo.services.jms.exception.JmsServiceException;


/**
 *
 * Reduced version of Spring's JmsOperations
 *
 * @see org.springframework.jms.core.JmsOperations
 * @see javax.jms.Destination
 * @see javax.jms.Session
 * @see javax.jms.MessageProducer
 * @see javax.jms.MessageConsumer
 */
public interface JmsServiceOperations {
   /**
    * Documentaci�.
    */
   public static final JmsServiceOperations EMPTY_INSTANCE = new JmsServiceOperations() {
         public void convertAndSend(Object message) throws JmsServiceException {
         }

         public void convertAndSend(Destination destination, Object message)
            throws JmsServiceException {
         }

         public void convertAndSend(String destinationName, Object message)
            throws JmsServiceException {
         }

         public Message receive() throws JmsServiceException {
            return null;
         }

         public Message receive(Destination destination)
            throws JmsServiceException {
            return null;
         }

         public Message receive(String destinationName)
            throws JmsServiceException {
            return null;
         }

         public Message receiveSelected(String messageSelector)
            throws JmsServiceException {
            return null;
         }

         public Message receiveSelected(Destination destination,
            String messageSelector) throws JmsServiceException {
            return null;
         }

         public Message receiveSelected(String destinationName,
            String messageSelector) throws JmsServiceException {
            return null;
         }

         public Object receiveAndConvert() throws JmsServiceException {
            return null;
         }

         public Object receiveAndConvert(Destination destination)
            throws JmsServiceException {
            return null;
         }

         public Object receiveAndConvert(String destinationName)
            throws JmsServiceException {
            return null;
         }

         public Object receiveSelectedAndConvert(String messageSelector)
            throws JmsServiceException {
            return null;
         }

         public Object receiveSelectedAndConvert(Destination destination,
            String messageSelector) throws JmsServiceException {
            return null;
         }

         public Object receiveSelectedAndConvert(String destinationName,
            String messageSelector) throws JmsServiceException {
            return null;
         }
      };

   /**
    * Send the given object to the default destination, converting the object
    * to a JMS message with a configured MessageConverter.
    * <p>
    * This will only work with a default destination specified!
    *
    * @param message
    *            the object to convert to a message
    * @throws JmsServiceException
    *             converted checked JMSException to unchecked
    */
   void convertAndSend(Object message) throws JmsServiceException;

   /**
    * Send the given object to the specified destination, converting the object
    * to a JMS message with a configured MessageConverter.
    *
    * @param destination
    *            the destination to send this message to
    * @param message
    *            the object to convert to a message
    * @throws JmsServiceException
    *             converted checked JMSException to unchecked
    */
   void convertAndSend(Destination destination, Object message)
      throws JmsServiceException;

   /**
    * Send the given object to the specified destination, converting the object
    * to a JMS message with a configured MessageConverter.
    *
    * @param destinationName
    *            the name of the destination to send this message to (to be
    *            resolved to an actual destination by a DestinationResolver)
    * @param message
    *            the object to convert to a message
    * @throws JmsServiceException
    *             checked JMSException converted to unchecked
    */
   void convertAndSend(String destinationName, Object message)
      throws JmsServiceException;

   /**
    * Receive a message synchronously from the default destination, but only
    * wait up to a specified time for delivery.
    * <p>
    * This method should be used carefully, since it will block the thread
    * until the message becomes available or until the timeout value is
    * exceeded.
    * <p>
    * This will only work with a default destination specified!
    *
    * @return the message produced for the consumer or <code>null</code> if
    *         the timeout expires.
    * @throws JmsServiceException
    *             checked JMSException converted to unchecked
    */
   Message receive() throws JmsServiceException;

   /**
    * Receive a message synchronously from the specified destination, but only
    * wait up to a specified time for delivery.
    * <p>
    * This method should be used carefully, since it will block the thread
    * until the message becomes available or until the timeout value is
    * exceeded.
    *
    * @param destination
    *            the destination to receive a message from
    * @return the message produced for the consumer or <code>null</code> if
    *         the timeout expires.
    * @throws JmsServiceException
    *             checked JMSException converted to unchecked
    */
   Message receive(Destination destination) throws JmsServiceException;

   /**
    * Receive a message synchronously from the specified destination, but only
    * wait up to a specified time for delivery.
    * <p>
    * This method should be used carefully, since it will block the thread
    * until the message becomes available or until the timeout value is
    * exceeded.
    *
    * @param destinationName
    *            the name of the destination to send this message to (to be
    *            resolved to an actual destination by a DestinationResolver)
    * @return the message produced for the consumer or <code>null</code> if
    *         the timeout expires.
    * @throws JmsServiceException
    *             checked JMSException converted to unchecked
    */
   Message receive(String destinationName) throws JmsServiceException;

   /**
    * Receive a message synchronously from the default destination, but only
    * wait up to a specified time for delivery.
    * <p>
    * This method should be used carefully, since it will block the thread
    * until the message becomes available or until the timeout value is
    * exceeded.
    * <p>
    * This will only work with a default destination specified!
    *
    * @param messageSelector
    *            the JMS message selector expression (or <code>null</code> if
    *            none). See the JMS specification for a detailed definition of
    *            selector expressions.
    * @return the message produced for the consumer or <code>null</code> if
    *         the timeout expires.
    * @throws JmsServiceException
    *             checked JMSException converted to unchecked
    */
   Message receiveSelected(String messageSelector) throws JmsServiceException;

   /**
    * Receive a message synchronously from the specified destination, but only
    * wait up to a specified time for delivery.
    * <p>
    * This method should be used carefully, since it will block the thread
    * until the message becomes available or until the timeout value is
    * exceeded.
    *
    * @param destination
    *            the destination to receive a message from
    * @param messageSelector
    *            the JMS message selector expression (or <code>null</code> if
    *            none). See the JMS specification for a detailed definition of
    *            selector expressions.
    * @return the message produced for the consumer or <code>null</code> if
    *         the timeout expires.
    * @throws JmsServiceException
    *             checked JMSException converted to unchecked
    */
   Message receiveSelected(Destination destination, String messageSelector)
      throws JmsServiceException;

   /**
    * Receive a message synchronously from the specified destination, but only
    * wait up to a specified time for delivery.
    * <p>
    * This method should be used carefully, since it will block the thread
    * until the message becomes available or until the timeout value is
    * exceeded.
    *
    * @param destinationName
    *            the name of the destination to send this message to (to be
    *            resolved to an actual destination by a DestinationResolver)
    * @param messageSelector
    *            the JMS message selector expression (or <code>null</code> if
    *            none). See the JMS specification for a detailed definition of
    *            selector expressions.
    * @return the message produced for the consumer or <code>null</code> if
    *         the timeout expires.
    * @throws JmsServiceException
    *             checked JMSException converted to unchecked
    */
   Message receiveSelected(String destinationName, String messageSelector)
      throws JmsServiceException;

   /**
    * Receive a message synchronously from the default destination, but only
    * wait up to a specified time for delivery. Convert the message into an
    * object with a configured MessageConverter.
    * <p>
    * This method should be used carefully, since it will block the thread
    * until the message becomes available or until the timeout value is
    * exceeded.
    * <p>
    * This will only work with a default destination specified!
    *
    * @return the message produced for the consumer or <code>null</code> if
    *         the timeout expires.
    * @throws JmsServiceException
    *             checked JMSException converted to unchecked
    */
   Object receiveAndConvert() throws JmsServiceException;

   /**
    * Receive a message synchronously from the specified destination, but only
    * wait up to a specified time for delivery. Convert the message into an
    * object with a configured MessageConverter.
    * <p>
    * This method should be used carefully, since it will block the thread
    * until the message becomes available or until the timeout value is
    * exceeded.
    *
    * @param destination
    *            the destination to receive a message from
    * @return the message produced for the consumer or <code>null</code> if
    *         the timeout expires.
    * @throws JmsServiceException
    *             checked JMSException converted to unchecked
    */
   Object receiveAndConvert(Destination destination) throws JmsServiceException;

   /**
    * Receive a message synchronously from the specified destination, but only
    * wait up to a specified time for delivery. Convert the message into an
    * object with a configured MessageConverter.
    * <p>
    * This method should be used carefully, since it will block the thread
    * until the message becomes available or until the timeout value is
    * exceeded.
    *
    * @param destinationName
    *            the name of the destination to send this message to (to be
    *            resolved to an actual destination by a DestinationResolver)
    * @return the message produced for the consumer or <code>null</code> if
    *         the timeout expires.
    * @throws JmsServiceException
    *             checked JMSException converted to unchecked
    */
   Object receiveAndConvert(String destinationName) throws JmsServiceException;

   /**
    * Receive a message synchronously from the default destination, but only
    * wait up to a specified time for delivery. Convert the message into an
    * object with a configured MessageConverter.
    * <p>
    * This method should be used carefully, since it will block the thread
    * until the message becomes available or until the timeout value is
    * exceeded.
    * <p>
    * This will only work with a default destination specified!
    *
    * @param messageSelector
    *            the JMS message selector expression (or <code>null</code> if
    *            none). See the JMS specification for a detailed definition of
    *            selector expressions.
    * @return the message produced for the consumer or <code>null</code> if
    *         the timeout expires.
    * @throws JmsServiceException
    *             checked JMSException converted to unchecked
    */
   Object receiveSelectedAndConvert(String messageSelector)
      throws JmsServiceException;

   /**
    * Receive a message synchronously from the specified destination, but only
    * wait up to a specified time for delivery. Convert the message into an
    * object with a configured MessageConverter.
    * <p>
    * This method should be used carefully, since it will block the thread
    * until the message becomes available or until the timeout value is
    * exceeded.
    *
    * @param destination
    *            the destination to receive a message from
    * @param messageSelector
    *            the JMS message selector expression (or <code>null</code> if
    *            none). See the JMS specification for a detailed definition of
    *            selector expressions.
    * @return the message produced for the consumer or <code>null</code> if
    *         the timeout expires.
    * @throws JmsServiceException
    *             checked JMSException converted to unchecked
    */
   Object receiveSelectedAndConvert(Destination destination,
      String messageSelector) throws JmsServiceException;

   /**
    * Receive a message synchronously from the specified destination, but only
    * wait up to a specified time for delivery. Convert the message into an
    * object with a configured MessageConverter.
    * <p>
    * This method should be used carefully, since it will block the thread
    * until the message becomes available or until the timeout value is
    * exceeded.
    *
    * @param destinationName
    *            the name of the destination to send this message to (to be
    *            resolved to an actual destination by a DestinationResolver)
    * @param messageSelector
    *            the JMS message selector expression (or <code>null</code> if
    *            none). See the JMS specification for a detailed definition of
    *            selector expressions.
    * @return the message produced for the consumer or <code>null</code> if
    *         the timeout expires.
    * @throws JmsServiceException
    *             checked JMSException converted to unchecked
    */
   Object receiveSelectedAndConvert(String destinationName,
      String messageSelector) throws JmsServiceException;
}
