/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.jms;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.jms.core.JmsOperations;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;


/**
 *
 * @author romaferre
 *static methods to:
 * - obtain the service from the servlet context and
 * - to get an JmsServiceOperations object from a request (resolves the service by examining the request)
 */
public class JmsServiceUtils {
   /**
    * Documentaci�.
    *
    * @param context Documentaci�
    *
    * @return Documentaci�
    */
   public static JmsService getService(ServletContext context) {
      WebApplicationContext webContext = WebApplicationContextUtils.getRequiredWebApplicationContext(context);

      return (JmsService) webContext.getBean(JmsService.JMS_BEAN_FACTORY_KEY);
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    * @param name Documentaci�
    *
    * @return Documentaci�
    */
   public static JmsServiceOperations getOperations(
      HttpServletRequest request, String name) {
      if (name == null) {
         return getOperations(request);
      }

      JmsService service = getService(request.getSession().getServletContext());

      if (service != null) {
         return service.getJmsOperations(name);
      }

      return JmsServiceOperations.EMPTY_INSTANCE;
   }

   /**
    * Documentaci�.
    *
    * @param request Documentaci�
    *
    * @return Documentaci�
    */
   public static JmsServiceOperations getOperations(HttpServletRequest request) {
      JmsService service = getService(request.getSession().getServletContext());

      if (service != null) {
         return service.getDefaultJmsOperations();
      }

      return JmsServiceOperations.EMPTY_INSTANCE;
   }
}
