/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.services.jms.impl;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import java.util.Properties;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.Message;

import javax.naming.NamingException;

import net.gencat.ctti.canigo.services.jms.JmsConfiguration;
import net.gencat.ctti.canigo.services.jms.JmsServiceOperations;
import net.gencat.ctti.canigo.services.jms.exception.JmsServiceException;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.jndi.JndiTemplate;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision: 1.4 $
  */
public class JmsOperationsImpl implements JmsConfiguration,
   JmsServiceOperations, JndiConfiguration {
   /**
    * Documentaci�.
    */
   private ConnectionFactory connectionFactory;

   /**
    * Documentaci�.
    */
   private JmsConfiguration configDelegate;

   /**
    * Documentaci�.
    */
   private JmsServiceOperations delegate;

   /**
    * Documentaci�.
    */
   private String connectionFactoryName;

   /**
    * Documentaci�.
    */
   private String namingContextFactory;

   /**
    * Documentaci�.
    */
   private String namingCredentials;

   /**
    * Documentaci�.
    */
   private String namingPrincipal;

   /**
    * Documentaci�.
    */
   private String namingProviderUrl;

   /**
    * Creates a new JmsOperationsImpl object.
    */
   public JmsOperationsImpl() {
      super();
      delegate = getInstance();
      configDelegate = (JmsConfiguration) delegate;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   protected JmsServiceOperations getInstance() {
      /**
       * Documentaci�.
       *
       * @author $author$
       * @version $Revision: 1.4 $
        */
      class JmsTemplateWrapped extends JmsTemplate implements JmsConfiguration,
         JmsServiceOperations {
      }

      final JmsTemplate templ = new JmsTemplateWrapped();

      return (JmsServiceOperations) Proxy.newProxyInstance(JmsTemplate.class.getClassLoader(),
         new Class[] { JmsConfiguration.class, JmsServiceOperations.class },
         new InvocationHandler() {
            public Object invoke(Object proxy, Method method, Object[] args)
               throws Throwable {
               try {
                  if ((templ.getConnectionFactory() == null) &&
                        method.getDeclaringClass()
                                 .isAssignableFrom(JmsServiceOperations.class)) {
                     if (getConnectionFactory() == null) {
                        obtainConnectionFactoryFromJNDI();
                     }

                     templ.setConnectionFactory(getConnectionFactory());
                  }

                  if (args != null) {
                     return method.invoke(templ, args);
                  }

                  return method.invoke(templ, new Object[] {  });
               } catch (JmsException jmsex) {
                  throw new JmsServiceException(jmsex, "");
               } catch (Exception ex) {
                  throw new JmsServiceException(ex, "");
               }
            }
         });
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public JmsTemplate getJmsTemplate() {
      return (JmsTemplate) delegate;
   }

   /**
    * Documentaci�.
    *
    * @param destination Documentaci�
    * @param message Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public void convertAndSend(Destination destination, Object message)
      throws JmsServiceException {
      delegate.convertAndSend(destination, message);
   }

   /**
    * Documentaci�.
    *
    * @param message Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public void convertAndSend(Object message) throws JmsServiceException {
      delegate.convertAndSend(message);
   }

   /**
    * Documentaci�.
    *
    * @param destinationName Documentaci�
    * @param message Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public void convertAndSend(String destinationName, Object message)
      throws JmsServiceException {
      delegate.convertAndSend(destinationName, message);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public Message receive() throws JmsServiceException {
      return delegate.receive();
   }

   /**
    * Documentaci�.
    *
    * @param destination Documentaci�
    *
    * @return Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public Message receive(Destination destination) throws JmsServiceException {
      return delegate.receive(destination);
   }

   /**
    * Documentaci�.
    *
    * @param destinationName Documentaci�
    *
    * @return Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public Message receive(String destinationName) throws JmsServiceException {
      return delegate.receive(destinationName);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public Object receiveAndConvert() throws JmsServiceException {
      return delegate.receiveAndConvert();
   }

   /**
    * Documentaci�.
    *
    * @param destination Documentaci�
    *
    * @return Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public Object receiveAndConvert(Destination destination)
      throws JmsServiceException {
      return delegate.receiveAndConvert(destination);
   }

   /**
    * Documentaci�.
    *
    * @param destinationName Documentaci�
    *
    * @return Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public Object receiveAndConvert(String destinationName)
      throws JmsServiceException {
      return delegate.receiveAndConvert(destinationName);
   }

   /**
    * Documentaci�.
    *
    * @param destination Documentaci�
    * @param messageSelector Documentaci�
    *
    * @return Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public Message receiveSelected(Destination destination,
      String messageSelector) throws JmsServiceException {
      return delegate.receiveSelected(destination, messageSelector);
   }

   /**
    * Documentaci�.
    *
    * @param destinationName Documentaci�
    * @param messageSelector Documentaci�
    *
    * @return Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public Message receiveSelected(String destinationName, String messageSelector)
      throws JmsServiceException {
      return delegate.receiveSelected(destinationName, messageSelector);
   }

   /**
    * Documentaci�.
    *
    * @param messageSelector Documentaci�
    *
    * @return Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public Message receiveSelected(String messageSelector)
      throws JmsServiceException {
      return delegate.receiveSelected(messageSelector);
   }

   /**
    * Documentaci�.
    *
    * @param destination Documentaci�
    * @param messageSelector Documentaci�
    *
    * @return Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public Object receiveSelectedAndConvert(Destination destination,
      String messageSelector) throws JmsServiceException {
      return delegate.receiveSelectedAndConvert(destination, messageSelector);
   }

   /**
    * Documentaci�.
    *
    * @param destinationName Documentaci�
    * @param messageSelector Documentaci�
    *
    * @return Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public Object receiveSelectedAndConvert(String destinationName,
      String messageSelector) throws JmsServiceException {
      return delegate.receiveSelectedAndConvert(destinationName, messageSelector);
   }

   /**
    * Documentaci�.
    *
    * @param messageSelector Documentaci�
    *
    * @return Documentaci�
    *
    * @throws JmsServiceException Documentaci�
    */
   public Object receiveSelectedAndConvert(String messageSelector)
      throws JmsServiceException {
      return delegate.receiveSelectedAndConvert(messageSelector);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public Destination getDefaultDestination() {
      return configDelegate.getDefaultDestination();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getDefaultDestinationName() {
      return configDelegate.getDefaultDestinationName();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getDeliveryMode() {
      return configDelegate.getDeliveryMode();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public int getPriority() {
      return configDelegate.getPriority();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public long getReceiveTimeout() {
      return configDelegate.getReceiveTimeout();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public long getTimeToLive() {
      return configDelegate.getTimeToLive();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isExplicitQosEnabled() {
      return configDelegate.isExplicitQosEnabled();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isMessageIdEnabled() {
      return configDelegate.isMessageIdEnabled();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isMessageTimestampEnabled() {
      return configDelegate.isMessageTimestampEnabled();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public boolean isPubSubNoLocal() {
      return configDelegate.isPubSubNoLocal();
   }

   /**
    * Documentaci�.
    *
    * @param destination Documentaci�
    */
   public void setDefaultDestination(Destination destination) {
      configDelegate.setDefaultDestination(destination);
   }

   /**
    * Documentaci�.
    *
    * @param defaultDestinationName Documentaci�
    */
   public void setDefaultDestinationName(String defaultDestinationName) {
      configDelegate.setDefaultDestinationName(defaultDestinationName);
   }

   /**
    * Documentaci�.
    *
    * @param deliveryMode Documentaci�
    */
   public void setDeliveryMode(int deliveryMode) {
      configDelegate.setDeliveryMode(deliveryMode);
   }

   /**
    * Documentaci�.
    *
    * @param deliveryPersistent Documentaci�
    */
   public void setDeliveryPersistent(boolean deliveryPersistent) {
      configDelegate.setDeliveryPersistent(deliveryPersistent);
   }

   /**
    * Documentaci�.
    *
    * @param explicitQosEnabled Documentaci�
    */
   public void setExplicitQosEnabled(boolean explicitQosEnabled) {
      configDelegate.setExplicitQosEnabled(explicitQosEnabled);
   }

   /**
    * Documentaci�.
    *
    * @param messageIdEnabled Documentaci�
    */
   public void setMessageIdEnabled(boolean messageIdEnabled) {
      configDelegate.setMessageIdEnabled(messageIdEnabled);
   }

   /**
    * Documentaci�.
    *
    * @param messageTimestampEnabled Documentaci�
    */
   public void setMessageTimestampEnabled(boolean messageTimestampEnabled) {
      configDelegate.setMessageTimestampEnabled(messageTimestampEnabled);
   }

   /**
    * Documentaci�.
    *
    * @param priority Documentaci�
    */
   public void setPriority(int priority) {
      configDelegate.setPriority(priority);
   }

   /**
    * Documentaci�.
    *
    * @param pubSubNoLocal Documentaci�
    */
   public void setPubSubNoLocal(boolean pubSubNoLocal) {
      configDelegate.setPubSubNoLocal(pubSubNoLocal);
   }

   /**
    * Documentaci�.
    *
    * @param receiveTimeout Documentaci�
    */
   public void setReceiveTimeout(long receiveTimeout) {
      configDelegate.setReceiveTimeout(receiveTimeout);
   }

   /**
    * Documentaci�.
    *
    * @param timeToLive Documentaci�
    */
   public void setTimeToLive(long timeToLive) {
      configDelegate.setTimeToLive(timeToLive);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getNamingContextFactory() {
      return namingContextFactory;
   }

   /**
    * Documentaci�.
    *
    * @param namingContextFactory Documentaci�
    */
   public void setNamingContextFactory(String namingContextFactory) {
      this.namingContextFactory = namingContextFactory;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getNamingCredentials() {
      return namingCredentials;
   }

   /**
    * Documentaci�.
    *
    * @param namingCredentials Documentaci�
    */
   public void setNamingCredentials(String namingCredentials) {
      this.namingCredentials = namingCredentials;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getNamingPrincipal() {
      return namingPrincipal;
   }

   /**
    * Documentaci�.
    *
    * @param namingPrincipal Documentaci�
    */
   public void setNamingPrincipal(String namingPrincipal) {
      this.namingPrincipal = namingPrincipal;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getNamingProviderUrl() {
      return namingProviderUrl;
   }

   /**
    * Documentaci�.
    *
    * @param namingProviderUrl Documentaci�
    */
   public void setNamingProviderUrl(String namingProviderUrl) {
      this.namingProviderUrl = namingProviderUrl;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public String getConnectionFactoryName() {
      return connectionFactoryName;
   }

   /**
    * Documentaci�.
    *
    * @param connectionFactoryName Documentaci�
    */
   public void setConnectionFactoryName(String connectionFactoryName) {
      this.connectionFactoryName = connectionFactoryName;
   }

   /**
    * Documentaci�.
    */
   private void obtainConnectionFactoryFromJNDI() {
      try {
         if (connectionFactory == null) {
            Properties props = new Properties();

            if (namingContextFactory != null) {
               props.setProperty("java.naming.factory.initial",
                  namingContextFactory);
            }

            if (namingProviderUrl != null) {
               props.setProperty("java.naming.provider.url", namingProviderUrl);
            }

            if (namingPrincipal != null) {
               props.setProperty("java.naming.security.principal",
                  namingPrincipal);
            }

            if (namingCredentials != null) {
               props.setProperty("java.naming.security.credentials",
                  namingCredentials);
            }

            JndiObjectFactoryBean jndiFactory = new JndiObjectFactoryBean();
            jndiFactory.setJndiTemplate(new JndiTemplate(props));
            jndiFactory.setJndiName(connectionFactoryName);
            jndiFactory.afterPropertiesSet();
            connectionFactory = (ConnectionFactory) jndiFactory.getObject();
         }
      } catch (NamingException e) {
         throw new JmsServiceException("");
      }
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ConnectionFactory getConnectionFactory() {
      return connectionFactory;
   }

   /**
    * Documentaci�.
    *
    * @param connectionFactory Documentaci�
    */
   public void setConnectionFactory(ConnectionFactory connectionFactory) {
      this.connectionFactory = connectionFactory;
   }
}
