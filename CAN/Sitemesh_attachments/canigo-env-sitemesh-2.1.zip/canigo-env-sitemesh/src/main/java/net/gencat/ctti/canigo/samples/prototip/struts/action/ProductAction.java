/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.samples.prototip.struts.action;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import net.gencat.ctti.canigo.samples.prototip.model.Item;
import net.gencat.ctti.canigo.samples.prototip.model.Product;
import net.gencat.ctti.canigo.samples.prototip.model.bo.CategoryBO;
import net.gencat.ctti.canigo.samples.prototip.model.bo.ItemBO;
import net.gencat.ctti.canigo.samples.prototip.model.bo.ProductBO;
import net.gencat.ctti.canigo.samples.prototip.web.spring.view.document.XMLView;
import net.gencat.ctti.canigo.services.web.lists.ValueListActionHelper;
import net.gencat.ctti.canigo.services.web.struts.DispatchActionSupport;
import net.gencat.ctti.canigo.services.web.struts.SpringBindingActionForm;
import net.gencat.ctti.canigo.services.xml.XMLSerializationService;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision$
  */
public class ProductAction extends DispatchActionSupport {
   /**
    * Documentaci�.
    */
   private CategoryBO categoryBO;

   /**
    * Documentaci�.
    */
   private ItemBO itemBO;

   /**
    * Documentaci�.
    */
   private ProductBO productBO;

   /**
    * Documentaci�.
    */
   private ValueListActionHelper valueListActionHelper;

   /**
    * Documentaci�.
    */
   private XMLSerializationService serializationService;

   /**
    * @return Returns the serializationService.
    */
   public XMLSerializationService getSerializationService() {
      return serializationService;
   }

   /**
    * @param serializationService The serializationService to set.
    */
   public void setSerializationService(
      XMLSerializationService serializationService) {
      this.serializationService = serializationService;
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward create(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      return mapping.findForward("create");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward edit(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      SpringBindingActionForm actionForm = (SpringBindingActionForm) form;
      Product vo = (Product) actionForm.getTarget();

      if (vo.getId() != null) {
         productBO.refresh(vo);
      }

      return mapping.findForward("edit");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward save(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      SpringBindingActionForm actionForm = (SpringBindingActionForm) form;
      Product vo = (Product) actionForm.getTarget();

      if ((vo.getCategory() != null) && (vo.getCategory().getId() != null)) {
         this.categoryBO.refresh(vo.getCategory());
         this.logService.getLog(this.getClass())
                        .debug("Category: " + vo.getCategory().getId());
      }

      if (vo.getId() != null) {
         productBO.saveOrUpdate(vo);
      }

      return mapping.findForward("success");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward search(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      valueListActionHelper.search(mapping, form, request, response);

      return mapping.findForward("list");
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ProductBO getDao() {
      return productBO;
   }

   /**
    * Documentaci�.
    *
    * @param productBO Documentaci�
    */
   public void setDao(ProductBO productBO) {
      this.productBO = productBO;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ValueListActionHelper getValueListActionHelper() {
      return valueListActionHelper;
   }

   /**
    * Documentaci�.
    *
    * @param valueListActionHelper Documentaci�
    */
   public void setValueListActionHelper(
      ValueListActionHelper valueListActionHelper) {
      this.valueListActionHelper = valueListActionHelper;
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward searchExportPDF(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      request.setAttribute("displayProvider", "ExportPDF");

      return this.search(mapping, form, request, response);
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward searchExportExcel(ActionMapping mapping,
      ActionForm form, javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      request.setAttribute("displayProvider", "ExportExcel");

      return this.search(mapping, form, request, response);
   }

   /**
    * @return Returns the categoryBO.
    */
   public CategoryBO getCategoryDao() {
      return categoryBO;
   }

   /**
    * @param categoryBO The categoryBO to set.
    */
   public void setCategoryDao(CategoryBO categoryBO) {
      this.categoryBO = categoryBO;
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward searchExportXML(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      this.logService.getLog(this.getClass()).debug("Searching products...");

      List list = ((ProductBO) this.productBO).findAll();
      this.logService.getLog(this.getClass())
                     .debug("La lista tiene " + list.size() + " elementos");

      if (list != null) {
         request.setAttribute(XMLView.XML_LIST, list);
      }

      if (serializationService != null) {
         request.setAttribute(XMLView.XML_SERIALIZATION_SERVICE,
            serializationService);
      }

      return mapping.findForward("xml");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward editMasterDetail(ActionMapping mapping,
      ActionForm form, javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      search(mapping, form, request, response);

      return mapping.findForward("edit");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward saveDetail(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      SpringBindingActionForm actionForm = (SpringBindingActionForm) form;

      Collection detail = actionForm.getTargetDetail();

      if (detail != null) {
         Iterator iteDetail = detail.iterator();

         while (iteDetail.hasNext()) {
            Item vo = (Item) iteDetail.next();

            if ((vo.getProductid() != null) &&
                  (vo.getProductid().getId() != null)) {
               this.productBO.refresh(vo.getProductid());
               this.logService.getLog(this.getClass())
                              .debug("Product: " + vo.getProductid().getId());
            }

            if (vo.getId() != null) {
               itemBO.saveOrUpdate(vo);
            }
         }
      }

      return mapping.findForward("success");
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ItemBO getItemDao() {
      return itemBO;
   }

   /**
    * Documentaci�.
    *
    * @param itemBO Documentaci�
    */
   public void setItemDao(ItemBO itemBO) {
      this.itemBO = itemBO;
   }
}
