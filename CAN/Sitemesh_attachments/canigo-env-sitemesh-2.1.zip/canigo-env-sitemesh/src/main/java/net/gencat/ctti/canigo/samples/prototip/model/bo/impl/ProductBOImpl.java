/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.samples.prototip.model.bo.impl;

import java.util.List;

import net.gencat.ctti.canigo.samples.prototip.model.Product;
import net.gencat.ctti.canigo.samples.prototip.model.bo.ProductBO;
import net.gencat.ctti.canigo.services.persistence.HibernateDAO;
import net.gencat.ctti.canigo.services.persistence.UniversalHibernateDAO;

import org.apache.commons.beanutils.BeanUtils;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision$
  */
public class ProductBOImpl implements ProductBO {
   /**
    * Documentaci�.
    */
   UniversalHibernateDAO dao;

   /**
    * Creates a new ProductBOImpl object.
    */
   public ProductBOImpl() {
      super();
   }

   /**
    * Documentaci�.
    */
   public void test() {
      System.out.println("------------> test");
   }

   /**
    * Documentaci�.
    *
    * @param id Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public Product getProductById(String id) throws Exception {
      return (Product) dao.get(Product.class, id);
   }

   /**
    * Documentaci�.
    *
    * @param product Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void save(Product product) throws Exception {
      // First try to see if exists the product
      //Product tmpProduct = new Product();
      //BeanUtils.copyProperties(tmpProduct,product);

      //dao.refresh(product);
      //BeanUtils.copyProperties(product,tmpProduct);		
      this.test();
      dao.save(product);
   }

   /**
    * Documentaci�.
    *
    * @param product Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void update(Product product) throws Exception {
      this.test();

      Product tmpProduct = new Product();
      tmpProduct.setId(product.getId());
      BeanUtils.copyProperties(tmpProduct, product);
      //		
      dao.refresh(tmpProduct);
      BeanUtils.copyProperties(tmpProduct, product);
      //		productDAO.refresh(tmpProduct);
      //		BeanUtils.c
      System.out.println("Update");
      dao.update(tmpProduct);
   }

   /**
    * Documentaci�.
    *
    * @param product Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void delete(Product product) throws Exception {
      this.test();
      dao.delete(product);
   }

   /**
    * Documentaci�.
    *
    * @param product Documentaci�
    *
    * @return Documentaci�
    */
   public Product load(Product product) {
      this.test();
      dao.refresh(product);

      return product;
   }

   /**
    * Documentaci�.
    *
    * @param product Documentaci�
    *
    * @return Documentaci�
    */
   public Product refresh(Product product) {
      this.test();
      dao.refresh(product);

      return product;
   }

   /**
    * Documentaci�.
    *
    * @param product Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public void saveOrUpdate(Product product) throws Exception {
      this.test();
      dao.saveOrUpdate(product);
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public List findAll() {
      return ((HibernateDAO) (dao)).findAll();
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public UniversalHibernateDAO getDao() {
      return dao;
   }

   /**
    * Documentaci�.
    *
    * @param dao Documentaci�
    */
   public void setDao(UniversalHibernateDAO dao) {
      this.dao = dao;
   }
}
