/*
 * ,m6Y=,:.gM##Od###a,:?"DGK   Generalitat de Catalunya
 * .#J=.dNJ7M#F` H#P!JMx,T?b
 * J1!.M##  M#F  #Hr ,##N,iW
 * J!d3H##  M#F  ##r ,##L4,?   CTTI
 *  .t\d##` M#F  ##r ,#H:lH,   Canigo
 * .#` d##  MHF` #Hr ,##:,,b
 * .Fr d##  M#F  ##r ,#H: cN   http://www.gencat.net/
 * ,F\ d##  M#F  ##r ,##: l#
 * .Nj d##  M#F` #Hr ,##:.+F
 *  Xc;d##` MHF  ##r ,##:2d!   Aquest codi �s propietat de la Generalitat de
 * ,.W,d##  M#F  ##r ,##2J$.   Catalunya. La seva distribuci� est� prohibida
 * JJ,4H##  M#F` ##r`,##d3`J   sense el seu consentiment
 * ,N..?M#1.M#F  #HL.w#Y...F
 * .@Ja,:,TWM##1O##NT".?.sJK   2007, Tots els drets reservats
 */
package net.gencat.ctti.canigo.samples.prototip.struts.action;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.gencat.ctti.canigo.samples.prototip.model.Item;
import net.gencat.ctti.canigo.samples.prototip.model.bo.ItemBO;
import net.gencat.ctti.canigo.samples.prototip.model.bo.ProductBO;
import net.gencat.ctti.canigo.samples.prototip.web.spring.view.document.XMLView;
import net.gencat.ctti.canigo.services.exceptions.BusinessException;
import net.gencat.ctti.canigo.services.ole.OleController;
import net.gencat.ctti.canigo.services.reporting.ReportingController;
import net.gencat.ctti.canigo.services.web.lists.ValueListActionHelper;
import net.gencat.ctti.canigo.services.web.struts.DispatchActionSupport;
import net.gencat.ctti.canigo.services.web.struts.SpringBindingActionForm;
import net.gencat.ctti.canigo.services.xml.XMLSerializationService;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Hibernate;


/**
 * Documentaci�.
 *
 * @author $author$
 * @version $Revision$
  */
public class ItemAction extends DispatchActionSupport {
   /**
    * Documentaci�.
    */
   private ItemBO itemBO;

   /**
    * Documentaci�.
    */
   private ProductBO productBO;

   /**
    * Documentaci�.
    */
   private ValueListActionHelper valueListActionHelper;

   /**
    * Documentaci�.
    */
   private XMLSerializationService serializationService;

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward edit(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      SpringBindingActionForm actionForm = (SpringBindingActionForm) form;
      Item vo = (Item) actionForm.getTarget();

      if (vo.getId() != null) {
         itemBO.refresh(vo);
      }

      return mapping.findForward("edit");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward create(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      this.logService.getLog(this.getClass()).debug("Creating new item...");

      SpringBindingActionForm actionForm = (SpringBindingActionForm) form;
      Item vo = (Item) actionForm.getTarget();

      if ((vo.getProductid() != null) && (vo.getProductid().getId() != null)) {
         this.productBO.refresh(vo.getProductid());
         this.logService.getLog(this.getClass())
                        .debug("Product: " + vo.getProductid().getId());
      }

      return mapping.findForward("create");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward save(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      SpringBindingActionForm actionForm = (SpringBindingActionForm) form;
      Item vo = (Item) actionForm.getTarget();
      this.logService.getLog(this.getClass())
                     .debug("Saving item: " + vo.getId() + " with product " +
         vo.getProductid());

      if ((vo.getProductid() != null) && (vo.getProductid().getId() != null)) {
         this.productBO.refresh(vo.getProductid());
         this.logService.getLog(this.getClass())
                        .debug("Product: " + vo.getProductid().getId());
      }

      if (vo.getId() != null) {
         itemBO.saveOrUpdate(vo);
      }

      return mapping.findForward("success");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward delete(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      SpringBindingActionForm actionForm = (SpringBindingActionForm) form;
      Item vo = (Item) actionForm.getTarget();
      this.logService.getLog(this.getClass())
                     .debug("Deleting item: " + vo.getId());

      if (vo.getId() != null) {
         itemBO.refresh(vo);
         itemBO.delete(vo);
      }

      return mapping.findForward("success");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    * @throws BusinessException Documentaci�
    */
   public ActionForward saveNew(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      SpringBindingActionForm actionForm = (SpringBindingActionForm) form;
      Item vo = (Item) actionForm.getTarget();

      if (vo.getId() != null) {
         Item existingItem = itemBO.getItemById(vo.getId());

         if (existingItem != null) {
            throw new BusinessException("items.duplicated_item",
               new Object[] { vo.getId() });
         }

         itemBO.save(vo);
      }

      return mapping.findForward("success");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward search(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      valueListActionHelper.search(mapping, form, request, response);

      return mapping.findForward("list");
   }

   /**
    * @return Returns the productBO.
    */
   public ProductBO getProductDao() {
      return productBO;
   }

   /**
    * @param productBO The productBO to set.
    */
   public void setProductDao(ProductBO productBO) {
      this.productBO = productBO;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ValueListActionHelper getValueListActionHelper() {
      return valueListActionHelper;
   }

   /**
    * Documentaci�.
    *
    * @param valueListActionHelper Documentaci�
    */
   public void setValueListActionHelper(
      ValueListActionHelper valueListActionHelper) {
      this.valueListActionHelper = valueListActionHelper;
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward searchExportPDF(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      request.setAttribute("displayProvider", "ExportPDF");

      return this.search(mapping, form, request, response);
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward searchExportExcel(ActionMapping mapping,
      ActionForm form, javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      request.setAttribute("displayProvider", "ExportExcel");

      return this.search(mapping, form, request, response);
   }

   /**
    * @return Returns the serializationService.
    */
   public XMLSerializationService getSerializationService() {
      return serializationService;
   }

   /**
    * @param serializationService The serializationService to set.
    */
   public void setSerializationService(
      XMLSerializationService serializationService) {
      this.serializationService = serializationService;
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward searchExportXML(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      this.logService.getLog(this.getClass()).debug("Searching items...");

      List list = (this.itemBO).findAll();
      this.logService.getLog(this.getClass())
                     .debug("La lista tiene " + list.size() + " elementos");

      if (list != null) {
         request.setAttribute(XMLView.XML_LIST, list);
      }

      if (serializationService != null) {
         request.setAttribute(XMLView.XML_SERIALIZATION_SERVICE,
            serializationService);
      }

      return mapping.findForward("xml");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward viewOleWord(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      this.logService.getLog(this.getClass()).debug("Searching items...");

      List list = (this.itemBO).findAll();
      this.logService.getLog(this.getClass()).debug("List size=" + list.size());

      if (list != null) {
         Map model = new HashMap();
         Iterator it = list.iterator();

         while (it.hasNext()) {
            Item i = (Item) it.next();
            Hibernate.initialize(i.getProductid().getCategory());
         }

         model.put("itemList", list);
         request.getSession()
                .setAttribute(OleController.OLE_CONTROLLER_MODEL, model);
         request.getSession()
                .setAttribute(OleController.OLE_CONTROLLER_VIEWID,
            "itemsWordView");
      }

      return mapping.findForward("oleController");
   }

   /**
    * Documentaci�.
    *
    * @param mapping Documentaci�
    * @param form Documentaci�
    * @param request Documentaci�
    * @param response Documentaci�
    *
    * @return Documentaci�
    *
    * @throws Exception Documentaci�
    */
   public ActionForward report(ActionMapping mapping, ActionForm form,
      javax.servlet.http.HttpServletRequest request,
      javax.servlet.http.HttpServletResponse response)
      throws Exception {
      this.logService.getLog(this.getClass()).debug("Searching items...");

      List list = (this.itemBO).findAll();
      this.logService.getLog(this.getClass()).debug("List size=" + list.size());

      if (list != null) {
         Map model = new HashMap();
         Iterator it = list.iterator();

         while (it.hasNext()) {
            Item i = (Item) it.next();
            Hibernate.initialize(i.getProductid().getCategory());
         }

         model.put("itemList", list);
         model.put("title", "Items");
         request.getSession()
                .setAttribute(ReportingController.REPORTING_CONTROLLER_MODEL,
            model);
         request.getSession()
                .setAttribute(ReportingController.REPORTING_CONTROLLER_REPORTID,
            "itemsReportView");
      }

      return mapping.findForward("reportsController");
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ProductBO getProductBO() {
      return productBO;
   }

   /**
    * Documentaci�.
    *
    * @param productBO Documentaci�
    */
   public void setProductBO(ProductBO productBO) {
      this.productBO = productBO;
   }

   /**
    * Documentaci�.
    *
    * @return Documentaci�
    */
   public ItemBO getItemBO() {
      return itemBO;
   }

   /**
    * Documentaci�.
    *
    * @param itemBO Documentaci�
    */
   public void setItemBO(ItemBO itemBO) {
      this.itemBO = itemBO;
   }
}
